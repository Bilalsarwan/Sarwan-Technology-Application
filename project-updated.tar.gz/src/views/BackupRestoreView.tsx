import React, { useState } from 'react';
import { exportFullBackupData } from '../services/db';
import {
  Download,
  Upload,
  Database,
  CheckCircle2,
  AlertTriangle,
  Clock,
  ShieldCheck,
  FileCode,
} from 'lucide-react';

interface BackupRestoreViewProps {
  stats: {
    invoicesCount: number;
    customersCount: number;
    paymentsCount: number;
    expensesCount: number;
  };
}

export const BackupRestoreView: React.FC<BackupRestoreViewProps> = ({ stats }) => {
  const [downloading, setDownloading] = useState<boolean>(false);
  const [lastExportTime, setLastExportTime] = useState<string | null>(null);
  const [statusMsg, setStatusMsg] = useState<{ type: 'success' | 'error'; text: string } | null>(
    null
  );

  const handleDownloadBackup = async () => {
    setDownloading(true);
    setStatusMsg(null);
    try {
      const data = await exportFullBackupData();
      const dateStr = new Date().toISOString().replace(/[:.]/g, '-').slice(0, 19);
      const filename = `sarwan_tech_backup_${dateStr}.json`;

      const jsonStr = JSON.stringify(data, null, 2);
      const blob = new Blob([jsonStr], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.setAttribute('download', filename);
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);

      setLastExportTime(new Date().toLocaleString());
      setStatusMsg({
        type: 'success',
        text: `Complete system backup downloaded successfully (${(
          jsonStr.length / 1024
        ).toFixed(1)} KB). Contains ${data.counts.invoices} invoices and ${
          data.counts.customers
        } customers.`,
      });
    } catch (err: any) {
      console.error('Backup error:', err);
      setStatusMsg({ type: 'error', text: 'Failed to generate system backup.' });
    } finally {
      setDownloading(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="bg-white rounded-xl p-5 border border-neutral-200 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-xs font-semibold text-orange-600">
            <Database className="w-4 h-4" />
            <span>Data Continuity &amp; Disaster Recovery</span>
          </div>
          <h1 className="text-xl font-bold text-neutral-900 mt-1">
            Full System Backup &amp; Recovery
          </h1>
          <p className="text-xs text-neutral-500 mt-0.5">
            Export complete financial data, customer ledger, invoices, cash payments, and audit logs.
          </p>
        </div>

        <button
          onClick={handleDownloadBackup}
          disabled={downloading}
          className="px-4 py-2.5 bg-[#F58220] hover:bg-[#e0751a] text-white text-xs font-bold rounded-lg shadow-xs transition flex items-center gap-2 disabled:opacity-50 cursor-pointer active:scale-98"
        >
          <Download className="w-4 h-4" />
          <span>{downloading ? 'Compiling Backup...' : 'Download Full Backup (.json)'}</span>
        </button>
      </div>

      {statusMsg && (
        <div
          className={`p-4 rounded-xl text-xs font-medium flex items-center gap-2.5 ${
            statusMsg.type === 'success'
              ? 'bg-emerald-50 text-emerald-800 border border-emerald-200'
              : 'bg-red-50 text-red-800 border border-red-200'
          }`}
        >
          {statusMsg.type === 'success' ? (
            <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-600" />
          ) : (
            <AlertTriangle className="w-4 h-4 shrink-0 text-red-600" />
          )}
          <span>{statusMsg.text}</span>
        </div>
      )}

      {/* Overview Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        <div className="bg-white p-4 rounded-xl border border-neutral-200 shadow-xs">
          <p className="text-xs text-neutral-500 font-medium">Total Invoices</p>
          <p className="text-xl font-bold text-neutral-900 mt-1">{stats.invoicesCount}</p>
          <p className="text-[10px] text-neutral-400 mt-0.5">Stored in Firestore</p>
        </div>

        <div className="bg-white p-4 rounded-xl border border-neutral-200 shadow-xs">
          <p className="text-xs text-neutral-500 font-medium">Registered Customers</p>
          <p className="text-xl font-bold text-neutral-900 mt-1">{stats.customersCount}</p>
          <p className="text-[10px] text-neutral-400 mt-0.5">Account profiles</p>
        </div>

        <div className="bg-white p-4 rounded-xl border border-neutral-200 shadow-xs">
          <p className="text-xs text-neutral-500 font-medium">Cash Payments</p>
          <p className="text-xl font-bold text-neutral-900 mt-1">{stats.paymentsCount}</p>
          <p className="text-[10px] text-neutral-400 mt-0.5">Audited receipts</p>
        </div>

        <div className="bg-white p-4 rounded-xl border border-neutral-200 shadow-xs">
          <p className="text-xs text-neutral-500 font-medium">Expense Records</p>
          <p className="text-xl font-bold text-neutral-900 mt-1">{stats.expensesCount}</p>
          <p className="text-[10px] text-neutral-400 mt-0.5">Operating costs</p>
        </div>
      </div>

      {/* Backup Standards & Security Box */}
      <div className="bg-neutral-900 text-white rounded-xl p-6 border border-neutral-800 shadow-md">
        <div className="flex items-center gap-2 text-xs font-bold text-orange-400 mb-2">
          <ShieldCheck className="w-4 h-4" />
          <span>Enterprise Backup Standards</span>
        </div>
        <h3 className="text-base font-bold text-white mb-2">
          Automated Redundancy &amp; Export Security
        </h3>
        <p className="text-xs text-neutral-300 leading-relaxed mb-4 max-w-2xl">
          Sarwan Technology's live database is continuously replicated on Google Cloud Firestore across redundant server zones. Downloading a manual JSON snapshot provides offline air-gapped protection for accounting audits and business archival.
        </p>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs text-neutral-300">
          <div className="p-3 bg-neutral-800/80 rounded-lg border border-neutral-700">
            <p className="font-bold text-white">Full Schema Integrity</p>
            <p className="text-[11px] text-neutral-400 mt-1">
              Includes 20-item row tables, Dari notes, Dahua equipment specs, and payment receipts.
            </p>
          </div>
          <div className="p-3 bg-neutral-800/80 rounded-lg border border-neutral-700">
            <p className="font-bold text-white">Zero Cloud Lock-in</p>
            <p className="text-[11px] text-neutral-400 mt-1">
              Exported as clean, readable JSON compatible with standard relational databases and spreadsheets.
            </p>
          </div>
          <div className="p-3 bg-neutral-800/80 rounded-lg border border-neutral-700">
            <p className="font-bold text-white">Audit Trail Included</p>
            <p className="text-[11px] text-neutral-400 mt-1">
              Preserves chronological transaction records with user timestamps and IDs.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
