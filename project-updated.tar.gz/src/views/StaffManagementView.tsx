import React, { useState, useMemo } from 'react';
import { UserProfile, UserRole, BusinessSettings, Customer } from '../types';
import { useAuth } from '../context/AuthContext';
import { isStaffUser, auditUserRoles, RoleAuditReport } from '../utils/userRoleAudit';
import {
  updateUserRoleAndPermissions,
  toggleUserActiveStatus,
} from '../services/db';
import { createApplicationUser, PRIMARY_ADMIN_EMAILS } from '../services/security';
import { DEFAULT_NEW_USER_PASSWORD } from '../utils/password';
import { getOfficialUserId, isProfileComplete, getProfileCompletionDetails } from '../utils/profileCompletion';
import { ProfilePhotoUpload } from '../components/common/ProfilePhotoUpload';
import { UserProfileModal } from '../components/staff/UserProfileModal';
import { UserCard } from '../components/staff/UserCard';
import { StaffCard } from '../components/staff/StaffCard';
import { UserDetailsModal } from '../components/staff/UserDetailsModal';
import {
  Users,
  ShieldCheck,
  UserPlus,
  Lock,
  AlertCircle,
  Eye,
  EyeOff,
  Loader2,
  X,
  Phone,
  Mail,
  User,
  KeyRound,
  AtSign,
  Search,
  CheckCircle2,
  XCircle,
  FileText,
  CreditCard,
  Building2,
  Briefcase,
  Shield,
  Filter,
  ExternalLink,
  ChevronRight,
  UserCheck,
} from 'lucide-react';

interface StaffManagementViewProps {
  settings?: BusinessSettings;
  users: UserProfile[];
  customers?: Customer[];
  loading?: boolean;
}

export const StaffManagementView: React.FC<StaffManagementViewProps> = ({
  settings,
  users: initialUsers,
  customers = [],
  loading = false,
}) => {
  const { userProfile } = useAuth();
  const [msg, setMsg] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  // Local overrides for optimistic user updates
  const [localUserOverrides, setLocalUserOverrides] = useState<Record<string, UserProfile>>({});

  // 1. Merge initial users with local updates
  const allMergedUsers = useMemo(() => {
    return initialUsers.map((u) => localUserOverrides[u.id] || u);
  }, [initialUsers, localUserOverrides]);

  // 2. Strict Staff Filter: guaranteed exclusion of all customer accounts
  // Applied AFTER all data sources and local overrides have been merged
  const staffUsers = useMemo(() => {
    return allMergedUsers.filter(isStaffUser);
  }, [allMergedUsers]);

  // Backward-compatible alias for staff users
  const users = staffUsers;

  // Search & Filter state
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [roleFilter, setRoleFilter] = useState<string>('all');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [completionFilter, setCompletionFilter] = useState<string>('all');

  // Dedicated User Details Modal State (opened when tapping any Staff Card)
  const [selectedUserForDetails, setSelectedUserForDetails] = useState<UserProfile | null>(null);

  // Tracks origin context to smoothly return to User Details after editing/viewing without modal stacking
  const [returnToUserDetailsUserId, setReturnToUserDetailsUserId] = useState<string | null>(null);

  // Complete Profile / View Profile Modal State
  const [selectedUserForModal, setSelectedUserForModal] = useState<UserProfile | null>(null);
  const [modalInitialTab, setModalInitialTab] = useState<'profile' | 'edit' | 'documents' | 'card'>('profile');

  // Dedicated User Card Modal State
  const [selectedUserForCard, setSelectedUserForCard] = useState<UserProfile | null>(null);
  const [cardAutoDownload, setCardAutoDownload] = useState<boolean>(false);

  // Role Diagnostic Audit Modal state
  const [showAuditModal, setShowAuditModal] = useState<boolean>(false);
  const [auditReport, setAuditReport] = useState<RoleAuditReport | null>(null);

  const handleRunAudit = () => {
    const report = auditUserRoles(allMergedUsers, customers);
    setAuditReport(report);
    setShowAuditModal(true);
  };

  // New Account Modal states
  const [showCreateModal, setShowCreateModal] = useState<boolean>(false);
  const [name, setName] = useState<string>('');
  const [username, setUsername] = useState<string>('');
  const [email, setEmail] = useState<string>('');
  const [phone, setPhone] = useState<string>('');
  const [defaultPassword, setDefaultPassword] = useState<string>(DEFAULT_NEW_USER_PASSWORD);
  const [showPassword, setShowPassword] = useState<boolean>(false);
  const [role, setRole] = useState<'invoice_manager' | 'payment_collector'>('invoice_manager');
  const [status, setStatus] = useState<'active' | 'inactive'>('active');
  const [photoURL, setPhotoURL] = useState<string>('');
  const [submittingUser, setSubmittingUser] = useState<boolean>(false);
  const [createError, setCreateError] = useState<string | null>(null);

  // Filtered staff users calculation (strictly staff only)
  const filteredUsers = useMemo(() => {
    return staffUsers.filter((u) => {
      const officialId = getOfficialUserId(u).toLowerCase();
      const nameMatch = u.name?.toLowerCase().includes(searchQuery.toLowerCase()) || false;
      const idMatch = officialId.includes(searchQuery.toLowerCase()) || u.id.toLowerCase().includes(searchQuery.toLowerCase());
      const usernameMatch = u.username?.toLowerCase().includes(searchQuery.toLowerCase()) || false;
      const emailMatch = u.email?.toLowerCase().includes(searchQuery.toLowerCase()) || false;
      const phoneMatch = u.phone?.toLowerCase().includes(searchQuery.toLowerCase()) || false;
      const jobMatch = u.jobTitle?.toLowerCase().includes(searchQuery.toLowerCase()) || false;
      const deptMatch = u.department?.toLowerCase().includes(searchQuery.toLowerCase()) || false;

      const matchesSearch =
        !searchQuery.trim() ||
        nameMatch ||
        idMatch ||
        usernameMatch ||
        emailMatch ||
        phoneMatch ||
        jobMatch ||
        deptMatch;

      const matchesRole = roleFilter === 'all' || u.role === roleFilter;

      const isSuspended = u.status === 'suspended';
      const isInactive = (u.status === 'inactive' || u.isDeactivated) && !isSuspended;
      const isActive = !isSuspended && !isInactive;

      const matchesStatus =
        statusFilter === 'all' ||
        (statusFilter === 'active' && isActive) ||
        (statusFilter === 'inactive' && isInactive) ||
        (statusFilter === 'suspended' && isSuspended);

      const complete = isProfileComplete(u);
      const matchesCompletion =
        completionFilter === 'all' ||
        (completionFilter === 'complete' && complete) ||
        (completionFilter === 'incomplete' && !complete);

      return matchesSearch && matchesRole && matchesStatus && matchesCompletion;
    });
  }, [staffUsers, searchQuery, roleFilter, statusFilter, completionFilter]);

  // Metric counts (strictly staff only)
  const totalStaffCount = staffUsers.length;
  const completeCount = useMemo(() => staffUsers.filter(isProfileComplete).length, [staffUsers]);
  const incompleteCount = totalStaffCount - completeCount;
  const activeCount = useMemo(() => staffUsers.filter((u) => u.status === 'active' && !u.isDeactivated).length, [staffUsers]);

  const handleNameChange = (val: string) => {
    setName(val);
    if (!username || username === name.toLowerCase().replace(/[^a-z0-9]/g, '')) {
      setUsername(val.toLowerCase().replace(/[^a-z0-9]/g, ''));
    }
  };

  const handleCreateAccount = async (e: React.FormEvent) => {
    e.preventDefault();
    setCreateError(null);

    if (!name.trim()) {
      setCreateError('Please enter the full name.');
      return;
    }
    const cleanUser = username.trim().toLowerCase().replace(/\s+/g, '_');
    if (!cleanUser || cleanUser.length < 3) {
      setCreateError('Username must be at least 3 characters.');
      return;
    }
    if (!email.trim() || !email.includes('@')) {
      setCreateError('Please enter a valid email address.');
      return;
    }
    if (!defaultPassword || defaultPassword.length < 6) {
      setCreateError('Default password must be at least 6 characters.');
      return;
    }

    setSubmittingUser(true);
    try {
      const created = await createApplicationUser({
        name: name.trim(),
        username: cleanUser,
        email: email.trim().toLowerCase(),
        phone: phone.trim(),
        defaultPassword,
        role,
        status,
        photoURL: photoURL.trim() || '',
        creatorId: userProfile?.id || 'super_admin',
        creatorName: userProfile?.name || 'Super Admin',
      });

      // Update local override
      setLocalUserOverrides((prev) => ({ ...prev, [created.id]: created }));

      const assignedId = getOfficialUserId(created);
      setMsg({
        type: 'success',
        text: `Account created successfully for "${name.trim()}" (@${cleanUser}) with permanent ID ${assignedId}. Mandatory password change required.`,
      });
      setShowCreateModal(false);
      // Reset form
      setName('');
      setUsername('');
      setEmail('');
      setPhone('');
      setDefaultPassword(DEFAULT_NEW_USER_PASSWORD);
      setRole('invoice_manager');
      setStatus('active');
      setPhotoURL('');
      setTimeout(() => setMsg(null), 5000);
    } catch (err: any) {
      console.error('Error creating user account:', err);
      setCreateError(err?.message || 'Failed to create user account.');
    } finally {
      setSubmittingUser(false);
    }
  };

  const handleRoleChange = async (userId: string, newRole: UserRole) => {
    if (newRole === 'super_admin' || newRole === 'customer') {
      setMsg({
        type: 'error',
        text: 'Privileged super_admin and customer portal roles cannot be assigned through staff management.',
      });
      return;
    }
    try {
      await updateUserRoleAndPermissions(
        userId,
        newRole,
        undefined,
        userProfile?.id || 'super_admin',
        userProfile?.name || 'Super Admin'
      );
      setLocalUserOverrides((prev) => {
        const existing = prev[userId] || staffUsers.find((u) => u.id === userId);
        if (!existing) return prev;
        const updated = { ...existing, role: newRole };
        if (selectedUserForDetails?.id === userId) {
          setSelectedUserForDetails(updated);
        }
        if (selectedUserForCard?.id === userId) {
          setSelectedUserForCard(updated);
        }
        return { ...prev, [userId]: updated };
      });
      setMsg({ type: 'success', text: `Updated role to "${newRole.replace('_', ' ')}".` });
      setTimeout(() => setMsg(null), 3000);
    } catch (err: any) {
      console.error(err);
      setMsg({ type: 'error', text: err?.message || 'Failed to update user role.' });
    }
  };

  const handleUserUpdated = (updatedUser: UserProfile) => {
    setLocalUserOverrides((prev) => ({ ...prev, [updatedUser.id]: updatedUser }));
    setSelectedUserForModal(updatedUser);
    if (selectedUserForDetails?.id === updatedUser.id) {
      setSelectedUserForDetails(updatedUser);
    }
    if (selectedUserForCard?.id === updatedUser.id) {
      setSelectedUserForCard(updatedUser);
    }
  };

  // Clean modal transition handlers: strictly prevent modal stacking by unmounting previous view before opening target interface
  const handleOpenViewProfileFromDetails = (u: UserProfile) => {
    setReturnToUserDetailsUserId(u.id);
    setSelectedUserForDetails(null);
    setSelectedUserForModal(u);
    setModalInitialTab('profile');
  };

  const handleOpenEditProfileFromDetails = (u: UserProfile) => {
    setReturnToUserDetailsUserId(u.id);
    setSelectedUserForDetails(null);
    setSelectedUserForModal(u);
    setModalInitialTab('edit');
  };

  const handleOpenCompleteProfileFromDetails = (u: UserProfile) => {
    setReturnToUserDetailsUserId(u.id);
    setSelectedUserForDetails(null);
    setSelectedUserForModal(u);
    setModalInitialTab('edit');
  };

  const handleOpenUserCardFromDetails = (u: UserProfile, autoDownload = false) => {
    setReturnToUserDetailsUserId(u.id);
    setSelectedUserForDetails(null);
    setSelectedUserForCard(u);
    setCardAutoDownload(autoDownload);
  };

  const handleOpenDocumentsFromDetails = (u: UserProfile) => {
    setReturnToUserDetailsUserId(u.id);
    setSelectedUserForDetails(null);
    setSelectedUserForModal(u);
    setModalInitialTab('documents');
  };

  const handleCloseProfileModal = () => {
    const returnUserId = returnToUserDetailsUserId;
    setSelectedUserForModal(null);
    setReturnToUserDetailsUserId(null);
    if (returnUserId) {
      // Find latest user from overrides or base list to display refreshed data in User Details
      const latestUser = localUserOverrides[returnUserId] || users.find((u) => u.id === returnUserId);
      if (latestUser) {
        setSelectedUserForDetails(latestUser);
      }
    }
  };

  const handleCloseUserCardModal = () => {
    const returnUserId = returnToUserDetailsUserId;
    setSelectedUserForCard(null);
    setReturnToUserDetailsUserId(null);
    if (returnUserId) {
      const latestUser = localUserOverrides[returnUserId] || users.find((u) => u.id === returnUserId);
      if (latestUser) {
        setSelectedUserForDetails(latestUser);
      }
    }
  };

  const roleDescriptions: Record<UserRole, string> = {
    super_admin:
      'Complete, unrestricted authority. System settings, audit trail, user credentials, financials, and overrides.',
    invoice_manager:
      'Operational authority. Create and edit invoices, register customers, record expenses, view reports, manage services.',
    payment_collector:
      'Cash collection authority. Record payments, export payment receipts, and record operating expenses.',
    customer:
      'Customer portal access. View own invoices, outstanding balance, service requests, and showcase portfolio.',
  };

  return (
    <div className="space-y-6">
      {/* View Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-5 rounded-2xl border border-neutral-200 shadow-xs">
        <div className="flex items-center gap-3">
          <div className="p-2.5 bg-orange-100 rounded-xl text-orange-600">
            <Users className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-base font-bold text-neutral-900 tracking-tight">
                Staff &amp; User Profile Management
              </h2>
              <span className="px-2 py-0.5 bg-orange-50 border border-orange-200 text-orange-700 text-[11px] font-bold rounded-md font-mono">
                ST-U-XXXX Standard
              </span>
            </div>
            <p className="text-xs text-neutral-500 mt-0.5">
              Central employee profiles, immutable IDs, PDF documentation, and role-based permissions.
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          {userProfile?.role === 'super_admin' && (
            <button
              id="btn-audit-roles"
              type="button"
              onClick={handleRunAudit}
              className="inline-flex items-center justify-center gap-1.5 px-3.5 py-2.5 bg-neutral-100 hover:bg-neutral-200 text-neutral-800 border border-neutral-300 text-xs font-bold rounded-xl shadow-2xs transition cursor-pointer"
              title="Audit user database for role inconsistencies and security issues"
            >
              <ShieldCheck className="w-4 h-4 text-orange-600" />
              <span>Audit Roles</span>
            </button>
          )}

          <button
            type="button"
            onClick={() => {
              setShowCreateModal(true);
              setCreateError(null);
            }}
            className="inline-flex items-center justify-center gap-2 px-4 py-2.5 bg-[#F58220] hover:bg-[#d46d15] text-white text-xs font-bold rounded-xl shadow-xs transition cursor-pointer active:scale-98"
          >
            <UserPlus className="w-4 h-4" />
            <span>Create New User</span>
          </button>
        </div>
      </div>

      {/* Notifications banner */}
      {msg && (
        <div
          className={`p-3.5 rounded-xl text-xs font-semibold flex items-center gap-2 border ${
            msg.type === 'success'
              ? 'bg-emerald-50 text-emerald-800 border-emerald-200'
              : 'bg-red-50 text-red-800 border-red-200'
          }`}
        >
          {msg.type === 'success' ? (
            <ShieldCheck className="w-4 h-4 text-emerald-600" />
          ) : (
            <AlertCircle className="w-4 h-4 text-red-600" />
          )}
          <span>{msg.text}</span>
        </div>
      )}

      {/* Metrics Summary Strip */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <div className="bg-white p-3.5 rounded-xl border border-neutral-200 shadow-xs">
          <span className="text-[10px] text-neutral-400 uppercase font-semibold block">Total Staff Members</span>
          <p className="text-lg font-black text-neutral-900 mt-0.5">{totalStaffCount}</p>
        </div>

        <div className="bg-white p-3.5 rounded-xl border border-neutral-200 shadow-xs">
          <span className="text-[10px] text-blue-600 uppercase font-semibold block flex items-center gap-1">
            <CheckCircle2 className="w-3 h-3 text-blue-600" /> Complete Profiles
          </span>
          <p className="text-lg font-black text-blue-900 mt-0.5">{completeCount}</p>
        </div>

        <div className="bg-white p-3.5 rounded-xl border border-neutral-200 shadow-xs">
          <span className="text-[10px] text-red-600 uppercase font-semibold block flex items-center gap-1">
            <XCircle className="w-3 h-3 text-red-600" /> Incomplete Profiles
          </span>
          <p className="text-lg font-black text-red-900 mt-0.5">{incompleteCount}</p>
        </div>

        <div className="bg-white p-3.5 rounded-xl border border-neutral-200 shadow-xs">
          <span className="text-[10px] text-emerald-600 uppercase font-semibold block flex items-center gap-1">
            <UserCheck className="w-3 h-3 text-emerald-600" /> Active Accounts
          </span>
          <p className="text-lg font-black text-emerald-900 mt-0.5">{activeCount}</p>
        </div>
      </div>

      {/* Search & Filters Bar */}
      <div className="bg-white p-4 rounded-xl border border-neutral-200 shadow-xs flex flex-col md:flex-row items-stretch md:items-center gap-3">
        {/* Search Input */}
        <div className="relative flex-1">
          <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-neutral-400">
            <Search className="w-4 h-4" />
          </div>
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search by name, User ID (ST-U-XXXX), username, phone, or position..."
            className="w-full pl-9 pr-3 py-2 text-xs bg-neutral-50 border border-neutral-300 rounded-xl focus:outline-none focus:bg-white focus:ring-1 focus:ring-orange-500"
          />
          {searchQuery && (
            <button
              type="button"
              onClick={() => setSearchQuery('')}
              className="absolute inset-y-0 right-0 pr-3 flex items-center text-neutral-400 hover:text-neutral-600"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          )}
        </div>

        {/* Dropdown Filters */}
        <div className="flex items-center gap-2 flex-wrap">
          {/* Role Filter */}
          <select
            value={roleFilter}
            onChange={(e) => setRoleFilter(e.target.value)}
            className="px-3 py-2 text-xs bg-neutral-50 border border-neutral-300 rounded-xl focus:outline-none focus:bg-white focus:ring-1 focus:ring-orange-500 cursor-pointer font-medium text-neutral-700"
          >
            <option value="all">All Roles</option>
            <option value="super_admin">Super Admin</option>
            <option value="invoice_manager">Invoice Manager</option>
            <option value="payment_collector">Payment Collector</option>
          </select>

          {/* Profile Completion Filter */}
          <select
            value={completionFilter}
            onChange={(e) => setCompletionFilter(e.target.value)}
            className="px-3 py-2 text-xs bg-neutral-50 border border-neutral-300 rounded-xl focus:outline-none focus:bg-white focus:ring-1 focus:ring-orange-500 cursor-pointer font-medium text-neutral-700"
          >
            <option value="all">All Profile States</option>
            <option value="complete">Complete Profile (Blue ✓)</option>
            <option value="incomplete">Incomplete Profile (Red ✕)</option>
          </select>

          {/* Status Filter */}
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="px-3 py-2 text-xs bg-neutral-50 border border-neutral-300 rounded-xl focus:outline-none focus:bg-white focus:ring-1 focus:ring-orange-500 cursor-pointer font-medium text-neutral-700"
          >
            <option value="all">All Statuses</option>
            <option value="active">Active Only</option>
            <option value="inactive">Inactive Only</option>
            <option value="suspended">Suspended Only</option>
          </select>
        </div>
      </div>

      {/* Staff Users Directory: Modern Responsive Staff Card Layout */}
      <div className="space-y-3">
        <div className="flex items-center justify-between flex-wrap gap-2 px-1">
          <div className="flex items-center gap-2">
            <h3 className="text-xs font-bold text-neutral-800 uppercase tracking-wider">
              Staff &amp; User Directory ({filteredUsers.length} of {users.length})
            </h3>
            <span className="text-[11px] text-neutral-400 font-mono hidden sm:inline">
              • Immutable ST-U-XXXX Standard
            </span>
          </div>
          <span className="text-[11px] text-neutral-500">
            Click any staff card to view full details &amp; actions
          </span>
        </div>

        {loading ? (
          /* Loading Skeleton */
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
            {[1, 2, 3, 4, 5, 6, 7, 8].map((n) => (
              <div
                key={n}
                className="bg-white rounded-2xl border border-neutral-200 p-5 animate-pulse flex flex-col justify-between h-44 shadow-2xs"
              >
                <div className="flex items-start justify-between">
                  <div className="w-14 h-14 bg-neutral-200 rounded-2xl" />
                  <div className="w-16 h-5 bg-neutral-100 rounded-md" />
                </div>
                <div>
                  <div className="h-4 bg-neutral-200 rounded w-3/4 mb-2" />
                  <div className="h-3 bg-neutral-150 rounded w-1/2" />
                </div>
                <div className="pt-3 border-t border-neutral-100 flex items-center justify-between">
                  <div className="w-20 h-5 bg-neutral-200 rounded" />
                  <div className="w-8 h-5 bg-neutral-200 rounded" />
                </div>
              </div>
            ))}
          </div>
        ) : filteredUsers.length === 0 ? (
          users.length === 0 ? (
            /* Clean Empty State */
            <div className="bg-white rounded-2xl border border-neutral-200 p-12 text-center shadow-xs">
              <div className="w-14 h-14 mx-auto mb-3 bg-orange-50 text-[#F58220] rounded-2xl flex items-center justify-center border border-orange-100">
                <Users className="w-7 h-7" />
              </div>
              <h3 className="text-sm font-bold text-neutral-900 mb-1">
                No staff users found.
              </h3>
              <p className="text-xs text-neutral-500 max-w-sm mx-auto mb-5 leading-relaxed">
                There are currently no staff user profiles registered in the central directory. Get started by creating your first employee profile.
              </p>
              <button
                type="button"
                onClick={() => {
                  setShowCreateModal(true);
                  setCreateError(null);
                }}
                className="inline-flex items-center gap-2 px-4 py-2.5 bg-[#F58220] hover:bg-[#d46d15] text-white text-xs font-bold rounded-xl shadow-xs transition cursor-pointer"
              >
                <UserPlus className="w-4 h-4" />
                <span>Create New User</span>
              </button>
            </div>
          ) : (
            /* Search / Filter Empty State */
            <div className="bg-white rounded-2xl border border-neutral-200 p-10 text-center shadow-xs">
              <div className="w-12 h-12 mx-auto mb-3 bg-neutral-100 text-neutral-500 rounded-2xl flex items-center justify-center border border-neutral-200">
                <Search className="w-6 h-6" />
              </div>
              <h3 className="text-sm font-bold text-neutral-900 mb-1">
                No matching staff users found.
              </h3>
              <p className="text-xs text-neutral-500 max-w-sm mx-auto mb-4 leading-relaxed">
                No staff profiles match your search and filter criteria. Try adjusting your query or reset your filters.
              </p>
              <button
                type="button"
                onClick={() => {
                  setSearchQuery('');
                  setRoleFilter('all');
                  setStatusFilter('all');
                  setCompletionFilter('all');
                }}
                className="inline-flex items-center gap-1.5 px-3.5 py-1.5 bg-neutral-100 hover:bg-neutral-200 text-neutral-700 text-xs font-semibold rounded-xl border border-neutral-300 transition cursor-pointer"
              >
                <X className="w-3.5 h-3.5" />
                <span>Reset Filters</span>
              </button>
            </div>
          )
        ) : (
          /* RESPONSIVE STAFF CARDS GRID */
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
            {filteredUsers.map((u) => (
              <StaffCard
                key={u.id}
                user={u}
                onClick={() => setSelectedUserForDetails(u)}
              />
            ))}
          </div>
        )}
      </div>

      {/* Permissions Matrix Reference */}
      <div className="bg-white rounded-xl border border-neutral-200 shadow-xs p-5">
        <h3 className="text-sm font-bold text-neutral-900 mb-1">
          Role Permissions Matrix
        </h3>
        <p className="text-xs text-neutral-500 mb-4">
          Hierarchical privilege assignments designed for commercial security contracting and retail operations.
        </p>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
          {(
            [
              'super_admin',
              'invoice_manager',
              'payment_collector',
              'customer',
            ] as UserRole[]
          ).map((r) => (
            <div
              key={r}
              className="p-3.5 rounded-lg border border-neutral-200 bg-neutral-50/50 space-y-1.5"
            >
              <div className="flex items-center justify-between">
                <span className="font-bold text-neutral-900 capitalize">
                  {r.replace('_', ' ')}
                </span>
                <span className="text-[10px] font-mono font-semibold px-2 py-0.5 bg-white border border-neutral-300 rounded-md">
                  {r}
                </span>
              </div>
              <p className="text-neutral-600 text-[11px] leading-relaxed">
                {roleDescriptions[r]}
              </p>
            </div>
          ))}
        </div>
      </div>

      {/* ================= COMPREHENSIVE USER PROFILE MODAL ================= */}
      {selectedUserForModal && (
        <UserProfileModal
          user={selectedUserForModal}
          settings={settings}
          currentAdminId={userProfile?.id || 'super_admin'}
          currentAdminName={userProfile?.name || 'Super Admin'}
          initialTab={modalInitialTab}
          onClose={handleCloseProfileModal}
          onProfileUpdated={handleUserUpdated}
        />
      )}

      {/* ================= DEDICATED USER DETAILS MODAL (Opened on Staff Card click) ================= */}
      {selectedUserForDetails && (
        <UserDetailsModal
          user={selectedUserForDetails}
          settings={settings}
          currentUser={userProfile}
          onClose={() => {
            setSelectedUserForDetails(null);
            setReturnToUserDetailsUserId(null);
          }}
          onOpenViewProfile={handleOpenViewProfileFromDetails}
          onOpenEditProfile={handleOpenEditProfileFromDetails}
          onOpenCompleteProfile={handleOpenCompleteProfileFromDetails}
          onOpenUserCard={(u) => handleOpenUserCardFromDetails(u, false)}
          onDownloadUserCard={(u) => handleOpenUserCardFromDetails(u, true)}
          onOpenDocuments={handleOpenDocumentsFromDetails}
          onUserStatusChanged={(updated) => {
            handleUserUpdated(updated);
            setSelectedUserForDetails(updated);
          }}
          onRoleChange={handleRoleChange}
        />
      )}

      {/* ================= DEDICATED DIGITAL USER CARD MODAL ================= */}
      {selectedUserForCard && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto">
          <div className="w-full max-w-xl bg-white rounded-2xl shadow-2xl border border-neutral-200 p-5 relative">
            <div className="flex items-center justify-between border-b border-neutral-150 pb-3 mb-4">
              <div className="flex items-center gap-2">
                <CreditCard className="w-5 h-5 text-orange-600" />
                <h3 className="text-sm font-bold text-neutral-900">
                  Official Employee Identification Card
                </h3>
              </div>
              <button
                type="button"
                onClick={handleCloseUserCardModal}
                className="p-1 text-neutral-400 hover:text-neutral-600 rounded-lg hover:bg-neutral-100 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <UserCard user={selectedUserForCard} settings={settings} autoDownload={cardAutoDownload} />

            <div className="mt-4 pt-3 border-t border-neutral-150 flex justify-end">
              <button
                type="button"
                onClick={handleCloseUserCardModal}
                className="px-4 py-2 border border-neutral-300 rounded-xl text-xs font-semibold text-neutral-700 hover:bg-neutral-100 transition cursor-pointer"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ================= SUPER ADMIN ACCOUNT CREATION MODAL ================= */}
      {showCreateModal && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="w-full max-w-lg bg-white rounded-2xl shadow-2xl border border-neutral-200 p-6 relative max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between border-b border-neutral-100 pb-3 mb-4">
              <div className="flex items-center gap-2">
                <div className="p-2 bg-orange-100 text-[#F58220] rounded-xl">
                  <UserPlus className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base font-bold text-neutral-900">
                    Create User Account
                  </h3>
                  <p className="text-[11px] text-neutral-500">
                    Allocates permanent ST-U-XXXX User ID. Profile can be completed later.
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setShowCreateModal(false)}
                className="p-1 text-neutral-400 hover:text-neutral-600 rounded-lg hover:bg-neutral-100 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {createError && (
              <div className="mb-4 p-3 bg-red-50 border border-red-200 text-red-700 text-xs rounded-xl flex items-start gap-2">
                <AlertCircle className="w-4 h-4 shrink-0 text-red-500 mt-0.5" />
                <p className="flex-1">{createError}</p>
              </div>
            )}

            <form onSubmit={handleCreateAccount} className="space-y-3.5">
              {/* Full Name */}
              <div>
                <label className="block text-xs font-semibold text-neutral-700 mb-1">
                  Full Name <span className="text-red-500">*</span>
                </label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-neutral-400">
                    <User className="w-4 h-4" />
                  </div>
                  <input
                    type="text"
                    required
                    value={name}
                    onChange={(e) => handleNameChange(e.target.value)}
                    placeholder="e.g. Ahmad Karimi"
                    className="w-full pl-9 pr-3 py-2 text-xs bg-neutral-50 border border-neutral-300 rounded-xl focus:outline-none focus:bg-white focus:ring-1 focus:ring-[#F58220]"
                  />
                </div>
              </div>

              {/* Username */}
              <div>
                <label className="block text-xs font-semibold text-neutral-700 mb-1">
                  Username (Unique Login ID) <span className="text-red-500">*</span>
                </label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-neutral-400">
                    <AtSign className="w-4 h-4" />
                  </div>
                  <input
                    type="text"
                    required
                    value={username}
                    onChange={(e) => setUsername(e.target.value.toLowerCase().replace(/\s+/g, '_'))}
                    placeholder="e.g. akarimi"
                    className="w-full pl-9 pr-3 py-2 text-xs bg-neutral-50 border border-neutral-300 rounded-xl focus:outline-none focus:bg-white focus:ring-1 focus:ring-[#F58220]"
                  />
                </div>
              </div>

              {/* Email */}
              <div>
                <label className="block text-xs font-semibold text-neutral-700 mb-1">
                  Registered Email Address <span className="text-red-500">*</span>
                </label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-neutral-400">
                    <Mail className="w-4 h-4" />
                  </div>
                  <input
                    type="email"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="e.g. ahmad@example.com"
                    className="w-full pl-9 pr-3 py-2 text-xs bg-neutral-50 border border-neutral-300 rounded-xl focus:outline-none focus:bg-white focus:ring-1 focus:ring-[#F58220]"
                  />
                </div>
              </div>

              {/* Phone */}
              <div>
                <label className="block text-xs font-semibold text-neutral-700 mb-1">
                  Phone Number
                </label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-neutral-400">
                    <Phone className="w-4 h-4" />
                  </div>
                  <input
                    type="tel"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    placeholder="e.g. 07XXXXXXXX"
                    className="w-full pl-9 pr-3 py-2 text-xs bg-neutral-50 border border-neutral-300 rounded-xl focus:outline-none focus:bg-white focus:ring-1 focus:ring-[#F58220]"
                  />
                </div>
              </div>

              {/* Default Password */}
              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="block text-xs font-semibold text-neutral-700">
                    Default Initial Password
                  </label>
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="text-[11px] text-neutral-500 hover:text-neutral-700 flex items-center gap-1 cursor-pointer"
                  >
                    {showPassword ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                    <span>{showPassword ? 'Hide' : 'Show'}</span>
                  </button>
                </div>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-neutral-400">
                    <Lock className="w-4 h-4" />
                  </div>
                  <input
                    type={showPassword ? 'text' : 'password'}
                    required
                    value={defaultPassword}
                    onChange={(e) => setDefaultPassword(e.target.value)}
                    placeholder="Enter default initial password"
                    className="w-full pl-9 pr-3 py-2 text-xs bg-neutral-50 border border-neutral-300 rounded-xl focus:outline-none focus:bg-white focus:ring-1 focus:ring-[#F58220]"
                  />
                </div>
                <div className="mt-1 flex items-center gap-1.5 text-[11px] text-amber-700 bg-amber-50 p-2 rounded-lg border border-amber-200">
                  <KeyRound className="w-3.5 h-3.5 shrink-0" />
                  <span>
                    Mandatory security: The user will be required to change this default password upon their first login.
                  </span>
                </div>
              </div>

              {/* Role selection */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-neutral-700 mb-1">
                    Application Role
                  </label>
                  <select
                    value={role}
                    onChange={(e) =>
                      setRole(
                        e.target.value as 'invoice_manager' | 'payment_collector'
                      )
                    }
                    className="w-full px-3 py-2 text-xs bg-neutral-50 border border-neutral-300 rounded-xl focus:outline-none focus:bg-white focus:ring-1 focus:ring-[#F58220] cursor-pointer"
                  >
                    <option value="invoice_manager">Invoice Manager</option>
                    <option value="payment_collector">Payment Collector</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-neutral-700 mb-1">
                    Account Status
                  </label>
                  <select
                    value={status}
                    onChange={(e) => setStatus(e.target.value as 'active' | 'inactive')}
                    className="w-full px-3 py-2 text-xs bg-neutral-50 border border-neutral-300 rounded-xl focus:outline-none focus:bg-white focus:ring-1 focus:ring-[#F58220] cursor-pointer"
                  >
                    <option value="active">Active (Access Allowed)</option>
                    <option value="inactive">Inactive (Access Blocked)</option>
                  </select>
                </div>
              </div>

              {/* Profile Photo Upload Control */}
              <div className="bg-neutral-50 p-3.5 rounded-xl border border-neutral-200">
                <label className="block text-xs font-semibold text-neutral-700 mb-2">
                  Staff Profile Photo (Optional)
                </label>
                <ProfilePhotoUpload
                  value={photoURL}
                  onChange={(newUrl) => setPhotoURL(newUrl || '')}
                  name={name || 'Staff Member'}
                  disabled={submittingUser}
                />
              </div>

              {/* Action Buttons */}
              <div className="pt-3 flex items-center justify-end gap-2 border-t border-neutral-100">
                <button
                  type="button"
                  onClick={() => setShowCreateModal(false)}
                  className="px-4 py-2 text-xs font-semibold text-neutral-600 hover:bg-neutral-100 rounded-xl transition cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={submittingUser}
                  className="px-5 py-2 bg-[#F58220] hover:bg-[#d46d15] text-white text-xs font-bold rounded-xl transition shadow flex items-center gap-1.5 cursor-pointer disabled:opacity-50"
                >
                  {submittingUser ? (
                    <>
                      <Loader2 className="w-3.5 h-3.5 animate-spin" />
                      <span>Creating User...</span>
                    </>
                  ) : (
                    <span>Create User</span>
                  )}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Role Diagnostic Audit Modal */}
      {showAuditModal && auditReport && (
        <div
          id="role-audit-modal"
          className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/60 backdrop-blur-xs overflow-y-auto"
        >
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-2xl max-h-[90vh] flex flex-col overflow-hidden border border-neutral-200 my-auto">
            {/* Modal Header */}
            <div className="flex items-center justify-between px-5 py-4 border-b border-neutral-200 bg-neutral-900 text-white">
              <div className="flex items-center gap-2.5">
                <ShieldCheck className="w-5 h-5 text-orange-400" />
                <div>
                  <h3 className="text-sm font-bold">User Role &amp; Permission Diagnostic Audit</h3>
                  <p className="text-[11px] text-neutral-400">
                    Safe, non-destructive audit scanning for role inconsistencies and permission risks
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setShowAuditModal(false)}
                className="p-1 rounded-lg text-neutral-400 hover:text-white hover:bg-neutral-800 transition"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Modal Body */}
            <div className="p-5 overflow-y-auto space-y-4 text-xs">
              {/* Summary Stats */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
                <div className="p-3 bg-neutral-50 rounded-xl border border-neutral-200 text-center">
                  <span className="text-[10px] text-neutral-500 font-semibold block">Total Users</span>
                  <span className="text-base font-black text-neutral-900">{auditReport.totalUsersScanned}</span>
                </div>
                <div className="p-3 bg-blue-50 rounded-xl border border-blue-200 text-center">
                  <span className="text-[10px] text-blue-700 font-semibold block">Staff Members</span>
                  <span className="text-base font-black text-blue-900">{auditReport.totalStaffUsers}</span>
                </div>
                <div className="p-3 bg-purple-50 rounded-xl border border-purple-200 text-center">
                  <span className="text-[10px] text-purple-700 font-semibold block">Customers</span>
                  <span className="text-base font-black text-purple-900">{auditReport.totalCustomerUsers}</span>
                </div>
                <div className={`p-3 rounded-xl border text-center ${auditReport.totalIssuesFound === 0 ? 'bg-emerald-50 border-emerald-200' : 'bg-amber-50 border-amber-200'}`}>
                  <span className="text-[10px] font-semibold block text-neutral-600">Issues Found</span>
                  <span className={`text-base font-black ${auditReport.totalIssuesFound === 0 ? 'text-emerald-700' : 'text-amber-800'}`}>
                    {auditReport.totalIssuesFound}
                  </span>
                </div>
              </div>

              {/* Status Banner */}
              {auditReport.totalIssuesFound === 0 ? (
                <div className="p-4 bg-emerald-50 border border-emerald-200 rounded-xl flex items-center gap-3">
                  <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
                  <div>
                    <h4 className="font-bold text-emerald-900 text-xs">All Roles Healthy &amp; Consistent</h4>
                    <p className="text-[11px] text-emerald-700 mt-0.5">
                      No customer leaks into staff records, orphan links, or privilege escalation detected.
                    </p>
                  </div>
                </div>
              ) : (
                <div className="space-y-2">
                  <div className="flex items-center justify-between text-neutral-700 font-bold text-xs">
                    <span>Detected Inconsistencies ({auditReport.issues.length})</span>
                    <span className="text-[11px] text-neutral-400 font-normal">Safe diagnostic mode (zero data modified)</span>
                  </div>

                  <div className="space-y-2 max-h-80 overflow-y-auto pr-1">
                    {auditReport.issues.map((issue, idx) => (
                      <div
                        key={idx}
                        className={`p-3 rounded-xl border text-xs space-y-1 ${
                          issue.severity === 'CRITICAL'
                            ? 'bg-rose-50/70 border-rose-200 text-rose-900'
                            : 'bg-amber-50/70 border-amber-200 text-amber-900'
                        }`}
                      >
                        <div className="flex items-center justify-between gap-2">
                          <span className="font-bold text-neutral-900">
                            {issue.userName} ({issue.userId})
                          </span>
                          <span
                            className={`px-2 py-0.5 text-[9px] font-bold rounded-full uppercase ${
                              issue.severity === 'CRITICAL'
                                ? 'bg-rose-200 text-rose-900'
                                : 'bg-amber-200 text-amber-900'
                            }`}
                          >
                            {issue.severity}: {issue.issueType.replace(/_/g, ' ')}
                          </span>
                        </div>
                        <p className="text-[11px] text-neutral-700">{issue.description}</p>
                        <p className="text-[11px] font-medium text-neutral-500 pt-1 border-t border-neutral-200/50">
                          <strong>Recommended action:</strong> {issue.recommendedAction}
                        </p>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>

            {/* Modal Footer */}
            <div className="px-5 py-3 border-t border-neutral-100 bg-neutral-50 flex items-center justify-between">
              <span className="text-[11px] text-neutral-400 font-mono">
                Scan timestamp: {new Date(auditReport.timestamp).toLocaleTimeString()}
              </span>
              <button
                type="button"
                onClick={() => setShowAuditModal(false)}
                className="px-4 py-1.5 text-xs font-semibold bg-neutral-900 hover:bg-neutral-800 text-white rounded-lg transition"
              >
                Close Report
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
