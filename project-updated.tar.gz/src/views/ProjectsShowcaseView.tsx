import React, { useState } from 'react';
import { Project } from '../types';
import { saveProject, deleteProject } from '../services/db';
import { useAuth } from '../context/AuthContext';
import {
  ShieldCheck,
  Video,
  Plus,
  Trash2,
  Edit2,
  ExternalLink,
  Eye,
  Camera,
  Layers,
  Sparkles,
  CheckCircle,
  X,
} from 'lucide-react';

interface ProjectsShowcaseViewProps {
  projects: Project[];
  onRequestSystem?: (project: Project) => void;
}

export const INITIAL_SHOWCASE_PROJECTS: Omit<Project, 'id' | 'createdAt'>[] = [
  {
    title: 'Dahua 4K Ultra-HD Smart CCTV System Installation',
    category: 'CCTV Surveillance',
    description: 'Complete commercial enterprise surveillance installation featuring 16x Dahua WizSense 4K IP cameras with AI perimeter protection, night color view, and 32-channel NVR with 16TB storage.',
    images: ['https://images.unsplash.com/photo-1557597774-9d273605dfa9?w=800&q=80'],
    isPublished: true,
    isFeatured: true,
    date: '2025-01-15',
  },
  {
    title: 'Solar-Powered 4G Autonomous Security Tower',
    category: 'Solar Camera Systems',
    description: 'Off-grid solar security solution deployed with dual-lens Dahua 4G PTZ cameras, continuous 24/7 battery backup, and remote real-time smartphone viewing for remote sites.',
    images: ['https://images.unsplash.com/photo-1508873696983-2df5703bc20d?w=800&q=80'],
    isPublished: true,
    isFeatured: true,
    date: '2025-02-10',
  },
  {
    title: 'Dahua TiOC 3-in-1 Active Deterrence Camera Network',
    category: 'IP & PTZ Cameras',
    description: 'Active deterrence surveillance system with red & blue flashing strobe lights, built-in siren, two-way audio talk, and smart motion detection to preemptively prevent security breaches.',
    images: ['https://images.unsplash.com/photo-1581092160607-ee22621dd758?w=800&q=80'],
    isPublished: true,
    isFeatured: false,
    date: '2025-02-28',
  },
  {
    title: 'Biometric Access Control & Video Intercom Villa System',
    category: 'Access Control & Intercom',
    description: 'Integrated IP video door phone system with Dahua facial recognition access terminal, electronic magnetic lock integration, and remote gate release via mobile application.',
    images: ['https://images.unsplash.com/photo-1558002038-1055907df827?w=800&q=80'],
    isPublished: true,
    isFeatured: false,
    date: '2025-03-01',
  },
];

export const ProjectsShowcaseView: React.FC<ProjectsShowcaseViewProps> = ({
  projects,
  onRequestSystem,
}) => {
  const { permissions, portalMode } = useAuth();
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [modalOpen, setModalOpen] = useState<boolean>(false);
  const [projectToEdit, setProjectToEdit] = useState<Project | null>(null);

  const [formTitle, setFormTitle] = useState<string>('');
  const [formCategory, setFormCategory] = useState<string>('CCTV Surveillance');
  const [formDescription, setFormDescription] = useState<string>('');
  const [formImageUrl, setFormImageUrl] = useState<string>('');
  const [formFeatured, setFormFeatured] = useState<boolean>(false);
  const [saving, setSaving] = useState<boolean>(false);

  // Combine database projects or seed if empty
  const displayProjects = projects.length > 0 ? projects : (INITIAL_SHOWCASE_PROJECTS as Project[]);

  const categories = [
    'all',
    'CCTV Surveillance',
    'Solar Camera Systems',
    'IP & PTZ Cameras',
    'Access Control & Intercom',
    'Commercial Projects',
  ];

  const filteredProjects = displayProjects.filter((p) => {
    if (selectedCategory !== 'all' && p.category !== selectedCategory) return false;
    return true;
  });

  const handleOpenAddModal = (proj?: Project) => {
    if (proj) {
      setProjectToEdit(proj);
      setFormTitle(proj.title);
      setFormCategory(proj.category);
      setFormDescription(proj.description);
      setFormImageUrl(proj.images?.[0] || '');
      setFormFeatured(Boolean(proj.isFeatured));
    } else {
      setProjectToEdit(null);
      setFormTitle('');
      setFormCategory('CCTV Surveillance');
      setFormDescription('');
      setFormImageUrl('https://images.unsplash.com/photo-1557597774-9d273605dfa9?w=800&q=80');
      setFormFeatured(false);
    }
    setModalOpen(true);
  };

  const handleSaveProject = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formTitle.trim()) return;

    setSaving(true);
    try {
      await saveProject({
        id: projectToEdit?.id,
        title: formTitle.trim(),
        category: formCategory,
        description: formDescription.trim(),
        images: formImageUrl.trim() ? [formImageUrl.trim()] : [],
        isPublished: true,
        isFeatured: formFeatured,
        date: new Date().toISOString().split('T')[0],
      });
      setModalOpen(false);
    } catch (err) {
      console.error('Failed to save project:', err);
      alert('Error saving project showcase item.');
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async (id: string) => {
    if (confirm('Are you sure you want to remove this project from the showcase?')) {
      await deleteProject(id);
    }
  };

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="bg-gradient-to-r from-neutral-950 via-neutral-900 to-neutral-950 text-white rounded-2xl p-6 sm:p-8 border border-neutral-800 shadow-md relative overflow-hidden">
        <div className="relative z-10 max-w-2xl">
          <div className="inline-flex items-center gap-2 px-3 py-1 bg-orange-500/20 text-orange-400 border border-orange-500/30 rounded-full text-xs font-semibold mb-3">
            <Sparkles className="w-3.5 h-3.5" />
            <span>Official Dahua &amp; Sarwan Security Portfolio</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
            CCTV &amp; Surveillance Showcase
          </h1>
          <p className="text-xs sm:text-sm text-neutral-300 mt-2 leading-relaxed">
            Explore state-of-the-art security installations, smart AI IP camera networks, active deterrence systems, and commercial surveillance projects engineered by Sarwan Technology.
          </p>

          <div className="mt-5 flex flex-wrap items-center gap-3">
            <div className="flex items-center gap-2 bg-white/10 backdrop-blur-xs px-3 py-1.5 rounded-lg text-xs">
              <ShieldCheck className="w-4 h-4 text-orange-400" />
              <span>Dahua Authorized Partner</span>
            </div>
            <div className="flex items-center gap-2 bg-white/10 backdrop-blur-xs px-3 py-1.5 rounded-lg text-xs">
              <CheckCircle className="w-4 h-4 text-emerald-400" />
              <span>100% Genuine Equipment &amp; Warranty</span>
            </div>
          </div>
        </div>

        {/* Decorative background logo / shape */}
        <div className="absolute right-4 -bottom-10 opacity-10 pointer-events-none hidden md:block">
          <Camera className="w-72 h-72 text-white" />
        </div>
      </div>

      {/* Filter and Controls Header */}
      <div className="bg-white rounded-xl p-4 border border-neutral-200 shadow-xs flex flex-wrap items-center justify-between gap-4">
        {/* Category Pills */}
        <div className="flex flex-wrap items-center gap-2">
          {categories.map((cat) => {
            const isActive = selectedCategory === cat;
            return (
              <button
                key={cat}
                onClick={() => setSelectedCategory(cat)}
                className={`text-xs font-semibold px-3 py-1.5 rounded-lg transition capitalize cursor-pointer ${
                  isActive
                    ? 'bg-neutral-900 text-white'
                    : 'bg-neutral-100 text-neutral-600 hover:bg-neutral-200'
                }`}
              >
                {cat === 'all' ? 'All Solutions' : cat}
              </button>
            );
          })}
        </div>

        {/* Add Project Button (Staff only) */}
        {permissions.canManageProjects && (
          <button
            onClick={() => handleOpenAddModal()}
            className="px-3.5 py-2 bg-[#F58220] hover:bg-[#e0751a] text-white text-xs font-bold rounded-lg shadow-xs transition flex items-center gap-1.5 cursor-pointer active:scale-98 ml-auto"
          >
            <Plus className="w-4 h-4" />
            <span>Add Showcase Project</span>
          </button>
        )}
      </div>

      {/* Projects Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredProjects.map((project, idx) => {
          return (
            <div
              key={project.id || `showcase-${idx}`}
              className="bg-white rounded-xl border border-neutral-200 shadow-xs overflow-hidden flex flex-col hover:shadow-md transition duration-200 group"
            >
              {/* Image Container */}
              <div className="relative aspect-video bg-neutral-900 overflow-hidden">
                <img
                  src={
                    project.images?.[0] ||
                    'https://images.unsplash.com/photo-1557597774-9d273605dfa9?w=800&q=80'
                  }
                  alt={project.title}
                  className="w-full h-full object-cover group-hover:scale-105 transition duration-300"
                  onError={(e) => {
                    e.currentTarget.src =
                      'https://images.unsplash.com/photo-1557597774-9d273605dfa9?w=800&q=80';
                  }}
                />

                {/* Category Badge */}
                <div className="absolute top-3 left-3 bg-neutral-950/80 backdrop-blur-xs text-white text-[10px] font-bold px-2.5 py-1 rounded-md border border-neutral-700">
                  {project.category}
                </div>

                {project.isFeatured && (
                  <div className="absolute top-3 right-3 bg-orange-600 text-white text-[10px] font-bold px-2 py-0.5 rounded-full shadow-xs">
                    Featured
                  </div>
                )}
              </div>

              {/* Card Content */}
              <div className="p-5 flex-1 flex flex-col justify-between">
                <div>
                  <h3 className="text-sm font-bold text-neutral-900 group-hover:text-orange-600 transition line-clamp-2">
                    {project.title}
                  </h3>
                  <p className="text-xs text-neutral-600 mt-2 line-clamp-3 leading-relaxed">
                    {project.description}
                  </p>
                </div>

                {/* Actions Footer */}
                <div className="mt-5 pt-4 border-t border-neutral-100 flex items-center justify-between gap-2">
                  <span className="text-[11px] text-neutral-400 font-medium">
                    {project.date}
                  </span>

                  <div className="flex items-center gap-2">
                    {/* Customer Action: Request this system */}
                    {onRequestSystem && (
                      <button
                        onClick={() => onRequestSystem(project)}
                        className="px-3 py-1.5 bg-orange-50 hover:bg-orange-100 text-orange-700 border border-orange-200 text-xs font-bold rounded-lg transition"
                      >
                        Request Quote
                      </button>
                    )}

                    {/* Staff Actions */}
                    {permissions.canManageProjects && project.id && (
                      <>
                        <button
                          onClick={() => handleOpenAddModal(project)}
                          className="p-1.5 text-neutral-500 hover:text-neutral-900 hover:bg-neutral-100 rounded-lg transition"
                          title="Edit"
                        >
                          <Edit2 className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={() => handleDelete(project.id)}
                          className="p-1.5 text-neutral-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition"
                          title="Delete"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </>
                    )}
                  </div>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Edit/Add Modal */}
      {modalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
          <div className="bg-white rounded-xl shadow-2xl w-full max-w-lg overflow-hidden border border-neutral-200">
            <div className="flex items-center justify-between px-6 py-4 border-b border-neutral-200 bg-neutral-900 text-white">
              <h2 className="text-sm font-bold">
                {projectToEdit ? 'Edit Showcase Project' : 'Add New Showcase Project'}
              </h2>
              <button
                onClick={() => setModalOpen(false)}
                className="p-1 rounded-lg text-neutral-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveProject} className="p-6 space-y-4">
              <div>
                <label className="block text-xs font-semibold text-neutral-700 mb-1">
                  Project Title *
                </label>
                <input
                  type="text"
                  required
                  value={formTitle}
                  onChange={(e) => setFormTitle(e.target.value)}
                  placeholder="e.g. Dahua WizSense 4K IP Camera System"
                  className="w-full text-xs p-2.5 bg-neutral-50 border border-neutral-300 rounded-lg focus:outline-none focus:bg-white focus:ring-1 focus:ring-orange-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-neutral-700 mb-1">
                    Category *
                  </label>
                  <select
                    value={formCategory}
                    onChange={(e) => setFormCategory(e.target.value)}
                    className="w-full text-xs p-2.5 bg-neutral-50 border border-neutral-300 rounded-lg focus:outline-none"
                  >
                    <option value="CCTV Surveillance">CCTV Surveillance</option>
                    <option value="Solar Camera Systems">Solar Camera Systems</option>
                    <option value="IP & PTZ Cameras">IP & PTZ Cameras</option>
                    <option value="Access Control & Intercom">Access Control & Intercom</option>
                    <option value="Commercial Projects">Commercial Projects</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-neutral-700 mb-1">
                    Featured Project
                  </label>
                  <label className="flex items-center gap-2 mt-2 cursor-pointer text-xs">
                    <input
                      type="checkbox"
                      checked={formFeatured}
                      onChange={(e) => setFormFeatured(e.target.checked)}
                      className="rounded text-orange-600 focus:ring-orange-500"
                    />
                    <span>Highlight on Home</span>
                  </label>
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-neutral-700 mb-1">
                  Image URL
                </label>
                <input
                  type="url"
                  value={formImageUrl}
                  onChange={(e) => setFormImageUrl(e.target.value)}
                  placeholder="https://images.unsplash.com/..."
                  className="w-full text-xs p-2.5 bg-neutral-50 border border-neutral-300 rounded-lg focus:outline-none focus:bg-white focus:ring-1 focus:ring-orange-500"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-neutral-700 mb-1">
                  Description &amp; Equipment Specifications
                </label>
                <textarea
                  rows={4}
                  value={formDescription}
                  onChange={(e) => setFormDescription(e.target.value)}
                  placeholder="Describe cameras, NVR channels, storage, and installation details..."
                  className="w-full text-xs p-2.5 bg-neutral-50 border border-neutral-300 rounded-lg focus:outline-none focus:bg-white focus:ring-1 focus:ring-orange-500"
                />
              </div>

              <div className="pt-3 flex justify-end gap-2 border-t border-neutral-200">
                <button
                  type="button"
                  onClick={() => setModalOpen(false)}
                  className="px-4 py-2 text-xs font-semibold text-neutral-600 hover:bg-neutral-100 rounded-lg transition"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={saving}
                  className="px-5 py-2 bg-neutral-900 hover:bg-black text-white text-xs font-bold rounded-lg transition disabled:opacity-50"
                >
                  {saving ? 'Saving...' : 'Save Project'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
