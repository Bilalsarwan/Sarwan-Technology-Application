import React, { useMemo } from 'react';
import {
  Customer,
  Invoice,
  Payment,
  Expense,
  BusinessSettings,
  UserProfile,
  UserPermissions,
  AuditLog,
  CustomerRequest,
  Project,
  AppNotification,
} from '../types';
import { useAuth, getDefaultPermissions } from '../context/AuthContext';
import {
  getSuperAdminDashboardData,
  getInvoiceManagerDashboardData,
  getPaymentCollectorDashboardData,
  getCustomerDashboardData,
} from '../services/dashboardAuthorization';
import { SuperAdminDashboard } from '../components/dashboard/SuperAdminDashboard';
import { InvoiceManagerDashboard } from '../components/dashboard/InvoiceManagerDashboard';
import { PaymentCollectorDashboard } from '../components/dashboard/PaymentCollectorDashboard';
import { CustomerDashboard } from '../components/dashboard/CustomerDashboard';
import { ActiveTab } from '../components/layout/Sidebar';
import {
  ShieldAlert,
  Loader2,
  Users,
  UserCheck,
  FileText,
  Banknote,
  Wallet,
  CheckCircle2,
  Clock,
  AlertCircle,
  PieChart,
  ArrowUpRight,
} from 'lucide-react';
import {
  calculateTotalUsers,
  calculateTotalCustomers,
  calculateTotalInvoices,
  calculateTotalPayments,
  calculateTotalOutstanding,
  calculateOrganizationKPIs,
  formatAFN,
  formatCount,
  getTodayDateString,
} from '../utils/format';

/**
 * Business Rule 1: Total Users
 * Count of all existing user accounts (active, inactive, suspended, pending).
 * Excludes deleted/null/undefined/empty-id records.
 */
export function calculateValidUsersCount(users: UserProfile[] = []): number {
  if (!Array.isArray(users)) return 0;
  return users.filter((u) => u && typeof u === 'object' && Boolean(u.id)).length;
}

/**
 * Business Rule 2: Total Customers
 * Count of customers where isArchived !== true. Excludes archived customers.
 */
export function calculateValidCustomersCount(customers: Customer[] = []): number {
  if (!Array.isArray(customers)) return 0;
  return customers.filter(
    (c) => c && typeof c === 'object' && Boolean(c.id) && c.isArchived !== true
  ).length;
}

/**
 * Business Rule 3: Total Invoices
 * Count of invoices where isVoid !== true and status !== 'Void'.
 * Strictly uses isVoid filtering to exclude voided billing.
 */
export function calculateValidInvoicesCount(invoices: Invoice[] = []): number {
  if (!Array.isArray(invoices)) return 0;
  return invoices.filter(
    (inv) =>
      inv &&
      typeof inv === 'object' &&
      Boolean(inv.id) &&
      inv.isVoid !== true &&
      inv.status !== 'Void'
  ).length;
}

/**
 * Business Rule 4: Total Payments
 * SUM of amounts of all valid payments where isVoid !== true.
 * Strictly uses isVoid filtering to exclude reversed/voided payments.
 */
export function calculateValidPaymentsAmount(payments: Payment[] = []): number {
  if (!Array.isArray(payments)) return 0;
  return payments.reduce((sum, p) => {
    if (!p || typeof p !== 'object' || !p.id || p.isVoid === true) {
      return sum;
    }
    const rawAmt = typeof p.amount === 'number' ? p.amount : parseFloat(String(p.amount ?? 0));
    const safeAmt = Number.isFinite(rawAmt) && rawAmt > 0 ? rawAmt : 0;
    return sum + safeAmt;
  }, 0);
}

/**
 * Business Rule 5: Total Outstanding
 * For each valid invoice (isVoid !== true and status !== 'Void'):
 *   Invoice Paid = SUM(all valid payments where isVoid !== true matching invoiceId or billNumber)
 *   Invoice Outstanding = Math.max(0, Invoice Total - Invoice Paid)
 * Total Outstanding = SUM(all valid invoice outstanding amounts)
 * Multi-payment installments are accurately summed and negative outstanding is clamped to 0.
 */
export function calculateValidOutstandingAmount(
  invoices: Invoice[] = [],
  payments: Payment[] = []
): number {
  if (!Array.isArray(invoices)) return 0;

  // 1. Valid non-void payments
  const validPayments = Array.isArray(payments)
    ? payments.filter((p) => p && typeof p === 'object' && Boolean(p.id) && p.isVoid !== true)
    : [];

  // 2. Valid non-void invoices (only payable)
  const validInvoices = invoices.filter(
    (inv) =>
      inv &&
      typeof inv === 'object' &&
      Boolean(inv.id) &&
      inv.isVoid !== true &&
      inv.status !== 'Void' &&
      inv.billingState !== 'quotation' &&
      inv.billingState !== 'rejected'
  );

  // 3. Relational index for invoice lookup
  const invoiceIdSet = new Set<string>();
  const billNumberToInvoiceId = new Map<string, string>();
  for (const inv of validInvoices) {
    invoiceIdSet.add(inv.id);
    if (inv.billNumber) {
      billNumberToInvoiceId.set(inv.billNumber, inv.id);
    }
  }

  // 4. Sum multiple payments per invoice
  const paymentsByInvoiceId = new Map<string, number>();
  for (const p of validPayments) {
    const rawAmt = typeof p.amount === 'number' ? p.amount : parseFloat(String(p.amount ?? 0));
    const safeAmt = Number.isFinite(rawAmt) && rawAmt > 0 ? rawAmt : 0;

    let targetInvoiceId: string | undefined = undefined;
    if (p.invoiceId && invoiceIdSet.has(p.invoiceId)) {
      targetInvoiceId = p.invoiceId;
    } else if (p.billNumber && billNumberToInvoiceId.has(p.billNumber)) {
      targetInvoiceId = billNumberToInvoiceId.get(p.billNumber);
    } else if (p.invoiceId && billNumberToInvoiceId.has(p.invoiceId)) {
      targetInvoiceId = billNumberToInvoiceId.get(p.invoiceId);
    }

    if (targetInvoiceId) {
      paymentsByInvoiceId.set(
        targetInvoiceId,
        (paymentsByInvoiceId.get(targetInvoiceId) || 0) + safeAmt
      );
    }
  }

  // 5. Calculate outstanding per invoice with clamping to 0 (prevent negative)
  let totalOutstanding = 0;
  for (const inv of validInvoices) {
    const rawTotal =
      typeof inv.totalAmount === 'number'
        ? inv.totalAmount
        : parseFloat(String(inv.totalAmount ?? 0));
    const invoiceTotalAmount = Number.isFinite(rawTotal) && rawTotal > 0 ? rawTotal : 0;
    const invoicePaidAmount = paymentsByInvoiceId.get(inv.id) || 0;

    const invoiceOutstanding = Math.max(0, invoiceTotalAmount - invoicePaidAmount);
    totalOutstanding += invoiceOutstanding;
  }

  return Math.round(totalOutstanding);
}

/**
 * Monetary formatting with guaranteed 'AFN' currency label
 */
export function formatMonetaryAFN(amount: number | undefined | null, prefix = false): string {
  return formatAFN(amount, prefix);
}

/**
 * Organization Overview Section Component
 * Displays the five core Organization KPIs in a responsive container:
 * - Mobile: grid-cols-1 (stacks cards vertically)
 * - Tablet: sm:grid-cols-2 (2x3 grid with the 5th card spanning 2 columns)
 * - Desktop: lg:grid-cols-5 (clean single row with 5 cards and no overflow)
 */
export interface OrganizationOverviewProps {
  totalUsers: number;
  totalCustomers: number;
  totalInvoices: number;
  totalPayments: number;
  totalOutstanding: number;
  currency?: string;
  className?: string;
}

export const OrganizationOverview: React.FC<OrganizationOverviewProps> = ({
  totalUsers,
  totalCustomers,
  totalInvoices,
  totalPayments,
  totalOutstanding,
  currency = 'AFN',
  className = '',
}) => {
  return (
    <div id="organization-overview-section" className={`space-y-3 ${className}`}>
      <div className="flex flex-col sm:flex-row sm:items-baseline justify-between gap-1">
        <div>
          <h2 id="organization-overview-title" className="text-base font-bold text-neutral-900 tracking-tight">
            Organization Overview
          </h2>
          <p id="organization-overview-subtitle" className="text-xs text-neutral-500">
            Real-time organization statistics
          </p>
        </div>
      </div>

      {/* Organization Overview section container */}
      <div
        id="organization-overview-container"
        className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3 sm:gap-4"
      >
        {/* 1. Total Users */}
        <div
          id="kpi-total-users-card"
          className="bg-white rounded-xl p-4 border border-neutral-200 shadow-xs flex flex-col justify-between min-w-0"
        >
          <div className="flex items-center justify-between text-neutral-500 mb-2">
            <span className="text-[11px] font-bold uppercase tracking-wide truncate mr-1">Total Users</span>
            <Users className="w-4 h-4 text-neutral-400 shrink-0" />
          </div>
          <div>
            <p
              id="kpi-total-users-value"
              className="text-xl sm:text-2xl font-bold font-mono text-neutral-900 tracking-tight truncate"
            >
              {formatCount(totalUsers)}
            </p>
            <span className="text-[10px] text-neutral-400 mt-1 block font-medium truncate">All accounts</span>
          </div>
        </div>

        {/* 2. Total Customers */}
        <div
          id="kpi-total-customers-card"
          className="bg-white rounded-xl p-4 border border-neutral-200 shadow-xs flex flex-col justify-between min-w-0"
        >
          <div className="flex items-center justify-between text-neutral-500 mb-2">
            <span className="text-[11px] font-bold uppercase tracking-wide truncate mr-1">Total Customers</span>
            <UserCheck className="w-4 h-4 text-orange-500 shrink-0" />
          </div>
          <div>
            <p
              id="kpi-total-customers-value"
              className="text-xl sm:text-2xl font-bold font-mono text-neutral-900 tracking-tight truncate"
            >
              {formatCount(totalCustomers)}
            </p>
            <span className="text-[10px] text-neutral-400 mt-1 block font-medium truncate">Active client accounts</span>
          </div>
        </div>

        {/* 3. Total Invoices */}
        <div
          id="kpi-total-invoices-card"
          className="bg-white rounded-xl p-4 border border-neutral-200 shadow-xs flex flex-col justify-between min-w-0"
        >
          <div className="flex items-center justify-between text-neutral-500 mb-2">
            <span className="text-[11px] font-bold uppercase tracking-wide truncate mr-1">Total Invoices</span>
            <FileText className="w-4 h-4 text-sky-500 shrink-0" />
          </div>
          <div>
            <p
              id="kpi-total-invoices-value"
              className="text-xl sm:text-2xl font-bold font-mono text-neutral-900 tracking-tight truncate"
            >
              {formatCount(totalInvoices)}
            </p>
            <span className="text-[10px] text-neutral-400 mt-1 block font-medium truncate">Generated billing</span>
          </div>
        </div>

        {/* 4. Total Payments */}
        <div
          id="kpi-total-payments-card"
          className="bg-white rounded-xl p-4 border border-neutral-200 shadow-xs flex flex-col justify-between min-w-0"
        >
          <div className="flex items-center justify-between text-emerald-600 mb-2">
            <span className="text-[11px] font-bold uppercase tracking-wide text-neutral-500 truncate mr-1">Total Payments</span>
            <Banknote className="w-4 h-4 text-emerald-600 shrink-0" />
          </div>
          <div>
            <p
              id="kpi-total-payments-value"
              className="text-xl sm:text-2xl font-bold font-mono text-emerald-600 tracking-tight truncate"
              title={formatMonetaryAFN(totalPayments, true)}
            >
              {formatMonetaryAFN(totalPayments, true)}
            </p>
            <span className="text-[10px] text-neutral-400 mt-1 block font-medium truncate">Cash collected</span>
          </div>
        </div>

        {/* 5. Total Outstanding */}
        <div
          id="kpi-total-outstanding-card"
          className="col-span-1 sm:col-span-2 lg:col-span-1 bg-neutral-950 text-white rounded-xl p-4 shadow-xs border border-neutral-800 flex flex-col justify-between min-w-0"
        >
          <div className="flex items-center justify-between text-orange-400 mb-2">
            <span className="text-[11px] font-bold uppercase tracking-wide text-neutral-300 truncate mr-1">Total Outstanding</span>
            <Wallet className="w-4 h-4 text-orange-400 shrink-0" />
          </div>
          <div>
            <p
              id="kpi-total-outstanding-value"
              className="text-xl sm:text-2xl font-black font-mono text-white tracking-tight truncate"
              title={formatMonetaryAFN(totalOutstanding, true)}
            >
              {formatMonetaryAFN(totalOutstanding, true)}
            </p>
            <span className="text-[10px] text-neutral-400 mt-1 block font-medium truncate">Receivable balance</span>
          </div>
        </div>
      </div>
    </div>
  );
};

// ===========================================================================
// INVOICE STATUS BREAKDOWN BUSINESS LOGIC & CALCULATION RULES
// ===========================================================================

export type InvoiceBreakdownStatus = 'Paid' | 'Partially Paid' | 'Unpaid' | 'Overdue';

export interface InvoiceStatusBreakdownItem {
  status: InvoiceBreakdownStatus;
  count: number;
  percentage: number;
  totalAmount: number;
  paidAmount: number;
  remainingAmount: number;
  invoices: Invoice[];
}

export interface InvoiceStatusBreakdownData {
  paid: InvoiceStatusBreakdownItem;
  partiallyPaid: InvoiceStatusBreakdownItem;
  unpaid: InvoiceStatusBreakdownItem;
  overdue: InvoiceStatusBreakdownItem;
  totalValidCount: number;
  totalValidAmount: number;
  totalValidRemaining: number;
}

/**
 * Categorizes valid invoices (isVoid !== true && status !== 'Void') into
 * Paid, Partially Paid, Unpaid, and Overdue statuses using the specified business logic:
 *
 * 1. Filter out all voided invoices (isVoid === true or status === 'Void') and invalid records.
 * 2. Sum multiple valid payment installments per invoice (payments with isVoid !== true).
 * 3. Categorization logic:
 *    - Paid:
 *      - inv.status === 'Paid', OR
 *      - (totalPaid >= totalAmount && totalAmount > 0), OR
 *      - (inv.remaining !== undefined && remaining <= 0 && totalPaid > 0)
 *    - Overdue:
 *      - Not Paid, AND
 *      - (inv.status === 'Overdue' OR (inv as any).isOverdue === true OR (Boolean((inv as any).dueDate) && String((inv as any).dueDate).trim() < todayStr))
 *    - Partially Paid:
 *      - Not Paid, Not Overdue, AND
 *      - (inv.status === 'Partially Paid' OR (totalPaid > 0 && totalPaid < totalAmount))
 *    - Unpaid:
 *      - Not Paid, Not Overdue, Not Partially Paid
 *      - (inv.status === 'Unpaid' OR all remaining valid invoices with 0 payments collected)
 * 4. Ensures all monetary outputs use the 'AFN' currency label.
 */
export function calculateInvoiceStatusBreakdown(
  invoices: Invoice[] = [],
  payments: Payment[] = [],
  todayDateStr?: string
): InvoiceStatusBreakdownData {
  const today = todayDateStr || getTodayDateString();

  // Aggregate valid payments per invoice
  const validPayments = Array.isArray(payments)
    ? payments.filter((p) => p && typeof p === 'object' && Boolean(p.id) && p.isVoid !== true)
    : [];

  const paymentsByInvoice = new Map<string, number>();
  for (const p of validPayments) {
    const amt = Number(p.amount) || 0;
    if (amt > 0) {
      if (p.invoiceId) {
        paymentsByInvoice.set(p.invoiceId, (paymentsByInvoice.get(p.invoiceId) || 0) + amt);
      }
      if (p.billNumber) {
        paymentsByInvoice.set(p.billNumber, (paymentsByInvoice.get(p.billNumber) || 0) + amt);
      }
    }
  }

  // Filter valid invoices (strictly excluding isVoid === true and status === 'Void')
  const validInvoices = Array.isArray(invoices)
    ? invoices.filter(
        (inv) =>
          inv &&
          typeof inv === 'object' &&
          Boolean(inv.id) &&
          inv.isVoid !== true &&
          inv.status !== 'Void'
      )
    : [];

  const paidList: Invoice[] = [];
  const overdueList: Invoice[] = [];
  const partiallyPaidList: Invoice[] = [];
  const unpaidList: Invoice[] = [];

  for (const inv of validInvoices) {
    const total = Number(inv.totalAmount) || 0;
    const paid =
      paymentsByInvoice.get(inv.id) ??
      paymentsByInvoice.get(inv.billNumber) ??
      (Number(inv.totalPaid) || 0);

    const remaining =
      inv.remaining !== undefined && inv.remaining !== null
        ? Math.max(0, Number(inv.remaining))
        : Math.max(0, total - paid);

    // 1. Check Paid
    const isPaid =
      inv.status === 'Paid' ||
      (paid >= total && total > 0) ||
      (inv.remaining !== undefined && remaining <= 0 && paid > 0);

    if (isPaid) {
      paidList.push(inv);
      continue;
    }

    // 2. Check Overdue
    const isOverdue =
      (inv.status as string) === 'Overdue' ||
      (inv as any).isOverdue === true ||
      (Boolean((inv as any).dueDate) && String((inv as any).dueDate).trim() < today);

    if (isOverdue) {
      overdueList.push(inv);
      continue;
    }

    // 3. Check Partially Paid
    const isPartial =
      inv.status === 'Partially Paid' ||
      (paid > 0 && paid < total);

    if (isPartial) {
      partiallyPaidList.push(inv);
      continue;
    }

    // 4. Default: Unpaid
    unpaidList.push(inv);
  }

  const totalValidCount = validInvoices.length;
  const totalValidAmount = validInvoices.reduce((sum, inv) => sum + (Number(inv.totalAmount) || 0), 0);

  const buildItem = (
    status: InvoiceBreakdownStatus,
    list: Invoice[]
  ): InvoiceStatusBreakdownItem => {
    const count = list.length;
    const percentage = totalValidCount > 0 ? Math.round((count / totalValidCount) * 100) : 0;
    const totalAmt = list.reduce((sum, inv) => sum + (Number(inv.totalAmount) || 0), 0);
    const paidAmt = list.reduce((sum, inv) => {
      const pd =
        paymentsByInvoice.get(inv.id) ??
        paymentsByInvoice.get(inv.billNumber) ??
        (Number(inv.totalPaid) || 0);
      return sum + pd;
    }, 0);
    const remAmt = list.reduce((sum, inv) => {
      const tot = Number(inv.totalAmount) || 0;
      const pd =
        paymentsByInvoice.get(inv.id) ??
        paymentsByInvoice.get(inv.billNumber) ??
        (Number(inv.totalPaid) || 0);
      return sum + Math.max(0, tot - pd);
    }, 0);

    return {
      status,
      count,
      percentage,
      totalAmount: totalAmt,
      paidAmount: paidAmt,
      remainingAmount: remAmt,
      invoices: list,
    };
  };

  const paid = buildItem('Paid', paidList);
  const partiallyPaid = buildItem('Partially Paid', partiallyPaidList);
  const unpaid = buildItem('Unpaid', unpaidList);
  const overdue = buildItem('Overdue', overdueList);

  const totalValidRemaining =
    paid.remainingAmount +
    partiallyPaid.remainingAmount +
    unpaid.remainingAmount +
    overdue.remainingAmount;

  return {
    paid,
    partiallyPaid,
    unpaid,
    overdue,
    totalValidCount,
    totalValidAmount,
    totalValidRemaining,
  };
}

export function calculatePaidInvoicesCount(invoices: Invoice[] = [], payments: Payment[] = []): number {
  return calculateInvoiceStatusBreakdown(invoices, payments).paid.count;
}

export function calculatePartiallyPaidInvoicesCount(invoices: Invoice[] = [], payments: Payment[] = []): number {
  return calculateInvoiceStatusBreakdown(invoices, payments).partiallyPaid.count;
}

export function calculateUnpaidInvoicesCount(invoices: Invoice[] = [], payments: Payment[] = []): number {
  return calculateInvoiceStatusBreakdown(invoices, payments).unpaid.count;
}

export function calculateOverdueInvoicesCount(
  invoices: Invoice[] = [],
  payments: Payment[] = [],
  todayDateStr?: string
): number {
  return calculateInvoiceStatusBreakdown(invoices, payments, todayDateStr).overdue.count;
}

export interface InvoiceStatusBreakdownProps {
  invoices: Invoice[];
  payments?: Payment[];
  todayDate?: string;
  currency?: string;
  className?: string;
  onSelectStatus?: (status: InvoiceBreakdownStatus) => void;
  onSelectInvoice?: (invoice: Invoice) => void;
  onViewAllInvoices?: () => void;
}

/**
 * Invoice Status Breakdown Component
 * Categorizes valid invoices (isVoid !== true) into Paid, Partially Paid, Unpaid, and Overdue statuses.
 * Displays counts, percentages, and financial summaries in AFN currency.
 */
export const InvoiceStatusBreakdown: React.FC<InvoiceStatusBreakdownProps> = ({
  invoices = [],
  payments = [],
  todayDate,
  currency = 'AFN',
  className = '',
  onSelectStatus,
  onSelectInvoice,
  onViewAllInvoices,
}) => {
  const breakdown = useMemo(() => {
    return calculateInvoiceStatusBreakdown(invoices, payments, todayDate);
  }, [invoices, payments, todayDate]);

  return (
    <div id="invoice-status-breakdown-section" className={`space-y-3 sm:space-y-4 ${className}`}>
      {/* Section Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
        <div>
          <div className="flex items-center gap-2">
            <PieChart className="w-4 h-4 text-orange-500 shrink-0" />
            <h2 id="invoice-status-breakdown-title" className="text-base font-bold text-neutral-900 tracking-tight">
              Invoice Status Breakdown
            </h2>
          </div>
          <p id="invoice-status-breakdown-subtitle" className="text-xs text-neutral-500 mt-0.5">
            Overview of current invoice distribution by status
          </p>
        </div>

        <div className="flex items-center gap-2 self-start sm:self-auto">
          <span
            id="breakdown-total-valid-badge"
            className="text-[11px] font-semibold font-mono px-2.5 py-1 rounded-md bg-neutral-100 text-neutral-700 border border-neutral-200"
          >
            Total Valid: {formatCount(breakdown.totalValidCount)}
          </span>
          {onViewAllInvoices && (
            <button
              onClick={onViewAllInvoices}
              className="text-xs font-semibold text-orange-600 hover:text-orange-700 transition flex items-center gap-1 cursor-pointer"
            >
              <span>View All</span>
              <ArrowUpRight className="w-3.5 h-3.5" />
            </button>
          )}
        </div>
      </div>

      {/* Proportional Distribution Bar */}
      {breakdown.totalValidCount > 0 && (
        <div className="bg-neutral-100 rounded-lg p-2 border border-neutral-200 space-y-1.5">
          <div className="h-2.5 w-full bg-neutral-200 rounded-full flex overflow-hidden">
            {breakdown.paid.count > 0 && (
              <div
                style={{ width: `${(breakdown.paid.count / breakdown.totalValidCount) * 100}%` }}
                className="bg-emerald-500 transition-all duration-500 hover:opacity-90"
                title={`Paid: ${breakdown.paid.count} (${breakdown.paid.percentage}%)`}
              />
            )}
            {breakdown.partiallyPaid.count > 0 && (
              <div
                style={{ width: `${(breakdown.partiallyPaid.count / breakdown.totalValidCount) * 100}%` }}
                className="bg-amber-500 transition-all duration-500 hover:opacity-90"
                title={`Partially Paid: ${breakdown.partiallyPaid.count} (${breakdown.partiallyPaid.percentage}%)`}
              />
            )}
            {breakdown.unpaid.count > 0 && (
              <div
                style={{ width: `${(breakdown.unpaid.count / breakdown.totalValidCount) * 100}%` }}
                className="bg-sky-500 transition-all duration-500 hover:opacity-90"
                title={`Unpaid: ${breakdown.unpaid.count} (${breakdown.unpaid.percentage}%)`}
              />
            )}
            {breakdown.overdue.count > 0 && (
              <div
                style={{ width: `${(breakdown.overdue.count / breakdown.totalValidCount) * 100}%` }}
                className="bg-rose-500 transition-all duration-500 hover:opacity-90"
                title={`Overdue: ${breakdown.overdue.count} (${breakdown.overdue.percentage}%)`}
              />
            )}
          </div>
          <div className="flex flex-wrap items-center justify-between text-[10px] text-neutral-500 px-1">
            <span className="flex items-center gap-1">
              <span className="w-2 h-2 rounded-full bg-emerald-500 inline-block" /> Paid ({breakdown.paid.percentage}%)
            </span>
            <span className="flex items-center gap-1">
              <span className="w-2 h-2 rounded-full bg-amber-500 inline-block" /> Partial ({breakdown.partiallyPaid.percentage}%)
            </span>
            <span className="flex items-center gap-1">
              <span className="w-2 h-2 rounded-full bg-sky-500 inline-block" /> Unpaid ({breakdown.unpaid.percentage}%)
            </span>
            <span className="flex items-center gap-1">
              <span className="w-2 h-2 rounded-full bg-rose-500 inline-block" /> Overdue ({breakdown.overdue.percentage}%)
            </span>
          </div>
        </div>
      )}

      {/* 4 Status Cards Grid */}
      <div
        id="invoice-status-breakdown-container"
        className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4"
      >
        {/* 1. Paid Card */}
        <div
          id="breakdown-card-paid"
          onClick={() => onSelectStatus?.('Paid')}
          className={`bg-white rounded-xl p-4 border border-emerald-200/80 bg-emerald-50/15 shadow-xs flex flex-col justify-between min-w-0 transition ${
            onSelectStatus ? 'cursor-pointer hover:border-emerald-300 hover:shadow-sm' : ''
          }`}
        >
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-2">
              <div className="w-7 h-7 rounded-lg bg-emerald-100 text-emerald-700 flex items-center justify-center shrink-0">
                <CheckCircle2 className="w-4 h-4" />
              </div>
              <div>
                <span id="breakdown-label-paid" className="text-[11px] font-bold uppercase tracking-wide text-emerald-800 block">
                  Paid
                </span>
                <span className="text-[10px] text-neutral-400">Fully collected</span>
              </div>
            </div>
            <span
              id="breakdown-percentage-paid"
              className="px-2 py-0.5 text-xs font-bold font-mono rounded-md bg-emerald-100 text-emerald-800"
            >
              {breakdown.paid.percentage}%
            </span>
          </div>

          <div>
            <div className="flex items-baseline justify-between gap-2">
              <p id="breakdown-count-paid" className="text-xl sm:text-2xl font-bold font-mono text-emerald-700 tracking-tight">
                {formatCount(breakdown.paid.count)}
              </p>
              <span className="text-[11px] font-semibold text-neutral-500">
                {breakdown.paid.count === 1 ? 'invoice' : 'invoices'}
              </span>
            </div>
            <div className="mt-2 pt-2 border-t border-emerald-100 flex items-center justify-between text-[11px]">
              <span className="text-neutral-400">Settled Amount:</span>
              <span
                id="breakdown-amount-paid"
                className="font-mono font-bold text-emerald-800 truncate"
                title={formatMonetaryAFN(breakdown.paid.totalAmount, true)}
              >
                {formatMonetaryAFN(breakdown.paid.totalAmount, true)}
              </span>
            </div>
          </div>
        </div>

        {/* 2. Partially Paid Card */}
        <div
          id="breakdown-card-partially-paid"
          onClick={() => onSelectStatus?.('Partially Paid')}
          className={`bg-white rounded-xl p-4 border border-amber-200/80 bg-amber-50/15 shadow-xs flex flex-col justify-between min-w-0 transition ${
            onSelectStatus ? 'cursor-pointer hover:border-amber-300 hover:shadow-sm' : ''
          }`}
        >
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-2">
              <div className="w-7 h-7 rounded-lg bg-amber-100 text-amber-700 flex items-center justify-center shrink-0">
                <Clock className="w-4 h-4" />
              </div>
              <div>
                <span id="breakdown-label-partially-paid" className="text-[11px] font-bold uppercase tracking-wide text-amber-800 block">
                  Partially Paid
                </span>
                <span className="text-[10px] text-neutral-400">Partially settled</span>
              </div>
            </div>
            <span
              id="breakdown-percentage-partially-paid"
              className="px-2 py-0.5 text-xs font-bold font-mono rounded-md bg-amber-100 text-amber-800"
            >
              {breakdown.partiallyPaid.percentage}%
            </span>
          </div>

          <div>
            <div className="flex items-baseline justify-between gap-2">
              <p id="breakdown-count-partially-paid" className="text-xl sm:text-2xl font-bold font-mono text-amber-700 tracking-tight">
                {formatCount(breakdown.partiallyPaid.count)}
              </p>
              <span className="text-[11px] font-semibold text-neutral-500">
                {breakdown.partiallyPaid.count === 1 ? 'invoice' : 'invoices'}
              </span>
            </div>
            <div className="mt-2 pt-2 border-t border-amber-100 flex items-center justify-between text-[11px]">
              <span className="text-neutral-400">Remaining Due:</span>
              <span
                id="breakdown-amount-partially-paid"
                className="font-mono font-bold text-amber-800 truncate"
                title={formatMonetaryAFN(breakdown.partiallyPaid.remainingAmount, true)}
              >
                {formatMonetaryAFN(breakdown.partiallyPaid.remainingAmount, true)}
              </span>
            </div>
          </div>
        </div>

        {/* 3. Unpaid Card */}
        <div
          id="breakdown-card-unpaid"
          onClick={() => onSelectStatus?.('Unpaid')}
          className={`bg-white rounded-xl p-4 border border-sky-200/80 bg-sky-50/15 shadow-xs flex flex-col justify-between min-w-0 transition ${
            onSelectStatus ? 'cursor-pointer hover:border-sky-300 hover:shadow-sm' : ''
          }`}
        >
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-2">
              <div className="w-7 h-7 rounded-lg bg-sky-100 text-sky-700 flex items-center justify-center shrink-0">
                <FileText className="w-4 h-4" />
              </div>
              <div>
                <span id="breakdown-label-unpaid" className="text-[11px] font-bold uppercase tracking-wide text-sky-800 block">
                  Unpaid
                </span>
                <span className="text-[10px] text-neutral-400">Awaiting full payment</span>
              </div>
            </div>
            <span
              id="breakdown-percentage-unpaid"
              className="px-2 py-0.5 text-xs font-bold font-mono rounded-md bg-sky-100 text-sky-800"
            >
              {breakdown.unpaid.percentage}%
            </span>
          </div>

          <div>
            <div className="flex items-baseline justify-between gap-2">
              <p id="breakdown-count-unpaid" className="text-xl sm:text-2xl font-bold font-mono text-sky-700 tracking-tight">
                {formatCount(breakdown.unpaid.count)}
              </p>
              <span className="text-[11px] font-semibold text-neutral-500">
                {breakdown.unpaid.count === 1 ? 'invoice' : 'invoices'}
              </span>
            </div>
            <div className="mt-2 pt-2 border-t border-sky-100 flex items-center justify-between text-[11px]">
              <span className="text-neutral-400">Total Unpaid:</span>
              <span
                id="breakdown-amount-unpaid"
                className="font-mono font-bold text-sky-800 truncate"
                title={formatMonetaryAFN(breakdown.unpaid.remainingAmount, true)}
              >
                {formatMonetaryAFN(breakdown.unpaid.remainingAmount, true)}
              </span>
            </div>
          </div>
        </div>

        {/* 4. Overdue Card */}
        <div
          id="breakdown-card-overdue"
          onClick={() => onSelectStatus?.('Overdue')}
          className={`bg-white rounded-xl p-4 border border-rose-200/80 bg-rose-50/15 shadow-xs flex flex-col justify-between min-w-0 transition ${
            onSelectStatus ? 'cursor-pointer hover:border-rose-300 hover:shadow-sm' : ''
          }`}
        >
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-2">
              <div className="w-7 h-7 rounded-lg bg-rose-100 text-rose-700 flex items-center justify-center shrink-0">
                <AlertCircle className="w-4 h-4" />
              </div>
              <div>
                <span id="breakdown-label-overdue" className="text-[11px] font-bold uppercase tracking-wide text-rose-800 block">
                  Overdue
                </span>
                <span className="text-[10px] text-neutral-400">Past payment deadline</span>
              </div>
            </div>
            <span
              id="breakdown-percentage-overdue"
              className="px-2 py-0.5 text-xs font-bold font-mono rounded-md bg-rose-100 text-rose-800"
            >
              {breakdown.overdue.percentage}%
            </span>
          </div>

          <div>
            <div className="flex items-baseline justify-between gap-2">
              <p id="breakdown-count-overdue" className="text-xl sm:text-2xl font-bold font-mono text-rose-700 tracking-tight">
                {formatCount(breakdown.overdue.count)}
              </p>
              <span className="text-[11px] font-semibold text-neutral-500">
                {breakdown.overdue.count === 1 ? 'invoice' : 'invoices'}
              </span>
            </div>
            <div className="mt-2 pt-2 border-t border-rose-100 flex items-center justify-between text-[11px]">
              <span className="text-neutral-400">Past Due Balance:</span>
              <span
                id="breakdown-amount-overdue"
                className="font-mono font-bold text-rose-800 truncate"
                title={formatMonetaryAFN(breakdown.overdue.remainingAmount, true)}
              >
                {formatMonetaryAFN(breakdown.overdue.remainingAmount, true)}
              </span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export interface DashboardViewProps {
  invoices: Invoice[];
  customers: Customer[];
  payments: Payment[];
  expenses: Expense[];
  settings: BusinessSettings;
  users?: UserProfile[];
  auditLogs?: AuditLog[];
  requests?: CustomerRequest[];
  projects?: Project[];
  notifications?: AppNotification[];
  onNewInvoice: () => void;
  onNewCustomer: () => void;
  onAddPayment: (invoiceId?: string) => void;
  onAddExpense: () => void;
  onSelectInvoice: (invoice: Invoice) => void;
  onSelectPayment?: (payment: Payment) => void;
  onSelectCustomer?: (customer: Customer) => void;
  onViewAllInvoices: () => void;
  onTabChange?: (tab: ActiveTab) => void;
  onRequestProject?: (project: Project) => void;
  onNewCustomerRequest?: () => void;
}

export const DashboardView: React.FC<DashboardViewProps> = ({
  invoices = [],
  customers = [],
  payments = [],
  expenses = [],
  settings,
  users = [],
  auditLogs = [],
  requests = [],
  projects = [],
  notifications = [],
  onNewInvoice,
  onNewCustomer,
  onAddPayment,
  onAddExpense,
  onSelectInvoice,
  onSelectPayment,
  onSelectCustomer,
  onViewAllInvoices,
  onTabChange,
  onRequestProject,
  onNewCustomerRequest,
}) => {
  const { userProfile, permissions, userRole, activeCustomer, loading: authLoading } = useAuth();

  // -------------------------------------------------------------------------
  // Top-Level Memoized Organization KPI Calculations
  // Strictly adhering to the 5 approved business rules:
  // 1. Total Users: count of all existing accounts regardless of status
  // 2. Total Customers: count(customers where isArchived !== true)
  // 3. Total Invoices: count(invoices where isVoid !== true and status !== 'Void')
  // 4. Total Payments: sum(amount of all valid payments where isVoid !== true)
  // 5. Total Outstanding: sum for each valid invoice (isVoid !== true) of
  //    Math.max(0, invoiceTotal - SUM(valid payments where isVoid !== true)),
  //    supporting multi-payment installments and clamping negative to 0.
  // All monetary results use the 'AFN' currency label.
  // -------------------------------------------------------------------------
  const memoizedTotalUsers = useMemo(() => {
    return calculateValidUsersCount(users);
  }, [users]);

  const memoizedTotalCustomers = useMemo(() => {
    return calculateValidCustomersCount(customers);
  }, [customers]);

  const memoizedTotalInvoices = useMemo(() => {
    return calculateValidInvoicesCount(invoices);
  }, [invoices]);

  const memoizedTotalPayments = useMemo(() => {
    return calculateValidPaymentsAmount(payments);
  }, [payments]);

  const memoizedTotalOutstanding = useMemo(() => {
    return calculateValidOutstandingAmount(invoices, payments);
  }, [invoices, payments]);

  // Formatted monetary results with explicit 'AFN' label
  const memoizedTotalPaymentsFormatted = useMemo(() => {
    return formatMonetaryAFN(memoizedTotalPayments, true);
  }, [memoizedTotalPayments]);

  const memoizedTotalOutstandingFormatted = useMemo(() => {
    return formatMonetaryAFN(memoizedTotalOutstanding, true);
  }, [memoizedTotalOutstanding]);

  // Guaranteed 'AFN' currency business settings
  const effectiveSettings: BusinessSettings = useMemo(() => {
    return {
      ...settings,
      currency: 'AFN',
    };
  }, [settings]);

  // Consolidated Organization KPIs object with guaranteed 'AFN' currency
  const organizationKPIs = useMemo(() => {
    return {
      totalUsers: memoizedTotalUsers,
      totalCustomers: memoizedTotalCustomers,
      totalInvoices: memoizedTotalInvoices,
      totalPayments: memoizedTotalPayments,
      totalOutstanding: memoizedTotalOutstanding,
      totalPaymentsFormatted: memoizedTotalPaymentsFormatted,
      totalOutstandingFormatted: memoizedTotalOutstandingFormatted,
      currency: 'AFN' as const,
    };
  }, [
    memoizedTotalUsers,
    memoizedTotalCustomers,
    memoizedTotalInvoices,
    memoizedTotalPayments,
    memoizedTotalOutstanding,
    memoizedTotalPaymentsFormatted,
    memoizedTotalOutstandingFormatted,
  ]);

  // 1. Loading State
  if (authLoading) {
    return (
      <div className="min-h-[400px] flex flex-col items-center justify-center p-8 text-center">
        <Loader2 className="w-8 h-8 text-orange-500 animate-spin mb-3" />
        <p className="text-sm font-semibold text-neutral-700">
          Verifying role authorization and loading dashboard...
        </p>
      </div>
    );
  }

  // 2. Identity & Status Validation
  if (!userProfile) {
    return (
      <div className="bg-white rounded-2xl p-8 border border-neutral-200 shadow-xs max-w-lg mx-auto text-center my-12">
        <ShieldAlert className="w-10 h-10 text-rose-500 mx-auto mb-3" />
        <h2 className="text-base font-bold text-neutral-900">Access Denied</h2>
        <p className="text-xs text-neutral-500 mt-1">
          No valid authenticated profile found. Please sign in to view the dashboard.
        </p>
      </div>
    );
  }

  if (userProfile.status === 'inactive' || userProfile.isDeactivated) {
    return (
      <div className="bg-white rounded-2xl p-8 border border-rose-200 bg-rose-50/20 shadow-xs max-w-lg mx-auto text-center my-12">
        <ShieldAlert className="w-10 h-10 text-rose-600 mx-auto mb-3" />
        <h2 className="text-base font-bold text-rose-900">Account Deactivated</h2>
        <p className="text-xs text-rose-700 mt-1">
          Your account has been deactivated by the Super Administrator. You do not have access to any dashboard data.
        </p>
      </div>
    );
  }

  // Determine effective role and permissions safely
  const effectiveRole = ((userProfile.role || userRole || '').trim().toLowerCase()) as any;
  const safeProfile: UserProfile = { ...userProfile, role: effectiveRole };
  const safePermissions: UserPermissions = permissions || getDefaultPermissions(effectiveRole);

  // 3. Strict Role-Based Dashboard Routing
  // Access Principle: Role → Permission → Data Ownership/Assignment → Access

  // --- ROLE: SUPER ADMIN ---
  if (effectiveRole === 'super_admin') {
    try {
      const baseData = getSuperAdminDashboardData(
        safeProfile,
        safePermissions,
        invoices,
        customers,
        payments,
        expenses,
        users,
        auditLogs,
        notifications
      );

      const superAdminData = {
        ...baseData,
        totalUsersCount: organizationKPIs.totalUsers,
        totalCustomersCount: organizationKPIs.totalCustomers,
        totalInvoicesCount: organizationKPIs.totalInvoices,
        totalPaymentsAmount: organizationKPIs.totalPayments,
        totalOutstandingAmount: organizationKPIs.totalOutstanding,
        currency: 'AFN',
      };

      return (
        <SuperAdminDashboard
          data={superAdminData}
          settings={effectiveSettings}
          onNewInvoice={onNewInvoice}
          onNewCustomer={onNewCustomer}
          onAddPayment={() => onAddPayment()}
          onAddExpense={onAddExpense}
          onSelectInvoice={onSelectInvoice}
          onSelectPayment={onSelectPayment}
          onTabChange={onTabChange}
          payments={payments}
          invoices={invoices}
          customers={customers}
          users={users}
          expenses={expenses}
          invoiceStatusBreakdown={
            <InvoiceStatusBreakdown
              invoices={invoices}
              payments={payments}
              onSelectInvoice={onSelectInvoice}
              onViewAllInvoices={() => onTabChange?.('invoices')}
            />
          }
        />
      );
    } catch (err) {
      console.error('Super Admin Dashboard authorization error:', err);
      return (
        <div className="p-6 bg-rose-50 border border-rose-200 text-rose-800 rounded-xl text-xs">
          Failed to load Super Admin dashboard: {(err as Error).message}
        </div>
      );
    }
  }

  // --- ROLE: INVOICE MANAGER ---
  if (effectiveRole === 'invoice_manager') {
    try {
      const baseInvoiceData = getInvoiceManagerDashboardData(
        safeProfile,
        safePermissions,
        invoices,
        customers,
        payments,
        requests,
        notifications
      );

      const invoiceManagerData = {
        ...baseInvoiceData,
        totalCustomersCount: organizationKPIs.totalCustomers,
        totalInvoicesCount: organizationKPIs.totalInvoices,
        totalOutstandingAmount: organizationKPIs.totalOutstanding,
        currency: 'AFN',
      };

      return (
        <InvoiceManagerDashboard
          data={invoiceManagerData}
          settings={effectiveSettings}
          onNewInvoice={onNewInvoice}
          onNewCustomer={onNewCustomer}
          onAddPayment={() => onAddPayment()}
          onAddExpense={onAddExpense}
          onSelectInvoice={onSelectInvoice}
          onSelectPayment={onSelectPayment}
          onTabChange={onTabChange}
          payments={payments}
        />
      );
    } catch (err) {
      console.error('Invoice Manager Dashboard authorization error:', err);
      return (
        <div className="p-6 bg-rose-50 border border-rose-200 text-rose-800 rounded-xl text-xs">
          Failed to load Invoice Manager dashboard: {(err as Error).message}
        </div>
      );
    }
  }

  // --- ROLE: PAYMENT COLLECTOR ---
  if (effectiveRole === 'payment_collector') {
    try {
      const collectorData = getPaymentCollectorDashboardData(
        safeProfile,
        safePermissions,
        invoices,
        customers,
        payments,
        notifications
      );

      return (
        <PaymentCollectorDashboard
          data={collectorData}
          settings={effectiveSettings}
          onAddPayment={(invId) => onAddPayment(invId)}
          onAddExpense={safePermissions.canManageExpenses || safePermissions.canCreateExpense || safeProfile.role === 'payment_collector' ? onAddExpense : undefined}
          onSelectInvoice={onSelectInvoice}
          onSelectPayment={onSelectPayment}
          onSelectCustomer={onSelectCustomer}
          onTabChange={onTabChange}
          payments={payments}
        />
      );
    } catch (err) {
      console.error('Payment Collector Dashboard authorization error:', err);
      return (
        <div className="p-6 bg-rose-50 border border-rose-200 text-rose-800 rounded-xl text-xs">
          Failed to load Payment Collector dashboard: {(err as Error).message}
        </div>
      );
    }
  }

  // --- ROLE: CUSTOMER ---
  if (effectiveRole === 'customer') {
    try {
      const customerData = getCustomerDashboardData(
        safeProfile,
        activeCustomer,
        invoices,
        payments,
        requests,
        projects,
        notifications
      );

      return (
        <CustomerDashboard
          data={customerData}
          settings={effectiveSettings}
          onSelectInvoice={onSelectInvoice}
          onNewRequest={onNewCustomerRequest}
          onRequestProject={onRequestProject}
          payments={payments}
        />
      );
    } catch (err) {
      console.error('Customer Dashboard authorization error:', err);
      return (
        <div className="p-6 bg-rose-50 border border-rose-200 text-rose-800 rounded-xl text-xs">
          Failed to load Customer dashboard: {(err as Error).message}
        </div>
      );
    }
  }

  // Fallback for unauthorized / unrecognized role
  return (
    <div className="bg-white rounded-2xl p-8 border border-neutral-200 shadow-xs max-w-lg mx-auto text-center my-12">
      <ShieldAlert className="w-10 h-10 text-amber-500 mx-auto mb-3" />
      <h2 className="text-base font-bold text-neutral-900">Unrecognized Role</h2>
      <p className="text-xs text-neutral-500 mt-1">
        Your account role ({effectiveRole || 'unassigned'}) does not have an assigned dashboard layout. Please contact the administrator.
      </p>
    </div>
  );
};
