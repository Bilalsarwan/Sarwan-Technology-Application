import React, { useState, useEffect, useCallback, useMemo } from 'react';
import { BusinessSettings, Invoice, Payment, CustomInvoiceTemplate } from '../types';
import {
  InvoiceDesignSettings,
  DEFAULT_INVOICE_DESIGN,
  DesignerElement,
  normalizeTableColumnOrder,
  normalizeFooterElementsOrder,
} from '../types/invoiceDesign';
import {
  migrateLegacyVisibility,
  migrateLegacySpacing,
} from '../utils/canonicalVisibility';
import { updateBusinessSettings, subscribeToInvoices, subscribeToPayments, cleanDataForFirestore } from '../services/db';
import { useAuth } from '../context/AuthContext';
import { InvoiceTemplatePreview } from '../components/invoice/InvoiceTemplatePreview';
import { ContextualToolbar } from '../components/invoice/ContextualToolbar';
import { InsertFieldManagerDrawer } from '../components/invoice/InsertFieldManagerDrawer';
import { DocumentLayoutDrawer } from '../components/invoice/DocumentLayoutDrawer';
import { TypographyControls, isTextDesignerElement } from '../components/invoice/TypographyControls';
import { resolveTemplates, DEFAULT_CUSTOM_TEMPLATES } from '../utils/defaultCustomTemplates';
import {
  Save,
  RotateCcw,
  Undo2,
  Redo2,
  CheckCircle2,
  AlertCircle,
  Loader2,
  ShieldAlert,
  ZoomIn,
  ZoomOut,
  Maximize2,
  Layout,
  PlusSquare,
  Building,
  FileText,
  Users,
  Table as TableIcon,
  CreditCard,
  Calculator,
  Compass,
  Check,
  Sparkles,
  ChevronDown,
  FolderOpen,
  Plus,
  Star,
  Copy,
  Trash2,
  X,
  Settings,
  Sliders,
  Type,
} from 'lucide-react';

export interface InvoiceDesignerViewProps {
  settings: BusinessSettings;
  onSettingsUpdated?: (updated: BusinessSettings) => void;
}

/**
 * Deep merge helper ensuring every nested property in InvoiceDesignSettings is guaranteed
 * to be defined and never undefined, preventing React uncontrolled-to-controlled input warnings.
 */
export function mergeDesignSettings(saved?: Partial<InvoiceDesignSettings>): InvoiceDesignSettings {
  if (!saved) return DEFAULT_INVOICE_DESIGN;

  const merged: InvoiceDesignSettings = {
    ...DEFAULT_INVOICE_DESIGN,
    ...saved,
    presetName: saved.presetName || DEFAULT_INVOICE_DESIGN.presetName,
    page: {
      ...DEFAULT_INVOICE_DESIGN.page,
      ...(saved.page || {}),
      margins: {
        ...DEFAULT_INVOICE_DESIGN.page.margins,
        ...(saved.page?.margins || {}),
      },
      showCornerDecorations:
        saved.page?.showCornerDecorations ?? DEFAULT_INVOICE_DESIGN.page.showCornerDecorations ?? true,
      showPageBorder:
        saved.page?.showPageBorder ?? DEFAULT_INVOICE_DESIGN.page.showPageBorder ?? false,
    },
    shapes: {
      topLeft: {
        ...DEFAULT_INVOICE_DESIGN.shapes?.topLeft,
        ...(saved.shapes?.topLeft || {}),
      },
      topRight: {
        ...DEFAULT_INVOICE_DESIGN.shapes?.topRight,
        ...(saved.shapes?.topRight || {}),
      },
      goldAccent: {
        ...DEFAULT_INVOICE_DESIGN.shapes?.goldAccent,
        ...(saved.shapes?.goldAccent || {}),
      },
      bottomLeft: {
        ...DEFAULT_INVOICE_DESIGN.shapes?.bottomLeft,
        ...(saved.shapes?.bottomLeft || {}),
      },
      bottomRight: {
        ...DEFAULT_INVOICE_DESIGN.shapes?.bottomRight,
        ...(saved.shapes?.bottomRight || {}),
      },
    } as any,
    logos: {
      logo1: {
        ...DEFAULT_INVOICE_DESIGN.logos.logo1,
        ...(saved.logos?.logo1 || {}),
        url: saved.logos?.logo1?.url ?? DEFAULT_INVOICE_DESIGN.logos.logo1.url,
      },
      logo2: {
        ...DEFAULT_INVOICE_DESIGN.logos.logo2,
        ...(saved.logos?.logo2 || {}),
        url: saved.logos?.logo2?.url ?? DEFAULT_INVOICE_DESIGN.logos.logo2.url,
      },
    },
    company: {
      ...DEFAULT_INVOICE_DESIGN.company,
      ...(saved.company || {}),
    },
    header: {
      ...DEFAULT_INVOICE_DESIGN.header,
      ...(saved.header || {}),
    },
    title: {
      ...DEFAULT_INVOICE_DESIGN.title,
      ...(saved.title || {}),
    },
    invoiceNumber: {
      ...DEFAULT_INVOICE_DESIGN.invoiceNumber,
      ...(saved.invoiceNumber || {}),
    },
    date: {
      ...DEFAULT_INVOICE_DESIGN.date,
      ...(saved.date || {}),
    },
    collector: {
      ...DEFAULT_INVOICE_DESIGN.collector,
      ...(saved.collector || {}),
    },
    customer: {
      ...DEFAULT_INVOICE_DESIGN.customer,
      ...(saved.customer || {}),
    },
    itemsTable: {
      ...DEFAULT_INVOICE_DESIGN.itemsTable,
      ...(saved.itemsTable || {}),
      columnOrder: normalizeTableColumnOrder(
        saved.itemsTable?.columnOrder || DEFAULT_INVOICE_DESIGN.itemsTable.columnOrder
      ),
      columns: {
        ...DEFAULT_INVOICE_DESIGN.itemsTable.columns,
        ...(saved.itemsTable?.columns || {}),
        sNo: {
          ...DEFAULT_INVOICE_DESIGN.itemsTable.columns.sNo,
          ...(saved.itemsTable?.columns?.sNo || {}),
        },
        description: {
          ...DEFAULT_INVOICE_DESIGN.itemsTable.columns.description,
          ...(saved.itemsTable?.columns?.description || {}),
        },
        quantity: {
          ...DEFAULT_INVOICE_DESIGN.itemsTable.columns.quantity,
          ...(saved.itemsTable?.columns?.quantity || {}),
        },
        unit: {
          ...DEFAULT_INVOICE_DESIGN.itemsTable.columns.unit,
          ...(saved.itemsTable?.columns?.unit || {}),
        },
        unitPrice: {
          ...DEFAULT_INVOICE_DESIGN.itemsTable.columns.unitPrice,
          ...(saved.itemsTable?.columns?.unitPrice || {}),
        },
        discount: {
          ...DEFAULT_INVOICE_DESIGN.itemsTable.columns.discount,
          ...(saved.itemsTable?.columns?.discount || {}),
        },
        tax: {
          ...DEFAULT_INVOICE_DESIGN.itemsTable.columns.tax,
          ...(saved.itemsTable?.columns?.tax || {}),
        },
        totalAmount: {
          ...DEFAULT_INVOICE_DESIGN.itemsTable.columns.totalAmount,
          ...(saved.itemsTable?.columns?.totalAmount || {}),
        },
      },
    },
    payment: {
      ...DEFAULT_INVOICE_DESIGN.payment,
      ...(saved.payment || {}),
    },
    totals: {
      ...DEFAULT_INVOICE_DESIGN.totals,
      ...(saved.totals || {}),
    },
    notes: {
      ...DEFAULT_INVOICE_DESIGN.notes,
      ...(saved.notes || {}),
    },
    signatures: {
      ...DEFAULT_INVOICE_DESIGN.signatures,
      ...(saved.signatures || {}),
    },
    footer: {
      ...DEFAULT_INVOICE_DESIGN.footer,
      ...(saved.footer || {}),
      footerElementsOrder: normalizeFooterElementsOrder(
        saved.footer?.footerElementsOrder || DEFAULT_INVOICE_DESIGN.footer?.footerElementsOrder
      ),
    },
    pageNumber: {
      ...DEFAULT_INVOICE_DESIGN.pageNumber,
      ...(saved.pageNumber || {}),
    },
    colors: {
      ...DEFAULT_INVOICE_DESIGN.colors,
      ...(saved.colors || {}),
    },
    typography: {
      ...DEFAULT_INVOICE_DESIGN.typography,
      ...(saved.typography || {}),
    },
    spacing: migrateLegacySpacing(saved.spacing),
    visibility: {
      ...DEFAULT_INVOICE_DESIGN.visibility,
      ...(saved.visibility || {}),
    },
  };
  return migrateLegacyVisibility(merged) as InvoiceDesignSettings;
}

export interface PresetCard {
  id: 'sarwan_official' | 'modern_corporate' | 'minimal_clean' | 'classic_formal' | 'compact_tech';
  name: string;
  badge: string;
  primaryColor: string;
  secondaryColor: string;
  accentColor: string;
  fontFamily: string;
  headingFontFamily: string;
}

export const PRESET_CARDS: PresetCard[] = [
  {
    id: 'sarwan_official',
    name: 'Sarwan Official (Style #7)',
    badge: 'Official',
    primaryColor: '#0B1E36',
    secondaryColor: '#1E3A8A',
    accentColor: '#C5A059',
    fontFamily: "'Inter', sans-serif",
    headingFontFamily: "'Inter', sans-serif",
  },
  {
    id: 'modern_corporate',
    name: 'Modern Corporate',
    badge: 'Corporate',
    primaryColor: '#0F172A',
    secondaryColor: '#2563EB',
    accentColor: '#38BDF8',
    fontFamily: "'Inter', sans-serif",
    headingFontFamily: "'Inter', sans-serif",
  },
  {
    id: 'minimal_clean',
    name: 'Minimal Clean',
    badge: 'Modern',
    primaryColor: '#18181B',
    secondaryColor: '#4F46E5',
    accentColor: '#6366F1',
    fontFamily: "'Roboto', sans-serif",
    headingFontFamily: "'Roboto', sans-serif",
  },
  {
    id: 'classic_formal',
    name: 'Classic Formal',
    badge: 'Traditional',
    primaryColor: '#0F172A',
    secondaryColor: '#2563EB',
    accentColor: '#D97706',
    fontFamily: "'Times New Roman', serif",
    headingFontFamily: "'Times New Roman', serif",
  },
  {
    id: 'compact_tech',
    name: 'Compact Tech',
    badge: 'Density',
    primaryColor: '#1E293B',
    secondaryColor: '#0284C7',
    accentColor: '#0D9488',
    fontFamily: "'Outfit', sans-serif",
    headingFontFamily: "'Outfit', sans-serif",
  },
];

const FieldToggleItem: React.FC<{
  label: string;
  checked: boolean;
  onChange: (checked: boolean) => void;
}> = ({ label, checked, onChange }) => (
  <label className="flex items-center justify-between p-2 rounded-lg hover:bg-neutral-50 cursor-pointer border border-neutral-200/70 transition select-none bg-white">
    <span className="text-xs font-medium text-neutral-800">{label}</span>
    <input
      type="checkbox"
      checked={checked}
      onChange={(e) => onChange(e.target.checked)}
      className="w-4 h-4 rounded text-blue-600 border-neutral-300 focus:ring-blue-500 cursor-pointer"
    />
  </label>
);

export const InvoiceDesignerView: React.FC<InvoiceDesignerViewProps> = ({
  settings,
  onSettingsUpdated,
}) => {
  const { isSuperAdmin } = useAuth();

  // Custom Templates Management state
  const [templates, setTemplates] = useState<CustomInvoiceTemplate[]>(() =>
    resolveTemplates(settings.customTemplates)
  );

  const [activeTemplateId, setActiveTemplateId] = useState<string>(() => {
    if (
      settings.activeTemplateId &&
      settings.customTemplates?.some((t) => t.id === settings.activeTemplateId)
    ) {
      return settings.activeTemplateId;
    }
    const initial = resolveTemplates(settings.customTemplates);
    const def = initial.find((t) => t.isDefault) || initial[0];
    return def?.id || 'tpl_security_service';
  });

  // Current template resolution
  const currentTemplate = useMemo(() => {
    return (
      templates.find((t) => t.id === activeTemplateId) ||
      templates[0] ||
      DEFAULT_CUSTOM_TEMPLATES[0]
    );
  }, [templates, activeTemplateId]);

  // Central strongly-typed Design State initialized safely
  const [design, setDesign] = useState<InvoiceDesignSettings>(() => {
    const initialTemplates = resolveTemplates(settings.customTemplates);
    const activeTpl =
      initialTemplates.find((t) => t.id === settings.activeTemplateId) ||
      initialTemplates.find((t) => t.isDefault) ||
      initialTemplates[0];
    return mergeDesignSettings(activeTpl?.design || settings.invoiceDesign);
  });

  // Undo / Redo history stacks
  const [history, setHistory] = useState<InvoiceDesignSettings[]>([
    mergeDesignSettings(settings.invoiceDesign),
  ]);
  const [historyIndex, setHistoryIndex] = useState<number>(0);

  // Preview options
  const [previewZoom, setPreviewZoom] = useState<number>(0.85);
  const [isFitMode, setIsFitMode] = useState<boolean>(true);
  const [realInvoices, setRealInvoices] = useState<Invoice[]>([]);
  const [selectedRealInvoiceId, setSelectedRealInvoiceId] = useState<string>('');
  const [showGuides, setShowGuides] = useState<boolean>(false);
  const [message, setMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  // ON-DEMAND OVERLAY DRAWERS (ONLY OPEN WHEN EXPLICITLY CLICKED)
  const [layoutOpen, setLayoutOpen] = useState<boolean>(false);
  const [insertOpen, setInsertOpen] = useState<boolean>(false);
  const [typographyOpen, setTypographyOpen] = useState<boolean>(false);

  // Active Click-to-Edit element in Preview (null = full workspace, no sidebar)
  const [selectedElement, setSelectedElement] = useState<DesignerElement | null>(null);

  // Template Modals & Dropdown State
  const [templateDropdownOpen, setTemplateDropdownOpen] = useState<boolean>(false);
  const [manageTemplatesOpen, setManageTemplatesOpen] = useState<boolean>(false);
  const [saveAsNewModalOpen, setSaveAsNewModalOpen] = useState<boolean>(false);
  const [newTemplateForm, setNewTemplateForm] = useState({
    name: '',
    category: 'Service',
    targetServiceOrClient: '',
    description: '',
    isDefault: false,
  });
  const [resetConfirmOpen, setResetConfirmOpen] = useState<boolean>(false);

  // Save / Dirty state
  const [saving, setSaving] = useState<boolean>(false);
  const [saveSuccess, setSaveSuccess] = useState<boolean>(false);
  const [isDirty, setIsDirty] = useState<boolean>(false);

  // Auto-dismiss toast notifications after ~3.2 seconds
  useEffect(() => {
    if (message) {
      const timer = setTimeout(() => {
        setMessage(null);
      }, 3200);
      return () => clearTimeout(timer);
    }
  }, [message]);

  // Sync external changes safely via deep merge
  useEffect(() => {
    if (settings.customTemplates && settings.customTemplates.length > 0) {
      setTemplates(settings.customTemplates);
    }
  }, [settings.customTemplates]);

  const [realPayments, setRealPayments] = useState<Payment[]>([]);

  // Load real invoices & payments from existing application data source
  useEffect(() => {
    const unsubInvoices = subscribeToInvoices((invs) => {
      setRealInvoices(invs);
      if (invs.length > 0) {
        setSelectedRealInvoiceId((prev) => prev || invs[0].id);
      }
    });
    const unsubPayments = subscribeToPayments((pmts) => {
      setRealPayments(pmts);
    });
    return () => {
      unsubInvoices();
      unsubPayments();
    };
  }, []);

  // Automatically resolve the latest invoice from the real invoice data source
  const latestInvoice = useMemo(() => {
    if (!realInvoices || realInvoices.length === 0) return null;
    return (
      [...realInvoices].sort((a, b) => {
        const timeA = new Date(a.createdAt || a.date || 0).getTime();
        const timeB = new Date(b.createdAt || b.date || 0).getTime();
        return timeB - timeA;
      })[0] || realInvoices[0]
    );
  }, [realInvoices]);

  const activeRealInvoice = useMemo(
    () => latestInvoice || realInvoices.find((i) => i.id === selectedRealInvoiceId) || null,
    [latestInvoice, realInvoices, selectedRealInvoiceId]
  );

  // Update design wrapper that marks dirty and pushes to undo stack
  const updateDesign = useCallback(
    (updater: (prev: InvoiceDesignSettings) => InvoiceDesignSettings) => {
      setDesign((prev) => {
        const next = updater(prev);
        setHistory((hist) => [...hist.slice(0, historyIndex + 1), next]);
        setHistoryIndex((idx) => idx + 1);
        setIsDirty(true);
        return next;
      });
    },
    [historyIndex]
  );

  // Undo Handler
  const handleUndo = useCallback(() => {
    if (historyIndex > 0) {
      const newIdx = historyIndex - 1;
      setHistoryIndex(newIdx);
      setDesign(history[newIdx]);
      setIsDirty(true);
    }
  }, [history, historyIndex]);

  // Redo Handler
  const handleRedo = useCallback(() => {
    if (historyIndex < history.length - 1) {
      const newIdx = historyIndex + 1;
      setHistoryIndex(newIdx);
      setDesign(history[newIdx]);
      setIsDirty(true);
    }
  }, [history, historyIndex]);

  // Switch between custom templates
  const handleSelectTemplate = (templateId: string) => {
    const target = templates.find((t) => t.id === templateId);
    if (!target) return;
    setActiveTemplateId(templateId);
    const merged = mergeDesignSettings(target.design);
    setDesign(merged);
    setHistory((hist) => [...hist.slice(0, historyIndex + 1), merged]);
    setHistoryIndex((idx) => idx + 1);
    setIsDirty(false);
    setMessage({
      type: 'success',
      text: `Loaded "${target.name}" (${target.category || 'Template'})`,
    });
  };

  // Save changes to Firestore (updates current template & system settings)
  const handleSaveDesign = async () => {
    setSaving(true);
    setMessage(null);

    // Validation
    if (
      design.page.margins.top < 0 ||
      design.page.margins.bottom < 0 ||
      design.page.margins.left < 0 ||
      design.page.margins.right < 0
    ) {
      setMessage({ type: 'error', text: 'Page margins must be positive numbers.' });
      setSaving(false);
      return;
    }

    try {
      const sanitizedDesign = cleanDataForFirestore(design);

      // Update the active template's design in the templates list
      const updatedTemplates = templates.map((t) =>
        t.id === activeTemplateId ? { ...t, design, updatedAt: new Date().toISOString() } : t
      );
      setTemplates(updatedTemplates);

      const sanitizedTemplates = cleanDataForFirestore(updatedTemplates);

      await updateBusinessSettings({
        invoiceDesign: sanitizedDesign,
        customTemplates: sanitizedTemplates,
        activeTemplateId,
      });

      setSaveSuccess(true);
      setIsDirty(false);
      setMessage({
        type: 'success',
        text: `Template "${currentTemplate.name}" saved successfully! Applied across all previews and PDF exports.`,
      });
      if (onSettingsUpdated) {
        onSettingsUpdated({
          ...settings,
          invoiceDesign: design,
          customTemplates: updatedTemplates,
          activeTemplateId,
        });
      }
      setTimeout(() => setSaveSuccess(false), 4000);
    } catch (err: any) {
      console.error('Error saving invoice design settings:', err);
      setMessage({ type: 'error', text: err?.message || 'Failed to save invoice design settings.' });
    } finally {
      setSaving(false);
    }
  };

  // Save As New Custom Template
  const handleCreateNewTemplate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTemplateForm.name.trim()) {
      setMessage({ type: 'error', text: 'Template name is required.' });
      return;
    }

    const newId = `tpl_${Date.now()}`;
    const newTemplate: CustomInvoiceTemplate = {
      id: newId,
      name: newTemplateForm.name.trim(),
      category: newTemplateForm.category || 'Service',
      targetServiceOrClient: newTemplateForm.targetServiceOrClient.trim() || undefined,
      description: newTemplateForm.description.trim() || undefined,
      design,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      isDefault: newTemplateForm.isDefault,
    };

    let updatedTemplates = [...templates];
    if (newTemplateForm.isDefault) {
      updatedTemplates = updatedTemplates.map((t) => ({ ...t, isDefault: false }));
    }
    updatedTemplates.push(newTemplate);

    setTemplates(updatedTemplates);
    setActiveTemplateId(newId);
    setSaveAsNewModalOpen(false);
    setNewTemplateForm({
      name: '',
      category: 'Service',
      targetServiceOrClient: '',
      description: '',
      isDefault: false,
    });

    try {
      await updateBusinessSettings({
        customTemplates: cleanDataForFirestore(updatedTemplates),
        activeTemplateId: newId,
        ...(newTemplateForm.isDefault ? { invoiceDesign: cleanDataForFirestore(design) } : {}),
      });
      setIsDirty(false);
      setMessage({
        type: 'success',
        text: `Created new template "${newTemplate.name}" for ${
          newTemplate.targetServiceOrClient || newTemplate.category
        }!`,
      });
      if (onSettingsUpdated) {
        onSettingsUpdated({
          ...settings,
          customTemplates: updatedTemplates,
          activeTemplateId: newId,
          ...(newTemplateForm.isDefault ? { invoiceDesign: design } : {}),
        });
      }
    } catch (err: any) {
      console.error('Error creating template:', err);
      setMessage({ type: 'error', text: 'Failed to save new template.' });
    }
  };

  // Duplicate an existing template
  const handleDuplicateTemplate = async (templateId: string) => {
    const original = templates.find((t) => t.id === templateId);
    if (!original) return;
    const newId = `tpl_${Date.now()}`;
    const copy: CustomInvoiceTemplate = {
      ...original,
      id: newId,
      name: `${original.name} (Copy)`,
      isDefault: false,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    const updated = [...templates, copy];
    setTemplates(updated);
    try {
      await updateBusinessSettings({ customTemplates: cleanDataForFirestore(updated) });
      setMessage({ type: 'success', text: `Duplicated "${original.name}".` });
      if (onSettingsUpdated) {
        onSettingsUpdated({ ...settings, customTemplates: updated });
      }
    } catch (err) {
      console.error(err);
    }
  };

  // Set a template as system default
  const handleSetDefaultTemplate = async (templateId: string) => {
    const target = templates.find((t) => t.id === templateId);
    if (!target) return;
    const updated = templates.map((t) => ({
      ...t,
      isDefault: t.id === templateId,
    }));
    setTemplates(updated);
    try {
      await updateBusinessSettings({
        customTemplates: cleanDataForFirestore(updated),
        activeTemplateId: templateId,
        invoiceDesign: cleanDataForFirestore(target.design),
      });
      setMessage({
        type: 'success',
        text: `"${target.name}" is now the default template for all invoices and PDF exports.`,
      });
      if (onSettingsUpdated) {
        onSettingsUpdated({
          ...settings,
          customTemplates: updated,
          activeTemplateId: templateId,
          invoiceDesign: target.design,
        });
      }
    } catch (err) {
      console.error(err);
    }
  };

  // Delete a template
  const handleDeleteTemplate = async (templateId: string) => {
    if (templates.length <= 1) {
      setMessage({ type: 'error', text: 'Cannot delete the only remaining template.' });
      return;
    }
    const target = templates.find((t) => t.id === templateId);
    const updated = templates.filter((t) => t.id !== templateId);
    let nextActiveId = activeTemplateId;
    if (activeTemplateId === templateId) {
      nextActiveId = updated[0].id;
      setDesign(updated[0].design);
    }
    setTemplates(updated);
    setActiveTemplateId(nextActiveId);
    try {
      await updateBusinessSettings({
        customTemplates: cleanDataForFirestore(updated),
        activeTemplateId: nextActiveId,
      });
      setMessage({ type: 'success', text: `Deleted template "${target?.name || ''}".` });
      if (onSettingsUpdated) {
        onSettingsUpdated({
          ...settings,
          customTemplates: updated,
          activeTemplateId: nextActiveId,
        });
      }
    } catch (err) {
      console.error(err);
    }
  };

  // Reset to Default (Style #7 Clean & Classic)
  const handleResetToDefault = () => {
    setDesign(DEFAULT_INVOICE_DESIGN);
    setHistory((hist) => [...hist.slice(0, historyIndex + 1), DEFAULT_INVOICE_DESIGN]);
    setHistoryIndex((idx) => idx + 1);
    setIsDirty(true);
    setResetConfirmOpen(false);
    setMessage({
      type: 'success',
      text: 'Reset to established Design #7 (Professional / Clean & Classic). Click "Save" to persist.',
    });
  };

  // Preset Selection: applies only styling parameters without touching business data
  const handleApplyPreset = (preset: PresetCard) => {
    updateDesign((prev) => ({
      ...prev,
      presetName: preset.id,
      colors: {
        ...prev.colors,
        primary: preset.primaryColor,
        secondary: preset.secondaryColor,
        accent: preset.accentColor,
        headerBackground: preset.primaryColor,
        tableHeaderBackground: preset.secondaryColor,
        footerBackground: preset.primaryColor,
        footerAccent: preset.accentColor,
        grandTotalBackground: preset.secondaryColor,
      },
      typography: {
        ...prev.typography,
        fontFamily: preset.fontFamily,
        headingFontFamily: preset.headingFontFamily,
      },
      shapes: {
        ...prev.shapes,
        topLeft: {
          ...prev.shapes.topLeft,
          fillColor: preset.primaryColor,
          accentColor: preset.accentColor,
        },
        topRight: {
          ...prev.shapes.topRight,
          fillColor: preset.primaryColor,
          accentColor: preset.accentColor,
        },
        goldAccent: {
          ...prev.shapes.goldAccent,
          fillColor: preset.accentColor,
          accentColor: preset.accentColor,
        },
        bottomLeft: {
          ...prev.shapes.bottomLeft,
          fillColor: preset.primaryColor,
          accentColor: preset.accentColor,
        },
        bottomRight: {
          ...prev.shapes.bottomRight,
          fillColor: preset.primaryColor,
          accentColor: preset.accentColor,
        },
      },
      company: {
        ...prev.company,
        sloganColor: preset.secondaryColor,
      },
    }));
    setMessage({
      type: 'success',
      text: `Applied "${preset.name}" preset styling.`,
    });
  };

  // Global Keyboard Shortcuts (Ctrl+Z, Ctrl+Y, Ctrl+S, Esc)
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        if (layoutOpen) setLayoutOpen(false);
        else if (insertOpen) setInsertOpen(false);
        else if (typographyOpen) setTypographyOpen(false);
        else if (templateDropdownOpen) setTemplateDropdownOpen(false);
        else if (selectedElement) setSelectedElement(null);
      } else if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'z') {
        if (e.shiftKey) {
          e.preventDefault();
          handleRedo();
        } else {
          e.preventDefault();
          handleUndo();
        }
      } else if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'y') {
        e.preventDefault();
        handleRedo();
      } else if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 's') {
        e.preventDefault();
        handleSaveDesign();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [handleUndo, handleRedo, handleSaveDesign, layoutOpen, insertOpen, typographyOpen, templateDropdownOpen, selectedElement]);

  // Super Admin security barrier
  if (!isSuperAdmin) {
    return (
      <div className="max-w-2xl mx-auto my-8 p-6 bg-red-50 rounded-2xl border border-red-200 text-red-900 shadow-sm">
        <div className="flex items-center gap-3">
          <ShieldAlert className="w-6 h-6 text-red-600 shrink-0" />
          <div>
            <h2 className="text-lg font-bold">Unauthorized: Super Admin Access Required</h2>
            <p className="text-xs text-red-700 mt-1">
              The Invoice Designer is restricted exclusively to Super Administrators.
            </p>
          </div>
        </div>
      </div>
    );
  }

  const canUndo = historyIndex > 0;
  const canRedo = historyIndex < history.length - 1;

  return (
    <div className="flex flex-col w-full h-full min-h-0 overflow-hidden bg-neutral-100 text-neutral-900 select-none relative">
      {/* ================= 1. SMALL FIXED TOP BAR ================= */}
      {/* Hierarchy: Insert | Layout | Undo | Redo | Reset | Save */}
      <header className="h-11 sm:h-12 bg-white border-b border-neutral-200 px-1.5 xs:px-2.5 sm:px-4 flex items-center justify-between shrink-0 shadow-2xs z-30 gap-1 sm:gap-2 min-w-0 w-full overflow-x-clip sm:overflow-visible">
        {/* Left: Document Title & Sarwan Technology Control & Responsive Status Badge */}
        <div className="flex items-center gap-1.5 sm:gap-2 min-w-0 shrink-0">
          <span className="text-xs font-bold tracking-tight text-neutral-900 hidden lg:inline">
            Invoice Designer
          </span>
          <span className="text-neutral-300 hidden lg:inline">|</span>

          {/* Sarwan Technology Dropdown Control */}
          <div className="relative min-w-0 shrink-0">
            <button
              type="button"
              onClick={() => setTemplateDropdownOpen((prev) => !prev)}
              className="flex items-center justify-center gap-1.5 h-8 w-8 sm:w-auto px-1.5 sm:px-2.5 text-xs font-semibold text-neutral-800 bg-neutral-100 hover:bg-neutral-200/80 border border-neutral-300 rounded-md transition cursor-pointer shrink-0 max-w-[200px]"
              title="Sarwan Technology - Switch or manage invoice templates"
              aria-label="Sarwan Technology"
            >
              <Building className="w-3.5 h-3.5 text-blue-600 shrink-0" />
              <span className="truncate hidden sm:inline">Sarwan Technology</span>
              <ChevronDown className="w-3 h-3 text-neutral-400 shrink-0 hidden sm:inline" />
            </button>

            {/* Template Dropdown Menu */}
            {templateDropdownOpen && (
              <div
                className="absolute left-0 top-full mt-1 w-72 sm:w-80 bg-white border border-neutral-200 rounded-xl shadow-xl z-50 py-1.5 animate-in fade-in zoom-in-95 duration-100 text-xs"
                onClick={(e) => e.stopPropagation()}
              >
                <div className="px-3 py-1.5 border-b border-neutral-100 flex items-center justify-between text-[11px] text-neutral-500 font-semibold uppercase">
                  <span>Custom Templates ({templates.length})</span>
                  <button
                    type="button"
                    onClick={() => {
                      setTemplateDropdownOpen(false);
                      setManageTemplatesOpen(true);
                    }}
                    className="text-blue-600 hover:text-blue-800 lowercase font-medium hover:underline cursor-pointer"
                  >
                    manage all
                  </button>
                </div>

                <div className="max-h-60 overflow-y-auto py-1">
                  {templates.map((tpl) => (
                    <button
                      key={tpl.id}
                      type="button"
                      onClick={() => {
                        handleSelectTemplate(tpl.id);
                        setTemplateDropdownOpen(false);
                      }}
                      className={`w-full px-3 py-1.5 text-left flex items-start justify-between gap-2 hover:bg-neutral-50 transition cursor-pointer ${
                        tpl.id === activeTemplateId ? 'bg-blue-50/70 border-l-2 border-blue-600' : ''
                      }`}
                    >
                      <div className="min-w-0 flex-1">
                        <div className="flex items-center gap-1.5">
                          <span
                            className={`font-semibold truncate ${
                              tpl.id === activeTemplateId ? 'text-blue-900' : 'text-neutral-800'
                            }`}
                          >
                            {tpl.name}
                          </span>
                          {tpl.isDefault && (
                            <span className="text-[9px] bg-amber-100 text-amber-800 px-1 py-0.2 rounded font-bold uppercase shrink-0">
                              Default
                            </span>
                          )}
                        </div>
                        {tpl.targetServiceOrClient && (
                          <p className="text-[10px] text-neutral-500 truncate mt-0.5">
                            {tpl.targetServiceOrClient}
                          </p>
                        )}
                      </div>
                      <span className="text-[10px] text-neutral-400 bg-neutral-100 px-1.5 py-0.5 rounded shrink-0">
                        {tpl.category}
                      </span>
                    </button>
                  ))}
                </div>

                <div className="p-2 border-t border-neutral-100 bg-neutral-50 flex items-center justify-between gap-2">
                  <button
                    type="button"
                    onClick={() => {
                      setTemplateDropdownOpen(false);
                      setSaveAsNewModalOpen(true);
                    }}
                    className="flex-1 flex items-center justify-center gap-1 px-2 py-1 text-xs font-semibold text-blue-700 bg-blue-50 hover:bg-blue-100 border border-blue-200 rounded-md transition cursor-pointer"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>Save As New...</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setTemplateDropdownOpen(false);
                      setManageTemplatesOpen(true);
                    }}
                    className="flex items-center justify-center gap-1 px-2 py-1 text-xs font-medium text-neutral-700 bg-white hover:bg-neutral-100 border border-neutral-200 rounded-md transition cursor-pointer"
                  >
                    <Settings className="w-3.5 h-3.5" />
                    <span>Manage</span>
                  </button>
                </div>
              </div>
            )}
          </div>

          {/* Responsive Unsaved / Saved Badge */}
          {isDirty ? (
            <span
              className="inline-flex items-center justify-center gap-1 text-[11px] font-medium text-amber-700 bg-amber-50 border border-amber-200 px-1.5 sm:px-2 py-0.5 rounded-full shrink-0"
              title="Unsaved changes - click Save to apply"
              aria-label="Design has unsaved changes"
            >
              <span className="w-2 h-2 rounded-full bg-amber-500 animate-pulse shrink-0" aria-hidden="true" />
              <span className="hidden sm:inline">Unsaved</span>
            </span>
          ) : (
            <span
              className="inline-flex items-center justify-center gap-1 text-[11px] font-medium text-emerald-700 bg-emerald-50 border border-emerald-200 px-1.5 sm:px-2 py-0.5 rounded-full shrink-0"
              title="All design changes are saved"
              aria-label="All design changes are saved"
            >
              <CheckCircle2 className="w-3 h-3 text-emerald-600 shrink-0" aria-hidden="true" />
              <span className="hidden sm:inline">Saved</span>
            </span>
          )}
        </div>

        {/* Center: Insert & Layout on-demand triggers, Typography & Zoom */}
        <div className="flex items-center gap-1 sm:gap-1.5 md:gap-2 shrink-0">
          {/* Insert / Field Manager on demand (always icon only) */}
          <button
            type="button"
            id="insert"
            onClick={() => {
              setInsertOpen(true);
              setLayoutOpen(false);
              setTypographyOpen(false);
            }}
            aria-label="Insert"
            title="Insert / Field Manager - Show / Hide invoice fields and table columns"
            className={`flex items-center justify-center h-8 w-8 rounded-md border transition cursor-pointer shrink-0 ${
              insertOpen
                ? 'bg-emerald-600 text-white border-emerald-700 shadow-2xs'
                : 'text-neutral-700 hover:text-emerald-700 bg-neutral-50 hover:bg-emerald-50 border-neutral-300'
            }`}
          >
            <PlusSquare className="w-4 h-4 shrink-0" />
          </button>

          {/* Layout document-level configuration on demand (always icon only) */}
          <button
            type="button"
            id="layout"
            onClick={() => {
              setLayoutOpen(true);
              setInsertOpen(false);
              setTypographyOpen(false);
            }}
            aria-label="Layout"
            title="Layout - Configure page margins, spacing, and table layout settings"
            className={`flex items-center justify-center h-8 w-8 rounded-md border transition cursor-pointer shrink-0 ${
              layoutOpen
                ? 'bg-blue-600 text-white border-blue-700 shadow-2xs'
                : 'text-neutral-700 hover:text-blue-700 bg-neutral-50 hover:bg-blue-50 border-neutral-300'
            }`}
          >
            <Layout className="w-4 h-4 shrink-0" />
          </button>

          {/* Typography on demand (always icon only) */}
          <button
            type="button"
            id="typography"
            onClick={() => {
              setTypographyOpen((prev) => {
                const next = !prev;
                if (next && selectedElement && !isTextDesignerElement(selectedElement)) {
                  setSelectedElement(null);
                }
                return next;
              });
              setLayoutOpen(false);
              setInsertOpen(false);
            }}
            aria-label="Typography"
            title="Typography - Configure font family, font size, weight, and text styling"
            className={`flex items-center justify-center h-8 w-8 rounded-md border transition cursor-pointer shrink-0 ${
              typographyOpen
                ? 'bg-purple-600 text-white border-purple-700 shadow-2xs'
                : 'text-neutral-700 hover:text-purple-700 bg-neutral-50 hover:bg-purple-50 border-neutral-300'
            }`}
          >
            <Type className="w-4 h-4 shrink-0" />
          </button>

          <span className="w-px h-4 bg-neutral-200 mx-0.5 hidden sm:inline" />

          {/* Responsive Zoom & Fit Controls */}
          <div className="hidden sm:flex items-center gap-1 border border-neutral-200 rounded-md px-1.5 py-0.5 bg-neutral-50">
            <button
              type="button"
              onClick={() => {
                setIsFitMode(false);
                setPreviewZoom((z) => Math.max(0.3, Math.round((z - 0.1) * 100) / 100));
              }}
              className="p-0.5 rounded text-neutral-600 hover:text-neutral-900 hover:bg-white transition cursor-pointer"
              title="Zoom Out"
            >
              <ZoomOut className="w-3.5 h-3.5" />
            </button>
            <span className="w-9 text-[11px] font-mono font-semibold text-center text-neutral-700">
              {Math.round(previewZoom * 100)}%
            </span>
            <button
              type="button"
              onClick={() => {
                setIsFitMode(false);
                setPreviewZoom((z) => Math.min(1.5, Math.round((z + 0.1) * 100) / 100));
              }}
              className="p-0.5 rounded text-neutral-600 hover:text-neutral-900 hover:bg-white transition cursor-pointer"
              title="Zoom In"
            >
              <ZoomIn className="w-3.5 h-3.5" />
            </button>
            <button
              type="button"
              onClick={() => {
                setIsFitMode(false);
                setPreviewZoom(1.0);
              }}
              className="text-[10px] font-medium text-neutral-500 hover:text-neutral-800 px-1 py-0.5 rounded hover:bg-white transition cursor-pointer"
              title="100% Actual Size"
            >
              100%
            </button>
            <button
              type="button"
              onClick={() => setIsFitMode(true)}
              className={`text-[10px] font-semibold px-1.5 py-0.5 rounded transition cursor-pointer ${
                isFitMode
                  ? 'bg-blue-600 text-white shadow-2xs'
                  : 'text-neutral-600 hover:text-neutral-900 hover:bg-white'
              }`}
              title="Fit to Screen (Responsive Auto-Fit)"
            >
              Fit
            </button>
          </div>
        </div>

        {/* Right: Undo, Redo, Reset, Save */}
        <div className="flex items-center gap-1 sm:gap-1.5 shrink-0">
          {/* Undo */}
          <button
            type="button"
            onClick={handleUndo}
            disabled={!canUndo}
            aria-label="Undo"
            className="flex items-center justify-center h-8 w-8 rounded-md text-neutral-600 hover:text-neutral-900 hover:bg-neutral-100 disabled:opacity-30 disabled:hover:bg-transparent transition cursor-pointer shrink-0"
            title="Undo (Ctrl+Z)"
          >
            <Undo2 className="w-4 h-4 shrink-0" />
          </button>

          {/* Redo */}
          <button
            type="button"
            onClick={handleRedo}
            disabled={!canRedo}
            aria-label="Redo"
            className="flex items-center justify-center h-8 w-8 rounded-md text-neutral-600 hover:text-neutral-900 hover:bg-neutral-100 disabled:opacity-30 disabled:hover:bg-transparent transition cursor-pointer shrink-0"
            title="Redo (Ctrl+Y)"
          >
            <Redo2 className="w-4 h-4 shrink-0" />
          </button>

          <span className="w-px h-4 bg-neutral-200 mx-0.5 hidden xs:inline" />

          {/* Reset */}
          <button
            type="button"
            onClick={() => setResetConfirmOpen(true)}
            aria-label="Reset"
            className="flex items-center justify-center gap-1 h-8 w-8 xs:h-8.5 xs:w-8.5 md:w-auto md:h-8 md:px-2 text-xs font-medium text-neutral-700 hover:text-neutral-900 hover:bg-neutral-100 rounded-md border border-neutral-200 transition cursor-pointer shrink-0"
            title="Restore Design #7 Defaults"
          >
            <RotateCcw className="w-3.5 h-3.5 text-neutral-500 shrink-0" />
            <span className="hidden md:inline">Reset</span>
          </button>

          {/* Save Button */}
          <button
            type="button"
            onClick={handleSaveDesign}
            disabled={saving}
            aria-label="Save"
            className="flex items-center justify-center gap-1.5 h-8 w-8 xs:h-8.5 xs:w-8.5 md:w-auto md:h-8 md:px-3 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 active:bg-blue-800 rounded-md shadow-2xs transition disabled:opacity-50 cursor-pointer shrink-0"
            title="Save changes to active template (Ctrl+S)"
          >
            {saving ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin shrink-0" />
                <span className="hidden md:inline">Saving...</span>
              </>
            ) : saveSuccess ? (
              <>
                <Check className="w-4 h-4 text-emerald-300 shrink-0" />
                <span className="hidden md:inline">Saved!</span>
              </>
            ) : (
              <>
                <Save className="w-4 h-4 text-blue-200 shrink-0" />
                <span className="hidden md:inline">Save</span>
              </>
            )}
          </button>
        </div>
      </header>

      {/* Notifications Banner */}
      {message && (
        <div
          className={`px-4 py-1.5 flex items-center justify-between text-xs animate-in fade-in duration-200 border-b z-30 ${
            message.type === 'success'
              ? 'bg-emerald-50 border-emerald-200 text-emerald-900'
              : 'bg-red-50 border-red-200 text-red-900'
          }`}
        >
          <div className="flex items-center gap-2">
            {message.type === 'success' ? (
              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
            ) : (
              <AlertCircle className="w-3.5 h-3.5 text-red-600 shrink-0" />
            )}
            <span className="font-medium">{message.text}</span>
          </div>
          <button
            type="button"
            onClick={() => setMessage(null)}
            className="text-neutral-400 hover:text-neutral-700 ml-4 font-bold"
          >
            ✕
          </button>
        </div>
      )}

      {/* ================= 1b. TYPOGRAPHY CONTROLS ================= */}
      {typographyOpen && (
        <>
          {/* Desktop & Tablet: Sleek horizontal toolbar ribbon right beneath top bar */}
          <div className="hidden sm:block bg-white border-b border-neutral-200 px-3 sm:px-4 py-1.5 shadow-2xs z-30 shrink-0 animate-in slide-in-from-top-1 duration-150">
            <TypographyControls
              selectedElement={selectedElement}
              design={design}
              updateDesign={updateDesign}
              onSelectElement={(el) => setSelectedElement(el)}
              onClose={() => setTypographyOpen(false)}
              layout="toolbar"
              showLabels={true}
              showFormattingButtons={true}
              className="w-full justify-between"
            />
          </div>

          {/* Mobile slide-up drawer (screens < 640px) */}
          <div
            className="sm:hidden fixed inset-0 z-50 bg-black/40 backdrop-blur-xs flex items-end justify-center animate-in fade-in duration-150"
            onClick={() => setTypographyOpen(false)}
          >
            <div
              className="bg-white w-full max-h-[85vh] rounded-t-2xl shadow-2xl flex flex-col border-t border-neutral-200 animate-in slide-in-from-bottom duration-200 text-neutral-800 p-4"
              onClick={(e) => e.stopPropagation()}
            >
              <div className="flex items-center justify-between pb-3 border-b border-neutral-200 shrink-0">
                <div className="flex items-center gap-2">
                  <div className="p-1.5 bg-purple-100 text-purple-700 rounded-md">
                    <Type className="w-4 h-4" />
                  </div>
                  <div>
                    <h3 className="text-sm font-bold text-neutral-900">Typography Controls</h3>
                    <p className="text-[10px] text-neutral-500">Configure font family and sizes</p>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => setTypographyOpen(false)}
                  className="p-1.5 text-neutral-400 hover:text-neutral-700 hover:bg-neutral-100 rounded-md cursor-pointer"
                  title="Close Typography Panel"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              <div className="py-2 border-b border-neutral-100 shrink-0">
                <label className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider block mb-1">
                  Target Element
                </label>
                <select
                  value={selectedElement || ''}
                  onChange={(e) => setSelectedElement(e.target.value ? (e.target.value as DesignerElement) : null)}
                  className="w-full px-2 py-1.5 text-xs font-semibold border border-neutral-300 rounded bg-neutral-50 text-neutral-800"
                >
                  <option value="">Default Document Font</option>
                  <optgroup label="Header & Branding">
                    <option value="companyEnglishName">Company English Name</option>
                    <option value="companyPashtoName">Company Pashto Name</option>
                    <option value="companySlogan">Company Slogan</option>
                  </optgroup>
                  <optgroup label="Invoice Information">
                    <option value="invoiceTitle">Invoice Title</option>
                    <option value="billNumber">Bill Number</option>
                    <option value="invoiceDate">Invoice Date</option>
                    <option value="dueDate">Due Date</option>
                    <option value="collector">Assigned Collector</option>
                  </optgroup>
                  <optgroup label="Customer Details">
                    <option value="customerName">Customer Name</option>
                    <option value="customerPhone">Customer Phone</option>
                    <option value="customerAddress">Customer Address</option>
                    <option value="customerEmail">Customer Email</option>
                    <option value="customerCompany">Customer Company</option>
                    <option value="customerId">Customer ID</option>
                  </optgroup>
                  <optgroup label="Items Table">
                    <option value="tableHeader">Table Header</option>
                    <option value="tableBody">Table Body</option>
                    <option value="tableColumnSerial">Column: Serial (#)</option>
                    <option value="tableColumnDescription">Column: Description</option>
                    <option value="tableColumnQuantity">Column: Quantity</option>
                    <option value="tableColumnUnit">Column: Unit</option>
                    <option value="tableColumnUnitPrice">Column: Unit Price</option>
                    <option value="tableColumnDiscount">Column: Discount</option>
                    <option value="tableColumnTax">Column: Tax</option>
                    <option value="tableColumnTotal">Column: Total</option>
                  </optgroup>
                  <optgroup label="Payment & Totals">
                    <option value="paymentInfo">Payment Details</option>
                    <option value="subtotal">Subtotal Row</option>
                    <option value="discountTotal">Discount Row</option>
                    <option value="taxTotal">Tax Row</option>
                    <option value="grandTotal">Grand Total Banner</option>
                    <option value="totalPaid">Total Paid Row</option>
                    <option value="remainingTotal">Remaining Total Row</option>
                  </optgroup>
                  <optgroup label="Closing & Signatures">
                    <option value="notes">Notes & Terms</option>
                    <option value="signatures">Signatures (General)</option>
                    <option value="signatureCustomer">Customer Signature</option>
                    <option value="signatureAuthorized">Authorized Signature</option>
                    <option value="footer">Footer (General)</option>
                    <option value="footerThankYou">Footer Thank You</option>
                    <option value="footerContacts">Footer Contacts</option>
                    <option value="pageNumber">Page Number</option>
                  </optgroup>
                </select>
              </div>

              <div className="flex-1 overflow-y-auto pt-3">
                <TypographyControls
                  selectedElement={selectedElement}
                  design={design}
                  updateDesign={updateDesign}
                  onSelectElement={(el) => setSelectedElement(el)}
                  layout="vertical"
                  showLabels={true}
                  showFormattingButtons={true}
                />
              </div>

              <div className="pt-3 border-t border-neutral-200 mt-2 shrink-0">
                <button
                  type="button"
                  onClick={() => setTypographyOpen(false)}
                  className="w-full py-2 bg-blue-600 text-white rounded-lg font-semibold text-xs text-center cursor-pointer"
                >
                  Done
                </button>
              </div>
            </div>
          </div>
        </>
      )}

      {/* ================= 2. MAIN SPACIOUS WORKSPACE (A4 CANVAS PRIMARY FOCUS) ================= */}
      <div className="flex-1 min-h-0 w-full overflow-hidden flex flex-row relative">
        <main className="flex-1 min-h-0 h-full w-full overflow-hidden flex flex-col bg-neutral-200/80 relative items-center justify-center">
          {/* Subtle click-to-edit indicator (unobtrusive, floating in bottom corner without consuming row) */}
          <div className="absolute bottom-2.5 left-3 pointer-events-none text-[10px] text-neutral-400 font-medium select-none bg-white/80 backdrop-blur-xs px-2 py-0.5 rounded shadow-2xs z-10 hidden sm:block">
            Click any element on the A4 page to edit its properties
          </div>

          {/* Full A4 Invoice Preview */}
          <div className="flex-1 min-h-0 w-full h-full overflow-hidden flex flex-col relative">
            <InvoiceTemplatePreview
              design={design}
              invoice={latestInvoice}
              payments={realPayments}
              settings={settings}
              zoom={previewZoom}
              onZoomChange={setPreviewZoom}
              isFitMode={isFitMode}
              onFitModeChange={setIsFitMode}
              showControls={false}
              selectedElement={selectedElement}
              onSelectElement={(el) => {
                setSelectedElement(el);
                if (el) {
                  setLayoutOpen(false);
                  setInsertOpen(false);
                }
              }}
              isInteractive={true}
              className={`flex-1 w-full h-full ${showGuides ? 'ring-2 ring-blue-400/40' : ''}`}
            />
          </div>
        </main>

        {/* ================= 3. CONTEXTUAL PROPERTIES PANEL (ONLY WHEN AN ELEMENT IS CLICKED) ================= */}
        {selectedElement && (
          <>
            {/* Mobile backdrop to easily tap outside and dismiss on small screens */}
            <div
              className="fixed inset-0 bg-black/25 backdrop-blur-2xs z-35 sm:hidden"
              onClick={() => setSelectedElement(null)}
            />
            <aside className="w-full max-w-[340px] sm:w-96 sm:max-w-none bg-white border-l border-neutral-300 shadow-2xl flex flex-col h-full z-40 absolute right-0 top-0 bottom-0 animate-in slide-in-from-right duration-150 overflow-hidden">
              <div className="flex-1 overflow-y-auto">
                <ContextualToolbar
                  selectedElement={selectedElement}
                  design={design}
                  updateDesign={updateDesign}
                  onClose={() => setSelectedElement(null)}
                  isSidebar={true}
                  placement="sidebar"
                />
              </div>
            </aside>
          </>
        )}
      </div>

      {/* ================= 4. DOCUMENT LAYOUT DRAWER ================= */}
      <DocumentLayoutDrawer
        isOpen={layoutOpen}
        onClose={() => setLayoutOpen(false)}
        design={design}
        updateDesign={updateDesign}
        showGuides={showGuides}
        onToggleGuides={setShowGuides}
      />

      {/* ================= 5. INSERT / FIELD MANAGER DRAWER ================= */}
      <InsertFieldManagerDrawer
        isOpen={insertOpen}
        onClose={() => setInsertOpen(false)}
        design={design}
        updateDesign={updateDesign}
        selectedElement={selectedElement}
        onSelectElement={setSelectedElement}
      />

      {/* ================= 6. SAVE AS NEW TEMPLATE MODAL ================= */}
      {saveAsNewModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl animate-in zoom-in-95 duration-200 border border-neutral-200">
            <div className="flex items-center justify-between pb-3 border-b border-neutral-200">
              <div className="flex items-center gap-2.5">
                <div className="p-2 bg-blue-100 text-blue-700 rounded-lg">
                  <FolderOpen className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base font-bold text-neutral-900">
                    Save As New Custom Template
                  </h3>
                  <p className="text-xs text-neutral-500">
                    Create a dedicated layout tailored for specific services or clients
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setSaveAsNewModalOpen(false)}
                className="p-1 rounded text-neutral-400 hover:text-neutral-700 cursor-pointer"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleCreateNewTemplate} className="space-y-4 pt-4 text-xs">
              <div>
                <label className="font-semibold text-neutral-700 block mb-1">
                  Template Name *
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. CCTV Installation Service, Corporate VIP, Retail Walk-in"
                  value={newTemplateForm.name}
                  onChange={(e) =>
                    setNewTemplateForm({ ...newTemplateForm, name: e.target.value })
                  }
                  className="w-full text-xs h-8 px-2.5 border border-neutral-300 rounded-lg focus:outline-none focus:ring-1 focus:ring-blue-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="font-semibold text-neutral-700 block mb-1">Category</label>
                  <select
                    value={newTemplateForm.category}
                    onChange={(e) =>
                      setNewTemplateForm({ ...newTemplateForm, category: e.target.value })
                    }
                    className="w-full text-xs h-8 px-2 border border-neutral-300 rounded-lg bg-white focus:outline-none focus:ring-1 focus:ring-blue-500"
                  >
                    <option value="Service">Service</option>
                    <option value="Retail">Retail</option>
                    <option value="Corporate">Corporate</option>
                    <option value="Maintenance">Maintenance</option>
                    <option value="Wholesale">Wholesale</option>
                    <option value="General">General</option>
                  </select>
                </div>

                <div>
                  <label className="font-semibold text-neutral-700 block mb-1">
                    Target Client / Service
                  </label>
                  <input
                    type="text"
                    placeholder="e.g. Camera Systems, VIPs"
                    value={newTemplateForm.targetServiceOrClient}
                    onChange={(e) =>
                      setNewTemplateForm({
                        ...newTemplateForm,
                        targetServiceOrClient: e.target.value,
                      })
                    }
                    className="w-full text-xs h-8 px-2.5 border border-neutral-300 rounded-lg focus:outline-none focus:ring-1 focus:ring-blue-500"
                  />
                </div>
              </div>

              <div>
                <label className="font-semibold text-neutral-700 block mb-1">
                  Description (Optional)
                </label>
                <textarea
                  rows={2}
                  placeholder="e.g. Features full technical itemization and dual manager signatures."
                  value={newTemplateForm.description}
                  onChange={(e) =>
                    setNewTemplateForm({ ...newTemplateForm, description: e.target.value })
                  }
                  className="w-full text-xs p-2 border border-neutral-300 rounded-lg focus:outline-none focus:ring-1 focus:ring-blue-500"
                />
              </div>

              <label className="flex items-center gap-2 p-2 bg-neutral-50 rounded-lg border border-neutral-200 cursor-pointer">
                <input
                  type="checkbox"
                  checked={newTemplateForm.isDefault}
                  onChange={(e) =>
                    setNewTemplateForm({ ...newTemplateForm, isDefault: e.target.checked })
                  }
                  className="w-4 h-4 rounded text-blue-600 border-neutral-300 focus:ring-blue-500 cursor-pointer"
                />
                <div>
                  <span className="font-semibold text-neutral-800 block text-xs">
                    Set as Default Template
                  </span>
                  <span className="text-[10px] text-neutral-500">
                    Use this template automatically for all regular new invoices and exports
                  </span>
                </div>
              </label>

              <div className="flex justify-end gap-2 pt-2 border-t border-neutral-100">
                <button
                  type="button"
                  onClick={() => setSaveAsNewModalOpen(false)}
                  className="px-3 py-1.5 text-xs font-semibold text-neutral-600 hover:bg-neutral-100 rounded-lg transition cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 text-xs font-bold text-white bg-blue-600 hover:bg-blue-700 rounded-lg shadow-sm transition cursor-pointer"
                >
                  Save Template
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ================= 7. MANAGE TEMPLATES MODAL ================= */}
      {manageTemplatesOpen && (
        <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-2xl w-full max-h-[85vh] flex flex-col shadow-2xl animate-in zoom-in-95 duration-200 border border-neutral-200 overflow-hidden">
            {/* Header */}
            <div className="px-6 py-4 border-b border-neutral-200 flex items-center justify-between bg-neutral-50/80">
              <div className="flex items-center gap-2.5">
                <div className="p-2 bg-blue-100 text-blue-700 rounded-lg">
                  <Settings className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base font-bold text-neutral-900">
                    Manage Custom Invoice Templates
                  </h3>
                  <p className="text-xs text-neutral-500">
                    Switch, duplicate, set default, or organize layouts for various services and clients
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setManageTemplatesOpen(false)}
                className="p-1.5 rounded-lg text-neutral-400 hover:text-neutral-700 hover:bg-neutral-200/60 transition cursor-pointer"
              >
                ✕
              </button>
            </div>

            {/* Body */}
            <div className="p-6 overflow-y-auto space-y-3 flex-1 text-xs">
              {templates.map((tpl) => (
                <div
                  key={tpl.id}
                  className={`p-3.5 rounded-xl border transition flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 ${
                    tpl.id === activeTemplateId
                      ? 'bg-blue-50/60 border-blue-300 ring-1 ring-blue-300'
                      : 'bg-white border-neutral-200 hover:border-neutral-300'
                  }`}
                >
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-neutral-900 text-sm">{tpl.name}</span>
                      <span className="text-[10px] font-semibold text-blue-700 bg-blue-100 px-2 py-0.5 rounded-full">
                        {tpl.category}
                      </span>
                      {tpl.isDefault && (
                        <span className="text-[10px] font-bold text-amber-800 bg-amber-100 border border-amber-300 px-2 py-0.5 rounded-full flex items-center gap-1">
                          <Star className="w-3 h-3 fill-amber-500 text-amber-500" />
                          Default
                        </span>
                      )}
                    </div>
                    {tpl.targetServiceOrClient && (
                      <p className="text-xs text-neutral-600 mt-1">
                        <span className="font-semibold text-neutral-500">Target:</span>{' '}
                        {tpl.targetServiceOrClient}
                      </p>
                    )}
                    {tpl.description && (
                      <p className="text-[11px] text-neutral-500 mt-0.5">{tpl.description}</p>
                    )}
                  </div>

                  {/* Actions */}
                  <div className="flex items-center gap-1.5 shrink-0 self-end sm:self-auto">
                    {tpl.id !== activeTemplateId ? (
                      <button
                        type="button"
                        onClick={() => {
                          handleSelectTemplate(tpl.id);
                          setManageTemplatesOpen(false);
                        }}
                        className="px-2.5 py-1 text-xs font-semibold text-blue-700 bg-blue-50 hover:bg-blue-100 border border-blue-200 rounded-lg transition cursor-pointer"
                      >
                        Load
                      </button>
                    ) : (
                      <span className="px-2.5 py-1 text-xs font-bold text-emerald-700 bg-emerald-50 border border-emerald-200 rounded-lg">
                        Active
                      </span>
                    )}

                    {!tpl.isDefault && (
                      <button
                        type="button"
                        onClick={() => handleSetDefaultTemplate(tpl.id)}
                        className="p-1.5 text-neutral-500 hover:text-amber-600 hover:bg-neutral-100 rounded-lg transition cursor-pointer"
                        title="Set as system default template"
                      >
                        <Star className="w-4 h-4" />
                      </button>
                    )}

                    <button
                      type="button"
                      onClick={() => handleDuplicateTemplate(tpl.id)}
                      className="p-1.5 text-neutral-500 hover:text-neutral-800 hover:bg-neutral-100 rounded-lg transition cursor-pointer"
                      title="Duplicate template"
                    >
                      <Copy className="w-4 h-4" />
                    </button>

                    {templates.length > 1 && (
                      <button
                        type="button"
                        onClick={() => handleDeleteTemplate(tpl.id)}
                        className="p-1.5 text-neutral-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition cursor-pointer"
                        title="Delete template"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    )}
                  </div>
                </div>
              ))}
            </div>

            {/* Footer */}
            <div className="px-6 py-3 border-t border-neutral-200 bg-neutral-50 flex items-center justify-between">
              <button
                type="button"
                onClick={() => {
                  setManageTemplatesOpen(false);
                  setSaveAsNewModalOpen(true);
                }}
                className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-blue-700 bg-blue-100 hover:bg-blue-200 rounded-lg transition cursor-pointer"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Create New Template</span>
              </button>
              <button
                type="button"
                onClick={() => setManageTemplatesOpen(false)}
                className="px-4 py-1.5 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg shadow-sm transition cursor-pointer"
              >
                Done
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ================= 8. RESET CONFIRMATION MODAL ================= */}
      {resetConfirmOpen && (
        <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 space-y-4 shadow-2xl animate-in zoom-in-95 duration-200 border border-neutral-200">
            <div className="flex items-center gap-3">
              <div className="p-3 bg-red-100 text-red-600 rounded-xl">
                <RotateCcw className="w-6 h-6" />
              </div>
              <div>
                <h3 className="text-base font-bold text-neutral-900">
                  Reset Design to Default Format?
                </h3>
                <p className="text-xs text-neutral-500">
                  This will restore our established custom design (Clean &amp; Classic — Design #7).
                </p>
              </div>
            </div>
            <p className="text-xs text-neutral-600 leading-relaxed">
              Your customized colors, margins, logos, and column widths will be restored to our canonical Design #7 format.
              You will still need to click &quot;Save&quot; in the top bar to persist this reset to the database.
            </p>
            <div className="flex justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setResetConfirmOpen(false)}
                className="px-4 py-2 text-xs font-semibold text-neutral-700 bg-neutral-100 hover:bg-neutral-200 rounded-lg transition cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleResetToDefault}
                className="px-4 py-2 text-xs font-bold text-white bg-red-600 hover:bg-red-700 rounded-lg shadow-sm transition cursor-pointer"
              >
                Yes, Reset to Default
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default InvoiceDesignerView;
