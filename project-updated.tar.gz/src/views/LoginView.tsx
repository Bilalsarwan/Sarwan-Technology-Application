import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import {
  ShieldCheck,
  AlertCircle,
  Eye,
  EyeOff,
  Lock,
  User as UserIcon,
  Loader2,
  LogIn,
  ChevronDown,
  ChevronUp,
} from 'lucide-react';
import { BusinessSettings } from '../types';

interface LoginViewProps {
  settings?: BusinessSettings;
}

export const LoginView: React.FC<LoginViewProps> = ({ settings }) => {
  const {
    signInWithGoogle,
    signInWithUsernameAndPassword,
    loading: authLoading,
    error: authError,
    clearError,
  } = useAuth();

  // Primary username/password state
  const [usernameOrEmail, setUsernameOrEmail] = useState<string>('');
  const [password, setPassword] = useState<string>('');
  const [showPassword, setShowPassword] = useState<boolean>(false);
  const [submitting, setSubmitting] = useState<boolean>(false);

  // Google sign-in state
  const [googleSubmitting, setGoogleSubmitting] = useState<boolean>(false);
  const [showGoogleUserIdOption, setShowGoogleUserIdOption] = useState<boolean>(false);
  const [googleUserIdInput, setGoogleUserIdInput] = useState<string>('');

  const [localError, setLocalError] = useState<string | null>(null);

  const displayError = localError || authError;

  /**
   * Primary Username + Password login handler.
   */
  const handleUsernamePasswordLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLocalError(null);
    clearError();

    const cleanUser = usernameOrEmail.trim();
    if (!cleanUser) {
      setLocalError('Please enter your username or registered email.');
      return;
    }
    if (!password) {
      setLocalError('Please enter your password.');
      return;
    }

    setSubmitting(true);
    try {
      await signInWithUsernameAndPassword(cleanUser, password);
    } catch (err: any) {
      setLocalError(err.message || 'Invalid username or password.');
    } finally {
      setSubmitting(false);
    }
  };

  /**
   * Google sign-in handler.
   */
  const handleGoogleSignIn = async () => {
    setLocalError(null);
    clearError();
    setGoogleSubmitting(true);
    try {
      await signInWithGoogle(googleUserIdInput.trim() || undefined);
    } catch (err: any) {
      setLocalError(err.message || 'Google authentication failed.');
    } finally {
      setGoogleSubmitting(false);
    }
  };

  // Fixed path as required by specification: public/assets/branding/SignInDesignLogo/sarwan-technology-logo.png
  const logoUrl = '/assets/branding/SignInDesignLogo/sarwan-technology-logo.png';

  return (
    <div className="min-h-screen w-full flex flex-col justify-center items-center px-5 py-10 sm:px-6 sm:py-16 bg-neutral-50 text-neutral-900 overflow-x-hidden">
      {/* Centered Login Card Container (around 400-430px max-width on desktop) */}
      <div className="w-full max-w-[420px]">
        <div className="bg-white rounded-2xl shadow-sm border border-neutral-200/80 p-6 sm:p-8">
          {/* Card Header: Logo, Heading & Supporting Text */}
          <div className="text-center mb-6">
            <div className="flex justify-center mb-4">
              <div
                className="w-20 h-20 sm:w-24 sm:h-24 bg-white flex items-center justify-center overflow-hidden p-1.5 shrink-0 shadow-xs"
                style={{ borderRadius: '100%', border: 'none' }}
              >
                <img
                  src={logoUrl}
                  alt="Sarwan Technology"
                  className="max-h-full max-w-full object-contain"
                  referrerPolicy="no-referrer"
                  onError={(e) => {
                    const target = e.currentTarget;
                    if (target.src.endsWith('.png')) target.src = '/sarwan-logo.svg';
                  }}
                />
              </div>
            </div>
            <h1 className="text-2xl font-bold text-neutral-900 tracking-tight">
              Sign In
            </h1>
            <p className="text-xs text-neutral-500 mt-1 leading-relaxed">
              Access your Sarwan Technology Billing &amp; Management Portal
            </p>
          </div>

          {/* Error Notice */}
          {displayError && (
            <div className="mb-5 p-3.5 bg-red-50 border border-red-200 text-red-700 text-xs rounded-xl flex items-start gap-2.5">
              <AlertCircle className="w-4 h-4 shrink-0 text-red-500 mt-0.5" />
              <div className="flex-1 font-medium leading-relaxed">{displayError}</div>
              <button
                type="button"
                onClick={() => {
                  setLocalError(null);
                  clearError();
                }}
                className="text-[11px] font-bold text-red-600 hover:text-red-800 cursor-pointer"
              >
                Dismiss
              </button>
            </div>
          )}

          {/* Primary Authentication Form */}
          <form onSubmit={handleUsernamePasswordLogin} className="space-y-4">
            {/* Username or Email Input */}
            <div>
              <label
                htmlFor="usernameOrEmail"
                className="block text-xs font-semibold text-neutral-700 mb-1.5"
              >
                Username or Email
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-neutral-400">
                  <UserIcon className="w-4 h-4" />
                </div>
                <input
                  id="usernameOrEmail"
                  type="text"
                  required
                  autoComplete="username"
                  value={usernameOrEmail}
                  onChange={(e) => {
                    setUsernameOrEmail(e.target.value);
                    if (localError) setLocalError(null);
                  }}
                  placeholder="Enter your username or email"
                  className="w-full h-11 pl-10 pr-3.5 text-xs sm:text-sm bg-neutral-50 border border-neutral-300 rounded-xl focus:outline-none focus:bg-white focus:border-[#F58220] focus:ring-2 focus:ring-[#F58220]/20 transition text-neutral-900 placeholder:text-neutral-400"
                />
              </div>
            </div>

            {/* Password Input */}
            <div>
              <div className="flex items-center justify-between mb-1.5">
                <label
                  htmlFor="loginPassword"
                  className="block text-xs font-semibold text-neutral-700"
                >
                  Password
                </label>
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="text-[11px] text-neutral-500 hover:text-neutral-800 font-medium flex items-center gap-1 cursor-pointer transition"
                >
                  {showPassword ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                  <span>{showPassword ? 'Hide' : 'Show'}</span>
                </button>
              </div>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-neutral-400">
                  <Lock className="w-4 h-4" />
                </div>
                <input
                  id="loginPassword"
                  type={showPassword ? 'text' : 'password'}
                  required
                  autoComplete="current-password"
                  value={password}
                  onChange={(e) => {
                    setPassword(e.target.value);
                    if (localError) setLocalError(null);
                  }}
                  placeholder="Enter your password"
                  className="w-full h-11 pl-10 pr-10 text-xs sm:text-sm bg-neutral-50 border border-neutral-300 rounded-xl focus:outline-none focus:bg-white focus:border-[#F58220] focus:ring-2 focus:ring-[#F58220]/20 transition text-neutral-900 placeholder:text-neutral-400"
                />
              </div>
            </div>

            {/* Primary Sign In Button: [ Sign In icon ] Sign In */}
            <button
              id="signin-submit-btn"
              type="submit"
              disabled={submitting || authLoading}
              className="w-full h-11 px-4 bg-[#F58220] hover:bg-[#d46d15] text-white text-xs sm:text-sm font-bold rounded-xl shadow-xs hover:shadow transition flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed active:scale-[0.99] mt-2"
            >
              {submitting ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  <span>Verifying Credentials...</span>
                </>
              ) : (
                <>
                  <LogIn className="w-4 h-4" />
                  <span>Sign In</span>
                </>
              )}
            </button>
          </form>

          {/* Divider */}
          <div className="relative flex items-center justify-center my-6">
            <div className="border-t border-neutral-200 w-full" />
            <span className="bg-white px-3 text-[11px] text-neutral-400 font-semibold uppercase tracking-wider whitespace-nowrap">
              or
            </span>
            <div className="border-t border-neutral-200 w-full" />
          </div>

          {/* Google Authentication Section */}
          <div className="space-y-3">
            <button
              id="google-signin-btn"
              type="button"
              onClick={handleGoogleSignIn}
              disabled={googleSubmitting || submitting || authLoading}
              className="w-full h-11 px-4 bg-white hover:bg-neutral-50 text-neutral-800 text-xs sm:text-sm font-semibold rounded-xl border border-neutral-300 shadow-xs hover:border-neutral-400 transition flex items-center justify-center gap-2.5 cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed active:scale-[0.99]"
            >
              {googleSubmitting ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin text-neutral-600" />
                  <span>Verifying Google Account...</span>
                </>
              ) : (
                <>
                  <svg className="w-4 h-4 shrink-0" viewBox="0 0 24 24">
                    <path
                      fill="#4285F4"
                      d="M23.745 12.27c0-.7-.06-1.4-.19-2.07H12v4.51h6.6c-.29 1.52-1.14 2.82-2.4 3.68v3.05h3.88c2.27-2.09 3.66-5.17 3.66-9.17z"
                    />
                    <path
                      fill="#34A853"
                      d="M12 24c3.24 0 5.95-1.08 7.93-2.91l-3.88-3.05c-1.08.72-2.45 1.16-4.05 1.16-3.12 0-5.77-2.1-6.72-4.93H1.25v3.15C3.26 21.36 7.33 24 12 24z"
                    />
                    <path
                      fill="#FBBC05"
                      d="M5.28 14.27c-.25-.72-.38-1.49-.38-2.27s.13-1.55.38-2.27V6.58H1.25C.45 8.18 0 9.99 0 12s.45 3.82 1.25 5.42l4.03-3.15z"
                    />
                    <path
                      fill="#EA4335"
                      d="M12 4.75c1.77 0 3.35.61 4.6 1.8l3.42-3.42C17.95 1.19 15.24 0 12 0 7.33 0 3.26 2.64 1.25 6.58l4.03 3.15c.95-2.83 3.6-4.98 6.72-4.98z"
                    />
                  </svg>
                  <span>Sign in with Google</span>
                </>
              )}
            </button>

            {/* Optional User ID link for Google Login verification */}
            <div className="pt-1">
              <button
                type="button"
                onClick={() => setShowGoogleUserIdOption(!showGoogleUserIdOption)}
                className="w-full text-center text-[11px] text-neutral-500 hover:text-neutral-800 font-medium flex items-center justify-center gap-1 cursor-pointer transition"
              >
                <span>Verify specific User ID with Google account</span>
                {showGoogleUserIdOption ? (
                  <ChevronUp className="w-3.5 h-3.5" />
                ) : (
                  <ChevronDown className="w-3.5 h-3.5" />
                )}
              </button>

              {showGoogleUserIdOption && (
                <div className="mt-2.5 p-3.5 bg-neutral-50 rounded-xl border border-neutral-200 text-xs space-y-2 animate-in fade-in duration-150">
                  <label className="block text-[11px] font-semibold text-neutral-700">
                    Application User ID or Username (Optional)
                  </label>
                  <input
                    type="text"
                    value={googleUserIdInput}
                    onChange={(e) => setGoogleUserIdInput(e.target.value)}
                    placeholder="e.g. ST-USR-XXXX or username"
                    className="w-full h-9 px-3 text-xs bg-white border border-neutral-300 rounded-lg focus:outline-none focus:border-[#F58220] focus:ring-1 focus:ring-[#F58220]"
                  />
                  <p className="text-[10px] text-neutral-500 leading-tight">
                    Verifies that the chosen Google email strictly matches this registered User ID record.
                  </p>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Minimal Corporate Security & Copyright Footer */}
        <div className="mt-6 text-center space-y-1.5 text-neutral-400">
          <div className="flex items-center justify-center gap-1.5 text-[11px] text-neutral-500">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
            <span>Encrypted Corporate Session &bull; Role-Based Access</span>
          </div>
          <p className="text-[10px] text-neutral-400">
            &copy; {new Date().getFullYear()} Sarwan Technology. All rights reserved.
          </p>
        </div>
      </div>
    </div>
  );
};
