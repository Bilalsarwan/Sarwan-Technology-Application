import React, { useState, useMemo, useEffect } from 'react';
import { Customer, CustomerStatus, CustomerType, Invoice, Payment, UserProfile, CustomerMigrationSummary } from '../types';
import { calculateCustomerSummary, formatAFN, formatDate } from '../utils/format';
import { useAuth } from '../context/AuthContext';
import { normalizeCustomerStatus, normalizePhone } from '../utils/customerValidation';
import { migrateCustomerIdsInPlace, deleteCustomerSafely } from '../services/db';
import {
  Search,
  UserPlus,
  Users,
  UserCheck,
  UserX,
  ChevronRight,
  Phone,
  Building,
  Eye,
  Pencil,
  Trash2,
  MoreVertical,
  ShieldCheck,
  MapPin,
  ChevronLeft,
  X,
  Filter,
  SlidersHorizontal,
  ArrowUpDown,
  ArrowUp,
  ArrowDown,
  DollarSign,
  Copy,
  Check,
  AlertTriangle,
  Lock,
  PauseCircle,
  CheckCircle2,
  AlertCircle,
  FileText,
  RotateCcw,
} from 'lucide-react';

export type CustomerSortColumn =
  | 'customer_id'
  | 'name'
  | 'company'
  | 'phone'
  | 'type'
  | 'balance'
  | 'status'
  | 'created_at'
  | 'updated_at';

export type CustomerSortDirection = 'asc' | 'desc';

interface CustomersViewProps {
  customers: Customer[];
  invoices: Invoice[];
  payments: Payment[];
  users?: UserProfile[];
  onNewCustomer: () => void;
  onSelectCustomer: (customer: Customer) => void;
  onEditCustomer: (customer: Customer) => void;
  onDeleteCustomer?: (customer: Customer) => Promise<void> | void;
}

export const CustomersView: React.FC<CustomersViewProps> = ({
  customers,
  invoices,
  payments,
  users = [],
  onNewCustomer,
  onSelectCustomer,
  onEditCustomer,
  onDeleteCustomer,
}) => {
  const { userProfile, permissions } = useAuth();
  const isSuperAdmin = userProfile?.role === 'super_admin';

  // Search & Filter State
  const [searchTerm, setSearchTerm] = useState<string>('');
  const [statusFilter, setStatusFilter] = useState<'all' | 'Active' | 'Inactive' | 'Blocked'>('all');
  const [typeFilter, setTypeFilter] = useState<'all' | CustomerType>('all');
  const [financialFilter, setFinancialFilter] = useState<'all' | 'Paid' | 'Outstanding' | 'Overdue'>('all');

  // Collapsible filter section visibility (collapsed by default)
  const [isFilterOpen, setIsFilterOpen] = useState<boolean>(false);

  // Unified Sorting State (Click-to-sort and mobile/filter sync)
  const [sortColumn, setSortColumn] = useState<CustomerSortColumn>('created_at');
  const [sortDirection, setSortDirection] = useState<CustomerSortDirection>('desc');

  // Pagination State (20, 50, 100 as specified)
  const [currentPage, setCurrentPage] = useState<number>(1);
  const [pageSize, setPageSize] = useState<number>(20);

  // Copied phone feedback
  const [copiedPhoneId, setCopiedPhoneId] = useState<string | null>(null);

  // Delete Confirmation Dialog State
  const [customerToDelete, setCustomerToDelete] = useState<Customer | null>(null);
  const [showDeleteDialog, setShowDeleteDialog] = useState<boolean>(false);
  const [isDeleting, setIsDeleting] = useState<boolean>(false);
  const [deleteError, setDeleteError] = useState<string | null>(null);
  const [deleteSuccessMessage, setDeleteSuccessMessage] = useState<string | null>(null);

  // Mobile 3-dot overflow menu state
  const [openMobileMenuId, setOpenMobileMenuId] = useState<string | null>(null);

  // In-place Migration State
  const [isMigrating, setIsMigrating] = useState<boolean>(false);
  const [migrationSummary, setMigrationSummary] = useState<CustomerMigrationSummary | null>(null);
  const [showMigrationModal, setShowMigrationModal] = useState<boolean>(false);
  const [migrationError, setMigrationError] = useState<string | null>(null);

  // Dismiss mobile menu or delete modal on Escape key
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        if (openMobileMenuId) {
          setOpenMobileMenuId(null);
        }
        if (showDeleteDialog && !isDeleting) {
          setShowDeleteDialog(false);
          setCustomerToDelete(null);
          setDeleteError(null);
        }
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [openMobileMenuId, showDeleteDialog, isDeleting]);

  // Click-to-sort column handler
  const handleColumnSort = (column: CustomerSortColumn) => {
    setCurrentPage(1);
    if (sortColumn === column) {
      setSortDirection((prev) => (prev === 'asc' ? 'desc' : 'asc'));
    } else {
      setSortColumn(column);
      setSortDirection('asc');
    }
  };

  // Helper to render sort indicators
  const renderSortIcon = (column: CustomerSortColumn) => {
    if (sortColumn === column) {
      return sortDirection === 'asc' ? (
        <ArrowUp className="w-3.5 h-3.5 text-orange-400 shrink-0" aria-hidden="true" />
      ) : (
        <ArrowDown className="w-3.5 h-3.5 text-orange-400 shrink-0" aria-hidden="true" />
      );
    }
    return (
      <ArrowUpDown
        className="w-3 h-3 text-neutral-400 group-hover:text-white shrink-0 opacity-60 group-hover:opacity-100 transition-opacity"
        aria-hidden="true"
      />
    );
  };

  // Open delete confirmation dialog
  const handleDeleteClick = (customer: Customer) => {
    setCustomerToDelete(customer);
    setDeleteError(null);
    setShowDeleteDialog(true);
  };

  // Confirm delete customer with existing deleteCustomerSafely logic
  const handleConfirmDelete = async () => {
    if (!customerToDelete || isDeleting) return;
    setIsDeleting(true);
    setDeleteError(null);
    try {
      await deleteCustomerSafely(
        customerToDelete.id,
        userProfile?.id || 'system',
        userProfile?.name || 'Staff'
      );
      if (onDeleteCustomer) {
        await onDeleteCustomer(customerToDelete);
      }
      setShowDeleteDialog(false);
      setDeleteSuccessMessage(`Customer "${customerToDelete.name}" was successfully deleted.`);
      setCustomerToDelete(null);
      setTimeout(() => setDeleteSuccessMessage(null), 4000);
    } catch (err: any) {
      console.error('Customer deletion error:', err);
      setDeleteError(err.message || 'Customer deletion failed.');
    } finally {
      setIsDeleting(false);
    }
  };

  const handleRunMigration = async () => {
    setIsMigrating(true);
    setMigrationError(null);
    try {
      const summary = await migrateCustomerIdsInPlace();
      setMigrationSummary(summary);
      setShowMigrationModal(true);
    } catch (err: any) {
      setMigrationError(err.message || 'Customer ID migration failed.');
      setShowMigrationModal(true);
    } finally {
      setIsMigrating(false);
    }
  };

  // Access Control: Customer users cannot view directory
  if (userProfile?.role === 'customer') {
    return (
      <div className="p-8 text-center bg-white rounded-xl border border-neutral-200 space-y-3">
        <AlertTriangle className="w-10 h-10 text-amber-500 mx-auto" />
        <h2 className="text-base font-bold text-neutral-900">Access Restricted</h2>
        <p className="text-xs text-neutral-500 max-w-md mx-auto">
          Customer portal accounts are limited to personal statements, invoices, and payment histories. Direct access to the internal directory is restricted.
        </p>
      </div>
    );
  }

  // Pre-calculate financial summaries map for performant filtering & sorting
  const customerSummaries = useMemo(() => {
    const map = new Map<string, ReturnType<typeof calculateCustomerSummary>>();
    customers.forEach((cust) => {
      map.set(cust.id, calculateCustomerSummary(cust.id, invoices, payments));
    });
    return map;
  }, [customers, invoices, payments]);

  // Overall Directory Aggregates
  const directoryMetrics = useMemo(() => {
    let totalSalesSum = 0;
    let totalPaidSum = 0;
    let totalBalanceSum = 0;
    let activeCount = 0;
    let inactiveCount = 0;
    let blockedCount = 0;
    let newCustomersCount = 0;

    // Determine current month & previous month prefixes (YYYY-MM)
    const now = new Date();
    const curYear = now.getFullYear();
    const curMonth = now.getMonth(); // 0-indexed
    const curMonthPrefix = `${curYear}-${String(curMonth + 1).padStart(2, '0')}`;
    
    const prevMonthDate = new Date(curYear, curMonth - 1, 1);
    const prevMonthPrefix = `${prevMonthDate.getFullYear()}-${String(prevMonthDate.getMonth() + 1).padStart(2, '0')}`;

    let currentMonthJoined = 0;
    let previousMonthJoined = 0;

    customers.forEach((c) => {
      const st = normalizeCustomerStatus(c.status, c.isArchived);
      if (st === 'Active') activeCount++;
      else if (st === 'Inactive') inactiveCount++;
      else if (st === 'Blocked') blockedCount++;

      // New customers: joined in current calendar month or within last 30 days
      if (c.createdAt) {
        if (c.createdAt.startsWith(curMonthPrefix)) {
          currentMonthJoined++;
        } else if (c.createdAt.startsWith(prevMonthPrefix)) {
          previousMonthJoined++;
        }
      }

      const summary = customerSummaries.get(c.id);
      if (summary) {
        totalSalesSum += summary.totalSales;
        totalPaidSum += summary.totalPaid;
        totalBalanceSum += summary.remainingBalance;
      }
    });

    newCustomersCount = currentMonthJoined;

    // Compute month-over-month new customers growth only if previous month has valid non-zero data
    let newCustomersGrowth: { rate: number; isPositive: boolean } | null = null;
    if (previousMonthJoined > 0) {
      const diff = currentMonthJoined - previousMonthJoined;
      const rate = Math.round((diff / previousMonthJoined) * 100);
      newCustomersGrowth = { rate: Math.abs(rate), isPositive: diff >= 0 };
    }

    return {
      totalCustomers: customers.length,
      activeCount,
      inactiveCount,
      blockedCount,
      newCustomersCount,
      newCustomersGrowth,
      totalSalesSum,
      totalPaidSum,
      totalBalanceSum,
    };
  }, [customers, customerSummaries]);

  // Filter and Sort Customers
  const filteredCustomers = useMemo(() => {
    const rawTerm = searchTerm.trim().toLowerCase();
    const normPhoneTerm = normalizePhone(searchTerm.trim());

    return customers
      .filter((cust) => {
        const custStatus = normalizeCustomerStatus(cust.status, cust.isArchived);
        const custType: CustomerType =
          cust.customerType || (cust.companyName && cust.companyName.trim().length > 0 ? 'Business' : 'Individual');
        const summary = customerSummaries.get(cust.id);

        // 1. Status Filter
        if (statusFilter !== 'all') {
          if (custStatus !== statusFilter) return false;
        }

        // 2. Customer Type Filter
        if (typeFilter !== 'all') {
          if (custType !== typeFilter) return false;
        }

        // 3. Financial Status Filter
        if (financialFilter !== 'all') {
          if (summary?.financialStatus !== financialFilter) return false;
        }

        // 4. Search Filter (Customer ID, Name, Company, Phone, Email)
        if (rawTerm) {
          const codeMatch = (cust.customerCode || cust.id).toLowerCase().includes(rawTerm);
          const nameMatch = cust.name.toLowerCase().includes(rawTerm);
          const companyMatch = (cust.companyName || '').toLowerCase().includes(rawTerm);
          const emailMatch = (cust.email || '').toLowerCase().includes(rawTerm);
          const phoneRawMatch = (cust.phone || '').toLowerCase().includes(rawTerm);
          const altPhoneRawMatch = (cust.alternatePhone || '').toLowerCase().includes(rawTerm);

          let phoneNormMatch = false;
          if (normPhoneTerm.length >= 3) {
            const custNormPhone = normalizePhone(cust.phone);
            const custNormAlt = normalizePhone(cust.alternatePhone);
            phoneNormMatch = custNormPhone.includes(normPhoneTerm) || custNormAlt.includes(normPhoneTerm);
          }

          if (!codeMatch && !nameMatch && !companyMatch && !emailMatch && !phoneRawMatch && !altPhoneRawMatch && !phoneNormMatch) {
            return false;
          }
        }

        return true;
      })
      .sort((a, b) => {
        const sumA = customerSummaries.get(a.id);
        const sumB = customerSummaries.get(b.id);
        const codeA = a.customerCode || a.id;
        const codeB = b.customerCode || b.id;

        let res = 0;
        switch (sortColumn) {
          case 'customer_id':
            res = codeA.localeCompare(codeB, undefined, { numeric: true, sensitivity: 'base' });
            break;
          case 'name':
            res = (a.name || '').localeCompare(b.name || '', undefined, { sensitivity: 'base' });
            break;
          case 'company':
            res = (a.companyName || '').localeCompare(b.companyName || '', undefined, { sensitivity: 'base' });
            break;
          case 'phone':
            res = (a.phone || '').localeCompare(b.phone || '', undefined, { numeric: true });
            break;
          case 'type': {
            const typeA = a.customerType || (a.companyName && a.companyName.trim().length > 0 ? 'Business' : 'Individual');
            const typeB = b.customerType || (b.companyName && b.companyName.trim().length > 0 ? 'Business' : 'Individual');
            res = typeA.localeCompare(typeB);
            break;
          }
          case 'balance': {
            const balA = sumA?.remainingBalance || 0;
            const balB = sumB?.remainingBalance || 0;
            res = balA - balB;
            break;
          }
          case 'status': {
            const statusRank: Record<string, number> = { Active: 1, Inactive: 2, Blocked: 3 };
            const statusA = normalizeCustomerStatus(a.status, a.isArchived);
            const statusB = normalizeCustomerStatus(b.status, b.isArchived);
            const rankA = statusRank[statusA] || 99;
            const rankB = statusRank[statusB] || 99;
            res = rankA - rankB;
            if (res === 0) {
              res = (a.name || '').localeCompare(b.name || '', undefined, { sensitivity: 'base' });
            }
            break;
          }
          case 'updated_at': {
            const dateA = new Date(a.updatedAt || a.createdAt || 0).getTime();
            const dateB = new Date(b.updatedAt || b.createdAt || 0).getTime();
            res = dateA - dateB;
            break;
          }
          case 'created_at':
          default: {
            const dateA = new Date(a.createdAt || 0).getTime();
            const dateB = new Date(b.createdAt || 0).getTime();
            res = dateA - dateB;
            break;
          }
        }

        const directedRes = sortDirection === 'desc' ? -res : res;
        // Stable tie-breaker: fallback to unique ID comparison
        return directedRes !== 0 ? directedRes : a.id.localeCompare(b.id);
      });
  }, [customers, searchTerm, statusFilter, typeFilter, financialFilter, sortColumn, sortDirection, customerSummaries]);

  // Pagination Math
  const totalRecords = filteredCustomers.length;
  const totalPages = Math.ceil(totalRecords / pageSize) || 1;
  const safeCurrentPage = Math.min(Math.max(currentPage, 1), totalPages);

  // Active filters count (for indicator badge on Filter toggle button)
  const activeFilterCount = useMemo(() => {
    let count = 0;
    if (searchTerm.trim()) count++;
    if (statusFilter !== 'all') count++;
    if (typeFilter !== 'all') count++;
    if (financialFilter !== 'all') count++;
    if (sortColumn !== 'created_at' || sortDirection !== 'desc') count++;
    return count;
  }, [searchTerm, statusFilter, typeFilter, financialFilter, sortColumn, sortDirection]);

  const paginatedCustomers = useMemo(() => {
    const start = (safeCurrentPage - 1) * pageSize;
    return filteredCustomers.slice(start, start + pageSize);
  }, [filteredCustomers, safeCurrentPage, pageSize]);

  const handlePageChange = (newPage: number) => {
    setCurrentPage(Math.min(Math.max(newPage, 1), totalPages));
  };

  const handleCopyPhone = (e: React.MouseEvent, id: string, phoneStr: string) => {
    e.stopPropagation();
    if (!phoneStr) return;
    navigator.clipboard.writeText(phoneStr);
    setCopiedPhoneId(id);
    setTimeout(() => setCopiedPhoneId(null), 2000);
  };

  // Two-way synchronization between sort dropdown and active sort column / direction
  const selectSortValue = useMemo(() => {
    if (sortColumn === 'created_at') return sortDirection === 'desc' ? 'newest' : 'oldest';
    if (sortColumn === 'customer_id') return sortDirection === 'desc' ? 'customer_id_desc' : 'customer_id';
    if (sortColumn === 'name') return sortDirection === 'desc' ? 'name_desc' : 'name_asc';
    if (sortColumn === 'company') return sortDirection === 'desc' ? 'company_desc' : 'company_asc';
    if (sortColumn === 'phone') return sortDirection === 'desc' ? 'phone_desc' : 'phone_asc';
    if (sortColumn === 'type') return sortDirection === 'desc' ? 'type_desc' : 'type_asc';
    if (sortColumn === 'balance') return sortDirection === 'desc' ? 'balance_desc' : 'balance_asc';
    if (sortColumn === 'status') return sortDirection === 'desc' ? 'status_desc' : 'status_asc';
    if (sortColumn === 'updated_at') return 'last_updated';
    return 'newest';
  }, [sortColumn, sortDirection]);

  const handleSelectSortChange = (val: string) => {
    setCurrentPage(1);
    switch (val) {
      case 'newest':
        setSortColumn('created_at');
        setSortDirection('desc');
        break;
      case 'oldest':
        setSortColumn('created_at');
        setSortDirection('asc');
        break;
      case 'customer_id':
        setSortColumn('customer_id');
        setSortDirection('asc');
        break;
      case 'customer_id_desc':
        setSortColumn('customer_id');
        setSortDirection('desc');
        break;
      case 'name_asc':
        setSortColumn('name');
        setSortDirection('asc');
        break;
      case 'name_desc':
        setSortColumn('name');
        setSortDirection('desc');
        break;
      case 'company_asc':
        setSortColumn('company');
        setSortDirection('asc');
        break;
      case 'company_desc':
        setSortColumn('company');
        setSortDirection('desc');
        break;
      case 'phone_asc':
        setSortColumn('phone');
        setSortDirection('asc');
        break;
      case 'phone_desc':
        setSortColumn('phone');
        setSortDirection('desc');
        break;
      case 'type_asc':
        setSortColumn('type');
        setSortDirection('asc');
        break;
      case 'type_desc':
        setSortColumn('type');
        setSortDirection('desc');
        break;
      case 'balance_desc':
        setSortColumn('balance');
        setSortDirection('desc');
        break;
      case 'balance_asc':
        setSortColumn('balance');
        setSortDirection('asc');
        break;
      case 'status_asc':
        setSortColumn('status');
        setSortDirection('asc');
        break;
      case 'status_desc':
        setSortColumn('status');
        setSortDirection('desc');
        break;
      case 'last_updated':
        setSortColumn('updated_at');
        setSortDirection('desc');
        break;
      default:
        setSortColumn('created_at');
        setSortDirection('desc');
    }
  };

  return (
    <div id="customers-view" className="space-y-4">
      {/* View Header */}
      <header className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 sm:gap-4 pb-1">
        <div className="min-w-0">
          <div className="flex items-center gap-2.5 flex-wrap">
            <h1 className="text-xl sm:text-2xl font-bold text-neutral-900 tracking-tight">
              Customers
            </h1>
            <span
              className="inline-flex items-center justify-center px-2 py-0.5 text-xs font-semibold font-mono rounded-full bg-neutral-100 text-neutral-700 border border-neutral-200"
              title="Total matching customers"
            >
              {filteredCustomers.length}
            </span>
          </div>
          <p className="text-xs sm:text-sm text-neutral-500 mt-1">
            Manage customer profiles and accounts
          </p>
        </div>

        <div className="flex items-center gap-2 sm:gap-2.5 shrink-0 self-start sm:self-auto">
          {/* Filter Toggle Button */}
          <button
            id="btn-toggle-filters"
            type="button"
            onClick={() => setIsFilterOpen((prev) => !prev)}
            className={`h-10 px-3 sm:px-3.5 inline-flex items-center justify-center gap-2 text-xs sm:text-sm font-medium rounded-lg border transition shadow-2xs touch-manipulation cursor-pointer select-none focus:outline-none focus:ring-2 focus:ring-neutral-400 ${
              isFilterOpen
                ? 'bg-neutral-100 text-neutral-900 border-neutral-300 shadow-inner font-semibold'
                : 'bg-white text-neutral-700 border-neutral-300 hover:bg-neutral-50 active:bg-neutral-100 hover:text-neutral-900'
            }`}
            title={isFilterOpen ? 'Hide Filters' : 'Show Filters'}
            aria-label={isFilterOpen ? 'Hide Filters' : 'Show Filters'}
            aria-expanded={isFilterOpen}
            aria-controls="customer-filter-section"
          >
            <SlidersHorizontal
              className={`w-4 h-4 shrink-0 transition-colors ${
                isFilterOpen ? 'text-blue-600' : 'text-neutral-500'
              }`}
              aria-hidden="true"
            />
            <span className="hidden sm:inline">Filter</span>
            {activeFilterCount > 0 && (
              <span
                className="px-1.5 py-0.2 rounded-full text-[10px] font-bold bg-blue-100 text-blue-700 border border-blue-200"
                title={`${activeFilterCount} active filters applied`}
              >
                {activeFilterCount}
              </span>
            )}
          </button>

          {/* Add Customer Button (Primary Blue) */}
          {permissions?.canManageCustomers && (
            <button
              id="btn-add-customer"
              type="button"
              onClick={onNewCustomer}
              className="h-10 px-3 sm:px-4 inline-flex items-center justify-center gap-2 text-xs sm:text-sm font-semibold text-white bg-blue-600 hover:bg-blue-700 active:bg-blue-800 rounded-lg shadow-sm hover:shadow transition focus:outline-none focus:ring-2 focus:ring-blue-500/30 touch-manipulation cursor-pointer shrink-0"
              title="Add Customer"
              aria-label="Add Customer"
            >
              <UserPlus className="w-4 h-4 text-white shrink-0" aria-hidden="true" />
              <span className="hidden sm:inline">Add Customer</span>
            </button>
          )}
        </div>
      </header>

      {/* Delete / Action Success Banner */}
      {deleteSuccessMessage && (
        <div
          id="customer-action-success-banner"
          className="p-3 bg-emerald-50 border border-emerald-200 text-emerald-800 rounded-xl text-xs flex items-center justify-between shadow-2xs animate-in fade-in duration-150"
        >
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" aria-hidden="true" />
            <span className="font-semibold">{deleteSuccessMessage}</span>
          </div>
          <button
            type="button"
            onClick={() => setDeleteSuccessMessage(null)}
            className="text-emerald-600 hover:text-emerald-800 p-0.5 rounded transition"
            title="Dismiss notification"
            aria-label="Dismiss notification"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      )}

      {/* Collapsible Search, Filter & Sort Controls (Positioned BEFORE KPI Cards with Smooth Collapse/Expand Animation) */}
      <div
        id="customer-filter-collapse-container"
        className={`grid transition-all duration-300 ease-in-out overflow-hidden ${
          isFilterOpen
            ? 'grid-rows-[1fr] opacity-100 scale-100'
            : 'grid-rows-[0fr] opacity-0 scale-[0.99] pointer-events-none -mt-4'
        }`}
        aria-hidden={!isFilterOpen}
      >
        <div className="overflow-hidden min-h-0">
          <div
            id="customer-filter-section"
            className="bg-white p-4 rounded-xl border border-neutral-200 shadow-2xs space-y-3"
          >
            <div className="flex flex-col lg:flex-row items-stretch lg:items-center justify-between gap-3">
              {/* Search Input */}
              <div className="relative flex-1">
                <Search className="w-4 h-4 text-neutral-400 absolute left-3 top-2.5" />
                <input
                  id="input-search-customers"
                  type="text"
                  value={searchTerm}
                  onChange={(e) => {
                    setSearchTerm(e.target.value);
                    setCurrentPage(1);
                  }}
                  placeholder="Search Customer ID (ST-CUST-1001), name, company, phone, email..."
                  className="w-full text-xs pl-9 pr-8 py-2 border border-neutral-300 rounded-lg focus:outline-none focus:ring-1 focus:ring-orange-500"
                />
                {searchTerm && (
                  <button
                    type="button"
                    onClick={() => setSearchTerm('')}
                    className="absolute right-2.5 top-2.5 text-neutral-400 hover:text-neutral-600"
                  >
                    <X className="w-3.5 h-3.5" />
                  </button>
                )}
              </div>

              {/* Filters and Sort */}
              <div className="flex flex-wrap items-center gap-2">
                {/* Status Filter */}
                <div className="flex items-center gap-1.5 text-xs">
                  <span className="text-neutral-500 text-[11px] font-medium">Status:</span>
                  <select
                    id="select-filter-status"
                    value={statusFilter}
                    onChange={(e) => {
                      setStatusFilter(e.target.value as any);
                      setCurrentPage(1);
                    }}
                    className="text-xs py-1.5 px-2.5 border border-neutral-300 rounded-lg bg-white text-neutral-800 focus:outline-none focus:ring-1 focus:ring-orange-500 font-medium"
                  >
                    <option value="all">All Statuses</option>
                    <option value="Active">Active</option>
                    <option value="Inactive">Inactive</option>
                    <option value="Blocked">Blocked</option>
                  </select>
                </div>

                {/* Type Filter */}
                <div className="flex items-center gap-1.5 text-xs">
                  <span className="text-neutral-500 text-[11px] font-medium">Type:</span>
                  <select
                    id="select-filter-type"
                    value={typeFilter}
                    onChange={(e) => {
                      setTypeFilter(e.target.value as any);
                      setCurrentPage(1);
                    }}
                    className="text-xs py-1.5 px-2.5 border border-neutral-300 rounded-lg bg-white text-neutral-800 focus:outline-none focus:ring-1 focus:ring-orange-500 font-medium"
                  >
                    <option value="all">All Types</option>
                    <option value="Individual">Individual</option>
                    <option value="Business">Business</option>
                  </select>
                </div>

                {/* Financial Status Filter */}
                <div className="flex items-center gap-1.5 text-xs">
                  <span className="text-neutral-500 text-[11px] font-medium">Financial:</span>
                  <select
                    id="select-filter-financial"
                    value={financialFilter}
                    onChange={(e) => {
                      setFinancialFilter(e.target.value as any);
                      setCurrentPage(1);
                    }}
                    className="text-xs py-1.5 px-2.5 border border-neutral-300 rounded-lg bg-white text-neutral-800 focus:outline-none focus:ring-1 focus:ring-orange-500 font-medium"
                  >
                    <option value="all">All Financial</option>
                    <option value="Paid">Paid (AFN 0 Due)</option>
                    <option value="Outstanding">Outstanding Due</option>
                    <option value="Overdue">Overdue Invoices</option>
                  </select>
                </div>

                {/* Sort Selector with Direction Toggle */}
                <div className="flex items-center gap-1.5 text-xs">
                  <span className="text-neutral-500 text-[11px] font-medium">Sort:</span>
                  <div className="flex items-center gap-1">
                    <select
                      id="select-sort-by"
                      value={selectSortValue}
                      onChange={(e) => handleSelectSortChange(e.target.value)}
                      className="text-xs py-1.5 px-2.5 border border-neutral-300 rounded-lg bg-white text-neutral-800 focus:outline-none focus:ring-1 focus:ring-orange-500 font-medium"
                    >
                      <option value="newest">Newest First</option>
                      <option value="oldest">Oldest First</option>
                      <option value="customer_id">Customer ID (Asc)</option>
                      <option value="customer_id_desc">Customer ID (Desc)</option>
                      <option value="name_asc">Name (A-Z)</option>
                      <option value="name_desc">Name (Z-A)</option>
                      <option value="company_asc">Company (A-Z)</option>
                      <option value="phone_asc">Phone (Asc)</option>
                      <option value="type_asc">Type (Individual/Business)</option>
                      <option value="balance_desc">Highest Balance</option>
                      <option value="balance_asc">Lowest Balance</option>
                      <option value="status_asc">Status (Active First)</option>
                      <option value="last_updated">Last Updated</option>
                    </select>
                    <button
                      id="btn-toggle-sort-direction"
                      type="button"
                      onClick={() => {
                        setCurrentPage(1);
                        setSortDirection((prev) => (prev === 'asc' ? 'desc' : 'asc'));
                      }}
                      className="p-1.5 border border-neutral-300 rounded-lg bg-white hover:bg-neutral-50 active:bg-neutral-100 text-neutral-700 focus:outline-none focus:ring-1 focus:ring-orange-500 transition"
                      title={`Toggle sort direction (currently ${sortDirection === 'asc' ? 'Ascending' : 'Descending'})`}
                      aria-label={`Toggle sort direction (currently ${sortDirection === 'asc' ? 'Ascending' : 'Descending'})`}
                    >
                      {sortDirection === 'asc' ? (
                        <ArrowUp className="w-3.5 h-3.5 text-orange-600" aria-hidden="true" />
                      ) : (
                        <ArrowDown className="w-3.5 h-3.5 text-orange-600" aria-hidden="true" />
                      )}
                    </button>
                  </div>
                </div>
              </div>
            </div>

            {/* Results summary label */}
            <div className="flex items-center justify-between text-xs text-neutral-500 pt-1 border-t border-neutral-100">
              <span>
                Showing <strong className="text-neutral-800">{filteredCustomers.length}</strong> customer accounts
              </span>
              {(searchTerm || statusFilter !== 'all' || typeFilter !== 'all' || financialFilter !== 'all' || sortColumn !== 'created_at' || sortDirection !== 'desc') && (
                <button
                  type="button"
                  onClick={() => {
                    setSearchTerm('');
                    setStatusFilter('all');
                    setTypeFilter('all');
                    setFinancialFilter('all');
                    setSortColumn('created_at');
                    setSortDirection('desc');
                    setCurrentPage(1);
                  }}
                  className="text-orange-600 hover:text-orange-700 font-semibold text-[11px]"
                >
                  Reset Filters
                </button>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Customer Module KPI Cards (Single row of 4 cards on desktop, 2x2 on tablet/mobile, 1 col on narrow screens) */}
      <section
        id="customer-kpi-cards-section"
        aria-label="Customer summary statistics"
        className="grid grid-cols-1 min-[480px]:grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4"
      >
        {/* 1. Total Customers (Blue accent) */}
        <div
          id="kpi-total-customers-card"
          className="bg-white rounded-xl p-4 border border-neutral-200/90 shadow-2xs hover:border-blue-200 transition-colors flex flex-col justify-between min-w-0"
        >
          <div className="flex items-center justify-between text-neutral-500 mb-2">
            <span className="text-[11px] font-bold uppercase tracking-wider text-neutral-500 truncate mr-2">
              Total Customers
            </span>
            <div className="w-8 h-8 rounded-lg bg-blue-50 flex items-center justify-center shrink-0">
              <Users className="w-4 h-4 text-blue-600" aria-hidden="true" />
            </div>
          </div>
          <div>
            <div className="flex items-baseline gap-2">
              <p
                id="kpi-total-customers-value"
                className="text-2xl sm:text-3xl font-bold font-mono text-neutral-900 tracking-tight"
              >
                {directoryMetrics.totalCustomers}
              </p>
            </div>
            <p className="text-xs text-neutral-500 mt-1 truncate">
              All registered profiles
            </p>
          </div>
        </div>

        {/* 2. Active Customers (Green accent) */}
        <div
          id="kpi-active-customers-card"
          className="bg-white rounded-xl p-4 border border-neutral-200/90 shadow-2xs hover:border-emerald-200 transition-colors flex flex-col justify-between min-w-0"
        >
          <div className="flex items-center justify-between text-neutral-500 mb-2">
            <span className="text-[11px] font-bold uppercase tracking-wider text-neutral-500 truncate mr-2">
              Active Customers
            </span>
            <div className="w-8 h-8 rounded-lg bg-emerald-50 flex items-center justify-center shrink-0">
              <UserCheck className="w-4 h-4 text-emerald-600" aria-hidden="true" />
            </div>
          </div>
          <div>
            <div className="flex items-baseline gap-2">
              <p
                id="kpi-active-customers-value"
                className="text-2xl sm:text-3xl font-bold font-mono text-neutral-900 tracking-tight"
              >
                {directoryMetrics.activeCount}
              </p>
              {directoryMetrics.totalCustomers > 0 && (
                <span className="text-[11px] font-semibold text-emerald-700 bg-emerald-50 px-1.5 py-0.5 rounded">
                  {Math.round((directoryMetrics.activeCount / directoryMetrics.totalCustomers) * 100)}%
                </span>
              )}
            </div>
            <p className="text-xs text-neutral-500 mt-1 truncate">
              Operational accounts in good standing
            </p>
          </div>
        </div>

        {/* 3. New Customers (Purple accent) */}
        <div
          id="kpi-new-customers-card"
          className="bg-white rounded-xl p-4 border border-neutral-200/90 shadow-2xs hover:border-purple-200 transition-colors flex flex-col justify-between min-w-0"
        >
          <div className="flex items-center justify-between text-neutral-500 mb-2">
            <span className="text-[11px] font-bold uppercase tracking-wider text-neutral-500 truncate mr-2">
              New Customers
            </span>
            <div className="w-8 h-8 rounded-lg bg-purple-50 flex items-center justify-center shrink-0">
              <UserPlus className="w-4 h-4 text-purple-600" aria-hidden="true" />
            </div>
          </div>
          <div>
            <div className="flex items-baseline gap-2">
              <p
                id="kpi-new-customers-value"
                className="text-2xl sm:text-3xl font-bold font-mono text-neutral-900 tracking-tight"
              >
                {directoryMetrics.newCustomersCount}
              </p>
              {directoryMetrics.newCustomersGrowth ? (
                <span
                  className={`text-[11px] font-semibold px-1.5 py-0.5 rounded ${
                    directoryMetrics.newCustomersGrowth.isPositive
                      ? 'text-purple-700 bg-purple-50'
                      : 'text-neutral-600 bg-neutral-100'
                  }`}
                  title="Month-over-month new customers growth"
                >
                  {directoryMetrics.newCustomersGrowth.isPositive ? '+' : '-'}
                  {directoryMetrics.newCustomersGrowth.rate}%
                </span>
              ) : null}
            </div>
            <p className="text-xs text-neutral-500 mt-1 truncate">
              Joined this calendar month
            </p>
          </div>
        </div>

        {/* 4. Inactive Customers (Amber accent) */}
        <div
          id="kpi-inactive-customers-card"
          className="bg-white rounded-xl p-4 border border-neutral-200/90 shadow-2xs hover:border-amber-200 transition-colors flex flex-col justify-between min-w-0"
        >
          <div className="flex items-center justify-between text-neutral-500 mb-2">
            <span className="text-[11px] font-bold uppercase tracking-wider text-neutral-500 truncate mr-2">
              Inactive Customers
            </span>
            <div className="w-8 h-8 rounded-lg bg-amber-50 flex items-center justify-center shrink-0">
              <UserX className="w-4 h-4 text-amber-600" aria-hidden="true" />
            </div>
          </div>
          <div>
            <div className="flex items-baseline gap-2">
              <p
                id="kpi-inactive-customers-value"
                className="text-2xl sm:text-3xl font-bold font-mono text-neutral-900 tracking-tight"
              >
                {directoryMetrics.inactiveCount}
              </p>
              {directoryMetrics.blockedCount > 0 && (
                <span
                  className="text-[11px] font-semibold text-rose-700 bg-rose-50 px-1.5 py-0.5 rounded"
                  title="Blocked accounts requiring administrative review"
                >
                  +{directoryMetrics.blockedCount} Blocked
                </span>
              )}
            </div>
            <p className="text-xs text-neutral-500 mt-1 truncate">
              Suspended or deactivated profiles
            </p>
          </div>
        </div>
      </section>

      {/* DESKTOP TABLE VIEW (hidden on mobile, visible on md and up) */}
      <div className="hidden md:block bg-white rounded-xl border border-neutral-200 shadow-2xs overflow-hidden">
        {paginatedCustomers.length === 0 ? (
          <div className="p-12 text-center text-xs text-neutral-500 space-y-2">
            <Users className="w-10 h-10 text-neutral-300 mx-auto" />
            <p className="font-bold text-sm text-neutral-700">No customer records found.</p>
            <p className="text-neutral-400 max-w-sm mx-auto">
              {searchTerm
                ? `No customers match query "${searchTerm}". Try searching by phone number or Customer ID.`
                : 'No customer accounts available. Click "Add Customer" to create your first record.'}
            </p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table id="customers-table" className="w-full border-collapse text-xs">
              <thead>
                <tr className="bg-neutral-900 text-white font-semibold text-left select-none">
                  {/* Customer ID */}
                  <th
                    scope="col"
                    className="py-3 px-3.5 whitespace-nowrap text-left"
                    aria-sort={sortColumn === 'customer_id' ? (sortDirection === 'asc' ? 'ascending' : 'descending') : 'none'}
                  >
                    <button
                      type="button"
                      onClick={() => handleColumnSort('customer_id')}
                      className="group inline-flex items-center gap-1.5 font-semibold text-white hover:text-orange-300 focus:outline-none focus:ring-1 focus:ring-orange-400 rounded transition cursor-pointer"
                      title="Sort by Customer ID"
                      aria-label="Sort by Customer ID"
                    >
                      <span>Customer ID</span>
                      {renderSortIcon('customer_id')}
                    </button>
                  </th>

                  {/* Customer Name */}
                  <th
                    scope="col"
                    className="py-3 px-3.5 text-left"
                    aria-sort={sortColumn === 'name' ? (sortDirection === 'asc' ? 'ascending' : 'descending') : 'none'}
                  >
                    <button
                      type="button"
                      onClick={() => handleColumnSort('name')}
                      className="group inline-flex items-center gap-1.5 font-semibold text-white hover:text-orange-300 focus:outline-none focus:ring-1 focus:ring-orange-400 rounded transition cursor-pointer"
                      title="Sort by Customer Name"
                      aria-label="Sort by Customer Name"
                    >
                      <span>Customer</span>
                      {renderSortIcon('name')}
                    </button>
                  </th>

                  {/* Company */}
                  <th
                    scope="col"
                    className="py-3 px-3.5 text-left"
                    aria-sort={sortColumn === 'company' ? (sortDirection === 'asc' ? 'ascending' : 'descending') : 'none'}
                  >
                    <button
                      type="button"
                      onClick={() => handleColumnSort('company')}
                      className="group inline-flex items-center gap-1.5 font-semibold text-white hover:text-orange-300 focus:outline-none focus:ring-1 focus:ring-orange-400 rounded transition cursor-pointer"
                      title="Sort by Company"
                      aria-label="Sort by Company"
                    >
                      <span>Company</span>
                      {renderSortIcon('company')}
                    </button>
                  </th>

                  {/* Phone */}
                  <th
                    scope="col"
                    className="py-3 px-3.5 text-left whitespace-nowrap"
                    aria-sort={sortColumn === 'phone' ? (sortDirection === 'asc' ? 'ascending' : 'descending') : 'none'}
                  >
                    <button
                      type="button"
                      onClick={() => handleColumnSort('phone')}
                      className="group inline-flex items-center gap-1.5 font-semibold text-white hover:text-orange-300 focus:outline-none focus:ring-1 focus:ring-orange-400 rounded transition cursor-pointer"
                      title="Sort by Phone Number"
                      aria-label="Sort by Phone Number"
                    >
                      <span>Phone</span>
                      {renderSortIcon('phone')}
                    </button>
                  </th>

                  {/* Type */}
                  <th
                    scope="col"
                    className="py-3 px-3.5 text-center whitespace-nowrap"
                    aria-sort={sortColumn === 'type' ? (sortDirection === 'asc' ? 'ascending' : 'descending') : 'none'}
                  >
                    <button
                      type="button"
                      onClick={() => handleColumnSort('type')}
                      className="group inline-flex items-center justify-center gap-1.5 font-semibold text-white hover:text-orange-300 focus:outline-none focus:ring-1 focus:ring-orange-400 rounded transition cursor-pointer"
                      title="Sort by Customer Type"
                      aria-label="Sort by Customer Type"
                    >
                      <span>Type</span>
                      {renderSortIcon('type')}
                    </button>
                  </th>

                  {/* Balance */}
                  <th
                    scope="col"
                    className="py-3 px-3.5 text-right whitespace-nowrap"
                    aria-sort={sortColumn === 'balance' ? (sortDirection === 'asc' ? 'ascending' : 'descending') : 'none'}
                  >
                    <button
                      type="button"
                      onClick={() => handleColumnSort('balance')}
                      className="group inline-flex items-center justify-end gap-1.5 font-semibold text-white hover:text-orange-300 focus:outline-none focus:ring-1 focus:ring-orange-400 rounded transition cursor-pointer ml-auto"
                      title="Sort by Outstanding Balance"
                      aria-label="Sort by Outstanding Balance"
                    >
                      <span>Balance</span>
                      {renderSortIcon('balance')}
                    </button>
                  </th>

                  {/* Status */}
                  <th
                    scope="col"
                    className="py-3 px-3.5 text-center whitespace-nowrap"
                    aria-sort={sortColumn === 'status' ? (sortDirection === 'asc' ? 'ascending' : 'descending') : 'none'}
                  >
                    <button
                      type="button"
                      onClick={() => handleColumnSort('status')}
                      className="group inline-flex items-center justify-center gap-1.5 font-semibold text-white hover:text-orange-300 focus:outline-none focus:ring-1 focus:ring-orange-400 rounded transition cursor-pointer"
                      title="Sort by Status"
                      aria-label="Sort by Status"
                    >
                      <span>Status</span>
                      {renderSortIcon('status')}
                    </button>
                  </th>

                  {/* Actions (Not Sortable) */}
                  <th scope="col" className="py-3 px-3.5 text-right whitespace-nowrap">
                    <span>Actions</span>
                  </th>
                </tr>
              </thead>
              <tbody className="divide-y divide-neutral-200">
                {paginatedCustomers.map((cust) => {
                  const summary = customerSummaries.get(cust.id) || {
                    totalInvoices: 0,
                    totalSales: 0,
                    totalPaid: 0,
                    remainingBalance: 0,
                    financialStatus: 'Paid' as const,
                  };

                  const custStatus = normalizeCustomerStatus(cust.status, cust.isArchived);
                  const custType: CustomerType =
                    cust.customerType || (cust.companyName && cust.companyName.trim().length > 0 ? 'Business' : 'Individual');
                  const initials = (cust.name || 'C')
                    .split(' ')
                    .filter(Boolean)
                    .slice(0, 2)
                    .map((w) => w[0]?.toUpperCase())
                    .join('') || 'C';

                  return (
                    <tr
                      key={cust.id}
                      onClick={() => onSelectCustomer(cust)}
                      className="hover:bg-neutral-50/80 transition cursor-pointer group"
                    >
                      {/* Customer ID */}
                      <td className="py-3 px-3.5 whitespace-nowrap">
                        <span className="font-mono font-bold text-xs px-2 py-0.5 rounded bg-neutral-100 text-neutral-800 border border-neutral-200 group-hover:border-orange-300">
                          {cust.customerCode || cust.id}
                        </span>
                      </td>

                      {/* Customer */}
                      <td className="py-3 px-3.5 min-w-[180px]">
                        <div className="flex items-center gap-2.5">
                          <div className="w-8 h-8 rounded-full border border-neutral-300 overflow-hidden bg-neutral-100 flex items-center justify-center shrink-0">
                            {cust.photoURL ? (
                              <img
                                src={cust.photoURL}
                                alt={cust.name}
                                className="w-full h-full object-cover"
                                referrerPolicy="no-referrer"
                              />
                            ) : (
                              <span className="text-[11px] font-bold text-neutral-600">{initials}</span>
                            )}
                          </div>
                          <div className="min-w-0">
                            <div className="font-bold text-neutral-900 text-xs truncate">{cust.name}</div>
                            {cust.email && (
                              <div className="text-[11px] text-neutral-400 truncate max-w-[200px]">
                                {cust.email}
                              </div>
                            )}
                          </div>
                        </div>
                      </td>

                      {/* Company */}
                      <td className="py-3 px-3.5 text-neutral-700 font-medium max-w-[150px] truncate">
                        {cust.companyName || '—'}
                      </td>

                      {/* Phone */}
                      <td className="py-3 px-3.5 whitespace-nowrap">
                        <div className="flex items-center gap-1 font-mono text-neutral-800 font-medium">
                          <span>{cust.phone}</span>
                          <button
                            type="button"
                            onClick={(e) => handleCopyPhone(e, cust.id, cust.phone)}
                            className="p-1 text-neutral-400 hover:text-neutral-700 rounded transition"
                            title="Copy phone"
                          >
                            {copiedPhoneId === cust.id ? (
                              <Check className="w-3 h-3 text-emerald-600" />
                            ) : (
                              <Copy className="w-3 h-3" />
                            )}
                          </button>
                        </div>
                      </td>

                      {/* Type */}
                      <td className="py-3 px-3.5 text-center whitespace-nowrap">
                        <span
                          className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                            custType === 'Business'
                              ? 'bg-blue-50 text-blue-800 border border-blue-200'
                              : 'bg-neutral-100 text-neutral-700 border border-neutral-200'
                          }`}
                        >
                          {custType}
                        </span>
                      </td>

                      {/* Balance */}
                      <td className="py-3 px-3.5 text-right whitespace-nowrap">
                        <div>
                          <span
                            className={`font-mono font-bold text-xs ${
                              summary.remainingBalance > 0
                                ? 'text-rose-600 font-black'
                                : 'text-emerald-700'
                            }`}
                          >
                            {formatAFN(summary.remainingBalance)}
                          </span>
                          {summary.financialStatus === 'Overdue' && (
                            <span className="block text-[9px] font-bold text-red-600 uppercase">
                              Overdue
                            </span>
                          )}
                        </div>
                      </td>

                      {/* Status */}
                      <td className="py-3 px-3.5 text-center whitespace-nowrap">
                        {custStatus === 'Active' && (
                          <span className="inline-flex items-center gap-1 text-[10px] font-bold bg-emerald-100 text-emerald-800 px-2 py-0.5 rounded-full">
                            <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                            Active
                          </span>
                        )}
                        {custStatus === 'Inactive' && (
                          <span className="inline-flex items-center gap-1 text-[10px] font-bold bg-neutral-100 text-neutral-700 px-2 py-0.5 rounded-full">
                            <PauseCircle className="w-3 h-3 text-neutral-500" />
                            Inactive
                          </span>
                        )}
                        {custStatus === 'Blocked' && (
                          <span className="inline-flex items-center gap-1 text-[10px] font-bold bg-rose-100 text-rose-800 px-2 py-0.5 rounded-full">
                            <Lock className="w-3 h-3 text-rose-600" />
                            Blocked
                          </span>
                        )}
                      </td>

                      {/* Actions Column (Desktop: 3 Icon-only actions) */}
                      <td className="py-3 px-3.5 text-right whitespace-nowrap" onClick={(e) => e.stopPropagation()}>
                        <div className="flex items-center justify-end gap-1">
                          {/* View Customer */}
                          <button
                            id={`btn-view-customer-${cust.id}`}
                            type="button"
                            onClick={() => onSelectCustomer(cust)}
                            className="p-1.5 text-blue-600 hover:text-blue-800 hover:bg-blue-50 focus:outline-none focus:ring-2 focus:ring-blue-500/30 rounded-lg transition"
                            title="View Customer"
                            aria-label={`View Customer ${cust.name}`}
                          >
                            <Eye className="w-4 h-4" aria-hidden="true" />
                          </button>

                          {/* Edit Customer */}
                          {permissions?.canManageCustomers && (
                            <button
                              id={`btn-edit-customer-${cust.id}`}
                              type="button"
                              onClick={() => onEditCustomer(cust)}
                              className="p-1.5 text-emerald-600 hover:text-emerald-800 hover:bg-emerald-50 focus:outline-none focus:ring-2 focus:ring-emerald-500/30 rounded-lg transition"
                              title="Edit Customer"
                              aria-label={`Edit Customer ${cust.name}`}
                            >
                              <Pencil className="w-4 h-4" aria-hidden="true" />
                            </button>
                          )}

                          {/* Delete Customer */}
                          {permissions?.canManageCustomers && (
                            <button
                              id={`btn-delete-customer-${cust.id}`}
                              type="button"
                              onClick={() => handleDeleteClick(cust)}
                              className="p-1.5 text-rose-600 hover:text-rose-800 hover:bg-rose-50 focus:outline-none focus:ring-2 focus:ring-rose-500/30 rounded-lg transition"
                              title="Delete Customer"
                              aria-label={`Delete Customer ${cust.name}`}
                            >
                              <Trash2 className="w-4 h-4" aria-hidden="true" />
                            </button>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* MOBILE CARDS VIEW (visible on mobile, hidden on md and up) */}
      <div className="block md:hidden space-y-3">
        {paginatedCustomers.length === 0 ? (
          <div className="p-8 text-center bg-white rounded-xl border border-neutral-200 text-xs text-neutral-500 space-y-2">
            <Users className="w-8 h-8 text-neutral-300 mx-auto" />
            <p className="font-bold text-neutral-700">No customers found</p>
          </div>
        ) : (
          paginatedCustomers.map((cust) => {
            const summary = customerSummaries.get(cust.id) || {
              totalInvoices: 0,
              totalSales: 0,
              totalPaid: 0,
              remainingBalance: 0,
              financialStatus: 'Paid' as const,
            };
            const custStatus = normalizeCustomerStatus(cust.status, cust.isArchived);
            const custType: CustomerType =
              cust.customerType || (cust.companyName && cust.companyName.trim().length > 0 ? 'Business' : 'Individual');

            return (
              <div
                key={cust.id}
                onClick={() => onSelectCustomer(cust)}
                className="bg-white p-4 rounded-xl border border-neutral-200 shadow-2xs space-y-3 cursor-pointer hover:border-orange-300 transition"
              >
                <div className="flex items-start justify-between gap-2">
                  <div>
                    <span className="font-mono text-xs font-bold px-2 py-0.5 rounded bg-neutral-100 text-neutral-800 border border-neutral-200">
                      {cust.customerCode || cust.id}
                    </span>
                    <h3 className="font-bold text-neutral-900 text-sm mt-1">{cust.name}</h3>
                    {cust.companyName && (
                      <p className="text-xs text-neutral-500 flex items-center gap-1 mt-0.5">
                        <Building className="w-3 h-3" />
                        {cust.companyName}
                      </p>
                    )}
                  </div>

                  <div className="flex flex-col items-end gap-1">
                    {custStatus === 'Active' && (
                      <span className="text-[10px] font-bold bg-emerald-100 text-emerald-800 px-2 py-0.5 rounded-full flex items-center gap-1">
                        <CheckCircle2 className="w-3 h-3" /> Active
                      </span>
                    )}
                    {custStatus === 'Inactive' && (
                      <span className="text-[10px] font-bold bg-neutral-100 text-neutral-700 px-2 py-0.5 rounded-full flex items-center gap-1">
                        <PauseCircle className="w-3 h-3" /> Inactive
                      </span>
                    )}
                    {custStatus === 'Blocked' && (
                      <span className="text-[10px] font-bold bg-rose-100 text-rose-800 px-2 py-0.5 rounded-full flex items-center gap-1">
                        <Lock className="w-3 h-3" /> Blocked
                      </span>
                    )}
                    <span className="text-[10px] font-semibold text-neutral-500 bg-neutral-50 px-2 py-0.5 rounded border border-neutral-200">
                      {custType}
                    </span>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-2 pt-2 border-t border-neutral-100 text-xs">
                  <div>
                    <span className="text-neutral-400 text-[11px] block">Phone:</span>
                    <span className="font-mono font-medium text-neutral-800">{cust.phone}</span>
                  </div>
                  <div className="text-right">
                    <span className="text-neutral-400 text-[11px] block">Outstanding Balance:</span>
                    <span
                      className={`font-mono font-bold ${
                        summary.remainingBalance > 0 ? 'text-rose-600' : 'text-emerald-700'
                      }`}
                    >
                      {formatAFN(summary.remainingBalance)}
                    </span>
                  </div>
                </div>

                {/* Mobile Card Actions (Three-dot overflow menu) */}
                <div
                  className="flex items-center justify-between pt-2 border-t border-neutral-100"
                  onClick={(e) => e.stopPropagation()}
                >
                  <span className="text-[11px] font-medium text-neutral-400">Actions</span>
                  <div className="relative">
                    <button
                      id={`btn-mobile-actions-${cust.id}`}
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        setOpenMobileMenuId(openMobileMenuId === cust.id ? null : cust.id);
                      }}
                      aria-label="Customer actions"
                      aria-expanded={openMobileMenuId === cust.id}
                      aria-haspopup="true"
                      className="p-1.5 text-neutral-600 hover:text-neutral-900 hover:bg-neutral-100 rounded-lg transition border border-neutral-200 focus:outline-none focus:ring-2 focus:ring-orange-500/30"
                    >
                      <MoreVertical className="w-4 h-4" aria-hidden="true" />
                    </button>

                    {openMobileMenuId === cust.id && (
                      <>
                        {/* Backdrop for outside click & touch */}
                        <div
                          className="fixed inset-0 z-30"
                          onClick={(e) => {
                            e.stopPropagation();
                            setOpenMobileMenuId(null);
                          }}
                          aria-hidden="true"
                        />

                        {/* Dropdown Menu */}
                        <div
                          role="menu"
                          aria-orientation="vertical"
                          aria-labelledby={`btn-mobile-actions-${cust.id}`}
                          className="absolute right-0 bottom-full mb-1 z-40 w-48 bg-white rounded-xl shadow-xl border border-neutral-200 py-1 text-xs divide-y divide-neutral-100"
                          onClick={(e) => e.stopPropagation()}
                        >
                          <div className="py-1">
                            <button
                              role="menuitem"
                              type="button"
                              onClick={() => {
                                setOpenMobileMenuId(null);
                                onSelectCustomer(cust);
                              }}
                              className="w-full flex items-center gap-2 px-3 py-2 text-left font-medium text-neutral-700 hover:bg-blue-50 hover:text-blue-700 transition"
                            >
                              <Eye className="w-4 h-4 text-blue-600 shrink-0" aria-hidden="true" />
                              <span>View Customer</span>
                            </button>
                          </div>

                          {permissions?.canManageCustomers && (
                            <div className="py-1">
                              <button
                                role="menuitem"
                                type="button"
                                onClick={() => {
                                  setOpenMobileMenuId(null);
                                  onEditCustomer(cust);
                                }}
                                className="w-full flex items-center gap-2 px-3 py-2 text-left font-medium text-neutral-700 hover:bg-emerald-50 hover:text-emerald-700 transition"
                              >
                                <Pencil className="w-4 h-4 text-emerald-600 shrink-0" aria-hidden="true" />
                                <span>Edit Customer</span>
                              </button>
                            </div>
                          )}

                          {permissions?.canManageCustomers && (
                            <div className="py-1">
                              <button
                                role="menuitem"
                                type="button"
                                onClick={() => {
                                  setOpenMobileMenuId(null);
                                  handleDeleteClick(cust);
                                }}
                                className="w-full flex items-center gap-2 px-3 py-2 text-left font-medium text-rose-600 hover:bg-rose-50 hover:text-rose-700 transition"
                              >
                                <Trash2 className="w-4 h-4 text-rose-600 shrink-0" aria-hidden="true" />
                                <span>Delete Customer</span>
                              </button>
                            </div>
                          )}
                        </div>
                      </>
                    )}
                  </div>
                </div>
              </div>
            );
          })
        )}
      </div>

      {/* Pagination Strip (Scalable 20, 50, 100) */}
      {totalRecords > 0 && (
        <div className="px-4 py-3 bg-white rounded-xl border border-neutral-200 shadow-2xs flex flex-col sm:flex-row items-center justify-between gap-3 text-xs">
          <div className="flex items-center gap-2 text-neutral-500">
            <span>Rows per page:</span>
            <select
              id="select-page-size"
              value={pageSize}
              onChange={(e) => {
                setPageSize(Number(e.target.value));
                setCurrentPage(1);
              }}
              className="py-1 px-2 border border-neutral-300 rounded-lg bg-white text-neutral-800 font-semibold focus:outline-none"
            >
              <option value={20}>20</option>
              <option value={50}>50</option>
              <option value={100}>100</option>
            </select>
            <span>
              Showing{' '}
              <strong className="text-neutral-800">
                {(safeCurrentPage - 1) * pageSize + 1}
              </strong>{' '}
              to{' '}
              <strong className="text-neutral-800">
                {Math.min(safeCurrentPage * pageSize, totalRecords)}
              </strong>{' '}
              of <strong className="text-neutral-800">{totalRecords}</strong>
            </span>
          </div>

          <div className="flex items-center gap-1">
            <button
              id="btn-prev-page"
              type="button"
              disabled={safeCurrentPage <= 1}
              onClick={() => handlePageChange(safeCurrentPage - 1)}
              className="p-1.5 border border-neutral-300 rounded-lg bg-white text-neutral-600 hover:bg-neutral-100 disabled:opacity-40 disabled:cursor-not-allowed transition"
              title="Previous page"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>

            <div className="flex items-center gap-1 px-3 font-mono text-neutral-700 font-bold">
              Page {safeCurrentPage} of {totalPages}
            </div>

            <button
              id="btn-next-page"
              type="button"
              disabled={safeCurrentPage >= totalPages}
              onClick={() => handlePageChange(safeCurrentPage + 1)}
              className="p-1.5 border border-neutral-300 rounded-lg bg-white text-neutral-600 hover:bg-neutral-100 disabled:opacity-40 disabled:cursor-not-allowed transition"
              title="Next page"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}

      {/* CUSTOMER ID MIGRATION SUMMARY MODAL */}
      {showMigrationModal && (
        <div
          id="customer-migration-modal-overlay"
          className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/60 backdrop-blur-xs overflow-y-auto"
        >
          <div
            id="customer-migration-modal-container"
            className="bg-white rounded-xl shadow-2xl w-full max-w-lg overflow-hidden border border-neutral-200 my-auto"
          >
            <div className="flex items-center justify-between px-5 py-3.5 border-b border-neutral-200 bg-neutral-900 text-white">
              <div className="flex items-center gap-2">
                <ShieldCheck className="w-5 h-5 text-orange-400" />
                <h3 className="text-sm font-bold">Customer ID Migration Summary</h3>
              </div>
              <button
                type="button"
                onClick={() => setShowMigrationModal(false)}
                className="text-neutral-400 hover:text-white transition"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-5 space-y-4 text-xs">
              {migrationError ? (
                <div className="p-3 bg-red-50 border border-red-200 text-red-700 rounded-lg flex items-start gap-2">
                  <AlertCircle className="w-4 h-4 shrink-0 text-red-500 mt-0.5" />
                  <div>
                    <strong className="block">Migration Error:</strong>
                    <span>{migrationError}</span>
                  </div>
                </div>
              ) : migrationSummary ? (
                <>
                  <div className="p-3 bg-emerald-50 border border-emerald-200 text-emerald-900 rounded-lg flex items-start gap-2">
                    <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-600 mt-0.5" />
                    <div>
                      <p className="font-bold">Migration Completed Successfully</p>
                      <p className="text-[11px] text-emerald-800 mt-0.5">
                        Legacy customer identifiers have been normalized into canonical ST-CUST-XXXX format in-place without duplicating documents or breaking financial records.
                      </p>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-2.5">
                    <div className="bg-neutral-50 p-2.5 rounded-lg border border-neutral-200">
                      <span className="text-[10px] text-neutral-500 block uppercase font-bold">Inspected Records</span>
                      <span className="text-base font-black font-mono text-neutral-900">{migrationSummary.totalInspected}</span>
                    </div>
                    <div className="bg-neutral-50 p-2.5 rounded-lg border border-neutral-200">
                      <span className="text-[10px] text-neutral-500 block uppercase font-bold">Already Compliant</span>
                      <span className="text-base font-black font-mono text-emerald-600">{migrationSummary.alreadyCompliant}</span>
                    </div>
                    <div className="bg-neutral-50 p-2.5 rounded-lg border border-neutral-200">
                      <span className="text-[10px] text-neutral-500 block uppercase font-bold">Migrated In-Place</span>
                      <span className="text-base font-black font-mono text-orange-600">{migrationSummary.migratedCount}</span>
                    </div>
                    <div className="bg-neutral-50 p-2.5 rounded-lg border border-neutral-200">
                      <span className="text-[10px] text-neutral-500 block uppercase font-bold">Counter High Mark</span>
                      <span className="text-base font-black font-mono text-neutral-900">{migrationSummary.highestAllocatedCode}</span>
                    </div>
                  </div>

                  {migrationSummary.duplicatesDetected.length > 0 && (
                    <div className="p-2.5 bg-amber-50 border border-amber-200 text-amber-900 rounded-lg text-[11px]">
                      <p className="font-bold flex items-center gap-1 text-amber-800">
                        <AlertTriangle className="w-3.5 h-3.5 text-amber-600" />
                        Legacy ID Duplicates Detected:
                      </p>
                      <p className="mt-1 font-mono text-[10px]">
                        {migrationSummary.duplicatesDetected.join(', ')}
                      </p>
                      <p className="mt-1 text-amber-700">
                        Duplicate codes were safely allocated new unique sequential identifiers.
                      </p>
                    </div>
                  )}

                  <div className="text-[11px] text-neutral-500 space-y-1 bg-neutral-50 p-3 rounded-lg border border-neutral-200">
                    <p className="font-semibold text-neutral-700">Safety Guarantees Verified:</p>
                    <p>• Firebase document IDs remained 100% unchanged.</p>
                    <p>• Historical invoice.customerId references remained intact.</p>
                    <p>• Atomic counter in systemCounters/customerIdCounter synchronized to {migrationSummary.highestAllocatedCode}.</p>
                  </div>
                </>
              ) : null}

              <div className="flex justify-end pt-2">
                <button
                  type="button"
                  onClick={() => setShowMigrationModal(false)}
                  className="px-4 py-2 text-xs font-bold text-white bg-neutral-900 hover:bg-neutral-800 rounded-lg transition"
                >
                  Close Summary
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* DELETE CUSTOMER CONFIRMATION DIALOG */}
      {showDeleteDialog && customerToDelete && (
        <div
          id="delete-customer-modal-overlay"
          className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/60 backdrop-blur-xs overflow-y-auto"
          role="dialog"
          aria-modal="true"
          aria-labelledby="delete-customer-dialog-title"
          aria-describedby="delete-customer-dialog-desc"
          onClick={() => {
            if (!isDeleting) {
              setShowDeleteDialog(false);
              setCustomerToDelete(null);
              setDeleteError(null);
            }
          }}
        >
          <div
            id="delete-customer-modal-container"
            className="bg-white rounded-xl shadow-2xl w-full max-w-md overflow-hidden border border-neutral-200 my-auto animate-in fade-in zoom-in-95 duration-150"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="p-5 sm:p-6 space-y-4">
              <div className="flex items-start gap-3.5">
                <div className="w-10 h-10 rounded-full bg-rose-50 border border-rose-200 flex items-center justify-center shrink-0">
                  <Trash2 className="w-5 h-5 text-rose-600" aria-hidden="true" />
                </div>
                <div className="min-w-0 flex-1">
                  <h3 id="delete-customer-dialog-title" className="text-base font-bold text-neutral-900">
                    Delete Customer?
                  </h3>
                  <p id="delete-customer-dialog-desc" className="text-xs text-neutral-600 mt-1">
                    Are you sure you want to delete this customer? This action may not be reversible.
                  </p>
                </div>
              </div>

              {/* Customer Profile Identity Details */}
              <div className="p-3 bg-neutral-50 rounded-lg border border-neutral-200 text-xs space-y-1.5">
                <div className="flex items-center justify-between">
                  <span className="text-neutral-500 text-[11px]">Customer ID:</span>
                  <span className="font-mono font-bold text-neutral-900">
                    {customerToDelete.customerCode || customerToDelete.id}
                  </span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-neutral-500 text-[11px]">Name:</span>
                  <span className="font-semibold text-neutral-900 truncate max-w-[220px]">
                    {customerToDelete.name}
                  </span>
                </div>
                {customerToDelete.companyName && (
                  <div className="flex items-center justify-between">
                    <span className="text-neutral-500 text-[11px]">Company:</span>
                    <span className="text-neutral-700 truncate max-w-[220px]">
                      {customerToDelete.companyName}
                    </span>
                  </div>
                )}
                {customerToDelete.phone && (
                  <div className="flex items-center justify-between">
                    <span className="text-neutral-500 text-[11px]">Phone:</span>
                    <span className="font-mono text-neutral-700">{customerToDelete.phone}</span>
                  </div>
                )}
              </div>

              {/* Deletion Error (e.g. historical invoices or payments exist) */}
              {deleteError && (
                <div className="p-3 bg-rose-50 border border-rose-200 text-rose-800 rounded-lg text-xs flex items-start gap-2">
                  <AlertCircle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
                  <div className="min-w-0 flex-1">
                    <p className="font-bold text-rose-900">Cannot Delete Customer</p>
                    <p className="text-[11px] text-rose-700 mt-0.5 whitespace-pre-wrap">{deleteError}</p>
                  </div>
                </div>
              )}

              {/* Dialog Buttons */}
              <div className="flex items-center justify-end gap-2.5 pt-2 border-t border-neutral-100">
                <button
                  id="btn-cancel-delete-customer"
                  type="button"
                  disabled={isDeleting}
                  onClick={() => {
                    setShowDeleteDialog(false);
                    setCustomerToDelete(null);
                    setDeleteError(null);
                  }}
                  className="px-4 py-2 text-xs font-semibold text-neutral-700 bg-white hover:bg-neutral-100 border border-neutral-300 rounded-lg transition disabled:opacity-50"
                >
                  Cancel
                </button>
                <button
                  id="btn-confirm-delete-customer"
                  type="button"
                  disabled={isDeleting}
                  onClick={handleConfirmDelete}
                  className="px-4 py-2 text-xs font-bold text-white bg-rose-600 hover:bg-rose-700 active:bg-rose-800 rounded-lg shadow-sm transition disabled:opacity-50 inline-flex items-center gap-1.5"
                >
                  {isDeleting && (
                    <span className="w-3.5 h-3.5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                  )}
                  <span>{isDeleting ? 'Deleting...' : 'Delete'}</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
