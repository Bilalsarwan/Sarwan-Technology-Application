import React, { useState, useMemo, useRef, useCallback, useEffect } from 'react';
import { Invoice, Payment, BusinessSettings, UserProfile } from '../../types';
import { buildCanonicalInvoiceDocument } from '../../utils/canonicalInvoiceDocument';
import { prepareInvoicePrintDocument, printPreparedInvoice } from '../../utils/print';
import { CanonicalInvoiceDocument } from './CanonicalInvoiceDocument';
import { formatAFN } from '../../utils/format';
import {
  X,
  Download,
  Printer,
  Loader2,
  ZoomIn,
  ZoomOut,
  Maximize2,
  AlertTriangle,
  FileText,
} from 'lucide-react';

export interface InvoicePdfDownloadModalProps {
  isOpen: boolean;
  onClose: () => void;
  invoice: Invoice | null;
  payments: Payment[];
  settings: BusinessSettings;
  userProfile?: UserProfile | null;
  totalPaidOverride?: number;
}

export const InvoicePdfDownloadModal: React.FC<InvoicePdfDownloadModalProps> = ({
  isOpen,
  onClose,
  invoice,
  payments,
  settings,
  userProfile,
  totalPaidOverride,
}) => {
  const [zoom, setZoom] = useState<number>(1.0);
  const [isFitMode, setIsFitMode] = useState<boolean>(true);
  const [fitScale, setFitScale] = useState<number>(1.0);
  const [docHeight, setDocHeight] = useState<number>(1123);
  const [isPrintReady, setIsPrintReady] = useState<boolean>(false);
  const [isPrinting, setIsPrinting] = useState<boolean>(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  const previewContainerRef = useRef<HTMLDivElement>(null);
  const docRef = useRef<HTMLDivElement>(null);

  const activeScale = isFitMode ? fitScale : zoom;

  const updatePreviewScale = useCallback(() => {
    const container = previewContainerRef.current;
    if (!container) return;
    const containerWidth = container.clientWidth;
    if (containerWidth <= 0) return;

    // Responsive horizontal padding based on container width
    const minPadding = containerWidth <= 400 ? 8 : containerWidth <= 640 ? 12 : containerWidth <= 1024 ? 16 : 24;
    const availableWidth = Math.max(60, containerWidth - minPadding * 2);

    // Standard A4 width is 210mm (~793.7px at 96 CSS DPI)
    const a4WidthPx = 793.7;
    const rawScale = availableWidth / a4WidthPx;
    // On desktop: readable size (up to 1.0); on tablet & mobile: scale down to fit available width
    const calculatedScale = Math.max(0.2, Math.min(1.0, Math.round(rawScale * 1000) / 1000));
    setFitScale(calculatedScale);

    if (docRef.current) {
      const h = docRef.current.offsetHeight;
      if (h > 0) setDocHeight(h);
    }
  }, []);

  useEffect(() => {
    if (!isOpen) return;

    updatePreviewScale();
    const rafId = requestAnimationFrame(() => updatePreviewScale());

    const container = previewContainerRef.current;
    let resizeObserver: ResizeObserver | null = null;
    if (typeof ResizeObserver !== 'undefined') {
      resizeObserver = new ResizeObserver(() => updatePreviewScale());
      if (container) resizeObserver.observe(container);
      if (docRef.current) resizeObserver.observe(docRef.current);
    }

    const handleWindowResize = () => updatePreviewScale();
    window.addEventListener('resize', handleWindowResize);
    window.addEventListener('orientationchange', handleWindowResize);

    return () => {
      cancelAnimationFrame(rafId);
      if (resizeObserver) resizeObserver.disconnect();
      window.removeEventListener('resize', handleWindowResize);
      window.removeEventListener('orientationchange', handleWindowResize);
    };
  }, [isOpen, updatePreviewScale]);

  // Build canonical invoice document using the current saved invoice design automatically
  const exportDoc = useMemo(() => {
    if (!invoice) return null;
    return buildCanonicalInvoiceDocument({
      invoice,
      payments,
      settings,
      userProfile,
      totalPaidOverride,
    });
  }, [invoice, payments, settings, userProfile, totalPaidOverride]);

  // Prepare canonical print document into #invoice-print-root while the modal is open
  useEffect(() => {
    if (!isOpen || !exportDoc) {
      setIsPrintReady(false);
      return;
    }

    let active = true;
    setIsPrintReady(false);

    prepareInvoicePrintDocument(exportDoc)
      .then(() => {
        if (active) {
          setIsPrintReady(true);
        }
      })
      .catch((err) => {
        console.error('Failed to prepare print document:', err);
        if (active) {
          // Allow native print fallback anyway
          setIsPrintReady(true);
        }
      });

    return () => {
      active = false;
    };
  }, [isOpen, exportDoc]);

  if (!isOpen || !invoice || !exportDoc) return null;

  const handleZoomChange = (delta: number) => {
    setIsFitMode(false);
    setZoom((prev) => Math.max(0.3, Math.min(1.5, Math.round((prev + delta) * 100) / 100)));
  };

  const handleFitClick = () => {
    setIsFitMode(true);
    updatePreviewScale();
  };

  const handleResetZoom = () => {
    setIsFitMode(false);
    setZoom(1.0);
  };

  const handlePrint = async () => {
    if (!isPrintReady || isPrinting) return;
    setIsPrinting(true);
    setErrorMessage(null);

    // Synchronously starts window.open in user click turn (if embedded) or calls window.print (if top-level)
    try {
      await printPreparedInvoice();
      setIsPrinting(false);
    } catch (err: any) {
      console.error('Print failed:', err);
      setErrorMessage(
        err?.message ||
          'Your browser blocked the print window. Please allow pop-ups for this site and try again.'
      );
      setIsPrinting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-black/65 backdrop-blur-xs overflow-y-auto">
      <div className="bg-white rounded-xl shadow-2xl w-full max-w-5xl max-h-[94vh] flex flex-col overflow-hidden border border-neutral-200">
        {/* Top Header Bar */}
        <div className="px-4 py-3 sm:px-6 sm:py-3.5 bg-neutral-900 text-white flex items-center justify-between shrink-0 border-b border-neutral-800">
          <div className="flex items-center gap-2.5 sm:gap-3 min-w-0">
            <div className="p-2 bg-neutral-800 rounded-lg border border-neutral-700 shrink-0 text-orange-400">
              <FileText className="w-5 h-5" />
            </div>
            <div className="min-w-0">
              <div className="flex items-center gap-2 flex-wrap">
                <h2 className="text-sm sm:text-base font-bold text-white truncate">
                  Print / Save Invoice as PDF
                </h2>
                <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-neutral-800 border border-neutral-700 text-orange-400 font-bold shrink-0">
                  {invoice.billNumber}
                </span>
              </div>
              <p className="text-[11px] text-neutral-400 truncate">
                Customer: {invoice.customerSnapshot?.name || 'Customer'} • Total: {formatAFN(invoice.totalAmount)}
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            disabled={isPrinting}
            className="p-1.5 rounded-lg text-neutral-400 hover:text-white hover:bg-neutral-800 transition cursor-pointer disabled:opacity-50 shrink-0"
            title="Close"
            aria-label="Close"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Error Banner if generation failed */}
        {errorMessage && (
          <div className="px-4 py-2.5 bg-rose-50 border-b border-rose-200 text-rose-700 text-xs flex items-center justify-between shrink-0">
            <div className="flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 text-rose-600 shrink-0" />
              <span>{errorMessage}</span>
            </div>
            <button
              type="button"
              onClick={() => setErrorMessage(null)}
              className="text-rose-500 hover:text-rose-800"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        )}

        {/* Modal Body: Live Document Preview */}
        <div className="flex-1 flex flex-col bg-neutral-100 min-w-0 overflow-hidden">
          {/* Preview Toolbar */}
          <div className="px-4 py-2.5 bg-neutral-200/80 border-b border-neutral-300 flex items-center justify-between text-xs shrink-0">
            <div className="flex items-center gap-2">
              <span className="font-semibold text-neutral-700">Preview:</span>
              <span className="text-[11px] text-neutral-500 font-mono">
                ({exportDoc.paperConfig.paperSize} {exportDoc.paperConfig.orientation})
              </span>
            </div>

            {/* Zoom Controls */}
            <div className="flex items-center gap-1 bg-white rounded-lg border border-neutral-300 p-0.5 shadow-2xs">
              <button
                type="button"
                onClick={handleFitClick}
                className={`px-2 py-0.5 rounded text-[11px] font-semibold transition cursor-pointer ${
                  isFitMode
                    ? 'bg-blue-600 text-white shadow-2xs'
                    : 'bg-white text-neutral-700 hover:bg-neutral-100'
                }`}
                title="Fit to Screen"
              >
                Fit
              </button>
              <div className="w-px h-3 bg-neutral-200 mx-0.5" />
              <button
                type="button"
                onClick={() => handleZoomChange(-0.1)}
                disabled={activeScale <= 0.3}
                className="p-1 text-neutral-600 hover:text-neutral-900 hover:bg-neutral-100 rounded disabled:opacity-40 cursor-pointer"
                title="Zoom Out"
              >
                <ZoomOut className="w-3.5 h-3.5" />
              </button>
              <span className="text-[11px] font-mono px-1.5 text-neutral-700 min-w-[42px] text-center">
                {Math.round(activeScale * 100)}%
              </span>
              <button
                type="button"
                onClick={() => handleZoomChange(0.1)}
                disabled={activeScale >= 1.5}
                className="p-1 text-neutral-600 hover:text-neutral-900 hover:bg-neutral-100 rounded disabled:opacity-40 cursor-pointer"
                title="Zoom In"
              >
                <ZoomIn className="w-3.5 h-3.5" />
              </button>
              <div className="w-px h-3 bg-neutral-200 mx-0.5" />
              <button
                type="button"
                onClick={handleResetZoom}
                className={`px-1.5 py-0.5 rounded text-[11px] font-medium transition cursor-pointer ${
                  !isFitMode && Math.abs(zoom - 1.0) < 0.01
                    ? 'bg-neutral-800 text-white'
                    : 'text-neutral-600 hover:text-neutral-900 hover:bg-neutral-100'
                }`}
                title="100% Actual Size"
              >
                <Maximize2 className="w-3.5 h-3.5 inline mr-1" />
                100%
              </button>
            </div>
          </div>

          {/* Responsive A4 Preview Viewport */}
          <div
            ref={previewContainerRef}
            className="flex-1 overflow-x-hidden overflow-y-auto p-2 sm:p-4 md:p-6 flex flex-col items-center overscroll-contain bg-neutral-200/60"
            style={{ boxSizing: 'border-box' }}
          >
            <div
              style={{
                width: `${Math.round(793.7 * activeScale)}px`,
                height: `${Math.round(docHeight * activeScale)}px`,
                position: 'relative',
                margin: '0 auto 60px auto',
                flexShrink: 0,
                transition: 'width 0.15s ease-out, height 0.15s ease-out',
              }}
            >
              <div
                ref={docRef}
                style={{
                  position: 'absolute',
                  top: 0,
                  left: 0,
                  width: '210mm',
                  minWidth: '210mm',
                  transform: `scale(${activeScale})`,
                  transformOrigin: 'top left',
                  transition: 'transform 0.15s ease-out',
                }}
                className="shadow-2xl bg-white border border-neutral-300 rounded"
              >
                <CanonicalInvoiceDocument
                  document={exportDoc}
                  id="invoice-pdf-download-document"
                />
              </div>
            </div>
          </div>
        </div>

        {/* Modal Footer */}
        <div className="px-4 py-3 sm:px-6 sm:py-3.5 bg-neutral-50 border-t border-neutral-200 flex flex-col sm:flex-row items-center justify-between gap-3 shrink-0">
          <div className="text-xs text-neutral-600 flex items-center gap-2">
            <span className="font-semibold text-neutral-800">Export Details:</span>
            <span className="font-mono text-neutral-600">
              {exportDoc.items.length} item{exportDoc.items.length !== 1 ? 's' : ''} • {exportDoc.paperConfig.paperSize} PDF
            </span>
          </div>

          <div className="flex items-center gap-2 w-full sm:w-auto justify-end">
            <button
              type="button"
              onClick={onClose}
              disabled={isPrinting}
              className="px-4 py-2 text-xs font-semibold rounded-lg bg-white hover:bg-neutral-100 border border-neutral-300 text-neutral-700 transition cursor-pointer disabled:opacity-50"
            >
              Cancel
            </button>
            <button
              type="button"
              onClick={handlePrint}
              disabled={!isPrintReady || isPrinting}
              className="px-5 py-2 text-xs font-bold rounded-lg bg-orange-600 hover:bg-orange-500 text-white transition inline-flex items-center justify-center gap-2 shadow-sm cursor-pointer disabled:opacity-50 active:scale-95 min-w-[170px]"
              title="Print or Save Invoice as PDF"
              aria-label="Print or Save Invoice as PDF"
            >
              {!isPrintReady ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin shrink-0" />
                  <span>Preparing Print...</span>
                </>
              ) : isPrinting ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin shrink-0" />
                  <span>Printing...</span>
                </>
              ) : (
                <>
                  <Printer className="w-4 h-4 shrink-0" />
                  <span>Print / Save as PDF</span>
                </>
              )}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default InvoicePdfDownloadModal;
