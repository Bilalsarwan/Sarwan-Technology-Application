import React, { useState, useEffect, useMemo, useRef, useCallback } from 'react';
import {
  Customer,
  Invoice,
  InvoiceItem,
  BusinessSettings,
  CustomerSnapshot,
  CompanySnapshot,
  UserProfile,
} from '../../types';
import {
  createDefault20Items,
  createInvoiceWithAtomicNumber,
  updateInvoice,
  saveCustomer,
  subscribeToUsers,
} from '../../services/db';
import {
  calculateLineTotal,
  calculateInvoiceTotal,
  calculateRemaining,
  formatAFN,
  formatInvoiceNumber,
  getTodayDateString,
} from '../../utils/format';
import { buildCanonicalInvoiceDocument } from '../../utils/canonicalInvoiceDocument';
import { CanonicalInvoiceDocument } from './CanonicalInvoiceDocument';
import { InvoicePdfDownloadModal } from './InvoicePdfDownloadModal';
import { useAuth } from '../../context/AuthContext';
import { resolveTemplates } from '../../utils/defaultCustomTemplates';
import {
  X,
  Plus,
  Trash2,
  Eye,
  Download,
  Printer,
  Save,
  CheckCircle,
  AlertCircle,
  UserPlus,
  Loader2,
  Lock,
} from 'lucide-react';
import { normalizeCustomerStatus } from '../../utils/customerValidation';

interface InvoiceModalProps {
  isOpen: boolean;
  onClose: () => void;
  customers: Customer[];
  settings: BusinessSettings;
  users?: UserProfile[];
  invoiceToEdit?: Invoice | null;
  onSuccess?: (createdInvoice: Invoice) => void;
  preselectedCustomer?: Customer | null;
  isCustomerLocked?: boolean;
}

export const InvoiceModal: React.FC<InvoiceModalProps> = ({
  isOpen,
  onClose,
  customers,
  settings,
  users,
  invoiceToEdit,
  onSuccess,
  preselectedCustomer,
  isCustomerLocked = false,
}) => {
  const { userProfile } = useAuth();
  const [localUsers, setLocalUsers] = useState<UserProfile[]>([]);
  const [assignedCollectorId, setAssignedCollectorId] = useState<string>('');
  const [selectedCustomerId, setSelectedCustomerId] = useState<string>('');
  const [customerName, setCustomerName] = useState<string>('');
  const [customerPhone, setCustomerPhone] = useState<string>('');
  const [customerAddress, setCustomerAddress] = useState<string>('');
  const [customerCompany, setCustomerCompany] = useState<string>('');
  const [isNewCustomer, setIsNewCustomer] = useState<boolean>(false);

  // Fallback to real-time subscription if users prop is not provided or empty
  useEffect(() => {
    if (users && users.length > 0) return;
    const unsub = subscribeToUsers((data) => {
      setLocalUsers(data);
    });
    return () => unsub();
  }, [users]);

  const availableUsers = users && users.length > 0 ? users : localUsers;

  // Active payment collectors only
  const activeCollectors = useMemo(() => {
    return (availableUsers || []).filter(
      (u) =>
        u.role === 'payment_collector' &&
        !u.isDeactivated &&
        u.status !== 'deactivated' &&
        u.status !== 'archived'
    );
  }, [availableUsers]);

  const [date, setDate] = useState<string>(getTodayDateString());
  const [items, setItems] = useState<InvoiceItem[]>(createDefault20Items());
  const [note, setNote] = useState<string>('');
  const [initialCashPaid, setInitialCashPaid] = useState<number | ''>('');
  const [initialCashNote, setInitialCashNote] = useState<string>('Initial cash upon billing');

  const availableTemplates = useMemo(() => {
    return resolveTemplates(settings.customTemplates);
  }, [settings.customTemplates]);

  const [selectedTemplateId, setSelectedTemplateId] = useState<string>(() => {
    if (invoiceToEdit?.templateId) return invoiceToEdit.templateId;
    return settings.activeTemplateId || '';
  });

  const [isPreviewOpen, setIsPreviewOpen] = useState<boolean>(false);
  const [isPdfModalOpen, setIsPdfModalOpen] = useState<boolean>(false);
  const [saving, setSaving] = useState<boolean>(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  // Responsive A4 Preview Scaling for Draft Preview Modal
  const previewContainerRef = useRef<HTMLDivElement>(null);
  const docRef = useRef<HTMLDivElement>(null);
  const [previewScale, setPreviewScale] = useState<number>(1);
  const [docHeight, setDocHeight] = useState<number>(1123);

  const updatePreviewScale = useCallback(() => {
    const container = previewContainerRef.current;
    if (!container) return;
    const containerWidth = container.clientWidth;
    if (containerWidth <= 0) return;

    const minPadding = containerWidth <= 400 ? 8 : containerWidth <= 640 ? 12 : containerWidth <= 1024 ? 16 : 24;
    const availableWidth = Math.max(60, containerWidth - minPadding * 2);
    const a4WidthPx = 793.7;
    const rawScale = availableWidth / a4WidthPx;
    const calculatedScale = Math.max(0.2, Math.min(1.0, Math.round(rawScale * 1000) / 1000));
    setPreviewScale(calculatedScale);

    if (docRef.current) {
      const h = docRef.current.offsetHeight;
      if (h > 0) setDocHeight(h);
    }
  }, []);

  useEffect(() => {
    if (!isPreviewOpen) return;

    updatePreviewScale();
    const rafId = requestAnimationFrame(() => updatePreviewScale());

    const container = previewContainerRef.current;
    let resizeObserver: ResizeObserver | null = null;
    if (typeof ResizeObserver !== 'undefined') {
      resizeObserver = new ResizeObserver(() => updatePreviewScale());
      if (container) resizeObserver.observe(container);
      if (docRef.current) resizeObserver.observe(docRef.current);
    }

    const handleWindowResize = () => updatePreviewScale();
    window.addEventListener('resize', handleWindowResize);
    window.addEventListener('orientationchange', handleWindowResize);

    return () => {
      cancelAnimationFrame(rafId);
      if (resizeObserver) resizeObserver.disconnect();
      window.removeEventListener('resize', handleWindowResize);
      window.removeEventListener('orientationchange', handleWindowResize);
    };
  }, [isPreviewOpen, updatePreviewScale]);

  // Determine if editing a locked or fully paid or void invoice
  const isInvoiceLocked = Boolean(
    invoiceToEdit &&
    (invoiceToEdit.isLocked ||
      invoiceToEdit.isVoid ||
      invoiceToEdit.status === 'Void' ||
      invoiceToEdit.status === 'Paid' ||
      (Number(invoiceToEdit.totalAmount) > 0 &&
        (Number(invoiceToEdit.totalPaid) >= Number(invoiceToEdit.totalAmount) ||
          Number(invoiceToEdit.remaining) <= 0)))
  );

  // Initialize or reset form
  useEffect(() => {
    if (!isOpen) return;

    // Safety guard: The Edit Invoice modal/form must NOT open for a locked invoice
    if (invoiceToEdit && isInvoiceLocked) {
      console.warn(
        'Cannot open edit modal for locked / fully paid invoice:',
        invoiceToEdit.billNumber
      );
      onClose();
      return;
    }

    if (invoiceToEdit) {
      setSelectedCustomerId(invoiceToEdit.customerId);
      setCustomerName(invoiceToEdit.customerSnapshot.name);
      setCustomerPhone(invoiceToEdit.customerSnapshot.phone);
      setCustomerAddress(invoiceToEdit.customerSnapshot.address || '');
      setCustomerCompany(invoiceToEdit.customerSnapshot.companyName || '');
      setDate(invoiceToEdit.date);
      setNote(invoiceToEdit.note || '');
      setIsNewCustomer(false);
      setAssignedCollectorId(invoiceToEdit.assignedCollectorId || '');

      // Load all items dynamically without truncating beyond 20
      let loadedItems: InvoiceItem[] = [];
      if (invoiceToEdit.items && invoiceToEdit.items.length > 0) {
        if (invoiceToEdit.items.length < 20) {
          // If invoice had fewer than 20 rows, pad to 20 for backward compatibility
          const padded = createDefault20Items();
          invoiceToEdit.items.forEach((it, idx) => {
            padded[idx] = { ...it, sNo: idx + 1 };
          });
          loadedItems = padded;
        } else {
          // 20 or more rows: load ALL items dynamically without any truncation!
          loadedItems = invoiceToEdit.items.map((it, idx) => ({
            ...it,
            sNo: idx + 1,
          }));
        }
      } else {
        loadedItems = createDefault20Items();
      }
      setItems(loadedItems);
      setInitialCashPaid('');
      setSelectedTemplateId(invoiceToEdit.templateId || settings.activeTemplateId || '');
    } else if (preselectedCustomer) {
      setSelectedCustomerId(preselectedCustomer.id);
      setCustomerName(preselectedCustomer.name);
      setCustomerPhone(preselectedCustomer.phone);
      setCustomerAddress(preselectedCustomer.address || '');
      setCustomerCompany(preselectedCustomer.companyName || '');
      setIsNewCustomer(false);
      setDate(getTodayDateString());
      setItems(createDefault20Items());
      setNote(settings.invoiceNote || '');
      setInitialCashPaid('');
      setInitialCashNote('Initial cash upon billing');
      setAssignedCollectorId('');
      setSelectedTemplateId(settings.activeTemplateId || '');
    } else {
      setSelectedCustomerId('');
      setCustomerName('');
      setCustomerPhone('');
      setCustomerAddress('');
      setCustomerCompany('');
      setIsNewCustomer(false);
      setDate(getTodayDateString());
      setItems(createDefault20Items());
      setNote(settings.invoiceNote || '');
      setInitialCashPaid('');
      setInitialCashNote('Initial cash upon billing');
      setAssignedCollectorId('');
      setSelectedTemplateId(settings.activeTemplateId || '');
    }
    setIsPreviewOpen(false);
    setErrorMessage(null);
  }, [isOpen, invoiceToEdit, settings, preselectedCustomer]);

  // When customer is selected from dropdown
  const handleSelectCustomer = (customerId: string) => {
    setSelectedCustomerId(customerId);
    setIsNewCustomer(false);
    const found = customers.find((c) => c.id === customerId);
    if (found) {
      const normStatus = normalizeCustomerStatus(found.status, found.isArchived);
      if (normStatus === 'Inactive' || normStatus === 'Blocked') {
        setErrorMessage(
          `Cannot create invoice for "${found.name}": Account is ${normStatus}. Inactive and Blocked accounts cannot receive invoices.`
        );
      } else {
        setErrorMessage(null);
      }
      setCustomerName(found.name);
      setCustomerPhone(found.phone);
      setCustomerAddress(found.address || '');
      setCustomerCompany(found.companyName || '');
    } else {
      setCustomerName('');
      setCustomerPhone('');
      setCustomerAddress('');
      setCustomerCompany('');
    }
  };

  const handleAddItem = () => {
    setItems((prev) => [
      ...prev,
      {
        sNo: prev.length + 1,
        description: '',
        quantity: '',
        unitPrice: '',
        totalAmount: 0,
      },
    ]);
  };

  const handleRemoveItem = (index: number) => {
    setItems((prev) => {
      if (prev.length <= 1) {
        return [
          {
            sNo: 1,
            description: '',
            quantity: '',
            unitPrice: '',
            totalAmount: 0,
          },
        ];
      }
      const filtered = prev.filter((_, idx) => idx !== index);
      return filtered.map((item, idx) => ({
        ...item,
        sNo: idx + 1,
      }));
    });
  };

  const handleItemChange = (
    index: number,
    field: 'description' | 'quantity' | 'unitPrice',
    value: string
  ) => {
    setItems((prev) => {
      const updated = [...prev];
      const item = { ...updated[index] };

      if (field === 'description') {
        item.description = value;
      } else if (field === 'quantity') {
        item.quantity = value === '' ? '' : Math.max(0, Number(value));
      } else if (field === 'unitPrice') {
        item.unitPrice = value === '' ? '' : Math.max(0, Number(value));
      }

      item.totalAmount = calculateLineTotal(item.quantity, item.unitPrice);
      item.sNo = index + 1;
      updated[index] = item;
      return updated;
    });
  };

  const invoiceTotal = calculateInvoiceTotal(items);
  const paidCashAmount = typeof initialCashPaid === 'number' ? initialCashPaid : 0;
  const remainingBalance = calculateRemaining(invoiceTotal, paidCashAmount);

  // Projected Bill Number
  const nextNumber = settings.nextInvoiceNumber || 1060;
  const prefix = settings.invoicePrefix || 'ST-';
  const projectedBillNo = invoiceToEdit ? invoiceToEdit.billNumber : `${prefix}${nextNumber}`;

  const validateForm = (): boolean => {
    if (!customerName.trim()) {
      setErrorMessage('Customer name is required.');
      return false;
    }
    if (!customerPhone.trim()) {
      setErrorMessage('Customer phone number is required.');
      return false;
    }
    if (invoiceTotal <= 0) {
      setErrorMessage('Please enter at least one invoice item with valid quantity and unit price.');
      return false;
    }
    if (paidCashAmount > invoiceTotal) {
      setErrorMessage('Paid cash amount cannot exceed the total invoice amount.');
      return false;
    }
    if (selectedCustomerId) {
      const found = customers.find((c) => c.id === selectedCustomerId);
      if (found) {
        const normStatus = normalizeCustomerStatus(found.status, found.isArchived);
        if (normStatus === 'Inactive' || normStatus === 'Blocked') {
          setErrorMessage(`Cannot create invoice for customer "${found.name}": Account is ${normStatus}.`);
          return false;
        }
      }
    }
    setErrorMessage(null);
    return true;
  };

  // Construct snapshot objects
  const customerSnapshot: CustomerSnapshot = {
    id: selectedCustomerId,
    name: customerName.trim(),
    phone: customerPhone.trim(),
    address: customerAddress.trim(),
    companyName: customerCompany.trim(),
  };

  const companySnapshot: CompanySnapshot = {
    companyName: settings.companyName,
    logo: settings.logo || '/sarwan-logo.png',
    phone: settings.phone,
    whatsapp: settings.whatsapp,
    email: settings.email,
    address: settings.address,
    currency: settings.currency || 'AFN',
    invoiceNote: settings.invoiceNote,
  };

  const previewInvoice: Invoice = useMemo(() => {
    return {
      id: invoiceToEdit?.id || 'draft-preview',
      billNumber: projectedBillNo,
      date,
      items,
      totalAmount: invoiceTotal,
      totalPaid: paidCashAmount,
      remaining: Math.max(0, invoiceTotal - paidCashAmount),
      status:
        invoiceToEdit?.status ||
        (paidCashAmount >= invoiceTotal && invoiceTotal > 0
          ? 'Paid'
          : paidCashAmount > 0
          ? 'Partially Paid'
          : 'Unpaid'),
      customerSnapshot,
      companySnapshot,
      note,
      isVoid: Boolean(invoiceToEdit?.isVoid || invoiceToEdit?.status === 'Void'),
      isLocked: isInvoiceLocked,
      createdAt: invoiceToEdit?.createdAt || new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      customerId: selectedCustomerId,
    };
  }, [
    invoiceToEdit,
    projectedBillNo,
    date,
    items,
    invoiceTotal,
    paidCashAmount,
    customerSnapshot,
    companySnapshot,
    note,
    isInvoiceLocked,
    selectedCustomerId,
  ]);

  const previewCanonicalDoc = useMemo(() => {
    return buildCanonicalInvoiceDocument({
      invoice: {
        id: invoiceToEdit?.id || 'draft-preview',
        billNumber: projectedBillNo,
        date,
        items,
        totalAmount: invoiceTotal,
        customerSnapshot,
        companySnapshot,
        note,
        status: invoiceToEdit?.status || 'Unpaid',
        isVoid: Boolean(invoiceToEdit?.isVoid || invoiceToEdit?.status === 'Void'),
        isLocked: isInvoiceLocked,
        templateId: selectedTemplateId || undefined,
      },
      totalPaidOverride: paidCashAmount,
      settings,
      userProfile,
    });
  }, [
    invoiceToEdit,
    projectedBillNo,
    date,
    items,
    invoiceTotal,
    customerSnapshot,
    companySnapshot,
    note,
    isInvoiceLocked,
    paidCashAmount,
    selectedTemplateId,
    settings,
    userProfile,
  ]);

  const handleDownloadPreviewPdf = () => {
    if (!previewInvoice) return;
    setIsPdfModalOpen(true);
  };

  const handleSaveInvoice = async () => {
    if (!validateForm()) return;
    setSaving(true);
    setErrorMessage(null);

    try {
      let custId = selectedCustomerId;

      // If new customer or not in database, create in customers collection
      if (isNewCustomer || !custId) {
        custId = await saveCustomer({
          name: customerName.trim(),
          phone: customerPhone.trim(),
          address: customerAddress.trim(),
          companyName: customerCompany.trim(),
          note: 'Created during invoice creation',
        });
        customerSnapshot.id = custId;
      }

      const sanitizedItems = items.map((it, idx) => ({
        ...it,
        sNo: idx + 1,
        totalAmount: calculateLineTotal(it.quantity, it.unitPrice),
      }));

      if (invoiceToEdit) {
        if (isInvoiceLocked) {
          throw new Error(
            invoiceToEdit.isVoid || invoiceToEdit.status === 'Void'
              ? 'This invoice is void. Void invoices cannot be modified.'
              : 'This invoice is locked because it is fully paid. Locked invoices cannot be modified.'
          );
        }
        // Update existing invoice
        await updateInvoice(
          invoiceToEdit.id,
          {
            customerId: custId,
            customerSnapshot,
            date,
            items: sanitizedItems,
            totalAmount: invoiceTotal,
            note,
            templateId: selectedTemplateId || undefined,
          },
          invoiceToEdit.totalPaid || 0,
          userProfile?.id || 'system',
          userProfile?.name || 'User',
          invoiceToEdit
        );
        onClose();
      } else {
        // Create new invoice with atomic sequential numbering starting from ST-1060 as quotation
        const created = await createInvoiceWithAtomicNumber({
          customerId: custId,
          customerSnapshot,
          companySnapshot,
          date,
          items: sanitizedItems,
          totalAmount: invoiceTotal,
          note,
          userId: userProfile?.id,
          userName: userProfile?.name,
          templateId: selectedTemplateId || undefined,
          billingState: 'quotation',
        });

        if (onSuccess) onSuccess(created);
        onClose();
      }
    } catch (err: any) {
      console.error('Save invoice error:', err);
      setErrorMessage(err.message || 'Failed to save invoice. Please check database connection.');
    } finally {
      setSaving(false);
    }
  };

  if (!isOpen || (invoiceToEdit && isInvoiceLocked)) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-black/60 backdrop-blur-xs overflow-y-auto">
      <div className="bg-white rounded-xl shadow-2xl w-full max-w-5xl my-6 flex flex-col max-h-[92vh] overflow-hidden border border-neutral-200">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-neutral-200 bg-neutral-900 text-white">
          <div className="flex items-center gap-3">
            <div
              className="w-9 h-9 bg-white flex items-center justify-center shrink-0 overflow-hidden p-1 shadow-xs"
              style={{ borderRadius: '100%', border: 'none' }}
            >
              <img
                src={settings?.logo || '/sarwan-logo.png'}
                alt="Sarwan Logo"
                className="max-h-full max-w-full object-contain"
                onError={(e) => {
                  const target = e.currentTarget;
                  if (target.src.endsWith('.png')) target.src = '/sarwan-logo.svg';
                }}
              />
            </div>
            <div>
              <div className="flex items-center gap-2 flex-wrap">
                <h2 className="text-lg font-bold">
                  {invoiceToEdit ? `Edit Invoice (${invoiceToEdit.billNumber})` : 'New Invoice'}
                </h2>
                {!invoiceToEdit && (
                  <span className="text-[10px] font-bold px-2 py-0.5 bg-amber-500/20 text-amber-300 border border-amber-400/40 rounded-full">
                    Quotation / Pending Approval
                  </span>
                )}
              </div>
              <p className="text-xs text-orange-400">
                Bill Number: <span className="font-mono font-bold">{projectedBillNo}</span>
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={() => {
                if (validateForm()) setIsPreviewOpen(true);
              }}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded bg-neutral-800 hover:bg-neutral-700 text-neutral-200 border border-neutral-700 transition"
              title="Preview A4 Invoice"
            >
              <Eye className="w-3.5 h-3.5 text-orange-400" />
              Preview Invoice
            </button>
            <button
              onClick={onClose}
              className="p-1.5 rounded-lg text-neutral-400 hover:text-white hover:bg-neutral-800 transition"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Modal Body */}
        <div className="p-4 sm:p-6 overflow-y-auto flex-1 space-y-6">
          {errorMessage && (
            <div className="p-3 bg-red-50 border border-red-200 rounded-lg flex items-center gap-2 text-xs text-red-700">
              <AlertCircle className="w-4 h-4 shrink-0 text-red-500" />
              <span>{errorMessage}</span>
            </div>
          )}

          {/* Section 1: Customer & Invoice Details */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 bg-neutral-50 p-4 rounded-lg border border-neutral-200">
            {/* Customer Selector / Creator */}
            <div className="space-y-1.5 md:col-span-2">
              <div className="flex items-center justify-between">
                <label className="text-xs font-bold text-neutral-700 uppercase tracking-wide">
                  Customer Information *
                </label>
                {!isCustomerLocked && (
                  <button
                    type="button"
                    onClick={() => {
                      setIsNewCustomer(!isNewCustomer);
                      if (!isNewCustomer) {
                        setSelectedCustomerId('');
                        setCustomerName('');
                        setCustomerPhone('');
                        setCustomerAddress('');
                        setCustomerCompany('');
                      }
                    }}
                    className="text-xs text-orange-600 hover:text-orange-700 font-semibold inline-flex items-center gap-1"
                  >
                    <UserPlus className="w-3 h-3" />
                    {isNewCustomer ? 'Select Existing Customer' : '+ New Customer'}
                  </button>
                )}
              </div>

              {isCustomerLocked ? (
                <div className="flex items-center gap-2 p-2.5 bg-neutral-100 border border-neutral-300 rounded-lg text-xs font-semibold text-neutral-800">
                  <Lock className="w-4 h-4 text-orange-600 shrink-0" />
                  <span>
                    Locked to Customer:{' '}
                    <strong className="font-mono text-neutral-900 font-bold">
                      {customers.find((c) => c.id === selectedCustomerId)?.customerCode || preselectedCustomer?.customerCode || selectedCustomerId}
                    </strong>{' '}
                    — {customerName}
                  </span>
                </div>
              ) : !isNewCustomer ? (
                <div>
                  <select
                    value={selectedCustomerId}
                    onChange={(e) => handleSelectCustomer(e.target.value)}
                    className="w-full text-sm border border-neutral-300 rounded px-3 py-2 bg-white focus:outline-none focus:ring-1 focus:ring-orange-500"
                  >
                    <option value="">-- Choose Existing Customer --</option>
                    {customers.map((c) => {
                      const normSt = normalizeCustomerStatus(c.status, c.isArchived);
                      const isBlockedOrInactive = normSt === 'Inactive' || normSt === 'Blocked';
                      return (
                        <option key={c.id} value={c.id} disabled={isBlockedOrInactive}>
                          {c.customerCode || c.id} — {c.name} ({c.phone}){' '}
                          {c.companyName ? `• ${c.companyName}` : ''}{' '}
                          {isBlockedOrInactive ? `[${normSt} - Invoices Blocked]` : ''}
                        </option>
                      );
                    })}
                  </select>
                </div>
              ) : null}

              {/* Customer fields */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
                <div>
                  <label className="text-[11px] font-semibold text-neutral-600 block">
                    Customer Name *
                  </label>
                  <input
                    type="text"
                    value={customerName ?? ''}
                    onChange={(e) => setCustomerName(e.target.value)}
                    placeholder="e.g. Ahmad Khan"
                    className="w-full text-sm border border-neutral-300 rounded px-3 py-1.5 focus:outline-none focus:ring-1 focus:ring-orange-500"
                  />
                </div>
                <div>
                  <label className="text-[11px] font-semibold text-neutral-600 block">
                    Phone Number *
                  </label>
                  <input
                    type="text"
                    value={customerPhone ?? ''}
                    onChange={(e) => setCustomerPhone(e.target.value)}
                    placeholder="e.g. 0799123456"
                    className="w-full text-sm border border-neutral-300 rounded px-3 py-1.5 focus:outline-none focus:ring-1 focus:ring-orange-500 font-mono"
                  />
                </div>
                <div>
                  <label className="text-[11px] font-semibold text-neutral-600 block">
                    Shop / Company Name
                  </label>
                  <input
                    type="text"
                    value={customerCompany ?? ''}
                    onChange={(e) => setCustomerCompany(e.target.value)}
                    placeholder="e.g. Kabul Plaza Electronics"
                    className="w-full text-sm border border-neutral-300 rounded px-3 py-1.5 focus:outline-none focus:ring-1 focus:ring-orange-500"
                  />
                </div>
                <div>
                  <label className="text-[11px] font-semibold text-neutral-600 block">
                    Address / Location
                  </label>
                  <input
                    type="text"
                    value={customerAddress ?? ''}
                    onChange={(e) => setCustomerAddress(e.target.value)}
                    placeholder="e.g. Dehbori, Kabul"
                    className="w-full text-sm border border-neutral-300 rounded px-3 py-1.5 focus:outline-none focus:ring-1 focus:ring-orange-500"
                  />
                </div>
              </div>
            </div>

            {/* Invoice Meta */}
            <div className="space-y-3 md:border-l md:border-neutral-200 md:pl-4">
              <div>
                <label className="text-[11px] font-semibold text-neutral-600 block">
                  Bill Number
                </label>
                <div className="text-sm font-bold font-mono text-neutral-900 bg-neutral-200/70 border border-neutral-300 px-3 py-1.5 rounded">
                  {projectedBillNo}
                </div>
              </div>
              <div>
                <label className="text-[11px] font-semibold text-neutral-600 block">
                  Invoice Date *
                </label>
                <input
                  type="date"
                  value={date}
                  onChange={(e) => setDate(e.target.value)}
                  className="w-full text-sm border border-neutral-300 rounded px-3 py-1.5 focus:outline-none focus:ring-1 focus:ring-orange-500 font-mono"
                />
              </div>
              <div>
                <label className="text-[11px] font-semibold text-neutral-600 block">Currency</label>
                <div className="text-xs font-bold text-neutral-800 bg-white border border-neutral-200 px-3 py-1.5 rounded">
                  AFN (Afghan Afghani)
                </div>
              </div>
              <div>
                <label className="text-[11px] font-semibold text-neutral-600 block">
                  Invoice Layout / Template
                </label>
                <select
                  value={selectedTemplateId}
                  onChange={(e) => setSelectedTemplateId(e.target.value)}
                  className="w-full text-xs font-medium border border-neutral-300 rounded px-2.5 py-1.5 bg-white focus:outline-none focus:ring-1 focus:ring-orange-500 cursor-pointer"
                >
                  <option value="">Default Company Layout</option>
                  {availableTemplates.map((t) => (
                    <option key={t.id} value={t.id}>
                      [{t.category}] {t.name} {t.targetServiceOrClient ? `• ${t.targetServiceOrClient}` : ''}
                    </option>
                  ))}
                </select>
              </div>
              {!invoiceToEdit && (
                <div>
                  <label className="text-[11px] font-semibold text-neutral-600 block">
                    Assign Collector
                  </label>
                  <div className="text-xs text-neutral-500 italic bg-neutral-100 border border-neutral-200 rounded px-3 py-2">
                    Disabled for Quotations (Becomes available once accepted / marked as payable)
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Section 2: Dynamic Items Table */}
          <div className="space-y-2">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div className="flex items-center gap-2">
                <label className="text-xs font-bold text-neutral-800 uppercase tracking-wide">
                  Invoice Items
                </label>
                <span className="text-[11px] font-mono font-medium px-2 py-0.5 rounded-full bg-neutral-100 text-neutral-600 border border-neutral-200">
                  {items.length} {items.length === 1 ? 'row' : 'rows'}
                </span>
              </div>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={handleAddItem}
                  className="px-3 py-1 text-xs font-semibold rounded-lg bg-neutral-900 hover:bg-neutral-800 text-white flex items-center gap-1.5 transition shadow-xs cursor-pointer"
                >
                  <Plus className="w-3.5 h-3.5" />
                  Add Item
                </button>
              </div>
            </div>

            <div className="border border-neutral-300 rounded-lg overflow-x-auto shadow-xs">
              <table className="w-full border-collapse text-xs">
                <thead>
                  <tr className="bg-neutral-900 text-white font-semibold">
                    <th className="py-2 px-2 text-center w-12 border-r border-neutral-800">S.No</th>
                    <th className="py-2 px-3 text-left border-r border-neutral-800">Description</th>
                    <th className="py-2 px-2 text-center w-24 border-r border-neutral-800">Quantity</th>
                    <th className="py-2 px-3 text-right w-32 border-r border-neutral-800">
                      Price (AFN)
                    </th>
                    <th className="py-2 px-3 text-right w-36 border-r border-neutral-800">Total Amount</th>
                    <th className="py-2 px-1 text-center w-10"></th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-neutral-200 bg-white">
                  {items.map((item, index) => {
                    const lineTotal = calculateLineTotal(item.quantity, item.unitPrice);
                    return (
                      <tr key={index} className="hover:bg-neutral-50/70 transition">
                        <td className="py-1 px-2 text-center text-neutral-500 font-mono border-r border-neutral-200">
                          {index + 1}
                        </td>
                        <td className="py-1 px-2 border-r border-neutral-200">
                          <input
                            type="text"
                            value={item.description ?? ''}
                            onChange={(e) => handleItemChange(index, 'description', e.target.value)}
                            placeholder={index === 0 ? 'e.g. 5MP Hikvision IP Bullet Camera' : ''}
                            className="w-full text-xs px-2 py-1 border border-transparent hover:border-neutral-300 focus:border-orange-500 focus:bg-orange-50/30 rounded outline-none"
                          />
                        </td>
                        <td className="py-1 px-1 border-r border-neutral-200">
                          <input
                            type="number"
                            min="0"
                            step="any"
                            value={item.quantity ?? ''}
                            onChange={(e) => handleItemChange(index, 'quantity', e.target.value)}
                            placeholder=""
                            className="w-full text-xs text-center font-mono px-2 py-1 border border-transparent hover:border-neutral-300 focus:border-orange-500 focus:bg-orange-50/30 rounded outline-none"
                          />
                        </td>
                        <td className="py-1 px-1 border-r border-neutral-200">
                          <input
                            type="number"
                            min="0"
                            step="any"
                            value={item.unitPrice ?? ''}
                            onChange={(e) => handleItemChange(index, 'unitPrice', e.target.value)}
                            placeholder=""
                            className="w-full text-xs text-right font-mono px-2 py-1 border border-transparent hover:border-neutral-300 focus:border-orange-500 focus:bg-orange-50/30 rounded outline-none"
                          />
                        </td>
                        <td className="py-1 px-3 text-right font-mono font-bold text-neutral-800 bg-neutral-50/40 border-r border-neutral-200">
                          {lineTotal > 0 ? formatInvoiceNumber(lineTotal) : '—'}
                        </td>
                        <td className="py-1 px-1 text-center">
                          <button
                            type="button"
                            onClick={() => handleRemoveItem(index)}
                            title={`Remove item #${index + 1}`}
                            aria-label={`Remove item #${index + 1}`}
                            className="p-1 rounded text-neutral-400 hover:text-rose-600 hover:bg-rose-50 transition cursor-pointer"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>

            <div className="flex flex-wrap items-center justify-between gap-2 pt-1">
              <button
                type="button"
                onClick={handleAddItem}
                className="px-3 py-1.5 text-xs font-semibold rounded-lg bg-neutral-900 hover:bg-neutral-800 text-white flex items-center gap-1.5 transition shadow-xs cursor-pointer"
              >
                <Plus className="w-3.5 h-3.5" />
                Add Item
              </button>
              <span className="text-xs text-neutral-500">
                Empty rows are cleanly formatted on printed A4 documents.
              </span>
            </div>
          </div>

          {/* Section 3: Summary & Cash Received (Only Cash Method) */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 items-start pt-2">
            <div>
              <label className="text-[11px] font-semibold text-neutral-700 block mb-1">
                Invoice Note / Terms
              </label>
              <textarea
                rows={3}
                value={note ?? ''}
                onChange={(e) => setNote(e.target.value)}
                placeholder="Specific notes or warranty clauses for this invoice..."
                className="w-full text-xs border border-neutral-300 rounded-lg p-2.5 focus:outline-none focus:ring-1 focus:ring-orange-500"
              />

              {!invoiceToEdit && (
                <div className="mt-4 p-3.5 bg-amber-50/70 border border-amber-200 rounded-lg space-y-1.5">
                  <div className="flex items-center gap-1.5 text-xs font-bold text-amber-900">
                    <AlertCircle className="w-4 h-4 text-amber-600 shrink-0" />
                    <span>Quotation Workflow</span>
                  </div>
                  <p className="text-[11px] text-amber-800 leading-relaxed">
                    New documents default to <strong>Quotation / Pending Approval</strong>. Once accepted by the customer or marked as payable by Invoice Manager/Super Admin, payment collection and collector assignments will be activated.
                  </p>
                </div>
              )}
            </div>

            {/* Calculations Card */}
            <div className="bg-neutral-50 border border-neutral-300 rounded-xl overflow-hidden p-4 space-y-3">
              <div className="flex justify-between items-center text-sm">
                <span className="text-neutral-600 font-medium">Total Price:</span>
                <span className="font-bold text-neutral-900 font-mono text-base">
                  {formatAFN(invoiceTotal)}
                </span>
              </div>
              <div className="flex justify-between items-center text-sm">
                <span className="text-emerald-700 font-medium">Cash Paid / Received:</span>
                <span className="font-bold text-emerald-700 font-mono">
                  {formatAFN(paidCashAmount)}
                </span>
              </div>
              <div className="border-t border-neutral-300 pt-3 flex justify-between items-center">
                <span className="font-bold text-neutral-900 uppercase tracking-wide text-xs">
                  Remaining Balance:
                </span>
                <span className="font-black text-lg text-orange-600 font-mono">
                  {formatAFN(remainingBalance)}
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Footer Actions */}
        <div className="px-6 py-4 border-t border-neutral-200 bg-neutral-100 flex flex-wrap items-center justify-between gap-3">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 text-xs font-semibold text-neutral-700 hover:bg-neutral-200 rounded-lg transition"
          >
            Cancel
          </button>
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => {
                if (validateForm()) setIsPreviewOpen(true);
              }}
              className="px-4 py-2 text-xs font-bold rounded-lg border border-neutral-300 bg-white hover:bg-neutral-50 text-neutral-800 transition inline-flex items-center gap-1.5"
            >
              <Eye className="w-3.5 h-3.5 text-orange-500" />
              Preview A4
            </button>
            <button
              type="button"
              disabled={saving || isInvoiceLocked}
              onClick={handleSaveInvoice}
              className="px-6 py-2 text-xs font-bold rounded-lg bg-neutral-900 hover:bg-black text-white transition inline-flex items-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              <Save className="w-4 h-4 text-orange-400" />
              {saving ? 'Saving...' : invoiceToEdit ? 'Update Invoice' : 'Save Invoice'}
            </button>
          </div>
        </div>
      </div>

      {/* ================= INVOICE PREVIEW MODAL ================= */}
      {isPreviewOpen && (
        <div className="fixed inset-0 z-60 bg-black/80 flex flex-col items-center justify-center p-3 sm:p-6 overflow-y-auto">
          {/* Action Toolbar */}
          <div className="w-full max-w-[800px] mb-4 flex items-center justify-between bg-neutral-900 text-white p-3 rounded-lg shadow-xl">
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold tracking-wider text-orange-400 uppercase">
                Invoice Preview: {projectedBillNo}
              </span>
            </div>
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={handleDownloadPreviewPdf}
                className="px-3 py-1.5 bg-neutral-800 hover:bg-neutral-700 text-white text-xs font-semibold rounded inline-flex items-center gap-1.5 transition border border-neutral-700 cursor-pointer"
                title="Print or Save Invoice as PDF"
                aria-label="Print or Save Invoice as PDF"
              >
                <Printer className="w-3.5 h-3.5 text-orange-400" />
                Print / Save as PDF
              </button>
              <button
                type="button"
                disabled={saving}
                onClick={async () => {
                  await handleSaveInvoice();
                  setIsPreviewOpen(false);
                }}
                className="px-4 py-1.5 bg-orange-600 hover:bg-orange-500 text-white text-xs font-bold rounded inline-flex items-center gap-1.5 transition cursor-pointer"
              >
                <Save className="w-3.5 h-3.5" />
                {saving ? 'Saving...' : 'Save Invoice'}
              </button>
              <button
                type="button"
                onClick={() => setIsPreviewOpen(false)}
                className="p-1.5 text-neutral-400 hover:text-white rounded transition cursor-pointer"
                title="Back to editor"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
          </div>

          {/* Responsive Canonical Invoice Sheet Container */}
          <div
            ref={previewContainerRef}
            className="w-full max-w-[850px] bg-neutral-100 rounded-lg shadow-2xl overflow-x-hidden overflow-y-auto max-h-[85vh] p-2 sm:p-4 flex flex-col items-center"
            style={{ boxSizing: 'border-box' }}
          >
            {previewCanonicalDoc && (
              <div
                style={{
                  width: `${Math.round(793.7 * previewScale)}px`,
                  height: `${Math.round(docHeight * previewScale)}px`,
                  position: 'relative',
                  margin: '0 auto',
                  flexShrink: 0,
                  transition: 'width 0.15s ease-out, height 0.15s ease-out',
                }}
              >
                <div
                  ref={docRef}
                  style={{
                    position: 'absolute',
                    top: 0,
                    left: 0,
                    transform: `scale(${previewScale})`,
                    transformOrigin: 'top left',
                    width: '210mm',
                    minWidth: '210mm',
                    transition: 'transform 0.15s ease-out',
                  }}
                  className="shadow-xl bg-white border border-neutral-300"
                >
                  <CanonicalInvoiceDocument
                    document={previewCanonicalDoc}
                    id="invoice-draft-preview-document"
                  />
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {isPdfModalOpen && previewInvoice && (
        <InvoicePdfDownloadModal
          isOpen={isPdfModalOpen}
          onClose={() => setIsPdfModalOpen(false)}
          invoice={previewInvoice}
          payments={[]}
          settings={settings}
          userProfile={userProfile}
        />
      )}
    </div>
  );
};
