import React, { useState, useEffect } from 'react';
import { saveExpense, resubmitRejectedExpense } from '../../services/db';
import { useAuth } from '../../context/AuthContext';
import { getTodayDateString } from '../../utils/format';
import { X, Receipt, AlertCircle, RefreshCw } from 'lucide-react';
import { Expense } from '../../types';

interface ExpenseModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess?: () => void;
  expenseToEdit?: Expense | null;
}

const EXPENSE_CATEGORIES = [
  'General Operations',
  'Tools & Equipment',
  'CCTV & Network Materials',
  'Office Utilities & Rent',
  'Transport & Fuel',
  'Maintenance & Repairs',
  'Staff Allowance / Food',
  'Other',
];

export const ExpenseModal: React.FC<ExpenseModalProps> = ({
  isOpen,
  onClose,
  onSuccess,
  expenseToEdit = null,
}) => {
  const { userProfile, currentUser } = useAuth();
  const [title, setTitle] = useState<string>('');
  const [category, setCategory] = useState<string>('General Operations');
  const [amount, setAmount] = useState<number | ''>('');
  const [date, setDate] = useState<string>(getTodayDateString());
  const [note, setNote] = useState<string>('');
  const [corrections, setCorrections] = useState<string>('');
  const [saving, setSaving] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  const isEditMode = Boolean(expenseToEdit);

  useEffect(() => {
    if (!isOpen) return;

    if (expenseToEdit) {
      setTitle(expenseToEdit.title || '');
      setCategory(expenseToEdit.category || 'General Operations');
      setAmount(expenseToEdit.amount ?? '');
      setDate(expenseToEdit.date || getTodayDateString());
      setNote(expenseToEdit.note || '');
      setCorrections('');
      setError(null);
    } else {
      setTitle('');
      setCategory('General Operations');
      setAmount('');
      setDate(getTodayDateString());
      setNote('');
      setCorrections('');
      setError(null);
    }
  }, [isOpen, expenseToEdit]);

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) {
      setError('Expense title is required.');
      return;
    }
    const numAmount = Number(amount);
    if (!numAmount || numAmount <= 0) {
      setError('Expense amount must be greater than zero.');
      return;
    }

    if (userProfile?.role === 'customer') {
      setError('Customers are not permitted to submit business expenses.');
      return;
    }

    setSaving(true);
    setError(null);

    const activeUserId = userProfile?.id || currentUser?.uid || '';
    const activeUserName = userProfile?.name || currentUser?.displayName || 'Staff';
    const activeUserRole = userProfile?.role || 'payment_collector';

    try {
      if (isEditMode && expenseToEdit) {
        // Edit & Resubmit Rejected Expense
        await resubmitRejectedExpense({
          expenseId: expenseToEdit.id,
          title: title.trim(),
          category,
          amount: numAmount,
          date,
          note: note.trim(),
          corrections: corrections.trim() || undefined,
          userId: activeUserId,
          userName: activeUserName,
          userRole: activeUserRole,
        });
      } else {
        // Create new expense request
        await saveExpense({
          title: title.trim(),
          category,
          amount: numAmount,
          date,
          note: note.trim(),
          requestedBy: activeUserId,
          requestedByName: activeUserName,
          requestedByRole: activeUserRole,
          status: 'pending_manager',
        });
      }

      if (onSuccess) onSuccess();
      onClose();
    } catch (err: any) {
      console.error('Error recording expense:', err);
      setError(err.message || 'Failed to record expense.');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
      <div className="bg-white rounded-xl shadow-2xl w-full max-w-lg overflow-hidden border border-neutral-200">
        <div className="flex items-center justify-between px-6 py-4 border-b border-neutral-200 bg-neutral-900 text-white">
          <div className="flex items-center gap-2.5">
            {isEditMode ? (
              <RefreshCw className="w-5 h-5 text-amber-400" />
            ) : (
              <Receipt className="w-5 h-5 text-orange-400" />
            )}
            <div>
              <h2 className="text-base font-bold">
                {isEditMode ? 'Edit & Resubmit Rejected Expense' : 'Record Business Expense'}
              </h2>
              {isEditMode && (
                <span className="text-[10px] text-amber-300 font-medium">
                  Status will reset to Pending Manager for re-review
                </span>
              )}
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-neutral-400 hover:text-white hover:bg-neutral-800 transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-4 max-h-[80vh] overflow-y-auto">
          {error && (
            <div className="p-2.5 bg-red-50 border border-red-200 text-red-700 text-xs rounded-lg flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0 text-red-500" />
              <span>{error}</span>
            </div>
          )}

          {/* Previous Rejection Reason Banner */}
          {isEditMode && expenseToEdit && (
            <div className="p-3 bg-rose-50 border border-rose-200 rounded-lg text-xs text-rose-900 space-y-1">
              <div className="flex items-center gap-1.5 font-bold text-rose-800">
                <AlertCircle className="w-3.5 h-3.5 text-rose-600" />
                <span>Previous Rejection Feedback</span>
              </div>
              <p className="text-[11px] text-rose-700">
                {expenseToEdit.rejectionReason || 'No specific rejection reason recorded.'}
              </p>
              {expenseToEdit.rejectedByName && (
                <p className="text-[10px] text-rose-500 font-medium">
                  Rejected by: {expenseToEdit.rejectedByName}
                  {expenseToEdit.rejectedAt ? ` on ${expenseToEdit.rejectedAt.slice(0, 10)}` : ''}
                </p>
              )}
            </div>
          )}

          <div>
            <label className="text-xs font-semibold text-neutral-700 block mb-1">
              Expense Title / Purpose *
            </label>
            <input
              type="text"
              required
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="e.g. Office electricity bill, CCTV tools & cable purchase"
              className="w-full text-xs border border-neutral-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-1 focus:ring-orange-500"
            />
          </div>

          <div>
            <label className="text-xs font-semibold text-neutral-700 block mb-1">
              Category *
            </label>
            <select
              value={category}
              onChange={(e) => setCategory(e.target.value)}
              className="w-full text-xs border border-neutral-300 rounded-lg px-3 py-2 bg-white focus:outline-none focus:ring-1 focus:ring-orange-500"
            >
              {EXPENSE_CATEGORIES.map((cat) => (
                <option key={cat} value={cat}>
                  {cat}
                </option>
              ))}
            </select>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-xs font-semibold text-neutral-700 block mb-1">
                Amount (AFN) *
              </label>
              <input
                type="number"
                min="1"
                required
                value={amount}
                onChange={(e) => setAmount(e.target.value === '' ? '' : Number(e.target.value))}
                placeholder="0 AFN"
                className="w-full text-xs font-mono font-bold border border-neutral-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-1 focus:ring-orange-500"
              />
            </div>
            <div>
              <label className="text-xs font-semibold text-neutral-700 block mb-1">
                Expense Date *
              </label>
              <input
                type="date"
                required
                value={date}
                onChange={(e) => setDate(e.target.value)}
                className="w-full text-xs font-mono border border-neutral-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-1 focus:ring-orange-500"
              />
            </div>
          </div>

          <div>
            <label className="text-xs font-semibold text-neutral-700 block mb-1">
              Note (Optional)
            </label>
            <textarea
              rows={2}
              value={note}
              onChange={(e) => setNote(e.target.value)}
              placeholder="Additional details, receipt numbers or memo..."
              className="w-full text-xs border border-neutral-300 rounded-lg p-2.5 focus:outline-none focus:ring-1 focus:ring-orange-500"
            />
          </div>

          {isEditMode && (
            <div>
              <label className="text-xs font-semibold text-neutral-700 block mb-1">
                Corrections / Resubmission Note (Optional)
              </label>
              <input
                type="text"
                value={corrections}
                onChange={(e) => setCorrections(e.target.value)}
                placeholder="Explain what was updated or attached to address the rejection..."
                className="w-full text-xs border border-neutral-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-1 focus:ring-amber-500"
              />
            </div>
          )}

          <div className="pt-2 flex items-center justify-end gap-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-semibold text-neutral-700 hover:bg-neutral-100 rounded-lg transition cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={saving}
              className={`px-5 py-2 text-xs font-bold rounded-lg transition disabled:opacity-50 inline-flex items-center gap-1.5 cursor-pointer ${
                isEditMode
                  ? 'bg-amber-600 hover:bg-amber-700 text-white'
                  : 'bg-neutral-900 hover:bg-black text-white'
              }`}
            >
              {saving
                ? isEditMode
                  ? 'Resubmitting...'
                  : 'Saving...'
                : isEditMode
                ? 'Resubmit for Review'
                : 'Save Expense'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
