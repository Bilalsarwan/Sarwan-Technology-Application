import React, { useState, useEffect, useRef } from 'react';
import { createRoot } from 'react-dom/client';
import { Payment, Invoice, BusinessSettings, ReceiptDesignSettings } from '../../types';
import { formatAFN, formatDate } from '../../utils/format';
import { isEmbeddedContext, printReceiptInDedicatedWindow } from '../../utils/print';
import { downloadElementAsPdf } from '../../utils/pdf';
import {
  X,
  Printer,
  Download,
  Loader2,
  Receipt,
  ShieldCheck,
  AlertTriangle,
  CreditCard,
  User,
  FileText,
} from 'lucide-react';

/* ==========================================================================
   CANONICAL PAYMENT RECEIPT DOCUMENT (SINGLE SOURCE OF TRUTH)
   A4 Professional Accounting Layout ONLY.
   Used identically for on-screen responsive preview, direct print, and PDF.
   Guaranteed to always fit completely on ONE single A4 page.
   ========================================================================== */

export interface PaymentReceiptDocumentProps {
  payment: Payment;
  invoice?: Invoice | null;
  settings: BusinessSettings;
}

export const PaymentReceiptDocument: React.FC<PaymentReceiptDocumentProps> = ({
  payment,
  invoice,
  settings,
}) => {
  // Status computation based on payment data model
  const isReversed = Boolean(
    payment.isVoid === true ||
    (payment as any).status === 'Void' ||
    (payment as any).status === 'Cancelled'
  );

  // Customer Information resolution (from payment or invoice customer snapshot)
  const customerName =
    payment.customerName ||
    invoice?.customerSnapshot?.name ||
    (invoice as any)?.customerName ||
    'Customer';
  const customerPhone =
    invoice?.customerSnapshot?.phone ||
    (payment as any).customerPhone ||
    null;
  const customerEmail = invoice?.customerSnapshot?.email || null;
  const customerAddress = invoice?.customerSnapshot?.address || null;

  // Date and Time formatting
  const formattedDate = formatDate(payment.date);
  const formattedTime = payment.time
    ? payment.time
    : payment.createdAt
    ? new Date(payment.createdAt).toLocaleTimeString([], {
        hour: '2-digit',
        minute: '2-digit',
      })
    : null;
  const formattedDateTime = formattedTime
    ? `${formattedDate} at ${formattedTime}`
    : formattedDate;

  // Payment Method and Collector
  const paymentMethod = payment.method
    ? payment.method === 'CASH'
      ? 'Cash'
      : payment.method
    : 'Cash';
  const collectorName = payment.recordedByName || 'Super Admin';

  // Invoice calculations based on trusted existing relationships
  const invoiceTotal = invoice
    ? typeof invoice.totalAmount === 'number'
      ? invoice.totalAmount
      : parseFloat(String(invoice.totalAmount ?? 0)) || 0
    : 0;

  const totalPaidToDate = invoice
    ? typeof invoice.totalPaid === 'number'
      ? invoice.totalPaid
      : parseFloat(String(invoice.totalPaid ?? payment.amount)) || payment.amount
    : payment.amount;

  // Amount paid prior to this specific transaction
  const previouslyPaid = Math.max(0, totalPaidToDate - payment.amount);

  // Authoritative remaining balance from invoice or calculation
  const remainingBalance = invoice
    ? typeof invoice.remaining === 'number'
      ? invoice.remaining
      : Math.max(0, invoiceTotal - totalPaidToDate)
    : 0;

  const invoiceStatus =
    invoice?.status ||
    (remainingBalance <= 0 ? 'Paid' : 'Partially Paid');

  const invoiceNumber = payment.billNumber || invoice?.billNumber || '—';

  // Company Information from application settings
  const companyName = settings.companyName || 'Sarwan Technology';
  const thankYouMessage =
    settings.invoiceNote ||
    settings.receiptDesign?.thermalFooter ||
    'Thank you for your business.';

  return (
    <div
      id="payment-receipt-document"
      className="bg-white text-neutral-900 mx-auto flex flex-col justify-between box-border border border-neutral-200 shadow-xs"
      style={{
        width: '210mm',
        maxWidth: '210mm',
        height: '297mm',
        maxHeight: '297mm',
        minHeight: '297mm',
        padding: '14mm 16mm',
        boxSizing: 'border-box',
        overflow: 'hidden',
        pageBreakInside: 'avoid',
        breakInside: 'avoid',
        pageBreakAfter: 'avoid',
        breakAfter: 'avoid',
        fontFamily: 'system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif',
      }}
    >
      {/* Upper Main Body: Header, Meta, Cards, Summary Table, and Notes */}
      <div className="flex-1 flex flex-col space-y-4 min-h-0">
        {/* 1. Header: Logo, Company Information & Large Title */}
        <div
          id="receipt-header-section"
          className="pb-4 border-b border-neutral-200 flex items-start justify-between gap-6"
        >
          {/* Company Branding & Contact Details */}
          <div className="space-y-1 min-w-0 max-w-[55%]">
            {settings.logo ? (
              <img
                src={settings.logo}
                alt={companyName}
                className="h-16 sm:h-[77px] max-w-[288px] w-auto object-contain mb-1.5"
                referrerPolicy="no-referrer"
              />
            ) : (
              <div className="flex items-center gap-2 mb-1.5">
                <div className="w-10 h-10 rounded-lg bg-neutral-900 text-white flex items-center justify-center font-black text-base">
                  ST
                </div>
                <span className="font-black text-lg tracking-tight text-neutral-950 uppercase">
                  {companyName}
                </span>
              </div>
            )}

            <p className="font-extrabold text-base text-neutral-900 leading-tight">
              {companyName}
            </p>

            {settings.address && (
              <p className="text-xs text-neutral-500 leading-tight">
                {settings.address}
              </p>
            )}

            {(settings.phone || settings.whatsapp) && (
              <p className="text-xs text-neutral-600 font-mono leading-tight">
                {settings.phone && <span>Tel: {settings.phone}</span>}
                {settings.phone && settings.whatsapp && <span> • </span>}
                {settings.whatsapp && <span>WA: {settings.whatsapp}</span>}
              </p>
            )}

            {settings.email && (
              <p className="text-xs text-neutral-600 leading-tight">
                {settings.email}
              </p>
            )}
          </div>

          {/* Receipt Title, Status Badge & Quick Meta */}
          <div className="text-right flex flex-col items-end min-w-0">
            <h1
              id="payment-receipt-title"
              className="text-2xl sm:text-3xl font-black uppercase text-neutral-950 tracking-wider"
            >
              PAYMENT RECEIPT
            </h1>

            <div className="mt-1.5 flex items-center gap-2">
              <span className="text-xs font-semibold text-neutral-500">Status:</span>
              {isReversed ? (
                <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-bold bg-rose-50 text-rose-700 border border-rose-200">
                  <AlertTriangle className="w-3.5 h-3.5 text-rose-500" />
                  <span>Reversed</span>
                </span>
              ) : (
                <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-bold bg-emerald-50 text-emerald-700 border border-emerald-200">
                  <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
                  <span>Completed</span>
                </span>
              )}
            </div>

            <div className="mt-2 text-xs text-neutral-600 space-y-0.5 font-sans">
              <div>
                <span className="text-neutral-400">Invoice: </span>
                <span className="font-mono font-bold text-orange-600 text-sm">
                  {invoiceNumber}
                </span>
              </div>
              <div>
                <span className="text-neutral-400">Date: </span>
                <span className="font-medium text-neutral-800">{formattedDate}</span>
              </div>
              {formattedTime && (
                <div>
                  <span className="text-neutral-400">Time: </span>
                  <span className="font-mono text-neutral-700">{formattedTime}</span>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* 2. Two-Column Grid: Customer Information & Payment Information */}
        <div className="grid grid-cols-2 gap-4">
          {/* Customer Information Card (Zero raw IDs visible) */}
          <div
            id="receipt-customer-info"
            className="bg-neutral-50/80 rounded-xl p-3.5 border border-neutral-200 space-y-2"
          >
            <div className="flex items-center gap-1.5 pb-1.5 border-b border-neutral-200/80">
              <User className="w-3.5 h-3.5 text-neutral-500" />
              <h3 className="text-xs font-bold uppercase tracking-wider text-neutral-700">
                Customer Information
              </h3>
            </div>

            <div className="space-y-1.5 text-xs">
              <div>
                <span className="text-neutral-400 text-[11px] block">Customer Name</span>
                <span className="font-bold text-neutral-900 text-sm break-words">
                  {customerName}
                </span>
              </div>

              {customerPhone && (
                <div>
                  <span className="text-neutral-400 text-[11px] block">Phone / Contact</span>
                  <span className="font-mono text-neutral-800">{customerPhone}</span>
                </div>
              )}

              {customerEmail && (
                <div>
                  <span className="text-neutral-400 text-[11px] block">Email Address</span>
                  <span className="text-neutral-700 break-all">{customerEmail}</span>
                </div>
              )}

              {customerAddress && (
                <div>
                  <span className="text-neutral-400 text-[11px] block">Address</span>
                  <span className="text-neutral-700">{customerAddress}</span>
                </div>
              )}
            </div>
          </div>

          {/* Payment Information Card (Zero raw IDs visible) */}
          <div
            id="receipt-payment-info"
            className="bg-neutral-50/80 rounded-xl p-3.5 border border-neutral-200 space-y-2"
          >
            <div className="flex items-center gap-1.5 pb-1.5 border-b border-neutral-200/80">
              <CreditCard className="w-3.5 h-3.5 text-neutral-500" />
              <h3 className="text-xs font-bold uppercase tracking-wider text-neutral-700">
                Payment Information
              </h3>
            </div>

            <div className="space-y-1.5 text-xs">
              <div>
                <span className="text-neutral-400 text-[11px] block">Payment Date &amp; Time</span>
                <span className="font-medium text-neutral-800">{formattedDateTime}</span>
              </div>

              <div>
                <span className="text-neutral-400 text-[11px] block">Payment Status</span>
                <span className="font-bold text-neutral-800">
                  {isReversed ? 'Reversed / Void' : 'Completed'}
                </span>
              </div>

              <div>
                <span className="text-neutral-400 text-[11px] block">Payment Method</span>
                <span className="font-bold text-neutral-900">{paymentMethod}</span>
              </div>

              <div>
                <span className="text-neutral-400 text-[11px] block">Collector / Cashier</span>
                <span className="font-medium text-neutral-800">{collectorName}</span>
              </div>

              {(payment as any).reference && (
                <div>
                  <span className="text-neutral-400 text-[11px] block">Reference</span>
                  <span className="font-mono text-neutral-700">{(payment as any).reference}</span>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* 3. Invoice Breakdown Section */}
        <div
          id="receipt-invoice-info"
          className="border border-neutral-200 rounded-xl overflow-hidden bg-white"
        >
          <div className="bg-neutral-100/90 px-4 py-2 border-b border-neutral-200 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <FileText className="w-3.5 h-3.5 text-neutral-600" />
              <span className="text-xs font-bold uppercase tracking-wider text-neutral-700">
                Invoice Information &amp; Ledger
              </span>
            </div>
            <div className="flex items-center gap-3 text-xs">
              <span className="text-neutral-500">
                Invoice Number: <strong className="font-mono text-orange-600">{invoiceNumber}</strong>
              </span>
              <span
                className={`text-[10px] font-bold uppercase px-2 py-0.5 rounded-full ${
                  invoiceStatus === 'Paid'
                    ? 'bg-emerald-100 text-emerald-800'
                    : invoiceStatus === 'Partially Paid'
                    ? 'bg-amber-100 text-amber-800'
                    : 'bg-neutral-200 text-neutral-800'
                }`}
              >
                {invoiceStatus}
              </span>
            </div>
          </div>

          <table className="w-full text-xs text-left border-collapse">
            <thead>
              <tr className="bg-neutral-50/70 border-b border-neutral-200 text-neutral-500 font-semibold text-[11px] uppercase tracking-wider">
                <th className="py-2.5 px-4">Description</th>
                <th className="py-2.5 px-4 text-center">Status</th>
                <th className="py-2.5 px-4 text-right">Amount (AFN)</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-neutral-150">
              <tr>
                <td className="py-2.5 px-4 text-neutral-800 font-medium">Invoice Total</td>
                <td className="py-2.5 px-4 text-center text-neutral-500">Bill Total</td>
                <td className="py-2.5 px-4 text-right font-mono font-semibold text-neutral-800">
                  {formatAFN(invoiceTotal)}
                </td>
              </tr>
              <tr>
                <td className="py-2.5 px-4 text-neutral-700">Previously Paid</td>
                <td className="py-2.5 px-4 text-center text-neutral-500">Prior Payments</td>
                <td className="py-2.5 px-4 text-right font-mono font-medium text-neutral-600">
                  {formatAFN(previouslyPaid)}
                </td>
              </tr>
              <tr className="bg-neutral-50/50">
                <td className="py-2.5 px-4 text-neutral-800 font-semibold">This Payment (Current)</td>
                <td className="py-2.5 px-4 text-center">
                  <span className="font-semibold text-emerald-700">Credited</span>
                </td>
                <td className="py-2.5 px-4 text-right font-mono font-bold text-emerald-700">
                  {formatAFN(payment.amount)}
                </td>
              </tr>
            </tbody>
          </table>
        </div>

        {/* 4. Payment Summary: Amount Paid & Remaining Balance (Prominently Highlighted) */}
        <div
          id="payment-receipt-summary"
          className="grid grid-cols-2 gap-4"
        >
          {/* Current Payment / Amount Paid - High Prominence */}
          <div className="p-4 rounded-xl bg-neutral-900 text-white shadow-xs flex flex-col justify-between">
            <div>
              <span className="text-[11px] font-semibold text-neutral-400 uppercase tracking-wider block">
                Amount Paid
              </span>
              <p
                id="receipt-summary-amount"
                className="text-2xl sm:text-3xl font-black font-mono text-emerald-400 mt-1 break-words"
              >
                {formatAFN(payment.amount)}
              </p>
            </div>
            <p className="text-[11px] text-neutral-400 mt-2">
              Paid via <span className="text-white font-medium">{paymentMethod}</span> • Cashier: {collectorName}
            </p>
          </div>

          {/* Remaining Balance - High Prominence */}
          <div className="p-4 rounded-xl bg-neutral-100 border border-neutral-300 flex flex-col justify-between">
            <div>
              <span className="text-[11px] font-semibold text-neutral-600 uppercase tracking-wider block">
                Remaining Balance
              </span>
              <p
                id="receipt-summary-remaining"
                className="text-2xl sm:text-3xl font-black font-mono text-neutral-950 mt-1 break-words"
              >
                {formatAFN(remainingBalance)}
              </p>
            </div>
            <p className="text-[11px] text-neutral-600 mt-2">
              Invoice Status: <span className="font-bold text-neutral-900">{invoiceStatus}</span>
            </p>
          </div>
        </div>

        {/* 5. Notes Section: Displayed ONLY when payment.note is present */}
        {payment.note && payment.note.trim().length > 0 && (
          <div
            id="receipt-notes-section"
            className="p-3.5 rounded-xl bg-neutral-50 border border-neutral-200"
          >
            <span className="text-[11px] font-bold text-neutral-500 uppercase tracking-wider block mb-1">
              Notes
            </span>
            <p className="text-xs text-neutral-800 whitespace-pre-wrap font-sans break-words">
              {payment.note.trim()}
            </p>
          </div>
        )}
      </div>

      {/* Lower Section: Signatures & Authorization + Footer */}
      <div className="pt-4 border-t border-neutral-200 space-y-4 shrink-0">
        {/* Signatures & Authorization */}
        <div
          id="receipt-signatures-section"
          className="grid grid-cols-2 gap-12 pt-2"
        >
          <div className="text-center">
            <div className="border-b border-neutral-300 w-3/4 mx-auto mb-1.5 pb-6"></div>
            <p className="text-xs font-semibold text-neutral-700">Customer Signature</p>
            <p className="text-[10px] text-neutral-400">{customerName}</p>
          </div>
          <div className="text-center">
            <div className="border-b border-neutral-300 w-3/4 mx-auto mb-1.5 pb-6"></div>
            <p className="text-xs font-semibold text-neutral-700">Authorized Signatory / Cashier</p>
            <p className="text-[10px] text-neutral-400">{collectorName}</p>
          </div>
        </div>

        {/* 6. Company Footer & Thank You Message */}
        <div
          id="receipt-footer-section"
          className="pt-2 text-center space-y-1"
        >
          <p className="text-xs font-semibold text-neutral-700">
            {thankYouMessage}
          </p>
          {settings.footerText && (
            <p className="text-[11px] text-neutral-400">
              {settings.footerText}
            </p>
          )}
        </div>
      </div>
    </div>
  );
};

/* ==========================================================================
   CANONICAL PRINT & PDF UTILITIES
   Uses the proven Invoice Print architecture: synchronous user activation,
   dedicated window in embedded/iframe contexts, A4 one-page print, and cleanup.
   ========================================================================== */

let isReceiptPrintingActive = false;

export async function printPaymentReceiptDocument(
  payment: Payment,
  invoice: Invoice | null | undefined,
  settings: BusinessSettings,
  printWindow?: Window | null
): Promise<void> {
  if (typeof window === 'undefined' || typeof document === 'undefined') return;
  if (isReceiptPrintingActive) return; // Concurrency protection

  isReceiptPrintingActive = true;
  const printTitle = `Payment-Receipt-${payment.billNumber || payment.id}`;

  try {
    const isEmbedded = isEmbeddedContext();
    let win = printWindow;

    // In embedded environments, if a window was not already opened synchronously, open one
    if (!win && isEmbedded) {
      try {
        win = window.open('', '_blank');
      } catch (err) {
        console.warn('[Receipt Print] window.open exception:', err);
      }
    }

    if (win) {
      // 1. Locate existing rendered receipt or prepare staging element
      let receiptEl = document.getElementById('payment-receipt-document');
      let stagingContainer: HTMLDivElement | null = null;
      let stagingRoot: ReturnType<typeof createRoot> | null = null;

      if (!receiptEl) {
        stagingContainer = document.createElement('div');
        stagingContainer.id = 'temp-receipt-staging';
        stagingContainer.style.cssText = 'position: fixed; left: -9999px; top: 0; width: 210mm;';
        document.body.appendChild(stagingContainer);
        stagingRoot = createRoot(stagingContainer);
        stagingRoot.render(
          React.createElement(PaymentReceiptDocument, { payment, invoice, settings })
        );

        await new Promise<void>((resolve) => {
          const startTime = Date.now();
          const check = () => {
            if (stagingContainer?.querySelector('#payment-receipt-document') || Date.now() - startTime > 1200) {
              resolve();
            } else {
              requestAnimationFrame(check);
            }
          };
          requestAnimationFrame(check);
        });
        receiptEl = stagingContainer.querySelector('#payment-receipt-document') as HTMLElement;
      }

      if (receiptEl) {
        try {
          await printReceiptInDedicatedWindow(win, receiptEl, printTitle);
        } finally {
          if (stagingRoot) {
            stagingRoot.unmount();
          }
          if (stagingContainer && stagingContainer.parentNode) {
            stagingContainer.parentNode.removeChild(stagingContainer);
          }
        }
        return;
      }
    }

    // 2. Direct print fallback in top-level browser when not using dedicated window
    document.body.classList.add('receipt-printing');
    let printRoot = document.getElementById('receipt-print-root') as HTMLDivElement | null;
    let rootInstance: ReturnType<typeof createRoot> | null = null;

    try {
      if (!printRoot) {
        printRoot = document.createElement('div');
        printRoot.id = 'receipt-print-root';
        document.body.appendChild(printRoot);
      }

      rootInstance = createRoot(printRoot);
      await new Promise<void>((resolve) => {
        rootInstance!.render(
          React.createElement(PaymentReceiptDocument, {
            payment,
            invoice,
            settings,
          })
        );
        const startTime = Date.now();
        const check = () => {
          if (printRoot?.querySelector('#payment-receipt-document') || Date.now() - startTime > 1200) {
            resolve();
          } else {
            requestAnimationFrame(check);
          }
        };
        requestAnimationFrame(check);
      });

      if (typeof document.fonts !== 'undefined' && document.fonts.ready) {
        try {
          await document.fonts.ready;
        } catch {}
      }

      const images = Array.from(printRoot.querySelectorAll('img'));
      if (images.length > 0) {
        await Promise.all(
          images.map(
            (img) =>
              new Promise<void>((resolve) => {
                if (img.complete && img.naturalHeight !== 0) {
                  resolve();
                } else {
                  img.onload = () => resolve();
                  img.onerror = () => resolve();
                  setTimeout(resolve, 800);
                }
              })
          )
        );
      }

      await new Promise((resolve) => setTimeout(resolve, 100));
      window.print();
    } finally {
      if (rootInstance) {
        rootInstance.unmount();
      }
      if (printRoot && printRoot.parentNode) {
        printRoot.parentNode.removeChild(printRoot);
      }
      document.body.classList.remove('receipt-printing');
    }
  } catch (err) {
    console.error('[Receipt Print] Error launching print preview:', err);
    throw err;
  } finally {
    isReceiptPrintingActive = false;
  }
}

/**
 * Generates and downloads a clean A4 one-page receipt PDF using the canonical PaymentReceiptDocument.
 */
export async function downloadPaymentReceiptPdf(
  payment: Payment,
  invoice: Invoice | null | undefined,
  settings: BusinessSettings
): Promise<void> {
  const filename = `Sarwan-Technology-Payment-Receipt-${payment.billNumber || payment.id}.pdf`;
  let receiptEl = document.getElementById('payment-receipt-document');
  let stagingContainer: HTMLDivElement | null = null;
  let stagingRoot: ReturnType<typeof createRoot> | null = null;

  if (!receiptEl) {
    stagingContainer = document.createElement('div');
    stagingContainer.id = 'temp-receipt-pdf-staging';
    stagingContainer.style.cssText = 'position: fixed; left: -9999px; top: 0; width: 210mm; height: 297mm;';
    document.body.appendChild(stagingContainer);
    stagingRoot = createRoot(stagingContainer);
    stagingRoot.render(
      React.createElement(PaymentReceiptDocument, { payment, invoice, settings })
    );

    await new Promise<void>((resolve) => {
      const startTime = Date.now();
      const check = () => {
        if (stagingContainer?.querySelector('#payment-receipt-document') || Date.now() - startTime > 1200) {
          resolve();
        } else {
          requestAnimationFrame(check);
        }
      };
      requestAnimationFrame(check);
    });
    receiptEl = stagingContainer.querySelector('#payment-receipt-document') as HTMLElement;
  }

  if (!receiptEl) {
    throw new Error('Unable to find or prepare PaymentReceiptDocument for PDF export.');
  }

  try {
    await downloadElementAsPdf(receiptEl, filename, {
      paperSize: 'A4',
      orientation: 'portrait',
    });
  } finally {
    if (stagingRoot) {
      stagingRoot.unmount();
    }
    if (stagingContainer && stagingContainer.parentNode) {
      stagingContainer.parentNode.removeChild(stagingContainer);
    }
  }
}

/* ==========================================================================
   OFFICIAL PAYMENT RECEIPT MODAL
   Screen modal wrapper rendering the exact canonical A4 Receipt Document.
   Auto-scales responsively to fit the viewport without horizontal scrollbars.
   ========================================================================== */

export interface PaymentReceiptModalProps {
  isOpen: boolean;
  onClose: () => void;
  payment: Payment | null;
  invoice?: Invoice | null;
  settings: BusinessSettings;
  design?: ReceiptDesignSettings;
  autoPrint?: boolean;
}

export const PaymentReceiptModal: React.FC<PaymentReceiptModalProps> = ({
  isOpen,
  onClose,
  payment,
  invoice,
  settings,
  autoPrint = false,
}) => {
  const [isPrinting, setIsPrinting] = useState<boolean>(false);
  const [isDownloading, setIsDownloading] = useState<boolean>(false);
  const [printError, setPrintError] = useState<string | null>(null);

  const containerRef = useRef<HTMLDivElement>(null);
  const docRef = useRef<HTMLDivElement>(null);
  const [scale, setScale] = useState<number>(1);
  const [docHeight, setDocHeight] = useState<number>(0);

  // Background body scroll lock while modal is open
  useEffect(() => {
    if (!isOpen) return;
    const originalOverflow = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    return () => {
      document.body.style.overflow = originalOverflow;
    };
  }, [isOpen]);

  // Handle ESC key to dismiss modal
  useEffect(() => {
    if (!isOpen) return;
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        onClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
    };
  }, [isOpen, onClose]);

  // Auto-Fit / Auto-Scale calculation based on available container width
  const updateScale = () => {
    if (!containerRef.current) return;
    const containerW = containerRef.current.clientWidth;
    if (!containerW) return;

    const horizontalPadding = containerW < 480 ? 16 : 32;
    const availableW = Math.max(260, containerW - horizontalPadding);
    const baseW = 794; // Standard A4 width in pixels at 96 DPI (210mm)

    let targetScale = availableW / baseW;

    if (targetScale > 1) {
      targetScale = 1;
    } else {
      // Smooth scaling down to fit smaller tablet & mobile screens
      targetScale = Math.max(0.35, targetScale);
    }

    setScale(parseFloat(targetScale.toFixed(3)));

    if (docRef.current) {
      setDocHeight(docRef.current.offsetHeight);
    }
  };

  useEffect(() => {
    if (!isOpen) return;
    updateScale();

    const containerEl = containerRef.current;
    const docEl = docRef.current;

    let ro: ResizeObserver | null = null;
    if (typeof ResizeObserver !== 'undefined' && containerEl) {
      ro = new ResizeObserver(() => {
        updateScale();
      });
      ro.observe(containerEl);
      if (docEl) ro.observe(docEl);
    }

    window.addEventListener('resize', updateScale);
    return () => {
      if (ro) ro.disconnect();
      window.removeEventListener('resize', updateScale);
    };
  }, [isOpen, payment?.id]);

  // Reset printing, downloading, and error states when closed
  useEffect(() => {
    if (!isOpen) {
      setIsPrinting(false);
      setIsDownloading(false);
      setPrintError(null);
    }
  }, [isOpen]);

  const handlePrintReceipt = async () => {
    if (!payment || isPrinting) return;
    setIsPrinting(true);
    setPrintError(null);

    // CRITICAL USER-ACTIVATION: Synchronously open print window directly on click turn (ZERO awaits before this call)
    let printWindow: Window | null = null;
    const isEmbedded = isEmbeddedContext();
    if (isEmbedded) {
      try {
        printWindow = window.open('', '_blank');
      } catch (err) {
        console.warn('[Receipt Print] window.open failed:', err);
      }
      if (!printWindow) {
        setPrintError(
          'Your browser blocked the print window. Please allow pop-ups for this site and try again.'
        );
        setIsPrinting(false);
        return;
      }
    }

    try {
      await printPaymentReceiptDocument(payment, invoice, settings, printWindow);
    } catch (err: any) {
      console.error('Error opening print preview:', err);
      setPrintError(err?.message || 'Failed to open print preview. Please try again.');
    } finally {
      setIsPrinting(false);
    }
  };

  const handleDownloadReceipt = async () => {
    if (!payment || isDownloading) return;
    setIsDownloading(true);
    setPrintError(null);

    try {
      await downloadPaymentReceiptPdf(payment, invoice, settings);
    } catch (err: any) {
      console.error('Error downloading receipt PDF:', err);
      setPrintError(err?.message || 'Failed to download receipt PDF.');
    } finally {
      setIsDownloading(false);
    }
  };

  // Auto-print support when opened specifically via direct print request
  useEffect(() => {
    if (isOpen && autoPrint && payment) {
      handlePrintReceipt();
    }
  }, [isOpen, autoPrint, payment?.id]);

  if (!isOpen || !payment) return null;

  const customerName =
    payment.customerName ||
    invoice?.customerSnapshot?.name ||
    (invoice as any)?.customerName ||
    'Customer';
  const invoiceNumber = payment.billNumber || invoice?.billNumber || '—';

  return (
    <div
      id="payment-receipt-modal"
      className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 md:p-6 bg-black/60 backdrop-blur-xs overscroll-contain"
      role="dialog"
      aria-modal="true"
      aria-labelledby="payment-receipt-modal-title"
    >
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-4xl overflow-hidden border border-neutral-200 flex flex-col max-h-[96vh] sm:max-h-[92vh]">
        {/* Pinned Modal Header Bar */}
        <div className="flex items-center justify-between px-4 sm:px-6 py-3.5 border-b border-neutral-200 bg-neutral-900 text-white shrink-0">
          <div className="flex items-center gap-2.5 min-w-0">
            <div className="w-8 h-8 rounded-lg bg-neutral-800 border border-neutral-700 flex items-center justify-center shrink-0">
              <Receipt className="w-4 h-4 text-orange-400" />
            </div>
            <div className="min-w-0">
              <h2
                id="payment-receipt-modal-title"
                className="text-sm sm:text-base font-bold text-white truncate"
              >
                Payment Receipt (A4)
              </h2>
              <p className="text-[11px] text-neutral-400 truncate">
                Invoice {invoiceNumber} • {customerName}
              </p>
            </div>
          </div>

          <button
            type="button"
            id="btn-receipt-header-close"
            onClick={onClose}
            className="p-1.5 sm:p-2 text-neutral-400 hover:text-white hover:bg-neutral-800 rounded-lg transition cursor-pointer shrink-0 ml-2"
            title="Close receipt"
            aria-label="Close receipt"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Scrollable Receipt Document Viewport with Responsive Auto-Fit */}
        <div
          ref={containerRef}
          className="flex-1 min-h-0 overflow-y-auto overflow-x-hidden p-2 sm:p-5 md:p-6 bg-neutral-100/70 overscroll-contain flex flex-col items-center"
        >
          <div
            style={{
              width: '794px',
              maxWidth: '100%',
              transform: `scale(${scale})`,
              transformOrigin: 'top center',
              transition: 'transform 0.15s ease-out',
              marginBottom:
                docHeight && scale !== 1
                  ? `${Math.round(docHeight * scale - docHeight)}px`
                  : undefined,
            }}
            className="shrink-0 drop-shadow-md"
          >
            <div ref={docRef}>
              <PaymentReceiptDocument
                payment={payment}
                invoice={invoice}
                settings={settings}
              />
            </div>
          </div>
        </div>

        {/* Pinned Action Controls Footer: Print, Download & Close */}
        <div
          id="payment-receipt-actions"
          className="px-4 sm:px-6 py-3 sm:py-4 border-t border-neutral-200 bg-neutral-50 flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-2.5 shrink-0"
        >
          {/* Action buttons: Print & Download */}
          <div className="flex items-center gap-2 flex-1 sm:flex-initial flex-wrap">
            <button
              type="button"
              id="btn-receipt-print"
              onClick={handlePrintReceipt}
              disabled={isPrinting}
              className="flex-1 sm:flex-initial px-4 py-2 text-xs font-semibold bg-white hover:bg-neutral-100 text-neutral-800 rounded-lg border border-neutral-300 transition inline-flex items-center justify-center gap-2 cursor-pointer shadow-2xs active:scale-[0.98] disabled:opacity-60 disabled:cursor-not-allowed"
              title="Print A4 Payment Receipt"
              aria-label="Print Receipt"
            >
              {isPrinting ? (
                <>
                  <Loader2 className="w-4 h-4 text-orange-600 animate-spin shrink-0" />
                  <span>Preparing Print...</span>
                </>
              ) : (
                <>
                  <Printer className="w-4 h-4 text-neutral-700 shrink-0" />
                  <span>Print Receipt</span>
                </>
              )}
            </button>

            <button
              type="button"
              id="btn-receipt-download"
              onClick={handleDownloadReceipt}
              disabled={isDownloading}
              className="flex-1 sm:flex-initial px-4 py-2 text-xs font-semibold bg-white hover:bg-neutral-100 text-neutral-800 rounded-lg border border-neutral-300 transition inline-flex items-center justify-center gap-2 cursor-pointer shadow-2xs active:scale-[0.98] disabled:opacity-60 disabled:cursor-not-allowed"
              title="Download A4 PDF Receipt"
              aria-label="Download Receipt"
            >
              {isDownloading ? (
                <>
                  <Loader2 className="w-4 h-4 text-orange-600 animate-spin shrink-0" />
                  <span>Exporting PDF...</span>
                </>
              ) : (
                <>
                  <Download className="w-4 h-4 text-orange-600 shrink-0" />
                  <span>Download PDF</span>
                </>
              )}
            </button>

            {printError && (
              <span className="text-[11px] font-medium text-rose-600 w-full sm:w-auto">
                {printError}
              </span>
            )}
          </div>

          {/* Close Action */}
          <button
            type="button"
            id="btn-receipt-close"
            onClick={onClose}
            className="w-full sm:w-auto px-5 py-2 text-xs font-bold text-white bg-neutral-900 hover:bg-black rounded-lg transition shadow-xs cursor-pointer active:scale-[0.98] text-center"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
