import React, { useState, useEffect } from 'react';
import { Invoice, Payment, Customer } from '../../types';
import { addCashPayment } from '../../services/db';
import { useAuth } from '../../context/AuthContext';
import {
  getAuthorizedInvoicesForPayments,
  canUserCollectForInvoice,
} from '../../services/dashboardAuthorization';
import {
  calculateTotalPaidForInvoice,
  calculateRemaining,
  formatAFN,
  getTodayDateString,
} from '../../utils/format';
import { X, DollarSign, AlertCircle, CheckCircle2, ShieldAlert } from 'lucide-react';

interface PaymentModalProps {
  isOpen: boolean;
  onClose: () => void;
  invoices: Invoice[];
  payments: Payment[];
  preselectedInvoiceId?: string;
  isCorrectionMode?: boolean;
  onSuccess?: (paymentId?: string) => void;
}

export const PaymentModal: React.FC<PaymentModalProps> = ({
  isOpen,
  onClose,
  invoices,
  payments,
  preselectedInvoiceId,
  isCorrectionMode = false,
  onSuccess,
}) => {
  const { userProfile } = useAuth();
  const [selectedInvoiceId, setSelectedInvoiceId] = useState<string>('');
  const [amount, setAmount] = useState<number | ''>('');
  const [date, setDate] = useState<string>(getTodayDateString());
  const [note, setNote] = useState<string>('');
  const [saving, setSaving] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  // Filter invoices based on user role & collector assignment
  const authorizedInvoices = getAuthorizedInvoicesForPayments(userProfile, invoices);

  useEffect(() => {
    if (!isOpen) return;

    if (preselectedInvoiceId) {
      const targetInv = invoices.find((i) => i.id === preselectedInvoiceId);
      if (targetInv && !canUserCollectForInvoice(userProfile, targetInv)) {
        setError('Access Denied: You are not authorized to collect payments for this invoice.');
        setSelectedInvoiceId('');
      } else {
        setSelectedInvoiceId(preselectedInvoiceId);
        setError(null);
      }
    } else {
      setSelectedInvoiceId('');
      setError(null);
    }

    setAmount('');
    setDate(getTodayDateString());
    setNote('');
  }, [isOpen, preselectedInvoiceId, isCorrectionMode, invoices, userProfile]);

  // Prevent background page from scrolling while modal is open
  useEffect(() => {
    if (!isOpen) return;
    const originalOverflow = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    return () => {
      document.body.style.overflow = originalOverflow;
    };
  }, [isOpen]);

  // Handle ESC key to dismiss modal
  useEffect(() => {
    if (!isOpen) return;
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        onClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  const selectedInvoice = invoices.find((inv) => inv.id === selectedInvoiceId);
  const invoiceTotal = selectedInvoice ? selectedInvoice.totalAmount : 0;
  const currentTotalPaid = selectedInvoice
    ? calculateTotalPaidForInvoice(selectedInvoice.id, payments)
    : 0;
  const currentRemaining = calculateRemaining(invoiceTotal, currentTotalPaid);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedInvoice) {
      setError('Please select a valid invoice to apply payment.');
      return;
    }

    if (!canUserCollectForInvoice(userProfile, selectedInvoice)) {
      setError('Access Denied: You are not authorized to collect payments for this invoice.');
      return;
    }

    const numAmount = Number(amount);
    if (!numAmount || numAmount <= 0) {
      setError('Payment amount must be greater than zero.');
      return;
    }

    // Payment Date validation (Payment Date <= Today)
    const todayStr = getTodayDateString();
    if (!date || date > todayStr) {
      setError(`Payment date cannot be in the future (Payment Date must be on or before today).`);
      return;
    }

    if (currentRemaining <= 0) {
      setError('This invoice is already fully paid. No further payments can be recorded.');
      return;
    }

    if (numAmount > currentRemaining) {
      setError(
        `Payment amount of AFN ${numAmount.toLocaleString('en-US')} exceeds the remaining balance of AFN ${currentRemaining.toLocaleString('en-US')}. Overpayment is not allowed.`
      );
      return;
    }

    setSaving(true);
    setError(null);

    try {
      const newPaymentId = await addCashPayment({
        invoiceId: selectedInvoice.id,
        billNumber: selectedInvoice.billNumber,
        customerId: selectedInvoice.customerId,
        customerName: selectedInvoice.customerSnapshot.name,
        amount: numAmount,
        date,
        note: note.trim(),
        isCorrection: isCorrectionMode,
        userId: userProfile?.id || 'system',
        userName: userProfile?.name || 'Staff',
        userRole: userProfile?.role,
      });

      if (onSuccess) onSuccess(newPaymentId);
      onClose();
    } catch (err: any) {
      console.error('Error adding cash payment:', err);
      setError(err.message || 'Failed to record cash payment.');
    } finally {
      setSaving(false);
    }
  };

  const isAlreadyPaid = selectedInvoice && currentRemaining <= 0;

  return (
    <div
      id="record-payment-modal-overlay"
      className="fixed inset-0 z-50 flex items-center justify-center p-2.5 sm:p-4 md:p-6 bg-black/70 backdrop-blur-xs overflow-y-auto"
      onClick={onClose}
      role="dialog"
      aria-modal="true"
      aria-labelledby="record-payment-title"
    >
      <div
        id="record-payment-modal-container"
        className="bg-white rounded-xl sm:rounded-2xl shadow-2xl border border-neutral-200 w-full max-w-lg my-auto overflow-hidden flex flex-col max-h-[calc(100dvh-1.5rem)] sm:max-h-[calc(100dvh-3rem)] animate-in fade-in zoom-in-95 duration-150"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between px-4 sm:px-6 py-3.5 sm:py-4 border-b border-neutral-200 bg-neutral-900 text-white shrink-0">
          <div className="flex items-center gap-2.5 min-w-0 pr-2">
            <div className="p-1.5 rounded-lg bg-orange-500/20 text-orange-400 shrink-0">
              <DollarSign className="w-5 h-5 text-orange-400" />
            </div>
            <div className="min-w-0">
              <h2 id="record-payment-title" className="text-sm sm:text-base font-bold truncate">
                {isCorrectionMode ? 'Record Payment Correction (Cash)' : 'Record Cash Payment'}
              </h2>
              <p className="text-[11px] text-neutral-400 truncate">
                Payment method: CASH ONLY • Overpayment Protected
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close modal"
            className="p-1.5 rounded-lg text-neutral-400 hover:text-white hover:bg-neutral-800 transition shrink-0 min-h-[36px] min-w-[36px] flex items-center justify-center cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Scrollable Form Body */}
        <form onSubmit={handleSubmit} className="p-4 sm:p-6 space-y-4 overflow-y-auto flex-1">
          {error && (
            <div className="p-3 bg-red-50 border border-red-200 text-red-700 text-xs rounded-lg flex items-start gap-2 break-words">
              <AlertCircle className="w-4 h-4 shrink-0 text-red-500 mt-0.5" />
              <span>{error}</span>
            </div>
          )}

          {/* Select Invoice */}
          <div>
            <label className="text-xs font-semibold text-neutral-700 block mb-1">
              Select Invoice / Bill No. *
            </label>
            <select
              required
              value={selectedInvoiceId}
              onChange={(e) => {
                setSelectedInvoiceId(e.target.value);
                setError(null);
              }}
              className="w-full text-xs border border-neutral-300 rounded-lg px-3 py-2.5 bg-white focus:outline-none focus:ring-1 focus:ring-orange-500 font-medium"
            >
              <option value="">-- Choose Authorized Invoice --</option>
              {authorizedInvoices.map((inv) => {
                const paid = calculateTotalPaidForInvoice(inv.id, payments);
                const rem = calculateRemaining(inv.totalAmount, paid);
                const isPaid = rem <= 0;
                return (
                  <option key={inv.id} value={inv.id} disabled={isPaid}>
                    {inv.billNumber} • {inv.customerSnapshot?.name || 'Customer'} • Remaining: {formatAFN(rem)} {isPaid ? '(FULLY PAID)' : `(${inv.status})`}
                  </option>
                );
              })}
            </select>
            {authorizedInvoices.length === 0 && (
              <p className="text-[11px] text-amber-700 mt-1.5 flex items-center gap-1">
                <ShieldAlert className="w-3.5 h-3.5 shrink-0" />
                <span>No invoices are currently assigned to your account for collection.</span>
              </p>
            )}
          </div>

          {/* If invoice selected, show financial snapshot */}
          {selectedInvoice && (
            <div className="bg-neutral-50 p-3 sm:p-4 rounded-xl border border-neutral-200 text-xs space-y-2">
              <div className="flex flex-col xs:flex-row xs:justify-between xs:items-center gap-0.5">
                <span className="text-neutral-500 font-medium">Customer:</span>
                <span className="font-bold text-neutral-900 break-words sm:text-right">
                  {selectedInvoice.customerSnapshot.name} {selectedInvoice.customerSnapshot.phone ? `(${selectedInvoice.customerSnapshot.phone})` : ''}
                </span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-neutral-500 font-medium">Customer ID:</span>
                <span className="font-mono text-neutral-700 font-semibold">
                  {selectedInvoice.customerId || 'CUST-N/A'}
                </span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-neutral-500 font-medium">Invoice Total:</span>
                <span className="font-mono font-bold text-neutral-800">
                  {formatAFN(invoiceTotal)}
                </span>
              </div>
              <div className="flex justify-between items-center text-emerald-700">
                <span className="font-medium">Already Paid (Cash):</span>
                <span className="font-mono font-bold">{formatAFN(currentTotalPaid)}</span>
              </div>
              <div className="flex justify-between items-center border-t border-neutral-200 pt-2 text-neutral-900 font-bold">
                <span className="text-orange-600">Remaining Balance:</span>
                <span className="font-mono text-orange-600 font-black text-sm">
                  {formatAFN(currentRemaining)}
                </span>
              </div>
              {isAlreadyPaid && (
                <div className="p-2.5 bg-emerald-50 border border-emerald-200 rounded-lg text-emerald-700 font-medium flex items-center gap-2 mt-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                  <span className="text-[11px] sm:text-xs">This invoice is fully settled. No further payments required.</span>
                </div>
              )}
            </div>
          )}

          {/* Amount and Date */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="text-xs font-semibold text-neutral-700 block mb-1">
                Cash Amount (AFN) *
              </label>
              <input
                type="number"
                min="1"
                max={currentRemaining > 0 ? currentRemaining : undefined}
                disabled={isAlreadyPaid || !selectedInvoice}
                required
                value={amount}
                onChange={(e) => setAmount(e.target.value === '' ? '' : Number(e.target.value))}
                placeholder={currentRemaining > 0 ? `Max: ${currentRemaining}` : 'Amount AFN'}
                className="w-full text-xs font-mono font-bold border border-neutral-300 rounded-lg px-3 py-2.5 focus:outline-none focus:ring-1 focus:ring-orange-500 disabled:bg-neutral-100 disabled:text-neutral-400"
              />
            </div>
            <div>
              <label className="text-xs font-semibold text-neutral-700 block mb-1">
                Payment Date *
              </label>
              <input
                type="date"
                required
                max={getTodayDateString()}
                disabled={isAlreadyPaid || !selectedInvoice}
                value={date}
                onChange={(e) => setDate(e.target.value)}
                className="w-full text-xs font-mono border border-neutral-300 rounded-lg px-3 py-2.5 focus:outline-none focus:ring-1 focus:ring-orange-500 disabled:bg-neutral-100"
              />
            </div>
          </div>

          <div>
            <label className="text-xs font-semibold text-neutral-700 block mb-1">
              Payment Note (Optional)
            </label>
            <input
              type="text"
              disabled={isAlreadyPaid || !selectedInvoice}
              value={note}
              onChange={(e) => setNote(e.target.value)}
              placeholder="Optional note..."
              className="w-full text-xs border border-neutral-300 rounded-lg px-3 py-2.5 focus:outline-none focus:ring-1 focus:ring-orange-500 disabled:bg-neutral-100"
            />
          </div>

          <div className="pt-3 border-t border-neutral-100 flex flex-col-reverse sm:flex-row items-stretch sm:items-center justify-end gap-2.5">
            <button
              type="button"
              onClick={onClose}
              className="w-full sm:w-auto px-4 py-2.5 text-xs font-semibold text-neutral-700 hover:bg-neutral-100 border border-neutral-200 sm:border-transparent rounded-lg transition cursor-pointer text-center"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={saving || !selectedInvoice || isAlreadyPaid}
              className="w-full sm:w-auto px-5 py-2.5 text-xs font-bold bg-neutral-900 hover:bg-black text-white rounded-lg transition disabled:opacity-50 inline-flex items-center justify-center gap-2 cursor-pointer disabled:cursor-not-allowed shadow-xs"
            >
              {saving ? 'Recording...' : 'Record Cash Payment'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
