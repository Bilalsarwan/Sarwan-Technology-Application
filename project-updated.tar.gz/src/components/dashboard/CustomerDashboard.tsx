import React, { useState } from 'react';
import { CustomerDashboardData } from '../../services/dashboardAuthorization';
import { Invoice, Payment, CustomerRequest, Project, BusinessSettings } from '../../types';
import {
  formatAFN,
  formatDate,
  calculateTotalPaidForInvoice,
  calculateRemaining,
} from '../../utils/format';
import {
  FileText,
  DollarSign,
  Wallet,
  Clock,
  CheckCircle2,
  AlertCircle,
  Plus,
  MessageSquare,
  Sparkles,
  Phone,
  Receipt,
  ChevronRight,
  ShieldCheck,
  Eye,
  Video,
  Send,
  XCircle,
  Ban,
} from 'lucide-react';
import { PaymentReceiptModal } from '../payment/PaymentReceiptModal';

interface CustomerDashboardProps {
  data: CustomerDashboardData;
  settings: BusinessSettings;
  onSelectInvoice: (invoice: Invoice) => void;
  onNewRequest?: () => void;
  onRequestProject?: (project: Project) => void;
  payments: Payment[];
}

export const CustomerDashboard: React.FC<CustomerDashboardProps> = ({
  data,
  settings,
  onSelectInvoice,
  onNewRequest,
  onRequestProject,
  payments,
}) => {
  const [selectedReceiptPayment, setSelectedReceiptPayment] = useState<Payment | null>(null);
  const [activeSubTab, setActiveSubTab] = useState<'invoices' | 'payments' | 'requests' | 'projects'>('invoices');

  // Status mapping for visual pipeline
  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'New':
        return 'bg-blue-100 text-blue-800 border-blue-200';
      case 'In Review':
        return 'bg-amber-100 text-amber-800 border-amber-200';
      case 'Quoted':
        return 'bg-purple-100 text-purple-800 border-purple-200';
      case 'Invoice Created':
        return 'bg-emerald-100 text-emerald-800 border-emerald-200';
      case 'Completed':
        return 'bg-neutral-100 text-neutral-800 border-neutral-200';
      default:
        return 'bg-neutral-100 text-neutral-600 border-neutral-200';
    }
  };

  return (
    <div className="space-y-6">
      {/* Top Welcome Banner */}
      <div className="bg-white rounded-2xl p-6 border border-neutral-200 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div className="flex items-center gap-4">
          <div className="w-14 h-14 rounded-2xl bg-orange-100 text-orange-700 font-extrabold text-2xl flex items-center justify-center shrink-0 border border-orange-200 shadow-xs">
            {data.customerName.charAt(0) || 'C'}
          </div>
          <div>
            <div className="flex items-center gap-2 flex-wrap">
              <h1 className="text-xl font-bold text-neutral-900">{data.customerName}</h1>
              <span className="text-[10px] font-bold px-2 py-0.5 bg-emerald-50 text-emerald-700 border border-emerald-200 rounded-full flex items-center gap-1">
                <ShieldCheck className="w-3 h-3 text-emerald-600" />
                Verified Client Account
              </span>
            </div>
            <p className="text-xs text-neutral-500 mt-1">
              Sarwan Technology Client Portal &bull; Personal Invoices, Cash Receipts &amp; Requests
            </p>
          </div>
        </div>

        {/* Quick Action: New Service Request */}
        {onNewRequest && (
          <button
            onClick={onNewRequest}
            className="px-4 py-2.5 bg-[#F58220] hover:bg-[#e0751a] text-white text-xs font-bold rounded-lg shadow-sm transition inline-flex items-center justify-center gap-1.5 cursor-pointer active:scale-98 self-start md:self-auto"
          >
            <Plus className="w-4 h-4" />
            Request Service / Quote
          </button>
        )}
      </div>

      {/* Financial Overview Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        {/* Total Invoiced Amount */}
        <div className="bg-white rounded-xl p-4 border border-neutral-200 shadow-xs">
          <div className="flex items-center justify-between text-neutral-500 mb-2">
            <span className="text-[11px] font-bold uppercase tracking-wide">Total Billed</span>
            <FileText className="w-4 h-4 text-neutral-400" />
          </div>
          <p className="text-2xl font-bold font-mono text-neutral-900">
            {formatAFN(data.totalInvoicedAmount)}
          </p>
          <span className="text-[10px] text-neutral-400 mt-1 block">
            Across {data.myInvoices.length} invoices
          </span>
        </div>

        {/* Total Paid Amount */}
        <div className="bg-emerald-50/60 rounded-xl p-4 border border-emerald-200 shadow-xs">
          <div className="flex items-center justify-between text-emerald-800 mb-2">
            <span className="text-[11px] font-bold uppercase tracking-wide">Total Paid (Cash)</span>
            <DollarSign className="w-4 h-4 text-emerald-600" />
          </div>
          <p className="text-2xl font-bold font-mono text-emerald-700">
            {formatAFN(data.totalPaidAmount)}
          </p>
          <span className="text-[10px] text-emerald-600 mt-1 block font-medium">
            Receipts confirmed
          </span>
        </div>

        {/* Total Outstanding Amount */}
        <div className="bg-neutral-900 text-white rounded-xl p-4 shadow-xs border border-neutral-800">
          <div className="flex items-center justify-between text-orange-400 mb-2">
            <span className="text-[11px] font-bold uppercase tracking-wide">Remaining Due</span>
            <Wallet className="w-4 h-4 text-orange-400" />
          </div>
          <p className="text-2xl font-black font-mono text-white">
            {formatAFN(data.totalOutstandingAmount)}
          </p>
          <span className="text-[10px] text-neutral-400 mt-1 block">
            Current outstanding balance
          </span>
        </div>
      </div>

      {/* Invoice Status Distribution */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
        <div className="bg-white p-4 rounded-xl border border-rose-100 bg-rose-50/20 shadow-xs flex items-center justify-between">
          <div>
            <span className="text-[11px] font-bold uppercase text-rose-700 tracking-wide">Unpaid Invoices</span>
            <p className="text-xl font-bold font-mono text-rose-700 mt-1">{data.unpaidInvoicesCount}</p>
            <p className="text-[10px] text-neutral-400 mt-0.5">Awaiting payment</p>
          </div>
          <Clock className="w-6 h-6 text-rose-400" />
        </div>

        <div className="bg-white p-4 rounded-xl border border-amber-100 bg-amber-50/20 shadow-xs flex items-center justify-between">
          <div>
            <span className="text-[11px] font-bold uppercase text-amber-700 tracking-wide">Partial Invoices</span>
            <p className="text-xl font-bold font-mono text-amber-700 mt-1">{data.partialInvoicesCount}</p>
            <p className="text-[10px] text-neutral-400 mt-0.5">Partially settled</p>
          </div>
          <AlertCircle className="w-6 h-6 text-amber-400" />
        </div>

        <div className="bg-white p-4 rounded-xl border border-emerald-100 bg-emerald-50/20 shadow-xs flex items-center justify-between">
          <div>
            <span className="text-[11px] font-bold uppercase text-emerald-700 tracking-wide">Paid Invoices</span>
            <p className="text-xl font-bold font-mono text-emerald-700 mt-1">{data.paidInvoicesCount}</p>
            <p className="text-[10px] text-neutral-400 mt-0.5">Fully cleared bills</p>
          </div>
          <CheckCircle2 className="w-6 h-6 text-emerald-600" />
        </div>
      </div>

      {/* Sub-tab Navigation */}
      <div className="bg-white rounded-xl border border-neutral-200 shadow-xs overflow-hidden">
        <div className="p-4 sm:p-5 border-b border-neutral-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <h2 className="text-sm font-bold text-neutral-900">Personal Account Hub</h2>
            <p className="text-xs text-neutral-500">Access your bills, payments, requests, and security packages</p>
          </div>

          <div className="flex flex-wrap items-center gap-1.5 bg-neutral-100 p-1 rounded-lg">
            <button
              onClick={() => setActiveSubTab('invoices')}
              className={`px-3 py-1.5 text-xs font-semibold rounded-md transition cursor-pointer ${
                activeSubTab === 'invoices'
                  ? 'bg-white text-neutral-900 shadow-xs font-bold'
                  : 'text-neutral-500 hover:text-neutral-900'
              }`}
            >
              My Invoices ({data.myInvoices.length})
            </button>
            <button
              onClick={() => setActiveSubTab('payments')}
              className={`px-3 py-1.5 text-xs font-semibold rounded-md transition cursor-pointer ${
                activeSubTab === 'payments'
                  ? 'bg-white text-neutral-900 shadow-xs font-bold'
                  : 'text-neutral-500 hover:text-neutral-900'
              }`}
            >
              My Payments ({data.myPayments.length})
            </button>
            <button
              onClick={() => setActiveSubTab('requests')}
              className={`px-3 py-1.5 text-xs font-semibold rounded-md transition cursor-pointer ${
                activeSubTab === 'requests'
                  ? 'bg-white text-neutral-900 shadow-xs font-bold'
                  : 'text-neutral-500 hover:text-neutral-900'
              }`}
            >
              My Requests ({data.myRequests.length})
            </button>
            <button
              onClick={() => setActiveSubTab('projects')}
              className={`px-3 py-1.5 text-xs font-semibold rounded-md transition cursor-pointer ${
                activeSubTab === 'projects'
                  ? 'bg-white text-neutral-900 shadow-xs font-bold'
                  : 'text-neutral-500 hover:text-neutral-900'
              }`}
            >
              Security Showcase
            </button>
          </div>
        </div>

        {/* Tab 1: My Invoices */}
        {activeSubTab === 'invoices' && (
          <div>
            {data.myInvoices.length === 0 ? (
              <div className="p-10 text-center text-neutral-400 text-xs">
                <FileText className="w-8 h-8 text-neutral-300 mx-auto mb-2" />
                <p className="font-semibold text-neutral-700">No invoices issued to your account yet.</p>
                <p className="mt-1">
                  Once Sarwan Technology generates an invoice for your equipment or service, you will see it here.
                </p>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-xs">
                  <thead>
                    <tr className="bg-neutral-50 text-neutral-600 font-semibold border-b border-neutral-200 text-left">
                      <th className="py-3 px-4">Bill No.</th>
                      <th className="py-3 px-4">Date</th>
                      <th className="py-3 px-4 text-right">Total Amount</th>
                      <th className="py-3 px-4 text-right">Paid (Cash)</th>
                      <th className="py-3 px-4 text-right">Remaining Due</th>
                      <th className="py-3 px-4 text-center">Status</th>
                      <th className="py-3 px-4 text-right">Action</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-neutral-100">
                    {data.myInvoices.map((inv) => {
                      const isQuotation = inv.billingState === 'quotation';
                      const isRejected = inv.billingState === 'rejected';
                      const isVoid = inv.isVoid === true || inv.status === 'Void';
                      const paid = calculateTotalPaidForInvoice(inv.id, payments);
                      const remaining = calculateRemaining(inv.totalAmount, paid);

                      return (
                        <tr
                          key={inv.id}
                          onClick={() => onSelectInvoice(inv)}
                          className="hover:bg-neutral-50 cursor-pointer transition"
                        >
                          <td className="py-3 px-4 font-mono font-bold text-neutral-900">
                            {inv.billNumber}
                          </td>
                          <td className="py-3 px-4 text-neutral-600">{formatDate(inv.date)}</td>
                          <td className="py-3 px-4 text-right font-mono font-bold text-neutral-900">
                            {formatAFN(inv.totalAmount)}
                          </td>
                          <td className="py-3 px-4 text-right font-mono font-bold text-emerald-700">
                            {isQuotation || isRejected ? (
                              <span className="text-neutral-400 font-normal text-xs">—</span>
                            ) : (
                              formatAFN(paid)
                            )}
                          </td>
                          <td className="py-3 px-4 text-right font-mono font-bold text-orange-600">
                            {isVoid ? (
                              <span className="text-neutral-400 font-normal text-xs">؋ 0 (Void)</span>
                            ) : isQuotation ? (
                              <span className="text-amber-600 font-normal text-xs">— (Quotation)</span>
                            ) : isRejected ? (
                              <span className="text-rose-600 font-normal text-xs">— (Rejected)</span>
                            ) : (
                              formatAFN(remaining)
                            )}
                          </td>
                          <td className="py-3 px-4 text-center">
                            {isVoid ? (
                              <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-neutral-200 text-neutral-800 border border-neutral-300 inline-flex items-center gap-1">
                                <Ban className="w-2.5 h-2.5" />
                                Void
                              </span>
                            ) : isQuotation ? (
                              <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-amber-100 text-amber-800 border border-amber-300 inline-flex items-center gap-1">
                                <Clock className="w-2.5 h-2.5" />
                                Quotation / Pending Approval
                              </span>
                            ) : isRejected ? (
                              <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-rose-100 text-rose-800 border border-rose-300 inline-flex items-center gap-1">
                                <XCircle className="w-2.5 h-2.5" />
                                Rejected
                              </span>
                            ) : (
                              <span
                                className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold ${
                                  inv.status === 'Paid'
                                    ? 'bg-emerald-100 text-emerald-800'
                                    : inv.status === 'Partially Paid'
                                    ? 'bg-amber-100 text-amber-800'
                                    : 'bg-rose-100 text-rose-800'
                                }`}
                              >
                                {inv.status}
                              </span>
                            )}
                          </td>
                          <td className="py-3 px-4 text-right">
                            {isQuotation ? (
                              <button
                                onClick={() => onSelectInvoice(inv)}
                                className="px-2.5 py-1 bg-emerald-700 hover:bg-emerald-800 text-white rounded text-[11px] font-semibold transition cursor-pointer inline-flex items-center gap-1 shadow-2xs"
                              >
                                <CheckCircle2 className="w-3 h-3" />
                                Review Quote
                              </button>
                            ) : (
                              <button
                                onClick={() => onSelectInvoice(inv)}
                                className="px-2.5 py-1 bg-neutral-900 hover:bg-neutral-800 text-white rounded text-[11px] font-semibold transition cursor-pointer inline-flex items-center gap-1"
                              >
                                <Eye className="w-3 h-3" />
                                View
                              </button>
                            )}
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        )}

        {/* Tab 2: My Payments */}
        {activeSubTab === 'payments' && (
          <div>
            {data.myPayments.length === 0 ? (
              <div className="p-10 text-center text-neutral-400 text-xs">
                <DollarSign className="w-8 h-8 text-neutral-300 mx-auto mb-2" />
                <p className="font-semibold text-neutral-700">No payment receipts on file.</p>
                <p className="mt-1">
                  Cash payments made to Sarwan Technology representatives will be posted here with official receipts.
                </p>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-xs">
                  <thead>
                    <tr className="bg-neutral-50 text-neutral-600 font-semibold border-b border-neutral-200 text-left">
                      <th className="py-3 px-4">Receipt Date</th>
                      <th className="py-3 px-4">Applied Bill</th>
                      <th className="py-3 px-4">Payment Method</th>
                      <th className="py-3 px-4 text-right">Amount Paid</th>
                      <th className="py-3 px-4 text-right">Action</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-neutral-100">
                    {data.myPayments.map((p) => (
                      <tr key={p.id} className="hover:bg-neutral-50 transition">
                        <td className="py-3 px-4 text-neutral-600">{formatDate(p.date)}</td>
                        <td className="py-3 px-4 font-mono font-bold text-neutral-900">{p.billNumber}</td>
                        <td className="py-3 px-4 text-neutral-500">
                          <span className="px-2 py-0.5 bg-neutral-100 rounded text-[10px] font-mono">
                            CASH ONLY
                          </span>
                        </td>
                        <td className="py-3 px-4 text-right font-mono font-bold text-emerald-700">
                          {formatAFN(p.amount)}
                        </td>
                        <td className="py-3 px-4 text-right">
                          <button
                            onClick={() => setSelectedReceiptPayment(p)}
                            className="px-2.5 py-1 bg-emerald-50 text-emerald-700 hover:bg-emerald-100 border border-emerald-200 rounded text-[11px] font-semibold transition cursor-pointer inline-flex items-center gap-1"
                          >
                            <Receipt className="w-3 h-3" />
                            Receipt
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        )}

        {/* Tab 3: Customer Requests with Status Pipeline */}
        {activeSubTab === 'requests' && (
          <div className="p-5">
            {data.myRequests.length === 0 ? (
              <div className="py-8 text-center text-neutral-400 text-xs">
                <MessageSquare className="w-8 h-8 text-neutral-300 mx-auto mb-2" />
                <p className="font-semibold text-neutral-700">No active service or quote requests.</p>
                <p className="mt-1 mb-4">
                  Need security camera installation, maintenance, or equipment quotation?
                </p>
                {onNewRequest && (
                  <button
                    onClick={onNewRequest}
                    className="px-4 py-2 bg-[#F58220] hover:bg-[#e0751a] text-white rounded-lg text-xs font-bold transition inline-flex items-center gap-1.5"
                  >
                    <Plus className="w-4 h-4" />
                    Submit a Request
                  </button>
                )}
              </div>
            ) : (
              <div className="space-y-4">
                {data.myRequests.map((req) => (
                  <div
                    key={req.id}
                    className="p-4 rounded-xl border border-neutral-200 bg-neutral-50/50 space-y-3"
                  >
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                      <h4 className="font-bold text-neutral-900 text-sm">{req.title}</h4>
                      <span
                        className={`text-[10px] font-bold px-2.5 py-0.5 rounded-full border ${getStatusBadge(
                          req.status
                        )}`}
                      >
                        {req.status}
                      </span>
                    </div>

                    <p className="text-xs text-neutral-600 leading-relaxed">{req.description}</p>

                    {/* Visual Progress Steps */}
                    <div className="pt-2 border-t border-neutral-200">
                      <p className="text-[10px] font-semibold text-neutral-400 uppercase tracking-wider mb-1.5">
                        Status Pipeline
                      </p>
                      <div className="grid grid-cols-5 gap-1 text-center text-[10px]">
                        {['New', 'In Review', 'Quoted', 'Invoice Created', 'Completed'].map((step, idx) => {
                          const steps = ['New', 'In Review', 'Quoted', 'Invoice Created', 'Completed'];
                          const currentIdx = steps.indexOf(req.status);
                          const isDone = currentIdx >= idx;
                          const isCurrent = req.status === step;

                          return (
                            <div
                              key={step}
                              className={`p-1.5 rounded text-[10px] font-semibold truncate ${
                                isCurrent
                                  ? 'bg-orange-500 text-white font-bold'
                                  : isDone
                                  ? 'bg-emerald-100 text-emerald-800'
                                  : 'bg-neutral-100 text-neutral-400'
                              }`}
                            >
                              {step}
                            </div>
                          );
                        })}
                      </div>
                    </div>

                    <div className="flex items-center justify-between text-[11px] text-neutral-400 pt-1">
                      <span>Submitted: {formatDate(req.createdAt)}</span>
                      {req.billNumber && (
                        <span className="font-mono text-orange-600 font-bold">
                          Invoice: {req.billNumber}
                        </span>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* Tab 4: Security Showcase / Projects */}
        {activeSubTab === 'projects' && (
          <div className="p-5">
            {data.projectsShowcase.length === 0 ? (
              <div className="py-8 text-center text-neutral-400 text-xs">
                <Sparkles className="w-8 h-8 text-neutral-300 mx-auto mb-2" />
                No security showcase packages published yet.
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {data.projectsShowcase.map((proj) => (
                  <div
                    key={proj.id}
                    className="rounded-xl border border-neutral-200 overflow-hidden bg-white shadow-xs flex flex-col justify-between"
                  >
                    {proj.images?.[0] ? (
                      <img
                        src={proj.images[0]}
                        alt={proj.title}
                        className="h-40 w-full object-cover"
                      />
                    ) : (
                      <div className="h-40 bg-neutral-900 flex items-center justify-center text-neutral-500">
                        <Video className="w-8 h-8 text-neutral-600" />
                      </div>
                    )}
                    <div className="p-4 flex-1 flex flex-col justify-between space-y-2">
                      <div>
                        <span className="text-[10px] font-bold uppercase text-orange-600 tracking-wider">
                          {proj.category || 'Security Surveillance'}
                        </span>
                        <h4 className="font-bold text-neutral-900 text-sm mt-0.5">{proj.title}</h4>
                        <p className="text-xs text-neutral-500 mt-1 line-clamp-2">{proj.description}</p>
                      </div>

                      {onRequestProject && (
                        <button
                          onClick={() => onRequestProject(proj)}
                          className="w-full mt-2 py-1.5 px-3 bg-neutral-900 hover:bg-neutral-800 text-white text-xs font-semibold rounded-lg transition cursor-pointer"
                        >
                          Inquire About Package
                        </button>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}
      </div>

      {/* Payment Receipt Modal */}
      {selectedReceiptPayment && (
        <PaymentReceiptModal
          isOpen={Boolean(selectedReceiptPayment)}
          onClose={() => setSelectedReceiptPayment(null)}
          payment={selectedReceiptPayment}
          settings={settings}
          design={settings.receiptDesign}
        />
      )}
    </div>
  );
};
