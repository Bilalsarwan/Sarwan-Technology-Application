import React, { useState, useRef, useEffect } from 'react';
import {
  Plus,
  DollarSign,
  Users,
  Receipt,
  UserCheck,
  ChevronDown,
  Sparkles,
} from 'lucide-react';

export interface QuickActionsPermissions {
  canCreateInvoice?: boolean;
  canCollectPayment?: boolean;
  canManageCustomers?: boolean;
  canManageExpenses?: boolean;
  canManageStaff?: boolean;
}

interface QuickActionsBarProps {
  onNewInvoice: () => void;
  onAddPayment: () => void;
  onNewCustomer: () => void;
  onAddExpense: () => void;
  onManageStaff: () => void;
  permissions?: QuickActionsPermissions;
}

export const QuickActionsBar: React.FC<QuickActionsBarProps> = ({
  onNewInvoice,
  onAddPayment,
  onNewCustomer,
  onAddExpense,
  onManageStaff,
  permissions = {
    canCreateInvoice: true,
    canCollectPayment: true,
    canManageCustomers: true,
    canManageExpenses: true,
    canManageStaff: true,
  },
}) => {
  const [isMoreOpen, setIsMoreOpen] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  const moreRef = useRef<HTMLDivElement>(null);
  const mobileRef = useRef<HTMLDivElement>(null);

  // Close dropdowns on outside click or Escape
  useEffect(() => {
    const handleOutsideClick = (e: MouseEvent) => {
      if (moreRef.current && !moreRef.current.contains(e.target as Node)) {
        setIsMoreOpen(false);
      }
      if (mobileRef.current && !mobileRef.current.contains(e.target as Node)) {
        setIsMobileMenuOpen(false);
      }
    };

    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        setIsMoreOpen(false);
        setIsMobileMenuOpen(false);
      }
    };

    document.addEventListener('mousedown', handleOutsideClick);
    document.addEventListener('keydown', handleKeyDown);
    return () => {
      document.removeEventListener('mousedown', handleOutsideClick);
      document.removeEventListener('keydown', handleKeyDown);
    };
  }, []);

  const hasMoreItems =
    permissions.canManageExpenses || permissions.canManageStaff;

  return (
    <div
      id="quick-actions-bar"
      className="bg-white rounded-xl border border-neutral-200 shadow-xs p-3 sm:p-3.5 flex items-center justify-between gap-3"
    >
      <div className="flex items-center gap-2 shrink-0">
        <div className="w-8 h-8 rounded-lg bg-orange-50 text-[#F58220] flex items-center justify-center font-bold text-xs shrink-0 border border-orange-100">
          <Sparkles className="w-4 h-4" />
        </div>
        <div>
          <h3 className="text-xs sm:text-sm font-bold text-neutral-900 leading-tight">
            Quick Actions
          </h3>
          <p className="text-[11px] text-neutral-400 hidden sm:block leading-tight">
            Perform daily operations in 1-click
          </p>
        </div>
      </div>

      {/* 1. DESKTOP VIEW (lg+ / xl): All 5 actions in exact specified order */}
      <div className="hidden lg:flex items-center gap-2">
        {permissions.canCreateInvoice && (
          <button
            type="button"
            id="qa-desktop-new-invoice"
            onClick={onNewInvoice}
            className="px-3.5 py-2 bg-[#F58220] hover:bg-[#e0751a] text-white text-xs font-bold rounded-lg shadow-xs transition inline-flex items-center gap-1.5 cursor-pointer active:scale-98 whitespace-nowrap"
          >
            <Plus className="w-4 h-4" />
            <span>New Invoice</span>
          </button>
        )}

        {permissions.canCollectPayment && (
          <button
            type="button"
            id="qa-desktop-add-payment"
            onClick={onAddPayment}
            className="px-3 py-2 bg-neutral-900 hover:bg-neutral-800 text-white text-xs font-semibold rounded-lg border border-neutral-800 transition inline-flex items-center gap-1.5 cursor-pointer whitespace-nowrap"
          >
            <DollarSign className="w-3.5 h-3.5 text-emerald-400" />
            <span>Add Payment</span>
          </button>
        )}

        {permissions.canManageCustomers && (
          <button
            type="button"
            id="qa-desktop-new-customer"
            onClick={onNewCustomer}
            className="px-3 py-2 bg-neutral-900 hover:bg-neutral-800 text-white text-xs font-semibold rounded-lg border border-neutral-800 transition inline-flex items-center gap-1.5 cursor-pointer whitespace-nowrap"
          >
            <Users className="w-3.5 h-3.5 text-orange-400" />
            <span>New Customer</span>
          </button>
        )}

        {permissions.canManageExpenses && (
          <button
            type="button"
            id="qa-desktop-add-expense"
            onClick={onAddExpense}
            className="px-3 py-2 bg-neutral-900 hover:bg-neutral-800 text-white text-xs font-semibold rounded-lg border border-neutral-800 transition inline-flex items-center gap-1.5 cursor-pointer whitespace-nowrap"
          >
            <Receipt className="w-3.5 h-3.5 text-rose-400" />
            <span>Add Expense</span>
          </button>
        )}

        {permissions.canManageStaff && (
          <button
            type="button"
            id="qa-desktop-manage-staff"
            onClick={onManageStaff}
            className="px-3 py-2 bg-neutral-900 hover:bg-neutral-800 text-white text-xs font-semibold rounded-lg border border-neutral-800 transition inline-flex items-center gap-1.5 cursor-pointer whitespace-nowrap"
          >
            <UserCheck className="w-3.5 h-3.5 text-sky-400" />
            <span>Manage Staff</span>
          </button>
        )}
      </div>

      {/* 2. TABLET VIEW (sm to lg): New Invoice | Add Payment | New Customer | More ▾ */}
      <div className="hidden sm:flex lg:hidden items-center gap-2">
        {permissions.canCreateInvoice && (
          <button
            type="button"
            id="qa-tablet-new-invoice"
            onClick={onNewInvoice}
            className="px-3 py-2 bg-[#F58220] hover:bg-[#e0751a] text-white text-xs font-bold rounded-lg shadow-xs transition inline-flex items-center gap-1.5 cursor-pointer active:scale-98 whitespace-nowrap"
          >
            <Plus className="w-4 h-4" />
            <span>New Invoice</span>
          </button>
        )}

        {permissions.canCollectPayment && (
          <button
            type="button"
            id="qa-tablet-add-payment"
            onClick={onAddPayment}
            className="px-3 py-2 bg-neutral-900 hover:bg-neutral-800 text-white text-xs font-semibold rounded-lg border border-neutral-800 transition inline-flex items-center gap-1.5 cursor-pointer whitespace-nowrap"
          >
            <DollarSign className="w-3.5 h-3.5 text-emerald-400" />
            <span>Add Payment</span>
          </button>
        )}

        {permissions.canManageCustomers && (
          <button
            type="button"
            id="qa-tablet-new-customer"
            onClick={onNewCustomer}
            className="px-3 py-2 bg-neutral-900 hover:bg-neutral-800 text-white text-xs font-semibold rounded-lg border border-neutral-800 transition inline-flex items-center gap-1.5 cursor-pointer whitespace-nowrap"
          >
            <Users className="w-3.5 h-3.5 text-orange-400" />
            <span>New Customer</span>
          </button>
        )}

        {hasMoreItems && (
          <div className="relative" ref={moreRef}>
            <button
              type="button"
              id="qa-tablet-more-btn"
              onClick={() => setIsMoreOpen((prev) => !prev)}
              className={`px-3 py-2 bg-neutral-900 hover:bg-neutral-800 text-white text-xs font-semibold rounded-lg border transition inline-flex items-center gap-1.5 cursor-pointer whitespace-nowrap ${
                isMoreOpen ? 'border-orange-500 bg-neutral-800 text-orange-400' : 'border-neutral-800'
              }`}
              aria-expanded={isMoreOpen}
              aria-haspopup="true"
            >
              <span>More</span>
              <ChevronDown
                className={`w-3.5 h-3.5 transition-transform duration-150 ${
                  isMoreOpen ? 'rotate-180 text-orange-400' : 'text-neutral-400'
                }`}
              />
            </button>

            {isMoreOpen && (
              <div className="absolute right-0 mt-2 w-48 bg-neutral-900 border border-neutral-700 rounded-xl shadow-2xl py-1.5 z-50 animate-in fade-in zoom-in-95 duration-100">
                <div className="px-3 py-1 text-[10px] uppercase font-bold tracking-wider text-neutral-400 border-b border-neutral-800 mb-1">
                  Additional Actions
                </div>
                {permissions.canManageExpenses && (
                  <button
                    type="button"
                    onClick={() => {
                      setIsMoreOpen(false);
                      onAddExpense();
                    }}
                    className="w-full px-3.5 py-2 text-left text-xs text-neutral-200 hover:text-white hover:bg-neutral-800 transition flex items-center gap-2.5 cursor-pointer font-medium"
                  >
                    <Receipt className="w-3.5 h-3.5 text-rose-400 shrink-0" />
                    <span>Add Expense</span>
                  </button>
                )}
                {permissions.canManageStaff && (
                  <button
                    type="button"
                    onClick={() => {
                      setIsMoreOpen(false);
                      onManageStaff();
                    }}
                    className="w-full px-3.5 py-2 text-left text-xs text-neutral-200 hover:text-white hover:bg-neutral-800 transition flex items-center gap-2.5 cursor-pointer font-medium"
                  >
                    <UserCheck className="w-3.5 h-3.5 text-sky-400 shrink-0" />
                    <span>Manage Staff</span>
                  </button>
                )}
              </div>
            )}
          </div>
        )}
      </div>

      {/* 3. MOBILE VIEW (< sm): Single compact "+ Quick Actions ▾" dropdown */}
      <div className="relative block sm:hidden" ref={mobileRef}>
        <button
          type="button"
          id="qa-mobile-toggle-btn"
          onClick={() => setIsMobileMenuOpen((prev) => !prev)}
          className="px-3 py-1.5 bg-[#F58220] hover:bg-[#e0751a] text-white text-xs font-bold rounded-lg shadow-xs transition inline-flex items-center gap-1.5 cursor-pointer active:scale-98 whitespace-nowrap"
          aria-expanded={isMobileMenuOpen}
          aria-haspopup="true"
        >
          <Plus className="w-4 h-4" />
          <span>Quick Actions</span>
          <ChevronDown
            className={`w-3.5 h-3.5 transition-transform duration-150 ${
              isMobileMenuOpen ? 'rotate-180' : ''
            }`}
          />
        </button>

        {isMobileMenuOpen && (
          <div className="absolute right-0 mt-2 w-52 bg-neutral-900 border border-neutral-700 rounded-xl shadow-2xl py-1.5 z-50 animate-in fade-in zoom-in-95 duration-100">
            <div className="px-3.5 py-1 text-[10px] uppercase font-bold tracking-wider text-neutral-400 border-b border-neutral-800 mb-1">
              Quick Actions
            </div>

            {permissions.canCreateInvoice && (
              <button
                type="button"
                onClick={() => {
                  setIsMobileMenuOpen(false);
                  onNewInvoice();
                }}
                className="w-full px-3.5 py-2 text-left text-xs text-white hover:bg-neutral-800 transition flex items-center gap-2.5 cursor-pointer font-semibold"
              >
                <div className="p-1 rounded-md bg-orange-500/20 text-[#F58220]">
                  <Plus className="w-3.5 h-3.5" />
                </div>
                <span>New Invoice</span>
              </button>
            )}

            {permissions.canCollectPayment && (
              <button
                type="button"
                onClick={() => {
                  setIsMobileMenuOpen(false);
                  onAddPayment();
                }}
                className="w-full px-3.5 py-2 text-left text-xs text-neutral-200 hover:text-white hover:bg-neutral-800 transition flex items-center gap-2.5 cursor-pointer font-medium"
              >
                <div className="p-1 rounded-md bg-emerald-500/10 text-emerald-400">
                  <DollarSign className="w-3.5 h-3.5" />
                </div>
                <span>Add Payment</span>
              </button>
            )}

            {permissions.canManageCustomers && (
              <button
                type="button"
                onClick={() => {
                  setIsMobileMenuOpen(false);
                  onNewCustomer();
                }}
                className="w-full px-3.5 py-2 text-left text-xs text-neutral-200 hover:text-white hover:bg-neutral-800 transition flex items-center gap-2.5 cursor-pointer font-medium"
              >
                <div className="p-1 rounded-md bg-orange-500/10 text-orange-400">
                  <Users className="w-3.5 h-3.5" />
                </div>
                <span>New Customer</span>
              </button>
            )}

            {permissions.canManageExpenses && (
              <button
                type="button"
                onClick={() => {
                  setIsMobileMenuOpen(false);
                  onAddExpense();
                }}
                className="w-full px-3.5 py-2 text-left text-xs text-neutral-200 hover:text-white hover:bg-neutral-800 transition flex items-center gap-2.5 cursor-pointer font-medium"
              >
                <div className="p-1 rounded-md bg-rose-500/10 text-rose-400">
                  <Receipt className="w-3.5 h-3.5" />
                </div>
                <span>Add Expense</span>
              </button>
            )}

            {permissions.canManageStaff && (
              <button
                type="button"
                onClick={() => {
                  setIsMobileMenuOpen(false);
                  onManageStaff();
                }}
                className="w-full px-3.5 py-2 text-left text-xs text-neutral-200 hover:text-white hover:bg-neutral-800 transition flex items-center gap-2.5 cursor-pointer font-medium"
              >
                <div className="p-1 rounded-md bg-sky-500/10 text-sky-400">
                  <UserCheck className="w-3.5 h-3.5" />
                </div>
                <span>Manage Staff</span>
              </button>
            )}
          </div>
        )}
      </div>
    </div>
  );
};
