import React, { useState, useMemo } from 'react';
import { Customer, CustomerStatus, CustomerType, Invoice, Payment, UserProfile, AuditLog } from '../../types';
import {
  calculateCustomerSummary,
  formatAFN,
  formatDate,
} from '../../utils/format';
import {
  setCustomerStatus,
  deleteCustomerSafely,
  linkCustomerToUserAccount,
  unlinkCustomerUserAccount,
} from '../../services/db';
import { createApplicationUser } from '../../services/security';
import { useAuth } from '../../context/AuthContext';
import { normalizeCustomerStatus } from '../../utils/customerValidation';
import {
  X,
  User,
  Phone,
  Building,
  MapPin,
  Mail,
  FileText,
  DollarSign,
  Archive,
  RotateCcw,
  Clock,
  ChevronRight,
  AlertCircle,
  ShieldCheck,
  Key,
  Trash2,
  Copy,
  Check,
  ExternalLink,
  MessageCircle,
  History,
  Lock,
  Eye,
  Plus,
  AlertTriangle,
  PauseCircle,
  CheckCircle2,
  ShieldAlert,
  Calendar,
  CreditCard,
  Receipt,
  MoreVertical,
  Edit2,
} from 'lucide-react';

interface CustomerDetailModalProps {
  customer: Customer | null;
  invoices: Invoice[];
  payments: Payment[];
  users?: UserProfile[];
  auditLogs?: AuditLog[];
  isOpen: boolean;
  onClose: () => void;
  onSelectInvoice?: (invoice: Invoice) => void;
  onEditCustomer?: (customer: Customer) => void;
  onNewInvoice?: (customer: Customer) => void;
  onAddPayment?: (customer: Customer) => void;
  onRefresh?: () => void;
}

export const CustomerDetailModal: React.FC<CustomerDetailModalProps> = ({
  customer,
  invoices,
  payments,
  users = [],
  auditLogs = [],
  isOpen,
  onClose,
  onSelectInvoice,
  onEditCustomer,
  onNewInvoice,
  onAddPayment,
  onRefresh,
}) => {
  const { userProfile, permissions } = useAuth();
  const isSuperAdmin = userProfile?.role === 'super_admin';
  const canManage = permissions?.canManageCustomers;

  const [activeTab, setActiveTab] = useState<'overview' | 'invoices' | 'payments' | 'activity'>('overview');
  const [statusUpdating, setStatusUpdating] = useState<boolean>(false);
  const [copiedPhone, setCopiedPhone] = useState<boolean>(false);
  const [copiedCode, setCopiedCode] = useState<boolean>(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);

  // More menu dropdown state
  const [showMoreMenu, setShowMoreMenu] = useState<boolean>(false);

  // Delete modal confirmation
  const [showDeleteConfirm, setShowDeleteConfirm] = useState<boolean>(false);
  const [deleting, setDeleting] = useState<boolean>(false);

  // Portal Account inline link state
  const [isLinkingPortal, setIsLinkingPortal] = useState<boolean>(false);
  const [selectedUserToLink, setSelectedUserToLink] = useState<string>('');
  const [isCreatingNewPortalUser, setIsCreatingNewPortalUser] = useState<boolean>(false);
  const [newPortalUsername, setNewPortalUsername] = useState<string>('');
  const [newPortalPassword, setNewPortalPassword] = useState<string>('');
  const [submittingPortal, setSubmittingPortal] = useState<boolean>(false);

  const customerId = customer?.id || '';
  const customerCode = customer ? (customer.customerCode || customer.customerId || customer.id) : '';
  const customerStatus = customer ? normalizeCustomerStatus(customer.status, customer.isArchived) : 'Active';
  const customerType: CustomerType = customer
    ? customer.customerType || (customer.companyName && customer.companyName.trim().length > 0 ? 'Business' : 'Individual')
    : 'Individual';

  const {
    totalInvoices,
    totalSales,
    totalPaid,
    remainingBalance,
    customerInvoices,
    customerPayments,
    hasOverdue,
    financialStatus,
  } = useMemo(() => {
    if (!customer) {
      return {
        totalInvoices: 0,
        totalSales: 0,
        totalPaid: 0,
        remainingBalance: 0,
        customerInvoices: [] as Invoice[],
        customerPayments: [] as Payment[],
        hasOverdue: false,
        financialStatus: 'Paid' as const,
      };
    }
    return calculateCustomerSummary(customer.id, invoices, payments);
  }, [customer, invoices, payments]);

  const hasFinancialTransactions = customerInvoices.length > 0 || customerPayments.length > 0;

  // Resolve linked user account if exists
  const linkedUser = customer
    ? (customer.userId
      ? users.find((u) => u.id === customer.userId || u.customerId === customer.id)
      : users.find((u) => u.customerId === customer.id))
    : undefined;

  // Unlinked user accounts available to link
  const unlinkedUsers = users.filter(
    (u) => u.role === 'customer' && !u.customerId && u.id !== customer?.userId
  );

  const initials = customer
    ? (customer.name || 'C')
        .split(' ')
        .filter(Boolean)
        .slice(0, 2)
        .map((w) => w[0]?.toUpperCase())
        .join('') || 'C'
    : 'C';

  const handleCopyPhone = () => {
    if (!customer.phone) return;
    navigator.clipboard.writeText(customer.phone);
    setCopiedPhone(true);
    setTimeout(() => setCopiedPhone(false), 2000);
  };

  const handleCopyCode = () => {
    navigator.clipboard.writeText(customerCode);
    setCopiedCode(true);
    setTimeout(() => setCopiedCode(false), 2000);
  };

  const handleStatusChange = async (newStatus: CustomerStatus) => {
    setStatusUpdating(true);
    setErrorMessage(null);
    setSuccessMessage(null);
    setShowMoreMenu(false);
    try {
      await setCustomerStatus(
        customer.id,
        newStatus,
        userProfile?.id || 'system',
        userProfile?.name || 'Staff',
        userProfile?.role || 'super_admin'
      );
      setSuccessMessage(`Customer status successfully updated to ${newStatus}.`);
      if (onRefresh) onRefresh();
    } catch (err: any) {
      console.error('Error changing customer status:', err);
      setErrorMessage(err.message || 'Failed to update customer status.');
    } finally {
      setStatusUpdating(false);
    }
  };

  const handleDeleteCustomer = async () => {
    setDeleting(true);
    setErrorMessage(null);
    try {
      await deleteCustomerSafely(
        customer.id,
        userProfile?.id || 'system',
        userProfile?.name || 'Staff'
      );
      setShowDeleteConfirm(false);
      onClose();
      if (onRefresh) onRefresh();
    } catch (err: any) {
      console.error('Error deleting customer:', err);
      setErrorMessage(err.message || 'Cannot delete customer.');
      setShowDeleteConfirm(false);
    } finally {
      setDeleting(false);
    }
  };

  const handleLinkExistingUser = async () => {
    if (!selectedUserToLink) {
      setErrorMessage('Please select a user account to link.');
      return;
    }
    setSubmittingPortal(true);
    setErrorMessage(null);
    try {
      await linkCustomerToUserAccount(
        customer.id,
        selectedUserToLink,
        userProfile?.id || 'system',
        userProfile?.name || 'Staff'
      );
      setSuccessMessage('Customer portal account linked successfully.');
      setIsLinkingPortal(false);
      setSelectedUserToLink('');
      if (onRefresh) onRefresh();
    } catch (err: any) {
      setErrorMessage(err.message || 'Failed to link user account.');
    } finally {
      setSubmittingPortal(false);
    }
  };

  const handleCreateNewPortalUser = async () => {
    const uname = newPortalUsername.trim().toLowerCase();
    if (!uname || uname.length < 3) {
      setErrorMessage('Username must be at least 3 characters.');
      return;
    }
    if (!newPortalPassword || newPortalPassword.length < 6) {
      setErrorMessage('Initial password must be at least 6 characters.');
      return;
    }
    const emailToUse = customer.email?.trim() || `${uname}@customer.sarwan.local`;

    setSubmittingPortal(true);
    setErrorMessage(null);
    try {
      await createApplicationUser({
        name: customer.name,
        username: uname,
        email: emailToUse,
        phone: customer.phone,
        address: customer.address,
        defaultPassword: newPortalPassword,
        role: 'customer',
        status: 'active',
        customerId: customer.id,
        creatorId: userProfile?.id || 'system',
        creatorName: userProfile?.name || 'Staff',
      });
      setSuccessMessage('Customer portal user created and linked successfully.');
      setIsCreatingNewPortalUser(false);
      setNewPortalUsername('');
      setNewPortalPassword('');
      if (onRefresh) onRefresh();
    } catch (err: any) {
      setErrorMessage(err.message || 'Failed to create portal user account.');
    } finally {
      setSubmittingPortal(false);
    }
  };

  const handleUnlinkPortal = async () => {
    if (!window.confirm(`Unlink portal access from customer "${customer.name}"?`)) {
      return;
    }
    setSubmittingPortal(true);
    setErrorMessage(null);
    try {
      await unlinkCustomerUserAccount(
        customer.id,
        userProfile?.id || 'system',
        userProfile?.name || 'Staff'
      );
      setSuccessMessage('Portal account unlinked.');
      if (onRefresh) onRefresh();
    } catch (err: any) {
      setErrorMessage(err.message || 'Failed to unlink portal account.');
    } finally {
      setSubmittingPortal(false);
    }
  };

  // Build Chronological Unified Activity List
  const activityList = useMemo(() => {
    if (!customer) return [];
    const events: Array<{
      id: string;
      title: string;
      description: string;
      date: string;
      type: 'created' | 'updated' | 'invoice' | 'payment' | 'status' | 'portal';
      actor?: string;
    }> = [];

    // 1. Audit Logs
    const relevantLogs = auditLogs.filter(
      (l) => l.entityId === customer.id || l.referenceNumber === customerCode
    );
    relevantLogs.forEach((l) => {
      let t: 'created' | 'updated' | 'status' | 'portal' = 'updated';
      if (l.action === 'create_customer') t = 'created';
      else if (l.summary?.toLowerCase().includes('status')) t = 'status';
      events.push({
        id: `audit-${l.id}`,
        title: l.summary || 'Customer update',
        description: `Action: ${l.action} by ${l.userName} (${l.userRole || 'Staff'})`,
        date: l.dateTime,
        type: t,
        actor: l.userName,
      });
    });

    // 2. Invoices Created
    customerInvoices.forEach((inv) => {
      events.push({
        id: `inv-${inv.id}`,
        title: `Invoice Generated: ${inv.billNumber}`,
        description: `Total: ${formatAFN(inv.totalAmount)} • Status: ${inv.status} • Billing State: ${inv.billingState || 'quotation'}`,
        date: inv.createdAt || inv.date,
        type: 'invoice',
        actor: inv.createdByName,
      });
    });

    // 3. Payments Received
    customerPayments.forEach((p) => {
      events.push({
        id: `pay-${p.id}`,
        title: `Payment Received: ${formatAFN(p.amount)}`,
        description: `Invoice: ${p.billNumber} • Method: ${p.method} • Recorded by ${p.recordedByName || 'Staff'}`,
        date: p.createdAt || p.date,
        type: 'payment',
        actor: p.recordedByName,
      });
    });

    // Sort newest first
    return events.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
  }, [auditLogs, customer, customerCode, customerInvoices, customerPayments]);

  if (!isOpen || !customer) return null;

  const canCreateNewInvoice = customerStatus === 'Active';
  const hasPayableInvoices = customerInvoices.some(
    (inv) =>
      inv.status !== 'Paid' &&
      inv.status !== 'Void' &&
      !inv.isVoid &&
      inv.billingState === 'payable'
  );
  const canAddPayment = customerStatus === 'Active' || hasPayableInvoices;

  return (
    <div
      id="customer-detail-modal-overlay"
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/60 backdrop-blur-xs overflow-y-auto"
    >
      <div
        id="customer-detail-modal-container"
        className="bg-white rounded-xl shadow-2xl w-full max-w-4xl max-h-[92vh] flex flex-col overflow-hidden border border-neutral-200 my-auto"
      >
        {/* Header: Customer ID | Name | Type | Status */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-neutral-200 bg-neutral-900 text-white">
          <div className="flex items-center gap-3.5 min-w-0">
            {/* Customer Photo / Avatar */}
            <div className="w-11 h-11 rounded-full border-2 border-orange-400 overflow-hidden bg-neutral-800 flex items-center justify-center shrink-0">
              {customer.photoURL ? (
                <img
                  src={customer.photoURL}
                  alt={customer.name}
                  className="w-full h-full object-cover"
                  referrerPolicy="no-referrer"
                />
              ) : (
                <span className="text-sm font-bold text-orange-400">{initials}</span>
              )}
            </div>

            <div className="min-w-0">
              <div className="flex flex-wrap items-center gap-2">
                <h2 className="text-base sm:text-lg font-bold truncate">{customer.name}</h2>

                {/* Customer ID */}
                <button
                  type="button"
                  onClick={handleCopyCode}
                  className="font-mono text-xs font-bold px-2 py-0.5 rounded bg-neutral-800 text-orange-400 border border-neutral-700 hover:bg-neutral-700 transition flex items-center gap-1"
                  title="Click to copy Customer ID"
                >
                  <span>{customerCode}</span>
                  {copiedCode ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                </button>

                {/* Customer Type */}
                <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-neutral-800 text-neutral-300 border border-neutral-700">
                  {customerType}
                </span>

                {/* Customer Status Badge */}
                {customerStatus === 'Active' && (
                  <span className="text-[10px] font-bold bg-emerald-900/80 text-emerald-200 border border-emerald-700 px-2 py-0.5 rounded-full flex items-center gap-1">
                    <CheckCircle2 className="w-3 h-3 text-emerald-400" />
                    Active
                  </span>
                )}
                {customerStatus === 'Inactive' && (
                  <span className="text-[10px] font-bold bg-neutral-800 text-neutral-300 border border-neutral-700 px-2 py-0.5 rounded-full flex items-center gap-1">
                    <PauseCircle className="w-3 h-3 text-neutral-400" />
                    Inactive
                  </span>
                )}
                {customerStatus === 'Blocked' && (
                  <span className="text-[10px] font-bold bg-rose-900/80 text-rose-200 border border-rose-700 px-2 py-0.5 rounded-full flex items-center gap-1">
                    <Lock className="w-3 h-3 text-rose-400" />
                    Blocked
                  </span>
                )}
              </div>

              <p className="text-xs text-neutral-400 font-mono mt-0.5 flex items-center gap-2">
                <span>{customer.phone}</span>
                {customer.companyName && (
                  <>
                    <span>•</span>
                    <span className="text-neutral-300">{customer.companyName}</span>
                  </>
                )}
              </p>
            </div>
          </div>

          {/* Action Header Buttons */}
          <div className="flex items-center gap-1.5 sm:gap-2 shrink-0">
            {/* Desktop / Tablet Buttons (hidden on mobile) */}
            <div className="hidden sm:flex items-center gap-2">
              {canManage && onEditCustomer && (
                <button
                  id="btn-edit-customer"
                  type="button"
                  onClick={() => {
                    onClose();
                    onEditCustomer(customer);
                  }}
                  className="px-3 py-1.5 text-xs font-semibold rounded-lg bg-neutral-800 hover:bg-neutral-700 text-neutral-200 border border-neutral-700 transition"
                >
                  Edit
                </button>
              )}

              {onNewInvoice && (
                <button
                  id="btn-new-invoice-for-customer"
                  type="button"
                  disabled={!canCreateNewInvoice}
                  onClick={() => {
                    if (!canCreateNewInvoice) return;
                    onClose();
                    onNewInvoice(customer);
                  }}
                  title={
                    !canCreateNewInvoice
                      ? `Cannot create invoice for an ${customerStatus} customer`
                      : 'Create invoice with customer locked'
                  }
                  className={`px-3 py-1.5 text-xs font-bold rounded-lg transition flex items-center gap-1.5 ${
                    canCreateNewInvoice
                      ? 'bg-orange-500 hover:bg-orange-600 text-white shadow-xs'
                      : 'bg-neutral-800 text-neutral-500 border border-neutral-700 cursor-not-allowed'
                  }`}
                >
                  <Plus className="w-3.5 h-3.5" />
                  New Invoice
                </button>
              )}

              {onAddPayment && (
                <button
                  id="btn-add-payment-for-customer"
                  type="button"
                  disabled={!canAddPayment}
                  onClick={() => {
                    if (!canAddPayment) {
                      setErrorMessage(
                        `Cannot record payment: Customer is ${customerStatus} and has no outstanding payable invoices.`
                      );
                      return;
                    }
                    onClose();
                    onAddPayment(customer);
                  }}
                  title={
                    !canAddPayment
                      ? `Cannot record standalone payments for an ${customerStatus} customer with no outstanding invoices`
                      : 'Record payment against customer invoice'
                  }
                  className={`px-3 py-1.5 text-xs font-bold rounded-lg transition flex items-center gap-1 ${
                    canAddPayment
                      ? 'bg-emerald-600 hover:bg-emerald-700 text-white shadow-xs'
                      : 'bg-neutral-800 text-neutral-500 border border-neutral-700 cursor-not-allowed'
                  }`}
                >
                  <DollarSign className="w-3.5 h-3.5" />
                  Add Payment
                </button>
              )}
            </div>

            {/* Mobile Primary Button */}
            <div className="flex sm:hidden items-center gap-1">
              {onNewInvoice && canCreateNewInvoice && (
                <button
                  type="button"
                  onClick={() => {
                    onClose();
                    onNewInvoice(customer);
                  }}
                  className="px-2.5 py-1 text-xs font-bold rounded-lg bg-orange-500 text-white shadow-xs transition flex items-center gap-1"
                >
                  <Plus className="w-3 h-3" />
                  Invoice
                </button>
              )}
            </div>

            {/* More Menu Dropdown */}
            <div className="relative">
              <button
                id="btn-customer-more-actions"
                type="button"
                onClick={() => setShowMoreMenu((prev) => !prev)}
                className="p-1.5 rounded-lg text-neutral-300 hover:text-white hover:bg-neutral-800 border border-neutral-700 transition"
                title="More actions"
              >
                <MoreVertical className="w-4 h-4" />
              </button>

              {showMoreMenu && (
                <div
                  id="customer-more-dropdown"
                  className="absolute right-0 mt-2 w-56 bg-white rounded-xl shadow-xl border border-neutral-200 py-1.5 z-50 text-xs text-neutral-800"
                >
                  {/* Mobile Actions section */}
                  <div className="block sm:hidden border-b border-neutral-100 pb-1 mb-1">
                    {canManage && onEditCustomer && (
                      <button
                        type="button"
                        onClick={() => {
                          setShowMoreMenu(false);
                          onClose();
                          onEditCustomer(customer);
                        }}
                        className="w-full text-left px-3 py-2 hover:bg-neutral-50 flex items-center gap-2 font-medium"
                      >
                        <Edit2 className="w-3.5 h-3.5 text-neutral-600" />
                        Edit Profile
                      </button>
                    )}
                    {onNewInvoice && (
                      <button
                        type="button"
                        disabled={!canCreateNewInvoice}
                        onClick={() => {
                          setShowMoreMenu(false);
                          onClose();
                          onNewInvoice(customer);
                        }}
                        className="w-full text-left px-3 py-2 hover:bg-neutral-50 flex items-center gap-2 font-medium disabled:opacity-50"
                      >
                        <Plus className="w-3.5 h-3.5 text-orange-600" />
                        New Invoice
                      </button>
                    )}
                    {onAddPayment && (
                      <button
                        type="button"
                        disabled={!canAddPayment}
                        onClick={() => {
                          if (!canAddPayment) {
                            setErrorMessage(
                              `Cannot record payment: Customer is ${customerStatus} and has no outstanding payable invoices.`
                            );
                            return;
                          }
                          setShowMoreMenu(false);
                          onClose();
                          onAddPayment(customer);
                        }}
                        className="w-full text-left px-3 py-2 hover:bg-neutral-50 flex items-center gap-2 font-medium disabled:opacity-50 disabled:cursor-not-allowed"
                        title={
                          !canAddPayment
                            ? `Cannot record standalone payments for an ${customerStatus} customer with no outstanding invoices`
                            : 'Record payment against customer invoice'
                        }
                      >
                        <DollarSign className="w-3.5 h-3.5 text-emerald-600" />
                        Add Payment
                      </button>
                    )}
                  </div>

                  <div className="px-3 py-1 font-bold text-[10px] text-neutral-400 uppercase tracking-wider border-b border-neutral-100">
                    Status Actions
                  </div>

                  {customerStatus !== 'Active' && (
                    <button
                      type="button"
                      disabled={customerStatus === 'Blocked' && !isSuperAdmin}
                      onClick={() => handleStatusChange('Active')}
                      className="w-full text-left px-3 py-2 hover:bg-neutral-50 flex items-center gap-2 font-medium disabled:opacity-50 disabled:cursor-not-allowed"
                    >
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                      {customerStatus === 'Blocked' ? 'Unblock Customer (Super Admin)' : 'Mark as Active'}
                    </button>
                  )}

                  {customerStatus !== 'Inactive' && (
                    <button
                      type="button"
                      onClick={() => handleStatusChange('Inactive')}
                      className="w-full text-left px-3 py-2 hover:bg-neutral-50 flex items-center gap-2 font-medium"
                    >
                      <PauseCircle className="w-3.5 h-3.5 text-neutral-600" />
                      Mark as Inactive
                    </button>
                  )}

                  {customerStatus !== 'Blocked' && isSuperAdmin && (
                    <button
                      type="button"
                      onClick={() => handleStatusChange('Blocked')}
                      className="w-full text-left px-3 py-2 hover:bg-neutral-50 flex items-center gap-2 font-medium text-rose-600"
                    >
                      <Lock className="w-3.5 h-3.5 text-rose-600" />
                      Block Customer Account
                    </button>
                  )}

                  <div className="border-t border-neutral-100 my-1" />

                  {/* Delete option */}
                  <button
                    type="button"
                    onClick={() => {
                      setShowMoreMenu(false);
                      setShowDeleteConfirm(true);
                    }}
                    className="w-full text-left px-3 py-2 hover:bg-rose-50 flex items-center gap-2 font-medium text-rose-600"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                    Delete Customer
                  </button>
                </div>
              )}
            </div>

            <button
              id="btn-close-customer-detail"
              type="button"
              onClick={onClose}
              className="p-1.5 rounded-lg text-neutral-400 hover:text-white hover:bg-neutral-800 transition ml-1"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Status / Alert Messages */}
        {errorMessage && (
          <div className="mx-6 mt-4 p-3 bg-red-50 border border-red-200 text-red-700 text-xs rounded-lg flex items-start gap-2">
            <AlertCircle className="w-4 h-4 shrink-0 text-red-500 mt-0.5" />
            <div className="flex-1">{errorMessage}</div>
            <button onClick={() => setErrorMessage(null)} className="text-red-500 hover:text-red-700">
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
        )}
        {successMessage && (
          <div className="mx-6 mt-4 p-3 bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs rounded-lg flex items-start gap-2">
            <Check className="w-4 h-4 shrink-0 text-emerald-600 mt-0.5" />
            <div className="flex-1">{successMessage}</div>
            <button onClick={() => setSuccessMessage(null)} className="text-emerald-600 hover:text-emerald-800">
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
        )}

        {/* Financial Summary Cards Strip: Total Invoiced | Total Paid | Outstanding */}
        <div className="px-6 pt-4">
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div className="bg-neutral-50 p-3.5 rounded-xl border border-neutral-200">
              <span className="text-[11px] font-bold text-neutral-500 uppercase tracking-wide block">
                Total Invoiced (Payable)
              </span>
              <p className="text-lg font-black font-mono text-neutral-900 mt-1">
                {formatAFN(totalSales)}
              </p>
              <span className="text-[10px] text-neutral-400 mt-0.5 block">
                {customerInvoices.length} total invoice(s)
              </span>
            </div>

            <div className="bg-emerald-50/60 p-3.5 rounded-xl border border-emerald-200">
              <span className="text-[11px] font-bold text-emerald-800 uppercase tracking-wide block">
                Total Paid
              </span>
              <p className="text-lg font-black font-mono text-emerald-700 mt-1">
                {formatAFN(totalPaid)}
              </p>
              <span className="text-[10px] text-emerald-600 mt-0.5 block">
                {customerPayments.length} recorded payment(s)
              </span>
            </div>

            <div
              className={`p-3.5 rounded-xl border ${
                remainingBalance > 0
                  ? 'bg-rose-50/70 border-rose-200 text-rose-950'
                  : 'bg-emerald-50/60 border-emerald-200 text-emerald-950'
              }`}
            >
              <span className="text-[11px] font-bold uppercase tracking-wide block">
                Outstanding Balance
              </span>
              <p className="text-lg font-black font-mono mt-1">
                {formatAFN(remainingBalance)}
              </p>
              <span className="text-[10px] font-semibold mt-0.5 block">
                {hasOverdue ? '⚠️ Overdue invoice(s) present' : remainingBalance > 0 ? 'Payment outstanding' : 'Fully settled (AFN 0)'}
              </span>
            </div>
          </div>
        </div>

        {/* 4 Tabs: Overview | Invoices | Payments | Activity */}
        <div className="px-6 pt-4 border-b border-neutral-200 flex items-center gap-4 text-xs font-bold">
          <button
            type="button"
            onClick={() => setActiveTab('overview')}
            className={`pb-2.5 border-b-2 transition ${
              activeTab === 'overview'
                ? 'border-orange-500 text-orange-600'
                : 'border-transparent text-neutral-500 hover:text-neutral-900'
            }`}
          >
            Overview
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('invoices')}
            className={`pb-2.5 border-b-2 transition flex items-center gap-1.5 ${
              activeTab === 'invoices'
                ? 'border-orange-500 text-orange-600'
                : 'border-transparent text-neutral-500 hover:text-neutral-900'
            }`}
          >
            Invoices
            <span className="text-[10px] font-mono px-1.5 py-0.2 rounded-full bg-neutral-100 text-neutral-700">
              {customerInvoices.length}
            </span>
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('payments')}
            className={`pb-2.5 border-b-2 transition flex items-center gap-1.5 ${
              activeTab === 'payments'
                ? 'border-orange-500 text-orange-600'
                : 'border-transparent text-neutral-500 hover:text-neutral-900'
            }`}
          >
            Payments
            <span className="text-[10px] font-mono px-1.5 py-0.2 rounded-full bg-neutral-100 text-neutral-700">
              {customerPayments.length}
            </span>
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('activity')}
            className={`pb-2.5 border-b-2 transition flex items-center gap-1.5 ${
              activeTab === 'activity'
                ? 'border-orange-500 text-orange-600'
                : 'border-transparent text-neutral-500 hover:text-neutral-900'
            }`}
          >
            Activity
            <span className="text-[10px] font-mono px-1.5 py-0.2 rounded-full bg-neutral-100 text-neutral-700">
              {activityList.length}
            </span>
          </button>
        </div>

        {/* Tab Body */}
        <div className="p-6 overflow-y-auto flex-1 space-y-4">
          {/* TAB 1: OVERVIEW */}
          {activeTab === 'overview' && (
            <div className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {/* Contact & Location Card */}
                <div className="bg-neutral-50 p-4 rounded-xl border border-neutral-200 space-y-3 text-xs">
                  <span className="text-[11px] font-bold text-neutral-500 uppercase tracking-wider block">
                    Contact &amp; Location Information
                  </span>

                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <span className="text-[10px] text-neutral-400 block">Customer ID</span>
                      <span className="font-mono font-bold text-neutral-900">{customerCode}</span>
                    </div>
                    <div>
                      <span className="text-[10px] text-neutral-400 block">Customer Type</span>
                      <span className="font-semibold text-neutral-900">{customerType}</span>
                    </div>
                  </div>

                  <div>
                    <span className="text-[10px] text-neutral-400 block">Full Name</span>
                    <span className="font-bold text-neutral-900">{customer.name}</span>
                  </div>

                  {customer.companyName && (
                    <div>
                      <span className="text-[10px] text-neutral-400 block">Company / Business Name</span>
                      <span className="font-medium text-neutral-900">{customer.companyName}</span>
                    </div>
                  )}

                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <span className="text-[10px] text-neutral-400 block">Primary Phone</span>
                      <div className="flex items-center gap-1.5 font-mono font-bold text-neutral-900">
                        <span>{customer.phone}</span>
                        <button
                          type="button"
                          onClick={handleCopyPhone}
                          className="text-neutral-400 hover:text-neutral-700"
                          title="Copy"
                        >
                          {copiedPhone ? <Check className="w-3 h-3 text-emerald-600" /> : <Copy className="w-3 h-3" />}
                        </button>
                        {customer.phone && (
                          <a
                            href={`https://wa.me/${customer.phone.replace(/[^0-9]/g, '')}`}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="text-emerald-600 hover:text-emerald-700"
                            title="WhatsApp"
                          >
                            <MessageCircle className="w-3.5 h-3.5" />
                          </a>
                        )}
                      </div>
                    </div>

                    <div>
                      <span className="text-[10px] text-neutral-400 block">Alternate Phone</span>
                      <span className="font-mono text-neutral-800">{customer.alternatePhone || '—'}</span>
                    </div>
                  </div>

                  <div>
                    <span className="text-[10px] text-neutral-400 block">Email Address</span>
                    {customer.email ? (
                      <a href={`mailto:${customer.email}`} className="text-blue-600 hover:underline">
                        {customer.email}
                      </a>
                    ) : (
                      <span className="text-neutral-400">—</span>
                    )}
                  </div>

                  <div>
                    <span className="text-[10px] text-neutral-400 block">Street / Physical Address</span>
                    <span className="text-neutral-800">{customer.address || '—'}</span>
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <span className="text-[10px] text-neutral-400 block">City</span>
                      <span className="text-neutral-800 font-medium">{customer.city || 'Kabul'}</span>
                    </div>
                    <div>
                      <span className="text-[10px] text-neutral-400 block">Province</span>
                      <span className="text-neutral-800 font-medium">{customer.province || 'Kabul'}</span>
                    </div>
                  </div>
                </div>

                {/* System & Portal Account Card */}
                <div className="bg-neutral-50 p-4 rounded-xl border border-neutral-200 space-y-3 text-xs">
                  <span className="text-[11px] font-bold text-neutral-500 uppercase tracking-wider block">
                    Account Status &amp; Audit Metadata
                  </span>

                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <span className="text-[10px] text-neutral-400 block">Status</span>
                      <span className="font-bold text-neutral-900">{customerStatus}</span>
                    </div>
                    <div>
                      <span className="text-[10px] text-neutral-400 block">Portal Access</span>
                      <span className="font-semibold text-neutral-900">
                        {linkedUser || customer.userId ? 'Enabled' : 'Disabled'}
                      </span>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <span className="text-[10px] text-neutral-400 block">Created At</span>
                      <span className="text-neutral-800">{formatDate(customer.createdAt)}</span>
                    </div>
                    <div>
                      <span className="text-[10px] text-neutral-400 block">Created By</span>
                      <span className="text-neutral-800">{customer.createdByName || customer.createdBy || 'System'}</span>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <span className="text-[10px] text-neutral-400 block">Last Updated</span>
                      <span className="text-neutral-800">{formatDate(customer.updatedAt)}</span>
                    </div>
                    <div>
                      <span className="text-[10px] text-neutral-400 block">Updated By</span>
                      <span className="text-neutral-800">{customer.updatedByName || customer.updatedBy || '—'}</span>
                    </div>
                  </div>

                  {/* Notes */}
                  <div>
                    <span className="text-[10px] text-neutral-400 block">Administrative Notes</span>
                    <p className="text-neutral-700 bg-white p-2 rounded border border-neutral-200 mt-1 whitespace-pre-wrap">
                      {customer.notes || customer.note || 'No notes recorded for this customer.'}
                    </p>
                  </div>

                  {/* Portal Integration Actions */}
                  <div className="pt-2 border-t border-neutral-200">
                    <span className="text-[10px] font-bold text-neutral-500 uppercase tracking-wider block mb-1.5">
                      Portal Self-Service Management
                    </span>
                    {linkedUser || customer.userId ? (
                      <div className="flex items-center justify-between p-2 bg-white rounded border border-neutral-200">
                        <div className="flex items-center gap-2">
                          <ShieldCheck className="w-4 h-4 text-emerald-600" />
                          <span className="font-mono text-neutral-800 font-bold">
                            @{linkedUser?.username || customer.userUsername || 'portal_user'}
                          </span>
                        </div>
                        <button
                          type="button"
                          onClick={handleUnlinkPortal}
                          disabled={submittingPortal}
                          className="text-rose-600 hover:text-rose-700 text-[11px] font-semibold"
                        >
                          Unlink
                        </button>
                      </div>
                    ) : (
                      <div className="space-y-2">
                        <p className="text-[11px] text-neutral-500">
                          This customer does not have a linked portal user account.
                        </p>
                        <div className="flex items-center gap-2">
                          <button
                            type="button"
                            onClick={() => setIsCreatingNewPortalUser(true)}
                            className="px-2.5 py-1 text-[11px] font-bold bg-neutral-900 text-white rounded hover:bg-neutral-800"
                          >
                            Create Portal Account
                          </button>
                          {unlinkedUsers.length > 0 && (
                            <button
                              type="button"
                              onClick={() => setIsLinkingPortal(true)}
                              className="px-2.5 py-1 text-[11px] font-semibold bg-white border border-neutral-300 text-neutral-700 rounded hover:bg-neutral-50"
                            >
                              Link Existing User
                            </button>
                          )}
                        </div>
                      </div>
                    )}

                    {/* Inline Create Portal User */}
                    {isCreatingNewPortalUser && (
                      <div className="mt-2 p-3 bg-white rounded border border-neutral-200 space-y-2">
                        <span className="font-bold text-[11px] text-neutral-800 block">
                          Create New Portal User Account
                        </span>
                        <input
                          type="text"
                          placeholder="Username (min 3 chars)"
                          value={newPortalUsername}
                          onChange={(e) => setNewPortalUsername(e.target.value)}
                          className="w-full text-xs px-2.5 py-1 border border-neutral-300 rounded font-mono"
                        />
                        <input
                          type="password"
                          placeholder="Temporary Password (min 6 chars)"
                          value={newPortalPassword}
                          onChange={(e) => setNewPortalPassword(e.target.value)}
                          className="w-full text-xs px-2.5 py-1 border border-neutral-300 rounded font-mono"
                        />
                        <div className="flex items-center justify-end gap-2">
                          <button
                            type="button"
                            onClick={() => setIsCreatingNewPortalUser(false)}
                            className="text-xs text-neutral-500 hover:text-neutral-700"
                          >
                            Cancel
                          </button>
                          <button
                            type="button"
                            disabled={submittingPortal}
                            onClick={handleCreateNewPortalUser}
                            className="px-3 py-1 text-xs font-bold bg-orange-600 text-white rounded hover:bg-orange-700"
                          >
                            Create
                          </button>
                        </div>
                      </div>
                    )}

                    {/* Inline Link Existing User */}
                    {isLinkingPortal && (
                      <div className="mt-2 p-3 bg-white rounded border border-neutral-200 space-y-2">
                        <span className="font-bold text-[11px] text-neutral-800 block">
                          Link to Existing User Account
                        </span>
                        <select
                          value={selectedUserToLink}
                          onChange={(e) => setSelectedUserToLink(e.target.value)}
                          className="w-full text-xs px-2.5 py-1 border border-neutral-300 rounded"
                        >
                          <option value="">Select unlinked user...</option>
                          {unlinkedUsers.map((u) => (
                            <option key={u.id} value={u.id}>
                              {u.name} (@{u.username})
                            </option>
                          ))}
                        </select>
                        <div className="flex items-center justify-end gap-2">
                          <button
                            type="button"
                            onClick={() => setIsLinkingPortal(false)}
                            className="text-xs text-neutral-500 hover:text-neutral-700"
                          >
                            Cancel
                          </button>
                          <button
                            type="button"
                            disabled={submittingPortal || !selectedUserToLink}
                            onClick={handleLinkExistingUser}
                            className="px-3 py-1 text-xs font-bold bg-neutral-900 text-white rounded hover:bg-neutral-800"
                          >
                            Link
                          </button>
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* TAB 2: INVOICES (Invoice No | Date | Amount | Paid | Remaining | Status) */}
          {activeTab === 'invoices' && (
            <div className="space-y-3">
              {customerInvoices.length === 0 ? (
                <div className="p-8 text-center text-xs text-neutral-500 bg-neutral-50 rounded-xl border border-neutral-200 space-y-2">
                  <FileText className="w-8 h-8 text-neutral-400 mx-auto" />
                  <p className="font-bold text-neutral-700">No invoices generated for this customer</p>
                  {canCreateNewInvoice && onNewInvoice && (
                    <button
                      type="button"
                      onClick={() => {
                        onClose();
                        onNewInvoice(customer);
                      }}
                      className="mt-2 px-3 py-1.5 text-xs font-bold bg-neutral-900 text-white rounded-lg hover:bg-neutral-800 inline-flex items-center gap-1.5"
                    >
                      <Plus className="w-3.5 h-3.5" />
                      Generate First Invoice
                    </button>
                  )}
                </div>
              ) : (
                <div className="overflow-x-auto rounded-xl border border-neutral-200">
                  <table className="w-full border-collapse text-xs">
                    <thead>
                      <tr className="bg-neutral-900 text-white font-semibold text-left">
                        <th className="py-2.5 px-3 whitespace-nowrap">Invoice No</th>
                        <th className="py-2.5 px-3">Date</th>
                        <th className="py-2.5 px-3 text-right">Amount</th>
                        <th className="py-2.5 px-3 text-right">Paid</th>
                        <th className="py-2.5 px-3 text-right">Remaining</th>
                        <th className="py-2.5 px-3 text-center">Status</th>
                        <th className="py-2.5 px-3 text-right">Actions</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-neutral-200">
                      {customerInvoices.map((inv) => {
                        const invPaid = customerPayments
                          .filter((p) => p.invoiceId === inv.id && !p.isVoid)
                          .reduce((s, p) => s + (Number(p.amount) || 0), 0);
                        const invRemaining = Math.max(0, (Number(inv.totalAmount) || 0) - invPaid);

                        return (
                          <tr
                            key={inv.id}
                            className="hover:bg-neutral-50 cursor-pointer transition"
                            onClick={() => onSelectInvoice && onSelectInvoice(inv)}
                          >
                            <td className="py-2.5 px-3 font-mono font-bold text-neutral-900 whitespace-nowrap">
                              {inv.billNumber}
                            </td>
                            <td className="py-2.5 px-3 text-neutral-600 whitespace-nowrap">
                              {formatDate(inv.date)}
                            </td>
                            <td className="py-2.5 px-3 text-right font-mono font-bold text-neutral-900 whitespace-nowrap">
                              {formatAFN(inv.totalAmount)}
                            </td>
                            <td className="py-2.5 px-3 text-right font-mono font-bold text-emerald-700 whitespace-nowrap">
                              {formatAFN(invPaid)}
                            </td>
                            <td className="py-2.5 px-3 text-right font-mono font-bold whitespace-nowrap">
                              <span className={invRemaining > 0 ? 'text-rose-600' : 'text-neutral-400'}>
                                {formatAFN(invRemaining)}
                              </span>
                            </td>
                            <td className="py-2.5 px-3 text-center whitespace-nowrap">
                              <span
                                className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                                  inv.status === 'Paid'
                                    ? 'bg-emerald-100 text-emerald-800'
                                    : inv.status === 'Partially Paid'
                                    ? 'bg-orange-100 text-orange-800'
                                    : inv.status === 'Void'
                                    ? 'bg-neutral-200 text-neutral-600'
                                    : 'bg-red-100 text-red-800'
                                }`}
                              >
                                {inv.status}
                              </span>
                            </td>
                            <td className="py-2.5 px-3 text-right whitespace-nowrap">
                              <button
                                type="button"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  if (onSelectInvoice) onSelectInvoice(inv);
                                }}
                                className="px-2 py-1 text-xs text-orange-600 hover:text-orange-700 font-bold hover:bg-orange-50 rounded transition"
                              >
                                View
                              </button>
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          )}

          {/* TAB 3: PAYMENTS (Date | Invoice | Amount | Method | Reference) */}
          {activeTab === 'payments' && (
            <div className="space-y-3">
              {customerPayments.length === 0 ? (
                <div className="p-8 text-center text-xs text-neutral-500 bg-neutral-50 rounded-xl border border-neutral-200 space-y-2">
                  <CreditCard className="w-8 h-8 text-neutral-400 mx-auto" />
                  <p className="font-bold text-neutral-700">No payment records found for this customer</p>
                </div>
              ) : (
                <div className="overflow-x-auto rounded-xl border border-neutral-200">
                  <table className="w-full border-collapse text-xs">
                    <thead>
                      <tr className="bg-neutral-900 text-white font-semibold text-left">
                        <th className="py-2.5 px-3">Date</th>
                        <th className="py-2.5 px-3">Invoice</th>
                        <th className="py-2.5 px-3 text-right">Amount</th>
                        <th className="py-2.5 px-3 text-center">Method</th>
                        <th className="py-2.5 px-3">Reference / Note</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-neutral-200">
                      {customerPayments.map((p) => (
                        <tr key={p.id} className="hover:bg-neutral-50">
                          <td className="py-2.5 px-3 whitespace-nowrap text-neutral-700">
                            {formatDate(p.date)}
                          </td>
                          <td className="py-2.5 px-3 font-mono font-bold text-neutral-900 whitespace-nowrap">
                            {p.billNumber}
                          </td>
                          <td className="py-2.5 px-3 text-right font-mono font-bold text-emerald-700 whitespace-nowrap">
                            {formatAFN(p.amount)}
                          </td>
                          <td className="py-2.5 px-3 text-center whitespace-nowrap">
                            <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-neutral-100 text-neutral-700">
                              {p.method}
                            </span>
                          </td>
                          <td className="py-2.5 px-3 text-neutral-600 truncate max-w-[200px]">
                            {p.note || '—'}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          )}

          {/* TAB 4: ACTIVITY (Chronological Audit / History Timeline) */}
          {activeTab === 'activity' && (
            <div className="space-y-3">
              {activityList.length === 0 ? (
                <div className="p-8 text-center text-xs text-neutral-500 bg-neutral-50 rounded-xl border border-neutral-200 space-y-2">
                  <History className="w-8 h-8 text-neutral-400 mx-auto" />
                  <p className="font-bold text-neutral-700">No activity logged yet</p>
                </div>
              ) : (
                <div className="relative pl-6 space-y-4 before:absolute before:left-2.5 before:top-2 before:bottom-2 before:w-0.5 before:bg-neutral-200">
                  {activityList.map((ev) => (
                    <div key={ev.id} className="relative text-xs">
                      <div className="absolute -left-6 top-1 w-2.5 h-2.5 rounded-full bg-orange-500 ring-4 ring-white" />
                      <div className="bg-neutral-50 p-3 rounded-lg border border-neutral-200">
                        <div className="flex items-center justify-between gap-2">
                          <span className="font-bold text-neutral-900">{ev.title}</span>
                          <span className="text-[10px] text-neutral-400 font-mono">
                            {formatDate(ev.date)}
                          </span>
                        </div>
                        <p className="text-[11px] text-neutral-600 mt-0.5">{ev.description}</p>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}
        </div>

        {/* Delete Confirmation Modal / Financial History Warning */}
        {showDeleteConfirm && (
          <div
            id="delete-customer-confirm-dialog"
            className="fixed inset-0 z-60 flex items-center justify-center p-4 bg-black/70 backdrop-blur-xs"
          >
            <div className="bg-white rounded-xl shadow-2xl p-6 max-w-md w-full border border-neutral-200 space-y-4">
              <div className="flex items-start gap-3">
                {hasFinancialTransactions ? (
                  <ShieldAlert className="w-6 h-6 text-amber-600 shrink-0" />
                ) : (
                  <Trash2 className="w-6 h-6 text-rose-600 shrink-0" />
                )}
                <div>
                  <h3 className="font-bold text-sm text-neutral-900">
                    {hasFinancialTransactions
                      ? 'Deletion Blocked: Financial History Exists'
                      : 'Permanently Delete Customer Account?'}
                  </h3>
                  <p className="text-xs text-neutral-600 mt-1">
                    {hasFinancialTransactions ? (
                      <>
                        Customer <strong>{customer.name}</strong> ({customerCode}) has{' '}
                        <strong>{customerInvoices.length} historical invoice(s)</strong> and{' '}
                        <strong>{customerPayments.length} payment(s)</strong>. Accounting ledgers must
                        remain intact for tax and financial auditing.
                        <br />
                        <br />
                        Would you like to mark this customer as <strong>Inactive</strong> instead?
                      </>
                    ) : (
                      <>
                        Are you sure you want to delete customer <strong>{customer.name}</strong> (
                        {customerCode})? This action cannot be undone.
                      </>
                    )}
                  </p>
                </div>
              </div>

              <div className="flex items-center justify-end gap-2 pt-2 border-t border-neutral-100">
                <button
                  type="button"
                  disabled={deleting}
                  onClick={() => setShowDeleteConfirm(false)}
                  className="px-3 py-1.5 text-xs font-semibold text-neutral-600 hover:bg-neutral-100 rounded-lg"
                >
                  Cancel
                </button>

                {hasFinancialTransactions ? (
                  <button
                    type="button"
                    onClick={() => {
                      setShowDeleteConfirm(false);
                      handleStatusChange('Inactive');
                    }}
                    className="px-3.5 py-1.5 text-xs font-bold text-white bg-neutral-900 hover:bg-neutral-800 rounded-lg shadow-sm"
                  >
                    Mark as Inactive
                  </button>
                ) : (
                  <button
                    type="button"
                    disabled={deleting}
                    onClick={handleDeleteCustomer}
                    className="px-3.5 py-1.5 text-xs font-bold text-white bg-rose-600 hover:bg-rose-700 rounded-lg shadow-sm"
                  >
                    {deleting ? 'Deleting...' : 'Confirm Delete'}
                  </button>
                )}
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
