import React, { useState, useEffect, useMemo } from 'react';
import { Customer, CustomerStatus, CustomerType, UserProfile } from '../../types';
import {
  saveCustomer,
  generateNextCustomerCode,
  linkCustomerToUserAccount,
} from '../../services/db';
import { createApplicationUser } from '../../services/security';
import { useAuth } from '../../context/AuthContext';
import { ProfilePhotoUpload } from '../common/ProfilePhotoUpload';
import {
  findDuplicatePhoneCustomer,
  normalizeCustomerStatus,
  AFGHAN_PROVINCES,
  validateCustomerData,
} from '../../utils/customerValidation';
import {
  X,
  User,
  Phone,
  Mail,
  MapPin,
  Building,
  FileText,
  ShieldCheck,
  Key,
  Hash,
  AlertCircle,
  AlertTriangle,
  CheckCircle2,
  Lock,
  ExternalLink,
  ChevronRight,
  Info,
} from 'lucide-react';

interface CustomerModalProps {
  isOpen: boolean;
  onClose: () => void;
  customerToEdit?: Customer | null;
  onSuccess?: (customerId: string) => void;
  existingCustomers?: Customer[];
  users?: UserProfile[];
  onSelectExistingCustomer?: (customer: Customer) => void;
}

export const CustomerModal: React.FC<CustomerModalProps> = ({
  isOpen,
  onClose,
  customerToEdit,
  onSuccess,
  existingCustomers = [],
  users = [],
  onSelectExistingCustomer,
}) => {
  const { userProfile } = useAuth();
  const isSuperAdmin = userProfile?.role === 'super_admin';

  // Core model fields
  const [customerCode, setCustomerCode] = useState<string>('');
  const [customerType, setCustomerType] = useState<CustomerType>('Individual');
  const [name, setName] = useState<string>('');
  const [companyName, setCompanyName] = useState<string>('');
  const [phone, setPhone] = useState<string>('');
  const [alternatePhone, setAlternatePhone] = useState<string>('');
  const [email, setEmail] = useState<string>('');
  const [address, setAddress] = useState<string>('');
  const [city, setCity] = useState<string>('Kabul');
  const [province, setProvince] = useState<string>('Kabul');
  const [notes, setNotes] = useState<string>('');
  const [photoURL, setPhotoURL] = useState<string>('');
  const [status, setStatus] = useState<CustomerStatus>('Active');

  // Duplicate phone warning state
  const [duplicateWarningCustomer, setDuplicateWarningCustomer] = useState<Customer | null>(null);
  const [allowDuplicatePhone, setAllowDuplicatePhone] = useState<boolean>(false);

  // Portal Account state
  const [createLoginAccount, setCreateLoginAccount] = useState<boolean>(false);
  const [portalUsername, setPortalUsername] = useState<string>('');
  const [portalPassword, setPortalPassword] = useState<string>('');
  const [selectedExistingUserId, setSelectedExistingUserId] = useState<string>('');

  const [saving, setSaving] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [fieldErrors, setFieldErrors] = useState<Record<string, string>>({});

  // Initialize or reset form state
  useEffect(() => {
    if (!isOpen) return;

    if (customerToEdit) {
      const normStatus = normalizeCustomerStatus(customerToEdit.status, customerToEdit.isArchived);
      setCustomerCode(customerToEdit.customerCode || customerToEdit.customerId || customerToEdit.id);
      setCustomerType(customerToEdit.customerType || (customerToEdit.companyName ? 'Business' : 'Individual'));
      setName(customerToEdit.name || '');
      setCompanyName(customerToEdit.companyName || '');
      setPhone(customerToEdit.phone || '');
      setAlternatePhone(customerToEdit.alternatePhone || '');
      setEmail(customerToEdit.email || '');
      setAddress(customerToEdit.address || '');
      setCity(customerToEdit.city || 'Kabul');
      setProvince(customerToEdit.province || 'Kabul');
      setNotes(customerToEdit.notes || customerToEdit.note || '');
      setPhotoURL(customerToEdit.photoURL || '');
      setStatus(normStatus);
      setCreateLoginAccount(false);
      setSelectedExistingUserId(customerToEdit.userId || '');
      setDuplicateWarningCustomer(null);
      setAllowDuplicatePhone(false);
    } else {
      setCustomerType('Individual');
      setName('');
      setCompanyName('');
      setPhone('');
      setAlternatePhone('');
      setEmail('');
      setAddress('');
      setCity('Kabul');
      setProvince('Kabul');
      setNotes('');
      setPhotoURL('');
      setStatus('Active');
      setCreateLoginAccount(false);
      setPortalUsername('');
      setPortalPassword('');
      setSelectedExistingUserId('');
      setDuplicateWarningCustomer(null);
      setAllowDuplicatePhone(false);

      // Auto-generate next sequential code (ST-CUST-XXXX)
      generateNextCustomerCode('ST-CUST-')
        .then((code) => {
          setCustomerCode(code);
        })
        .catch(() => {
          setCustomerCode('ST-CUST-1001');
        });
    }
    setError(null);
    setFieldErrors({});
  }, [isOpen, customerToEdit]);

  // Check for duplicate phone live whenever phone changes
  const checkDuplicatePhone = (inputPhone: string) => {
    if (!inputPhone || inputPhone.trim().length < 6) {
      setDuplicateWarningCustomer(null);
      return;
    }
    const duplicate = findDuplicatePhoneCustomer(
      inputPhone.trim(),
      existingCustomers,
      customerToEdit?.id
    );
    setDuplicateWarningCustomer(duplicate);
    if (!duplicate) {
      setAllowDuplicatePhone(false);
    }
  };

  const handlePhoneChange = (val: string) => {
    setPhone(val);
    if (fieldErrors.phone) {
      setFieldErrors((prev) => ({ ...prev, phone: '' }));
    }
    checkDuplicatePhone(val);
  };

  // When customer name changes and creating login, suggest username if empty
  const handleNameChange = (val: string) => {
    setName(val);
    if (fieldErrors.name) {
      setFieldErrors((prev) => ({ ...prev, name: '' }));
    }
    if (!customerToEdit && createLoginAccount && !portalUsername) {
      const suggested = val.toLowerCase().replace(/[^a-z0-9]/g, '_').slice(0, 15);
      if (suggested) setPortalUsername(suggested);
    }
  };

  if (!isOpen) return null;

  // Unlinked user accounts that can be attached to this customer
  const unlinkedCustomerUsers = users.filter(
    (u) =>
      u.role === 'customer' &&
      (!u.customerId || u.customerId === customerToEdit?.id)
  );

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    // 1. Validation
    const validation = validateCustomerData({
      customerType,
      name,
      companyName,
      phone,
      email,
      address,
      city,
      province,
    });

    if (!validation.isValid) {
      setFieldErrors(validation.errors);
      const firstMsg = Object.values(validation.errors)[0];
      setError(firstMsg || 'Please correct the highlighted fields.');
      return;
    }

    // 2. Duplicate phone check warning blocker
    if (duplicateWarningCustomer && !allowDuplicatePhone) {
      setError(
        `Duplicate phone detected with ${duplicateWarningCustomer.customerCode || duplicateWarningCustomer.id} (${duplicateWarningCustomer.name}). Click "Continue Anyway" below to acknowledge or view existing customer.`
      );
      return;
    }

    // 3. Portal account validation if requested
    if (createLoginAccount) {
      const cleanUname = portalUsername.trim().toLowerCase();
      if (!cleanUname || cleanUname.length < 3) {
        setError('Portal username must be at least 3 characters.');
        return;
      }
      if (!portalPassword || portalPassword.length < 6) {
        setError('Temporary password must be at least 6 characters.');
        return;
      }
    }

    setSaving(true);
    try {
      const savedCustomerId = await saveCustomer(
        {
          id: customerToEdit ? customerToEdit.id : undefined,
          customerCode: customerCode || undefined,
          customerId: customerCode || undefined,
          customerType,
          name: name.trim(),
          phone: phone.trim(),
          alternatePhone: alternatePhone.trim() || undefined,
          email: email.trim().toLowerCase(),
          address: address.trim(),
          city: city.trim(),
          province: province.trim(),
          companyName: customerType === 'Business' ? companyName.trim() : (companyName.trim() || undefined),
          notes: notes.trim(),
          note: notes.trim(),
          photoURL: photoURL.trim() || undefined,
          status,
          userId: selectedExistingUserId || undefined,
          allowDuplicatePhone: Boolean(allowDuplicatePhone),
        },
        userProfile?.id || 'system',
        userProfile?.name || 'Staff',
        userProfile?.role || 'super_admin'
      );

      // Handle Portal account creation if toggled
      if (createLoginAccount) {
        await createApplicationUser({
          name: name.trim(),
          username: portalUsername.trim().toLowerCase(),
          email: email.trim().toLowerCase(),
          phone: phone.trim(),
          defaultPassword: portalPassword,
          role: 'customer',
          status: 'active',
          customerId: savedCustomerId,
          creatorId: userProfile?.id || 'system',
          creatorName: userProfile?.name || 'Staff',
        });
      } else if (selectedExistingUserId && selectedExistingUserId !== customerToEdit?.userId) {
        // Link existing user account
        await linkCustomerToUserAccount(
          savedCustomerId,
          selectedExistingUserId,
          userProfile?.id || 'system',
          userProfile?.name || 'Staff'
        );
      }

      if (onSuccess) onSuccess(savedCustomerId);
      onClose();
    } catch (err: any) {
      console.error('Error saving customer:', err);
      setError(err.message || 'Failed to save customer account. Please try again.');
    } finally {
      setSaving(false);
    }
  };

  const isCurrentStatusBlocked = customerToEdit && normalizeCustomerStatus(customerToEdit.status, customerToEdit.isArchived) === 'Blocked';

  return (
    <div
      id="customer-modal-overlay"
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/60 backdrop-blur-xs overflow-y-auto"
    >
      <div
        id="customer-modal-container"
        className="bg-white rounded-xl shadow-2xl w-full max-w-2xl max-h-[92vh] flex flex-col overflow-hidden border border-neutral-200 my-auto"
      >
        {/* Modal Header */}
        <div className="flex items-center justify-between px-4 sm:px-6 py-3.5 sm:py-4 border-b border-neutral-200 bg-neutral-900 text-white">
          <div className="flex items-center gap-2.5">
            <User className="w-5 h-5 text-orange-400 shrink-0" />
            <div className="min-w-0">
              <div className="flex items-center gap-2 flex-wrap">
                <h2 className="text-sm sm:text-base font-bold truncate">
                  {customerToEdit ? 'Edit Customer Profile' : 'Register New Customer'}
                </h2>
                <span className="text-[11px] font-mono font-bold bg-neutral-800 text-orange-400 px-2 py-0.5 rounded border border-neutral-700">
                  {customerCode || (customerToEdit?.customerCode || 'ST-CUST-1001')}
                </span>
              </div>
              <p className="text-[11px] text-neutral-400 truncate">
                {customerToEdit
                  ? `Updating record: ${customerToEdit.customerCode || customerToEdit.id} (${customerToEdit.name})`
                  : 'Add customer to ledger with auto-generated ID and strict validations'}
              </p>
            </div>
          </div>
          <button
            id="btn-close-customer-modal"
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-lg text-neutral-400 hover:text-white hover:bg-neutral-800 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-4 sm:p-6 space-y-4 overflow-y-auto flex-1">
          {error && (
            <div
              id="customer-modal-error-banner"
              className="p-3 bg-red-50 border border-red-200 text-red-700 text-xs rounded-lg flex items-start gap-2"
            >
              <AlertCircle className="w-4 h-4 shrink-0 mt-0.5 text-red-500" />
              <div className="flex-1 font-medium">{error}</div>
            </div>
          )}

          {/* DUPLICATE PHONE WARNING BANNER */}
          {duplicateWarningCustomer && (
            <div
              id="duplicate-phone-warning-card"
              className="p-3.5 bg-amber-50 border border-amber-300 rounded-xl space-y-2.5 text-amber-900"
            >
              <div className="flex items-start gap-2.5">
                <AlertTriangle className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
                <div className="flex-1 text-xs">
                  <p className="font-bold text-amber-950">
                    Duplicate Phone Number Detected
                  </p>
                  <p className="mt-0.5 text-amber-800">
                    A customer with this phone number is already registered in the system:
                  </p>
                  <div className="mt-2 p-2 bg-white/80 rounded-lg border border-amber-200 grid grid-cols-2 gap-2 text-[11px]">
                    <div>
                      <span className="text-neutral-500">Customer ID:</span>{' '}
                      <span className="font-mono font-bold text-neutral-900">
                        {duplicateWarningCustomer.customerCode || duplicateWarningCustomer.id}
                      </span>
                    </div>
                    <div>
                      <span className="text-neutral-500">Name:</span>{' '}
                      <span className="font-semibold text-neutral-900">{duplicateWarningCustomer.name}</span>
                    </div>
                    <div>
                      <span className="text-neutral-500">Company:</span>{' '}
                      <span className="text-neutral-800">{duplicateWarningCustomer.companyName || '—'}</span>
                    </div>
                    <div>
                      <span className="text-neutral-500">Status:</span>{' '}
                      <span className="font-semibold text-neutral-800">
                        {duplicateWarningCustomer.status || 'Active'}
                      </span>
                    </div>
                  </div>
                </div>
              </div>

              <div className="flex items-center justify-end gap-2 pt-1 border-t border-amber-200">
                {onSelectExistingCustomer && (
                  <button
                    type="button"
                    onClick={() => {
                      onClose();
                      onSelectExistingCustomer(duplicateWarningCustomer);
                    }}
                    className="px-3 py-1.5 text-xs font-semibold bg-white border border-amber-300 text-amber-900 rounded-lg hover:bg-amber-100 flex items-center gap-1.5 transition"
                  >
                    <ExternalLink className="w-3.5 h-3.5" />
                    View Existing Customer
                  </button>
                )}
                <button
                  type="button"
                  onClick={() => setAllowDuplicatePhone(true)}
                  className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition ${
                    allowDuplicatePhone
                      ? 'bg-emerald-600 text-white'
                      : 'bg-amber-600 text-white hover:bg-amber-700'
                  }`}
                >
                  {allowDuplicatePhone ? '✓ Duplicate Overridden' : 'Continue Anyway'}
                </button>
              </div>
            </div>
          )}

          {/* Customer Type Selector */}
          <div>
            <label className="text-xs font-semibold text-neutral-700 block mb-1.5">
              Customer Type *
            </label>
            <div className="grid grid-cols-2 gap-3">
              <button
                type="button"
                onClick={() => setCustomerType('Individual')}
                className={`flex items-center justify-center gap-2 py-2 px-3 rounded-lg text-xs font-bold border transition ${
                  customerType === 'Individual'
                    ? 'bg-neutral-900 text-white border-neutral-900 shadow-xs'
                    : 'bg-white text-neutral-700 border-neutral-300 hover:bg-neutral-50'
                }`}
              >
                <User className="w-3.5 h-3.5" />
                Individual
              </button>
              <button
                type="button"
                onClick={() => setCustomerType('Business')}
                className={`flex items-center justify-center gap-2 py-2 px-3 rounded-lg text-xs font-bold border transition ${
                  customerType === 'Business'
                    ? 'bg-neutral-900 text-white border-neutral-900 shadow-xs'
                    : 'bg-white text-neutral-700 border-neutral-300 hover:bg-neutral-50'
                }`}
              >
                <Building className="w-3.5 h-3.5" />
                Business
              </button>
            </div>
          </div>

          {/* Customer ID & Status Row */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="text-xs font-semibold text-neutral-700 block mb-1">
                Customer ID (System Managed)
              </label>
              <div className="relative">
                <Hash className="w-4 h-4 text-neutral-400 absolute left-3 top-2.5" />
                <input
                  id="input-customer-code"
                  type="text"
                  readOnly
                  disabled
                  value={customerCode}
                  placeholder="ST-CUST-1001"
                  className="w-full text-xs font-mono font-bold pl-9 pr-3 py-2 border border-neutral-200 bg-neutral-100 text-neutral-700 rounded-lg cursor-not-allowed uppercase"
                />
              </div>
              <p className="text-[10px] text-neutral-500 mt-0.5">
                {customerToEdit ? 'Immutable system ledger identifier.' : 'Auto-generated sequentially upon registration.'}
              </p>
            </div>

            <div>
              <label className="text-xs font-semibold text-neutral-700 block mb-1">
                Account Status *
              </label>
              {customerToEdit ? (
                <div>
                  <select
                    id="select-customer-status"
                    value={status}
                    onChange={(e) => setStatus(e.target.value as CustomerStatus)}
                    disabled={isCurrentStatusBlocked && !isSuperAdmin}
                    className="w-full text-xs font-semibold py-2 px-3 border border-neutral-300 rounded-lg focus:outline-none focus:ring-1 focus:ring-orange-500 bg-white"
                  >
                    <option value="Active">Active (Full Access)</option>
                    <option value="Inactive">Inactive (Suspended)</option>
                    {isSuperAdmin && <option value="Blocked">Blocked (Locked by Admin)</option>}
                    {!isSuperAdmin && isCurrentStatusBlocked && (
                      <option value="Blocked">Blocked (Locked)</option>
                    )}
                  </select>
                  {isCurrentStatusBlocked && !isSuperAdmin && (
                    <p className="text-[10px] text-rose-600 mt-0.5 flex items-center gap-1">
                      <Lock className="w-3 h-3" />
                      Only Super Admin has permission to unblock this customer.
                    </p>
                  )}
                </div>
              ) : (
                <div className="py-2 px-3 bg-neutral-100 border border-neutral-200 rounded-lg text-xs font-bold text-emerald-700 flex items-center gap-1.5">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                  Active (Default for new customers)
                </div>
              )}
            </div>
          </div>

          {/* Name & Company */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="text-xs font-semibold text-neutral-700 block mb-1">
                Customer Full Name *
              </label>
              <div className="relative">
                <User className="w-4 h-4 text-neutral-400 absolute left-3 top-2.5" />
                <input
                  id="input-customer-name"
                  type="text"
                  required
                  value={name}
                  onChange={(e) => handleNameChange(e.target.value)}
                  placeholder="e.g. Ahmad Tariq"
                  className={`w-full text-xs pl-9 pr-3 py-2 border rounded-lg focus:outline-none focus:ring-1 focus:ring-orange-500 ${
                    fieldErrors.name ? 'border-red-500 bg-red-50/30' : 'border-neutral-300'
                  }`}
                />
              </div>
              {fieldErrors.name && (
                <p className="text-[10px] text-red-600 mt-0.5">{fieldErrors.name}</p>
              )}
            </div>

            <div>
              <label className="text-xs font-semibold text-neutral-700 block mb-1">
                Company Name {customerType === 'Business' ? '*' : '(Optional)'}
              </label>
              <div className="relative">
                <Building className="w-4 h-4 text-neutral-400 absolute left-3 top-2.5" />
                <input
                  id="input-customer-company"
                  type="text"
                  required={customerType === 'Business'}
                  value={companyName}
                  onChange={(e) => {
                    setCompanyName(e.target.value);
                    if (fieldErrors.companyName) {
                      setFieldErrors((prev) => ({ ...prev, companyName: '' }));
                    }
                  }}
                  placeholder="e.g. Kabul Logistics Co."
                  className={`w-full text-xs pl-9 pr-3 py-2 border rounded-lg focus:outline-none focus:ring-1 focus:ring-orange-500 ${
                    fieldErrors.companyName ? 'border-red-500 bg-red-50/30' : 'border-neutral-300'
                  }`}
                />
              </div>
              {fieldErrors.companyName && (
                <p className="text-[10px] text-red-600 mt-0.5">{fieldErrors.companyName}</p>
              )}
            </div>
          </div>

          {/* Phone & Alternate Phone */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="text-xs font-semibold text-neutral-700 block mb-1">
                Primary Phone Number *
              </label>
              <div className="relative">
                <Phone className="w-4 h-4 text-neutral-400 absolute left-3 top-2.5" />
                <input
                  id="input-customer-phone"
                  type="tel"
                  required
                  value={phone}
                  onChange={(e) => handlePhoneChange(e.target.value)}
                  onBlur={() => checkDuplicatePhone(phone)}
                  placeholder="0731339014 or +93..."
                  className={`w-full text-xs pl-9 pr-3 py-2 border rounded-lg focus:outline-none focus:ring-1 focus:ring-orange-500 ${
                    fieldErrors.phone ? 'border-red-500 bg-red-50/30' : 'border-neutral-300'
                  }`}
                />
              </div>
              {fieldErrors.phone && (
                <p className="text-[10px] text-red-600 mt-0.5">{fieldErrors.phone}</p>
              )}
            </div>

            <div>
              <label className="text-xs font-semibold text-neutral-700 block mb-1">
                Alternate Phone (Optional)
              </label>
              <div className="relative">
                <Phone className="w-4 h-4 text-neutral-400 absolute left-3 top-2.5" />
                <input
                  id="input-customer-alt-phone"
                  type="tel"
                  value={alternatePhone}
                  onChange={(e) => setAlternatePhone(e.target.value)}
                  placeholder="Secondary phone / WhatsApp"
                  className="w-full text-xs pl-9 pr-3 py-2 border border-neutral-300 rounded-lg focus:outline-none focus:ring-1 focus:ring-orange-500"
                />
              </div>
            </div>
          </div>

          {/* Email */}
          <div>
            <label className="text-xs font-semibold text-neutral-700 block mb-1">
              Email Address *
            </label>
            <div className="relative">
              <Mail className="w-4 h-4 text-neutral-400 absolute left-3 top-2.5" />
              <input
                id="input-customer-email"
                type="email"
                required
                value={email}
                onChange={(e) => {
                  setEmail(e.target.value);
                  if (fieldErrors.email) {
                    setFieldErrors((prev) => ({ ...prev, email: '' }));
                  }
                }}
                placeholder="customer@example.com"
                className={`w-full text-xs pl-9 pr-3 py-2 border rounded-lg focus:outline-none focus:ring-1 focus:ring-orange-500 ${
                  fieldErrors.email ? 'border-red-500 bg-red-50/30' : 'border-neutral-300'
                }`}
              />
            </div>
            {fieldErrors.email && (
              <p className="text-[10px] text-red-600 mt-0.5">{fieldErrors.email}</p>
            )}
          </div>

          {/* Address, City, Province */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div className="sm:col-span-1">
              <label className="text-xs font-semibold text-neutral-700 block mb-1">
                Street / Address *
              </label>
              <div className="relative">
                <MapPin className="w-4 h-4 text-neutral-400 absolute left-3 top-2.5" />
                <input
                  id="input-customer-address"
                  type="text"
                  required
                  value={address}
                  onChange={(e) => {
                    setAddress(e.target.value);
                    if (fieldErrors.address) {
                      setFieldErrors((prev) => ({ ...prev, address: '' }));
                    }
                  }}
                  placeholder="Street 4, Shahr-e Naw"
                  className={`w-full text-xs pl-9 pr-3 py-2 border rounded-lg focus:outline-none focus:ring-1 focus:ring-orange-500 ${
                    fieldErrors.address ? 'border-red-500 bg-red-50/30' : 'border-neutral-300'
                  }`}
                />
              </div>
              {fieldErrors.address && (
                <p className="text-[10px] text-red-600 mt-0.5">{fieldErrors.address}</p>
              )}
            </div>

            <div>
              <label className="text-xs font-semibold text-neutral-700 block mb-1">
                City *
              </label>
              <input
                id="input-customer-city"
                type="text"
                required
                value={city}
                onChange={(e) => {
                  setCity(e.target.value);
                  if (fieldErrors.city) {
                    setFieldErrors((prev) => ({ ...prev, city: '' }));
                  }
                }}
                placeholder="e.g. Kabul"
                className={`w-full text-xs px-3 py-2 border rounded-lg focus:outline-none focus:ring-1 focus:ring-orange-500 ${
                  fieldErrors.city ? 'border-red-500 bg-red-50/30' : 'border-neutral-300'
                }`}
              />
              {fieldErrors.city && (
                <p className="text-[10px] text-red-600 mt-0.5">{fieldErrors.city}</p>
              )}
            </div>

            <div>
              <label className="text-xs font-semibold text-neutral-700 block mb-1">
                Province *
              </label>
              <select
                id="select-customer-province"
                value={province}
                onChange={(e) => {
                  setProvince(e.target.value);
                  if (fieldErrors.province) {
                    setFieldErrors((prev) => ({ ...prev, province: '' }));
                  }
                }}
                className={`w-full text-xs px-3 py-2 border rounded-lg focus:outline-none focus:ring-1 focus:ring-orange-500 bg-white ${
                  fieldErrors.province ? 'border-red-500 bg-red-50/30' : 'border-neutral-300'
                }`}
              >
                {AFGHAN_PROVINCES.map((prov) => (
                  <option key={prov} value={prov}>
                    {prov}
                  </option>
                ))}
              </select>
              {fieldErrors.province && (
                <p className="text-[10px] text-red-600 mt-0.5">{fieldErrors.province}</p>
              )}
            </div>
          </div>

          {/* Notes */}
          <div>
            <label className="text-xs font-semibold text-neutral-700 block mb-1">
              Administrative Notes & References (Optional)
            </label>
            <textarea
              id="textarea-customer-note"
              rows={2}
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="Special billing terms, installation location notes, authorized contacts..."
              className="w-full text-xs p-2.5 border border-neutral-300 rounded-lg focus:outline-none focus:ring-1 focus:ring-orange-500"
            />
          </div>

          {/* Profile Photo Upload */}
          <div className="bg-neutral-50 p-3 rounded-xl border border-neutral-200">
            <label className="text-xs font-semibold text-neutral-700 block mb-1.5">
              Customer Avatar / Photo (Optional)
            </label>
            <ProfilePhotoUpload
              value={photoURL}
              onChange={(newUrl) => setPhotoURL(newUrl)}
              name={name || 'Customer'}
              disabled={saving}
            />
          </div>

          {/* Portal Account Integration */}
          <div className="p-3.5 bg-neutral-50 rounded-xl border border-neutral-200 space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 text-emerald-600" />
                <span className="text-xs font-bold text-neutral-800">
                  Customer Self-Service Portal Access
                </span>
              </div>
              {!customerToEdit && (
                <label className="flex items-center gap-2 cursor-pointer text-xs font-medium text-neutral-600">
                  <input
                    type="checkbox"
                    checked={createLoginAccount}
                    onChange={(e) => setCreateLoginAccount(e.target.checked)}
                    className="rounded text-orange-600 focus:ring-orange-500"
                  />
                  Create Portal Login
                </label>
              )}
            </div>

            {createLoginAccount && !customerToEdit && (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2 border-t border-neutral-200">
                <div>
                  <label className="text-[11px] font-semibold text-neutral-700 block mb-1">
                    Portal Username *
                  </label>
                  <input
                    type="text"
                    required={createLoginAccount}
                    value={portalUsername}
                    onChange={(e) => setPortalUsername(e.target.value.toLowerCase().replace(/[^a-z0-9_]/g, ''))}
                    placeholder="e.g. tariq_tech"
                    className="w-full text-xs px-3 py-1.5 border border-neutral-300 rounded-lg focus:outline-none focus:ring-1 focus:ring-orange-500 lowercase font-mono"
                  />
                </div>
                <div>
                  <label className="text-[11px] font-semibold text-neutral-700 block mb-1">
                    Temporary Password *
                  </label>
                  <input
                    type="password"
                    required={createLoginAccount}
                    value={portalPassword}
                    onChange={(e) => setPortalPassword(e.target.value)}
                    placeholder="Min 6 characters"
                    className="w-full text-xs px-3 py-1.5 border border-neutral-300 rounded-lg focus:outline-none focus:ring-1 focus:ring-orange-500 font-mono"
                  />
                </div>
              </div>
            )}

            {unlinkedCustomerUsers.length > 0 && !createLoginAccount && (
              <div className="pt-2 border-t border-neutral-200">
                <label className="text-[11px] font-semibold text-neutral-700 block mb-1">
                  Or Link to Existing User Account
                </label>
                <select
                  value={selectedExistingUserId}
                  onChange={(e) => setSelectedExistingUserId(e.target.value)}
                  className="w-full text-xs px-3 py-1.5 border border-neutral-300 rounded-lg bg-white focus:outline-none focus:ring-1 focus:ring-orange-500"
                >
                  <option value="">No linked user account</option>
                  {unlinkedCustomerUsers.map((u) => (
                    <option key={u.id} value={u.id}>
                      {u.name} (@{u.username}) — {u.email}
                    </option>
                  ))}
                </select>
              </div>
            )}
          </div>

          {/* Form Actions */}
          <div className="flex flex-col-reverse sm:flex-row sm:items-center sm:justify-end gap-2 pt-4 border-t border-neutral-200">
            <button
              id="btn-cancel-customer-modal"
              type="button"
              onClick={onClose}
              disabled={saving}
              className="w-full sm:w-auto px-4 py-2.5 sm:py-2 text-xs font-semibold text-neutral-700 hover:bg-neutral-100 rounded-lg transition text-center"
            >
              Cancel
            </button>
            <button
              id="btn-save-customer"
              type="submit"
              disabled={saving}
              className="w-full sm:w-auto px-5 py-2.5 sm:py-2 text-xs font-bold text-white bg-neutral-900 hover:bg-neutral-800 disabled:opacity-50 rounded-lg shadow-sm transition flex items-center justify-center gap-2"
            >
              {saving ? (
                <>Saving Account...</>
              ) : (
                <>
                  <CheckCircle2 className="w-4 h-4 text-orange-400" />
                  {customerToEdit ? 'Save Changes' : 'Register Customer'}
                </>
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
