import {
  collection,
  doc,
  getDoc,
  onSnapshot,
  setDoc,
  updateDoc,
  runTransaction,
  query,
  orderBy,
  where,
  getDocs,
  deleteDoc,
  writeBatch,
  limit,
  startAfter,
  getCountFromServer,
  getAggregateFromServer,
  sum,
} from 'firebase/firestore';
import { db } from './firebase';
import { verifyPassword } from '../utils/password';
import {
  Customer,
  CustomerStatus,
  CustomerType,
  CustomerCanonicalStatus,
  CustomerMigrationSummary,
  Invoice,
  Payment,
  Expense,
  ExpenseStatus,
  ExpenseTimelineEntry,
  BusinessSettings,
  InvoiceItem,
  CustomerSnapshot,
  CompanySnapshot,
  InvoiceStatus,
  InvoiceBillingState,
  AssignmentHistoryEntry,
  ReceiptDesignSettings,
  CustomerRegistration,
  Service,
  Post,
  AuditLog,
  AuditLogChange,
  CustomerRequest,
  CustomerRequestReply,
  Project,
  AppNotification,
  UserProfile,
  EmployeeDocument,
  UserRole,
  UserPermissions,
  UserAccountStatus,
  RequestStatus,
  PaymentMethod,
  PAYMENT_METHOD_LABELS,
  PaymentStatusFilter,
  PaymentSortField,
  PaymentSortDirection,
} from '../types';
import { isProfileComplete } from '../utils/profileCompletion';
import { isInvoiceLocked } from '../utils/invoiceCalculator';
import {
  validatePaymentDate,
  validatePaymentMethod,
  sanitizePaymentNote,
  checkPaymentReversalEligibility,
} from '../utils/paymentValidation';
import {
  normalizeCustomerStatus,
  migrateCustomerId,
  findDuplicatePhoneCustomer,
  validateCustomerData,
  normalizePhone,
} from '../utils/customerValidation';

/**
 * Recursively cleans any data payload before sending to Firestore,
 * ensuring that NO 'undefined' properties are ever transmitted.
 */
export function cleanDataForFirestore<T>(data: T): T {
  if (data === null || data === undefined) {
    return null as any;
  }
  if (Array.isArray(data)) {
    return data
      .filter((item) => item !== undefined)
      .map((item) => cleanDataForFirestore(item)) as any;
  }
  if (typeof data === 'object' && !(data instanceof Date)) {
    const cleaned: Record<string, any> = {};
    for (const [key, val] of Object.entries(data)) {
      if (val !== undefined) {
        const cleanedVal = cleanDataForFirestore(val);
        if (cleanedVal !== undefined) {
          cleaned[key] = cleanedVal;
        }
      }
    }
    return cleaned as any;
  }
  return data;
}

export const DEFAULT_SETTINGS: BusinessSettings = {
  companyName: 'Sarwan Technology',
  logo: '/sarwan-logo.png',
  logo2: '/dahua-logo.svg',
  phone: '0731339014',
  whatsapp: '0778771020',
  email: 'Sarwantechnology.af@gmail.com',
  address: 'Kabul, Afghanistan',
  website: 'https://sarwantechnology.af',
  invoicePrefix: 'ST-',
  nextInvoiceNumber: 1060,
  currency: 'AFN',
  invoiceNote: 'Note: Goods once sold cannot be returned. This bill is valid only with authorized manager signature.',
  footerText: 'Sarwan Technology - Comprehensive Security & Surveillance Solutions',
  authorizedEmails: ['bilalsarwan7@gmail.com', 'bilalsarwan2@gmail.com', 'sarwancreative.af@gmail.com'],
  loginTitle: 'Sarwan Technology',
  loginSubtitle: 'Billing & Business Management System',
  loginWelcome: 'Security Surveillance & Technology Equipment Supplier',
};

// Ensure 20 items in invoice table
export function createDefault20Items(): InvoiceItem[] {
  return Array.from({ length: 20 }, (_, index) => ({
    sNo: index + 1,
    description: '',
    quantity: '',
    unitPrice: '',
    totalAmount: 0,
  }));
}

// Subscribe to Settings
export function subscribeToSettings(
  onUpdate: (settings: BusinessSettings) => void,
  onError?: (err: Error) => void
) {
  const settingsDocRef = doc(db, 'settings', 'company_settings');
  return onSnapshot(
    settingsDocRef,
    (snapshot) => {
      if (snapshot.exists()) {
        onUpdate({ ...DEFAULT_SETTINGS, ...snapshot.data() } as BusinessSettings);
      } else {
        // Initialize default settings in Firestore
        setDoc(settingsDocRef, DEFAULT_SETTINGS).catch(console.error);
        onUpdate(DEFAULT_SETTINGS);
      }
    },
    (err) => {
      console.warn('Settings subscription fallback:', err);
      onUpdate(DEFAULT_SETTINGS);
      if (onError) onError(err);
    }
  );
}

// Update Settings
export async function updateBusinessSettings(
  newSettings: Partial<BusinessSettings>,
  userId: string = 'system',
  userName: string = 'System Admin'
): Promise<void> {
  const settingsDocRef = doc(db, 'settings', 'company_settings');
  await setDoc(settingsDocRef, newSettings, { merge: true });

  await addAuditLog({
    action: 'update_settings',
    userId,
    userName,
    entityType: 'settings',
    entityId: 'company_settings',
    summary: 'Updated company business & invoice settings',
  });
}

// ================= AUDIT LOGS =================
export async function addAuditLog(logData: {
  action: AuditLog['action'];
  userId: string;
  userName: string;
  userRole?: string;
  entityType: AuditLog['entityType'];
  entityId: string;
  referenceNumber?: string;
  summary: string;
  changes?: AuditLogChange[];
}): Promise<string> {
  try {
    const logRef = doc(collection(db, 'auditLogs'));
    const now = new Date().toISOString();
    const logItem: AuditLog = {
      id: logRef.id,
      dateTime: now,
      ...logData,
    };
    const cleanLog = Object.fromEntries(
      Object.entries(logItem).filter(([_, v]) => v !== undefined)
    );
    await setDoc(logRef, cleanLog);
    return logRef.id;
  } catch (err) {
    console.warn('Could not record audit log:', err);
    return '';
  }
}

export function subscribeToAuditLogs(
  onUpdate: (logs: AuditLog[]) => void,
  onError?: (err: Error) => void
) {
  const q = query(collection(db, 'auditLogs'), orderBy('dateTime', 'desc'));
  return onSnapshot(
    q,
    (snapshot) => {
      const logs: AuditLog[] = [];
      snapshot.forEach((docSnap) => {
        logs.push({ id: docSnap.id, ...docSnap.data() } as AuditLog);
      });
      onUpdate(logs);
    },
    (err) => {
      console.warn('Audit logs listener error:', err);
      if (onError) onError(err);
    }
  );
}

// ================= CUSTOMERS =================
export function subscribeToCustomers(
  onUpdate: (customers: Customer[]) => void,
  onError?: (err: Error) => void
) {
  const q = query(collection(db, 'customers'), orderBy('createdAt', 'desc'));
  return onSnapshot(
    q,
    (snapshot) => {
      const customers: Customer[] = [];
      snapshot.forEach((docSnap) => {
        const raw = docSnap.data();
        const normStatus = normalizeCustomerStatus(raw.status, raw.isArchived);
        const rawCode = raw.customerCode || raw.customerId || '';
        const normCode = migrateCustomerId(rawCode, 1001);
        const normType: CustomerType =
          raw.customerType || (raw.companyName && raw.companyName.trim().length > 0 ? 'Business' : 'Individual');

        const customer: Customer = {
          id: docSnap.id,
          customerCode: normCode,
          customerId: normCode,
          customerType: normType,
          name: raw.name || '',
          phone: raw.phone || '',
          alternatePhone: raw.alternatePhone || '',
          email: raw.email || '',
          address: raw.address || '',
          city: raw.city || '',
          province: raw.province || '',
          companyName: raw.companyName || '',
          note: raw.note || raw.notes || '',
          notes: raw.notes || raw.note || '',
          photoURL: raw.photoURL || '',
          status: normStatus,
          isArchived: normStatus === 'Inactive',
          userId: raw.userId || '',
          userUsername: raw.userUsername || '',
          userEmail: raw.userEmail || '',
          hasPortalAccount: Boolean(raw.userId || raw.hasPortalAccount),
          portalEnabled: Boolean(raw.portalEnabled ?? (normStatus === 'Active' && (raw.userId || raw.hasPortalAccount))),
          createdAt: raw.createdAt || new Date().toISOString(),
          updatedAt: raw.updatedAt || raw.createdAt || new Date().toISOString(),
          createdBy: raw.createdBy || '',
          createdByName: raw.createdByName || '',
          updatedBy: raw.updatedBy || '',
          updatedByName: raw.updatedByName || '',
        };
        customers.push(customer);

        // Controlled in-place document migration for legacy codes and fields
        // Crucial: Firebase document ID remains unchanged, invoice.customerId remains unchanged!
        const needsCodeMigration = rawCode.startsWith('CUST-') || !raw.customerCode;
        const needsStatusMigration =
          raw.status === 'active' ||
          raw.status === 'deactivated' ||
          raw.status === 'archived' ||
          !raw.customerType;

        if (needsCodeMigration || needsStatusMigration) {
          updateDoc(docSnap.ref, {
            customerCode: normCode,
            customerId: normCode,
            status: normStatus,
            customerType: normType,
            updatedAt: new Date().toISOString(),
          }).catch(() => {
            // Background migration error ignored silently
          });
        }
      });
      onUpdate(customers);
    },
    (err) => {
      console.warn('Customers listener error:', err);
      if (onError) onError(err);
    }
  );
}

/**
 * Allocates the next immutable, auto-incrementing Customer ID using a Firestore transaction.
 * Format: ST-CUST-1001, ST-CUST-1002, ST-CUST-1003...
 * 
 * Rules enforced:
 * 1. Base starting number is 1001.
 * 2. Increments exactly +1 atomically in a Firestore transaction.
 * 3. Atomic transaction prevents race conditions and duplicate IDs between concurrent users.
 * 4. Stored persistently in systemCounters/customerIdCounter.
 * 5. IDs are never reused even if customer records are deleted.
 * 6. Never generated by simply counting frontend records.
 */
export async function allocateNextCustomerId(prefix = 'ST-CUST-'): Promise<string> {
  const counterRef = doc(db, 'systemCounters', 'customerIdCounter');
  const allocatedId = await runTransaction(db, async (transaction) => {
    const counterSnap = await transaction.get(counterRef);
    let nextNum = 1001;

    if (counterSnap.exists()) {
      const data = counterSnap.data();
      if (typeof data.nextNumber === 'number') {
        nextNum = data.nextNumber;
      } else if (typeof data.currentNumber === 'number') {
        nextNum = data.currentNumber + 1;
      }
    } else {
      // First-time counter seeding: inspect existing customer records to find true maximum
      const custSnap = await getDocs(collection(db, 'customers'));
      let maxNum = 1000;
      custSnap.forEach((d) => {
        const data = d.data();
        const code = String(data.customerCode || data.customerId || '');
        if (code) {
          const numMatch = code.match(/(?:ST-CUST-|CUST-)?(\d+)/i);
          if (numMatch && numMatch[1]) {
            const numPart = parseInt(numMatch[1], 10);
            if (!isNaN(numPart) && numPart > maxNum) {
              maxNum = numPart;
            }
          }
        }
      });
      nextNum = maxNum + 1;
    }

    transaction.set(
      counterRef,
      {
        currentNumber: nextNum,
        nextNumber: nextNum + 1,
        lastAllocatedId: `${prefix}${nextNum}`,
        updatedAt: new Date().toISOString(),
      },
      { merge: true }
    );

    return `${prefix}${nextNum}`;
  });

  return allocatedId;
}

/**
 * Peeks or previews the next sequential Customer Code (ST-CUST-1001, ST-CUST-1002, etc.)
 * for form prefilling without claiming/incrementing the atomic counter prematurely.
 */
export async function generateNextCustomerCode(prefix = 'ST-CUST-'): Promise<string> {
  try {
    const counterRef = doc(db, 'systemCounters', 'customerIdCounter');
    const counterSnap = await getDoc(counterRef);
    if (counterSnap.exists()) {
      const data = counterSnap.data();
      if (typeof data.nextNumber === 'number') {
        return `${prefix}${data.nextNumber}`;
      }
      if (typeof data.currentNumber === 'number') {
        return `${prefix}${data.currentNumber + 1}`;
      }
    }

    const custSnap = await getDocs(collection(db, 'customers'));
    let maxNum = 1000;
    custSnap.forEach((d) => {
      const data = d.data();
      const code = String(data.customerCode || data.customerId || '');
      if (code) {
        const numMatch = code.match(/(?:ST-CUST-|CUST-)?(\d+)/i);
        if (numMatch && numMatch[1]) {
          const numPart = parseInt(numMatch[1], 10);
          if (!isNaN(numPart) && numPart > maxNum) {
            maxNum = numPart;
          }
        }
      }
    });
    return `${prefix}${maxNum + 1}`;
  } catch (err) {
    console.warn('Error previewing next customer code, using fallback:', err);
    return `${prefix}1001`;
  }
}

export async function saveCustomer(
  customerData: {
    id?: string;
    customerCode?: string;
    customerId?: string;
    customerType?: CustomerType;
    name: string;
    phone: string;
    alternatePhone?: string;
    email?: string;
    address?: string;
    city?: string;
    province?: string;
    companyName?: string;
    note?: string;
    notes?: string;
    photoURL?: string;
    status?: CustomerStatus;
    isArchived?: boolean;
    userId?: string;
    hasPortalAccount?: boolean;
    portalEnabled?: boolean;
    allowDuplicatePhone?: boolean;
  },
  userId: string = 'system',
  userName: string = 'User',
  userRole: string = 'super_admin'
): Promise<string> {
  const customerType: CustomerType = customerData.customerType || 'Individual';
  const trimmedName = customerData.name?.trim() || '';
  const trimmedPhone = customerData.phone?.trim() || '';
  const trimmedAltPhone = customerData.alternatePhone?.trim() || '';
  const trimmedEmail = customerData.email?.trim().toLowerCase() || '';
  const trimmedAddress = customerData.address?.trim() || '';
  const trimmedCity = customerData.city?.trim() || '';
  const trimmedProvince = customerData.province?.trim() || '';
  const trimmedCompany = customerData.companyName?.trim() || '';
  const combinedNote = (customerData.notes || customerData.note || '').trim();
  const photoURL = customerData.photoURL?.trim() || '';

  // 1. Backend Validation of all Required Fields
  const validation = validateCustomerData({
    customerType,
    name: trimmedName,
    companyName: trimmedCompany,
    phone: trimmedPhone,
    email: trimmedEmail,
    address: trimmedAddress,
    city: trimmedCity,
    province: trimmedProvince,
  });

  if (!validation.isValid) {
    const firstErr = Object.values(validation.errors)[0];
    throw new Error(firstErr || 'Customer data validation failed.');
  }

  // 2. Determine and normalize status
  // New customers default to Active and cannot be created as Blocked
  let rawStatus = customerData.status;
  if (!customerData.id) {
    if (rawStatus === 'Blocked' || rawStatus === ('blocked' as any)) {
      throw new Error('New customer accounts cannot be directly created with "Blocked" status. New accounts default to Active.');
    }
    rawStatus = 'Active';
  }
  const normStatus = normalizeCustomerStatus(rawStatus, customerData.isArchived);
  const isArchived = normStatus === 'Inactive';

  // 3. Duplicate Phone Check using normalized phone (exclude editing customer)
  const customersCol = collection(db, 'customers');
  const allCustSnap = await getDocs(customersCol);
  const existingCustomers: Customer[] = [];
  allCustSnap.forEach((d) => {
    existingCustomers.push({ id: d.id, ...d.data() } as Customer);
  });

  const duplicateCust = findDuplicatePhoneCustomer(
    trimmedPhone,
    existingCustomers,
    customerData.id
  );

  if (duplicateCust && !customerData.allowDuplicatePhone) {
    const dupCode = duplicateCust.customerCode || duplicateCust.id;
    const dupCompany = duplicateCust.companyName ? ` (${duplicateCust.companyName})` : '';
    throw new Error(
      `Duplicate Phone Detected: A customer with phone number "${trimmedPhone}" already exists: ${dupCode} - ${duplicateCust.name}${dupCompany}.`
    );
  }

  const now = new Date().toISOString();

  // 4. Update or Create
  if (customerData.id) {
    // EDIT FLOW: Customer ID and Firebase Document ID are strictly immutable
    const custRef = doc(db, 'customers', customerData.id);
    const existingSnap = await getDoc(custRef);
    if (!existingSnap.exists()) {
      throw new Error('Customer record not found.');
    }
    const existingData = existingSnap.data() as Customer;
    const immutableCustomerCode =
      existingData.customerCode || existingData.customerId || migrateCustomerId(customerData.id, 1001);

    // If changing from Blocked to Active/Inactive, ensure role is authorized
    const existingNormStatus = normalizeCustomerStatus(existingData.status, existingData.isArchived);
    if (existingNormStatus === 'Blocked' && normStatus !== 'Blocked' && userRole !== 'super_admin') {
      throw new Error('Access Denied: Only Super Admin has permission to unblock a blocked customer.');
    }

    const updatedCustomer: Partial<Customer> = {
      customerCode: immutableCustomerCode,
      customerId: immutableCustomerCode,
      customerType,
      name: trimmedName,
      phone: trimmedPhone,
      alternatePhone: trimmedAltPhone,
      email: trimmedEmail,
      address: trimmedAddress,
      city: trimmedCity,
      province: trimmedProvince,
      companyName: trimmedCompany,
      note: combinedNote,
      notes: combinedNote,
      photoURL,
      status: normStatus,
      isArchived,
      updatedAt: now,
      updatedBy: userId,
      updatedByName: userName,
    };

    if (customerData.userId !== undefined) {
      updatedCustomer.userId = customerData.userId || '';
      updatedCustomer.hasPortalAccount = Boolean(customerData.userId);
      updatedCustomer.portalEnabled = normStatus === 'Active' && Boolean(customerData.userId);
    }

    await updateDoc(custRef, cleanDataForFirestore(updatedCustomer));

    // If linked to a user account, keep link synchronized
    if (customerData.userId) {
      const userRef = doc(db, 'users', customerData.userId);
      await updateDoc(userRef, {
        customerId: customerData.id,
        updatedAt: now,
      }).catch(console.warn);
    }

    await addAuditLog({
      action: 'CUSTOMER_UPDATED',
      userId,
      userName,
      userRole,
      entityType: 'customer',
      entityId: customerData.id,
      referenceNumber: immutableCustomerCode,
      summary: `Updated customer profile: ${trimmedName} (${immutableCustomerCode}) - Status: ${normStatus}`,
    });

    return customerData.id;
  } else {
    // CREATE FLOW: Safely generate atomic ST-CUST-XXXX sequential ID via transaction
    const newCustRef = doc(collection(db, 'customers'));
    const customerCode = await allocateNextCustomerId('ST-CUST-');

    const newCustomer: Customer = {
      id: newCustRef.id,
      customerCode,
      customerId: customerCode,
      customerType,
      name: trimmedName,
      phone: trimmedPhone,
      alternatePhone: trimmedAltPhone,
      email: trimmedEmail,
      address: trimmedAddress,
      city: trimmedCity,
      province: trimmedProvince,
      companyName: trimmedCompany,
      note: combinedNote,
      notes: combinedNote,
      photoURL,
      status: 'Active',
      isArchived: false,
      userId: customerData.userId || '',
      hasPortalAccount: Boolean(customerData.userId),
      portalEnabled: Boolean(customerData.userId),
      createdAt: now,
      updatedAt: now,
      createdBy: userId,
      createdByName: userName,
      updatedBy: userId,
      updatedByName: userName,
    };

    await setDoc(newCustRef, cleanDataForFirestore(newCustomer));

    // If user account is linked, update user record
    if (customerData.userId) {
      const userRef = doc(db, 'users', customerData.userId);
      await updateDoc(userRef, {
        customerId: newCustRef.id,
        updatedAt: now,
      }).catch(console.warn);
    }

    await addAuditLog({
      action: 'CUSTOMER_CREATED',
      userId,
      userName,
      userRole,
      entityType: 'customer',
      entityId: newCustRef.id,
      referenceNumber: customerCode,
      summary: `Created new customer: ${trimmedName} (${customerCode}, Type: ${customerType}, Phone: ${trimmedPhone})`,
    });

    return newCustRef.id;
  }
}

/**
 * Updates Customer Status (Active | Inactive | Blocked) with strict role authorization:
 * - Active: Invoices, payments, profile editing, portal allowed.
 * - Inactive: New invoices blocked, standalone payments blocked, profile editing allowed, portal disabled.
 * - Blocked: New invoices blocked, standalone payments blocked, profile editing allowed, portal disabled.
 *   ONLY Super Admin can unblock a Blocked customer.
 */
export async function setCustomerStatus(
  customerId: string,
  newStatus: CustomerStatus,
  userId: string = 'system',
  userName: string = 'User',
  userRole: string = 'super_admin'
): Promise<void> {
  const custRef = doc(db, 'customers', customerId);
  const custSnap = await getDoc(custRef);
  if (!custSnap.exists()) {
    throw new Error('Customer record not found.');
  }

  const custData = custSnap.data() as Customer;
  const currentStatus = normalizeCustomerStatus(custData.status, custData.isArchived);
  const targetStatus = normalizeCustomerStatus(newStatus);

  // Permission Check: Collectors and Customers cannot change customer status
  if (userRole === 'payment_collector' || userRole === 'customer') {
    throw new Error('Access Denied: You do not have permission to change customer status.');
  }

  // Unblocking Check: Only Super Admin can unblock a Blocked customer
  if (currentStatus === 'Blocked' && targetStatus !== 'Blocked') {
    if (userRole !== 'super_admin') {
      throw new Error('Access Denied: Only Super Admin has permission to unblock a blocked customer.');
    }
  }

  const now = new Date().toISOString();
  const isArchived = targetStatus === 'Inactive';
  const portalEnabled = targetStatus === 'Active' && Boolean(custData.userId || custData.hasPortalAccount);

  await updateDoc(custRef, {
    status: targetStatus,
    isArchived,
    portalEnabled,
    updatedAt: now,
    updatedBy: userId,
    updatedByName: userName,
  });

  // If customer has a linked user account, keep user status synced or disabled
  if (custData.userId) {
    const userRef = doc(db, 'users', custData.userId);
    const userStatus = targetStatus === 'Active' ? 'active' : targetStatus === 'Blocked' ? 'suspended' : 'inactive';
    await updateDoc(userRef, {
      status: userStatus,
      updatedAt: now,
    }).catch(console.warn);
  }

  let actionType: any = 'CUSTOMER_UPDATED';
  if (targetStatus === 'Inactive') actionType = 'CUSTOMER_DEACTIVATED';
  else if (targetStatus === 'Blocked') actionType = 'CUSTOMER_BLOCKED';
  else if (targetStatus === 'Active' && currentStatus === 'Blocked') actionType = 'CUSTOMER_UNBLOCKED';
  else if (targetStatus === 'Active') actionType = 'CUSTOMER_REACTIVATED';

  await addAuditLog({
    action: actionType,
    userId,
    userName,
    userRole,
    entityType: 'customer',
    entityId: customerId,
    referenceNumber: custData.customerCode || customerId,
    summary: `Changed customer status from ${currentStatus} to ${targetStatus} (${custData.name})`,
  });
}

export async function archiveCustomer(
  customerId: string,
  isArchived = true,
  userId: string = 'system',
  userName: string = 'User',
  userRole: string = 'super_admin'
): Promise<void> {
  return setCustomerStatus(
    customerId,
    isArchived ? 'Inactive' : 'Active',
    userId,
    userName,
    userRole
  );
}

/**
 * Safely deletes a customer record.
 * STRICT PROTECTION: If the customer has ANY historical invoices or payments,
 * permanent deletion is prevented to protect accounting records and audit integrity.
 * Never reuses deleted customer IDs (counter is atomic and forward-only).
 */
export async function deleteCustomerSafely(
  customerId: string,
  userId: string = 'system',
  userName: string = 'User'
): Promise<void> {
  const custRef = doc(db, 'customers', customerId);
  const custSnap = await getDoc(custRef);
  if (!custSnap.exists()) {
    throw new Error('Customer record not found.');
  }

  const custData = custSnap.data() as Customer;

  // Check for any existing invoices attached to this customer
  const invoicesQ = query(
    collection(db, 'invoices'),
    where('customerId', '==', customerId)
  );
  const invSnap = await getDocs(invoicesQ);

  // Check for any payments attached to this customer
  const paymentsQ = query(
    collection(db, 'payments'),
    where('customerId', '==', customerId)
  );
  const paySnap = await getDocs(paymentsQ);

  if (!invSnap.empty || !paySnap.empty) {
    const invCount = invSnap.size;
    const payCount = paySnap.size;
    throw new Error(
      `Cannot permanently delete customer "${custData.name}". This account has ${invCount} historical invoice(s) and ${payCount} payment transaction(s). Historical financial ledgers must remain intact for accounting integrity. Please deactivate or archive this customer instead.`
    );
  }

  // If customer was linked to a user account, unlink it first
  if (custData.userId) {
    const userRef = doc(db, 'users', custData.userId);
    await updateDoc(userRef, {
      customerId: '',
      updatedAt: new Date().toISOString(),
    }).catch(console.warn);
  }

  // Delete customer document
  await deleteDoc(custRef);

  await addAuditLog({
    action: 'CUSTOMER_DELETED',
    userId,
    userName,
    entityType: 'customer',
    entityId: customerId,
    referenceNumber: custData.customerCode || custData.name,
    summary: `Permanently deleted customer record "${custData.name}" (${custData.customerCode || customerId}) (No transaction history).`,
  });
}

/**
 * Links a customer record to an existing user account in the central users collection.
 */
export async function linkCustomerToUserAccount(
  customerId: string,
  userAccountId: string,
  userId: string = 'system',
  userName: string = 'User'
): Promise<void> {
  const custRef = doc(db, 'customers', customerId);
  const userRef = doc(db, 'users', userAccountId);

  const [custSnap, userSnap] = await Promise.all([getDoc(custRef), getDoc(userRef)]);

  if (!custSnap.exists()) {
    throw new Error('Customer record not found.');
  }
  if (!userSnap.exists()) {
    throw new Error('User account not found.');
  }

  const custData = custSnap.data() as Customer;
  const userData = userSnap.data() as UserProfile;

  // Verify user is not already linked to another customer
  if (userData.customerId && userData.customerId !== customerId) {
    throw new Error(
      `This user account is already linked to another customer (Customer ID: ${userData.customerId}).`
    );
  }

  const now = new Date().toISOString();
  const custStatus = normalizeCustomerStatus(custData.status, custData.isArchived);

  // Update customer
  await updateDoc(custRef, {
    userId: userAccountId,
    userUsername: userData.username,
    userEmail: userData.email,
    hasPortalAccount: true,
    portalEnabled: custStatus === 'Active',
    updatedAt: now,
  });

  // Update user
  await updateDoc(userRef, {
    customerId: customerId,
    role: 'customer',
    status: custStatus === 'Active' ? 'active' : 'inactive',
    updatedAt: now,
  });

  await addAuditLog({
    action: 'PORTAL_ENABLED',
    userId,
    userName,
    entityType: 'customer',
    entityId: customerId,
    referenceNumber: custData.customerCode || custData.name,
    summary: `Linked customer "${custData.name}" to portal user @${userData.username}.`,
  });
}

/**
 * Unlinks a customer from their portal user account.
 */
export async function unlinkCustomerUserAccount(
  customerId: string,
  userId: string = 'system',
  userName: string = 'User'
): Promise<void> {
  const custRef = doc(db, 'customers', customerId);
  const custSnap = await getDoc(custRef);

  if (!custSnap.exists()) {
    throw new Error('Customer record not found.');
  }

  const custData = custSnap.data() as Customer;
  const linkedUserId = custData.userId;

  const now = new Date().toISOString();

  await updateDoc(custRef, {
    userId: '',
    userUsername: '',
    userEmail: '',
    hasPortalAccount: false,
    portalEnabled: false,
    updatedAt: now,
  });

  if (linkedUserId) {
    const userRef = doc(db, 'users', linkedUserId);
    await updateDoc(userRef, {
      customerId: '',
      updatedAt: now,
    }).catch(console.warn);
  }

  await addAuditLog({
    action: 'PORTAL_DISABLED',
    userId,
    userName,
    entityType: 'customer',
    entityId: customerId,
    referenceNumber: custData.customerCode || custData.name,
    summary: `Unlinked portal user account from customer "${custData.name}".`,
  });
}

/**
 * Migration Utility for Customer IDs:
 * 1. Inspects all existing customer records in-place.
 * 2. Detects missing IDs, legacy 'CUST-XXXX' IDs, or numeric IDs.
 * 3. Normalizes legacy IDs into 'ST-CUST-XXXX' without altering Firebase Document IDs.
 * 4. Preserves all invoice.customerId relationships and historical snapshots.
 * 5. Guarantees no duplicate documents are ever created.
 * 6. Synchronizes atomic counter in systemCounters/customerIdCounter so future IDs never clash.
 * 7. Returns a detailed Migration Summary.
 */
export async function migrateCustomerIdsInPlace(): Promise<CustomerMigrationSummary> {
  const summary: CustomerMigrationSummary = {
    totalInspected: 0,
    alreadyCompliant: 0,
    migratedCount: 0,
    missingCodesFixed: 0,
    duplicatesDetected: [],
    highestAllocatedCode: 'ST-CUST-1000',
    maxNumericValue: 1000,
    errors: [],
    success: true,
    timestamp: new Date().toISOString(),
  };

  try {
    const custSnap = await getDocs(collection(db, 'customers'));
    summary.totalInspected = custSnap.size;

    const seenCodes = new Set<string>();
    const docsToMigrate: Array<{
      ref: any;
      id: string;
      raw: any;
      targetCode: string;
      isMissing: boolean;
    }> = [];

    let currentMaxNum = 1000;

    // Phase 1: Inspection & Detection of Existing Unique Codes
    custSnap.forEach((d) => {
      const raw = d.data();
      const rawCode = String(raw.customerCode || raw.customerId || '').trim();

      if (rawCode) {
        const match = rawCode.match(/(?:ST-CUST-|CUST-)?(\d+)/i);
        if (match && match[1]) {
          const num = parseInt(match[1], 10);
          if (!isNaN(num) && num > currentMaxNum) {
            currentMaxNum = num;
          }
        }

        if (seenCodes.has(rawCode.toUpperCase())) {
          summary.duplicatesDetected.push(rawCode);
        } else {
          seenCodes.add(rawCode.toUpperCase());
        }
      }
    });

    // Phase 2: Plan Migrations
    custSnap.forEach((d) => {
      const raw = d.data();
      const rawCode = String(raw.customerCode || raw.customerId || '').trim();
      const isMissing = !rawCode;

      const isLegacyFormat = rawCode.startsWith('CUST-') || /^\d+$/.test(rawCode);
      const isExactValid = /^ST-CUST-\d+$/.test(rawCode);

      if (isExactValid && raw.customerCode === raw.customerId && raw.customerType && raw.status) {
        summary.alreadyCompliant++;
        return;
      }

      let targetCode = '';
      if (isMissing) {
        currentMaxNum++;
        targetCode = `ST-CUST-${currentMaxNum}`;
        summary.missingCodesFixed++;
      } else if (isLegacyFormat) {
        const match = rawCode.match(/(?:CUST-)?(\d+)/i);
        const numPart = match && match[1] ? match[1] : '';
        const candidate = `ST-CUST-${numPart}`;
        if (candidate && !seenCodes.has(candidate.toUpperCase())) {
          targetCode = candidate;
          seenCodes.add(candidate.toUpperCase());
        } else {
          currentMaxNum++;
          targetCode = `ST-CUST-${currentMaxNum}`;
        }
      } else if (!isExactValid) {
        currentMaxNum++;
        targetCode = `ST-CUST-${currentMaxNum}`;
      } else {
        targetCode = rawCode;
      }

      docsToMigrate.push({
        ref: d.ref,
        id: d.id,
        raw,
        targetCode,
        isMissing,
      });
    });

    // Phase 3: Execute in-place updates (never duplicate documents)
    for (const item of docsToMigrate) {
      try {
        const normStatus = normalizeCustomerStatus(item.raw.status, item.raw.isArchived);
        const normType: CustomerType =
          item.raw.customerType ||
          (item.raw.companyName && item.raw.companyName.trim().length > 0 ? 'Business' : 'Individual');

        await updateDoc(item.ref, {
          customerCode: item.targetCode,
          customerId: item.targetCode,
          status: normStatus,
          customerType: normType,
          updatedAt: new Date().toISOString(),
        });

        summary.migratedCount++;
      } catch (err: any) {
        summary.errors.push({
          customerId: item.id,
          error: err.message || String(err),
        });
        summary.success = false;
      }
    }

    // Phase 4: Sync system counter
    summary.maxNumericValue = currentMaxNum;
    summary.highestAllocatedCode = `ST-CUST-${currentMaxNum}`;

    const counterRef = doc(db, 'systemCounters', 'customerIdCounter');
    await setDoc(
      counterRef,
      {
        currentNumber: currentMaxNum,
        nextNumber: currentMaxNum + 1,
        lastAllocatedId: `ST-CUST-${currentMaxNum}`,
        updatedAt: new Date().toISOString(),
      },
      { merge: true }
    );
  } catch (globalErr: any) {
    summary.success = false;
    summary.errors.push({
      customerId: 'GLOBAL',
      error: globalErr.message || String(globalErr),
    });
  }

  return summary;
}

export interface CustomersPaginationResult {
  customers: Customer[];
  lastDoc: any;
  hasMore: boolean;
  totalCount?: number;
}

/**
 * Server-side paginated queries for large customer databases.
 */
export async function fetchCustomersPaginated(params: {
  pageSize?: number;
  lastVisibleDoc?: any;
  statusFilter?: string;
  typeFilter?: string;
}): Promise<CustomersPaginationResult> {
  const pageSize = params.pageSize || 20;
  const constraints: any[] = [];

  if (params.statusFilter && params.statusFilter !== 'all') {
    constraints.push(where('status', '==', params.statusFilter));
  }

  if (params.typeFilter && params.typeFilter !== 'all') {
    constraints.push(where('customerType', '==', params.typeFilter));
  }

  constraints.push(orderBy('createdAt', 'desc'));
  constraints.push(limit(pageSize + 1));

  if (params.lastVisibleDoc) {
    constraints.push(startAfter(params.lastVisibleDoc));
  }

  const q = query(collection(db, 'customers'), ...constraints);
  const snap = await getDocs(q);

  const docs = snap.docs;
  const hasMore = docs.length > pageSize;
  const pageDocs = hasMore ? docs.slice(0, pageSize) : docs;
  const lastDoc = pageDocs.length > 0 ? pageDocs[pageDocs.length - 1] : null;

  const customers: Customer[] = pageDocs.map((docSnap) => {
    const raw = docSnap.data();
    const normStatus = normalizeCustomerStatus(raw.status, raw.isArchived);
    const normCode = raw.customerCode || raw.customerId || `ST-CUST-${docSnap.id.slice(0, 4)}`;
    const normType: CustomerType =
      raw.customerType || (raw.companyName && raw.companyName.trim().length > 0 ? 'Business' : 'Individual');

    return {
      id: docSnap.id,
      customerCode: normCode,
      customerId: normCode,
      customerType: normType,
      name: raw.name || '',
      phone: raw.phone || '',
      alternatePhone: raw.alternatePhone || '',
      email: raw.email || '',
      address: raw.address || '',
      city: raw.city || '',
      province: raw.province || '',
      companyName: raw.companyName || '',
      note: raw.note || raw.notes || '',
      notes: raw.notes || raw.note || '',
      photoURL: raw.photoURL || '',
      status: normStatus,
      isArchived: normStatus === 'Inactive',
      userId: raw.userId || '',
      userUsername: raw.userUsername || '',
      userEmail: raw.userEmail || '',
      hasPortalAccount: Boolean(raw.userId || raw.hasPortalAccount),
      portalEnabled: Boolean(raw.portalEnabled ?? (normStatus === 'Active' && (raw.userId || raw.hasPortalAccount))),
      createdAt: raw.createdAt || new Date().toISOString(),
      updatedAt: raw.updatedAt || raw.createdAt || new Date().toISOString(),
      createdBy: raw.createdBy || '',
      createdByName: raw.createdByName || '',
      updatedBy: raw.updatedBy || '',
      updatedByName: raw.updatedByName || '',
    };
  });

  return {
    customers,
    lastDoc,
    hasMore,
  };
}

// ================= INVOICES =================
export function subscribeToInvoices(
  onUpdate: (invoices: Invoice[]) => void,
  onError?: (err: Error) => void
) {
  const q = query(collection(db, 'invoices'), orderBy('createdAt', 'desc'));
  return onSnapshot(
    q,
    (snapshot) => {
      const invoices: Invoice[] = [];
      snapshot.forEach((docSnap) => {
        invoices.push({ id: docSnap.id, ...docSnap.data() } as Invoice);
      });
      onUpdate(invoices);
    },
    (err) => {
      console.warn('Invoices listener error:', err);
      if (onError) onError(err);
    }
  );
}

// Atomic Invoice Creation with Sequential Bill Number starting from ST-1060
export async function createInvoiceWithAtomicNumber(params: {
  customerId: string;
  customerSnapshot: CustomerSnapshot;
  companySnapshot: CompanySnapshot;
  date: string;
  items: InvoiceItem[];
  totalAmount: number;
  note: string;
  initialCashPaid?: number;
  paymentNote?: string;
  requestId?: string;
  userId?: string;
  userName?: string;
  assignedCollectorId?: string;
  assignedCollectorName?: string;
  templateId?: string;
  billingState?: InvoiceBillingState;
}): Promise<Invoice> {
  const settingsRef = doc(db, 'settings', 'company_settings');
  const invoicesColl = collection(db, 'invoices');
  const paymentsColl = collection(db, 'payments');
  const newInvoiceRef = doc(invoicesColl);
  const now = new Date().toISOString();

  // New invoices default to "quotation"
  const billingState: InvoiceBillingState = params.billingState || 'quotation';
  const isPayable = billingState === 'payable';

  let generatedBillNumber = 'ST-1060';
  let status: InvoiceStatus = 'Unpaid';
  // Quotations and rejected invoices cannot have initial payments
  const initialCash = isPayable ? (Number(params.initialCashPaid) || 0) : 0;

  // Enforce overpayment protection on initial payment
  if (initialCash > params.totalAmount) {
    throw new Error(
      `Initial cash payment (AFN ${initialCash}) cannot exceed the invoice total (AFN ${params.totalAmount}).`
    );
  }

  if (initialCash >= params.totalAmount && params.totalAmount > 0) {
    status = 'Paid';
  } else if (initialCash > 0) {
    status = 'Partially Paid';
  }

  // Backend verification: Inactive or Blocked customers cannot receive new invoices
  if (params.customerId) {
    const custRef = doc(db, 'customers', params.customerId);
    const custSnap = await getDoc(custRef);
    if (custSnap.exists()) {
      const custData = custSnap.data() as Customer;
      const custNormStatus = normalizeCustomerStatus(custData.status, custData.isArchived);
      if (custNormStatus === 'Inactive') {
        throw new Error(
          `Cannot create invoice: Customer "${custData.name}" is Inactive. Please activate the customer before generating new invoices.`
        );
      }
      if (custNormStatus === 'Blocked') {
        throw new Error(
          `Cannot create invoice: Customer "${custData.name}" is Blocked. Only Super Admin can unblock this customer.`
        );
      }
    }
  }

  await runTransaction(db, async (transaction) => {
    const settingsDoc = await transaction.get(settingsRef);
    let nextNum = 1060;
    let prefix = 'ST-';

    if (settingsDoc.exists()) {
      const data = settingsDoc.data();
      nextNum = Number(data.nextInvoiceNumber) || 1060;
      prefix = data.invoicePrefix || 'ST-';
    }

    generatedBillNumber = `${prefix}${nextNum}`;

    // Increment counter in settings atomically
    transaction.set(
      settingsRef,
      { nextInvoiceNumber: nextNum + 1 },
      { merge: true }
    );

    const isLocked = status === 'Paid';
    const remaining = Math.max(0, params.totalAmount - initialCash);

    const invoiceData: Invoice = {
      id: newInvoiceRef.id,
      billNumber: generatedBillNumber,
      customerId: params.customerId,
      customerSnapshot: params.customerSnapshot,
      companySnapshot: params.companySnapshot,
      date: params.date,
      items: params.items,
      totalAmount: params.totalAmount,
      totalPaid: initialCash,
      remaining,
      isLocked,
      ...(isLocked ? { lockedAt: now } : {}),
      note: params.note || '',
      createdBy: params.userId || 'system',
      createdByName: params.userName || 'Super Admin',
      createdAt: now,
      updatedAt: now,
      status,
      billingState,
      ...(params.templateId ? { templateId: params.templateId } : {}),
      ...(params.requestId ? { requestId: params.requestId } : {}),
      ...(isPayable && params.assignedCollectorId
        ? {
            assignedCollectorId: params.assignedCollectorId,
            assignedCollectorName: params.assignedCollectorName || '',
            assignedAt: now,
            assignedBy: params.userId || '',
            assignedByName: params.userName || 'Staff',
            assignmentHistory: [
              {
                collectorId: params.assignedCollectorId,
                collectorName: params.assignedCollectorName || 'Collector',
                assignedBy: params.userId || '',
                assignedByName: params.userName || 'Staff',
                assignedAt: now,
              },
            ],
          }
        : {}),
    };

    transaction.set(newInvoiceRef, cleanDataForFirestore(invoiceData));

    // If initial cash payment was provided, create separate payment transaction
    if (initialCash > 0) {
      const newPaymentRef = doc(paymentsColl);
      const paymentData: Payment = {
        id: newPaymentRef.id,
        invoiceId: newInvoiceRef.id,
        billNumber: generatedBillNumber,
        customerId: params.customerId,
        customerName: params.customerSnapshot.name || '',
        amount: initialCash,
        date: params.date,
        time: new Date().toLocaleTimeString('en-US', { hour12: false }),
        note: params.paymentNote?.trim() || 'Initial cash received upon billing',
        method: 'CASH',
        recordedBy: params.userId || 'system',
        recordedByName: params.userName || 'Super Admin',
        createdAt: now,
      };
      transaction.set(newPaymentRef, cleanDataForFirestore(paymentData));
    }
  });

  // Record audit log
  await addAuditLog({
    action: 'create_invoice',
    userId: params.userId || 'system',
    userName: params.userName || 'User',
    entityType: 'invoice',
    entityId: newInvoiceRef.id,
    referenceNumber: generatedBillNumber,
    summary: `Created Invoice ${generatedBillNumber} for ${params.customerSnapshot.name} (AFN ${params.totalAmount.toLocaleString('en-US')})`,
  });

  // Generate real system notification for invoice creation
  try {
    await createNotification({
      target: 'staff',
      title: `Invoice Created: ${generatedBillNumber}`,
      message: `Invoice ${generatedBillNumber} created for ${params.customerSnapshot.name} (AFN ${params.totalAmount.toLocaleString('en-US')}).`,
      type: 'invoice',
      linkId: newInvoiceRef.id,
      entityId: newInvoiceRef.id,
      entityType: 'invoice',
    });

    if (params.customerId) {
      await createNotification({
        target: params.customerId,
        customerId: params.customerId,
        title: `New Invoice #${generatedBillNumber}`,
        message: `A new invoice ${generatedBillNumber} for AFN ${params.totalAmount.toLocaleString('en-US')} has been generated for your account.`,
        type: 'invoice',
        linkId: newInvoiceRef.id,
        entityId: newInvoiceRef.id,
        entityType: 'invoice',
      });
    }
  } catch (notifErr) {
    console.warn('Could not dispatch invoice creation notification:', notifErr);
  }

  // If created from request, update the request status
  if (params.requestId) {
    await updateCustomerRequestStatus(
      params.requestId,
      'Invoice Created',
      newInvoiceRef.id,
      generatedBillNumber
    );
  }

  return {
    id: newInvoiceRef.id,
    billNumber: generatedBillNumber,
    customerId: params.customerId,
    customerSnapshot: params.customerSnapshot,
    companySnapshot: params.companySnapshot,
    date: params.date,
    items: params.items,
    totalAmount: params.totalAmount,
    totalPaid: initialCash,
    remaining: Math.max(0, params.totalAmount - initialCash),
    isLocked: status === 'Paid',
    note: params.note || '',
    createdAt: now,
    updatedAt: now,
    status,
    ...(params.requestId ? { requestId: params.requestId } : {}),
  };
}

// Update existing Invoice with financial consistency check and audit log
export async function updateInvoice(
  invoiceId: string,
  params: {
    customerId: string;
    customerSnapshot: CustomerSnapshot;
    date: string;
    items: InvoiceItem[];
    totalAmount: number;
    note: string;
    templateId?: string;
  },
  existingPaymentsTotal: number,
  userId: string = 'system',
  userName: string = 'User',
  previousInvoice?: Invoice
): Promise<void> {
  const invRef = doc(db, 'invoices', invoiceId);
  const invSnap = await getDoc(invRef);
  if (!invSnap.exists()) {
    throw new Error(`Invoice #${invoiceId} not found.`);
  }
  const dbInvoice = invSnap.data() as Partial<Invoice>;

  // STALE DATA PROTECTION & BACKEND ENFORCEMENT:
  // 1. Check if invoice is marked locked in database or in previous state
  if (dbInvoice.isLocked || previousInvoice?.isLocked) {
    throw new Error(
      'This invoice is locked because it is fully paid. Locked invoices cannot be modified.'
    );
  }

  // 2. Fetch and recalculate actual total paid from existing non-void payment records
  const invPaymentsQuery = query(
    collection(db, 'payments'),
    where('invoiceId', '==', invoiceId)
  );
  const paymentsSnap = await getDocs(invPaymentsQuery);
  let liveTotalPaid = 0;
  paymentsSnap.forEach((pDoc) => {
    const pData = pDoc.data();
    if (!pData.isVoid) {
      liveTotalPaid += Number(pData.amount) || 0;
    }
  });

  const actualPaymentsTotal = Math.max(
    liveTotalPaid,
    Number(dbInvoice.totalPaid) || 0,
    Number(existingPaymentsTotal) || 0
  );
  const currentInvoiceTotal = Number(dbInvoice.totalAmount) || 0;

  // 3a. If the invoice is void, reject the update
  if (dbInvoice.isVoid === true || dbInvoice.status === 'Void') {
    throw new Error(
      'This invoice is void. Void invoices cannot be modified.'
    );
  }

  // 3b. If the invoice is rejected, reject the update
  if (dbInvoice.billingState === 'rejected') {
    throw new Error(
      'Cannot edit a rejected quotation. It must first be marked as payable.'
    );
  }

  // 3c. If the invoice is fully paid or remaining balance <= 0, reject the update
  const isFullyPaid =
    dbInvoice.status === 'Paid' ||
    (currentInvoiceTotal > 0 && actualPaymentsTotal >= currentInvoiceTotal);

  if (isFullyPaid) {
    // Sync lock status in database if not yet marked
    if (!dbInvoice.isLocked) {
      try {
        await updateDoc(invRef, {
          isLocked: true,
          status: 'Paid',
          lockedAt: new Date().toISOString(),
        });
      } catch (err) {
        console.warn('Could not sync lock status on fully paid invoice:', err);
      }
    }
    throw new Error(
      'This invoice is locked because it is fully paid. Locked invoices cannot be modified.'
    );
  }

  // 4. Financial integrity check: Cannot reduce invoice total below what was already paid
  if (actualPaymentsTotal > 0 && params.totalAmount < actualPaymentsTotal) {
    throw new Error(
      `Cannot update invoice: The new total amount (AFN ${params.totalAmount.toLocaleString('en-US')}) cannot be less than the payments already collected (AFN ${actualPaymentsTotal.toLocaleString('en-US')}).`
    );
  }

  const now = new Date().toISOString();

  let status: InvoiceStatus = 'Unpaid';
  if (actualPaymentsTotal >= params.totalAmount && params.totalAmount > 0) {
    status = 'Paid';
  } else if (actualPaymentsTotal > 0) {
    status = 'Partially Paid';
  }

  const remaining = Math.max(0, params.totalAmount - actualPaymentsTotal);
  const isLocked = status === 'Paid';

  await updateDoc(
    invRef,
    cleanDataForFirestore({
      customerId: params.customerId,
      customerSnapshot: params.customerSnapshot,
      date: params.date,
      items: params.items,
      totalAmount: params.totalAmount,
      totalPaid: actualPaymentsTotal,
      remaining,
      isLocked,
      ...(isLocked ? { lockedAt: now } : {}),
      note: params.note || '',
      status,
      ...(params.templateId ? { templateId: params.templateId } : {}),
      updatedAt: now,
      updatedBy: userId,
      updatedByName: userName,
    })
  );

  // Track field changes for audit log
  const changes: AuditLogChange[] = [];
  if (previousInvoice) {
    if (previousInvoice.totalAmount !== params.totalAmount) {
      changes.push({
        field: 'totalAmount',
        oldValue: previousInvoice.totalAmount,
        newValue: params.totalAmount,
      });
    }
    if (previousInvoice.date !== params.date) {
      changes.push({
        field: 'date',
        oldValue: previousInvoice.date,
        newValue: params.date,
      });
    }
  }

  await addAuditLog({
    action: 'edit_invoice',
    userId,
    userName,
    entityType: 'invoice',
    entityId: invoiceId,
    referenceNumber: previousInvoice?.billNumber || invoiceId,
    summary: `Edited invoice ${previousInvoice?.billNumber || invoiceId}: New total AFN ${params.totalAmount.toLocaleString('en-US')}`,
    changes,
  });
}

// Void/Cancel Invoice (Non-destructive financial cancellation)
export async function voidInvoice(
  invoiceId: string,
  reason: string,
  userId: string = 'system',
  userName: string = 'Admin'
): Promise<void> {
  const invRef = doc(db, 'invoices', invoiceId);
  const now = new Date().toISOString();

  await updateDoc(invRef, {
    status: 'Void',
    isVoid: true,
    voidReason: reason.trim(),
    voidedAt: now,
    voidedBy: userName,
    updatedAt: now,
  });

  await addAuditLog({
    action: 'void_invoice',
    userId,
    userName,
    entityType: 'invoice',
    entityId: invoiceId,
    summary: `Voided invoice: ${reason}`,
  });
}

// ================= INVOICE BILLING STATE WORKFLOW =================

/**
 * Updates an invoice's billing state (quotation -> payable or quotation -> rejected).
 * Authorized actors:
 * - Customer: Can Accept or Reject quotations issued to their account.
 * - Invoice Manager & Super Admin: Can Mark as Payable or Mark as Rejected.
 * Records the actor, role/source, and timestamp for audit and integrity.
 */
export async function updateInvoiceBillingState(params: {
  invoiceId: string;
  newState: 'payable' | 'rejected';
  actorId: string;
  actorName: string;
  actorRole: UserRole | 'customer';
  source: 'customer' | 'admin' | string;
}): Promise<void> {
  const { invoiceId, newState, actorId, actorName, actorRole, source } = params;
  if (!invoiceId) throw new Error('Invoice ID is required.');
  if (newState !== 'payable' && newState !== 'rejected') {
    throw new Error('Invalid billing state transition. Allowed states: payable, rejected.');
  }

  // 1. Role validation
  const isAuthorizedRole =
    actorRole === 'super_admin' ||
    actorRole === 'invoice_manager' ||
    actorRole === 'customer';

  if (!isAuthorizedRole) {
    throw new Error('Access Denied: Only Super Admin, Invoice Manager, or Customer can change billing state.');
  }

  const invRef = doc(db, 'invoices', invoiceId);
  const invSnap = await getDoc(invRef);
  if (!invSnap.exists()) {
    throw new Error('Invoice not found.');
  }

  const invData = invSnap.data() as Invoice;

  // 2. Void protection
  if (invData.isVoid === true || invData.status === 'Void') {
    throw new Error('Cannot change billing state of a void invoice.');
  }

  // 3. Customer ownership validation
  if (actorRole === 'customer') {
    if (invData.customerId !== actorId && invData.customerSnapshot?.id !== actorId) {
      throw new Error('Access Denied: You can only approve or reject quotations issued to your account.');
    }
    const currentState = invData.billingState || 'quotation';
    if (currentState !== 'quotation') {
      throw new Error(`Quotation is already in "${currentState}" state and cannot be modified.`);
    }
  }

  // 4. Financial protection: Invoices with collected payments cannot be rejected
  if (newState === 'rejected') {
    const paymentsQuery = query(collection(db, 'payments'), where('invoiceId', '==', invoiceId));
    const paySnap = await getDocs(paymentsQuery);
    let totalPaid = 0;
    paySnap.forEach((pDoc) => {
      const p = pDoc.data();
      if (!p.isVoid) totalPaid += Number(p.amount) || 0;
    });
    if (totalPaid > 0 || (Number(invData.totalPaid) || 0) > 0) {
      throw new Error('Cannot reject an invoice with recorded payments. Use the Void mechanism instead.');
    }
  }

  const now = new Date().toISOString();
  const isCustomer = actorRole === 'customer';

  const updatePayload: Record<string, any> = {
    billingState: newState,
    updatedAt: now,
  };

  if (newState === 'payable') {
    updatePayload.acceptedAt = now;
    updatePayload.acceptedBy = isCustomer ? 'customer' : actorName;
    updatePayload.acceptanceSource = isCustomer ? 'customer' : (source || 'Admin Panel');
    if (!isCustomer) {
      updatePayload.changedBy = actorName;
      updatePayload.changedByRole = actorRole === 'super_admin' ? 'Super Admin' : 'Invoice Manager';
      updatePayload.changedAt = now;
      updatePayload.changeSource = source || 'Admin Panel';
    }
  } else if (newState === 'rejected') {
    updatePayload.rejectedAt = now;
    updatePayload.rejectedBy = isCustomer ? 'customer' : actorName;
    updatePayload.rejectionSource = isCustomer ? 'customer' : (source || 'Admin Panel');
    if (!isCustomer) {
      updatePayload.changedBy = actorName;
      updatePayload.changedByRole = actorRole === 'super_admin' ? 'Super Admin' : 'Invoice Manager';
      updatePayload.changedAt = now;
      updatePayload.changeSource = source || 'Admin Panel';
    }
  }

  await updateDoc(invRef, updatePayload);

  // 5. Audit log
  await addAuditLog({
    action: newState === 'payable' ? 'accept_quotation' : 'reject_quotation',
    userId: actorId,
    userName: actorName,
    entityType: 'invoice',
    entityId: invoiceId,
    referenceNumber: invData.billNumber,
    summary: `${isCustomer ? 'Customer' : (actorRole === 'super_admin' ? 'Super Admin' : 'Invoice Manager')} ${newState === 'payable' ? 'accepted quotation / marked as payable' : 'rejected quotation'} for ${invData.billNumber} (AFN ${Number(invData.totalAmount || 0).toLocaleString('en-US')}). Source: ${source || (isCustomer ? 'Customer Portal' : 'Admin Panel')}`,
  });

  // 6. Notification
  try {
    if (isCustomer) {
      await createNotification({
        target: 'staff',
        title: newState === 'payable' ? `Quotation Accepted: ${invData.billNumber}` : `Quotation Rejected: ${invData.billNumber}`,
        message: `Customer ${actorName} ${newState === 'payable' ? 'accepted' : 'rejected'} quotation ${invData.billNumber}.`,
        type: 'invoice',
        linkId: invoiceId,
        entityId: invoiceId,
        entityType: 'invoice',
      });
    } else {
      await createNotification({
        target: 'customer',
        customerId: invData.customerId,
        title: newState === 'payable' ? `Quotation Approved: ${invData.billNumber}` : `Quotation Rejected: ${invData.billNumber}`,
        message: `Your quotation ${invData.billNumber} has been ${newState === 'payable' ? 'marked as payable' : 'marked as rejected'}.`,
        type: 'invoice',
        linkId: invoiceId,
        entityId: invoiceId,
        entityType: 'invoice',
      });
    }
  } catch (notifErr) {
    console.warn('Could not create notification for billing state change:', notifErr);
  }
}

/**
 * Permanently deletes a quotation or rejected invoice.
 * Authorized roles:
 * - Invoice Manager: YES
 * - Super Admin: YES
 * - Customers and others: NO
 * Confirmed financial invoices (payable, paid, partially paid) are protected from deletion.
 */
export async function deleteInvoicePermanently(params: {
  invoiceId: string;
  userId: string;
  userName: string;
  userRole: UserRole;
}): Promise<void> {
  const { invoiceId, userId, userName, userRole } = params;
  if (!invoiceId) throw new Error('Invoice ID is required for deletion.');

  // 1. Role validation
  if (userRole !== 'super_admin' && userRole !== 'invoice_manager') {
    throw new Error('Access Denied: Only Super Admin and Invoice Manager can permanently delete invoices.');
  }

  const invRef = doc(db, 'invoices', invoiceId);
  const invSnap = await getDoc(invRef);
  if (!invSnap.exists()) {
    throw new Error('Invoice not found.');
  }

  const invData = invSnap.data() as Invoice;

  // 2. Financial protection: Confirmed financial invoices cannot be deleted
  const billingState = invData.billingState || 'payable';
  if (billingState === 'payable') {
    throw new Error(
      'Confirmed financial invoices (payable, unpaid, partially paid, paid) cannot be deleted. Use the Void mechanism to cancel confirmed billing.'
    );
  }

  if (invData.status === 'Paid' || invData.status === 'Partially Paid' || (Number(invData.totalPaid) || 0) > 0) {
    throw new Error(
      'Invoices with financial activity cannot be deleted. Use the Void mechanism instead.'
    );
  }

  // 3. Ensure no payments are linked
  const payQuery = query(collection(db, 'payments'), where('invoiceId', '==', invoiceId));
  const paySnap = await getDocs(payQuery);
  if (!paySnap.empty) {
    throw new Error(
      'Cannot delete invoice with existing payment records. Use the Void mechanism instead.'
    );
  }

  // 4. Delete document
  await deleteDoc(invRef);

  // 5. Audit log
  await addAuditLog({
    action: 'delete_invoice',
    userId,
    userName,
    entityType: 'invoice',
    entityId: invoiceId,
    referenceNumber: invData.billNumber,
    summary: `Permanently deleted ${invData.billingState || 'quotation'} invoice ${invData.billNumber || invoiceId} for ${invData.customerSnapshot?.name || 'Customer'}.`,
  });
}

// ================= PAYMENTS =================
export function subscribeToPayments(
  onUpdate: (payments: Payment[]) => void,
  onError?: (err: Error) => void
) {
  const q = query(collection(db, 'payments'), orderBy('createdAt', 'desc'));
  return onSnapshot(
    q,
    (snapshot) => {
      const payments: Payment[] = [];
      snapshot.forEach((docSnap) => {
        payments.push({ id: docSnap.id, ...docSnap.data() } as Payment);
      });
      onUpdate(payments);
    },
    (err) => {
      console.warn('Payments listener error:', err);
      if (onError) onError(err);
    }
  );
}

// Add Cash Payment with strict Overpayment Protection, Date Rule, Extensible Method, and Atomic Commit
export async function addCashPayment(params: {
  invoiceId: string;
  billNumber?: string;
  customerId?: string;
  customerName?: string;
  amount: number;
  date?: string;
  note?: string;
  method?: PaymentMethod;
  isCorrection?: boolean;
  correctionRefId?: string;
  userId?: string;
  userName?: string;
  userRole?: string;
}): Promise<string> {
  // 1. Role Verification: Customers can never record payments
  const userRole = (params.userRole || '').toLowerCase().trim();
  if (userRole === 'customer') {
    throw new Error('Access Denied: Customers are not permitted to record payments.');
  }

  // 2. Validate Payment Amount (Reject zero/negative)
  const paymentAmount = Number(params.amount);
  if (isNaN(paymentAmount) || paymentAmount <= 0) {
    throw new Error('Payment amount must be greater than zero.');
  }

  // 3. Payment Date Rule (Payment Date <= Today; reject future dates at service layer)
  const dateValidation = validatePaymentDate(params.date);
  if (!dateValidation.isValid) {
    throw new Error(dateValidation.error || 'Payment date cannot be in the future.');
  }
  const validPaymentDate = dateValidation.normalizedDate;

  // 4. Payment Method Architecture (Cash is only active method; extensible for future)
  const methodValidation = validatePaymentMethod(params.method);
  if (!methodValidation.isValid) {
    throw new Error(methodValidation.error || 'Only Cash payments are currently accepted.');
  }
  const paymentMethod = methodValidation.method;

  // 5. Payment Note: Genuinely optional (no artificial/default notes stored)
  const sanitizedNote = sanitizePaymentNote(params.note);

  // 6. Recalculate authoritative Paid Amount from DB, excluding voided payments
  const invPaymentsQuery = query(
    collection(db, 'payments'),
    where('invoiceId', '==', params.invoiceId)
  );
  const paymentsSnap = await getDocs(invPaymentsQuery);
  let currentTotalPaid = 0;
  paymentsSnap.forEach((pDoc) => {
    const data = pDoc.data();
    if (!data.isVoid) {
      currentTotalPaid += Number(data.amount) || 0;
    }
  });

  const invDocRef = doc(db, 'invoices', params.invoiceId);
  const paymentsColl = collection(db, 'payments');
  const newPaymentRef = doc(paymentsColl);
  const auditColl = collection(db, 'auditLogs');
  const newAuditRef = doc(auditColl);
  const fullyPaidAuditRef = doc(auditColl);

  const now = new Date().toISOString();
  const paymentTime = new Date().toLocaleTimeString('en-US', { hour12: false });

  let finalBillNumber = '';
  let finalCustomerId = '';
  let finalCustomerName = '';
  let newTotalPaid = 0;
  let newRemaining = 0;
  let status: InvoiceStatus = 'Partially Paid';

  // ATOMIC FINANCIAL OPERATION:
  // Payment creation, Invoice financial update, and Audit Log are committed atomically.
  // If ANY step fails, the entire transaction is rolled back.
  await runTransaction(db, async (transaction) => {
    // 7. Verify the Invoice inside transaction
    const invSnap = await transaction.get(invDocRef);
    if (!invSnap.exists()) {
      throw new Error('Associated invoice was not found.');
    }

    const invoiceData = invSnap.data() as Invoice;
    if (invoiceData.isVoid || invoiceData.status === 'Void') {
      throw new Error('Cannot accept payment on a voided invoice.');
    }
    if (invoiceData.billingState === 'quotation') {
      throw new Error(
        'Cannot accept payment on a quotation. The quotation must first be accepted / marked as payable.'
      );
    }
    if (invoiceData.billingState === 'rejected') {
      throw new Error('Cannot accept payment on a rejected quotation.');
    }

    // 8. Collector Scope Enforcement: Only invoices assigned to this collector
    if (userRole === 'payment_collector') {
      const collectorId = params.userId || '';
      const collectorName = (params.userName || '').toLowerCase().trim();
      const matchId = invoiceData.assignedCollectorId === collectorId;
      const matchName =
        invoiceData.assignedCollectorName &&
        invoiceData.assignedCollectorName.toLowerCase().trim() === collectorName;

      if (!matchId && !matchName) {
        throw new Error(
          'Access Denied: You are only authorized to record payments for invoices assigned to you.'
        );
      }
    }

    finalBillNumber = params.billNumber || invoiceData.billNumber || '';
    finalCustomerId = params.customerId || invoiceData.customerId || '';
    finalCustomerName =
      params.customerName || invoiceData.customerSnapshot?.name || '';

    // 9. Calculate Remaining Balance from authoritative figures
    const invoiceTotal = Number(invoiceData.totalAmount) || 0;
    const remainingBalance = Math.max(0, invoiceTotal - currentTotalPaid);

    if (remainingBalance <= 0) {
      throw new Error(
        `This invoice is already fully paid (Remaining Balance: AFN 0). No further payments can be accepted.`
      );
    }

    // 10. Reject Overpayment
    if (paymentAmount > remainingBalance) {
      throw new Error(
        `Payment amount of AFN ${paymentAmount.toLocaleString('en-US')} exceeds the remaining balance of AFN ${remainingBalance.toLocaleString('en-US')}. Overpayment is strictly prevented.`
      );
    }

    // 11. Create Payment Record (structured method, clean note)
    const paymentData: Payment = {
      id: newPaymentRef.id,
      invoiceId: params.invoiceId,
      billNumber: finalBillNumber,
      customerId: finalCustomerId,
      customerName: finalCustomerName,
      amount: paymentAmount,
      date: validPaymentDate,
      time: paymentTime,
      note: sanitizedNote,
      method: paymentMethod,
      recordedBy: params.userId || 'system',
      recordedByName: params.userName || 'Staff',
      createdAt: now,
      ...(params.isCorrection ? { isCorrection: true } : {}),
      ...(params.correctionRefId && params.correctionRefId.trim()
        ? { correctionRefId: params.correctionRefId.trim() }
        : {}),
    };
    transaction.set(newPaymentRef, cleanDataForFirestore(paymentData));

    // 12. Update Invoice Financial State & Status
    newTotalPaid = currentTotalPaid + paymentAmount;
    newRemaining = Math.max(0, invoiceTotal - newTotalPaid);
    status = 'Partially Paid';
    let isLocked = false;
    if (newTotalPaid >= invoiceTotal) {
      status = 'Paid';
      isLocked = true;
    }

    transaction.update(
      invDocRef,
      cleanDataForFirestore({
        status,
        totalPaid: newTotalPaid,
        remaining: newRemaining,
        isLocked,
        ...(isLocked ? { lockedAt: now } : {}),
        updatedAt: now,
      })
    );

    // 13. Create related Audit Log inside the atomic transaction
    const methodDisplay = PAYMENT_METHOD_LABELS[paymentMethod] || paymentMethod;
    const auditData: AuditLog = {
      id: newAuditRef.id,
      dateTime: now,
      action: 'record_payment',
      userId: params.userId || 'system',
      userName: params.userName || 'Staff',
      userRole: params.userRole,
      entityType: 'payment',
      entityId: newPaymentRef.id,
      referenceNumber: finalBillNumber,
      summary: `Recorded ${methodDisplay.toLowerCase()} payment of AFN ${paymentAmount.toLocaleString('en-US')} on invoice ${finalBillNumber} (Customer: ${finalCustomerName}, Remaining: AFN ${newRemaining.toLocaleString('en-US')})`,
    };
    transaction.set(newAuditRef, cleanDataForFirestore(auditData));

    if (status === 'Paid') {
      const fullyPaidAudit: AuditLog = {
        id: fullyPaidAuditRef.id,
        dateTime: now,
        action: 'edit_invoice',
        userId: params.userId || 'system',
        userName: params.userName || 'Staff',
        userRole: params.userRole,
        entityType: 'invoice',
        entityId: params.invoiceId,
        referenceNumber: finalBillNumber,
        summary: `Invoice ${finalBillNumber} became Fully Paid (Total: AFN ${invoiceTotal.toLocaleString('en-US')})`,
      };
      transaction.set(fullyPaidAuditRef, cleanDataForFirestore(fullyPaidAudit));
    }
  });

  // Post-transaction notifications (non-blocking)
  try {
    await createNotification({
      target: 'staff',
      title: `Payment Recorded: ${finalBillNumber}`,
      message: `Recorded AFN ${paymentAmount.toLocaleString('en-US')} cash payment from ${finalCustomerName} on invoice ${finalBillNumber}. Remaining balance: AFN ${newRemaining.toLocaleString('en-US')}.`,
      type: 'payment',
      linkId: newPaymentRef.id,
      entityId: newPaymentRef.id,
      entityType: 'payment',
    });

    if (finalCustomerId) {
      await createNotification({
        target: finalCustomerId,
        customerId: finalCustomerId,
        title: `Payment Received: ${finalBillNumber}`,
        message: `Your cash payment of AFN ${paymentAmount.toLocaleString('en-US')} on invoice ${finalBillNumber} has been recorded. Remaining balance: AFN ${newRemaining.toLocaleString('en-US')}.`,
        type: 'payment',
        linkId: newPaymentRef.id,
        entityId: newPaymentRef.id,
        entityType: 'payment',
      });
    }
  } catch (notifErr) {
    console.warn('Could not dispatch payment notification:', notifErr);
  }

  return newPaymentRef.id;
}

// Extensible alias for recording payments
export const addPayment = addCashPayment;

export async function getPaymentById(paymentId: string): Promise<Payment | null> {
  const snap = await getDoc(doc(db, 'payments', paymentId));
  if (!snap.exists()) return null;
  return { id: snap.id, ...(snap.data() as any) } as Payment;
}

// Assign Collector to Invoice with history tracking, validation, and notification
export async function assignCollectorToInvoice(
  invoiceId: string,
  collectorId: string,
  collectorName: string,
  assignedBy: string,
  assignedByName: string,
  previousCollectorId?: string,
  previousCollectorName?: string,
  existingHistory: AssignmentHistoryEntry[] = []
): Promise<void> {
  if (!invoiceId) {
    throw new Error('Invoice ID is required for collector assignment.');
  }
  if (!collectorId || !collectorName) {
    throw new Error('Please select an eligible Invoice Collector.');
  }

  // Authoritative validation against latest Firestore invoice document
  const invRef = doc(db, 'invoices', invoiceId);
  const invSnap = await getDoc(invRef);
  if (!invSnap.exists()) {
    throw new Error('Invoice not found.');
  }

  const invData = invSnap.data() as Invoice;

  // 1. VOID VALIDATION: Void invoices cannot receive collector assignments
  if (invData.isVoid === true || invData.status === 'Void') {
    throw new Error('Cannot assign or reassign a collector to a voided invoice.');
  }

  // 1b. QUOTATION / REJECTED VALIDATION: Quotations and rejected invoices cannot have collectors assigned
  if (invData.billingState === 'quotation') {
    throw new Error('Cannot assign a collector to a quotation. Quotations must first be accepted / marked as payable.');
  }
  if (invData.billingState === 'rejected') {
    throw new Error('Cannot assign a collector to a rejected invoice.');
  }

  // 2. LOCKED VALIDATION: Locked or fully paid invoices cannot have a collector assigned or reassigned
  if (invData.isLocked === true || isInvoiceLocked(invData)) {
    throw new Error('Cannot assign or reassign a collector because this invoice is locked.');
  }

  // 3. DUPLICATE CHECK: Prevent duplicate assignment to the already assigned collector
  const currentAssignedCollectorId = invData.assignedCollectorId || previousCollectorId;
  if (currentAssignedCollectorId && currentAssignedCollectorId === collectorId) {
    throw new Error(`Collector "${collectorName}" is already assigned to this invoice.`);
  }

  // 4. Verify collector validity from Firestore
  try {
    const userDoc = await getDoc(doc(db, 'users', collectorId));
    if (userDoc.exists()) {
      const userData = userDoc.data();
      if (userData.status && userData.status !== 'active') {
        throw new Error(
          `Cannot assign: Staff account "${userData.name || collectorName}" is currently ${userData.status}. Only active staff may be assigned.`
        );
      }
      if (userData.role && userData.role !== 'payment_collector') {
        throw new Error(
          `Cannot assign: Staff account "${userData.name || collectorName}" is not an authorized Invoice Collector.`
        );
      }
    }
  } catch (err: any) {
    if (err?.message && err.message.startsWith('Cannot assign:')) {
      throw err;
    }
    // Network/offline fallback: proceed with provided parameters
  }

  const now = new Date().toISOString();
  const billNumber = invData.billNumber || invoiceId;
  const currentHistory = Array.isArray(invData.assignmentHistory) && invData.assignmentHistory.length > 0
    ? invData.assignmentHistory
    : existingHistory;

  const effectivePreviousId = invData.assignedCollectorId || previousCollectorId;
  const effectivePreviousName = invData.assignedCollectorName || previousCollectorName;

  const entry: AssignmentHistoryEntry = {
    collectorId,
    collectorName,
    assignedBy,
    assignedByName,
    assignedAt: now,
    ...(effectivePreviousId ? { previousCollectorId: effectivePreviousId } : {}),
    ...(effectivePreviousName ? { previousCollectorName: effectivePreviousName } : {}),
  };

  await updateDoc(
    invRef,
    cleanDataForFirestore({
      assignedCollectorId: collectorId,
      assignedCollectorName: collectorName,
      assignedBy,
      assignedByName,
      assignedAt: now,
      assignmentHistory: [...currentHistory, entry],
      updatedAt: now,
    })
  );

  const isReassignment = Boolean(effectivePreviousId && effectivePreviousId !== collectorId);
  await addAuditLog({
    action: 'edit_invoice',
    userId: assignedBy,
    userName: assignedByName,
    entityType: 'invoice',
    entityId: invoiceId,
    summary: isReassignment
      ? `Reassigned invoice #${billNumber} from ${effectivePreviousName || 'previous collector'} to ${collectorName}`
      : `Assigned collector ${collectorName} to invoice #${billNumber}`,
  });

  await createNotification({
    target: collectorId,
    title: isReassignment ? 'Invoice Reassigned To You' : 'New Invoice Assigned For Collection',
    message: `You have been assigned to collect payment for invoice #${billNumber}.`,
    type: 'invoice',
    linkId: invoiceId,
  });
}

// Super Admin manual lock / unlock toggle
export async function toggleInvoiceLock(
  invoiceId: string,
  isLocked: boolean,
  reason: string,
  userId: string,
  userName: string
): Promise<void> {
  const invRef = doc(db, 'invoices', invoiceId);
  const now = new Date().toISOString();
  await updateDoc(
    invRef,
    cleanDataForFirestore({
      isLocked,
      ...(isLocked ? { lockedAt: now } : { unlockedAt: now, unlockReason: reason }),
      updatedAt: now,
    })
  );

  await addAuditLog({
    action: 'edit_invoice',
    userId,
    userName,
    entityType: 'invoice',
    entityId: invoiceId,
    summary: `${isLocked ? 'Locked' : 'Unlocked'} invoice #${invoiceId}: ${reason}`,
  });
}

// Verify Super Admin Password credentials for sensitive financial mutations
export async function verifySuperAdminPassword(
  userId: string,
  password: string
): Promise<{ isValid: boolean; user?: UserProfile; error?: string }> {
  if (!userId || !password || !password.trim()) {
    return { isValid: false, error: 'User ID and password are required.' };
  }

  try {
    const userDocRef = doc(db, 'users', userId);
    let userSnap = await getDoc(userDocRef);
    if (!userSnap.exists()) {
      // Check if user exists by query in users collection with role super_admin
      const usersCol = collection(db, 'users');
      const q = query(usersCol, where('role', '==', 'super_admin'));
      const qSnap = await getDocs(q);
      const matched = qSnap.docs.find(
        (d) => d.id === userId || (d.data() as UserProfile).id === userId
      );
      if (matched) {
        userSnap = matched as any;
      }
    }

    if (!userSnap.exists()) {
      return { isValid: false, error: 'Access Denied: Super Admin account not found.' };
    }

    const userData = userSnap.data() as UserProfile;
    if (userData.role !== 'super_admin') {
      return { isValid: false, error: 'Access Denied: Only Super Admin is authorized to perform this operation.' };
    }

    if (!userData.passwordSalt || !userData.passwordHash) {
      return { isValid: false, error: 'Authentication error: Password credentials not configured for this account.' };
    }

    const isMatch = await verifyPassword(password, userData.passwordSalt, userData.passwordHash);
    if (!isMatch) {
      return { isValid: false, error: 'Authentication Failed: Incorrect Super Admin password.' };
    }

    return { isValid: true, user: userData };
  } catch (err: any) {
    console.error('Super Admin password verification error:', err);
    return { isValid: false, error: err.message || 'Password verification failed.' };
  }
}

// Strict Payment Correction with Reversal Entry & Replacement Payment (Super Admin Only, Atomic Transaction)
export async function correctPayment(params: {
  paymentId: string;
  invoiceId: string;
  reason: string;
  password?: string;
  correctedAmount?: number;
  correctedNote?: string;
  userId: string;
  userName: string;
  userRole?: string;
}): Promise<string | undefined> {
  // 1. Mandatory Reason validation
  if (!params.reason || !params.reason.trim()) {
    throw new Error('A valid, non-empty reason is required for payment reversal.');
  }

  // 2. Server-side Super Admin role enforcement
  if (params.userRole && params.userRole !== 'super_admin') {
    throw new Error('Access Denied: Only Super Admin is authorized to reverse or correct payments.');
  }

  // 3. Mandatory Super Admin Password Verification (Central reversal logic / service layer enforcement)
  if (!params.password || !params.password.trim()) {
    throw new Error('Super Admin password is required to reverse a payment.');
  }

  const verification = await verifySuperAdminPassword(params.userId, params.password);
  if (!verification.isValid) {
    throw new Error(verification.error || 'Authentication Failed: Incorrect Super Admin password.');
  }

  // 4. Atomic Reversal Transaction via runTransaction
  const now = new Date().toISOString();
  let createdReplacementPaymentId: string | undefined = undefined;

  await runTransaction(db, async (transaction) => {
    // Read original payment
    const payRef = doc(db, 'payments', params.paymentId);
    const paySnap = await transaction.get(payRef);
    if (!paySnap.exists()) {
      throw new Error('Payment record not found.');
    }

    const origData = paySnap.data() as Payment;
    if (origData.isVoid) {
      throw new Error('This payment has already been reversed.');
    }

    // 48-Hour Reversal Rule Enforcement (Backend/Service Layer)
    const reversalEligibility = checkPaymentReversalEligibility(origData);
    if (!reversalEligibility.isEligible) {
      throw new Error(
        reversalEligibility.reason ||
          'Payment reversal window expired: Payments can only be reversed within 48 hours of creation.'
      );
    }

    // Read linked invoice
    const targetInvoiceId = params.invoiceId || origData.invoiceId;
    const invRef = doc(db, 'invoices', targetInvoiceId);
    const invSnap = await transaction.get(invRef);
    if (!invSnap.exists()) {
      throw new Error('Linked invoice record not found.');
    }
    const invoiceData = invSnap.data() as Invoice;

    const reversedAmount = Number(origData.amount) || 0;
    const replacementAmount =
      params.correctedAmount !== undefined && params.correctedAmount > 0
        ? Number(params.correctedAmount)
        : 0;

    // Validate correction amount
    if (params.correctedAmount !== undefined && params.correctedAmount < 0) {
      throw new Error('Payment correction amount cannot be negative.');
    }

    // A. Mark original payment as void (preserving all historical information)
    transaction.update(
      payRef,
      cleanDataForFirestore({
        isVoid: true,
        voidReason: params.reason.trim(),
        correctedBy: params.userId,
        correctedByName: params.userName,
        correctedAt: now,
      })
    );

    // B. If replacement amount provided, create replacement payment record atomically
    if (replacementAmount > 0) {
      const paymentsColl = collection(db, 'payments');
      const newPayRef = doc(paymentsColl);
      createdReplacementPaymentId = newPayRef.id;

      const replacementPayment: Payment = {
        id: newPayRef.id,
        invoiceId: targetInvoiceId,
        billNumber: origData.billNumber || invoiceData.billNumber || '',
        customerId: origData.customerId || invoiceData.customerId || '',
        customerName: origData.customerName || invoiceData.customerSnapshot?.name || '',
        amount: replacementAmount,
        date: origData.date || now.split('T')[0],
        time: new Date().toLocaleTimeString('en-US', { hour12: false }),
        note:
          params.correctedNote?.trim() ||
          `Correction for Payment #${params.paymentId}: ${params.reason.trim()}`,
        method: 'CASH',
        recordedBy: params.userId,
        recordedByName: params.userName,
        createdAt: now,
        isCorrection: true,
        correctionRefId: params.paymentId,
        correctionReason: params.reason.trim(),
      };
      transaction.set(newPayRef, cleanDataForFirestore(replacementPayment));
    }

    // C. Calculate updated Invoice financials atomically
    const currentTotalPaid = Number(invoiceData.totalPaid) || 0;
    const invTotal = Number(invoiceData.totalAmount) || 0;
    const newTotalPaid = Math.max(0, currentTotalPaid - reversedAmount + replacementAmount);
    const newRemaining = Math.max(0, invTotal - newTotalPaid);

    let newStatus: InvoiceStatus = 'Unpaid';
    let isLocked = false;
    if (newTotalPaid >= invTotal && invTotal > 0) {
      newStatus = 'Paid';
      isLocked = true;
    } else if (newTotalPaid > 0) {
      newStatus = 'Partially Paid';
      isLocked = false;
    } else {
      newStatus = 'Unpaid';
      isLocked = false;
    }

    transaction.update(
      invRef,
      cleanDataForFirestore({
        status: newStatus,
        totalPaid: newTotalPaid,
        remaining: newRemaining,
        isLocked,
        updatedAt: now,
      })
    );

    // D. Create mandatory audit log atomically in the same transaction
    const auditColl = collection(db, 'auditLogs');
    const auditRef = doc(auditColl);
    const auditEntry: AuditLog = {
      id: auditRef.id,
      action: 'reverse_payment',
      userId: params.userId,
      userName: params.userName,
      entityType: 'payment',
      entityId: params.paymentId,
      referenceNumber: origData.billNumber || invoiceData.billNumber,
      dateTime: now,
      summary: `Reversed cash payment #${params.paymentId} (AFN ${reversedAmount.toLocaleString('en-US')}) on invoice ${origData.billNumber || invoiceData.billNumber}. Reason: ${params.reason.trim()}.${createdReplacementPaymentId ? ` Created replacement payment #${createdReplacementPaymentId} (AFN ${replacementAmount.toLocaleString('en-US')}).` : ''}`,
      changes: [
        {
          field: 'isVoid',
          oldValue: false,
          newValue: true,
        },
        {
          field: 'invoice.totalPaid',
          oldValue: currentTotalPaid,
          newValue: newTotalPaid,
        },
        {
          field: 'invoice.remaining',
          oldValue: invoiceData.remaining ?? Math.max(0, invTotal - currentTotalPaid),
          newValue: newRemaining,
        },
        {
          field: 'invoice.status',
          oldValue: invoiceData.status,
          newValue: newStatus,
        },
      ],
    };
    transaction.set(auditRef, cleanDataForFirestore(auditEntry));
  });

  return createdReplacementPaymentId;
}

// Void or Reverse a Payment (Super Admin Only helper)
export async function voidPayment(
  paymentId: string,
  invoiceId: string,
  reason: string,
  password?: string,
  userId: string = 'system',
  userName: string = 'Super Admin'
): Promise<void> {
  await correctPayment({
    paymentId,
    invoiceId,
    reason,
    password,
    userId,
    userName,
    userRole: 'super_admin',
  });
}

// Server-side cursor-based pagination query for Payments History
export async function getPaginatedPaymentsFromServer(params: {
  pageSize?: number;
  lastDoc?: any;
  sortField?: PaymentSortField;
  sortDirection?: PaymentSortDirection;
  statusFilter?: PaymentStatusFilter;
}): Promise<{
  payments: Payment[];
  lastVisibleDoc: any;
  hasMore: boolean;
}> {
  const pageSize = params.pageSize || 25;
  const constraints: any[] = [];

  // Sorting
  const sortDirection = params.sortDirection || 'desc';
  const sortField =
    params.sortField === 'amount'
      ? 'amount'
      : params.sortField === 'customer'
      ? 'customerName'
      : 'date';

  constraints.push(orderBy(sortField, sortDirection));

  // Cursor pagination
  if (params.lastDoc) {
    constraints.push(startAfter(params.lastDoc));
  }

  // Retrieve 1 extra document to detect if there is a next page
  constraints.push(limit(pageSize + 1));

  const q = query(collection(db, 'payments'), ...constraints);
  const snap = await getDocs(q);

  const docs = snap.docs;
  const hasMore = docs.length > pageSize;
  const pageDocs = hasMore ? docs.slice(0, pageSize) : docs;
  const payments: Payment[] = pageDocs.map((d) => ({ id: d.id, ...d.data() } as Payment));
  const lastVisibleDoc = pageDocs.length > 0 ? pageDocs[pageDocs.length - 1] : null;

  return {
    payments,
    lastVisibleDoc,
    hasMore,
  };
}

// ================= EXPENSES =================
export function subscribeToExpenses(
  onUpdate: (expenses: Expense[]) => void,
  onError?: (err: Error) => void
) {
  const q = query(collection(db, 'expenses'), orderBy('date', 'desc'));
  return onSnapshot(
    q,
    (snapshot) => {
      const expenses: Expense[] = [];
      snapshot.forEach((docSnap) => {
        expenses.push({ id: docSnap.id, ...docSnap.data() } as Expense);
      });
      onUpdate(expenses);
    },
    (err) => {
      console.warn('Expenses listener error:', err);
      if (onError) onError(err);
    }
  );
}

export async function saveExpense(params: {
  id?: string;
  title: string;
  amount: number;
  date: string;
  category?: string;
  note?: string;
  requestedBy: string;
  requestedByName: string;
  requestedByRole: string;
  status?: ExpenseStatus;
}): Promise<string> {
  if (params.requestedByRole === 'customer') {
    throw new Error('Access Denied: Customers cannot create expenses.');
  }

  const now = new Date().toISOString();
  const initialStatus: ExpenseStatus = params.status || 'pending_manager';

  if (params.id) {
    const expRef = doc(db, 'expenses', params.id);
    await updateDoc(
      expRef,
      cleanDataForFirestore({
        title: params.title.trim(),
        amount: Number(params.amount) || 0,
        date: params.date,
        category: params.category || 'General',
        note: params.note?.trim() || '',
        updatedAt: now,
      })
    );
    return params.id;
  } else {
    const expRef = doc(collection(db, 'expenses'));
    const initialTimeline: ExpenseTimelineEntry = {
      action: 'Submitted Request',
      performedBy: params.requestedBy,
      performedByName: params.requestedByName,
      performedByRole: params.requestedByRole,
      timestamp: now,
      note: params.note || undefined,
    };
    const expenseData: Expense = {
      id: expRef.id,
      title: params.title.trim(),
      amount: Number(params.amount) || 0,
      date: params.date,
      category: params.category || 'General',
      note: params.note?.trim() || '',
      requestedBy: params.requestedBy,
      requestedByName: params.requestedByName,
      requestedByRole: params.requestedByRole,
      status: initialStatus,
      timeline: [initialTimeline],
      createdAt: now,
      updatedAt: now,
    };
    await setDoc(expRef, cleanDataForFirestore(expenseData));

    await addAuditLog({
      action: 'edit_customer',
      userId: params.requestedBy,
      userName: params.requestedByName,
      entityType: 'settings',
      entityId: expRef.id,
      summary: `Submitted expense request: "${params.title}" (AFN ${params.amount})`,
    });

    try {
      await createNotification({
        target: 'staff',
        title: `New Expense Submitted: ${params.title}`,
        message: `${params.requestedByName || 'Staff'} submitted expense "${params.title}" (AFN ${Number(params.amount).toLocaleString('en-US')}) for approval.`,
        type: 'expense',
        linkId: expRef.id,
        entityId: expRef.id,
        entityType: 'expense',
      });
    } catch (e) {
      console.warn('Could not dispatch expense creation notification:', e);
    }

    return expRef.id;
  }
}

export async function advanceExpenseWorkflow(params: {
  expenseId: string;
  action: 'manager_approve' | 'admin_approve' | 'admin_execute' | 'reject' | 'resubmit';
  userId: string;
  userName: string;
  userRole: string;
  reason?: string;
  corrections?: string;
  existingTimeline?: ExpenseTimelineEntry[];
}): Promise<void> {
  // Enforce Role-Based Permissions at data action layer
  if (params.userRole === 'customer') {
    throw new Error('Access Denied: Customers have no permissions on operating expenses.');
  }

  if (params.action === 'manager_approve') {
    if (params.userRole !== 'invoice_manager' && params.userRole !== 'super_admin') {
      throw new Error('Access Denied: Payment Collectors cannot approve expenses as Invoice Manager.');
    }
  } else if (params.action === 'admin_approve') {
    if (params.userRole !== 'super_admin') {
      throw new Error('Access Denied: Only Super Admin can approve expenses at the admin stage.');
    }
  } else if (params.action === 'admin_execute') {
    if (params.userRole !== 'super_admin') {
      throw new Error('Access Denied: Only Super Admin can execute and disburse expenses.');
    }
  } else if (params.action === 'reject') {
    if (params.userRole !== 'invoice_manager' && params.userRole !== 'super_admin') {
      throw new Error('Access Denied: Only Invoice Manager or Super Admin can reject expenses.');
    }
  }

  const expRef = doc(db, 'expenses', params.expenseId);
  const now = new Date().toISOString();
  let nextStatus: ExpenseStatus = 'pending_manager';
  const updates: Partial<Expense> = { updatedAt: now };

  let actionLabel = '';
  switch (params.action) {
    case 'manager_approve':
      nextStatus = 'pending_admin';
      actionLabel = 'Invoice Manager Approved';
      updates.managerApprovedBy = params.userId;
      updates.managerApprovedByName = params.userName;
      updates.managerApprovedAt = now;
      break;
    case 'admin_approve':
      nextStatus = 'approved';
      actionLabel = 'Super Admin Approved';
      updates.adminApprovedBy = params.userId;
      updates.adminApprovedByName = params.userName;
      updates.adminApprovedAt = now;
      break;
    case 'admin_execute':
      nextStatus = 'executed';
      actionLabel = 'Executed & Disbursed';
      updates.executionStatus = 'executed';
      updates.executedBy = params.userId;
      updates.executedByName = params.userName;
      updates.executedAt = now;
      break;
    case 'reject':
      nextStatus = 'rejected';
      actionLabel = `Rejected: ${params.reason || 'No reason specified'}`;
      updates.rejectionReason = params.reason || '';
      updates.rejectedBy = params.userId;
      updates.rejectedByName = params.userName;
      updates.rejectedAt = now;
      break;
    case 'resubmit':
      nextStatus = 'pending_manager';
      actionLabel = `Resubmitted with corrections: ${params.corrections || ''}`;
      updates.resubmissionReason = params.reason || '';
      updates.resubmissionCorrections = params.corrections || '';
      updates.resubmittedBy = params.userId;
      updates.resubmittedByName = params.userName;
      updates.resubmittedAt = now;
      break;
  }

  updates.status = nextStatus;
  const newTimelineEntry: ExpenseTimelineEntry = {
    action: actionLabel,
    performedBy: params.userId,
    performedByName: params.userName,
    performedByRole: params.userRole,
    timestamp: now,
    note: params.reason || params.corrections,
  };
  updates.timeline = [...(params.existingTimeline || []), newTimelineEntry];

  await updateDoc(expRef, cleanDataForFirestore(updates));

  // Generate notification for expense review actions
  try {
    let notifTitle = `Expense ${actionLabel}`;
    let notifMsg = `Expense update: ${actionLabel} by ${params.userName}.`;
    if (params.action === 'reject') {
      notifTitle = 'Expense Request Rejected';
      notifMsg = `Expense was rejected by ${params.userName}. Reason: ${params.reason || 'No reason specified'}.`;
    } else if (params.action === 'admin_approve') {
      notifTitle = 'Expense Approved by Admin';
      notifMsg = `Expense was approved by Super Admin ${params.userName}.`;
    } else if (params.action === 'manager_approve') {
      notifTitle = 'Expense Approved by Manager';
      notifMsg = `Expense was approved by ${params.userName} and is pending Admin approval.`;
    } else if (params.action === 'admin_execute') {
      notifTitle = 'Expense Disbursed';
      notifMsg = `Expense has been marked executed and disbursed by ${params.userName}.`;
    } else if (params.action === 'resubmit') {
      notifTitle = 'Expense Request Resubmitted';
      notifMsg = `Expense was resubmitted with corrections by ${params.userName}.`;
    }

    await createNotification({
      target: 'staff',
      title: notifTitle,
      message: notifMsg,
      type: 'expense',
      linkId: params.expenseId,
      entityId: params.expenseId,
      entityType: 'expense',
    });
  } catch (e) {
    console.warn('Could not dispatch expense workflow notification:', e);
  }
}

/**
 * Resubmits a rejected expense after editing by its original requester.
 * Enforces ownership: only original requester (matched via authenticated user ID) can edit & resubmit.
 * Strictly preserves all immutable audit and rejection history fields.
 * Returns status to 'pending_manager' so it enters the standard workflow again.
 */
export async function resubmitRejectedExpense(params: {
  expenseId: string;
  title: string;
  amount: number;
  date: string;
  category?: string;
  note?: string;
  corrections?: string;
  userId: string;
  userName: string;
  userRole: string;
}): Promise<void> {
  if (!params.expenseId) throw new Error('Expense ID is required.');
  if (params.userRole === 'customer') {
    throw new Error('Access Denied: Customers cannot create or edit expenses.');
  }

  const expRef = doc(db, 'expenses', params.expenseId);
  const snap = await getDoc(expRef);
  if (!snap.exists()) {
    throw new Error('Expense record not found.');
  }

  const existing = snap.data() as Expense;

  // 1. Status validation: ONLY rejected expenses can be edited & resubmitted
  if (existing.status !== 'rejected') {
    throw new Error('Only rejected expenses can be edited and resubmitted.');
  }

  // 2. Ownership validation: ONLY original requester can edit their rejected expense
  const isOwner =
    existing.requestedBy === params.userId ||
    (existing.requestedBy && params.userId && existing.requestedBy.toLowerCase() === params.userId.toLowerCase());

  if (!isOwner) {
    throw new Error('Access Denied: You can only edit and resubmit your own rejected expense requests.');
  }

  // 3. Numeric validation
  const numAmount = Number(params.amount);
  if (!Number.isFinite(numAmount) || numAmount <= 0) {
    throw new Error('Expense amount must be a positive number.');
  }

  const now = new Date().toISOString();

  // 4. Timeline history preservation: append new entry
  const newTimelineEntry: ExpenseTimelineEntry = {
    action: 'Corrected & Resubmitted Request',
    performedBy: params.userId,
    performedByName: params.userName,
    performedByRole: params.userRole,
    timestamp: now,
    note: params.corrections?.trim() || `Corrected details: "${params.title.trim()}" (AFN ${numAmount.toLocaleString('en-US')})`,
  };

  const updatedTimeline = [...(existing.timeline || []), newTimelineEntry];

  // 5. System-controlled updates:
  // - PRESERVES immutable fields: requestedBy, requestedByName, requestedByRole, createdAt
  // - PRESERVES rejection history: rejectionReason, rejectedBy, rejectedByName, rejectedAt
  // - PRESERVES previous approval/execution metadata if any
  // - Returns status to 'pending_manager'
  const updates: Partial<Expense> = {
    title: params.title.trim(),
    amount: numAmount,
    date: params.date,
    category: params.category || 'General Operations',
    note: params.note?.trim() || '',
    status: 'pending_manager',
    resubmittedBy: params.userId,
    resubmittedByName: params.userName,
    resubmittedAt: now,
    resubmissionReason: params.corrections?.trim() || 'Corrected rejected details',
    resubmissionCorrections: params.corrections?.trim() || '',
    timeline: updatedTimeline,
    updatedAt: now,
  };

  await updateDoc(expRef, cleanDataForFirestore(updates));

  // 6. Audit log entry
  await addAuditLog({
    action: 'edit_customer',
    userId: params.userId,
    userName: params.userName,
    entityType: 'settings',
    entityId: params.expenseId,
    summary: `Resubmitted rejected expense #${params.expenseId}: "${params.title.trim()}" (AFN ${numAmount}) for manager review`,
  });

  // 7. Reviewer notification
  try {
    await createNotification({
      target: 'staff',
      title: `Rejected Expense Resubmitted: ${params.title.trim()}`,
      message: `${params.userName} corrected and resubmitted expense "${params.title.trim()}" (AFN ${numAmount.toLocaleString('en-US')}) for manager review.`,
      type: 'expense',
      linkId: params.expenseId,
      entityId: params.expenseId,
      entityType: 'expense',
    });
  } catch (e) {
    console.warn('Could not dispatch resubmission notification:', e);
  }
}

// Backward-compatible addExpense
export async function addExpense(params: {
  title: string;
  amount: number;
  date: string;
  note?: string;
  category?: string;
  requestedBy?: string;
  requestedByName?: string;
  requestedByRole?: string;
}): Promise<string> {
  return saveExpense({
    title: params.title,
    amount: params.amount,
    date: params.date,
    category: params.category || 'General',
    note: params.note || '',
    requestedBy: params.requestedBy || 'system',
    requestedByName: params.requestedByName || 'Staff',
    requestedByRole: params.requestedByRole || 'staff',
    status: 'pending_manager',
  });
}

// ================= CUSTOMER REQUESTS =================
export function subscribeToCustomerRequests(
  onUpdate: (requests: CustomerRequest[]) => void,
  onError?: (err: Error) => void
) {
  const q = query(collection(db, 'requests'), orderBy('createdAt', 'desc'));
  return onSnapshot(
    q,
    (snapshot) => {
      const requests: CustomerRequest[] = [];
      snapshot.forEach((docSnap) => {
        requests.push({ id: docSnap.id, ...docSnap.data() } as CustomerRequest);
      });
      onUpdate(requests);
    },
    (err) => {
      console.warn('Customer requests listener error:', err);
      if (onError) onError(err);
    }
  );
}

export async function createCustomerRequest(
  data: Omit<CustomerRequest, 'id' | 'status' | 'replies' | 'createdAt' | 'updatedAt'>
): Promise<string> {
  const reqRef = doc(collection(db, 'requests'));
  const now = new Date().toISOString();

  const requestData: CustomerRequest = {
    id: reqRef.id,
    ...data,
    status: 'New',
    replies: [],
    createdAt: now,
    updatedAt: now,
  };

  const cleanData = Object.fromEntries(
    Object.entries(requestData).filter(([_, v]) => v !== undefined)
  );

  await setDoc(reqRef, cleanData);

  // Trigger notification for staff
  await createNotification({
    target: 'staff',
    title: 'New Customer Service Request',
    message: `${data.customerName} submitted a new request: "${data.title}"`,
    type: 'request',
    linkId: reqRef.id,
  });

  return reqRef.id;
}

export async function updateCustomerRequestStatus(
  requestId: string,
  status: RequestStatus,
  invoiceId?: string,
  billNumber?: string
): Promise<void> {
  const reqRef = doc(db, 'requests', requestId);
  const now = new Date().toISOString();

  const updates: Partial<CustomerRequest> = {
    status,
    updatedAt: now,
    ...(invoiceId ? { invoiceId } : {}),
    ...(billNumber ? { billNumber } : {}),
  };

  await updateDoc(reqRef, updates);
}

export async function addCustomerRequestReply(
  requestId: string,
  reply: Omit<CustomerRequestReply, 'id' | 'createdAt'>,
  currentReplies: CustomerRequestReply[]
): Promise<void> {
  const reqRef = doc(db, 'requests', requestId);
  const now = new Date().toISOString();

  const newReply: CustomerRequestReply = {
    id: 'rep_' + Math.random().toString(36).substring(2, 9),
    ...reply,
    createdAt: now,
  };

  const cleanReply = Object.fromEntries(
    Object.entries(newReply).filter(([_, v]) => v !== undefined)
  ) as CustomerRequestReply;

  await updateDoc(reqRef, {
    replies: [...currentReplies, cleanReply],
    updatedAt: now,
  });
}

// ================= SHOWCASE PROJECTS & UPDATES =================
export function subscribeToProjects(
  onUpdate: (projects: Project[]) => void,
  onError?: (err: Error) => void
) {
  const q = query(collection(db, 'projects'), orderBy('createdAt', 'desc'));
  return onSnapshot(
    q,
    (snapshot) => {
      const projects: Project[] = [];
      snapshot.forEach((docSnap) => {
        projects.push({ id: docSnap.id, ...docSnap.data() } as Project);
      });
      onUpdate(projects);
    },
    (err) => {
      console.warn('Projects listener error:', err);
      if (onError) onError(err);
    }
  );
}

export async function saveProject(
  projectData: Omit<Project, 'id' | 'createdAt'> & { id?: string }
): Promise<string> {
  const now = new Date().toISOString();
  if (projectData.id) {
    const projRef = doc(db, 'projects', projectData.id);
    await updateDoc(projRef, {
      title: projectData.title.trim(),
      description: projectData.description.trim(),
      category: projectData.category.trim(),
      images: projectData.images || [],
      videoUrl: projectData.videoUrl || '',
      isPublished: projectData.isPublished,
      isFeatured: projectData.isFeatured,
      date: projectData.date,
    });
    return projectData.id;
  } else {
    const newProjRef = doc(collection(db, 'projects'));
    const newProject: Project = {
      id: newProjRef.id,
      title: projectData.title.trim(),
      description: projectData.description.trim(),
      category: projectData.category.trim(),
      images: projectData.images || [],
      videoUrl: projectData.videoUrl || '',
      isPublished: projectData.isPublished,
      isFeatured: projectData.isFeatured,
      date: projectData.date,
      createdAt: now,
    };
    await setDoc(newProjRef, newProject);
    return newProjRef.id;
  }
}

export async function deleteProject(projectId: string): Promise<void> {
  const projRef = doc(db, 'projects', projectId);
  await deleteDoc(projRef);
}

// ================= NOTIFICATIONS =================
export function subscribeToNotifications(
  targetOrUser: string | { id?: string; role?: string; customerId?: string } | null,
  onUpdate: (notifications: AppNotification[]) => void,
  onError?: (err: Error) => void
) {
  const q = query(collection(db, 'notifications'), orderBy('createdAt', 'desc'));
  return onSnapshot(
    q,
    (snapshot) => {
      const notifications: AppNotification[] = [];
      snapshot.forEach((docSnap) => {
        const item = { id: docSnap.id, ...docSnap.data() } as AppNotification;
        if (!targetOrUser) {
          notifications.push(item);
          return;
        }

        if (typeof targetOrUser === 'string') {
          if (
            targetOrUser === 'all' ||
            targetOrUser === 'super_admin' ||
            item.target === 'staff' ||
            item.target === targetOrUser ||
            item.customerId === targetOrUser ||
            item.userId === targetOrUser ||
            item.recipientId === targetOrUser
          ) {
            notifications.push(item);
          }
        } else {
          // Object: role-aware filtering
          const role = targetOrUser.role;
          const uid = targetOrUser.id;
          const cid = targetOrUser.customerId;

          if (role === 'super_admin') {
            // Super Admin receives system-wide notifications
            notifications.push(item);
          } else if (role === 'invoice_manager') {
            // Invoice Manager receives staff notifications, invoices, payments, expenses, requests
            if (
              item.target === 'staff' ||
              item.target === 'all' ||
              item.target === 'invoice_manager' ||
              item.userId === uid ||
              item.recipientId === uid ||
              ['invoice', 'payment', 'expense', 'request', 'system'].includes(item.type)
            ) {
              notifications.push(item);
            }
          } else if (role === 'payment_collector') {
            // Payment Collector receives collector assignments, payments, tasks
            if (
              item.target === uid ||
              item.userId === uid ||
              item.recipientId === uid ||
              item.target === 'payment_collector' ||
              (item.target === 'staff' && item.type === 'payment')
            ) {
              notifications.push(item);
            }
          } else if (role === 'customer' || cid) {
            // Customer receives notifications targeted to their customerId or userId
            if (
              (cid && (item.customerId === cid || item.target === cid)) ||
              (uid && (item.userId === uid || item.target === uid || item.recipientId === uid))
            ) {
              notifications.push(item);
            }
          } else {
            if (item.target === 'staff' || item.target === uid || item.recipientId === uid) {
              notifications.push(item);
            }
          }
        }
      });
      onUpdate(notifications);
    },
    (err) => {
      console.warn('Notifications listener error:', err);
      if (onError) onError(err);
    }
  );
}

export async function createNotification(
  data: Omit<AppNotification, 'id' | 'isRead' | 'createdAt'>
): Promise<string> {
  const notifRef = doc(collection(db, 'notifications'));
  const now = new Date().toISOString();

  const item: AppNotification = {
    id: notifRef.id,
    ...data,
    isRead: false,
    createdAt: now,
  };

  const cleanItem = Object.fromEntries(
    Object.entries(item).filter(([_, v]) => v !== undefined)
  );

  await setDoc(notifRef, cleanItem);
  return notifRef.id;
}

export async function markNotificationAsRead(notificationId: string): Promise<void> {
  const notifRef = doc(db, 'notifications', notificationId);
  await updateDoc(notifRef, { isRead: true });
}

export async function markAllNotificationsAsRead(notificationIds: string[]): Promise<void> {
  if (!notificationIds.length) return;
  const batch = writeBatch(db);
  notificationIds.forEach((id) => {
    batch.update(doc(db, 'notifications', id), { isRead: true });
  });
  await batch.commit();
}

export async function deleteNotification(notificationId: string): Promise<void> {
  const notifRef = doc(db, 'notifications', notificationId);
  await deleteDoc(notifRef);
}

export async function clearAllNotifications(notificationIds: string[]): Promise<void> {
  if (!notificationIds.length) return;
  const batch = writeBatch(db);
  notificationIds.forEach((id) => {
    batch.delete(doc(db, 'notifications', id));
  });
  await batch.commit();
}

// ================= STAFF & USER ROLES =================
export function subscribeToUsers(
  onUpdate: (users: UserProfile[]) => void,
  onError?: (err: Error) => void
) {
  const q = query(collection(db, 'users'), orderBy('createdAt', 'desc'));
  return onSnapshot(
    q,
    (snapshot) => {
      const users: UserProfile[] = [];
      snapshot.forEach((docSnap) => {
        users.push({ id: docSnap.id, ...docSnap.data() } as UserProfile);
      });
      onUpdate(users);
    },
    (err) => {
      console.warn('Users listener error:', err);
      if (onError) onError(err);
    }
  );
}

export async function updateUserRoleAndPermissions(
  userId: string,
  role: UserRole,
  permissions?: Partial<UserPermissions>,
  adminId: string = 'system',
  adminName: string = 'Super Admin'
): Promise<void> {
  const userRef = doc(db, 'users', userId);
  const snap = await getDoc(userRef);
  if (!snap.exists()) {
    throw new Error(`User with ID ${userId} was not found.`);
  }
  const existingUser = snap.data() as UserProfile;

  // 1. Privilege Protection: Cannot elevate an ordinary account to super_admin
  if (role === 'super_admin' && existingUser.role !== 'super_admin') {
    throw new Error(
      'Access Denied: Standard role management cannot elevate an account to super_admin. Privileged roles are restricted to root system administrators.'
    );
  }

  // 2. Relationship Guard: Prevent converting customer-linked accounts to staff roles while active
  const hasCustomerLink = Boolean(existingUser.customerId && existingUser.customerId.trim().length > 0);
  if (
    (existingUser.role === 'customer' || hasCustomerLink) &&
    (role === 'invoice_manager' || role === 'payment_collector' || role === 'super_admin')
  ) {
    throw new Error(
      `Cannot change customer account "${existingUser.name}" to a staff role while actively linked to customer record (${existingUser.customerId || 'linked'}). Customer accounts cannot hold staff authority.`
    );
  }

  // 3. Customer Role Guard: Prevent assigning customer role without a valid customer relationship
  if (role === 'customer' && !hasCustomerLink) {
    throw new Error(
      'Cannot assign Customer role to an account without an active, validated customer record relationship.'
    );
  }

  await updateDoc(userRef, {
    role,
    ...(permissions ? { permissions } : {}),
    updatedAt: new Date().toISOString(),
  });

  await addAuditLog({
    action: 'change_role',
    userId: adminId,
    userName: adminName,
    entityType: 'user',
    entityId: userId,
    summary: `Changed user ${userId} (${existingUser.name}) role to "${role}"`,
  });
}

export async function toggleUserActiveStatus(
  userId: string,
  isDeactivated: boolean,
  adminId: string = 'system',
  adminName: string = 'Super Admin'
): Promise<void> {
  const userRef = doc(db, 'users', userId);
  await updateDoc(userRef, {
    isDeactivated,
    status: isDeactivated ? 'inactive' : 'active',
    updatedAt: new Date().toISOString(),
  });

  await addAuditLog({
    action: 'change_role',
    userId: adminId,
    userName: adminName,
    entityType: 'user',
    entityId: userId,
    summary: `${isDeactivated ? 'Deactivated' : 'Reactivated'} user account ${userId}`,
  });
}

export async function setUserAccountStatus(
  userId: string,
  status: UserAccountStatus,
  adminId: string = 'system',
  adminName: string = 'Super Admin'
): Promise<void> {
  const userRef = doc(db, 'users', userId);
  const isDeactivated = status === 'inactive' || status === 'suspended';
  await updateDoc(userRef, {
    status,
    isDeactivated,
    updatedAt: new Date().toISOString(),
  });

  await addAuditLog({
    action: 'change_role',
    userId: adminId,
    userName: adminName,
    entityType: 'user',
    entityId: userId,
    summary: `Changed user account status of ${userId} to ${status}`,
  });
}

// ================= BACKUP & RECOVERY =================
export async function exportFullBackupData(): Promise<{
  exportDate: string;
  version: string;
  counts: Record<string, number>;
  customers: Customer[];
  invoices: Invoice[];
  payments: Payment[];
  expenses: Expense[];
  settings: BusinessSettings | null;
  auditLogs: AuditLog[];
  requests: CustomerRequest[];
  projects: Project[];
}> {
  const [
    custSnap,
    invSnap,
    paySnap,
    expSnap,
    setSnap,
    logSnap,
    reqSnap,
    projSnap,
  ] = await Promise.all([
    getDocs(collection(db, 'customers')),
    getDocs(collection(db, 'invoices')),
    getDocs(collection(db, 'payments')),
    getDocs(collection(db, 'expenses')),
    getDocs(collection(db, 'settings')),
    getDocs(collection(db, 'auditLogs')),
    getDocs(collection(db, 'requests')),
    getDocs(collection(db, 'projects')),
  ]);

  const customers: Customer[] = custSnap.docs.map((d) => ({ id: d.id, ...d.data() } as Customer));
  const invoices: Invoice[] = invSnap.docs.map((d) => ({ id: d.id, ...d.data() } as Invoice));
  const payments: Payment[] = paySnap.docs.map((d) => ({ id: d.id, ...d.data() } as Payment));
  const expenses: Expense[] = expSnap.docs.map((d) => ({ id: d.id, ...d.data() } as Expense));
  const auditLogs: AuditLog[] = logSnap.docs.map((d) => ({ id: d.id, ...d.data() } as AuditLog));
  const requests: CustomerRequest[] = reqSnap.docs.map((d) => ({ id: d.id, ...d.data() } as CustomerRequest));
  const projects: Project[] = projSnap.docs.map((d) => ({ id: d.id, ...d.data() } as Project));
  const settings = setSnap.docs.length > 0 ? (setSnap.docs[0].data() as BusinessSettings) : null;

  return {
    exportDate: new Date().toISOString(),
    version: '2.0-ST',
    counts: {
      customers: customers.length,
      invoices: invoices.length,
      payments: payments.length,
      expenses: expenses.length,
      auditLogs: auditLogs.length,
      requests: requests.length,
      projects: projects.length,
    },
    customers,
    invoices,
    payments,
    expenses,
    settings,
    auditLogs,
    requests,
    projects,
  };
}

// ================= RECEIPT DESIGN SETTINGS =================
export async function saveReceiptDesignSettings(
  design: ReceiptDesignSettings,
  userId: string = 'system',
  userName: string = 'Super Admin'
): Promise<void> {
  const settingsRef = doc(db, 'settings', 'company_settings');
  await setDoc(
    settingsRef,
    cleanDataForFirestore({
      receiptDesign: design,
      updatedAt: new Date().toISOString(),
    }),
    { merge: true }
  );

  await addAuditLog({
    action: 'update_settings',
    userId,
    userName,
    entityType: 'settings',
    entityId: 'company_settings',
    summary: 'Updated custom Thermal & Standard receipt design settings',
  });
}

// ================= CUSTOMER SELF-REGISTRATION & MATCHING =================
export function subscribeToRegistrations(
  onUpdate: (registrations: CustomerRegistration[]) => void,
  onError?: (err: Error) => void
) {
  const q = query(collection(db, 'registrations'), orderBy('createdAt', 'desc'));
  return onSnapshot(
    q,
    (snapshot) => {
      const list: CustomerRegistration[] = [];
      snapshot.forEach((docSnap) => {
        list.push({ id: docSnap.id, ...docSnap.data() } as CustomerRegistration);
      });
      onUpdate(list);
    },
    (err) => {
      console.warn('Registrations listener error:', err);
      if (onError) onError(err);
    }
  );
}

export async function submitCustomerRegistration(params: {
  name: string;
  phone: string;
  email?: string;
  companyName?: string;
  address: string;
  note?: string;
  existingCustomers: Customer[];
}): Promise<string> {
  const regRef = doc(collection(db, 'registrations'));
  const now = new Date().toISOString();

  // Intelligent matching against existing customers
  const cleanPhone = params.phone.replace(/\D/g, '');
  let matchType: 'Strong Match' | 'Possible Match' | 'No Match' = 'No Match';
  let matchedCustomerId: string | undefined = undefined;

  for (const c of params.existingCustomers) {
    const custPhone = c.phone ? c.phone.replace(/\D/g, '') : '';
    if (
      custPhone &&
      cleanPhone &&
      (custPhone === cleanPhone || custPhone.endsWith(cleanPhone) || cleanPhone.endsWith(custPhone))
    ) {
      matchType = 'Strong Match';
      matchedCustomerId = c.id;
      break;
    }
    if (params.email && c.email && params.email.trim().toLowerCase() === c.email.trim().toLowerCase()) {
      matchType = 'Possible Match';
      matchedCustomerId = c.id;
    } else if (params.name.trim().toLowerCase() === c.name.trim().toLowerCase()) {
      matchType = 'Possible Match';
      matchedCustomerId = c.id;
    }
  }

  const regData: CustomerRegistration = {
    id: regRef.id,
    name: params.name.trim(),
    phone: params.phone.trim(),
    email: params.email?.trim() || undefined,
    companyName: params.companyName?.trim() || undefined,
    address: params.address.trim(),
    note: params.note?.trim() || undefined,
    otpVerified: true,
    status: 'pending',
    matchType,
    matchedCustomerId,
    createdAt: now,
    updatedAt: now,
  };

  await setDoc(regRef, cleanDataForFirestore(regData));

  // Notify Super Admin
  await createNotification({
    target: 'staff',
    title: 'New Customer Sign-up Pending',
    message: `${params.name} (${params.phone}) has signed up. Match: ${matchType}.`,
    type: 'system',
    linkId: regRef.id,
  });

  return regRef.id;
}

export async function reviewCustomerRegistration(params: {
  registrationId: string;
  action: 'approve_new' | 'link_existing' | 'reject';
  linkedCustomerId?: string;
  rejectionReason?: string;
  registration: CustomerRegistration;
  reviewedBy: string;
  reviewedByName: string;
}): Promise<string> {
  const now = new Date().toISOString();
  const regRef = doc(db, 'registrations', params.registrationId);

  if (params.action === 'reject') {
    await updateDoc(
      regRef,
      cleanDataForFirestore({
        status: 'rejected',
        rejectionReason: params.rejectionReason || 'Application details could not be verified.',
        reviewedBy: params.reviewedBy,
        reviewedAt: now,
        updatedAt: now,
      })
    );
    return params.registrationId;
  }

  let finalCustomerId = params.linkedCustomerId;

  if (params.action === 'approve_new') {
    const newCustId = await saveCustomer(
      {
        name: params.registration.name,
        phone: params.registration.phone,
        email: params.registration.email || '',
        companyName: params.registration.companyName || '',
        address: params.registration.address,
        note: params.registration.note || 'Created from customer registration',
      },
      params.reviewedBy,
      params.reviewedByName
    );
    finalCustomerId = newCustId;
  }

  await updateDoc(
    regRef,
    cleanDataForFirestore({
      status: 'active',
      matchedCustomerId: finalCustomerId,
      reviewedBy: params.reviewedBy,
      reviewedAt: now,
      updatedAt: now,
    })
  );

  return finalCustomerId || params.registrationId;
}

// ================= PUBLIC WEBSITE SERVICES =================
export function subscribeToServices(
  onUpdate: (services: Service[]) => void,
  onError?: (err: Error) => void
) {
  const q = query(collection(db, 'services'), orderBy('displayOrder', 'asc'));
  return onSnapshot(
    q,
    (snapshot) => {
      const items: Service[] = [];
      snapshot.forEach((d) => items.push({ id: d.id, ...d.data() } as Service));
      onUpdate(items);
    },
    (err) => {
      console.warn('Services listener error:', err);
      if (onError) onError(err);
    }
  );
}

export async function saveService(
  data: Omit<Service, 'id' | 'createdAt' | 'updatedAt'> & { id?: string }
): Promise<string> {
  const now = new Date().toISOString();
  if (data.id) {
    const sRef = doc(db, 'services', data.id);
    await updateDoc(sRef, cleanDataForFirestore({ ...data, updatedAt: now }));
    return data.id;
  } else {
    const sRef = doc(collection(db, 'services'));
    await setDoc(
      sRef,
      cleanDataForFirestore({ ...data, id: sRef.id, createdAt: now, updatedAt: now })
    );
    return sRef.id;
  }
}

export async function deleteService(serviceId: string): Promise<void> {
  await deleteDoc(doc(db, 'services', serviceId));
}

// ================= PUBLIC WEBSITE POSTS =================
export function subscribeToPosts(
  onUpdate: (posts: Post[]) => void,
  onError?: (err: Error) => void
) {
  const q = query(collection(db, 'posts'), orderBy('createdAt', 'desc'));
  return onSnapshot(
    q,
    (snapshot) => {
      const items: Post[] = [];
      snapshot.forEach((d) => items.push({ id: d.id, ...d.data() } as Post));
      onUpdate(items);
    },
    (err) => {
      console.warn('Posts listener error:', err);
      if (onError) onError(err);
    }
  );
}

export async function savePost(
  data: Omit<Post, 'id' | 'createdAt' | 'updatedAt'> & { id?: string }
): Promise<string> {
  const now = new Date().toISOString();
  if (data.id) {
    const pRef = doc(db, 'posts', data.id);
    await updateDoc(pRef, cleanDataForFirestore({ ...data, updatedAt: now }));
    return data.id;
  } else {
    const pRef = doc(collection(db, 'posts'));
    await setDoc(
      pRef,
      cleanDataForFirestore({ ...data, id: pRef.id, createdAt: now, updatedAt: now })
    );
    return pRef.id;
  }
}

export async function deletePost(postId: string): Promise<void> {
  await deleteDoc(doc(db, 'posts', postId));
}

// ================= USER PROFILE & EMPLOYEE MANAGEMENT =================
export async function updateUserProfile(
  userId: string,
  data: Partial<UserProfile>,
  adminId: string = 'system',
  adminName: string = 'Administrator'
): Promise<UserProfile> {
  const uRef = doc(db, 'users', userId);
  const snap = await getDoc(uRef);
  if (!snap.exists()) {
    throw new Error(`User with ID ${userId} not found.`);
  }
  const currentData = snap.data() as UserProfile;

  // Protect immutable fields! User ID, document ID, username, password credentials, and creation time cannot be altered
  const {
    id: _ignoredId,
    userId: _ignoredUserId,
    username: _ignoredUsername,
    passwordHash: _ignoredHash,
    passwordSalt: _ignoredSalt,
    createdAt: _ignoredCreatedAt,
    ...allowedUpdates
  } = data as any;

  const merged: UserProfile = {
    ...currentData,
    ...allowedUpdates,
    updatedAt: new Date().toISOString(),
  };

  // Re-evaluate profile completion status automatically
  merged.profileCompletionStatus = isProfileComplete(merged) ? 'complete' : 'incomplete';

  await updateDoc(uRef, cleanDataForFirestore(merged) as any);

  await addAuditLog({
    action: 'change_role',
    userId: adminId,
    userName: adminName,
    entityType: 'user',
    entityId: userId,
    summary: `Updated profile details for "${merged.name}" (${merged.userId || userId}). Profile completion: ${merged.profileCompletionStatus}.`,
  }).catch(console.warn);

  return merged;
}

// ================= EMPLOYEE DOCUMENTS (PDF ONLY) =================
export async function getEmployeeDocuments(userId: string): Promise<EmployeeDocument[]> {
  try {
    const docsCol = collection(db, 'users', userId, 'documents');
    const q = query(docsCol, orderBy('uploadedAt', 'desc'));
    const snap = await getDocs(q);
    return snap.docs.map((d) => ({
      id: d.id,
      ...(d.data() as Omit<EmployeeDocument, 'id'>),
    }));
  } catch (err) {
    console.error(`Error fetching employee documents for user ${userId}:`, err);
    return [];
  }
}

export async function saveEmployeeDocument(
  userId: string,
  docData: Omit<EmployeeDocument, 'id'>
): Promise<EmployeeDocument> {
  const docId = `DOC-${Date.now()}-${Math.random().toString(36).substring(2, 6).toUpperCase()}`;
  const docRef = doc(db, 'users', userId, 'documents', docId);
  const record: EmployeeDocument = {
    id: docId,
    ...docData,
    userId,
    fileType: 'application/pdf',
    uploadedAt: docData.uploadedAt || new Date().toISOString(),
  };

  await setDoc(docRef, cleanDataForFirestore(record));

  await addAuditLog({
    action: 'create_user',
    userId: docData.uploadedBy || 'admin',
    userName: docData.uploadedBy || 'Administrator',
    entityType: 'user',
    entityId: docId,
    summary: `Uploaded employee PDF document "${docData.documentName}" for user ${userId}.`,
  }).catch(console.warn);

  return record;
}

export async function deleteEmployeeDocument(
  userId: string,
  documentId: string,
  adminId: string = 'system',
  adminName: string = 'Administrator'
): Promise<void> {
  const docRef = doc(db, 'users', userId, 'documents', documentId);
  await deleteDoc(docRef);

  await addAuditLog({
    action: 'change_role',
    userId: adminId,
    userName: adminName,
    entityType: 'user',
    entityId: documentId,
    summary: `Deleted employee document ${documentId} for user ${userId}.`,
  }).catch(console.warn);
}

export {
  fetchPaginatedPaymentsFromFirestore,
  fetchServerPaymentSummaryMetrics,
  DEFAULT_PAYMENTS_PAGE_SIZE,
} from './paymentPagination';

