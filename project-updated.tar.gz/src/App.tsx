import React, { useState, useEffect } from 'react';
import { AuthProvider, useAuth } from './context/AuthContext';
import { ToastProvider } from './context/ToastContext';
import {
  subscribeToSettings,
  subscribeToCustomers,
  subscribeToInvoices,
  subscribeToPayments,
  subscribeToExpenses,
  subscribeToCustomerRequests,
  subscribeToProjects,
  subscribeToAuditLogs,
  subscribeToUsers,
  subscribeToNotifications,
  markNotificationAsRead,
  updateCustomerRequestStatus,
} from './services/db';
import {
  BusinessSettings,
  Customer,
  Invoice,
  Payment,
  Expense,
  CustomerRequest,
  Project,
  AuditLog,
  UserProfile,
  AppNotification,
} from './types';
import { Sidebar, ActiveTab } from './components/layout/Sidebar';
import { Header } from './components/layout/Header';
import { ChangePasswordModal } from './components/auth/ChangePasswordModal';
import { LoginView } from './views/LoginView';
import { DashboardView } from './views/DashboardView';
import { InvoicesView } from './views/InvoicesView';
import { CustomersView } from './views/CustomersView';
import { PaymentsView } from './views/PaymentsView';
import { ExpensesView } from './views/ExpensesView';
import { ReportsView } from './views/ReportsView';
import { SettingsView } from './views/SettingsView';
import { CustomerRequestsView } from './views/CustomerRequestsView';
import { ProjectsShowcaseView } from './views/ProjectsShowcaseView';
import { StaffManagementView } from './views/StaffManagementView';
import { AuditLogsView } from './views/AuditLogsView';
import { BackupRestoreView } from './views/BackupRestoreView';
import { InvoiceDesignerView } from './views/InvoiceDesignerView';
import { CustomerPortalView } from './views/CustomerPortalView';
import { NotificationsView } from './views/NotificationsView';

import { createPortal } from 'react-dom';
import { InvoiceModal } from './components/invoice/InvoiceModal';
import { InvoiceDetailModal } from './components/invoice/InvoiceDetailModal';
import { calculateTotalPaidForInvoice, calculateRemaining } from './utils/format';
import { normalizeCustomerStatus } from './utils/customerValidation';
import { CustomerModal } from './components/customer/CustomerModal';
import { CustomerDetailModal } from './components/customer/CustomerDetailModal';
import { PaymentModal } from './components/payment/PaymentModal';
import { PaymentReceiptModal } from './components/payment/PaymentReceiptModal';
import { getPaymentById } from './services/db';
import { ExpenseModal } from './components/expense/ExpenseModal';
import { RouteGuard } from './components/auth/RouteGuard';
import { Loader2 } from 'lucide-react';

export const TAB_TO_ROUTE: Record<ActiveTab, string> = {
  dashboard: '/dashboard',
  invoices: '/invoices',
  customers: '/customers',
  payments: '/payments',
  expenses: '/expenses',
  requests: '/requests',
  projects: '/projects',
  reports: '/reports',
  staff: '/staff',
  audit: '/audit-log',
  backup: '/backup',
  invoice_design: '/invoice-design',
  settings: '/settings',
  notifications: '/notifications',
};

export const ROUTE_TO_TAB: Record<string, ActiveTab> = {
  '/': 'dashboard',
  '/dashboard': 'dashboard',
  '/invoices': 'invoices',
  '/customers': 'customers',
  '/payments': 'payments',
  '/expenses': 'expenses',
  '/requests': 'requests',
  '/projects': 'projects',
  '/reports': 'reports',
  '/staff': 'staff',
  '/audit-log': 'audit',
  '/audit': 'audit',
  '/backup': 'backup',
  '/invoice-design': 'invoice_design',
  '/invoice_design': 'invoice_design',
  '/settings': 'settings',
  '/notifications': 'notifications',
};

function getInitialTab(): ActiveTab {
  if (typeof window === 'undefined') return 'dashboard';
  const path = window.location.pathname.toLowerCase();
  const hash = window.location.hash.replace(/^#/, '').toLowerCase();
  if (ROUTE_TO_TAB[path]) return ROUTE_TO_TAB[path];
  if (ROUTE_TO_TAB[`/${path.replace(/^\//, '')}`]) return ROUTE_TO_TAB[`/${path.replace(/^\//, '')}`];
  if (ROUTE_TO_TAB[hash]) return ROUTE_TO_TAB[hash];
  if (ROUTE_TO_TAB[`/${hash.replace(/^\//, '')}`]) return ROUTE_TO_TAB[`/${hash.replace(/^\//, '')}`];
  return 'dashboard';
}

const defaultSettings: BusinessSettings = {
  companyName: 'Sarwan Technology',
  logo: '/sarwan-logo.png',
  phone: '0731339014',
  whatsapp: '0778771020',
  email: 'Sarwantechnology.af@gmail.com',
  address: 'Kabul, Afghanistan',
  currency: 'AFN',
  invoicePrefix: 'ST-',
  nextInvoiceNumber: 1060,
  invoiceNote: 'Thank you for choosing Sarwan Technology.',
  authorizedEmails: ['admin@sarwantechnology.com', 'bilalsarwan7@gmail.com', 'bilalsarwan2@gmail.com', 'sarwancreative.af@gmail.com'],
};

function MainApplication() {
  const { isAuthorized, userProfile, loading: authLoading, portalMode, activeCustomer } = useAuth();

  const [settings, setSettings] = useState<BusinessSettings>(defaultSettings);
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [invoices, setInvoices] = useState<Invoice[]>([]);
  const [payments, setPayments] = useState<Payment[]>([]);
  const [expenses, setExpenses] = useState<Expense[]>([]);
  const [requests, setRequests] = useState<CustomerRequest[]>([]);
  const [projects, setProjects] = useState<Project[]>([]);
  const [auditLogs, setAuditLogs] = useState<AuditLog[]>([]);
  const [users, setUsers] = useState<UserProfile[]>([]);
  const [notifications, setNotifications] = useState<AppNotification[]>([]);

  const [activeTab, setActiveTab] = useState<ActiveTab>(getInitialTab);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState<boolean>(false);
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState<boolean>(() => {
    if (typeof window !== 'undefined') {
      return localStorage.getItem('sarwan_sidebar_collapsed') === 'true';
    }
    return false;
  });

  const handleToggleSidebarCollapse = () => {
    setIsSidebarCollapsed((prev) => {
      const next = !prev;
      try {
        localStorage.setItem('sarwan_sidebar_collapsed', String(next));
      } catch {
        // ignore localStorage error
      }
      return next;
    });
  };
  const [dashboardRefreshKey, setDashboardRefreshKey] = useState<number>(0);
  const [isDashboardRefreshing, setIsDashboardRefreshing] = useState<boolean>(false);
  const [dataRefreshTrigger, setDataRefreshTrigger] = useState<number>(0);

  const handleTabChange = (newTab: ActiveTab) => {
    if (newTab === 'dashboard' && activeTab === 'dashboard') {
      // Behavior B: User is already on Business Dashboard -> reload / refresh Dashboard
      setIsDashboardRefreshing(true);
      setDashboardRefreshKey((prev) => prev + 1);
      setDataRefreshTrigger((prev) => prev + 1);
      setTimeout(() => {
        setIsDashboardRefreshing(false);
      }, 250);
      return;
    }

    // Behavior A: User is on another page -> navigate to existing Business Dashboard
    setActiveTab(newTab);
    const targetRoute = TAB_TO_ROUTE[newTab] || `/${newTab}`;
    if (typeof window !== 'undefined' && window.location.pathname !== targetRoute) {
      try {
        window.history.pushState(null, '', targetRoute);
      } catch {
        // Sandboxed environment fallback
      }
    }
  };

  // Sync activeTab when browser back/forward buttons are clicked or URL changes
  useEffect(() => {
    const handleLocationChange = () => {
      const currentPath = window.location.pathname.toLowerCase();
      const currentHash = window.location.hash.replace(/^#/, '').toLowerCase();
      const matched =
        ROUTE_TO_TAB[currentPath] ||
        ROUTE_TO_TAB[`/${currentPath.replace(/^\//, '')}`] ||
        ROUTE_TO_TAB[currentHash];
      if (matched && matched !== activeTab) {
        setActiveTab(matched);
      }
    };

    window.addEventListener('popstate', handleLocationChange);
    window.addEventListener('hashchange', handleLocationChange);
    return () => {
      window.removeEventListener('popstate', handleLocationChange);
      window.removeEventListener('hashchange', handleLocationChange);
    };
  }, [activeTab]);

  // Modal states
  const [isInvoiceModalOpen, setIsInvoiceModalOpen] = useState<boolean>(false);
  const [invoiceToEdit, setInvoiceToEdit] = useState<Invoice | null>(null);
  const [selectedInvoiceDetail, setSelectedInvoiceDetail] = useState<Invoice | null>(null);

  const [isCustomerModalOpen, setIsCustomerModalOpen] = useState<boolean>(false);
  const [customerToEdit, setCustomerToEdit] = useState<Customer | null>(null);
  const [selectedCustomerDetail, setSelectedCustomerDetail] = useState<Customer | null>(null);
  const [preselectedInvoiceCustomer, setPreselectedInvoiceCustomer] = useState<Customer | null>(null);
  const [isInvoiceCustomerLocked, setIsInvoiceCustomerLocked] = useState<boolean>(false);

  const [isPaymentModalOpen, setIsPaymentModalOpen] = useState<boolean>(false);
  const [paymentInvoiceId, setPaymentInvoiceId] = useState<string | undefined>(undefined);
  const [isPaymentCorrection, setIsPaymentCorrection] = useState<boolean>(false);
  const [activeReceiptPayment, setActiveReceiptPayment] = useState<Payment | null>(null);

  const [isExpenseModalOpen, setIsExpenseModalOpen] = useState<boolean>(false);
  const [expenseToEdit, setExpenseToEdit] = useState<Expense | null>(null);
  const [sourceRequest, setSourceRequest] = useState<CustomerRequest | null>(null);

  const handleOpenNewExpense = () => {
    setExpenseToEdit(null);
    setIsExpenseModalOpen(true);
  };

  const handleOpenEditExpense = (exp: Expense) => {
    setExpenseToEdit(exp);
    setIsExpenseModalOpen(true);
  };

  // Firestore real-time subscriptions
  useEffect(() => {
    if (!isAuthorized) return;

    const unsubSettings = subscribeToSettings((newSettings) => {
      setSettings(newSettings);
    });

    const unsubCustomers = subscribeToCustomers((newCustomers) => {
      setCustomers(newCustomers);
      setSelectedCustomerDetail((current) => {
        if (!current) return null;
        return newCustomers.find((c) => c.id === current.id) || current;
      });
    });

    const unsubInvoices = subscribeToInvoices((newInvoices) => {
      setInvoices(newInvoices);
      setSelectedInvoiceDetail((current) => {
        if (!current) return null;
        return newInvoices.find((i) => i.id === current.id) || current;
      });
    });

    const unsubPayments = subscribeToPayments((newPayments) => {
      setPayments(newPayments);
    });

    const unsubExpenses = subscribeToExpenses((newExpenses) => {
      setExpenses(newExpenses);
    });

    const unsubRequests = subscribeToCustomerRequests((newRequests) => {
      setRequests(newRequests);
    });

    const unsubProjects = subscribeToProjects((newProjects) => {
      setProjects(newProjects);
    });

    const unsubAudit = subscribeToAuditLogs((newLogs) => {
      setAuditLogs(newLogs);
    });

    const unsubUsers = subscribeToUsers((newUsers) => {
      setUsers(newUsers);
    });

    const notifTarget = userProfile
      ? {
          id: userProfile.id,
          role: userProfile.role,
          customerId: userProfile.customerId || activeCustomer?.id,
        }
      : activeCustomer
      ? { id: activeCustomer.id, role: 'customer', customerId: activeCustomer.id }
      : 'staff';

    const unsubNotifications = subscribeToNotifications(notifTarget, (newNotifs) => {
      setNotifications(newNotifs);
    });

    return () => {
      unsubSettings();
      unsubCustomers();
      unsubInvoices();
      unsubPayments();
      unsubExpenses();
      unsubRequests();
      unsubProjects();
      unsubAudit();
      unsubUsers();
      unsubNotifications();
    };
  }, [isAuthorized, userProfile?.id, userProfile?.role, activeCustomer?.id, dataRefreshTrigger]);

  if (authLoading) {
    return (
      <div className="min-h-screen bg-neutral-100 flex flex-col items-center justify-center p-4">
        <div className="p-4 bg-white rounded-2xl shadow-md border border-neutral-200 flex flex-col items-center gap-3">
          <div
            className="w-16 h-16 bg-white flex items-center justify-center shrink-0 overflow-hidden p-1 shadow-xs"
            style={{ borderRadius: '100%', border: 'none' }}
          >
            <img
              src={settings?.logo || '/sarwan-logo.png'}
              alt="Sarwan Technology"
              className="max-h-full max-w-full object-contain animate-pulse"
              onError={(e) => {
                const target = e.currentTarget;
                if (target.src.endsWith('.png')) target.src = '/sarwan-logo.svg';
              }}
            />
          </div>
          <p className="text-xs font-semibold text-neutral-600">Connecting to Sarwan Technology...</p>
        </div>
      </div>
    );
  }

  if (!isAuthorized) {
    return <LoginView settings={settings} />;
  }

  // Mandatory password change flow: restrict user until new password is set
  if (userProfile?.mustChangePassword) {
    return <ChangePasswordModal />;
  }

  // ================= CUSTOMER PORTAL MODE =================
  if (portalMode === 'customer' && activeCustomer) {
    return (
      <>
        <CustomerPortalView
          customer={activeCustomer}
          invoices={invoices}
          payments={payments}
          requests={requests}
          projects={projects}
          settings={settings}
          onSelectInvoice={(inv) => setSelectedInvoiceDetail(inv)}
          notifications={notifications}
          onMarkNotificationRead={markNotificationAsRead}
        />

        {/* Global modals accessible from customer portal (e.g. view invoice) */}
        <InvoiceDetailModal
          isOpen={Boolean(selectedInvoiceDetail)}
          onClose={() => setSelectedInvoiceDetail(null)}
          invoice={selectedInvoiceDetail}
          payments={payments}
          settings={settings}
        />
      </>
    );
  }

  // Quick action: Generate Invoice from Customer Request
  const handleGenerateInvoiceFromRequest = (req: CustomerRequest) => {
    setSourceRequest(req);
    // Find matching customer or construct snapshot
    let targetCustomer = customers.find(
      (c) =>
        c.id === req.customerId ||
        c.phone === req.customerPhone ||
        c.name.toLowerCase() === req.customerName.toLowerCase()
    );

    const initialInv: Partial<Invoice> = {
      customerId: targetCustomer?.id || req.customerId || '',
      customerSnapshot: {
        id: targetCustomer?.id || req.customerId || 'cust_temp',
        name: req.customerName,
        phone: req.customerPhone,
        email: req.customerEmail || '',
        address: targetCustomer?.address || '',
        companyName: targetCustomer?.companyName || '',
      },
      items: [
        {
          sNo: 1,
          description: req.title,
          quantity: 1,
          unitPrice: 0,
          totalAmount: 0,
        },
        ...Array.from({ length: 19 }, (_, i) => ({
          sNo: i + 2,
          description: '',
          quantity: '' as const,
          unitPrice: '' as const,
          totalAmount: 0,
        })),
      ],
    };

    setInvoiceToEdit(initialInv as Invoice);
    setIsInvoiceModalOpen(true);
  };

  const handleInvoiceCreated = async (created: Invoice) => {
    setSelectedInvoiceDetail(created);
    if (sourceRequest) {
      try {
        await updateCustomerRequestStatus(
          sourceRequest.id,
          'Invoice Created',
          created.id,
          created.billNumber
        );
      } catch (err) {
        console.warn('Could not link request to created invoice:', err);
      }
      setSourceRequest(null);
    }
  };

  return (
    <div
      className={`min-h-screen bg-neutral-100 text-neutral-900 flex ${
        activeTab === 'invoice_design' ? 'h-screen overflow-hidden' : ''
      }`}
    >
      {/* Sidebar Navigation */}
      <Sidebar
        activeTab={activeTab}
        onTabChange={handleTabChange}
        logo={settings?.logo || '/sarwan-logo.png'}
        onNewInvoice={() => {
          setInvoiceToEdit(null);
          setSourceRequest(null);
          setIsInvoiceModalOpen(true);
        }}
        isOpenOnMobile={isMobileMenuOpen}
        onCloseMobile={() => setIsMobileMenuOpen(false)}
        isCollapsed={isSidebarCollapsed}
        onToggleCollapse={handleToggleSidebarCollapse}
      />

      {/* Main Content Area */}
      <div
        className={`flex-1 flex flex-col min-w-0 transition-all duration-300 ease-in-out ${
          isSidebarCollapsed ? 'lg:pl-20' : 'lg:pl-64'
        } ${activeTab === 'invoice_design' ? 'h-screen overflow-hidden' : ''}`}
      >
        <Header
          activeTab={activeTab}
          logo={settings?.logo || '/sarwan-logo.png'}
          settings={settings}
          notifications={notifications}
          onMarkNotificationRead={markNotificationAsRead}
          onTabChange={handleTabChange}
          onOpenMobileMenu={() => setIsMobileMenuOpen(true)}
          onNewInvoice={() => {
            setInvoiceToEdit(null);
            setSourceRequest(null);
            setIsInvoiceModalOpen(true);
          }}
        />

        <main
          className={
            activeTab === 'invoice_design'
              ? 'flex-1 w-full min-h-0 overflow-hidden flex flex-col p-0'
              : 'flex-1 p-4 sm:p-6 max-w-7xl w-full mx-auto'
          }
        >
          {activeTab === 'dashboard' && (
            isDashboardRefreshing ? (
              <div
                id="dashboard-refreshing-container"
                className="min-h-[400px] flex flex-col items-center justify-center p-8 text-center"
              >
                <Loader2 className="w-8 h-8 text-[#F58220] animate-spin mb-3" />
                <p className="text-sm font-semibold text-neutral-700">
                  Refreshing Business Dashboard...
                </p>
                <p className="text-xs text-neutral-400 mt-1">Reloading metrics, transactions, and ledger balances</p>
              </div>
            ) : (
              <DashboardView
                key={`dashboard-view-${dashboardRefreshKey}`}
                invoices={invoices}
                customers={customers}
                payments={payments}
                expenses={expenses}
                settings={settings}
                users={users}
                auditLogs={auditLogs}
                requests={requests}
                projects={projects}
                notifications={notifications}
                onNewInvoice={() => {
                  setInvoiceToEdit(null);
                  setSourceRequest(null);
                  setIsInvoiceModalOpen(true);
                }}
                onNewCustomer={() => {
                  setCustomerToEdit(null);
                  setIsCustomerModalOpen(true);
                }}
                onAddPayment={(invoiceId) => {
                  setPaymentInvoiceId(invoiceId);
                  setIsPaymentCorrection(false);
                  setIsPaymentModalOpen(true);
                }}
                onAddExpense={handleOpenNewExpense}
                onSelectInvoice={(inv) => setSelectedInvoiceDetail(inv)}
                onSelectPayment={(p) => {
                  handleTabChange('payments');
                }}
                onSelectCustomer={(c) => {
                  setSelectedCustomerDetail(c);
                  handleTabChange('customers');
                }}
                onViewAllInvoices={() => handleTabChange('invoices')}
                onTabChange={handleTabChange}
                onRequestProject={() => {
                  handleTabChange('requests');
                }}
                onNewCustomerRequest={() => handleTabChange('requests')}
              />
            )
          )}

          {activeTab === 'invoices' && (
            <RouteGuard
              routePath="/invoices"
              routeName="Invoice Management"
              allowedRoles={['super_admin', 'invoice_manager', 'payment_collector']}
              requiredPermission="canViewInvoices"
              redirectTo="dashboard"
              onRedirect={handleTabChange}
            >
              <InvoicesView
                invoices={invoices}
                payments={payments}
                settings={settings}
                users={users}
                onNewInvoice={() => {
                  setInvoiceToEdit(null);
                  setSourceRequest(null);
                  setIsInvoiceModalOpen(true);
                }}
                onSelectInvoice={(inv) => setSelectedInvoiceDetail(inv)}
                onEditInvoice={(inv) => {
                  const paid = Math.max(
                    calculateTotalPaidForInvoice(inv.id, payments),
                    Number(inv.totalPaid) || 0
                  );
                  const total = Number(inv.totalAmount) || 0;
                  const isLocked = Boolean(
                    inv.isLocked ||
                    inv.status === 'Paid' ||
                    (total > 0 && paid >= total) ||
                    (total > 0 && calculateRemaining(total, paid) <= 0)
                  );
                  if (isLocked) {
                    console.warn('Cannot edit locked / fully paid invoice:', inv.billNumber);
                    return;
                  }
                  setInvoiceToEdit(inv);
                  setIsInvoiceModalOpen(true);
                }}
              />
            </RouteGuard>
          )}

          {activeTab === 'customers' && (
            <RouteGuard
              routePath="/customers"
              routeName="Customer Accounts & Ledger"
              allowedRoles={['super_admin', 'invoice_manager', 'payment_collector']}
              requiredPermission="canViewCustomers"
              redirectTo="dashboard"
              onRedirect={handleTabChange}
            >
              <CustomersView
                customers={customers}
                invoices={invoices}
                payments={payments}
                users={users}
                onNewCustomer={() => {
                  setCustomerToEdit(null);
                  setIsCustomerModalOpen(true);
                }}
                onSelectCustomer={(cust) => setSelectedCustomerDetail(cust)}
                onEditCustomer={(cust) => {
                  setCustomerToEdit(cust);
                  setIsCustomerModalOpen(true);
                }}
              />
            </RouteGuard>
          )}

          {activeTab === 'payments' && (
            <RouteGuard
              routePath="/payments"
              routeName="Payment Ledger"
              allowedRoles={['super_admin', 'invoice_manager', 'payment_collector']}
              requiredPermission="canViewPayments"
              redirectTo="dashboard"
              onRedirect={handleTabChange}
            >
              <PaymentsView
                payments={payments}
                invoices={invoices}
                settings={settings}
                users={users}
                onAddPayment={() => {
                  setPaymentInvoiceId(undefined);
                  setIsPaymentCorrection(false);
                  setIsPaymentModalOpen(true);
                }}
                onAddCorrection={() => {
                  setPaymentInvoiceId(undefined);
                  setIsPaymentCorrection(true);
                  setIsPaymentModalOpen(true);
                }}
                onSelectInvoice={(inv) => setSelectedInvoiceDetail(inv)}
                onNavigateToInvoices={() => handleTabChange('invoices')}
              />
            </RouteGuard>
          )}

          {activeTab === 'expenses' && (
            <RouteGuard
              routePath="/expenses"
              routeName="Operating Expenses"
              allowedRoles={['super_admin', 'invoice_manager', 'payment_collector']}
              requiredPermission="canViewExpenses"
              redirectTo="dashboard"
              onRedirect={handleTabChange}
            >
              <ExpensesView
                expenses={expenses}
                onAddExpense={handleOpenNewExpense}
                onEditExpense={handleOpenEditExpense}
              />
            </RouteGuard>
          )}

          {activeTab === 'requests' && (
            <CustomerRequestsView
              requests={requests}
              customers={customers}
              onGenerateInvoice={handleGenerateInvoiceFromRequest}
            />
          )}

          {activeTab === 'projects' && (
            <ProjectsShowcaseView
              projects={projects}
              onRequestSystem={(proj) => {
                handleTabChange('requests');
              }}
            />
          )}

          {activeTab === 'reports' && (
            <RouteGuard
              routePath="/reports"
              routeName="Financial Reports & Analytics"
              allowedRoles={['super_admin', 'invoice_manager']}
              requiredPermission="canViewReports"
              redirectTo="dashboard"
              onRedirect={handleTabChange}
            >
              <ReportsView
                invoices={invoices}
                payments={payments}
                expenses={expenses}
                settings={settings}
              />
            </RouteGuard>
          )}

          {activeTab === 'staff' && (
            <RouteGuard
              routePath="/staff"
              routeName="Staff & Role-Based Access Control"
              allowedRoles={['super_admin']}
              requiredPermission="canManageStaff"
              redirectTo="dashboard"
              onRedirect={handleTabChange}
            >
              <StaffManagementView
                settings={settings}
                users={users}
                customers={customers}
              />
            </RouteGuard>
          )}

          {activeTab === 'audit' && (
            <RouteGuard
              routePath="/audit-log"
              routeName="System Audit Trail"
              allowedRoles={['super_admin']}
              requiredPermission="canViewAuditLogs"
              redirectTo="dashboard"
              onRedirect={handleTabChange}
            >
              <AuditLogsView
                logs={auditLogs}
              />
            </RouteGuard>
          )}

          {activeTab === 'backup' && (
            <RouteGuard
              routePath="/backup"
              routeName="Backup & Recovery"
              allowedRoles={['super_admin']}
              requiredPermission="canExportBackup"
              redirectTo="dashboard"
              onRedirect={handleTabChange}
            >
              <BackupRestoreView
                stats={{
                  invoicesCount: invoices.length,
                  customersCount: customers.length,
                  paymentsCount: payments.length,
                  expensesCount: expenses.length,
                }}
              />
            </RouteGuard>
          )}

          {activeTab === 'invoice_design' && (
            <RouteGuard
              routePath="/invoice-design"
              routeName="Invoice Designer"
              allowedRoles={['super_admin']}
              requiredPermission="canManageSettings"
              redirectTo="dashboard"
              onRedirect={handleTabChange}
            >
              <InvoiceDesignerView settings={settings} />
            </RouteGuard>
          )}

          {activeTab === 'settings' && (
            <RouteGuard
              routePath="/settings"
              routeName="System & Company Settings"
              allowedRoles={['super_admin']}
              requiredPermission="canManageSettings"
              redirectTo="dashboard"
              onRedirect={handleTabChange}
            >
              <SettingsView settings={settings} />
            </RouteGuard>
          )}

          {activeTab === 'notifications' && (
            <NotificationsView
              notifications={notifications}
              onMarkNotificationRead={markNotificationAsRead}
              onTabChange={handleTabChange}
            />
          )}
        </main>
      </div>

      {/* Global Modals */}
      <InvoiceModal
        isOpen={isInvoiceModalOpen}
        onClose={() => {
          setIsInvoiceModalOpen(false);
          setInvoiceToEdit(null);
          setSourceRequest(null);
          setPreselectedInvoiceCustomer(null);
          setIsInvoiceCustomerLocked(false);
        }}
        customers={customers}
        settings={settings}
        users={users}
        invoiceToEdit={invoiceToEdit}
        preselectedCustomer={preselectedInvoiceCustomer}
        isCustomerLocked={isInvoiceCustomerLocked}
        onSuccess={handleInvoiceCreated}
      />

      <InvoiceDetailModal
        isOpen={Boolean(selectedInvoiceDetail)}
        onClose={() => setSelectedInvoiceDetail(null)}
        invoice={selectedInvoiceDetail}
        payments={payments}
        settings={settings}
        users={users}
        onEdit={(inv) => {
          const paid = Math.max(
            calculateTotalPaidForInvoice(inv.id, payments),
            Number(inv.totalPaid) || 0
          );
          const total = Number(inv.totalAmount) || 0;
          const isLocked = Boolean(
            inv.isLocked ||
            inv.status === 'Paid' ||
            (total > 0 && paid >= total) ||
            (total > 0 && calculateRemaining(total, paid) <= 0)
          );
          if (isLocked) {
            console.warn('Cannot edit locked / fully paid invoice:', inv.billNumber);
            return;
          }
          setSelectedInvoiceDetail(null);
          setInvoiceToEdit(inv);
          setIsInvoiceModalOpen(true);
        }}
      />

      <CustomerModal
        isOpen={isCustomerModalOpen}
        onClose={() => {
          setIsCustomerModalOpen(false);
          setCustomerToEdit(null);
        }}
        customerToEdit={customerToEdit}
        existingCustomers={customers}
        users={users}
        onSelectExistingCustomer={(cust) => setSelectedCustomerDetail(cust)}
      />

      <CustomerDetailModal
        isOpen={Boolean(selectedCustomerDetail)}
        onClose={() => setSelectedCustomerDetail(null)}
        customer={selectedCustomerDetail}
        invoices={invoices}
        payments={payments}
        users={users}
        auditLogs={auditLogs}
        onSelectInvoice={(inv) => {
          setSelectedCustomerDetail(null);
          setSelectedInvoiceDetail(inv);
        }}
        onEditCustomer={(cust) => {
          setSelectedCustomerDetail(null);
          setCustomerToEdit(cust);
          setIsCustomerModalOpen(true);
        }}
        onNewInvoice={(cust) => {
          setSelectedCustomerDetail(null);
          setInvoiceToEdit(null);
          setPreselectedInvoiceCustomer(cust);
          setIsInvoiceCustomerLocked(true);
          setIsInvoiceModalOpen(true);
        }}
        onAddPayment={(cust) => {
          const normSt = normalizeCustomerStatus(cust.status, cust.isArchived);
          const custOutstanding = invoices.find(
            (inv) =>
              inv.customerId === cust.id &&
              inv.status !== 'Paid' &&
              inv.status !== 'Void' &&
              !inv.isVoid &&
              inv.billingState === 'payable'
          );
          if (normSt !== 'Active' && !custOutstanding) {
            console.warn(`Cannot accept standalone payment for ${normSt} customer: ${cust.name}`);
            return;
          }
          setSelectedCustomerDetail(null);
          setPaymentInvoiceId(custOutstanding?.id || undefined);
          setIsPaymentCorrection(false);
          setIsPaymentModalOpen(true);
        }}
        onRefresh={() => {
          if (selectedCustomerDetail) {
            const fresh = customers.find((c) => c.id === selectedCustomerDetail.id);
            if (fresh) setSelectedCustomerDetail(fresh);
          }
        }}
      />

      <PaymentModal
        isOpen={isPaymentModalOpen}
        onClose={() => {
          setIsPaymentModalOpen(false);
          setPaymentInvoiceId(undefined);
          setIsPaymentCorrection(false);
        }}
        invoices={invoices}
        payments={payments}
        preselectedInvoiceId={paymentInvoiceId}
        isCorrectionMode={isPaymentCorrection}
        onSuccess={async (paymentId) => {
          if (paymentId) {
            const found = payments.find((p) => p.id === paymentId);
            if (found) {
              setActiveReceiptPayment(found);
            } else {
              try {
                const freshPayment = await getPaymentById(paymentId);
                if (freshPayment) {
                  setActiveReceiptPayment(freshPayment);
                }
              } catch (e) {
                console.warn('Could not auto-open receipt:', e);
              }
            }
          }
        }}
      />

      {activeReceiptPayment && (
        <PaymentReceiptModal
          isOpen={!!activeReceiptPayment}
          onClose={() => setActiveReceiptPayment(null)}
          payment={activeReceiptPayment}
          invoice={invoices.find((i) => i.id === activeReceiptPayment.invoiceId) || null}
          settings={settings}
        />
      )}

      <ExpenseModal
        isOpen={isExpenseModalOpen}
        onClose={() => {
          setIsExpenseModalOpen(false);
          setExpenseToEdit(null);
        }}
        expenseToEdit={expenseToEdit}
        onSuccess={() => {
          setIsExpenseModalOpen(false);
          setExpenseToEdit(null);
        }}
      />
    </div>
  );
}

export default function App() {
  return (
    <ToastProvider>
      <AuthProvider>
        <MainApplication />
      </AuthProvider>
    </ToastProvider>
  );
}

