export type PaperSize = 'A4' | 'A5' | 'Letter' | 'Custom';
export type PageOrientation = 'portrait' | 'landscape';
export type HeaderLayout =
  | 'logo_left_company_center_logo_right'
  | 'logo_left_company_right'
  | 'company_left_logo_right'
  | 'both_logos_left'
  | 'both_logos_right'
  | 'centered'
  | 'stacked';

export type TextDirection = 'ltr' | 'rtl' | 'auto';
export type TextAlign = 'left' | 'center' | 'right' | 'justify';
export type FontWeight = 'normal' | 'medium' | 'semibold' | 'bold';
export type TableRowMode = 'fixed_20' | 'fixed_15' | 'fixed_10' | 'dynamic';
export type TableBorderStyle = 'all' | 'horizontal_only' | 'vertical_only' | 'none';
export type SignatureStyle = 'dotted_line' | 'solid_line' | 'box';

export type DesignerElement =
  | 'companyEnglishName'
  | 'companyPashtoName'
  | 'companySlogan'
  | 'logoLeft'
  | 'logoRight'
  | 'shapeTopLeft'
  | 'shapeTopRight'
  | 'shapeGoldAccent'
  | 'shapeBottomLeft'
  | 'shapeBottomRight'
  | 'invoiceTitle'
  | 'invoiceMeta'
  | 'billNumber'
  | 'invoiceDate'
  | 'dueDate'
  | 'collector'
  | 'customerInfo'
  | 'customerName'
  | 'customerPhone'
  | 'customerAddress'
  | 'customerEmail'
  | 'customerCompany'
  | 'customerId'
  | 'itemsTable'
  | 'tableHeader'
  | 'tableBody'
  | 'tableColumnSerial'
  | 'tableColumnDescription'
  | 'tableColumnQuantity'
  | 'tableColumnUnit'
  | 'tableColumnUnitPrice'
  | 'tableColumnDiscount'
  | 'tableColumnTax'
  | 'tableColumnTotal'
  | 'paymentInfo'
  | 'paymentMethod'
  | 'paymentStatus'
  | 'paidAmount'
  | 'remainingAmount'
  | 'totals'
  | 'subtotal'
  | 'discountTotal'
  | 'taxTotal'
  | 'grandTotal'
  | 'totalPaid'
  | 'remainingTotal'
  | 'paymentStatusTotal'
  | 'notes'
  | 'signatures'
  | 'signatureCustomer'
  | 'signatureAuthorized'
  | 'footer'
  | 'footerThankYou'
  | 'footerContacts'
  | 'pageNumber';

export interface ShapeConfig {
  show: boolean;
  width: number; // in px
  height: number; // in px
  lockAspectRatio?: boolean; // When true, width/height resize proportionally
  x?: number; // X position offset (px)
  y?: number; // Y position offset (px)
  fillColor: string; // e.g. '#0B1E36'
  accentColor: string; // e.g. '#C5A059'
  opacity: number; // 0 to 1
  border?: 'none' | 'solid' | 'dashed';
  borderWidth: number; // e.g. 2.5
  borderColor?: string;
  borderRadius?: number;
  rotation?: number; // in degrees
  zIndex?: number;
  locked?: boolean;
  padding?: number;
  margin?: number;
}

export interface LogoConfig {
  show: boolean;
  url: string;
  width: number; // in px
  height: number; // in px
  position: 'left' | 'center' | 'right';
  alignment: 'top' | 'center' | 'bottom';
  margin: number;
  opacity: number;
}

export interface TableColumnConfig {
  show: boolean;
  label: string;
  width: string; // e.g. '10%', '46%'
  align: 'left' | 'center' | 'right';
  fontFamily?: string;
  fontSize?: number;
  fontWeight?: FontWeight;
  textColor?: string;
  backgroundColor?: string;
  headerTextColor?: string;
  headerBgColor?: string;
  padding?: number;
  borderWidth?: number;
  borderColor?: string;
  borderStyle?: 'none' | 'solid' | 'dashed';
  locked?: boolean;
  italic?: boolean;
  underline?: boolean;
}

export type TableColumnKey =
  | 'sNo'
  | 'description'
  | 'quantity'
  | 'unit'
  | 'unitPrice'
  | 'discount'
  | 'tax'
  | 'totalAmount';

export const DEFAULT_COLUMN_ORDER: TableColumnKey[] = [
  'sNo',
  'description',
  'quantity',
  'unit',
  'unitPrice',
  'discount',
  'tax',
  'totalAmount',
];

/**
 * Normalizes table column order.
 * Safely migrates legacy reversed column orders:
 * e.g. ['totalAmount', 'unitPrice', 'quantity', 'description', 'sNo']
 * while respecting any intentional forward user-defined column reordering.
 */
export function normalizeTableColumnOrder(savedOrder?: Array<string>): TableColumnKey[] {
  if (!Array.isArray(savedOrder) || savedOrder.length === 0) {
    return [...DEFAULT_COLUMN_ORDER];
  }

  // Detect legacy reversed default order or any reversed sequence where totalAmount precedes sNo
  const hasTotal = savedOrder.indexOf('totalAmount');
  const hasSNo = savedOrder.indexOf('sNo');
  const isLegacyReversed =
    (hasTotal !== -1 && hasSNo !== -1 && hasTotal < hasSNo) ||
    (savedOrder.length >= 2 && savedOrder[0] === 'totalAmount' && savedOrder[savedOrder.length - 1] === 'sNo');

  if (isLegacyReversed) {
    return [...DEFAULT_COLUMN_ORDER];
  }

  const validKeys = DEFAULT_COLUMN_ORDER;
  const filtered = savedOrder.filter((k): k is TableColumnKey => validKeys.includes(k as any));
  if (filtered.length === 0) {
    return [...DEFAULT_COLUMN_ORDER];
  }

  // Append any missing standard keys to ensure complete table functionality
  const missing = validKeys.filter((k) => !filtered.includes(k));
  return [...filtered, ...missing];
}

export type FooterElementId = 'thankYou' | 'contacts' | 'pageNumber';

export const DEFAULT_FOOTER_ELEMENTS_ORDER: FooterElementId[] = [
  'thankYou',
  'contacts',
  'pageNumber',
];

export function normalizeFooterElementsOrder(
  saved?: FooterElementId[] | string[]
): FooterElementId[] {
  const validSet: FooterElementId[] = ['thankYou', 'contacts', 'pageNumber'];
  if (!Array.isArray(saved) || saved.length === 0) {
    return [...DEFAULT_FOOTER_ELEMENTS_ORDER];
  }
  const result: FooterElementId[] = [];
  for (const item of saved) {
    if (validSet.includes(item as FooterElementId) && !result.includes(item as FooterElementId)) {
      result.push(item as FooterElementId);
    }
  }
  for (const item of validSet) {
    if (!result.includes(item)) {
      result.push(item);
    }
  }
  return result;
}

export interface CollectorConfig {
  show: boolean;
  label: string;
  fontSize: number;
  fontWeight: FontWeight;
  fontFamily?: string;
  italic?: boolean;
  underline?: boolean;
  color: string;
  valueColor?: string;
  alignment: 'left' | 'center' | 'right';
}

export interface InvoiceDesignSettings {
  id?: string;
  presetName?: 'sarwan_official' | 'modern_corporate' | 'minimal_clean' | 'classic_formal' | 'compact_tech' | 'custom';
  
  // 1. Page
  page: {
    paperSize: PaperSize;
    orientation: PageOrientation;
    margins: {
      top: number; // in mm
      right: number;
      bottom: number;
      left: number;
    };
    showCornerDecorations?: boolean;
    showPageBorder?: boolean;
  };

  // Decorative Shapes (Design #7 corner diagonal flaps & gold accent line)
  shapes?: {
    topLeft: ShapeConfig;
    topRight: ShapeConfig;
    goldAccent: ShapeConfig;
    bottomLeft?: ShapeConfig;
    bottomRight?: ShapeConfig;
  };

  // 2. Logos
  logos: {
    logo1: LogoConfig;
    logo2: LogoConfig;
  };

  // 3. Company Information
  company: {
    name?: string;
    showName: boolean;
    showPashtoName?: boolean;
    showSubtitle: boolean;
    subtitle: string;
    pashtoName?: string;
    pashtoFontSize?: number;
    pashtoFontFamily?: string;
    pashtoColor?: string;
    slogan?: string;
    sloganFontSize?: number;
    sloganColor?: string;
    sloganFontFamily?: string;
    sloganFontWeight?: FontWeight;
    sloganAlign?: 'left' | 'center' | 'right';
    sloganLineHeight?: number;
    sloganLetterSpacing?: string | number;
    sloganWidth?: number;
    sloganSpacing?: number;
    sloganItalic?: boolean;
    sloganUnderline?: boolean;
    fontFamily?: string;
    fontWeight?: FontWeight;
    italic?: boolean;
    underline?: boolean;
    color?: string;
    showAddress: boolean;
    showPhone: boolean;
    showWhatsapp: boolean;
    showEmail: boolean;
    showWebsite: boolean;
    showAdditionalContact: boolean;
    additionalContact: string;
    fontSize: number;
  };

  // 4. Header
  header: {
    show: boolean;
    height: number;
    headerText: string;
    headerTextSize: number;
    layout: HeaderLayout;
    alignment: 'left' | 'center' | 'right';
    border: 'none' | 'top' | 'bottom' | 'both';
    borderThickness: number;
    borderColor: string;
    backgroundColor: string;
    spacing: number;
    padding: number;
  };

  // 5. Title
  title: {
    show: boolean;
    text: string; // English primary title
    secondaryText: string; // Dari / Pashto Arabic title
    invoiceTitle?: string; // e.g. "INVOICE" or "TAX INVOICE"
    fontSize: number;
    fontWeight: FontWeight;
    fontFamily: string;
    color: string;
    secondaryColor: string;
    alignment: 'left' | 'center' | 'right';
    direction: TextDirection;
    marginTop: number;
    marginBottom: number;
  };

  // 6. Invoice Number
  invoiceNumber: {
    show: boolean;
    label: string;
    secondaryLabel: string;
    fontSize: number;
    fontWeight: FontWeight;
    fontFamily?: string;
    italic?: boolean;
    underline?: boolean;
    color: string;
    valueColor: string;
    alignment: 'left' | 'center' | 'right';
    direction: TextDirection;
    position: 'header_sub' | 'header_right' | 'customer_row';
    borderColor?: string;
    backgroundColor?: string;
    borderStyle?: 'none' | 'solid' | 'dashed';
    borderWidth?: number;
    borderRadius?: number;
  };

  // 6b. Invoice Metadata Container
  invoiceMeta?: {
    backgroundColor?: string;
    borderColor?: string;
    borderStyle?: 'none' | 'solid' | 'dashed';
    borderWidth?: number;
    borderRadius?: number;
  };

  // 7. Date
  date: {
    show: boolean;
    showDueDate?: boolean;
    label: string;
    secondaryLabel: string;
    dueDateLabel?: string;
    format: 'YYYY-MM-DD' | 'DD/MM/YYYY' | 'MM/DD/YYYY' | 'localized';
    fontSize: number;
    fontWeight?: FontWeight;
    fontFamily?: string;
    italic?: boolean;
    underline?: boolean;
    color: string;
    valueColor?: string;
    alignment: 'left' | 'center' | 'right';
    direction: TextDirection;
  };

  // 8. Customer Information
  customer: {
    show: boolean;
    position: 'left' | 'center' | 'right' | 'split_with_date';
    sectionTitle?: string;
    label: string;
    nameLabel?: string;
    phoneLabel?: string;
    addressLabel?: string;
    emailLabel?: string;
    secondaryLabel: string;
    showName: boolean;
    showPhone: boolean;
    showEmail: boolean;
    showAddress: boolean;
    showCompany: boolean;
    showCustomerId: boolean;
    fontSize: number;
    fontWeight: FontWeight;
    fontFamily?: string;
    nameFontFamily?: string;
    phoneFontFamily?: string;
    addressFontFamily?: string;
    emailFontFamily?: string;
    italic?: boolean;
    underline?: boolean;
    color: string;
    alignment: 'left' | 'center' | 'right';
    direction: TextDirection;
    spacing: number;
    borderColor?: string;
    backgroundColor?: string;
    nameFontSize?: number;
    phoneFontSize?: number;
    addressFontSize?: number;
    emailFontSize?: number;
    companyFontSize?: number;
    customerIdFontSize?: number;
    companyLabel?: string;
    customerIdLabel?: string;
    companyFontFamily?: string;
    customerIdFontFamily?: string;
    companyFontWeight?: FontWeight;
    customerIdFontWeight?: FontWeight;
    nameFontWeight?: FontWeight;
    phoneFontWeight?: FontWeight;
    addressFontWeight?: FontWeight;
    emailFontWeight?: FontWeight;
    companyColor?: string;
    companyValueColor?: string;
    customerIdColor?: string;
    customerIdValueColor?: string;
    nameLabelColor?: string;
    nameValueColor?: string;
    phoneLabelColor?: string;
    phoneValueColor?: string;
    addressLabelColor?: string;
    addressValueColor?: string;
    emailLabelColor?: string;
    emailValueColor?: string;
    nameItalic?: boolean;
    nameUnderline?: boolean;
    phoneItalic?: boolean;
    phoneUnderline?: boolean;
    addressItalic?: boolean;
    addressUnderline?: boolean;
    emailItalic?: boolean;
    emailUnderline?: boolean;
    companyItalic?: boolean;
    companyUnderline?: boolean;
    customerIdItalic?: boolean;
    customerIdUnderline?: boolean;
  };

  // 8b. Assigned Collector (display collector name only, never photo)
  collector: CollectorConfig;

  // 9. Items Table
  itemsTable: {
    show: boolean;
    rowMode: TableRowMode;
    columnOrder: Array<
      'sNo' | 'description' | 'quantity' | 'unit' | 'unitPrice' | 'discount' | 'tax' | 'totalAmount'
    >;
    columns: {
      sNo: TableColumnConfig;
      description: TableColumnConfig;
      quantity: TableColumnConfig;
      unit: TableColumnConfig;
      unitPrice: TableColumnConfig;
      discount: TableColumnConfig;
      tax: TableColumnConfig;
      totalAmount: TableColumnConfig;
    };
    headerBgColor: string;
    headerTextColor: string;
    headerFontSize: number;
    headerFontWeight: FontWeight;
    headerFontFamily?: string;
    headerItalic?: boolean;
    headerUnderline?: boolean;
    headerAlignment: 'left' | 'center' | 'right';
    bodyFontSize: number;
    bodyFontWeight?: FontWeight;
    bodyFontFamily?: string;
    bodyItalic?: boolean;
    bodyUnderline?: boolean;
    rowHeight: number;
    bodyAlignment: 'left' | 'center' | 'right';
    borderStyle: TableBorderStyle;
    borderThickness: number;
    borderColor: string;
    backgroundColor?: string;
    tableBorderColor?: string;
    tableBorderStyle?: 'none' | 'solid' | 'dashed';
    tableBorderWidth?: number;
    tableBorderRadius?: number;
    padding: number;
    useZebraStriping: boolean;
    alternateRowColor: string;
    spacingTop: number;
    spacingBottom: number;
  };

  // 10. Totals Section
  totals: {
    show: boolean;
    position: 'left' | 'right';
    width: string; // e.g. '32%' or '40%'
    showSubtotal: boolean;
    subtotalLabel: string;
    subtotalFontSize?: number;
    subtotalFontFamily?: string;
    subtotalFontWeight?: FontWeight;
    subtotalColor?: string;
    subtotalValueColor?: string;
    subtotalItalic?: boolean;
    subtotalUnderline?: boolean;

    showDiscount: boolean;
    discountLabel: string;
    discountFontSize?: number;
    discountFontFamily?: string;
    discountFontWeight?: FontWeight;
    discountColor?: string;
    discountValueColor?: string;
    discountItalic?: boolean;
    discountUnderline?: boolean;

    showTax: boolean;
    taxLabel: string;
    taxFontSize?: number;
    taxFontFamily?: string;
    taxFontWeight?: FontWeight;
    taxColor?: string;
    taxValueColor?: string;
    taxItalic?: boolean;
    taxUnderline?: boolean;

    showGrandTotal: boolean;
    grandTotalLabel: string;
    grandTotalFontSize?: number;
    grandTotalFontFamily?: string;
    grandTotalFontWeight?: FontWeight;
    grandTotalColor?: string;
    grandTotalValueColor?: string;
    grandTotalBg?: string;
    grandTotalItalic?: boolean;
    grandTotalUnderline?: boolean;

    showTotalPaid: boolean;
    totalPaidLabel: string;
    totalPaidFontSize?: number;
    totalPaidFontFamily?: string;
    totalPaidFontWeight?: FontWeight;
    totalPaidColor?: string;
    totalPaidValueColor?: string;
    totalPaidItalic?: boolean;
    totalPaidUnderline?: boolean;

    showRemaining: boolean;
    remainingLabel: string;
    remainingFontSize?: number;
    remainingFontFamily?: string;
    remainingFontWeight?: FontWeight;
    remainingColor?: string;
    remainingValueColor?: string;
    remainingItalic?: boolean;
    remainingUnderline?: boolean;

    showPaymentStatus: boolean;
    paymentStatusTotalFontSize?: number;
    paymentStatusTotalFontFamily?: string;
    paymentStatusTotalFontWeight?: FontWeight;
    paymentStatusTotalColor?: string;
    paymentStatusTotalValueColor?: string;
    paymentStatusTotalItalic?: boolean;
    paymentStatusTotalUnderline?: boolean;

    fontSize: number;
    fontWeight: FontWeight;
    fontFamily?: string;
    italic?: boolean;
    underline?: boolean;
    color: string;
    valueColor: string;
    borderColor: string;
    backgroundColor: string;
    borderStyle?: 'none' | 'solid' | 'dashed';
    borderWidth?: number;
    borderRadius?: number;
  };

  // 11. Payment Section
  payment: {
    show: boolean;
    showMethod?: boolean;
    methodLabel?: string;
    methodFontSize?: number;
    methodFontFamily?: string;
    methodFontWeight?: FontWeight;
    methodColor?: string;
    methodValueColor?: string;
    methodItalic?: boolean;
    methodUnderline?: boolean;

    showPaymentStatusBadge: boolean;
    statusLabel: string;
    statusFontSize?: number;
    statusFontFamily?: string;
    statusFontWeight?: FontWeight;
    statusColor?: string;
    statusValueColor?: string;
    statusItalic?: boolean;
    statusUnderline?: boolean;

    showPaid: boolean;
    paidLabel: string;
    paidFontSize?: number;
    paidFontFamily?: string;
    paidFontWeight?: FontWeight;
    paidColor?: string;
    paidValueColor?: string;
    paidItalic?: boolean;
    paidUnderline?: boolean;

    showRemaining: boolean;
    remainingLabel: string;
    remainingFontSize?: number;
    remainingFontFamily?: string;
    remainingFontWeight?: FontWeight;
    remainingColor?: string;
    remainingValueColor?: string;
    remainingItalic?: boolean;
    remainingUnderline?: boolean;

    showSubtotal: boolean;
    showDiscount: boolean;
    showTotal: boolean;
    showPaymentHistorySummary: boolean;
    subtotalLabel: string;
    discountLabel: string;
    totalLabel: string;
    borderColor?: string;
    backgroundColor?: string;
    textColor?: string;
    fontSize?: number;
    fontWeight?: FontWeight;
    fontFamily?: string;
    italic?: boolean;
    underline?: boolean;
  };

  // 12. Notes
  notes: {
    showInvoiceNote: boolean;
    notesLabel?: string;
    invoiceNoteText: string;
    invoiceNoteFontSize: number;
    invoiceNoteFontFamily: string;
    invoiceNoteFontWeight: FontWeight;
    italic?: boolean;
    underline?: boolean;
    invoiceNoteColor: string;
    invoiceNoteAlign: TextAlign;
    invoiceNoteDirection: TextDirection;
    invoiceNoteSpacing: number;
    invoiceNoteBorder: boolean;
    borderColor?: string;
    invoiceNoteBgColor: string;
    showFooterNote: boolean;
    footerNoteText: string;
    showAdditionalNote: boolean;
    additionalNoteText: string;
  };

  // 13. Signatures
  signatures: {
    show: boolean;
    showManagerSignature: boolean;
    managerSignatureLabel: string;
    showCustomerSignature: boolean;
    customerSignatureLabel: string;
    signatureStyle: SignatureStyle;
    managerSignatureImage?: string;
    customerSignatureImage?: string;
    width: string;
    height: number;
    alignment: 'left' | 'center' | 'right';
    borderColor?: string;
    fontSize?: number;
    fontWeight?: FontWeight;
    fontFamily?: string;
    managerFontFamily?: string;
    customerFontFamily?: string;
    customerFontSize?: number;
    managerFontSize?: number;
    customerFontWeight?: FontWeight;
    managerFontWeight?: FontWeight;
    customerColor?: string;
    managerColor?: string;
    customerBorderColor?: string;
    managerBorderColor?: string;
    customerWidth?: string;
    managerWidth?: string;
    customerHeight?: number;
    managerHeight?: number;
    customerSignatureStyle?: SignatureStyle;
    managerSignatureStyle?: SignatureStyle;
    italic?: boolean;
    underline?: boolean;
    color?: string;
  };

  // 14. Footer
  footer: {
    show: boolean;
    showThankYou?: boolean;
    showContacts?: boolean;
    footerText: string;
    showPhone: boolean;
    showWhatsapp: boolean;
    showEmail: boolean;
    showWebsite: boolean;
    showAddress: boolean;
    phoneLabel?: string;
    whatsappLabel?: string;
    emailLabel?: string;
    addressLabel?: string;
    websiteLabel?: string;
    fontSize: number;
    fontWeight: FontWeight;
    fontFamily?: string;
    thankYouFontFamily?: string;
    contactsFontFamily?: string;
    thankYouFontSize?: number;
    thankYouFontWeight?: FontWeight;
    thankYouColor?: string;
    contactsFontSize?: number;
    contactsColor?: string;
    padding?: number;
    paddingLeft?: number;
    paddingRight?: number;
    height?: number;
    italic?: boolean;
    underline?: boolean;
    lineHeight?: number;
    color: string;
    alignment: 'left' | 'center' | 'right';
    direction: TextDirection;
    spacing: number;
    topSpacing: number;
    bottomSpacing: number;
    borderTop: boolean;
    borderColor: string;
    backgroundColor: string;
    borderStyle?: 'none' | 'solid' | 'dashed';
    borderWidth?: number;
    borderRadius?: number;
    layoutMode?: 'full_width' | 'contained';
    accentColor?: string;
    accentLineWidth?: number;
    accentLineHeight?: number;
    accentLineColor?: string;
    showAccentLines?: boolean;
    footerElementsOrder?: FooterElementId[];
  };

  // 15. Page Number
  pageNumber: {
    show: boolean;
    format: 'page_x_of_y' | 'page_x' | 'simple';
    position: 'bottom_right' | 'bottom_center' | 'bottom_left';
    fontSize: number;
    fontWeight?: FontWeight;
    fontFamily?: string;
    italic?: boolean;
    underline?: boolean;
    color: string;
  };

  // 16. Typography
  typography: {
    fontFamily: string;
    headingFontFamily: string;
    baseFontSize: number;
    headerFontSize: number;
    titleFontSize: number;
    companyNameFontSize?: number;
    pashtoFontSize?: number;
    sloganFontSize?: number;
    sectionHeadingFontSize?: number;
    tableFontSize: number;
    tableHeaderFontSize: number;
    footerFontSize: number;
    footerFontWeight?: FontWeight;
    footerLineHeight?: number;
    lineHeight: number;
  };

  // 17. Colors
  colors: {
    primary: string;
    secondary: string;
    accent?: string;
    text: string;
    mutedText?: string;
    background: string;
    cardBackground?: string;
    headerBackground: string;
    tableHeaderBackground: string;
    tableHeaderText: string;
    border: string;
    footerBackground: string;
    footerText?: string;
    footerAccent?: string;
    grandTotalBackground?: string;
    grandTotalText?: string;
  };

  // 18. Spacing (Canonical Section Gap Model)
  spacing: {
    // Canonical Section Gap Keys
    headerToMeta?: number;
    metaToCustomer?: number;
    customerToTable?: number;
    tableToPayment?: number;
    paymentToTotals?: number;
    totalsToNotes?: number;
    notesToSignatures?: number;
    footerSpacing: number;

    // Layout geometry & inner paddings
    sectionSpacing: number; // in px
    headerSpacing: number;
    tablePadding: number;
    tableSpacing: number;
    rowHeight: number;
    customerSpacing: number;
    paymentSpacing?: number;
    totalsSpacing: number;
    internalPadding: number;

    // Legacy gap aliases (backward compatibility)
    metaSpacing?: number;
    metaToCustomerSpacing?: number;
    customerToTableSpacing?: number;
    tableToPaymentSpacing?: number;
    paymentToTotalsSpacing?: number;
    totalsToNotesSpacing?: number;
    notesToSignaturesSpacing?: number;
  };

  // 19. Central Section Visibility Checklist
  visibility: {
    header: boolean;
    logo1: boolean;
    logo2: boolean;
    companyInfo: boolean;
    invoiceTitle: boolean;
    invoiceNumber: boolean;
    date: boolean;
    customerInfo: boolean;
    collector: boolean;
    itemsTable: boolean;
    subtotal: boolean;
    discount: boolean;
    tax: boolean;
    total: boolean;
    paid: boolean;
    remaining: boolean;
    paymentStatus: boolean;
    notes: boolean;
    signatures: boolean;
    footer: boolean;
    pageNumber: boolean;
  };

  // 20. Section Order
  sectionOrder: string[];
}

/**
 * The official Sarwan Technology Default Invoice Design
 * (Reflects the authentic 20-row CCTV security official billing format)
 */
export const DEFAULT_INVOICE_DESIGN: InvoiceDesignSettings = {
  presetName: 'sarwan_official',
  page: {
    paperSize: 'A4',
    orientation: 'portrait',
    margins: {
      top: 12,
      right: 12,
      bottom: 12,
      left: 12,
    },
    showCornerDecorations: true,
    showPageBorder: false,
  },
  shapes: {
    topLeft: {
      show: true,
      width: 130,
      height: 65,
      x: 0,
      y: 0,
      fillColor: '#0B1E36',
      accentColor: '#C5A059',
      opacity: 1,
      border: 'none',
      borderWidth: 2.5,
      borderRadius: 0,
      rotation: 0,
      zIndex: 20,
      locked: false,
    },
    topRight: {
      show: true,
      width: 130,
      height: 65,
      x: 0,
      y: 0,
      fillColor: '#0B1E36',
      accentColor: '#C5A059',
      opacity: 1,
      border: 'none',
      borderWidth: 2.5,
      borderRadius: 0,
      rotation: 0,
      zIndex: 20,
      locked: false,
    },
    goldAccent: {
      show: true,
      width: 130,
      height: 65,
      x: 0,
      y: 0,
      fillColor: '#C5A059',
      accentColor: '#C5A059',
      opacity: 1,
      border: 'none',
      borderWidth: 2.5,
      borderRadius: 0,
      rotation: 0,
      zIndex: 20,
      locked: false,
    },
    bottomLeft: {
      show: true,
      width: 130,
      height: 65,
      x: 0,
      y: 0,
      fillColor: '#0B1E36',
      accentColor: '#C5A059',
      opacity: 1,
      border: 'none',
      borderWidth: 2.5,
      borderRadius: 0,
      rotation: 0,
      zIndex: 20,
      locked: false,
    },
    bottomRight: {
      show: true,
      width: 130,
      height: 65,
      x: 0,
      y: 0,
      fillColor: '#0B1E36',
      accentColor: '#C5A059',
      opacity: 1,
      border: 'none',
      borderWidth: 2.5,
      borderRadius: 0,
      rotation: 0,
      zIndex: 20,
      locked: false,
    },
  },
  logos: {
    logo1: {
      show: true,
      url: '/sarwan-logo.png',
      width: 140,
      height: 64,
      position: 'left',
      alignment: 'center',
      margin: 0,
      opacity: 1,
    },
    logo2: {
      show: true,
      url: '/dahua-logo.svg',
      width: 140,
      height: 46,
      position: 'right',
      alignment: 'center',
      margin: 0,
      opacity: 1,
    },
  },
  company: {
    name: 'Sarwan Technology',
    showName: true,
    showSubtitle: true,
    subtitle: 'Technology That Works for You',
    pashtoName: 'ساروان تکنالوژي',
    slogan: 'Technology That Works for You',
    sloganFontSize: 10.5,
    sloganColor: '#1E4E8C',
    pashtoFontFamily: '"Scheherazade New", "Amiri", "Noto Naskh Arabic", Arial, sans-serif',
    sloganFontFamily: 'Arial, sans-serif',
    fontFamily: 'Arial, sans-serif',
    showAddress: true,
    showPhone: true,
    showWhatsapp: true,
    showEmail: true,
    showWebsite: true,
    showAdditionalContact: false,
    additionalContact: '',
    fontSize: 11.5,
  },
  header: {
    show: true,
    height: 120,
    headerText: 'Sarwan Technology',
    headerTextSize: 22,
    layout: 'logo_left_company_center_logo_right',
    alignment: 'center',
    border: 'bottom',
    borderThickness: 1,
    borderColor: '#001838',
    backgroundColor: 'transparent',
    spacing: 12,
    padding: 0,
  },
  title: {
    show: true,
    text: 'Sarwan Technology',
    secondaryText: 'ساروان تکنالوژي',
    invoiceTitle: 'INVOICE',
    fontSize: 24,
    fontWeight: 'bold',
    fontFamily: 'serif',
    color: '#001838',
    secondaryColor: '#001838',
    alignment: 'center',
    direction: 'ltr',
    marginTop: 0,
    marginBottom: 4,
  },
  invoiceNumber: {
    show: true,
    label: 'Invoice No:',
    secondaryLabel: 'Invoice No:',
    fontSize: 12,
    fontWeight: 'bold',
    color: '#000000',
    valueColor: '#001838',
    alignment: 'center',
    direction: 'ltr',
    position: 'header_sub',
    borderColor: '#E5E7EB',
    backgroundColor: '#FFFFFF',
    borderStyle: 'solid',
    borderWidth: 1,
    borderRadius: 4,
  },
  invoiceMeta: {
    backgroundColor: '#FFFFFF',
    borderColor: '#E5E7EB',
    borderStyle: 'solid',
    borderWidth: 1,
    borderRadius: 4,
  },
  date: {
    show: true,
    label: 'Invoice Date:',
    secondaryLabel: 'Invoice Date:',
    dueDateLabel: 'Due Date:',
    format: 'YYYY-MM-DD',
    fontSize: 12,
    color: '#000000',
    alignment: 'left',
    direction: 'ltr',
  },
  customer: {
    show: true,
    position: 'split_with_date',
    sectionTitle: 'CUSTOMER INFORMATION',
    label: 'Customer Name:',
    nameLabel: 'Customer Name:',
    phoneLabel: 'Phone:',
    addressLabel: 'Address:',
    emailLabel: 'Email:',
    secondaryLabel: 'Customer Information',
    showName: true,
    showPhone: true,
    showEmail: true,
    showAddress: true,
    showCompany: true,
    showCustomerId: false,
    fontSize: 12,
    fontWeight: 'bold',
    color: '#000000',
    alignment: 'left',
    direction: 'ltr',
    spacing: 8,
    borderColor: '#D8E2EC',
    backgroundColor: '#FFFFFF',
  },
  collector: {
    show: true,
    label: 'Collector:',
    fontSize: 11.5,
    fontWeight: 'bold',
    color: '#000000',
    valueColor: '#0F172A',
    alignment: 'left',
  },
  itemsTable: {
    show: true,
    rowMode: 'fixed_20',
    columnOrder: [...DEFAULT_COLUMN_ORDER],
    columns: {
      sNo: { show: true, label: 'S. No', width: '10%', align: 'center' },
      description: { show: true, label: 'Description', width: '46%', align: 'center' },
      quantity: { show: true, label: 'Quantity', width: '12%', align: 'center' },
      unit: { show: false, label: 'Unit', width: '8%', align: 'center' },
      unitPrice: { show: true, label: 'Price (AFN)', width: '16%', align: 'center' },
      discount: { show: false, label: 'Discount', width: '10%', align: 'center' },
      tax: { show: false, label: 'Tax', width: '8%', align: 'center' },
      totalAmount: { show: true, label: 'Total Amount', width: '16%', align: 'center' },
    },
    headerBgColor: '#001838',
    headerTextColor: '#FFFFFF',
    headerFontSize: 11.5,
    headerFontWeight: 'bold',
    headerFontFamily: 'Arial, sans-serif',
    bodyFontFamily: 'Arial, sans-serif',
    headerAlignment: 'center',
    bodyFontSize: 11,
    rowHeight: 22.5,
    bodyAlignment: 'center',
    borderStyle: 'all',
    borderThickness: 1,
    borderColor: '#000000',
    backgroundColor: '#FFFFFF',
    tableBorderColor: '#D8E2EC',
    tableBorderStyle: 'solid',
    tableBorderWidth: 1,
    tableBorderRadius: 4,
    padding: 4,
    useZebraStriping: false,
    alternateRowColor: '#F9FAFB',
    spacingTop: 8,
    spacingBottom: 8,
  },
  totals: {
    show: true,
    position: 'right',
    width: '320px',
    showSubtotal: true,
    subtotalLabel: 'Subtotal',
    showDiscount: true,
    discountLabel: 'Discount',
    showTax: true,
    taxLabel: 'Tax',
    showGrandTotal: true,
    grandTotalLabel: 'Grand Total',
    showTotalPaid: false,
    totalPaidLabel: 'Paid / Received',
    showRemaining: false,
    remainingLabel: 'Remaining / Balance',
    showPaymentStatus: true,
    fontSize: 12,
    grandTotalFontSize: 12,
    fontWeight: 'bold',
    fontFamily: 'Arial, sans-serif',
    grandTotalFontFamily: 'Arial, sans-serif',
    color: '#000000',
    valueColor: '#000000',
    borderColor: '#E5E7EB',
    backgroundColor: '#FFFFFF',
    borderStyle: 'solid',
    borderWidth: 1,
    borderRadius: 4,
  },
  payment: {
    show: true,
    showSubtotal: true,
    showDiscount: false,
    showTotal: true,
    showPaid: true,
    showRemaining: true,
    showPaymentStatusBadge: true,
    showPaymentHistorySummary: false,
    subtotalLabel: 'Subtotal:',
    discountLabel: 'Discount:',
    totalLabel: 'Total:',
    paidLabel: 'Received:',
    remainingLabel: 'Remaining:',
    statusLabel: 'Payment Status:',
    borderColor: '#D8E2EC',
    backgroundColor: '#FFFFFF',
    textColor: '#0B1E36',
    fontFamily: 'Arial, sans-serif',
    fontSize: 11.5,
  },
  notes: {
    showInvoiceNote: true,
    notesLabel: 'Notes:',
    invoiceNoteText:
      'Thank you for your business. Please contact us if you have any questions regarding this invoice.',
    invoiceNoteFontSize: 11,
    invoiceNoteFontFamily: 'Arial, sans-serif',
    invoiceNoteFontWeight: 'normal',
    invoiceNoteColor: '#374151',
    invoiceNoteAlign: 'left',
    invoiceNoteDirection: 'ltr',
    invoiceNoteSpacing: 6,
    invoiceNoteBorder: true,
    borderColor: '#E5E7EB',
    invoiceNoteBgColor: '#F9FAFB',
    showFooterNote: false,
    footerNoteText: '',
    showAdditionalNote: false,
    additionalNoteText: '',
  },
  signatures: {
    show: true,
    showManagerSignature: true,
    managerSignatureLabel: 'Manager / Authorized Signature',
    showCustomerSignature: true,
    customerSignatureLabel: 'Customer Signature',
    signatureStyle: 'solid_line',
    width: '100%',
    height: 70,
    alignment: 'center',
    borderColor: '#1E4E8C',
    color: '#0B1E36',
    fontSize: 11.5,
    customerFontFamily: 'Arial, sans-serif',
    managerFontFamily: 'Arial, sans-serif',
  },
  footer: {
    show: true,
    footerText: 'Thank you for your business!',
    showPhone: true,
    showWhatsapp: true,
    showEmail: true,
    showWebsite: true,
    showAddress: true,
    phoneLabel: 'Phone:',
    whatsappLabel: 'WhatsApp:',
    emailLabel: 'Email:',
    addressLabel: 'Address:',
    websiteLabel: 'Website:',
    fontSize: 11,
    fontWeight: 'bold',
    fontFamily: 'Arial, sans-serif',
    thankYouFontFamily: 'Arial, sans-serif',
    contactsFontFamily: 'Arial, sans-serif',
    lineHeight: 1.4,
    color: '#FFFFFF',
    alignment: 'center',
    direction: 'ltr',
    spacing: 8,
    topSpacing: 8,
    bottomSpacing: 8,
    borderTop: true,
    borderColor: '#C5A059',
    backgroundColor: '#0B1E36',
    borderStyle: 'solid',
    borderWidth: 2.5,
    borderRadius: 0,
    layoutMode: 'full_width',
    accentColor: '#C5A059',
    accentLineWidth: 56,
    accentLineHeight: 1,
    accentLineColor: '#C5A059',
    showAccentLines: true,
    footerElementsOrder: ['thankYou', 'contacts', 'pageNumber'],
  },
  pageNumber: {
    show: false,
    format: 'page_x_of_y',
    position: 'bottom_right',
    fontSize: 10,
    color: '#6B7280',
  },
  typography: {
    fontFamily: 'Arial, sans-serif',
    headingFontFamily: '"Times New Roman", serif',
    baseFontSize: 12,
    headerFontSize: 22,
    titleFontSize: 26,
    companyNameFontSize: 24,
    pashtoFontSize: 20,
    sloganFontSize: 10.5,
    sectionHeadingFontSize: 11,
    tableFontSize: 11,
    tableHeaderFontSize: 11.5,
    footerFontSize: 11,
    footerFontWeight: 'bold',
    footerLineHeight: 1.4,
    lineHeight: 1.4,
  },
  colors: {
    primary: '#0B1E36',
    secondary: '#1E4E8C',
    accent: '#C5A059',
    text: '#0F172A',
    mutedText: '#64748B',
    background: '#FFFFFF',
    cardBackground: '#F0F7FF',
    headerBackground: 'transparent',
    tableHeaderBackground: '#0B1E36',
    tableHeaderText: '#FFFFFF',
    border: '#D8E2EC',
    footerBackground: '#0B1E36',
    footerText: '#FFFFFF',
    footerAccent: '#C5A059',
    grandTotalBackground: '#1E4E8C',
    grandTotalText: '#FFFFFF',
  },
  spacing: {
    // Canonical Section Gap Keys
    headerToMeta: 8,
    metaToCustomer: 8,
    customerToTable: 8,
    tableToPayment: 10,
    paymentToTotals: 16,
    totalsToNotes: 10,
    notesToSignatures: 10,
    footerSpacing: 8,

    // Layout geometry & inner paddings
    sectionSpacing: 10,
    headerSpacing: 8,
    tablePadding: 4,
    tableSpacing: 8,
    rowHeight: 22.5,
    customerSpacing: 8,
    paymentSpacing: 10,
    totalsSpacing: 10,
    internalPadding: 8,
  },
  visibility: {
    header: true,
    logo1: true,
    logo2: true,
    companyInfo: true,
    invoiceTitle: true,
    invoiceNumber: true,
    date: true,
    customerInfo: true,
    collector: true,
    itemsTable: true,
    subtotal: true,
    discount: true,
    tax: true,
    total: true,
    paid: true,
    remaining: true,
    paymentStatus: false,
    notes: true,
    signatures: true,
    footer: true,
    pageNumber: false,
  },
  sectionOrder: [
    'header',
    'invoice_meta',
    'customer',
    'items_table',
    'totals_and_signatures',
    'notes',
    'footer',
  ],
};

