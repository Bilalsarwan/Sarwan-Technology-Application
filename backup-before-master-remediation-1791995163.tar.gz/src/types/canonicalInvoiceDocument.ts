import { InvoiceDesignSettings } from './invoiceDesign';
import { InvoicePaperConfig } from '../utils/invoicePaperConfig';

export interface CanonicalInvoiceItem {
  sNo: number;
  description: string;
  quantity: number | '';
  unit?: string;
  unitPrice: number | '';
  totalAmount: number;
  discount?: number;
  tax?: number;
}

export interface CanonicalInvoicePage {
  pageNumber: number;
  totalPages: number;
  isFirstPage: boolean;
  isLastPage: boolean;
  items: CanonicalInvoiceItem[];
  showPayment: boolean;
  showNotes: boolean;
  showSignatures: boolean;
}

export interface CanonicalInvoiceDocumentModel {
  id: string;
  billNumber: string;
  date: string;
  displayDate: string;
  dueDate?: string;
  displayDueDate?: string;
  status: 'Unpaid' | 'Partially Paid' | 'Paid' | 'Void' | 'Overdue';
  billingState?: 'quotation' | 'payable' | 'rejected';
  isVoid: boolean;
  isLocked: boolean;

  customer: {
    id?: string;
    name: string;
    phone?: string;
    companyName?: string;
    address?: string;
    email?: string;
  };

  assignedCollector?: {
    id?: string;
    name?: string;
  };
  createdBy?: string;

  company: {
    companyName: string;
    logo?: string;
    logo2?: string;
    phone?: string;
    whatsapp?: string;
    email?: string;
    address?: string;
    website?: string;
    currency: string;
    invoiceNote?: string;
    subtitle?: string;
    footerText?: string;
  };

  items: CanonicalInvoiceItem[];
  pages?: CanonicalInvoicePage[];

  subtotal?: number;
  totalPrice: number;
  totalPaid: number;
  remainingBalance: number;
  totalTax?: number;
  totalDiscount?: number;
  paymentMethod?: string;

  note?: string;

  design: InvoiceDesignSettings;
  paperConfig: InvoicePaperConfig;
}
