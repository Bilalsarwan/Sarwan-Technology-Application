import React, { useState, useMemo, useRef, useCallback, useEffect } from 'react';
import { Invoice, Payment, BusinessSettings, UserProfile, Expense } from '../../types';
import {
  formatAFN,
  formatDate,
  calculateTotalPaidForInvoice,
  calculateRemaining,
  getTodayDateString,
} from '../../utils/format';
import {
  addCashPayment,
  updateInvoiceBillingState,
  deleteInvoicePermanently,
  subscribeToInvoiceExpenses,
  saveInvoiceExpense,
  deleteInvoiceExpense,
  advanceExpenseWorkflow,
  filterExpensesForUser,
} from '../../services/db';
import { toast } from '../../context/ToastContext';
import { buildCanonicalInvoiceDocument } from '../../utils/canonicalInvoiceDocument';
import { CanonicalInvoiceDocument } from './CanonicalInvoiceDocument';
import { PaymentReceiptModal } from '../payment/PaymentReceiptModal';
import { InvoiceAssignmentModal } from './InvoiceAssignmentModal';
import { InvoicePdfDownloadModal } from './InvoicePdfDownloadModal';
import { InternalInvoiceExpenseReportModal } from './InternalInvoiceExpenseReportModal';
import { ExpenseAuditHistoryModal, formatRoleLabel } from '../expense/ExpenseAuditHistoryModal';
import { ExpenseModal } from '../expense/ExpenseModal';
import { ExpenseWorkflowInfoBox } from '../expense/ExpenseWorkflowInfoBox';
import { ExpenseStatusBadge } from '../../utils/expenseStatus';
import { prepareInvoicePrintDocument } from '../../utils/print';
import { useAuth } from '../../context/AuthContext';
import { canUserCollectForInvoice } from '../../services/dashboardAuthorization';
import {
  canAccessPurchaseCost,
  calculateInvoiceProfitSummary,
  calculateInvoiceExpenseSummary,
} from '../../utils/purchaseCostCalculator';
import {
  X,
  Download,
  Printer,
  PlusCircle,
  Clock,
  CheckCircle2,
  AlertTriangle,
  FileText,
  DollarSign,
  TrendingUp,
  User,
  Building,
  Phone,
  MapPin,
  Eye,
  Loader2,
  Receipt,
  Lock,
  Ban,
  UserCheck,
  History,
  Pencil,
  Trash2,
  Check,
  AlertCircle,
  XCircle,
  ChevronUp,
  ChevronDown,
  RotateCcw,
  ShieldAlert,
} from 'lucide-react';

interface InvoiceDetailModalProps {
  invoice: Invoice | null;
  payments: Payment[];
  settings: BusinessSettings;
  isOpen: boolean;
  onClose: () => void;
  onEdit?: (invoice: Invoice) => void;
  onRefresh?: () => void;
  onDelete?: (invoiceId: string) => void;
  users?: UserProfile[];
  expenses?: Expense[];
}

export const InvoiceDetailModal: React.FC<InvoiceDetailModalProps> = ({
  invoice,
  payments,
  settings,
  isOpen,
  onClose,
  onEdit,
  onRefresh,
  onDelete,
  users = [],
  expenses: propExpenses,
}) => {
  const { currentUser, userProfile, permissions } = useAuth();
  const [showAddPayment, setShowAddPayment] = useState<boolean>(false);
  const [isAssignModalOpen, setIsAssignModalOpen] = useState<boolean>(false);
  const [showHistoryLogs, setShowHistoryLogs] = useState<boolean>(false);
  const [paymentAmount, setPaymentAmount] = useState<number | ''>('');
  const [paymentDate, setPaymentDate] = useState<string>(getTodayDateString());
  const [paymentNote, setPaymentNote] = useState<string>('');
  const [submittingPayment, setSubmittingPayment] = useState<boolean>(false);
  const [paymentError, setPaymentError] = useState<string | null>(null);
  const [showPrintPreview, setShowPrintPreview] = useState<boolean>(false);
  const [isPdfModalOpen, setIsPdfModalOpen] = useState<boolean>(false);
  const [pdfError, setPdfError] = useState<string | null>(null);
  const [selectedReceiptPayment, setSelectedReceiptPayment] = useState<Payment | null>(null);

  // Billing state action modals and execution states
  const [isStateChanging, setIsStateChanging] = useState<boolean>(false);
  const [stateChangeAction, setStateChangeAction] = useState<'payable' | 'rejected' | null>(null);
  const [showStateConfirmModal, setShowStateConfirmModal] = useState<boolean>(false);
  const [showDeleteConfirmModal, setShowDeleteConfirmModal] = useState<boolean>(false);
  const [isDeleting, setIsDeleting] = useState<boolean>(false);
  const [actionError, setActionError] = useState<string | null>(null);
  const [actionSuccess, setActionSuccess] = useState<string | null>(null);

  // Invoice Expenses Management State
  const [invoiceExpenses, setInvoiceExpenses] = useState<Expense[]>([]);
  const [isExpenseFormOpen, setIsExpenseFormOpen] = useState<boolean>(false);
  const [editingExpense, setEditingExpense] = useState<Expense | null>(null);
  const [expenseTitle, setExpenseTitle] = useState<string>('');
  const [expenseAmount, setExpenseAmount] = useState<number | ''>('');
  const [expenseDate, setExpenseDate] = useState<string>(getTodayDateString());
  const [expenseCategory, setExpenseCategory] = useState<string>('General Operations');
  const [expenseNote, setExpenseNote] = useState<string>('');
  const [savingExpense, setSavingExpense] = useState<boolean>(false);
  const [expenseFormError, setExpenseFormError] = useState<string | null>(null);
  const [expenseCorrections, setExpenseCorrections] = useState<string>('');
  const [expenseToDelete, setExpenseToDelete] = useState<Expense | null>(null);
  const [isDeletingExpense, setIsDeletingExpense] = useState<boolean>(false);
  const [isExpenseReportModalOpen, setIsExpenseReportModalOpen] = useState<boolean>(false);
  const [expenseToReject, setExpenseToReject] = useState<Expense | null>(null);
  const [rejectionReasonInput, setRejectionReasonInput] = useState<string>('');
  const [rejectionError, setRejectionError] = useState<string | null>(null);
  const [isSubmittingRejection, setIsSubmittingRejection] = useState<boolean>(false);
  const [selectedExpenseForHistory, setSelectedExpenseForHistory] = useState<Expense | null>(null);
  const [advancingExpenseId, setAdvancingExpenseId] = useState<string | null>(null);
  const [expandedWorkflowExpenseId, setExpandedWorkflowExpenseId] = useState<string | null>(null);
  const lastFocusedExpenseTriggerRef = useRef<HTMLElement | null>(null);

  // Dedicated Disbursement & Execution Dialog State (Phase 3 Hardening)
  const [expenseToDisburse, setExpenseToDisburse] = useState<Expense | null>(null);
  const [disbursedAmountInput, setDisbursedAmountInput] = useState<string>('');
  const [disbursementMethodInput, setDisbursementMethodInput] = useState<string>('Cash');
  const [disbursementDateInput, setDisbursementDateInput] = useState<string>('');
  const [disbursementRefInput, setDisbursementRefInput] = useState<string>('');
  const [disbursementNoteInput, setDisbursementNoteInput] = useState<string>('');
  const [isSubmittingDisbursement, setIsSubmittingDisbursement] = useState<boolean>(false);
  const [disbursementError, setDisbursementError] = useState<string | null>(null);

  // Responsive A4 Preview Scaling (calculates available width, scales document uniformly, maintains 210x297mm A4 aspect ratio)
  const previewContainerRef = useRef<HTMLDivElement>(null);
  const docRef = useRef<HTMLDivElement>(null);
  const [fitScale, setFitScale] = useState<number>(1);
  const [docHeight, setDocHeight] = useState<number>(1123);
  const [isFitMode, setIsFitMode] = useState<boolean>(true);
  const [manualZoom, setManualZoom] = useState<number>(1);

  const activeScale = isFitMode ? fitScale : manualZoom;

  const updatePreviewScale = useCallback(() => {
    const container = previewContainerRef.current;
    if (!container) return;
    const containerWidth = container.clientWidth;
    if (containerWidth <= 0) return;

    // Responsive horizontal padding based on container width:
    // 8px on mobile (<= 400px), 12px (401-640px), 16px (641-1024px), 24px on desktop (> 1024px)
    const minPadding = containerWidth <= 400 ? 8 : containerWidth <= 640 ? 12 : containerWidth <= 1024 ? 16 : 24;
    const availableWidth = Math.max(60, containerWidth - minPadding * 2);

    // Standard A4 width is 210mm (~793.7px at 96 CSS DPI: 210 * 96 / 25.4)
    const a4WidthPx = 793.7;
    const rawScale = availableWidth / a4WidthPx;
    // On desktop: readable size (up to 1.0); on tablet & mobile: automatically scale down to fit available width
    const calculatedScale = Math.max(0.2, Math.min(1.0, Math.round(rawScale * 1000) / 1000));
    setFitScale(calculatedScale);

    if (docRef.current) {
      const h = docRef.current.offsetHeight;
      if (h > 0) {
        setDocHeight(h);
      }
    }
  }, []);

  useEffect(() => {
    if (!showPrintPreview) return;

    // Initial scale calculation immediately and on next frame
    updatePreviewScale();
    const rafId = requestAnimationFrame(() => {
      updatePreviewScale();
    });

    const container = previewContainerRef.current;
    let resizeObserver: ResizeObserver | null = null;
    if (typeof ResizeObserver !== 'undefined') {
      resizeObserver = new ResizeObserver(() => {
        updatePreviewScale();
      });
      if (container) resizeObserver.observe(container);
      if (docRef.current) resizeObserver.observe(docRef.current);
    }

    const handleWindowResize = () => {
      updatePreviewScale();
    };

    window.addEventListener('resize', handleWindowResize);
    window.addEventListener('orientationchange', handleWindowResize);

    return () => {
      cancelAnimationFrame(rafId);
      if (resizeObserver) resizeObserver.disconnect();
      window.removeEventListener('resize', handleWindowResize);
      window.removeEventListener('orientationchange', handleWindowResize);
    };
  }, [showPrintPreview, updatePreviewScale]);

  const invoicePayments = useMemo(() => {
    if (!invoice) return [];
    return payments.filter((p) => p.invoiceId === invoice.id);
  }, [invoice, payments]);

  const totalPaid = useMemo(() => {
    if (!invoice) return 0;
    return Math.max(
      calculateTotalPaidForInvoice(invoice.id, payments),
      Number(invoice.totalPaid) || 0
    );
  }, [invoice, payments]);

  const total = invoice ? Number(invoice.totalAmount) || 0 : 0;
  const isVoid = Boolean(invoice && (invoice.isVoid === true || invoice.status === 'Void'));
  const isQuotation = invoice?.billingState === 'quotation';
  const isRejected = invoice?.billingState === 'rejected';
  const isPayable = !isQuotation && !isRejected;

  const remaining = isVoid ? 0 : calculateRemaining(total, totalPaid);
  const isLockedOrPaid = Boolean(
    isVoid ||
    invoice?.isLocked ||
    invoice?.status === 'Paid' ||
    (total > 0 && totalPaid >= total) ||
    remaining <= 0
  );
  const canCollect = Boolean(
    !isVoid &&
    !isLockedOrPaid &&
    isPayable &&
    canUserCollectForInvoice(userProfile, invoice) &&
    permissions.canRecordPayment
  );

  const canAssign = Boolean(
    !isVoid &&
    !isLockedOrPaid &&
    isPayable &&
    (userProfile?.role === 'super_admin' ||
      userProfile?.role === 'invoice_manager' ||
      permissions?.canAssignInvoice) &&
    userProfile?.role !== 'customer' &&
    userProfile?.role !== 'payment_collector'
  );

  const assignedCollectorProfile = useMemo(() => {
    if (!invoice?.assignedCollectorId || !users) return null;
    return users.find((u) => u.id === invoice.assignedCollectorId) || null;
  }, [invoice?.assignedCollectorId, users]);

  const isAuthorizedForProfitSummary = useMemo(() => {
    return canAccessPurchaseCost(userProfile?.role);
  }, [userProfile?.role]);

  const canAccessInvoiceExpenses = useMemo(() => {
    const role = userProfile?.role;
    return role === 'super_admin' || role === 'invoice_manager' || role === 'payment_collector';
  }, [userProfile?.role]);

  // Requirement 7: Super Admin CANNOT create or submit expense requests.
  // Creation is restricted exclusively to Invoice Managers and Payment Collectors.
  const canAddExpense = useMemo(() => {
    const role = userProfile?.role;
    return role === 'invoice_manager' || role === 'payment_collector';
  }, [userProfile?.role]);

  // Real-time subscription to invoice expenses for authorized users
  useEffect(() => {
    if (!isOpen || !invoice?.id || !canAccessInvoiceExpenses) {
      setInvoiceExpenses([]);
      setIsExpenseFormOpen(false);
      setEditingExpense(null);
      setExpenseToDelete(null);
      setExpenseToReject(null);
      setSelectedExpenseForHistory(null);
      setExpandedWorkflowExpenseId(null);
      return;
    }

    // Reset editing and delete dialogs on invoice switch
    setIsExpenseFormOpen(false);
    setEditingExpense(null);
    setExpenseToDelete(null);
    setExpandedWorkflowExpenseId(null);

    // Immediately isolate to this invoice and filter according to user role to prevent privacy leaks
    const invoiceOnly = (propExpenses || []).filter((e) => e.invoiceId === invoice.id);
    const initial = filterExpensesForUser(invoiceOnly, userProfile?.role, userProfile?.id);
    setInvoiceExpenses(initial);

    const unsub = subscribeToInvoiceExpenses(
      invoice.id,
      (data) => {
        setInvoiceExpenses(data);
      },
      (err) => {
        console.warn('Invoice expenses listener error:', err);
      },
      userProfile?.role,
      userProfile?.id
    );

    return () => unsub();
  }, [isOpen, invoice?.id, userProfile?.role, userProfile?.id, propExpenses]);

  const profitSummary = useMemo(() => {
    if (!invoice || !isAuthorizedForProfitSummary) return null;
    return calculateInvoiceProfitSummary(invoice.items || [], invoiceExpenses, invoice.id);
  }, [invoice, isAuthorizedForProfitSummary, invoiceExpenses]);

  const expenseSummary = useMemo(() => {
    return calculateInvoiceExpenseSummary(invoiceExpenses || [], invoice?.id);
  }, [invoiceExpenses, invoice?.id]);

  const canonicalDoc = useMemo(() => {
    if (!invoice) return null;
    return buildCanonicalInvoiceDocument({
      invoice,
      payments,
      totalPaidOverride: totalPaid,
      settings,
      userProfile,
    });
  }, [invoice, payments, totalPaid, settings, userProfile]);

  // Pre-warm the print document in #invoice-print-root while InvoiceDetailModal is open
  useEffect(() => {
    if (!isOpen || !canonicalDoc) return;
    prepareInvoicePrintDocument(canonicalDoc).catch((err) => {
      console.warn('Pre-warming print document in InvoiceDetailModal:', err);
    });
  }, [isOpen, canonicalDoc]);

  const handleDownloadPdf = () => {
    if (!invoice) return;
    setIsPdfModalOpen(true);
  };

  const handleAddPayment = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!invoice) return;

    const amountNum = Number(paymentAmount);
    if (!amountNum || amountNum <= 0) {
      setPaymentError('Please enter a valid cash amount greater than 0.');
      return;
    }
    if (amountNum > remaining) {
      setPaymentError(`Amount cannot exceed remaining balance of ${formatAFN(remaining)}.`);
      return;
    }

    // Payment Date validation (Payment Date <= Today)
    const todayStr = getTodayDateString();
    if (!paymentDate || paymentDate > todayStr) {
      setPaymentError('Payment date cannot be in the future (Payment Date must be on or before today).');
      return;
    }

    setSubmittingPayment(true);
    setPaymentError(null);

    try {
      await addCashPayment({
        invoiceId: invoice.id,
        billNumber: invoice.billNumber,
        customerId: invoice.customerId,
        customerName: invoice.customerSnapshot?.name || 'Customer',
        amount: amountNum,
        date: paymentDate,
        note: paymentNote.trim(),
        userId: userProfile?.id,
        userName: userProfile?.name,
        userRole: userProfile?.role,
      });

      toast.success(`Payment of ${formatAFN(amountNum)} recorded successfully.`);
      setPaymentAmount('');
      setPaymentNote('');
      setShowAddPayment(false);
    } catch (err: any) {
      console.error('Error adding payment:', err);
      const errMsg = err.message || 'Failed to record cash payment.';
      setPaymentError(errMsg);
      toast.error(errMsg);
    } finally {
      setSubmittingPayment(false);
    }
  };

  const handleUpdateBillingState = async (newState: 'payable' | 'rejected') => {
    if (!invoice || !userProfile) return;
    setIsStateChanging(true);
    setActionError(null);
    try {
      await updateInvoiceBillingState({
        invoiceId: invoice.id,
        newState,
        actorId: userProfile.id,
        actorName: userProfile.name || (userProfile.role === 'customer' ? 'Customer' : 'Staff'),
        actorRole: userProfile.role || 'customer',
        source: userProfile.role === 'customer' ? 'Customer Portal' : 'Admin Panel',
      });
      const successMsg =
        newState === 'payable'
          ? 'Quotation has been accepted and marked as payable.'
          : 'Quotation has been rejected.';
      setActionSuccess(successMsg);
      toast.success(successMsg);
      setShowStateConfirmModal(false);
      setStateChangeAction(null);
      if (onRefresh) onRefresh();
    } catch (err: any) {
      console.error('Failed to update billing state:', err);
      const errMsg = err.message || 'Failed to update billing state.';
      setActionError(errMsg);
      toast.error(errMsg);
    } finally {
      setIsStateChanging(false);
    }
  };

  const handleDeletePermanently = async () => {
    if (!invoice || !userProfile) return;
    setIsDeleting(true);
    setActionError(null);
    try {
      await deleteInvoicePermanently({
        invoiceId: invoice.id,
        userId: userProfile.id,
        userName: userProfile.name || 'Admin',
        userRole: userProfile.role,
      });
      toast.success('Invoice deleted permanently.');
      setShowDeleteConfirmModal(false);
      onClose();
      if (onDelete) onDelete(invoice.id);
      if (onRefresh) onRefresh();
    } catch (err: any) {
      console.error('Failed to permanently delete invoice:', err);
      const errMsg = err.message || 'Failed to delete invoice.';
      setActionError(errMsg);
      toast.error(errMsg);
    } finally {
      setIsDeleting(false);
    }
  };

  const handleOpenAddExpense = () => {
    if (userProfile?.role === 'super_admin') {
      toast.error('Super Admin cannot create or submit expense requests. Expense creation is restricted to Invoice Managers and Payment Collectors.');
      return;
    }
    lastFocusedExpenseTriggerRef.current = (document.activeElement as HTMLElement) || null;
    if (isExpenseFormOpen && !editingExpense) {
      // If already open in add mode, keep existing modal open without duplicating or clearing
      return;
    }
    // If switching from editing an existing expense to adding a new one, clear editing state
    if (editingExpense) {
      setEditingExpense(null);
      setExpenseTitle('');
      setExpenseAmount('');
      setExpenseNote('');
    }
    setExpenseCorrections('');
    if (!expenseDate) {
      setExpenseDate(getTodayDateString());
    }
    if (!expenseCategory) {
      setExpenseCategory('General Operations');
    }
    setExpenseFormError(null);
    setIsExpenseFormOpen(true);
  };

  const handleCloseExpenseForm = () => {
    setIsExpenseFormOpen(false);
    setEditingExpense(null);
    setExpenseCorrections('');
    setExpenseFormError(null);
    if (lastFocusedExpenseTriggerRef.current && typeof lastFocusedExpenseTriggerRef.current.focus === 'function') {
      lastFocusedExpenseTriggerRef.current.focus();
    }
  };

  const handleOpenEditExpense = (exp: Expense) => {
    if (userProfile?.role === 'super_admin') {
      toast.error('Super Admin cannot edit requested expense details. Super Admin may only perform authorized approval or rejection actions.');
      return;
    }
    if (exp.status === 'approved' || exp.status === 'executed') {
      toast.error('Approved expenses are immutable and cannot be edited or resubmitted.');
      return;
    }
    const currentUserId = userProfile?.id || (userProfile as any)?.userId || '';
    const isOwner = Boolean(currentUserId && exp.requestedBy && exp.requestedBy.toLowerCase() === currentUserId.toLowerCase());
    if (exp.status === 'rejected' && !isOwner) {
      toast.error('Only the original authorized requester can edit and resubmit their rejected expense.');
      return;
    }
    lastFocusedExpenseTriggerRef.current = (document.activeElement as HTMLElement) || null;
    setEditingExpense(exp);
    setExpenseTitle(exp.title || exp.description || '');
    setExpenseAmount(exp.amount ?? '');
    setExpenseDate(exp.date || exp.expenseDate || getTodayDateString());
    setExpenseCategory(exp.category || 'General Operations');
    setExpenseNote(exp.note || '');
    setExpenseCorrections(exp.resubmissionCorrections || '');
    setExpenseFormError(null);
    setIsExpenseFormOpen(true);
  };

  const handleAdvanceWorkflow = async (
    exp: Expense,
    action: 'manager_approve' | 'admin_approve' | 'admin_execute'
  ) => {
    if (advancingExpenseId) return;

    let storedSession: any = null;
    try {
      const sessionStr = typeof window !== 'undefined' ? localStorage.getItem('sarwan_auth_session_v1') : null;
      if (sessionStr) storedSession = JSON.parse(sessionStr);
    } catch {}

    const activeUserId = userProfile?.id || userProfile?.userId || storedSession?.userId || 'admin';
    const activeUserName = userProfile?.name || userProfile?.username || storedSession?.username || 'Staff';
    const activeUserRole = userProfile?.role || 'super_admin';
    const activeUserJobTitle = userProfile?.jobTitle || '';
    const activeUserPhotoURL = userProfile?.photoURL || '';

    if (activeUserRole === 'customer') {
      toast.error('Customer accounts cannot approve or execute expenses.');
      return;
    }

    setAdvancingExpenseId(exp.id);
    try {
      const idToken = (await currentUser?.getIdToken().catch(() => null)) || storedSession?.idToken || '';
      const resp = await fetch('/api/expenses/workflow', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...(idToken ? { Authorization: `Bearer ${idToken}` } : {}),
        },
        body: JSON.stringify({
          idToken: idToken || undefined,
          expenseId: exp.id,
          action,
          userId: activeUserId,
          userName: activeUserName,
          userRole: activeUserRole,
          userJobTitle: activeUserJobTitle,
          userPhotoURL: activeUserPhotoURL,
        }),
      });

      if (!resp.ok) {
        const errData = await resp.json().catch(() => ({}));
        throw new Error(errData?.error || 'Failed to advance expense workflow.');
      }

      if (action === 'manager_approve') {
        toast.success('Approved by Invoice Manager. Sent to Super Admin.');
      } else if (action === 'admin_approve') {
        toast.success('Approved by Super Admin.');
      } else if (action === 'admin_execute') {
        toast.success('Expense marked as executed & disbursed.');
      }
    } catch (err: any) {
      console.error('Failed to update expense status:', err);
      toast.error(err.message || 'Failed to update expense status.');
    } finally {
      setAdvancingExpenseId(null);
    }
  };

  const handleOpenDisburseModal = (exp: Expense) => {
    setExpenseToDisburse(exp);
    setDisbursedAmountInput(String(exp.amount || ''));
    setDisbursementMethodInput('Cash');
    setDisbursementDateInput(new Date().toISOString().slice(0, 10));
    setDisbursementRefInput('');
    setDisbursementNoteInput('');
    setDisbursementError(null);
  };

  const handleConfirmDisburse = async () => {
    if (!expenseToDisburse || isSubmittingDisbursement) return;
    const numAmount = Number(disbursedAmountInput);
    if (!Number.isFinite(numAmount) || numAmount <= 0) {
      setDisbursementError('Disbursed amount must be a positive number.');
      return;
    }
    if (numAmount > expenseToDisburse.amount) {
      setDisbursementError(`Disbursed amount cannot exceed approved amount (${expenseToDisburse.amount} AFN).`);
      return;
    }
    if (!disbursementDateInput) {
      setDisbursementError('Disbursement date is required.');
      return;
    }

    setIsSubmittingDisbursement(true);
    setDisbursementError(null);

    let storedSession: any = null;
    try {
      const sessionStr = typeof window !== 'undefined' ? localStorage.getItem('sarwan_auth_session_v1') : null;
      if (sessionStr) storedSession = JSON.parse(sessionStr);
    } catch {}

    const activeUserId = userProfile?.id || userProfile?.userId || storedSession?.userId || 'admin';
    const activeUserName = userProfile?.name || userProfile?.username || storedSession?.username || 'Super Admin';
    const activeUserRole = userProfile?.role || 'super_admin';
    const activeUserJobTitle = userProfile?.jobTitle || '';
    const activeUserPhotoURL = userProfile?.photoURL || '';

    try {
      const idToken = (await currentUser?.getIdToken().catch(() => null)) || storedSession?.idToken || '';
      const resp = await fetch('/api/expenses/workflow', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...(idToken ? { Authorization: `Bearer ${idToken}` } : {}),
        },
        body: JSON.stringify({
          idToken: idToken || undefined,
          expenseId: expenseToDisburse.id,
          action: 'admin_execute',
          userId: activeUserId,
          userName: activeUserName,
          userRole: activeUserRole,
          userJobTitle: activeUserJobTitle,
          userPhotoURL: activeUserPhotoURL,
          disbursedAmount: numAmount,
          disbursementMethod: disbursementMethodInput,
          executionDate: disbursementDateInput,
          disbursementReference: disbursementRefInput.trim() || undefined,
          disbursementNote: disbursementNoteInput.trim() || undefined,
        }),
      });

      if (!resp.ok) {
        const errData = await resp.json().catch(() => ({}));
        throw new Error(errData?.error || 'Failed to disburse expense.');
      }

      toast.success(`Expense disbursed (${numAmount.toLocaleString('en-US')} AFN via ${disbursementMethodInput}). Marked as Executed.`);
      setExpenseToDisburse(null);
    } catch (err: any) {
      console.error('Failed to execute disbursement:', err);
      setDisbursementError(err?.message || 'Failed to disburse expense.');
      toast.error(err?.message || 'Failed to disburse expense.');
    } finally {
      setIsSubmittingDisbursement(false);
    }
  };

  const handleOpenRejectModal = (exp: Expense) => {
    setExpenseToReject(exp);
    setRejectionReasonInput('');
    setRejectionError(null);
  };

  const handleConfirmReject = async () => {
    if (!expenseToReject || isSubmittingRejection) return;
    const trimmedReason = rejectionReasonInput.trim();
    if (!trimmedReason || trimmedReason.length < 3) {
      setRejectionError('A meaningful rejection reason (at least 3 characters) is required to reject an expense.');
      return;
    }

    setIsSubmittingRejection(true);
    setRejectionError(null);

    let storedSession: any = null;
    try {
      const sessionStr = typeof window !== 'undefined' ? localStorage.getItem('sarwan_auth_session_v1') : null;
      if (sessionStr) storedSession = JSON.parse(sessionStr);
    } catch {}

    const activeUserId = userProfile?.id || userProfile?.userId || storedSession?.userId || 'admin';
    const activeUserName = userProfile?.name || userProfile?.username || storedSession?.username || 'Staff';
    const activeUserRole = userProfile?.role || 'super_admin';
    const activeUserJobTitle = userProfile?.jobTitle || '';
    const activeUserPhotoURL = userProfile?.photoURL || '';

    if (activeUserRole === 'customer') {
      setRejectionError('Access Denied: Customer accounts cannot reject operating expenses.');
      setIsSubmittingRejection(false);
      return;
    }

    try {
      const idToken = (await currentUser?.getIdToken().catch(() => null)) || storedSession?.idToken || '';
      const resp = await fetch('/api/expenses/workflow', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...(idToken ? { Authorization: `Bearer ${idToken}` } : {}),
        },
        body: JSON.stringify({
          idToken: idToken || undefined,
          expenseId: expenseToReject.id,
          action: 'reject',
          userId: activeUserId,
          userName: activeUserName,
          userRole: activeUserRole,
          userJobTitle: activeUserJobTitle,
          userPhotoURL: activeUserPhotoURL,
          reason: trimmedReason,
        }),
      });

      if (!resp.ok) {
        const errData = await resp.json().catch(() => ({}));
        throw new Error(errData?.error || 'Failed to reject expense.');
      }

      toast.success('Expense request rejected.');
      setExpenseToReject(null);
      setRejectionReasonInput('');
    } catch (err: any) {
      const errorMsg = err?.message || 'Failed to reject expense.';
      setRejectionError(errorMsg);
      toast.error(errorMsg);
    } finally {
      setIsSubmittingRejection(false);
    }
  };

  const handleSaveExpense = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!invoice || savingExpense) return;

    if (!expenseTitle.trim()) {
      setExpenseFormError('Expense description is required.');
      return;
    }
    const numAmount = Number(expenseAmount);
    if (!Number.isFinite(numAmount) || numAmount <= 0) {
      setExpenseFormError('Expense amount must be greater than zero.');
      return;
    }
    if (!expenseDate) {
      setExpenseFormError('Expense date is required.');
      return;
    }
    if (editingExpense?.status === 'rejected') {
      if (!expenseCorrections || !expenseCorrections.trim() || expenseCorrections.trim().length < 3) {
        setExpenseFormError('A resubmission note (at least 3 characters) describing corrections made is required.');
        return;
      }
    }

    let storedSession: any = null;
    try {
      const sessionStr = typeof window !== 'undefined' ? localStorage.getItem('sarwan_auth_session_v1') : null;
      if (sessionStr) storedSession = JSON.parse(sessionStr);
    } catch {}

    const activeUserId = userProfile?.id || userProfile?.userId || storedSession?.userId || 'admin';
    const activeUserName = userProfile?.name || userProfile?.username || storedSession?.username || 'Staff';
    const activeUserRole = userProfile?.role || 'super_admin';
    const activeUserJobTitle = userProfile?.jobTitle || '';
    const activeUserPhotoURL = userProfile?.photoURL || '';

    if (activeUserRole === 'customer') {
      setExpenseFormError('Access Denied: Customer accounts cannot create or submit operating expenses.');
      return;
    }

    if (activeUserRole === 'super_admin') {
      const errMsg = editingExpense
        ? 'Access Denied: Super Admin cannot edit submitted expense requests. Super Admin may only perform authorized approval or rejection actions.'
        : 'Access Denied: Super Admin cannot create or submit expense requests. Expense creation is restricted to Invoice Managers and Payment Collectors.';
      setExpenseFormError(errMsg);
      toast.error(errMsg);
      return;
    }

    setSavingExpense(true);
    setExpenseFormError(null);

    try {
      let handledByServer = false;
      try {
        const idToken = (await currentUser?.getIdToken().catch(() => null)) || storedSession?.idToken || '';
        const resp = await fetch('/api/expenses/save', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            ...(idToken ? { Authorization: `Bearer ${idToken}` } : {}),
          },
          body: JSON.stringify({
            idToken: idToken || undefined,
            id: editingExpense?.id,
            invoiceId: invoice.id,
            billNumber: invoice.billNumber,
            title: expenseTitle.trim(),
            amount: numAmount,
            date: expenseDate,
            category: expenseCategory,
            note: expenseNote.trim(),
            corrections: expenseCorrections.trim(),
            userId: activeUserId,
            userName: activeUserName,
            userRole: activeUserRole,
            userJobTitle: activeUserJobTitle,
            userPhotoURL: activeUserPhotoURL,
          }),
        });
        if (resp.ok) {
          handledByServer = true;
        } else {
          const errData = await resp.json().catch(() => ({}));
          if (errData?.error) throw new Error(errData.error);
        }
      } catch (serverErr: any) {
        if (serverErr?.message && !serverErr.message.includes('fetch') && !serverErr.message.includes('Failed to fetch')) {
          throw serverErr;
        }
      }

      if (!handledByServer) {
        await saveInvoiceExpense({
          id: editingExpense?.id,
          invoiceId: invoice.id,
          billNumber: invoice.billNumber,
          title: expenseTitle.trim(),
          amount: numAmount,
          date: expenseDate,
          category: expenseCategory,
          note: expenseNote.trim(),
          corrections: expenseCorrections.trim(),
          userId: activeUserId,
          userName: activeUserName,
          userRole: activeUserRole,
          userJobTitle: activeUserJobTitle,
          userPhotoURL: activeUserPhotoURL,
        });
      }

      const successText = editingExpense
        ? (editingExpense.status === 'rejected'
            ? 'Expense request resubmitted successfully.'
            : 'Expense updated successfully.')
        : (activeUserRole === 'payment_collector'
            ? 'Expense request submitted for Invoice Manager approval.'
            : activeUserRole === 'invoice_manager'
            ? 'Expense request submitted for Super Admin approval.'
            : 'Expense added successfully.');
      toast.success(successText);

      setIsExpenseFormOpen(false);
      setEditingExpense(null);
      setExpenseTitle('');
      setExpenseAmount('');
      setExpenseNote('');
      setExpenseCorrections('');
      setExpenseFormError(null);
      if (lastFocusedExpenseTriggerRef.current && typeof lastFocusedExpenseTriggerRef.current.focus === 'function') {
        lastFocusedExpenseTriggerRef.current.focus();
      }
    } catch (err: any) {
      console.error('Error saving invoice expense:', err);
      const errMsg = err?.message || 'Failed to save expense.';
      setExpenseFormError(errMsg);
      toast.error(errMsg);
    } finally {
      setSavingExpense(false);
    }
  };

  const handleConfirmDeleteExpense = async () => {
    if (!expenseToDelete || !invoice || isDeletingExpense) return;

    let storedSession: any = null;
    try {
      const sessionStr = typeof window !== 'undefined' ? localStorage.getItem('sarwan_auth_session_v1') : null;
      if (sessionStr) storedSession = JSON.parse(sessionStr);
    } catch {}

    const activeUserId = userProfile?.id || userProfile?.userId || storedSession?.userId || 'admin';
    const activeUserName = userProfile?.name || userProfile?.username || storedSession?.username || 'Staff';
    const activeUserRole = userProfile?.role || 'super_admin';

    if (activeUserRole !== 'super_admin' && activeUserRole !== 'invoice_manager') {
      toast.error('Access Denied: Only Super Admin and Invoice Manager can delete invoice expenses.');
      return;
    }

    setIsDeletingExpense(true);
    try {
      let handledByServer = false;
      try {
        const idToken = (await currentUser?.getIdToken().catch(() => null)) || storedSession?.idToken || '';
        const resp = await fetch('/api/expenses/delete', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            ...(idToken ? { Authorization: `Bearer ${idToken}` } : {}),
          },
          body: JSON.stringify({
            idToken: idToken || undefined,
            expenseId: expenseToDelete.id,
            invoiceId: invoice.id,
            billNumber: invoice.billNumber,
            userId: activeUserId,
            userName: activeUserName,
            userRole: activeUserRole,
          }),
        });
        if (resp.ok) {
          handledByServer = true;
        } else {
          const errData = await resp.json().catch(() => ({}));
          if (errData?.error) throw new Error(errData.error);
        }
      } catch (serverErr: any) {
        if (serverErr?.message && !serverErr.message.includes('fetch') && !serverErr.message.includes('Failed to fetch')) {
          throw serverErr;
        }
      }

      if (!handledByServer) {
        await deleteInvoiceExpense({
          expenseId: expenseToDelete.id,
          invoiceId: invoice.id,
          billNumber: invoice.billNumber,
          userId: activeUserId,
          userName: activeUserName,
          userRole: activeUserRole,
        });
      }

      toast.success('Expense deleted successfully.');
      setExpenseToDelete(null);
    } catch (err: any) {
      console.error('Error deleting invoice expense:', err);
      toast.error(err.message || 'Failed to delete expense.');
    } finally {
      setIsDeletingExpense(false);
    }
  };

  const statusColors: Record<string, string> = {
    Paid: 'bg-emerald-100 text-emerald-800 border-emerald-300',
    'Partially Paid': 'bg-amber-100 text-amber-800 border-amber-300',
    Unpaid: 'bg-rose-100 text-rose-800 border-rose-300',
    Void: 'bg-neutral-200 text-neutral-800 border-neutral-300',
  };

  const createdDateDisplay = useMemo(() => {
    if (!invoice) return '—';
    const target = invoice.createdAt || invoice.date;
    if (!target) return '—';
    try {
      const d = new Date(target);
      if (isNaN(d.getTime())) return target;
      const hasTime = target.includes('T') || target.includes(':');
      const datePart = d.toLocaleDateString('en-GB', {
        day: 'numeric',
        month: 'short',
        year: 'numeric',
      });
      if (hasTime) {
        const timePart = d.toLocaleTimeString('en-US', {
          hour: 'numeric',
          minute: '2-digit',
          hour12: true,
        });
        return `${datePart}, ${timePart}`;
      }
      return datePart;
    } catch {
      return target;
    }
  }, [invoice]);

  if (!invoice) return null;

  return (
    <>
      {isOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 md:p-6 bg-black/60 backdrop-blur-xs overflow-y-auto">
      <div className="bg-[var(--app-surface-modal,#FFFFFF)] text-[var(--app-text-primary,#0F172A)] rounded-xl shadow-2xl w-full max-w-4xl max-h-[90vh] sm:max-h-[92vh] flex flex-col overflow-hidden border border-[var(--app-border,#E2E8F0)] transition-colors">
        {/* Modal Top Bar */}
        <div className="px-3.5 py-3 sm:px-6 sm:py-4 border-b border-[var(--app-border-subtle,#F1F5F9)] bg-[var(--color-surface-sidebar,#0A0F1D)] text-white shrink-0">
          <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-2.5 sm:gap-4">
            {/* Top row on mobile / Left group on desktop */}
            <div className="flex items-center justify-between md:justify-start gap-2.5 sm:gap-3 min-w-0">
              <div className="flex items-center gap-2.5 sm:gap-3 min-w-0">
                <div className="p-1.5 bg-neutral-800 rounded-lg border border-neutral-700 shrink-0">
                  <FileText className="w-5 h-5 text-orange-400" />
                </div>
                <div className="min-w-0">
                  <div className="flex items-center gap-2 flex-wrap">
                    <h2 className="text-base sm:text-lg font-bold font-mono text-orange-400 truncate">
                      {invoice.billNumber}
                    </h2>
                    {isVoid ? (
                      <span className="text-[10px] font-bold px-2 py-0.5 rounded-full border inline-flex items-center gap-1 shrink-0 bg-neutral-200 text-neutral-800 border-neutral-300">
                        <Ban className="w-2.5 h-2.5 text-neutral-700 inline shrink-0" />
                        Void
                      </span>
                    ) : isQuotation ? (
                      <span className="text-[10px] font-bold px-2.5 py-0.5 rounded-full border inline-flex items-center gap-1 shrink-0 bg-amber-500/20 text-amber-300 border-amber-400/40">
                        <Clock className="w-2.5 h-2.5 text-amber-300 inline shrink-0" />
                        Quotation / Pending Approval
                      </span>
                    ) : isRejected ? (
                      <span className="text-[10px] font-bold px-2.5 py-0.5 rounded-full border inline-flex items-center gap-1 shrink-0 bg-rose-500/20 text-rose-300 border-rose-400/40">
                        <XCircle className="w-2.5 h-2.5 text-rose-300 inline shrink-0" />
                        Rejected
                      </span>
                    ) : (
                      <span
                        className={`text-[10px] font-bold px-2 py-0.5 rounded-full border inline-flex items-center gap-1 shrink-0 ${
                          statusColors[invoice.status] || statusColors.Unpaid
                        }`}
                      >
                        {invoice.status}
                      </span>
                    )}
                  </div>
                  {/* On desktop (md+): Created Date shown under bill info */}
                  <p className="hidden md:block text-xs text-neutral-400 whitespace-nowrap mt-0.5">
                    Created: {createdDateDisplay}
                  </p>
                </div>
              </div>

              {/* Close Button on mobile - right aligned in top row */}
              <button
                type="button"
                onClick={onClose}
                className="md:hidden p-2 rounded-lg text-neutral-400 hover:text-white hover:bg-neutral-800 transition shrink-0 active:scale-95 cursor-pointer"
                title="Close"
                aria-label="Close invoice details"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Mobile: Vertical layout of Created Date (line 1) + Related Action Buttons (line 2) */}
            {/* Desktop: Horizontal layout adjacent to bill info */}
            <div className="flex flex-col md:flex-row md:items-center gap-2 md:gap-3">
              {/* Line 1 on mobile: Created Date (intact, non-wrapping) */}
              <div className="md:hidden flex items-center text-xs text-neutral-300 font-mono whitespace-nowrap">
                <span>Created: {createdDateDisplay}</span>
              </div>

              {/* Line 2 on mobile: Action Buttons (icon-only on mobile, icon + text on tablet/desktop) */}
              <div className="flex items-center gap-1.5 sm:gap-2 overflow-x-auto py-0.5">
                {canAssign && (
                  <button
                    type="button"
                    onClick={() => setIsAssignModalOpen(true)}
                    className="p-2 sm:px-3 sm:py-1.5 text-xs font-semibold rounded-lg bg-neutral-800 hover:bg-neutral-700 text-[#F58220] border border-[#F58220]/40 transition inline-flex items-center justify-center gap-1.5 active:scale-95 cursor-pointer shrink-0"
                    title={
                      invoice.assignedCollectorName
                        ? `Reassign Collector (Current: ${invoice.assignedCollectorName})`
                        : 'Assign Invoice to Collector'
                    }
                    aria-label={
                      invoice.assignedCollectorName
                        ? `Reassign Collector (Current: ${invoice.assignedCollectorName})`
                        : 'Assign Invoice to Collector'
                    }
                  >
                    <UserCheck className="w-4 h-4 sm:w-3.5 sm:h-3.5 text-[#F58220] shrink-0" />
                    <span className="hidden sm:inline">
                      {invoice.assignedCollectorName ? 'Reassign' : 'Assign'}
                    </span>
                  </button>
                )}
                <button
                  type="button"
                  onClick={() => setShowPrintPreview(!showPrintPreview)}
                  className="p-2 sm:px-3 sm:py-1.5 text-xs font-semibold rounded-lg bg-neutral-800 hover:bg-neutral-700 text-neutral-200 border border-neutral-700 transition inline-flex items-center justify-center gap-1.5 shrink-0 active:scale-95 cursor-pointer"
                  title={showPrintPreview ? 'View Data' : 'A4 Preview'}
                  aria-label={showPrintPreview ? 'View Data' : 'A4 Preview'}
                >
                  <Eye className="w-4 h-4 sm:w-3.5 sm:h-3.5 text-neutral-400 shrink-0" />
                  <span className="hidden sm:inline">
                    {showPrintPreview ? 'View Data' : 'A4 Preview'}
                  </span>
                </button>
                <button
                  type="button"
                  onClick={handleDownloadPdf}
                  disabled={!invoice}
                  className="p-2 sm:px-3.5 sm:py-1.5 text-xs font-semibold rounded-lg bg-[#2563EB] hover:bg-[#1D4ED8] active:bg-[#1E40AF] text-white transition inline-flex items-center justify-center gap-1.5 shadow-xs disabled:opacity-50 shrink-0 cursor-pointer focus:outline-none focus-visible:ring-2 focus-visible:ring-[#2563EB]"
                  title="Print / Save Invoice as PDF"
                  aria-label="Print / Save Invoice as PDF"
                >
                  <Printer className="w-4 h-4 sm:w-3.5 sm:h-3.5 shrink-0" />
                  <span className="hidden sm:inline">Print / Save as PDF</span>
                </button>
                {/* Desktop Close button */}
                <button
                  type="button"
                  onClick={onClose}
                  className="hidden md:inline-flex p-1.5 rounded-lg text-neutral-400 hover:text-white hover:bg-neutral-800 transition ml-1 shrink-0 active:scale-95 cursor-pointer"
                  title="Close"
                  aria-label="Close invoice details"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Body Content */}
        <div className="p-3.5 sm:p-6 overflow-y-auto flex-1 space-y-4 sm:space-y-6 overscroll-contain">
          {pdfError && (
            <div className="p-3 bg-rose-50 border border-rose-200 text-rose-700 text-xs rounded-lg flex items-center justify-between">
              <span className="break-words">{pdfError}</span>
              <button onClick={() => setPdfError(null)} className="text-rose-500 hover:text-rose-800 shrink-0">
                <X className="w-4 h-4" />
              </button>
            </div>
          )}

          {showPrintPreview && canonicalDoc ? (
            <div className="flex flex-col gap-2 w-full min-w-0">
              {/* Responsive Zoom & Fit Indicator Bar */}
              <div className="flex items-center justify-between bg-neutral-100 border border-neutral-300 rounded-lg px-3 py-1.5 text-xs text-neutral-600 shrink-0">
                <div className="flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full bg-emerald-500 shrink-0" />
                  <span className="font-semibold text-neutral-800">A4 Invoice Preview</span>
                  <span className="text-neutral-400">|</span>
                  <span className="text-neutral-500 text-[11px] font-mono">
                    210 × 297 mm ({Math.round(activeScale * 100)}%{isFitMode ? ' Fit' : ''})
                  </span>
                </div>
                <div className="flex items-center gap-1">
                  <button
                    type="button"
                    onClick={() => {
                      setIsFitMode(true);
                      updatePreviewScale();
                    }}
                    className={`px-2 py-0.5 rounded text-[11px] font-semibold transition cursor-pointer ${
                      isFitMode
                        ? 'bg-blue-600 text-white shadow-2xs'
                        : 'bg-white text-neutral-700 border border-neutral-300 hover:bg-neutral-50'
                    }`}
                    title="Fit to Screen"
                  >
                    Fit
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setIsFitMode(false);
                      setManualZoom(1.0);
                    }}
                    className={`px-1.5 py-0.5 rounded text-[11px] font-medium transition cursor-pointer ${
                      !isFitMode && manualZoom === 1.0
                        ? 'bg-neutral-800 text-white'
                        : 'bg-white text-neutral-700 border border-neutral-300 hover:bg-neutral-50'
                    }`}
                    title="100% Actual Size"
                  >
                    100%
                  </button>
                </div>
              </div>

              {/* Responsive A4 Preview Viewport */}
              <div
                ref={previewContainerRef}
                className="bg-neutral-200/80 p-2 sm:p-4 rounded-xl flex flex-col items-center overflow-x-hidden overflow-y-auto shadow-inner w-full min-w-0 max-h-[70vh]"
                style={{ boxSizing: 'border-box' }}
              >
                {/* Scaled A4 Document Stage: exact scaled width and height prevents overflow and reserves vertical space */}
                <div
                  style={{
                    width: `${Math.round(793.7 * activeScale)}px`,
                    height: `${Math.round(docHeight * activeScale)}px`,
                    position: 'relative',
                    margin: '0 auto',
                    flexShrink: 0,
                    transition: 'width 0.15s ease-out, height 0.15s ease-out',
                  }}
                >
                  <div
                    ref={docRef}
                    style={{
                      position: 'absolute',
                      top: 0,
                      left: 0,
                      transform: `scale(${activeScale})`,
                      transformOrigin: 'top left',
                      width: '210mm',
                      minWidth: '210mm',
                      transition: 'transform 0.15s ease-out',
                    }}
                    className="shadow-2xl border border-neutral-300 bg-white"
                  >
                    <CanonicalInvoiceDocument
                      document={canonicalDoc}
                      id="invoice-detail-preview-document"
                    />
                  </div>
                </div>
              </div>
            </div>
          ) : (
            <>
              {/* Action Error / Success Feedback */}
              {actionError && (
                <div className="p-3 bg-rose-50 border border-rose-300 text-rose-800 text-xs rounded-xl flex items-center justify-between gap-2 shadow-2xs">
                  <div className="flex items-center gap-2">
                    <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
                    <span className="font-medium">{actionError}</span>
                  </div>
                  <button
                    type="button"
                    onClick={() => setActionError(null)}
                    className="text-rose-500 hover:text-rose-700 p-1 cursor-pointer"
                  >
                    <X className="w-3.5 h-3.5" />
                  </button>
                </div>
              )}
              {actionSuccess && (
                <div className="p-3 bg-emerald-50 border border-emerald-300 text-emerald-800 text-xs rounded-xl flex items-center justify-between gap-2 shadow-2xs">
                  <div className="flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                    <span className="font-medium">{actionSuccess}</span>
                  </div>
                  <button
                    type="button"
                    onClick={() => setActionSuccess(null)}
                    className="text-emerald-500 hover:text-emerald-700 p-1 cursor-pointer"
                  >
                    <X className="w-3.5 h-3.5" />
                  </button>
                </div>
              )}

              {isVoid && (
                <div className="p-3 sm:p-3.5 bg-neutral-100 border border-neutral-300 text-neutral-800 text-xs rounded-xl flex items-center gap-2.5">
                  <Ban className="w-4 h-4 text-neutral-600 shrink-0" />
                  <div>
                    <span className="font-bold">This invoice is Void.</span>
                    <span className="text-neutral-600 ml-1">
                      It is permanently cancelled and excluded from active sales calculations and receivables. No further payments or edits can be made.
                    </span>
                  </div>
                </div>
              )}

              {/* Quotation Workflow Banner */}
              {!isVoid && isQuotation && (
                <div className="p-3.5 sm:p-4 bg-amber-50/90 border border-amber-300 rounded-xl flex flex-col md:flex-row md:items-center justify-between gap-3 text-xs text-amber-950 shadow-2xs">
                  <div className="flex items-start gap-2.5">
                    <Clock className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
                    <div>
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="font-bold text-sm text-amber-900">Quotation / Pending Approval</span>
                        <span className="text-[10px] font-bold px-2 py-0.5 bg-amber-200/80 text-amber-900 rounded-full border border-amber-300">
                          Price Offer Only • Not a Sale
                        </span>
                      </div>
                      <p className="text-amber-800 text-xs mt-1 leading-relaxed">
                        This document is a quotation price offer. It is strictly excluded from sales totals, customer revenue, and receivables. Payments and collector assignments are disabled until accepted.
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2 shrink-0 self-end md:self-auto flex-wrap">
                    {userProfile?.role === 'customer' ? (
                      <>
                        <button
                          type="button"
                          onClick={() => {
                            setStateChangeAction('payable');
                            setShowStateConfirmModal(true);
                          }}
                          className="px-3.5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-lg shadow-xs inline-flex items-center gap-1.5 transition cursor-pointer active:scale-95 text-xs"
                        >
                          <CheckCircle2 className="w-4 h-4" />
                          Accept Quotation
                        </button>
                        <button
                          type="button"
                          onClick={() => {
                            setStateChangeAction('rejected');
                            setShowStateConfirmModal(true);
                          }}
                          className="px-3 py-2 bg-white hover:bg-rose-50 text-rose-700 border border-rose-300 font-bold rounded-lg shadow-xs inline-flex items-center gap-1.5 transition cursor-pointer active:scale-95 text-xs"
                        >
                          <XCircle className="w-4 h-4" />
                          Reject Quotation
                        </button>
                      </>
                    ) : (userProfile?.role === 'super_admin' || userProfile?.role === 'invoice_manager') ? (
                      <>
                        <button
                          type="button"
                          onClick={() => {
                            setStateChangeAction('payable');
                            setShowStateConfirmModal(true);
                          }}
                          className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-lg shadow-xs inline-flex items-center gap-1.5 transition cursor-pointer active:scale-95 text-xs"
                          title="Mark this quotation as payable"
                        >
                          <CheckCircle2 className="w-3.5 h-3.5" />
                          Mark as Payable
                        </button>
                        <button
                          type="button"
                          onClick={() => {
                            setStateChangeAction('rejected');
                            setShowStateConfirmModal(true);
                          }}
                          className="px-3 py-1.5 bg-white hover:bg-rose-50 text-rose-700 border border-rose-300 font-bold rounded-lg shadow-xs inline-flex items-center gap-1.5 transition cursor-pointer active:scale-95 text-xs"
                          title="Mark this quotation as rejected"
                        >
                          <XCircle className="w-3.5 h-3.5" />
                          Mark as Rejected
                        </button>
                        <button
                          type="button"
                          onClick={() => setShowDeleteConfirmModal(true)}
                          className="px-2.5 py-1.5 bg-neutral-100 hover:bg-rose-100 text-neutral-700 hover:text-rose-700 border border-neutral-300 hover:border-rose-300 font-bold rounded-lg shadow-xs inline-flex items-center gap-1 transition cursor-pointer active:scale-95 text-xs"
                          title="Permanently delete this quotation"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                          Delete
                        </button>
                      </>
                    ) : null}
                  </div>
                </div>
              )}

              {/* Quotation Rejected Banner */}
              {!isVoid && isRejected && (
                <div className="p-3.5 sm:p-4 bg-rose-50/90 border border-rose-300 rounded-xl flex flex-col md:flex-row md:items-center justify-between gap-3 text-xs text-rose-950 shadow-2xs">
                  <div className="flex items-start gap-2.5">
                    <Ban className="w-5 h-5 text-rose-600 shrink-0 mt-0.5" />
                    <div>
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="font-bold text-sm text-rose-900">Quotation Rejected</span>
                        <span className="text-[10px] font-bold px-2 py-0.5 bg-rose-200/80 text-rose-900 rounded-full border border-rose-300">
                          Declined
                        </span>
                      </div>
                      <p className="text-rose-800 text-xs mt-1 leading-relaxed">
                        This quotation was rejected and is excluded from all financial calculations, reports, and receivables. Payments and collector assignments are prohibited.
                        {(invoice.rejectedAt || invoice.changedAt) && (
                          <span className="block mt-1 text-[11px] text-rose-700 font-mono">
                            Rejected: {formatDate(invoice.rejectedAt || invoice.changedAt || '')} by {invoice.rejectedBy || invoice.changedBy || 'Customer'} ({invoice.rejectionSource || invoice.changeSource || 'Portal'})
                          </span>
                        )}
                      </p>
                    </div>
                  </div>
                  {(userProfile?.role === 'super_admin' || userProfile?.role === 'invoice_manager') && (
                    <div className="flex items-center gap-2 shrink-0 self-end md:self-auto flex-wrap">
                      <button
                        type="button"
                        onClick={() => {
                          setStateChangeAction('payable');
                          setShowStateConfirmModal(true);
                        }}
                        className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-lg shadow-xs inline-flex items-center gap-1.5 transition cursor-pointer active:scale-95 text-xs"
                      >
                        <CheckCircle2 className="w-3.5 h-3.5" />
                        Mark as Payable
                      </button>
                      <button
                        type="button"
                        onClick={() => setShowDeleteConfirmModal(true)}
                        className="px-2.5 py-1.5 bg-rose-100 hover:bg-rose-200 text-rose-800 border border-rose-300 font-bold rounded-lg shadow-xs inline-flex items-center gap-1 transition cursor-pointer active:scale-95 text-xs"
                        title="Permanently delete this rejected quotation"
                      >
                        <Trash2 className="w-3.5 h-3.5 text-rose-600" />
                        Delete
                      </button>
                    </div>
                  )}
                </div>
              )}

              {/* Quotation Acceptance Audit Banner */}
              {!isVoid && isPayable && (invoice.acceptedAt || invoice.changedAt) && (
                <div className="p-2.5 px-3.5 bg-emerald-50/80 border border-emerald-200 text-emerald-900 text-xs rounded-xl flex items-center justify-between gap-2">
                  <div className="flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                    <span className="text-[11px]">
                      <strong>Quotation Approved / Payable:</strong> Accepted on {formatDate(invoice.acceptedAt || invoice.changedAt || '')} by {invoice.acceptedBy || invoice.changedBy || 'Customer'} ({invoice.acceptanceSource || invoice.changeSource || 'Admin Panel'})
                    </span>
                  </div>
                </div>
              )}

              {/* Customer Snapshot & Meta */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="bg-[var(--app-bg-muted,#F1F5F9)] p-3.5 sm:p-4 rounded-xl border border-[var(--app-border,#E2E8F0)] transition-colors">
                  <h3 className="text-xs font-bold uppercase tracking-wider text-[var(--app-text-muted,#64748B)] mb-3 flex items-center gap-1.5">
                    <User className="w-3.5 h-3.5 text-[var(--brand-orange,#F7941D)] shrink-0" />
                    Customer Information (Historical Snapshot)
                  </h3>
                  <div className="space-y-1.5 text-xs">
                    <p className="text-sm font-bold text-[var(--app-text-primary,#0F172A)] break-words">
                      {invoice.customerSnapshot.name}
                    </p>
                    <p className="text-[var(--app-text-secondary,#475569)] flex items-center gap-1.5 font-mono break-all">
                      <Phone className="w-3.5 h-3.5 text-neutral-400 shrink-0" />
                      {invoice.customerSnapshot.phone}
                    </p>
                    {invoice.customerSnapshot.companyName && (
                      <p className="text-neutral-600 flex items-center gap-1.5 break-words">
                        <Building className="w-3.5 h-3.5 text-neutral-400 shrink-0" />
                        {invoice.customerSnapshot.companyName}
                      </p>
                    )}
                    {invoice.customerSnapshot.address && (
                      <p className="text-neutral-600 flex items-center gap-1.5 break-words">
                        <MapPin className="w-3.5 h-3.5 text-neutral-400 shrink-0" />
                        {invoice.customerSnapshot.address}
                      </p>
                    )}
                  </div>
                </div>

                {/* Financial Overview Card */}
                <div className="bg-neutral-900 text-white p-3.5 sm:p-4 rounded-xl flex flex-col justify-between">
                  <div className="space-y-2">
                    <div className="flex justify-between items-center text-xs text-neutral-400">
                      <span>Total Invoice Amount:</span>
                      <span className="font-bold text-white font-mono text-sm whitespace-nowrap">
                        {formatAFN(invoice.totalAmount)}
                      </span>
                    </div>
                    <div className="flex justify-between items-center text-xs text-emerald-400">
                      <span>Total Paid (Cash):</span>
                      <span className="font-bold font-mono text-sm whitespace-nowrap">{formatAFN(totalPaid)}</span>
                    </div>
                    <div className="border-t border-neutral-800 pt-2 flex justify-between items-center text-sm">
                      <span className="font-bold text-orange-400 uppercase text-xs tracking-wider">
                        Remaining Balance:
                      </span>
                      <span className="font-black font-mono text-base text-white whitespace-nowrap">
                        {isVoid ? (
                          <span className="text-neutral-400 text-xs font-normal">
                            0 AFN <span className="text-[10px] text-neutral-400">(Void)</span>
                          </span>
                        ) : isQuotation ? (
                          <span className="text-amber-400 text-xs font-normal">
                            0 AFN <span className="text-[10px] text-amber-300 font-medium">(Quotation)</span>
                          </span>
                        ) : isRejected ? (
                          <span className="text-rose-400 text-xs font-normal">
                            0 AFN <span className="text-[10px] text-rose-300 font-medium">(Rejected)</span>
                          </span>
                        ) : (
                          formatAFN(remaining)
                        )}
                      </span>
                    </div>
                  </div>

                  {remaining > 0 && !showAddPayment && canCollect && !invoice.isVoid && invoice.status !== 'Void' && (
                    <button
                      onClick={() => setShowAddPayment(true)}
                      className="mt-4 w-full py-2 bg-[#2563EB] hover:bg-[#1D4ED8] active:bg-[#1E40AF] text-white text-xs font-bold rounded-lg shadow-xs transition inline-flex items-center justify-center gap-1.5 cursor-pointer focus:outline-none focus-visible:ring-2 focus-visible:ring-[#2563EB]"
                    >
                      <PlusCircle className="w-3.5 h-3.5" />
                      Add Cash Payment
                    </button>
                  )}
                </div>
              </div>

              {/* Collector Assignment Information Card */}
              <div className="bg-neutral-50 p-3.5 sm:p-4 rounded-xl border border-neutral-200">
                <div className="flex items-center justify-between mb-3">
                  <h3 className="text-xs font-bold uppercase tracking-wider text-neutral-500 flex items-center gap-1.5">
                    <UserCheck className="w-3.5 h-3.5 text-[#F58220] shrink-0" />
                    Collector Assignment
                  </h3>
                  {canAssign ? (
                    <button
                      type="button"
                      onClick={() => setIsAssignModalOpen(true)}
                      className="px-2.5 py-1 text-xs font-bold rounded-lg bg-white hover:bg-neutral-100 text-neutral-800 border border-neutral-300 transition inline-flex items-center gap-1 cursor-pointer shadow-xs active:scale-95 shrink-0"
                    >
                      <UserCheck className="w-3.5 h-3.5 text-[#F58220] shrink-0" />
                      <span className="hidden sm:inline">
                        {invoice.assignedCollectorName ? 'Change Collector' : 'Assign Collector'}
                      </span>
                      <span className="sm:hidden">
                        {invoice.assignedCollectorName ? 'Change' : 'Assign'}
                      </span>
                    </button>
                  ) : isQuotation ? (
                    <span
                      className="text-[11px] text-amber-700 font-medium"
                      title="Collector assignment is disabled for quotations."
                    >
                      Disabled for Quotations
                    </span>
                  ) : isRejected ? (
                    <span
                      className="text-[11px] text-rose-700 font-medium"
                      title="Collector assignment is disabled for rejected invoices."
                    >
                      Disabled for Rejected
                    </span>
                  ) : isLockedOrPaid && !isVoid ? (
                    <span
                      className="text-[11px] text-neutral-500 font-medium"
                      title="Invoice is locked. Collector assignment cannot be changed."
                    >
                      Locked (Assignment disabled)
                    </span>
                  ) : null}
                </div>

                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs bg-white p-3 rounded-lg border border-neutral-200">
                  <div className="flex items-center gap-3 min-w-0">
                    <div className="w-10 h-10 rounded-full bg-neutral-100 border border-neutral-300 overflow-hidden flex items-center justify-center shrink-0">
                      {assignedCollectorProfile?.photoURL ? (
                        <img
                          src={assignedCollectorProfile.photoURL}
                          alt={invoice.assignedCollectorName || 'Collector'}
                          className="w-full h-full object-cover"
                          onError={(e) => {
                            (e.currentTarget as HTMLElement).style.display = 'none';
                          }}
                        />
                      ) : (
                        <User className="w-5 h-5 text-neutral-500" />
                      )}
                    </div>
                    <div className="min-w-0">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="font-bold text-sm text-neutral-900 break-words">
                          {invoice.assignedCollectorName || 'Unassigned'}
                        </span>
                        <span
                          className={`text-[10px] font-bold px-2 py-0.5 rounded-full border shrink-0 ${
                            invoice.assignedCollectorName
                              ? 'bg-sky-50 text-sky-800 border-sky-200'
                              : 'bg-neutral-100 text-neutral-600 border-neutral-200'
                          }`}
                        >
                          {invoice.assignedCollectorName ? 'Assigned for Collection' : 'Unassigned'}
                        </span>
                      </div>
                      <div className="text-[11px] text-neutral-500 mt-0.5 flex flex-wrap gap-x-3 gap-y-0.5 font-mono">
                        {invoice.assignedAt && (
                          <span className="whitespace-nowrap">Assigned: {formatDate(invoice.assignedAt)}</span>
                        )}
                        {invoice.assignedByName && (
                          <span className="break-words">By: {invoice.assignedByName}</span>
                        )}
                        {assignedCollectorProfile?.phone && (
                          <span className="whitespace-nowrap">Phone: {assignedCollectorProfile.phone}</span>
                        )}
                      </div>
                    </div>
                  </div>

                  {invoice.assignmentHistory && invoice.assignmentHistory.length > 0 && (
                    <button
                      type="button"
                      onClick={() => setShowHistoryLogs(!showHistoryLogs)}
                      className="text-[11px] font-semibold text-neutral-600 hover:text-neutral-900 inline-flex items-center gap-1 self-start sm:self-auto cursor-pointer shrink-0"
                    >
                      <History className="w-3.5 h-3.5 text-neutral-400 shrink-0" />
                      <span>
                        {invoice.assignmentHistory.length} Assignment Log{invoice.assignmentHistory.length > 1 ? 's' : ''}
                      </span>
                    </button>
                  )}
                </div>

                {showHistoryLogs && invoice.assignmentHistory && invoice.assignmentHistory.length > 0 && (
                  <div className="mt-3 pt-3 border-t border-neutral-200 space-y-1.5">
                    <span className="text-[10px] font-bold uppercase text-neutral-500 block">
                      Assignment Audit Log
                    </span>
                    {invoice.assignmentHistory.map((h, idx) => (
                      <div
                        key={idx}
                        className="p-2 bg-neutral-100/70 border border-neutral-200 rounded text-[11px] text-neutral-700 flex items-center justify-between gap-2"
                      >
                        <div className="min-w-0">
                          <span className="font-semibold text-neutral-900 break-words">{h.collectorName}</span>
                          {h.previousCollectorName && (
                            <span className="text-neutral-500 text-[10px] ml-1 break-words">
                              (replaced {h.previousCollectorName})
                            </span>
                          )}
                          <span className="text-neutral-500 text-[10px] ml-2 break-words">
                            by {h.assignedByName || 'Admin'}
                          </span>
                        </div>
                        <span className="font-mono text-[10px] text-neutral-500 whitespace-nowrap shrink-0">
                          {formatDate(h.assignedAt)}
                        </span>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {/* Add Cash Payment Sub-Form */}
              {showAddPayment && (
                <form
                  onSubmit={handleAddPayment}
                  className="bg-amber-50/80 border border-amber-300 rounded-xl p-3.5 sm:p-4 space-y-3"
                >
                  <div className="flex items-center justify-between">
                    <h4 className="text-xs font-bold text-amber-900 flex items-center gap-1.5">
                      <DollarSign className="w-4 h-4 text-amber-600 shrink-0" />
                      Record Cash Payment (CASH ONLY)
                    </h4>
                    <button
                      type="button"
                      onClick={() => setShowAddPayment(false)}
                      className="text-amber-800 hover:text-amber-950 text-xs font-bold cursor-pointer"
                    >
                      Cancel
                    </button>
                  </div>

                  {paymentError && (
                    <div className="p-2 bg-red-100 text-red-700 text-xs rounded break-words">
                      {paymentError}
                    </div>
                  )}

                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                    <div>
                      <label className="text-[11px] font-semibold text-amber-900 block">
                        Amount (AFN) *
                      </label>
                      <input
                        type="number"
                        min="1"
                        max={remaining}
                        value={paymentAmount ?? ''}
                        onChange={(e) =>
                          setPaymentAmount(e.target.value === '' ? '' : Number(e.target.value))
                        }
                        placeholder={`Max: ${remaining}`}
                        className="w-full text-xs font-mono border border-amber-300 rounded px-2.5 py-1.5 bg-white focus:outline-none focus:ring-1 focus:ring-amber-500"
                        required
                      />
                    </div>
                    <div>
                      <label className="text-[11px] font-semibold text-amber-900 block">
                        Payment Date *
                      </label>
                      <input
                        type="date"
                        max={getTodayDateString()}
                        value={paymentDate ?? ''}
                        onChange={(e) => setPaymentDate(e.target.value)}
                        className="w-full text-xs font-mono border border-amber-300 rounded px-2.5 py-1.5 bg-white focus:outline-none focus:ring-1 focus:ring-amber-500"
                        required
                      />
                    </div>
                    <div>
                      <label className="text-[11px] font-semibold text-amber-900 block">Note</label>
                      <input
                        type="text"
                        value={paymentNote ?? ''}
                        onChange={(e) => setPaymentNote(e.target.value)}
                        placeholder="Optional note..."
                        className="w-full text-xs border border-amber-300 rounded px-2.5 py-1.5 bg-white focus:outline-none focus:ring-1 focus:ring-amber-500"
                      />
                    </div>
                  </div>

                  <div className="flex justify-end pt-1">
                    <button
                      type="submit"
                      disabled={submittingPayment}
                      className="px-4 py-1.5 bg-[#2563EB] hover:bg-[#1D4ED8] active:bg-[#1E40AF] text-white text-xs font-bold rounded-lg shadow-xs transition disabled:opacity-50 cursor-pointer focus:outline-none focus-visible:ring-2 focus-visible:ring-[#2563EB]"
                    >
                      {submittingPayment ? 'Recording...' : 'Confirm Cash Payment'}
                    </button>
                  </div>
                </form>
              )}

              {/* Invoice Note (if present) */}
              {invoice.note && (
                <div className="bg-neutral-50 p-3.5 rounded-xl border border-neutral-200 text-xs">
                  <span className="font-bold text-neutral-700 block mb-1">Invoice Note</span>
                  <p className="text-neutral-600 break-words whitespace-pre-wrap">{invoice.note}</p>
                </div>
              )}

              {/* Payment History Table (Prompt: Every payment stored as separate transaction) */}
              <div>
                <h4 className="text-xs font-bold uppercase tracking-wider text-neutral-700 mb-2 flex items-center gap-1.5">
                  <Clock className="w-3.5 h-3.5 text-orange-500 shrink-0" />
                  Cash Payment History ({invoicePayments.length} transactions)
                </h4>
                {invoicePayments.length === 0 ? (
                  <div className="p-4 bg-neutral-50 border border-neutral-200 rounded-lg text-xs text-neutral-500 text-center">
                    No cash payments recorded for this invoice yet.
                  </div>
                ) : (
                  <div className="border border-neutral-200 rounded-lg overflow-x-auto shadow-xs">
                    <table className="w-full min-w-[500px] sm:min-w-full border-collapse text-xs">
                      <thead>
                        <tr className="bg-neutral-100 text-neutral-700 font-semibold text-left">
                          <th className="py-2 px-3 whitespace-nowrap">Date</th>
                          <th className="py-2 px-3 whitespace-nowrap">Transaction ID</th>
                          <th className="py-2 px-3 whitespace-nowrap">Method</th>
                          <th className="py-2 px-3">Note</th>
                          <th className="py-2 px-3 text-right whitespace-nowrap">Amount</th>
                          <th className="py-2 px-3 text-right whitespace-nowrap">Receipt</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-neutral-200">
                        {invoicePayments.map((p) => (
                          <tr key={p.id} className="hover:bg-neutral-50">
                            <td className="py-2 px-3 font-mono text-neutral-800 whitespace-nowrap">
                              {formatDate(p.date)}
                            </td>
                            <td className="py-2 px-3 font-mono text-[11px] text-neutral-500 whitespace-nowrap">
                              #{p.id.slice(0, 8)}
                            </td>
                            <td className="py-2 px-3 whitespace-nowrap">
                              <span className="px-1.5 py-0.5 text-[10px] font-bold bg-amber-100 text-amber-800 rounded">
                                CASH
                              </span>
                            </td>
                            <td className="py-2 px-3 text-neutral-600 break-words max-w-[150px] sm:max-w-none">
                              {p.isCorrection && (
                                <span className="mr-1 px-1 py-0.2 bg-amber-100 text-amber-900 rounded font-semibold text-[9px]">
                                  Adj
                                </span>
                              )}
                              {p.note || '—'}
                            </td>
                            <td className="py-2 px-3 text-right font-mono font-bold text-emerald-700 whitespace-nowrap">
                              +{formatAFN(p.amount)}
                            </td>
                            <td className="py-2 px-3 text-right whitespace-nowrap">
                              <button
                                type="button"
                                onClick={() => setSelectedReceiptPayment(p)}
                                className="p-1.5 sm:px-2 sm:py-0.5 text-[11px] font-semibold bg-neutral-100 hover:bg-neutral-200 text-neutral-800 rounded border border-neutral-300 transition inline-flex items-center gap-1 cursor-pointer active:scale-95"
                                title="View Receipt"
                                aria-label="View Receipt"
                              >
                                <Receipt className="w-3.5 h-3.5 sm:w-3 sm:h-3 text-neutral-700 shrink-0" />
                                <span className="hidden sm:inline">Receipt</span>
                              </button>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}
              </div>

              {/* Items Summary */}
              <div>
                <h4 className="text-xs font-bold uppercase tracking-wider text-neutral-700 mb-2">
                  Invoice Items
                </h4>
                <div className="border border-neutral-200 rounded-lg overflow-x-auto shadow-xs">
                  <table className="w-full min-w-[480px] sm:min-w-full border-collapse text-xs">
                    <thead>
                      <tr className="bg-neutral-100 text-neutral-700 font-semibold">
                        <th className="py-2 px-2 text-center w-12 shrink-0">#</th>
                        <th className="py-2 px-3 text-left">Description</th>
                        <th className="py-2 px-2 text-center w-16 sm:w-20 shrink-0">Quantity</th>
                        <th className="py-2 px-3 text-right w-24 sm:w-28 shrink-0">Price</th>
                        {isAuthorizedForProfitSummary && (
                          <>
                            <th className="py-2 px-3 text-right w-24 sm:w-28 shrink-0 text-neutral-600">
                              Cost
                            </th>
                            <th className="py-2 px-3 text-right w-24 sm:w-28 shrink-0 text-emerald-800">
                              Profit
                            </th>
                          </>
                        )}
                        <th className="py-2 px-3 text-right w-28 sm:w-32 shrink-0">Total</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-neutral-200 bg-white">
                      {invoice.items
                        .filter((it) => it.description || it.quantity)
                        .map((it, idx) => {
                          const hasCost =
                            it.purchaseCost !== undefined &&
                            it.purchaseCost !== '' &&
                            !isNaN(Number(it.purchaseCost));
                          const lineProfit =
                            it.totalProfit !== undefined
                              ? it.totalProfit
                              : hasCost
                              ? Math.round(
                                  ((Number(it.unitPrice) || 0) - Number(it.purchaseCost)) *
                                    (Number(it.quantity) || 0) *
                                    100
                                ) / 100
                              : undefined;

                          return (
                            <tr key={idx} className="hover:bg-neutral-50">
                              <td className="py-2 px-2 text-center text-neutral-400 font-mono">
                                {it.sNo}
                              </td>
                              <td className="py-2 px-3 font-medium text-neutral-800 break-words max-w-[200px] sm:max-w-none">
                                {it.description}
                              </td>
                              <td className="py-2 px-2 text-center font-mono text-neutral-700">
                                {it.quantity}
                              </td>
                              <td className="py-2 px-3 text-right font-mono text-neutral-700 whitespace-nowrap">
                                {formatAFN(Number(it.unitPrice))}
                              </td>
                              {isAuthorizedForProfitSummary && (
                                <>
                                  <td className="py-2 px-3 text-right font-mono text-neutral-600 whitespace-nowrap">
                                    {hasCost ? (
                                      formatAFN(Number(it.purchaseCost))
                                    ) : (
                                      <span className="text-neutral-400 font-sans italic text-[11px]">
                                        Unrecorded
                                      </span>
                                    )}
                                  </td>
                                  <td className="py-2 px-3 text-right font-mono whitespace-nowrap font-medium">
                                    {lineProfit !== undefined ? (
                                      <span
                                        className={
                                          lineProfit >= 0 ? 'text-emerald-700' : 'text-rose-600'
                                        }
                                      >
                                        {formatAFN(lineProfit)}
                                      </span>
                                    ) : (
                                      <span className="text-neutral-400 font-sans italic text-[11px]">
                                        —
                                      </span>
                                    )}
                                  </td>
                                </>
                              )}
                              <td className="py-2 px-3 text-right font-mono font-bold text-neutral-900 whitespace-nowrap">
                                {formatAFN(it.totalAmount)}
                              </td>
                            </tr>
                          );
                        })}
                    </tbody>
                  </table>
                </div>
              </div>

              {/* ================= INVOICE EXPENSES SECTION ================= */}
              {canAccessInvoiceExpenses && (
                <div
                  data-testid="invoice-expenses-section"
                  className="bg-neutral-50 rounded-xl border border-neutral-200 p-3.5 sm:p-4 space-y-3"
                >
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-neutral-200 pb-2.5">
                    <div className="flex items-center gap-2">
                      <div className="w-6 h-6 rounded-md bg-neutral-900 text-white flex items-center justify-center shrink-0">
                        <Receipt className="w-3.5 h-3.5 text-orange-400" />
                      </div>
                      <div>
                        <h4 className="text-xs font-bold uppercase tracking-wider text-neutral-900 flex items-center gap-2">
                          Invoice Expenses
                          <span className="text-[10px] font-semibold font-mono text-neutral-600 normal-case bg-neutral-200/80 px-2 py-0.5 rounded border border-neutral-300">
                            Direct Costs
                          </span>
                        </h4>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      {isAuthorizedForProfitSummary && (
                        <button
                          type="button"
                          id="btn-print-invoice-expenses"
                          onClick={() => setIsExpenseReportModalOpen(true)}
                          className="px-2.5 py-1 text-xs font-semibold rounded bg-white hover:bg-neutral-100 text-neutral-800 border border-neutral-300 transition inline-flex items-center gap-1.5 cursor-pointer shadow-2xs active:scale-95"
                          title="Print / Download Internal Expense Report PDF"
                        >
                          <Printer className="w-3.5 h-3.5 text-neutral-600" />
                          <span>Expense Report PDF</span>
                        </button>
                      )}

                      {canAddExpense ? (
                        <button
                          type="button"
                          id="btn-add-invoice-expense"
                          onClick={handleOpenAddExpense}
                          className="px-2.5 py-1 text-xs font-semibold rounded-lg bg-[#2563EB] hover:bg-[#1D4ED8] active:bg-[#1E40AF] text-white transition inline-flex items-center gap-1.5 cursor-pointer shadow-xs focus:outline-none focus-visible:ring-2 focus-visible:ring-[#2563EB]"
                          title="Add Expense"
                        >
                          <PlusCircle className="w-3.5 h-3.5 text-white" />
                          <span>Add Expense</span>
                        </button>
                      ) : userProfile?.role === 'super_admin' ? (
                        <div
                          className="px-2.5 py-1 text-xs font-semibold rounded-lg bg-amber-50 text-amber-800 border border-amber-200 inline-flex items-center gap-1.5 select-none"
                          title="Super Admin cannot create or submit expense requests. Creation is restricted to Invoice Managers and Payment Collectors."
                        >
                          <ShieldAlert className="w-3.5 h-3.5 text-amber-600" />
                          <span>Approval &amp; Review Mode</span>
                        </div>
                      ) : null}
                    </div>
                  </div>

                  {/* Expense Summary KPI Cards */}
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5 sm:gap-3">
                    {/* 1. Total Expenses */}
                    <div className="bg-white p-2.5 sm:p-3 rounded-lg border border-neutral-200 shadow-2xs">
                      <span className="text-[10px] font-bold uppercase tracking-wider text-neutral-500 block">
                        Total Expenses
                      </span>
                      <span className="text-xs sm:text-sm font-bold font-mono text-neutral-900 block mt-1 break-words">
                        {formatAFN(expenseSummary.totalExpenses)}
                      </span>
                      <span className="text-[9px] text-neutral-400 block mt-0.5">
                        Sum of linked expenses
                      </span>
                    </div>

                    {/* 2. Number of Expenses */}
                    <div className="bg-white p-2.5 sm:p-3 rounded-lg border border-neutral-200 shadow-2xs">
                      <span className="text-[10px] font-bold uppercase tracking-wider text-neutral-500 block">
                        Number of Expenses
                      </span>
                      <span className="text-xs sm:text-sm font-bold font-mono text-neutral-900 block mt-1 break-words">
                        {expenseSummary.count} record{expenseSummary.count === 1 ? '' : 's'}
                      </span>
                      <span className="text-[9px] text-neutral-400 block mt-0.5">
                        Independent invoice expenses
                      </span>
                    </div>

                    {/* 3. Latest Expense Date */}
                    <div className="bg-white p-2.5 sm:p-3 rounded-lg border border-neutral-200 shadow-2xs">
                      <span className="text-[10px] font-bold uppercase tracking-wider text-neutral-500 block">
                        Latest Expense Date
                      </span>
                      <span className="text-xs sm:text-sm font-bold font-mono text-neutral-900 block mt-1 break-words">
                        {expenseSummary.latestDate ? formatDate(expenseSummary.latestDate) : 'None'}
                      </span>
                      <span className="text-[9px] text-neutral-400 block mt-0.5">
                        Most recent recorded
                      </span>
                    </div>
                  </div>

                  {/* Expenses List / Table */}
                  {invoiceExpenses.length === 0 ? (
                    <div className="p-4 bg-white border border-neutral-200 rounded-lg text-xs text-neutral-500 text-center">
                      {canAddExpense ? (
                        <>No expenses recorded for this invoice yet. Click &ldquo;Add Expense&rdquo; to submit direct operating costs.</>
                      ) : (
                        <>No expenses recorded for this invoice yet.</>
                      )}
                    </div>
                  ) : (
                    <div className="border border-neutral-200 rounded-lg overflow-x-auto shadow-xs bg-white">
                      <table className="w-full min-w-[760px] sm:min-w-full border-collapse text-xs">
                        <thead>
                          <tr className="bg-neutral-100 text-neutral-700 font-semibold text-left">
                            <th className="py-2 px-3 whitespace-nowrap">Description</th>
                            <th className="py-2 px-3 whitespace-nowrap">Category</th>
                            <th className="py-2 px-3 whitespace-nowrap">Date</th>
                            <th className="py-2 px-3 whitespace-nowrap">Status</th>
                            <th className="py-2 px-3 whitespace-nowrap">Requested By</th>
                            <th className="py-2 px-3 whitespace-nowrap">Created At</th>
                            <th className="py-2 px-3 text-right whitespace-nowrap">Amount</th>
                            <th className="py-2 px-3 text-center whitespace-nowrap">Actions</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-neutral-200">
                          {invoiceExpenses.map((exp) => {
                            const activeUserId = userProfile?.id || (userProfile as any)?.userId || '';
                            const isOwner =
                              Boolean(activeUserId && exp.requestedBy && exp.requestedBy.toLowerCase() === activeUserId.toLowerCase());
                            const isSelf = isOwner;
                            const isSuperAdmin = userProfile?.role === 'super_admin';
                            const isInvoiceManager = userProfile?.role === 'invoice_manager';
                            const isCollector = userProfile?.role === 'payment_collector';

                            // Workflow capability checks:
                            const canManagerApprove =
                              isInvoiceManager &&
                              exp.status === 'pending_manager' &&
                              !isSelf; // Prevents self-approval and Super Admin bypass

                            const canAdminApprove =
                              isSuperAdmin &&
                              exp.status === 'pending_admin' &&
                              !isSelf; // Prevents self-approval

                            const canAdminExecute =
                              isSuperAdmin && exp.status === 'approved';

                            const canReject =
                              !isSelf &&
                              ((isInvoiceManager && exp.status === 'pending_manager') ||
                               (isSuperAdmin && (exp.status === 'pending_admin' || exp.status === 'pending_manager')));

                            // Only owner can edit/resubmit their own draft or rejected expense
                            // Super Admin is STRICTLY forbidden from editing requested expenses
                            const canEdit = isOwner && !isSuperAdmin && (exp.status === 'draft' || exp.status === 'rejected');

                            const canDelete =
                              // Approved and executed expenses are immutable and cannot be deleted
                              exp.status !== 'executed' &&
                              exp.status !== 'approved' &&
                              (isSuperAdmin || (isOwner && (exp.status === 'draft' || exp.status === 'rejected')));

                            const hasHistory =
                              Boolean(
                                (exp.approvalHistory && exp.approvalHistory.length > 0) ||
                                (exp.timeline && exp.timeline.length > 0) ||
                                exp.rejectionReason ||
                                exp.requestedBy ||
                                exp.createdAt
                              );

                            return (
                              <React.Fragment key={exp.id}>
                                <tr className="hover:bg-neutral-50">
                                  <td className="py-2 px-3 text-neutral-900 font-medium">
                                    <div className="break-words max-w-xs sm:max-w-sm whitespace-normal">{exp.title}</div>
                                    {exp.note && (
                                      <div className="text-[11px] text-neutral-500 font-normal break-words max-w-xs sm:max-w-sm whitespace-normal mt-0.5">{exp.note}</div>
                                    )}
                                    {exp.rejectionReason && exp.status === 'rejected' && (
                                      <div className="text-[11px] text-rose-700 bg-rose-50 border border-rose-200 rounded px-1.5 py-0.5 mt-1 font-normal break-words">
                                        <span className="font-bold">Rejection note:</span> {exp.rejectionReason}
                                      </div>
                                    )}
                                  </td>
                                  <td className="py-2 px-3 text-neutral-600 whitespace-nowrap">
                                    <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-neutral-100 text-neutral-700 border border-neutral-200">
                                      {exp.category || 'General'}
                                    </span>
                                  </td>
                                  <td className="py-2 px-3 font-mono text-neutral-800 whitespace-nowrap">
                                    {formatDate(exp.date)}
                                  </td>
                                  <td className="py-2 px-3 whitespace-nowrap">
                                    <ExpenseStatusBadge expense={exp} />
                                  </td>
                                  <td className="py-2 px-3 text-neutral-600 whitespace-nowrap">
                                    <div className="text-[10px] text-neutral-500 font-semibold tracking-wide">
                                      Requested By: {formatRoleLabel(exp.requestedByRole, exp.requestedByJobTitle)}
                                    </div>
                                    <div className="font-bold text-neutral-900 text-xs">
                                      {exp.requestedByName || 'Staff Member'}
                                    </div>
                                  </td>
                                  <td className="py-2 px-3 text-neutral-500 font-mono text-[11px] whitespace-nowrap">
                                    {exp.createdAt ? formatDate(exp.createdAt) : '—'}
                                  </td>
                                  <td className="py-2 px-3 text-right font-mono font-bold text-neutral-900 whitespace-nowrap">
                                    {formatAFN(exp.amount)}
                                  </td>
                                  <td className="py-2 px-3 text-center whitespace-nowrap" onClick={(e) => e.stopPropagation()}>
                                    <div className="inline-flex items-center gap-1">
                                      {/* Manager Approval Action */}
                                      {canManagerApprove && (
                                        <button
                                          type="button"
                                          disabled={Boolean(advancingExpenseId)}
                                          onClick={() => handleAdvanceWorkflow(exp, 'manager_approve')}
                                          className="px-2 py-0.5 text-[11px] font-bold rounded bg-amber-500 hover:bg-amber-600 text-white transition cursor-pointer shadow-2xs disabled:opacity-50 inline-flex items-center gap-0.5"
                                          title="Manager Approval: Advance to Super Admin stage"
                                        >
                                          {advancingExpenseId === exp.id ? (
                                            <Loader2 className="w-3 h-3 animate-spin" />
                                          ) : (
                                            <Check className="w-3 h-3" />
                                          )}
                                          <span>Manager Approve</span>
                                        </button>
                                      )}

                                      {/* Admin Approval Action */}
                                      {canAdminApprove && (
                                        <button
                                          type="button"
                                          disabled={Boolean(advancingExpenseId)}
                                          onClick={() => handleAdvanceWorkflow(exp, 'admin_approve')}
                                          className="px-2 py-0.5 text-[11px] font-bold rounded bg-emerald-600 hover:bg-emerald-700 text-white transition cursor-pointer shadow-2xs disabled:opacity-50 inline-flex items-center gap-0.5"
                                          title="Super Admin Final Approval"
                                        >
                                          {advancingExpenseId === exp.id ? (
                                            <Loader2 className="w-3 h-3 animate-spin" />
                                          ) : (
                                            <Check className="w-3 h-3" />
                                          )}
                                          <span>Admin Approve</span>
                                        </button>
                                      )}

                                      {/* Admin Execute & Disburse Action */}
                                      {canAdminExecute && (
                                        <button
                                          type="button"
                                          disabled={Boolean(advancingExpenseId)}
                                          onClick={() => handleAdvanceWorkflow(exp, 'admin_execute')}
                                          className="px-2 py-0.5 text-[11px] font-bold rounded bg-neutral-900 hover:bg-black text-white transition cursor-pointer shadow-2xs disabled:opacity-50 inline-flex items-center gap-0.5"
                                          title="Execute & Disburse Funds"
                                        >
                                          {advancingExpenseId === exp.id ? (
                                            <Loader2 className="w-3 h-3 animate-spin" />
                                          ) : (
                                            <CheckCircle2 className="w-3 h-3 text-emerald-400" />
                                          )}
                                          <span>Disburse</span>
                                        </button>
                                      )}

                                      {/* Reject Action with Reason Modal */}
                                      {canReject && !isSelf && (
                                        <button
                                          type="button"
                                          disabled={Boolean(advancingExpenseId)}
                                          onClick={() => handleOpenRejectModal(exp)}
                                          className="px-1.5 py-0.5 text-[11px] font-semibold rounded bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200 transition cursor-pointer shadow-2xs inline-flex items-center gap-0.5"
                                          title="Reject expense request with reason"
                                        >
                                          <XCircle className="w-3 h-3 text-rose-600" />
                                          <span>Reject</span>
                                        </button>
                                      )}

                                      {/* Timeline / History Audit Modal Trigger */}
                                      {hasHistory && (
                                        <button
                                          type="button"
                                          onClick={() => setSelectedExpenseForHistory(exp)}
                                          className="p-1 text-neutral-500 hover:text-neutral-900 hover:bg-neutral-100 rounded transition cursor-pointer"
                                          title="View Approval History & Audit Trail"
                                          aria-label="View Approval History"
                                        >
                                          <History className="w-3.5 h-3.5 text-neutral-600" />
                                        </button>
                                      )}

                                      {/* Workflow Info Box Inline Toggle */}
                                      <button
                                        type="button"
                                        onClick={() =>
                                          setExpandedWorkflowExpenseId(
                                            expandedWorkflowExpenseId === exp.id ? null : exp.id
                                          )
                                        }
                                        className={`p-1 rounded transition cursor-pointer ${
                                          expandedWorkflowExpenseId === exp.id
                                            ? 'text-blue-700 bg-blue-100'
                                            : 'text-neutral-500 hover:text-neutral-900 hover:bg-neutral-100'
                                        }`}
                                        title={
                                          expandedWorkflowExpenseId === exp.id
                                            ? 'Collapse Workflow Information'
                                            : 'View Workflow Requester & Approver Information'
                                        }
                                        aria-label="Toggle Workflow Details"
                                      >
                                        {expandedWorkflowExpenseId === exp.id ? (
                                          <ChevronUp className="w-3.5 h-3.5 text-blue-700" />
                                        ) : (
                                          <ChevronDown className="w-3.5 h-3.5 text-neutral-600" />
                                        )}
                                      </button>

                                      {/* Edit / Resubmit */}
                                      {canEdit && (
                                        <button
                                          type="button"
                                          onClick={() => handleOpenEditExpense(exp)}
                                          className={`p-1 rounded transition cursor-pointer ${
                                            exp.status === 'rejected'
                                              ? 'text-blue-600 hover:text-blue-800 hover:bg-blue-50'
                                              : 'text-neutral-500 hover:text-neutral-900 hover:bg-neutral-100'
                                          }`}
                                          title={exp.status === 'rejected' ? 'Edit & Resubmit Rejected Expense' : 'Edit Expense'}
                                          aria-label={exp.status === 'rejected' ? 'Edit & Resubmit Rejected Expense' : 'Edit Expense'}
                                        >
                                          {exp.status === 'rejected' ? (
                                            <RotateCcw className="w-3.5 h-3.5 text-blue-600" />
                                          ) : (
                                            <Pencil className="w-3.5 h-3.5 text-neutral-600" />
                                          )}
                                        </button>
                                      )}

                                      {/* Delete */}
                                      {canDelete && (
                                        <button
                                          type="button"
                                          onClick={() => setExpenseToDelete(exp)}
                                          className="p-1 text-rose-500 hover:text-rose-700 hover:bg-rose-50 rounded transition cursor-pointer"
                                          title="Delete Expense"
                                          aria-label="Delete Expense"
                                        >
                                          <Trash2 className="w-3.5 h-3.5 text-rose-600" />
                                        </button>
                                      )}
                                    </div>
                                  </td>
                                </tr>

                                {/* Expanded Workflow Information Box Row */}
                                {expandedWorkflowExpenseId === exp.id && (
                                  <tr className="bg-neutral-50/70">
                                    <td colSpan={8} className="p-3 border-t border-b border-neutral-200">
                                      <ExpenseWorkflowInfoBox expense={exp} users={users} />
                                    </td>
                                  </tr>
                                )}
                              </React.Fragment>
                            );
                          })}
                        </tbody>
                      </table>
                    </div>
                  )}
                </div>
              )}

              {/* Internal Invoice Profit Summary (Phase 2) - Authorized Staff Only (super_admin, invoice_manager) */}
              {isAuthorizedForProfitSummary && profitSummary && (
                <div
                  data-testid="invoice-profit-summary"
                  className="bg-neutral-50 rounded-xl border border-neutral-200 p-3.5 sm:p-4 space-y-3"
                >
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-neutral-200 pb-2.5">
                    <div className="flex items-center gap-2">
                      <div className="w-6 h-6 rounded-md bg-neutral-900 text-white flex items-center justify-center shrink-0">
                        <TrendingUp className="w-3.5 h-3.5 text-orange-400" />
                      </div>
                      <div>
                        <h4 className="text-xs font-bold uppercase tracking-wider text-neutral-900 flex items-center gap-2">
                          Profit Summary
                          <span className="text-[10px] font-semibold font-mono text-neutral-600 normal-case bg-neutral-200/80 px-2 py-0.5 rounded border border-neutral-300">
                            Internal Only / Administrative Use
                          </span>
                        </h4>
                      </div>
                    </div>
                    {profitSummary.hasCompleteCostData ? (
                      <span className="text-[11px] font-medium text-emerald-700 bg-emerald-50 border border-emerald-200 px-2 py-0.5 rounded-full inline-flex items-center gap-1 w-fit">
                        <CheckCircle2 className="w-3 h-3 text-emerald-600 shrink-0" />
                        Complete cost data ({profitSummary.itemsWithCostCount}/{profitSummary.totalItemsCount} items)
                      </span>
                    ) : profitSummary.totalItemsCount === 0 ? (
                      <span className="text-[11px] font-medium text-neutral-500 bg-neutral-100 border border-neutral-200 px-2 py-0.5 rounded-full inline-flex items-center gap-1 w-fit">
                        No billable items
                      </span>
                    ) : (
                      <span className="text-[11px] font-medium text-amber-800 bg-amber-50 border border-amber-200 px-2 py-0.5 rounded-full inline-flex items-center gap-1 w-fit">
                        <AlertTriangle className="w-3 h-3 text-amber-600 shrink-0" />
                        Incomplete cost data ({profitSummary.itemsWithCostCount}/{profitSummary.totalItemsCount} items with cost)
                      </span>
                    )}
                  </div>

                  {/* Warning banner when purchase cost data is incomplete */}
                  {!profitSummary.hasCompleteCostData && profitSummary.totalItemsCount > 0 && (
                    <div className="p-2.5 bg-amber-50 border border-amber-200 rounded-lg flex items-start gap-2 text-xs text-amber-900">
                      <AlertCircle className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
                      <div>
                        <span className="font-bold">Incomplete Cost Data:</span> {profitSummary.missingCostItemsCount} of {profitSummary.totalItemsCount} item(s) do not have purchase cost recorded. Historical costs are never fabricated; profit figures reflect available recorded costs only.
                      </div>
                    </div>
                  )}

                  {/* Profit Metrics Grid */}
                  <div className="grid grid-cols-2 sm:grid-cols-5 gap-2.5 sm:gap-3">
                    {/* Metric 1: Total Sales */}
                    <div className="bg-white p-2.5 sm:p-3 rounded-lg border border-neutral-200 shadow-2xs">
                      <span className="text-[10px] font-bold uppercase tracking-wider text-neutral-500 block">
                        Total Sales
                      </span>
                      <span className="text-xs sm:text-sm font-bold font-mono text-neutral-900 block mt-1 break-words">
                        {formatAFN(profitSummary.totalSales)}
                      </span>
                      <span className="text-[9px] text-neutral-400 block mt-0.5">
                        Sum of item sales
                      </span>
                    </div>

                    {/* Metric 2: Total Item Cost */}
                    <div className="bg-white p-2.5 sm:p-3 rounded-lg border border-neutral-200 shadow-2xs">
                      <span className="text-[10px] font-bold uppercase tracking-wider text-neutral-500 block">
                        Total Item Cost
                      </span>
                      <span className="text-xs sm:text-sm font-bold font-mono text-neutral-900 block mt-1 break-words">
                        {formatAFN(profitSummary.totalItemCost)}
                      </span>
                      <span className="text-[9px] text-neutral-400 block mt-0.5">
                        Sum of (Cost × Qty)
                      </span>
                    </div>

                    {/* Metric 3: Gross Profit */}
                    <div className={`p-2.5 sm:p-3 rounded-lg border shadow-2xs ${
                      profitSummary.grossProfit >= 0
                        ? 'bg-emerald-50/50 border-emerald-200 text-emerald-950'
                        : 'bg-rose-50/50 border-rose-200 text-rose-950'
                    }`}>
                      <span className="text-[10px] font-bold uppercase tracking-wider text-neutral-600 block">
                        Gross Profit
                      </span>
                      <span className={`text-xs sm:text-sm font-black font-mono block mt-1 break-words ${
                        profitSummary.grossProfit >= 0 ? 'text-emerald-700' : 'text-rose-700'
                      }`}>
                        {formatAFN(profitSummary.grossProfit)}
                      </span>
                      <span className="text-[9px] text-neutral-500 block mt-0.5">
                        Sales − Item Cost
                      </span>
                    </div>

                    {/* Metric 4: Total Expenses */}
                    <div className="bg-white p-2.5 sm:p-3 rounded-lg border border-neutral-200 shadow-2xs">
                      <span className="text-[10px] font-bold uppercase tracking-wider text-neutral-500 block">
                        Total Expenses
                      </span>
                      <span className="text-xs sm:text-sm font-bold font-mono text-neutral-900 block mt-1 break-words">
                        {formatAFN(profitSummary.totalExpenses)}
                      </span>
                      <span className="text-[9px] text-neutral-500 block mt-0.5">
                        {profitSummary.invoiceExpensesCount} linked expense{profitSummary.invoiceExpensesCount === 1 ? '' : 's'}
                      </span>
                    </div>

                    {/* Metric 5: Net Profit */}
                    <div className={`col-span-2 sm:col-span-1 p-2.5 sm:p-3 rounded-lg border shadow-2xs ${
                      profitSummary.netProfit >= 0
                        ? 'bg-sky-50/60 border-sky-200 text-sky-950'
                        : 'bg-rose-50/60 border-rose-200 text-rose-950'
                    }`}>
                      <span className="text-[10px] font-bold uppercase tracking-wider text-neutral-600 block">
                        Net Profit
                      </span>
                      <span className={`text-xs sm:text-sm font-black font-mono block mt-1 break-words ${
                        profitSummary.netProfit >= 0 ? 'text-sky-800' : 'text-rose-700'
                      }`}>
                        {formatAFN(profitSummary.netProfit)}
                      </span>
                      <span className="text-[9px] text-neutral-500 block mt-0.5">
                        Gross − Expenses
                      </span>
                    </div>
                  </div>
                </div>
              )}
            </>
          )}
        </div>

        {/* Footer */}
        <div className="px-3.5 py-3 sm:px-6 sm:py-3.5 border-t border-neutral-200 bg-neutral-50 flex items-center justify-between gap-2 shrink-0">
          <div className="text-xs text-neutral-500 whitespace-nowrap">
            Created on {formatDate(invoice.createdAt || invoice.date)}
          </div>
          <div className="flex items-center gap-1.5 sm:gap-2">
            <button
              type="button"
              onClick={handleDownloadPdf}
              disabled={!invoice}
              className="p-2 sm:px-3 sm:py-1.5 text-xs font-semibold rounded bg-white hover:bg-neutral-100 border border-neutral-300 text-orange-600 transition inline-flex items-center justify-center gap-1.5 active:scale-95 disabled:opacity-50 shrink-0 cursor-pointer"
              title="Print / Save Invoice as PDF"
              aria-label="Print / Save Invoice as PDF"
            >
              <Printer className="w-4 h-4 sm:w-3.5 sm:h-3.5 shrink-0" />
              <span className="hidden sm:inline">Print / Save as PDF</span>
            </button>
            {onEdit && (
              <button
                type="button"
                disabled={isVoid || isLockedOrPaid || !permissions.canEditInvoice}
                onClick={() => {
                  if (isVoid || isLockedOrPaid || !permissions.canEditInvoice) return;
                  onClose();
                  onEdit(invoice);
                }}
                className={`p-2 sm:px-3 sm:py-1.5 text-xs font-semibold rounded border transition inline-flex items-center justify-center gap-1.5 shrink-0 ${
                  isVoid || isLockedOrPaid || !permissions.canEditInvoice
                    ? 'bg-neutral-100 text-neutral-400 border-neutral-200 cursor-not-allowed opacity-60 pointer-events-none'
                    : 'bg-white hover:bg-neutral-100 border-neutral-300 text-neutral-800 active:scale-95 cursor-pointer'
                }`}
                title={
                  isVoid
                    ? 'This invoice is void. Void invoices cannot be modified.'
                    : isLockedOrPaid
                    ? 'Invoice is locked (Fully Paid). Modifications disabled.'
                    : !permissions.canEditInvoice
                    ? 'You do not have permission to edit invoices.'
                    : 'Edit Invoice'
                }
                aria-label={
                  isVoid
                    ? 'Void Invoice'
                    : isLockedOrPaid
                    ? 'Locked (Paid)'
                    : 'Edit Invoice'
                }
                aria-disabled={isVoid || isLockedOrPaid || !permissions.canEditInvoice}
              >
                {isVoid ? (
                  <Ban className="w-4 h-4 sm:w-3.5 sm:h-3.5 text-neutral-400 shrink-0" />
                ) : isLockedOrPaid ? (
                  <Lock className="w-4 h-4 sm:w-3.5 sm:h-3.5 text-neutral-400 shrink-0" />
                ) : (
                  <Pencil className="w-4 h-4 sm:w-3.5 sm:h-3.5 text-neutral-600 shrink-0" />
                )}
                <span className="hidden sm:inline">
                  {isVoid ? 'Void' : isLockedOrPaid ? 'Locked (Paid)' : 'Edit Invoice'}
                </span>
              </button>
            )}
            <button
              type="button"
              onClick={onClose}
              className="p-2 sm:px-4 sm:py-1.5 text-xs font-semibold rounded-lg bg-neutral-100 hover:bg-neutral-200 active:bg-neutral-300 text-neutral-800 border border-neutral-300 transition inline-flex items-center justify-center gap-1 shrink-0 cursor-pointer shadow-2xs"
              title="Close"
              aria-label="Close"
            >
              <X className="w-4 h-4 sm:hidden shrink-0" />
              <span className="hidden sm:inline">Close</span>
            </button>
          </div>
        </div>
      </div>

      {selectedReceiptPayment && (
        <PaymentReceiptModal
          isOpen={!!selectedReceiptPayment}
          onClose={() => setSelectedReceiptPayment(null)}
          payment={selectedReceiptPayment}
          invoice={invoice}
          settings={settings}
        />
      )}

      {isAssignModalOpen && invoice && (
        <InvoiceAssignmentModal
          isOpen={isAssignModalOpen}
          onClose={() => setIsAssignModalOpen(false)}
          invoice={invoice}
          users={users}
        />
      )}

      {isPdfModalOpen && invoice && (
        <InvoicePdfDownloadModal
          isOpen={isPdfModalOpen}
          onClose={() => setIsPdfModalOpen(false)}
          invoice={invoice}
          payments={payments}
          settings={settings}
          userProfile={userProfile}
          totalPaidOverride={totalPaid}
        />
      )}

      {isExpenseReportModalOpen && invoice && (
        <InternalInvoiceExpenseReportModal
          isOpen={isExpenseReportModalOpen}
          onClose={() => setIsExpenseReportModalOpen(false)}
          invoice={invoice}
          expenses={invoiceExpenses}
          settings={settings}
          userProfile={userProfile}
        />
      )}

      {/* State Change Confirmation Modal (Customer Accept/Reject or Admin Mark Payable/Rejected) */}
      {showStateConfirmModal && invoice && stateChangeAction && (
        <div className="fixed inset-0 z-60 flex items-center justify-center p-4 bg-black/70 backdrop-blur-xs animate-in fade-in duration-150">
          <div className="bg-white rounded-2xl shadow-2xl max-w-md w-full overflow-hidden border border-neutral-200">
            <div className={`p-5 text-white ${stateChangeAction === 'payable' ? 'bg-emerald-700' : 'bg-rose-700'}`}>
              <div className="flex items-center gap-3">
                <div className="p-2 bg-white/20 rounded-xl">
                  {stateChangeAction === 'payable' ? (
                    <CheckCircle2 className="w-6 h-6 text-white" />
                  ) : (
                    <XCircle className="w-6 h-6 text-white" />
                  )}
                </div>
                <div>
                  <h3 className="text-base font-bold text-white">
                    {userProfile?.role === 'customer'
                      ? stateChangeAction === 'payable'
                        ? 'Accept Quotation'
                        : 'Reject Quotation'
                      : stateChangeAction === 'payable'
                      ? 'Mark Quotation as Payable'
                      : 'Mark Quotation as Rejected'}
                  </h3>
                  <p className="text-xs text-white/80 font-mono mt-0.5">
                    {invoice.billNumber} • AFN {Number(invoice.totalAmount || 0).toLocaleString('en-US')}
                  </p>
                </div>
              </div>
            </div>

            <div className="p-5 space-y-4">
              <p className="text-xs text-neutral-600 leading-relaxed">
                {userProfile?.role === 'customer' ? (
                  stateChangeAction === 'payable' ? (
                    <>
                      Are you sure you want to <strong>accept quotation {invoice.billNumber}</strong>?
                      Upon acceptance, this will become an active payable order with Sarwan Technology.
                    </>
                  ) : (
                    <>
                      Are you sure you want to <strong>decline quotation {invoice.billNumber}</strong>?
                      This price offer will be marked as rejected.
                    </>
                  )
                ) : stateChangeAction === 'payable' ? (
                  <>
                    Are you sure you want to mark quotation <strong>{invoice.billNumber}</strong> as <strong>Payable</strong>?
                    This will confirm the sale, include it in business sales totals, receivables, and customer metrics, and enable cash collection and collector assignment.
                  </>
                ) : (
                  <>
                    Are you sure you want to mark quotation <strong>{invoice.billNumber}</strong> as <strong>Rejected</strong>?
                    It will be excluded from all financial reports, sales figures, and receivables.
                  </>
                )}
              </p>

              <div className="p-3 bg-neutral-50 rounded-xl border border-neutral-200 text-[11px] space-y-1 text-neutral-600">
                <div className="flex justify-between">
                  <span className="text-neutral-400">Customer:</span>
                  <span className="font-semibold text-neutral-800">{invoice.customerSnapshot?.name}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-neutral-400">Total Amount:</span>
                  <span className="font-bold text-neutral-900 font-mono">AFN {Number(invoice.totalAmount || 0).toLocaleString('en-US')}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-neutral-400">Actor:</span>
                  <span className="font-medium text-neutral-800">{userProfile?.name || 'Authorized User'} ({userProfile?.role === 'customer' ? 'Customer' : userProfile?.role === 'super_admin' ? 'Super Admin' : 'Invoice Manager'})</span>
                </div>
              </div>

              <div className="flex items-center justify-end gap-2 pt-2 border-t border-neutral-100">
                <button
                  type="button"
                  disabled={isStateChanging}
                  onClick={() => {
                    setShowStateConfirmModal(false);
                    setStateChangeAction(null);
                  }}
                  className="px-4 py-2 text-xs font-semibold rounded-lg bg-neutral-100 hover:bg-neutral-200 text-neutral-700 transition cursor-pointer disabled:opacity-50"
                >
                  Cancel
                </button>
                <button
                  type="button"
                  disabled={isStateChanging}
                  onClick={() => handleUpdateBillingState(stateChangeAction)}
                  className={`px-4 py-2 text-xs font-bold rounded-lg text-white transition inline-flex items-center gap-1.5 shadow-sm cursor-pointer disabled:opacity-50 ${
                    stateChangeAction === 'payable'
                      ? 'bg-emerald-600 hover:bg-emerald-700 active:scale-95'
                      : 'bg-rose-600 hover:bg-rose-700 active:scale-95'
                  }`}
                >
                  {isStateChanging ? (
                    <>
                      <Loader2 className="w-3.5 h-3.5 animate-spin" />
                      Updating...
                    </>
                  ) : stateChangeAction === 'payable' ? (
                    <>
                      <CheckCircle2 className="w-3.5 h-3.5" />
                      {userProfile?.role === 'customer' ? 'Yes, Accept Quotation' : 'Confirm & Mark Payable'}
                    </>
                  ) : (
                    <>
                      <XCircle className="w-3.5 h-3.5" />
                      {userProfile?.role === 'customer' ? 'Yes, Reject Quotation' : 'Confirm & Mark Rejected'}
                    </>
                  )}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Permanent Delete Confirmation Modal */}
      {showDeleteConfirmModal && invoice && (
        <div className="fixed inset-0 z-60 flex items-center justify-center p-4 bg-black/70 backdrop-blur-xs animate-in fade-in duration-150">
          <div className="bg-white rounded-2xl shadow-2xl max-w-md w-full overflow-hidden border border-rose-200">
            <div className="p-5 bg-rose-700 text-white flex items-center gap-3">
              <div className="p-2 bg-white/20 rounded-xl">
                <Trash2 className="w-6 h-6 text-white" />
              </div>
              <div>
                <h3 className="text-base font-bold">Permanently Delete Invoice</h3>
                <p className="text-xs text-rose-200 font-mono mt-0.5">
                  {invoice.billNumber} • {invoice.billingState || 'quotation'}
                </p>
              </div>
            </div>

            <div className="p-5 space-y-4">
              <div className="p-3 bg-amber-50 border border-amber-200 rounded-xl flex items-start gap-2.5 text-xs text-amber-900">
                <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
                <div>
                  <p className="font-bold">Permanent Destruction Warning</p>
                  <p className="mt-0.5 text-amber-800">
                    This document will be permanently removed from the system. This action cannot be reversed.
                  </p>
                </div>
              </div>

              <p className="text-xs text-neutral-600 leading-relaxed">
                Are you sure you want to permanently delete {invoice.billingState || 'quotation'} invoice <strong>{invoice.billNumber}</strong> for <strong>{invoice.customerSnapshot?.name}</strong>?
              </p>

              <div className="flex items-center justify-end gap-2 pt-2 border-t border-neutral-100">
                <button
                  type="button"
                  disabled={isDeleting}
                  onClick={() => setShowDeleteConfirmModal(false)}
                  className="px-4 py-2 text-xs font-semibold rounded-lg bg-neutral-100 hover:bg-neutral-200 text-neutral-700 transition cursor-pointer disabled:opacity-50"
                >
                  Cancel
                </button>
                <button
                  type="button"
                  disabled={isDeleting}
                  onClick={handleDeletePermanently}
                  className="px-4 py-2 text-xs font-bold rounded-lg bg-rose-600 hover:bg-rose-700 text-white transition inline-flex items-center gap-1.5 shadow-sm cursor-pointer active:scale-95 disabled:opacity-50"
                >
                  {isDeleting ? (
                    <>
                      <Loader2 className="w-3.5 h-3.5 animate-spin" />
                      Deleting...
                    </>
                  ) : (
                    <>
                      <Trash2 className="w-3.5 h-3.5" />
                      Permanently Delete
                    </>
                  )}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Delete Expense Confirmation Modal */}
      {expenseToDelete && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-xs">
          <div className="bg-white rounded-xl shadow-xl max-w-md w-full p-5 space-y-4 border border-neutral-200">
            <div className="flex items-center gap-3 text-rose-600">
              <div className="w-10 h-10 rounded-full bg-rose-100 flex items-center justify-center shrink-0">
                <Trash2 className="w-5 h-5 text-rose-600" />
              </div>
              <div>
                <h4 className="text-sm font-bold text-neutral-900">Delete Expense</h4>
                <p className="text-xs text-neutral-500">
                  Confirm permanent deletion of this expense record.
                </p>
              </div>
            </div>

            <div className="p-3 bg-neutral-50 border border-neutral-200 rounded-lg text-xs space-y-1">
              <div className="flex justify-between">
                <span className="text-neutral-500">Description:</span>
                <span className="font-semibold text-neutral-800 break-words">{expenseToDelete.title}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-neutral-500">Amount:</span>
                <span className="font-mono font-bold text-neutral-900">{formatAFN(expenseToDelete.amount)}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-neutral-500">Date:</span>
                <span className="font-mono text-neutral-700">{formatDate(expenseToDelete.date)}</span>
              </div>
            </div>

            <p className="text-xs text-neutral-600">
              This action will permanently delete only this expense record. Invoice balance and payment records are unaffected.
            </p>

            <div className="flex justify-end gap-2 pt-2 border-t border-neutral-100">
              <button
                type="button"
                onClick={() => setExpenseToDelete(null)}
                disabled={isDeletingExpense}
                className="px-3.5 py-1.5 text-xs font-semibold rounded border border-neutral-300 text-neutral-700 hover:bg-neutral-50 transition cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleConfirmDeleteExpense}
                disabled={isDeletingExpense}
                className="px-4 py-1.5 bg-rose-600 hover:bg-rose-700 text-white text-xs font-bold rounded transition disabled:opacity-50 cursor-pointer flex items-center gap-1.5"
              >
                {isDeletingExpense && <Loader2 className="w-3.5 h-3.5 animate-spin" />}
                <span>Confirm Delete</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Reject Expense Modal (Requires mandatory non-empty reason) */}
      {expenseToReject && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-xs">
          <div className="bg-white rounded-xl shadow-xl max-w-md w-full p-5 space-y-4 border border-rose-200">
            <div className="flex items-center gap-3 text-rose-600">
              <div className="w-10 h-10 rounded-full bg-rose-100 flex items-center justify-center shrink-0">
                <XCircle className="w-5 h-5 text-rose-600" />
              </div>
              <div>
                <h4 className="text-sm font-bold text-neutral-900">Reject Expense Request</h4>
                <p className="text-xs text-neutral-500">
                  Provide a mandatory rejection reason for the requester.
                </p>
              </div>
            </div>

            <div className="p-3 bg-neutral-50 border border-neutral-200 rounded-lg text-xs space-y-1">
              <div className="flex justify-between">
                <span className="text-neutral-500">Expense:</span>
                <span className="font-semibold text-neutral-800 break-words">{expenseToReject.title}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-neutral-500">Amount:</span>
                <span className="font-mono font-bold text-neutral-900">{formatAFN(expenseToReject.amount)}</span>
              </div>
              <div className="flex justify-between items-baseline">
                <span className="text-neutral-500">
                  Requested By: {formatRoleLabel(expenseToReject.requestedByRole, expenseToReject.requestedByJobTitle)}
                </span>
                <span className="font-semibold text-neutral-800">{expenseToReject.requestedByName || 'Staff Member'}</span>
              </div>
            </div>

            {rejectionError && (
              <div className="p-2.5 bg-rose-50 border border-rose-200 text-rose-800 text-xs rounded-lg flex items-center gap-2">
                <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
                <span>{rejectionError}</span>
              </div>
            )}

            <div>
              <label className="text-[11px] font-bold text-neutral-700 block mb-1">
                Reason for Rejection *
              </label>
              <textarea
                rows={3}
                value={rejectionReasonInput ?? ''}
                onChange={(e) => {
                  setRejectionReasonInput(e.target.value);
                  if (rejectionError) setRejectionError(null);
                }}
                placeholder="State clearly why this expense was rejected and what corrections are required (minimum 3 characters)..."
                className="w-full text-xs border border-neutral-300 rounded-lg p-2.5 focus:outline-none focus:ring-2 focus:ring-rose-500 focus:border-rose-500"
                required
              />
              <span className="text-[10px] text-neutral-500 block mt-1">
                A minimum of 3 characters is required to explain the rejection reason.
              </span>
            </div>

            <div className="flex justify-end gap-2 pt-2 border-t border-neutral-100">
              <button
                type="button"
                onClick={() => {
                  setExpenseToReject(null);
                  setRejectionReasonInput('');
                  setRejectionError(null);
                }}
                disabled={isSubmittingRejection}
                className="px-3.5 py-1.5 text-xs font-semibold rounded border border-neutral-300 text-neutral-700 hover:bg-neutral-50 transition cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleConfirmReject}
                disabled={isSubmittingRejection || rejectionReasonInput.trim().length < 3}
                className="px-4 py-1.5 bg-rose-600 hover:bg-rose-700 text-white text-xs font-bold rounded transition disabled:opacity-50 cursor-pointer flex items-center gap-1.5"
              >
                {isSubmittingRejection && <Loader2 className="w-3.5 h-3.5 animate-spin" />}
                <span>Confirm Rejection</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Audit History / Connected Vertical Workflow Timeline Modal */}
      {selectedExpenseForHistory && (
        <ExpenseAuditHistoryModal
          expense={selectedExpenseForHistory}
          onClose={() => setSelectedExpenseForHistory(null)}
          users={users}
        />
      )}

      {/* Dedicated Expense Modal Dialog (Add / Edit / Resubmit) */}
      <ExpenseModal
        isOpen={isExpenseFormOpen}
        onClose={handleCloseExpenseForm}
        onSubmit={handleSaveExpense}
        invoice={invoice}
        editingExpense={editingExpense}
        expenseTitle={expenseTitle}
        setExpenseTitle={setExpenseTitle}
        expenseAmount={expenseAmount}
        setExpenseAmount={setExpenseAmount}
        expenseDate={expenseDate}
        setExpenseDate={setExpenseDate}
        expenseCategory={expenseCategory}
        setExpenseCategory={setExpenseCategory}
        expenseNote={expenseNote}
        setExpenseNote={setExpenseNote}
        expenseCorrections={expenseCorrections}
        setExpenseCorrections={setExpenseCorrections}
        expenseFormError={expenseFormError}
        savingExpense={savingExpense}
        lastFocusedTrigger={lastFocusedExpenseTriggerRef.current}
      />

        </div>
      )}
    </>
  );
};
