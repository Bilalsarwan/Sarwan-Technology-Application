import React, { useState } from 'react';
import { InvoiceDesignSettings } from '../../types/invoiceDesign';
import { FONT_OPTIONS } from './TypographyControls';
import {
  X,
  Layout,
  Maximize2,
  Sliders,
  Table as TableIcon,
  Sparkles,
  Link2,
  Link2Off,
  CheckCircle2,
  FileCheck,
  Compass,
  Type,
} from 'lucide-react';

export interface DocumentLayoutDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  design: InvoiceDesignSettings;
  updateDesign: (updater: (prev: InvoiceDesignSettings) => InvoiceDesignSettings) => void;
  showGuides: boolean;
  onToggleGuides: (show: boolean) => void;
}

export const DocumentLayoutDrawer: React.FC<DocumentLayoutDrawerProps> = ({
  isOpen,
  onClose,
  design,
  updateDesign,
  showGuides,
  onToggleGuides,
}) => {
  const [linkMargins, setLinkMargins] = useState<boolean>(false);

  if (!isOpen) return null;

  const margins = design.page.margins || { top: 12, right: 12, bottom: 12, left: 12 };
  const paperWidthMm = design.page.orientation === 'landscape' ? 297 : 210;
  const paperHeightMm = design.page.orientation === 'landscape' ? 210 : 297;

  const usableWidthMm = Math.max(0, paperWidthMm - (margins.left + margins.right));
  const usableHeightMm = Math.max(0, paperHeightMm - (margins.top + margins.bottom));
  const usableAreaCm2 = ((usableWidthMm * usableHeightMm) / 100).toFixed(1);

  const handleMarginChange = (side: 'top' | 'right' | 'bottom' | 'left', val: number) => {
    const clamped = Math.max(4, Math.min(35, val));
    if (linkMargins) {
      updateDesign((p) => ({
        ...p,
        page: {
          ...p.page,
          margins: { top: clamped, right: clamped, bottom: clamped, left: clamped },
        },
      }));
    } else {
      updateDesign((p) => ({
        ...p,
        page: {
          ...p.page,
          margins: { ...p.page.margins, [side]: clamped },
        },
      }));
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 bg-black/40 backdrop-blur-xs flex items-center justify-end animate-in fade-in duration-150"
      onClick={onClose}
    >
      <div
        className="bg-white w-full sm:w-[480px] h-full shadow-2xl flex flex-col border-l border-neutral-200 animate-in slide-in-from-right duration-200 text-neutral-800"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="px-4 py-3 sm:px-5 border-b border-neutral-200 flex items-center justify-between bg-neutral-50/90 shrink-0">
          <div className="flex items-center gap-2.5 min-w-0">
            <div className="p-1.5 bg-blue-100 text-blue-700 rounded-md shrink-0">
              <Layout className="w-4 h-4" />
            </div>
            <div className="min-w-0">
              <h3 className="text-sm font-bold text-neutral-900 truncate">Document Layout</h3>
              <p className="text-[11px] text-neutral-500 truncate">
                Configure page margins, spacing & paper geometry
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close Layout Manager"
            className="p-1.5 text-neutral-400 hover:text-neutral-700 rounded-md hover:bg-neutral-200/60 transition cursor-pointer"
            title="Close (Esc)"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Scrollable Content */}
        <div className="p-4 sm:p-5 overflow-y-auto space-y-5 flex-1 text-xs">
          {/* 1. Paper Format & Usable Content Area */}
          <div className="border border-neutral-200 rounded-xl overflow-hidden bg-white shadow-2xs">
            <div className="px-3.5 py-2.5 bg-neutral-50/80 border-b border-neutral-200 flex items-center justify-between">
              <div className="flex items-center gap-2 font-bold text-neutral-800 text-[11px] uppercase tracking-wider">
                <Compass className="w-3.5 h-3.5 text-blue-600" />
                <span>Paper Settings & Usable Area</span>
              </div>
              <span className="text-[10px] font-bold text-blue-700 bg-blue-50 px-2 py-0.5 rounded border border-blue-200">
                A4 (210 × 297 mm)
              </span>
            </div>
            <div className="p-3.5 space-y-3">
              <div className="grid grid-cols-2 gap-2 text-xs">
                <div>
                  <span className="text-[11px] text-neutral-500 block mb-1">Paper Size</span>
                  <select
                    value={design.page.paperSize || 'A4'}
                    onChange={(e) =>
                      updateDesign((p) => ({
                        ...p,
                        page: { ...p.page, paperSize: e.target.value as any },
                      }))
                    }
                    className="w-full h-8 px-2 border border-neutral-300 rounded-md bg-neutral-50 text-xs font-semibold focus:outline-none focus:ring-1 focus:ring-blue-500"
                  >
                    <option value="A4">A4 (210 × 297 mm)</option>
                    <option value="A5">A5 (148 × 210 mm)</option>
                    <option value="Letter">US Letter (8.5 × 11 in)</option>
                  </select>
                </div>
                <div>
                  <span className="text-[11px] text-neutral-500 block mb-1">Orientation</span>
                  <select
                    value={design.page.orientation || 'portrait'}
                    onChange={(e) =>
                      updateDesign((p) => ({
                        ...p,
                        page: { ...p.page, orientation: e.target.value as any },
                      }))
                    }
                    className="w-full h-8 px-2 border border-neutral-300 rounded-md bg-neutral-50 text-xs font-semibold focus:outline-none focus:ring-1 focus:ring-blue-500"
                  >
                    <option value="portrait">Portrait</option>
                    <option value="landscape">Landscape</option>
                  </select>
                </div>
              </div>

              {/* Usable Area Dynamic Stats Box */}
              <div className="bg-gradient-to-br from-blue-50/60 to-indigo-50/60 p-3 rounded-lg border border-blue-100 flex items-center justify-between">
                <div>
                  <span className="text-[10px] font-bold uppercase tracking-wider text-blue-900 block">
                    Printable Content Area
                  </span>
                  <span className="text-xs font-mono font-bold text-blue-800">
                    {usableWidthMm} × {usableHeightMm} mm
                  </span>
                </div>
                <div className="text-right">
                  <span className="text-[10px] text-neutral-500 block">Usable Space</span>
                  <span className="text-xs font-bold text-indigo-700">{usableAreaCm2} cm²</span>
                </div>
              </div>
            </div>
          </div>

          {/* 2. Page Margins (Independent or Linked) */}
          <div className="border border-neutral-200 rounded-xl overflow-hidden bg-white shadow-2xs">
            <div className="px-3.5 py-2.5 bg-neutral-50/80 border-b border-neutral-200 flex items-center justify-between">
              <div className="flex items-center gap-2 font-bold text-neutral-800 text-[11px] uppercase tracking-wider">
                <Maximize2 className="w-3.5 h-3.5 text-blue-600" />
                <span>Page Margins (mm)</span>
              </div>
              <button
                type="button"
                onClick={() => setLinkMargins(!linkMargins)}
                className={`flex items-center gap-1 px-2 py-0.5 text-[10px] font-semibold rounded transition cursor-pointer ${
                  linkMargins
                    ? 'bg-blue-600 text-white shadow-2xs'
                    : 'bg-neutral-100 text-neutral-600 hover:bg-neutral-200'
                }`}
                title={linkMargins ? 'Margins Linked (all sides equal)' : 'Margins Independent'}
              >
                {linkMargins ? <Link2 className="w-3 h-3" /> : <Link2Off className="w-3 h-3" />}
                <span>{linkMargins ? 'Linked' : 'Independent'}</span>
              </button>
            </div>
            <div className="p-3.5">
              <div className="grid grid-cols-2 gap-3">
                {(['top', 'right', 'bottom', 'left'] as const).map((side) => (
                  <div key={side} className="flex flex-col gap-1">
                    <span className="text-[10px] uppercase font-semibold text-neutral-500">
                      {side} Margin
                    </span>
                    <div className="flex items-center gap-1.5">
                      <input
                        type="number"
                        min={4}
                        max={35}
                        value={margins[side]}
                        onChange={(e) => handleMarginChange(side, Number(e.target.value))}
                        className="w-full text-xs h-8 px-2 border border-neutral-300 rounded bg-white font-mono focus:outline-none focus:ring-1 focus:ring-blue-500"
                      />
                      <span className="text-[11px] text-neutral-400 font-medium">mm</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* 3. Section Spacing Controls */}
          <div className="border border-neutral-200 rounded-xl overflow-hidden bg-white shadow-2xs">
            <div className="px-3.5 py-2.5 bg-neutral-50/80 border-b border-neutral-200 flex items-center justify-between">
              <div className="flex items-center gap-2 font-bold text-neutral-800 text-[11px] uppercase tracking-wider">
                <Sliders className="w-3.5 h-3.5 text-blue-600" />
                <span>Section Spacing (px)</span>
              </div>
            </div>
            <div className="p-3.5 space-y-2.5">
              {[
                {
                  label: 'Header → Invoice Meta',
                  desc: 'Gap under header branding banner',
                  value: design.spacing.headerToMeta ?? (design.spacing as any).metaSpacing ?? design.spacing.headerSpacing ?? 8,
                  onChange: (v: number) =>
                    updateDesign((p) => ({
                      ...p,
                      spacing: { ...p.spacing, headerToMeta: v, headerSpacing: v },
                    })),
                },
                {
                  label: 'Invoice Meta → Customer',
                  desc: 'Gap between metadata box and customer box',
                  value: design.spacing.metaToCustomer ?? (design.spacing as any).metaToCustomerSpacing ?? design.spacing.customerSpacing ?? 8,
                  onChange: (v: number) =>
                    updateDesign((p) => ({
                      ...p,
                      spacing: { ...p.spacing, metaToCustomer: v },
                    })),
                },
                {
                  label: 'Customer → Items Table',
                  desc: 'Gap above invoice items table',
                  value: design.spacing.customerToTable ?? (design.spacing as any).customerToTableSpacing ?? design.spacing.tableSpacing ?? 8,
                  onChange: (v: number) =>
                    updateDesign((p) => ({
                      ...p,
                      spacing: { ...p.spacing, customerToTable: v, tableSpacing: v },
                    })),
                },
                {
                  label: 'Items Table → Payment',
                  desc: 'Gap between items table and payment card',
                  value: design.spacing.tableToPayment ?? (design.spacing as any).tableToPaymentSpacing ?? design.spacing.paymentSpacing ?? 10,
                  onChange: (v: number) =>
                    updateDesign((p) => ({
                      ...p,
                      spacing: { ...p.spacing, tableToPayment: v, paymentSpacing: v },
                    })),
                },
                {
                  label: 'Payment → Totals',
                  desc: 'Horizontal gap between payment & totals cards',
                  value: design.spacing.paymentToTotals ?? (design.spacing as any).paymentToTotalsSpacing ?? 16,
                  onChange: (v: number) =>
                    updateDesign((p) => ({
                      ...p,
                      spacing: { ...p.spacing, paymentToTotals: v },
                    })),
                },
                {
                  label: 'Totals → Notes',
                  desc: 'Gap between totals summary and notes card',
                  value: design.spacing.totalsToNotes ?? (design.spacing as any).totalsToNotesSpacing ?? design.spacing.totalsSpacing ?? 10,
                  onChange: (v: number) =>
                    updateDesign((p) => ({
                      ...p,
                      spacing: { ...p.spacing, totalsToNotes: v, totalsSpacing: v },
                    })),
                },
                {
                  label: 'Notes → Signatures',
                  desc: 'Gap between notes card and signature lines',
                  value: design.spacing.notesToSignatures ?? (design.spacing as any).notesToSignaturesSpacing ?? design.spacing.sectionSpacing ?? 10,
                  onChange: (v: number) =>
                    updateDesign((p) => ({
                      ...p,
                      spacing: { ...p.spacing, notesToSignatures: v },
                    })),
                },
                {
                  label: 'Footer Spacing',
                  desc: 'Gap above bottom footer banner',
                  value: design.spacing.footerSpacing ?? 8,
                  onChange: (v: number) =>
                    updateDesign((p) => ({
                      ...p,
                      spacing: { ...p.spacing, footerSpacing: v },
                    })),
                },
              ].map((item, idx) => (
                <div
                  key={idx}
                  className="flex items-center justify-between p-2 rounded-lg bg-neutral-50 border border-neutral-100"
                >
                  <div className="min-w-0 pr-2">
                    <span className="font-semibold text-neutral-800 block text-xs truncate">
                      {item.label}
                    </span>
                    <span className="text-[10px] text-neutral-400 block truncate">{item.desc}</span>
                  </div>
                  <div className="flex items-center gap-1 shrink-0">
                    <input
                      type="number"
                      min={0}
                      max={40}
                      value={item.value}
                      onChange={(e) => item.onChange(Number(e.target.value))}
                      className="w-14 text-xs h-7 px-1 text-center border border-neutral-300 rounded bg-white font-mono focus:outline-none focus:ring-1 focus:ring-blue-500"
                    />
                    <span className="text-[10px] text-neutral-400 font-medium">px</span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* 4. Header & Footer Layout Heights */}
          <div className="border border-neutral-200 rounded-xl overflow-hidden bg-white shadow-2xs">
            <div className="px-3.5 py-2.5 bg-neutral-50/80 border-b border-neutral-200 flex items-center justify-between">
              <div className="flex items-center gap-2 font-bold text-neutral-800 text-[11px] uppercase tracking-wider">
                <FileCheck className="w-3.5 h-3.5 text-blue-600" />
                <span>Header & Footer Layout</span>
              </div>
            </div>
            <div className="p-3.5 space-y-2.5">
              <div className="flex items-center justify-between p-2 rounded-lg bg-neutral-50 border border-neutral-100">
                <div>
                  <span className="font-semibold text-neutral-800 block text-xs">Header Height</span>
                  <span className="text-[10px] text-neutral-400">Fixed header height (px)</span>
                </div>
                <div className="flex items-center gap-1">
                  <input
                    type="number"
                    min={40}
                    max={120}
                    value={design.header.height || 64}
                    onChange={(e) =>
                      updateDesign((p) => ({
                        ...p,
                        header: { ...p.header, height: Number(e.target.value) },
                      }))
                    }
                    className="w-14 text-xs h-7 px-1 text-center border border-neutral-300 rounded bg-white font-mono focus:outline-none focus:ring-1 focus:ring-blue-500"
                  />
                  <span className="text-[10px] text-neutral-400 font-medium">px</span>
                </div>
              </div>

              <div className="flex items-center justify-between p-2 rounded-lg bg-neutral-50 border border-neutral-100">
                <div>
                  <span className="font-semibold text-neutral-800 block text-xs">Footer Height</span>
                  <span className="text-[10px] text-neutral-400">Fixed footer banner height (px)</span>
                </div>
                <div className="flex items-center gap-1">
                  <input
                    type="number"
                    min={35}
                    max={90}
                    value={(design.footer as any).height || 50}
                    onChange={(e) =>
                      updateDesign((p) => ({
                        ...p,
                        footer: { ...p.footer, height: Number(e.target.value) } as any,
                      }))
                    }
                    className="w-14 text-xs h-7 px-1 text-center border border-neutral-300 rounded bg-white font-mono focus:outline-none focus:ring-1 focus:ring-blue-500"
                  />
                  <span className="text-[10px] text-neutral-400 font-medium">px</span>
                </div>
              </div>
            </div>
          </div>

          {/* 5. Items Table Layout Geometry */}
          <div className="border border-neutral-200 rounded-xl overflow-hidden bg-white shadow-2xs">
            <div className="px-3.5 py-2.5 bg-neutral-50/80 border-b border-neutral-200 flex items-center justify-between">
              <div className="flex items-center gap-2 font-bold text-neutral-800 text-[11px] uppercase tracking-wider">
                <TableIcon className="w-3.5 h-3.5 text-blue-600" />
                <span>Table Layout</span>
              </div>
            </div>
            <div className="p-3.5 space-y-2.5">
              <div className="flex items-center justify-between p-2 rounded-lg bg-neutral-50 border border-neutral-100">
                <div>
                  <span className="font-semibold text-neutral-800 block text-xs">Row Height</span>
                  <span className="text-[10px] text-neutral-400">Height of item table rows</span>
                </div>
                <div className="flex items-center gap-1">
                  <input
                    type="number"
                    min={18}
                    max={40}
                    step={0.5}
                    value={design.spacing.rowHeight}
                    onChange={(e) =>
                      updateDesign((p) => ({
                        ...p,
                        spacing: { ...p.spacing, rowHeight: Number(e.target.value) },
                      }))
                    }
                    className="w-14 text-xs h-7 px-1 text-center border border-neutral-300 rounded bg-white font-mono focus:outline-none focus:ring-1 focus:ring-blue-500"
                  />
                  <span className="text-[10px] text-neutral-400 font-medium">px</span>
                </div>
              </div>

              <div className="flex items-center justify-between p-2 rounded-lg bg-neutral-50 border border-neutral-100">
                <div>
                  <span className="font-semibold text-neutral-800 block text-xs">Table Header Background</span>
                  <span className="text-[10px] text-neutral-400">Canonical color for all invoice table headers</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <input
                    type="color"
                    value={design.colors.tableHeaderBackground || design.itemsTable.headerBgColor || '#0B1E36'}
                    onChange={(e) => {
                      const val = e.target.value;
                      updateDesign((p) => ({
                        ...p,
                        colors: { ...p.colors, tableHeaderBackground: val },
                        itemsTable: { ...p.itemsTable, headerBgColor: val },
                      }));
                    }}
                    className="w-7 h-7 p-0.5 border border-neutral-300 rounded cursor-pointer"
                  />
                  <span className="text-[11px] font-mono uppercase text-neutral-600">
                    {design.colors.tableHeaderBackground || design.itemsTable.headerBgColor || '#0B1E36'}
                  </span>
                </div>
              </div>

              <div className="flex items-center justify-between p-2 rounded-lg bg-neutral-50 border border-neutral-100">
                <div>
                  <span className="font-semibold text-neutral-800 block text-xs">Table Header Text Color</span>
                  <span className="text-[10px] text-neutral-400">Canonical header text & icon color</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <input
                    type="color"
                    value={design.colors.tableHeaderText || design.itemsTable.headerTextColor || '#FFFFFF'}
                    onChange={(e) => {
                      const val = e.target.value;
                      updateDesign((p) => ({
                        ...p,
                        colors: { ...p.colors, tableHeaderText: val },
                        itemsTable: { ...p.itemsTable, headerTextColor: val },
                      }));
                    }}
                    className="w-7 h-7 p-0.5 border border-neutral-300 rounded cursor-pointer"
                  />
                  <span className="text-[11px] font-mono uppercase text-neutral-600">
                    {design.colors.tableHeaderText || design.itemsTable.headerTextColor || '#FFFFFF'}
                  </span>
                </div>
              </div>

              <div className="flex items-center justify-between p-2 rounded-lg bg-neutral-50 border border-neutral-100">
                <div>
                  <span className="font-semibold text-neutral-800 block text-xs">Cell Padding</span>
                  <span className="text-[10px] text-neutral-400">Vertical cell inner padding</span>
                </div>
                <div className="flex items-center gap-1">
                  <input
                    type="number"
                    min={2}
                    max={16}
                    value={design.spacing.tablePadding}
                    onChange={(e) =>
                      updateDesign((p) => ({
                        ...p,
                        spacing: { ...p.spacing, tablePadding: Number(e.target.value) },
                      }))
                    }
                    className="w-14 text-xs h-7 px-1 text-center border border-neutral-300 rounded bg-white font-mono focus:outline-none focus:ring-1 focus:ring-blue-500"
                  />
                  <span className="text-[10px] text-neutral-400 font-medium">px</span>
                </div>
              </div>

              <label className="flex items-center justify-between p-2 rounded-lg bg-neutral-50 border border-neutral-100 cursor-pointer">
                <div>
                  <span className="font-semibold text-neutral-800 block text-xs">Zebra Striping</span>
                  <span className="text-[10px] text-neutral-400">Alternate row background tints</span>
                </div>
                <input
                  type="checkbox"
                  checked={Boolean(design.itemsTable.useZebraStriping)}
                  onChange={(e) =>
                    updateDesign((p) => ({
                      ...p,
                      itemsTable: { ...p.itemsTable, useZebraStriping: e.target.checked },
                    }))
                  }
                  className="w-4 h-4 rounded text-blue-600 border-neutral-300 focus:ring-blue-500 cursor-pointer"
                />
              </label>

              <label className="flex items-center justify-between p-2 rounded-lg bg-neutral-50 border border-neutral-100 cursor-pointer">
                <div>
                  <span className="font-semibold text-neutral-800 block text-xs">
                    Repeat Header on Multi-Page
                  </span>
                  <span className="text-[10px] text-neutral-400">
                    Include table header on pages 2+
                  </span>
                </div>
                <input
                  type="checkbox"
                  checked={(design.itemsTable as any).repeatHeaderOnMultiPage !== false}
                  onChange={(e) =>
                    updateDesign((p) => ({
                      ...p,
                      itemsTable: {
                        ...p.itemsTable,
                        repeatHeaderOnMultiPage: e.target.checked,
                      } as any,
                    }))
                  }
                  className="w-4 h-4 rounded text-blue-600 border-neutral-300 focus:ring-blue-500 cursor-pointer"
                />
              </label>
            </div>
          </div>

          {/* 6. Document Accents & Visual Guides */}
          <div className="border border-neutral-200 rounded-xl overflow-hidden bg-white shadow-2xs">
            <div className="px-3.5 py-2.5 bg-neutral-50/80 border-b border-neutral-200 flex items-center justify-between">
              <div className="flex items-center gap-2 font-bold text-neutral-800 text-[11px] uppercase tracking-wider">
                <Sparkles className="w-3.5 h-3.5 text-blue-600" />
                <span>Accents & Boundary Guides</span>
              </div>
            </div>
            <div className="p-3.5 space-y-2.5">
              <label className="flex items-center justify-between p-2 rounded-lg bg-neutral-50 border border-neutral-100 cursor-pointer">
                <div>
                  <span className="font-semibold text-neutral-800 block text-xs">Corner Flap Accents</span>
                  <span className="text-[10px] text-neutral-400">Geometric navy & gold corner flaps</span>
                </div>
                <input
                  type="checkbox"
                  checked={design.page.showCornerDecorations !== false}
                  onChange={(e) =>
                    updateDesign((p) => ({
                      ...p,
                      page: { ...p.page, showCornerDecorations: e.target.checked },
                    }))
                  }
                  className="w-4 h-4 rounded text-blue-600 border-neutral-300 focus:ring-blue-500 cursor-pointer"
                />
              </label>

              <label className="flex items-center justify-between p-2 rounded-lg bg-neutral-50 border border-neutral-100 cursor-pointer">
                <div>
                  <span className="font-semibold text-neutral-800 block text-xs">Outer Page Border</span>
                  <span className="text-[10px] text-neutral-400">Draw perimeter border on printable edge</span>
                </div>
                <input
                  type="checkbox"
                  checked={Boolean(design.page.showPageBorder)}
                  onChange={(e) =>
                    updateDesign((p) => ({
                      ...p,
                      page: { ...p.page, showPageBorder: e.target.checked },
                    }))
                  }
                  className="w-4 h-4 rounded text-blue-600 border-neutral-300 focus:ring-blue-500 cursor-pointer"
                />
              </label>

              <label className="flex items-center justify-between p-2 rounded-lg bg-neutral-50 border border-neutral-100 cursor-pointer">
                <div>
                  <span className="font-semibold text-neutral-800 block text-xs">
                    Margin Visual Guides
                  </span>
                  <span className="text-[10px] text-neutral-400">Show printable boundary overlay</span>
                </div>
                <input
                  type="checkbox"
                  checked={showGuides}
                  onChange={(e) => onToggleGuides(e.target.checked)}
                  className="w-4 h-4 rounded text-blue-600 border-neutral-300 focus:ring-blue-500 cursor-pointer"
                />
              </label>
            </div>
          </div>

          {/* 7. Document Typography */}
          <div className="border border-neutral-200 rounded-xl overflow-hidden bg-white shadow-2xs">
            <div className="px-3.5 py-2.5 bg-neutral-50/80 border-b border-neutral-200 flex items-center justify-between">
              <div className="flex items-center gap-2 font-bold text-neutral-800 text-[11px] uppercase tracking-wider">
                <Type className="w-3.5 h-3.5 text-blue-600" />
                <span>Document Typography</span>
              </div>
            </div>
            <div className="p-3.5 space-y-3">
              <div>
                <span className="text-[11px] text-neutral-500 block mb-1">Default Body Font</span>
                <select
                  value={design.typography.fontFamily || 'Inter, system-ui, sans-serif'}
                  onChange={(e) =>
                    updateDesign((p) => ({
                      ...p,
                      typography: { ...p.typography, fontFamily: e.target.value },
                    }))
                  }
                  className="w-full h-8 px-2 border border-neutral-300 rounded-md bg-neutral-50 text-xs font-semibold focus:outline-none focus:ring-1 focus:ring-blue-500 cursor-pointer"
                >
                  {FONT_OPTIONS.map((f) => (
                    <option key={f.value} value={f.value}>
                      {f.label}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <span className="text-[11px] text-neutral-500 block mb-1">Heading Font Family</span>
                <select
                  value={design.typography.headingFontFamily || design.typography.fontFamily || 'Inter, system-ui, sans-serif'}
                  onChange={(e) =>
                    updateDesign((p) => ({
                      ...p,
                      typography: { ...p.typography, headingFontFamily: e.target.value },
                    }))
                  }
                  className="w-full h-8 px-2 border border-neutral-300 rounded-md bg-neutral-50 text-xs font-semibold focus:outline-none focus:ring-1 focus:ring-blue-500 cursor-pointer"
                >
                  {FONT_OPTIONS.map((f) => (
                    <option key={f.value} value={f.value}>
                      {f.label}
                    </option>
                  ))}
                </select>
              </div>

              <div className="flex items-center justify-between p-2 rounded-lg bg-neutral-50 border border-neutral-100">
                <div>
                  <span className="font-semibold text-neutral-800 block text-xs">Base Font Size</span>
                  <span className="text-[10px] text-neutral-400">Default body text size (px)</span>
                </div>
                <div className="flex items-center gap-1">
                  <input
                    type="number"
                    min={8}
                    max={18}
                    step={0.5}
                    value={design.typography.baseFontSize || 11.5}
                    onChange={(e) =>
                      updateDesign((p) => ({
                        ...p,
                        typography: { ...p.typography, baseFontSize: Number(e.target.value) },
                      }))
                    }
                    className="w-14 text-xs h-7 px-1 text-center border border-neutral-300 rounded bg-white font-mono focus:outline-none focus:ring-1 focus:ring-blue-500"
                  />
                  <span className="text-[10px] text-neutral-400 font-medium">px</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="px-4 py-3 sm:px-5 border-t border-neutral-200 bg-neutral-50 flex items-center justify-between shrink-0">
          <div className="flex items-center gap-1.5 text-[11px] text-neutral-500">
            <CheckCircle2 className="w-3.5 h-3.5 text-blue-600" />
            <span>Updates live on canvas</span>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-1.5 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 active:bg-blue-800 rounded-md shadow-2xs transition cursor-pointer"
          >
            Done
          </button>
        </div>
      </div>
    </div>
  );
};
