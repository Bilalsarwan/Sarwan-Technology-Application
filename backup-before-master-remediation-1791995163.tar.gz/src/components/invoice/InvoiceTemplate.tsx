import React from 'react';
import {
  CanonicalInvoiceDocumentModel,
  CanonicalInvoiceItem,
  CanonicalInvoicePage,
} from '../../types/canonicalInvoiceDocument';
import {
  TableColumnConfig,
  InvoiceDesignSettings,
  DesignerElement,
  DEFAULT_INVOICE_DESIGN,
  normalizeTableColumnOrder,
  normalizeFooterElementsOrder,
} from '../../types/invoiceDesign';
import { formatInvoiceNumber } from '../../utils/format';
import {
  isPopulatedInvoiceItem,
  getItemRowHeight,
  calculateInvoicePageChunks,
  paginateInvoiceItems,
} from '../../utils/canonicalInvoicePagination';

export {
  isPopulatedInvoiceItem,
  getItemRowHeight,
  calculateInvoicePageChunks,
  paginateInvoiceItems,
};

export interface InvoiceTemplateProps {
  document: CanonicalInvoiceDocumentModel;
  design?: InvoiceDesignSettings;
  id?: string;
  className?: string;
  selectedElement?: DesignerElement | null;
  onSelectElement?: (element: DesignerElement | null) => void;
  isInteractive?: boolean;
}

/**
 * InvoiceTemplate
 * 
 * EXACT VISUAL IMPLEMENTATION OF THE APPROVED REFERENCE INVOICE (Style #7).
 * Single shared source of truth for PDF Download and Invoice Preview.
 * 
 * Visual Spec from Reference Image:
 * - Corner frames: Deep navy triangular corner accents with gold diagonal divider lines
 * - Header: Logo 1 (Left), Logo 2 (Right), Centered "Sarwan Technology", Pashto, Slogan flanked by vertical rules
 * - Sub-header: Large bold "Invoice" on the left, compact bordered metadata box on the right
 * - Customer Info: Wide card with user icon header tab (#F0F7FF) and clean label-value grid
 * - Items Table: Natural height, royal blue header (#0055A5), blue item numbers, light-blue borders (#BAE6FD)
 * - Bottom Row: Left = Payment Information (Method, Status, Paid, Remaining)
 *               Right = Totals Summary with Solid Royal Blue (#0055A5) Grand Total
 * - Notes: Full-width card with note icon and natural compact height
 * - Signatures: Customer Signature (Left), Collector Signature (Right) with blue accent lines
 * - Footer: Deep navy banner with gold accent line, angled corner shapes, and "Thank you for your business!"
 */
export const InvoiceTemplate: React.FC<InvoiceTemplateProps> = ({
  document: doc,
  design: propDesign,
  id,
  className = '',
  selectedElement,
  onSelectElement,
  isInteractive = false,
}) => {
  const design = propDesign || doc.design;
  const paperConfig = doc.paperConfig;

  // Click-to-edit selection and hover helper
  const getInteractive = (elementKey: DesignerElement, label: string) => {
    if (!isInteractive) return {};
    const isSelected = selectedElement === elementKey;
    return {
      'data-designer-element': elementKey,
      onClick: (e: React.MouseEvent) => {
        e.stopPropagation();
        onSelectElement?.(elementKey);
      },
      className: `transition-all duration-150 cursor-pointer ${
        isSelected
          ? 'ring-2 ring-blue-600 ring-offset-2 ring-offset-white shadow-sm z-30 rounded-xs'
          : 'hover:outline hover:outline-1 hover:outline-dashed hover:outline-blue-400 hover:bg-blue-50/20'
      }`,
      title: `Click to edit ${label}`,
    };
  };

  const renderBadge = (elementKey: DesignerElement, label: string) => {
    if (!isInteractive || selectedElement !== elementKey) return null;
    return (
      <span className="absolute -top-5 left-0 z-50 flex items-center gap-1 bg-blue-600 text-white text-[9px] font-bold px-1.5 py-0.5 rounded shadow pointer-events-none select-none tracking-wide whitespace-nowrap animate-in fade-in duration-150">
        <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
        {label}
      </span>
    );
  };

  // Canonical pagination: consume pre-computed pages from doc if present, or compute canonically
  const pages: CanonicalInvoicePage[] = React.useMemo(() => {
    if (doc.pages && doc.pages.length > 0) {
      return doc.pages;
    }
    return paginateInvoiceItems(doc.items, paperConfig, design, doc);
  }, [doc.pages, doc.items, paperConfig, design, doc]);

  const totalPages = pages.length;

  // Ordered visible columns
  const rawOrder = normalizeTableColumnOrder(design.itemsTable?.columnOrder);
  const columnKeys: (keyof typeof design.itemsTable.columns & string)[] = (rawOrder as (keyof typeof design.itemsTable.columns & string)[]).filter((key) => {
    if (!design.itemsTable.columns[key]) return false;
    return Boolean(design.itemsTable.columns[key]?.show);
  });

  // Ordered footer elements
  const footerElementsOrder = normalizeFooterElementsOrder(design.footer?.footerElementsOrder);

  // 1. Canonical Global Color Palette (design.colors is the single canonical source of truth)
  const deepNavy = design.colors.primary || '#0B1E36'; // Primary / Dark navy
  const royalBlue = design.colors.secondary || '#1E4E8C'; // Secondary blue
  const goldAccent = design.colors.accent || '#C5A059'; // Accent gold
  const skyBorder = design.colors.border || '#D8E2EC'; // Borders
  const lightBlueBg = design.colors.cardBackground || '#F0F7FF'; // Card/box background
  const charcoalText = design.colors.text || '#0F172A'; // Primary body text
  const mutedText = design.colors.mutedText || '#64748B'; // Muted secondary text
  const pageBackground = design.colors.background || '#FFFFFF'; // Sheet background

  // 2. Canonical Typography (design.typography is the single canonical source of truth)
  const fontFamily = design.typography.fontFamily || 'Arial, sans-serif';
  const baseFontSize = design.typography.baseFontSize || 11.5;
  const sectionHeadingFontSize = design.typography.sectionHeadingFontSize || 11;
  const customerFontSize = design.customer?.fontSize || baseFontSize;

  // Header & Brand Typography
  const companyNameFontSize = design.company?.fontSize || design.typography.companyNameFontSize || 24;
  const pashtoFontSize = design.company?.pashtoFontSize || design.typography.pashtoFontSize || 20;
  const sloganFontSize = design.company?.sloganFontSize || design.typography.sloganFontSize || 10.5;
  const sloganColor = design.company?.sloganColor || royalBlue;
  const invoiceTitleFontSize = design.title?.fontSize || design.typography.titleFontSize || 24;

  // Table Colors, Dimensions & Typography
  const tableHeaderBg = design.colors.tableHeaderBackground || '#F1F5F9';
  const tableHeaderTextColor = design.colors.tableHeaderText || (design.colors.tableHeaderBackground ? '#FFFFFF' : (deepNavy || '#0B1E36'));
  const tableHeaderFontSize = design.typography.tableHeaderFontSize || 11.5;
  const tableBodyFontSize = design.typography.tableFontSize || 10;
  const tableRowHeight = design.spacing.rowHeight || 22.5;
  const tablePadding = design.spacing.tablePadding ?? design.itemsTable.padding ?? 4;

  // Grand Total Colors & Typography
  const grandTotalBg = design.colors.grandTotalBackground || royalBlue;
  const grandTotalTextColor = design.colors.grandTotalText || '#FFFFFF';
  const grandTotalFontSize = design.totals.grandTotalFontSize || design.totals.fontSize || 12;

  // Footer Colors & Typography
  const footerBgColor = design.colors.footerBackground || deepNavy;
  const footerTextColor = design.colors.footerText || '#FFFFFF';
  const footerAccentColor = design.colors.footerAccent || goldAccent;
  const footerFontSize = design.typography.footerFontSize || 11;
  const footerFontWeight = design.typography.footerFontWeight || 'bold';
  const footerLineHeight = design.typography.footerLineHeight || 1.4;

  // 3. Decorative Shapes (Design #7 corner diagonal flaps & gold accent line)
  const shapeTopLeft = design.shapes?.topLeft || {
    show: true,
    width: 130,
    height: 65,
    x: 0,
    y: 0,
    fillColor: deepNavy,
    accentColor: goldAccent,
    opacity: 1,
    borderWidth: 2.5,
    borderRadius: 0,
    rotation: 0,
    zIndex: 20,
  };

  const shapeTopRight = design.shapes?.topRight || {
    show: true,
    width: 130,
    height: 65,
    x: 0,
    y: 0,
    fillColor: deepNavy,
    accentColor: goldAccent,
    opacity: 1,
    borderWidth: 2.5,
    borderRadius: 0,
    rotation: 0,
    zIndex: 20,
  };

  const shapeGoldAccent = design.shapes?.goldAccent || {
    show: true,
    width: 130,
    height: 65,
    fillColor: goldAccent,
    accentColor: goldAccent,
    opacity: 1,
    borderWidth: 2.5,
    borderRadius: 0,
    rotation: 0,
    zIndex: 20,
  };

  const shapeBottomLeft = design.shapes?.bottomLeft || {
    show: true,
    width: 130,
    height: 65,
    x: 0,
    y: 0,
    fillColor: footerBgColor,
    accentColor: footerAccentColor,
    opacity: 1,
    borderWidth: 2.5,
    borderRadius: 0,
    rotation: 0,
    zIndex: 20,
  };

  const shapeBottomRight = design.shapes?.bottomRight || {
    show: true,
    width: 130,
    height: 65,
    x: 0,
    y: 0,
    fillColor: footerBgColor,
    accentColor: footerAccentColor,
    opacity: 1,
    borderWidth: 2.5,
    borderRadius: 0,
    rotation: 0,
    zIndex: 20,
  };

  // Configurable text values with reference defaults
  const companyNameEnglish =
    design.company?.name || design.title.text || design.header.headerText || doc.company.companyName || 'Sarwan Technology';
  const companyNamePashto =
    design.company.pashtoName || design.title.secondaryText || 'ساروان تکنالوژي';
  const sloganText =
    design.company.slogan || design.company.subtitle || 'Technology That Works for You';
  const invoiceTitleText =
    design.title.invoiceTitle || 'Invoice';

  const logo1Url =
    (design.logos?.logo1?.url && design.logos.logo1.url.trim()) ||
    (doc.design?.logos?.logo1?.url && doc.design.logos.logo1.url.trim()) ||
    doc.company.logo ||
    '/sarwan-logo.png';
  const logo2Url =
    (design.logos?.logo2?.url && design.logos.logo2.url.trim()) ||
    (doc.design?.logos?.logo2?.url && doc.design.logos.logo2.url.trim()) ||
    doc.company.logo2 ||
    '/dahua-logo.svg';

  // PDF-safe SVG converter: Converts SVG logos to high-resolution PNG data URLs
  // ensuring html2canvas renders the complete logo without text clipping or aspect-ratio distortion
  const [safeLogo1Url, setSafeLogo1Url] = React.useState<string>(logo1Url);
  const [safeLogo2Url, setSafeLogo2Url] = React.useState<string>(logo2Url);

  React.useEffect(() => {
    setSafeLogo1Url(logo1Url);
    if (!logo1Url) return;

    if (
      logo1Url.startsWith('data:image/png') ||
      logo1Url.startsWith('data:image/jpeg') ||
      logo1Url.endsWith('.png') ||
      logo1Url.endsWith('.jpg') ||
      logo1Url.endsWith('.jpeg') ||
      logo1Url.endsWith('.webp')
    ) {
      return;
    }

    let active = true;
    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.onload = () => {
      if (!active) return;
      try {
        const canvas = document.createElement('canvas');
        const targetWidth = (design.logos?.logo1?.width || 120) * 3;
        const targetHeight = (design.logos?.logo1?.height || 56) * 3;
        canvas.width = targetWidth;
        canvas.height = targetHeight;
        const ctx = canvas.getContext('2d');
        if (ctx) {
          ctx.imageSmoothingEnabled = true;
          ctx.imageSmoothingQuality = 'high';
          ctx.drawImage(img, 0, 0, targetWidth, targetHeight);
          const dataUrl = canvas.toDataURL('image/png');
          setSafeLogo1Url(dataUrl);
        }
      } catch {
        // Fallback to original url
      }
    };
    img.src = logo1Url;

    return () => {
      active = false;
    };
  }, [logo1Url, design.logos?.logo1?.width, design.logos?.logo1?.height]);

  React.useEffect(() => {
    setSafeLogo2Url(logo2Url);
    if (!logo2Url) return;

    // If already a raster data URL or raster image, use directly
    if (
      logo2Url.startsWith('data:image/png') ||
      logo2Url.startsWith('data:image/jpeg') ||
      logo2Url.endsWith('.png') ||
      logo2Url.endsWith('.jpg')
    ) {
      return;
    }

    let active = true;
    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.onload = () => {
      if (!active) return;
      try {
        const canvas = document.createElement('canvas');
        const targetWidth = (design.logos.logo2.width || 140) * 3;
        const targetHeight = (design.logos.logo2.height || 46) * 3;
        canvas.width = targetWidth;
        canvas.height = targetHeight;
        const ctx = canvas.getContext('2d');
        if (ctx) {
          ctx.imageSmoothingEnabled = true;
          ctx.imageSmoothingQuality = 'high';
          ctx.drawImage(img, 0, 0, targetWidth, targetHeight);
          const dataUrl = canvas.toDataURL('image/png');
          setSafeLogo2Url(dataUrl);
        }
      } catch {
        // Fallback to original url
      }
    };
    img.src = logo2Url;

    return () => {
      active = false;
    };
  }, [logo2Url, design.logos.logo2.width, design.logos.logo2.height]);

  // Canonical centralized formatting for all invoice display values (removes unnecessary trailing decimal zeros)
  const fmt = (val: number | string | undefined | null): string => formatInvoiceNumber(val);

  const displaySubtotal = typeof (doc as any).subtotal === 'number' && Number.isFinite((doc as any).subtotal)
    ? (doc as any).subtotal
    : doc.totalPrice;

  const taxRateVal = (doc as any).taxRate ?? (doc as any).taxPercentage;
  const taxRateDisplay = typeof taxRateVal === 'number' && Number.isFinite(taxRateVal) ? `${fmt(taxRateVal)}%` : '0%';
  const rawTaxLabel = (design.totals.taxLabel || 'Tax').replace(/:$/, '').trim();
  const fullTaxLabel = rawTaxLabel.includes('%') ? rawTaxLabel : `${rawTaxLabel} (${taxRateDisplay})`;

  // PDF-safe corner decoration data URIs (dynamically styled with primary & gold colors)
  const topLeftFillEncoded = encodeURIComponent(shapeTopLeft.fillColor || deepNavy);
  const topLeftAccentEncoded = encodeURIComponent(shapeGoldAccent.show !== false ? (shapeGoldAccent.fillColor || shapeTopLeft.accentColor || goldAccent) : 'transparent');
  const topRightFillEncoded = encodeURIComponent(shapeTopRight.fillColor || deepNavy);
  const topRightAccentEncoded = encodeURIComponent(shapeGoldAccent.show !== false ? (shapeGoldAccent.fillColor || shapeTopRight.accentColor || goldAccent) : 'transparent');

  const topLeftCornerBg = `data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 130 65' width='130' height='65' preserveAspectRatio='none'%3E%3Cpolygon points='0,0 130,0 0,55' fill='${topLeftFillEncoded}' /%3E%3Cline x1='0' y1='55' x2='130' y2='0' stroke='${topLeftAccentEncoded}' stroke-width='2.5' /%3E%3C/svg%3E`;
  const topRightCornerBg = `data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 130 65' width='130' height='65' preserveAspectRatio='none'%3E%3Cpolygon points='0,0 130,0 130,55' fill='${topRightFillEncoded}' /%3E%3Cline x1='0' y1='0' x2='130' y2='55' stroke='${topRightAccentEncoded}' stroke-width='2.5' /%3E%3C/svg%3E`;
  const bottomLeftFillEncoded = encodeURIComponent(shapeBottomLeft.fillColor || footerBgColor);
  const bottomLeftAccentEncoded = encodeURIComponent(shapeBottomLeft.accentColor || footerAccentColor);
  const bottomRightFillEncoded = encodeURIComponent(shapeBottomRight.fillColor || footerBgColor);
  const bottomRightAccentEncoded = encodeURIComponent(shapeBottomRight.accentColor || footerAccentColor);

  const bottomLeftCornerBg = `data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 130 65' width='130' height='65' preserveAspectRatio='none'%3E%3Cpolygon points='0,65 130,65 0,10' fill='${bottomLeftFillEncoded}' /%3E%3Cline x1='0' y1='10' x2='130' y2='65' stroke='${bottomLeftAccentEncoded}' stroke-width='${shapeBottomLeft.borderWidth || 2.5}' /%3E%3C/svg%3E`;
  const bottomRightCornerBg = `data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 130 65' width='130' height='65' preserveAspectRatio='none'%3E%3Cpolygon points='0,65 130,65 130,10' fill='${bottomRightFillEncoded}' /%3E%3Cline x1='0' y1='65' x2='130' y2='10' stroke='${bottomRightAccentEncoded}' stroke-width='${shapeBottomRight.borderWidth || 2.5}' /%3E%3C/svg%3E`;

  return (
    <div
      id={id}
      className={`canonical-invoice-container ${className}`}
      style={{
        width: `${paperConfig.widthMm}mm`,
        minWidth: `${paperConfig.widthMm}mm`,
        margin: '0 auto',
        boxSizing: 'border-box',
        backgroundColor: 'transparent',
      }}
    >
      {pages.map((page, pageIndex) => {
        const isFirstPage = page.isFirstPage;
        const isLastPage = page.isLastPage;
        const pageNumber = page.pageNumber;
        const itemsChunk = page.items;

        return (
          <div
            key={pageIndex}
            className="canonical-invoice-sheet invoice-page-sheet relative"
            data-page-number={pageNumber}
            onClick={(e) => {
              if (isInteractive && (e.target === e.currentTarget || (e.target as HTMLElement)?.id === 'invoice-main-content')) {
                onSelectElement?.(null);
              }
            }}
            style={{
              width: `${paperConfig.widthMm}mm`,
              height: `${paperConfig.heightMm}mm`,
              minHeight: `${paperConfig.heightMm}mm`,
              maxHeight: `${paperConfig.heightMm}mm`,
              paddingTop: `${paperConfig.marginTopMm ?? 12}mm`,
              paddingRight: `${paperConfig.marginRightMm ?? 12}mm`,
              paddingBottom: `${paperConfig.marginBottomMm ?? 12}mm`,
              paddingLeft: `${paperConfig.marginLeftMm ?? 12}mm`,
              boxSizing: 'border-box',
              backgroundColor: design.colors.background || '#FFFFFF',
              color: charcoalText,
              fontFamily: fontFamily,
              fontSize: `${design.typography.baseFontSize || 11.5}px`,
              lineHeight: 1.3,
              display: 'flex',
              flexDirection: 'column',
              justifyContent: 'space-between',
              margin: '0 auto 24px auto',
              pageBreakAfter: isLastPage ? 'auto' : 'always',
              breakAfter: isLastPage ? 'auto' : 'page',
              overflow: 'hidden',
            }}
          >
            {/* ================= CORNER GEOMETRIC DECORATIONS (Top Only) ================= */}
            {/* Top-Left Corner Diagonal Flap (PDF-safe wrapper + SVG) */}
            {design.page.showCornerDecorations !== false && shapeTopLeft.show !== false && (
              <div
                {...getInteractive('shapeTopLeft', 'Top-Left Decorative Shape')}
                className={`absolute top-0 left-0 ${isInteractive ? 'pointer-events-auto' : 'pointer-events-none'} ${getInteractive('shapeTopLeft', 'Top-Left Decorative Shape').className || ''}`}
                style={{
                  position: 'absolute',
                  top: `${shapeTopLeft.y || 0}px`,
                  left: `${shapeTopLeft.x || 0}px`,
                  width: `${shapeTopLeft.width || 130}px`,
                  height: `${shapeTopLeft.height || 65}px`,
                  opacity: shapeTopLeft.opacity ?? 1,
                  transform: shapeTopLeft.rotation ? `rotate(${shapeTopLeft.rotation}deg)` : undefined,
                  borderRadius: `${shapeTopLeft.borderRadius || 0}px`,
                  pointerEvents: isInteractive ? 'auto' : 'none',
                  zIndex: shapeTopLeft.zIndex ?? 20,
                  border: shapeTopLeft.border && shapeTopLeft.border !== 'none'
                    ? `${shapeTopLeft.borderWidth || 1}px ${shapeTopLeft.border} ${shapeTopLeft.borderColor || shapeTopLeft.accentColor || goldAccent}`
                    : undefined,
                  overflow: 'hidden',
                  backgroundImage: `url("${topLeftCornerBg}")`,
                  backgroundSize: '100% 100%',
                  backgroundRepeat: 'no-repeat',
                }}
              >
                {renderBadge('shapeTopLeft', 'Top-Left Shape')}
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  viewBox={`0 0 ${shapeTopLeft.width || 130} ${shapeTopLeft.height || 65}`}
                  width={shapeTopLeft.width || 130}
                  height={shapeTopLeft.height || 65}
                  className="w-full h-full block pointer-events-none"
                  style={{
                    width: `${shapeTopLeft.width || 130}px`,
                    height: `${shapeTopLeft.height || 65}px`,
                    pointerEvents: 'none',
                    display: 'block',
                  }}
                  preserveAspectRatio="none"
                >
                  <polygon points={`0,0 ${shapeTopLeft.width || 130},0 0,${Math.round((shapeTopLeft.height || 65) * 0.85)}`} fill={shapeTopLeft.fillColor || deepNavy} />
                  <line x1="0" y1={Math.round((shapeTopLeft.height || 65) * 0.85)} x2={shapeTopLeft.width || 130} y2="0" stroke={shapeGoldAccent.show !== false ? (shapeGoldAccent.fillColor || shapeTopLeft.accentColor || goldAccent) : 'transparent'} strokeWidth={shapeTopLeft.borderWidth || 2.5} />
                </svg>
              </div>
            )}

            {/* Top-Right Corner Diagonal Flap (PDF-safe wrapper + SVG) */}
            {design.page.showCornerDecorations !== false && shapeTopRight.show !== false && (
              <div
                {...getInteractive('shapeTopRight', 'Top-Right Decorative Shape')}
                className={`absolute top-0 right-0 ${isInteractive ? 'pointer-events-auto' : 'pointer-events-none'} ${getInteractive('shapeTopRight', 'Top-Right Decorative Shape').className || ''}`}
                style={{
                  position: 'absolute',
                  top: `${shapeTopRight.y || 0}px`,
                  right: `${shapeTopRight.x || 0}px`,
                  width: `${shapeTopRight.width || 130}px`,
                  height: `${shapeTopRight.height || 65}px`,
                  opacity: shapeTopRight.opacity ?? 1,
                  transform: shapeTopRight.rotation ? `rotate(${shapeTopRight.rotation}deg)` : undefined,
                  borderRadius: `${shapeTopRight.borderRadius || 0}px`,
                  pointerEvents: isInteractive ? 'auto' : 'none',
                  zIndex: shapeTopRight.zIndex ?? 20,
                  border: shapeTopRight.border && shapeTopRight.border !== 'none'
                    ? `${shapeTopRight.borderWidth || 1}px ${shapeTopRight.border} ${shapeTopRight.borderColor || shapeTopRight.accentColor || goldAccent}`
                    : undefined,
                  overflow: 'hidden',
                  backgroundImage: `url("${topRightCornerBg}")`,
                  backgroundSize: '100% 100%',
                  backgroundRepeat: 'no-repeat',
                }}
              >
                {renderBadge('shapeTopRight', 'Top-Right Shape')}
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  viewBox={`0 0 ${shapeTopRight.width || 130} ${shapeTopRight.height || 65}`}
                  width={shapeTopRight.width || 130}
                  height={shapeTopRight.height || 65}
                  className="w-full h-full block pointer-events-none"
                  style={{
                    width: `${shapeTopRight.width || 130}px`,
                    height: `${shapeTopRight.height || 65}px`,
                    pointerEvents: 'none',
                    display: 'block',
                  }}
                  preserveAspectRatio="none"
                >
                  <polygon points={`0,0 ${shapeTopRight.width || 130},0 ${shapeTopRight.width || 130},${Math.round((shapeTopRight.height || 65) * 0.85)}`} fill={shapeTopRight.fillColor || deepNavy} />
                  <line x1="0" y1="0" x2={shapeTopRight.width || 130} y2={Math.round((shapeTopRight.height || 65) * 0.85)} stroke={shapeGoldAccent.show !== false ? (shapeGoldAccent.fillColor || shapeTopRight.accentColor || goldAccent) : 'transparent'} strokeWidth={shapeTopRight.borderWidth || 2.5} />
                </svg>
              </div>
            )}

            {/* Main Content Area: Flex 1 natural flow above bottom-anchored footer */}
            <div
              id="invoice-main-content"
              data-section="invoice-main-content"
              className="w-full flex flex-col relative z-10 flex-1 min-h-0"
              style={{
                width: '100%',
                boxSizing: 'border-box',
                flex: '1 1 auto',
              }}
            >
              {/* ================= 1. HEADER SECTION ================= */}
              {isFirstPage && design.visibility.header && design.header.show ? (
                <div
                  id="invoice-header-section"
                  data-section="invoice-header"
                  className="w-full"
                  style={{
                    backgroundColor: design.header.backgroundColor || 'transparent',
                    borderTop: (design.header.border === 'top' || design.header.border === 'both')
                      ? `${design.header.borderThickness || 1}px solid ${design.header.borderColor || skyBorder}`
                      : 'none',
                    borderBottom: (design.header.border === 'bottom' || design.header.border === 'both')
                      ? `${design.header.borderThickness || 1}px solid ${design.header.borderColor || skyBorder}`
                      : design.header.border === 'none'
                      ? 'none'
                      : `${design.header.borderThickness || 1}px solid ${design.header.borderColor || skyBorder}`,
                    paddingTop: `${design.header.padding ?? 2}px`,
                    paddingBottom: `${design.header.padding ?? 8}px`,
                    marginBottom: `${design.spacing.headerToMeta ?? (design.spacing as any).metaSpacing ?? design.spacing.headerSpacing ?? design.header.spacing ?? 8}px`,
                    minHeight: design.header.height ? `${design.header.height}px` : undefined,
                  }}
                >
                  <div className="flex items-center justify-between w-full pt-0.5">
                    {/* LEFT: Company Logo 1 */}
                    {design.visibility.logo1 && design.logos.logo1.show ? (
                      <div
                        id="invoice-header-logo-1"
                        data-header-component="logo-1"
                        {...getInteractive('logoLeft', 'Left Logo')}
                        className={`flex items-center justify-start shrink-0 relative z-30 ${getInteractive('logoLeft', 'Left Logo').className || ''}`}
                        style={{
                          width: `${design.logos.logo1.width || 120}px`,
                          opacity: design.logos.logo1.opacity ?? 1,
                          alignSelf:
                            design.logos.logo1.alignment === 'top'
                              ? 'flex-start'
                              : design.logos.logo1.alignment === 'bottom'
                              ? 'flex-end'
                              : 'center',
                          margin: design.logos.logo1.margin ? `${design.logos.logo1.margin}px` : undefined,
                        }}
                      >
                        {renderBadge('logoLeft', 'Left Logo')}
                        <img
                          src={safeLogo1Url}
                          alt={companyNameEnglish}
                          style={{
                            maxHeight: `${design.logos.logo1.height || 56}px`,
                            maxWidth: `${design.logos.logo1.width || 120}px`,
                            width: 'auto',
                            height: 'auto',
                            objectFit: 'contain',
                            display: 'block',
                          }}
                          onError={(e) => {
                            const target = e.currentTarget;
                            if (target.src !== '/sarwan-logo.png') {
                              target.src = '/sarwan-logo.png';
                            }
                          }}
                        />
                      </div>
                    ) : (
                      <div
                        id="invoice-header-logo-1"
                        data-header-component="logo-1"
                        {...getInteractive('logoLeft', 'Left Logo')}
                        className={`${getInteractive('logoLeft', 'Left Logo').className || ''}`}
                        style={{ width: `${design.logos.logo1.width || 120}px` }}
                      >
                        {renderBadge('logoLeft', 'Left Logo')}
                      </div>
                    )}

                    {/* CENTER: English Name, Pashto Name & Slogan (Clean layout without unwanted vertical dividers) */}
                    <div
                      className={`flex flex-col ${
                        design.header.alignment === 'left'
                          ? 'items-start text-left'
                          : design.header.alignment === 'right'
                          ? 'items-end text-right'
                          : 'items-center text-center'
                      } justify-center flex-1 px-4 min-w-0 relative z-30`}
                    >
                      {/* English Company Name */}
                      {design.company.showName !== false ? (
                        <div
                          id="invoice-header-company-name"
                          data-header-component="company-name"
                          {...getInteractive('companyEnglishName', 'Company English Name')}
                          dir="ltr"
                          className={`font-extrabold tracking-tight break-words ${getInteractive('companyEnglishName', 'Company English Name').className || ''}`}
                          style={{
                            color: design.company.color || design.title.color || deepNavy,
                            fontSize: `${companyNameFontSize}px`,
                            fontWeight: design.company.fontWeight || design.title.fontWeight || 'bold',
                            fontStyle: design.company.italic ? 'italic' : 'normal',
                            textDecoration: design.company.underline ? 'underline' : 'none',
                            lineHeight: '1.2',
                            fontFamily: design.company.fontFamily || design.typography.headingFontFamily || design.typography.fontFamily || 'Inter, system-ui, sans-serif',
                          }}
                        >
                          {renderBadge('companyEnglishName', 'Company English Name')}
                          {companyNameEnglish}
                        </div>
                      ) : (
                        <div id="invoice-header-company-name" data-header-component="company-name" style={{ display: 'none' }} />
                      )}

                      {/* Pashto Company Name */}
                      {design.company.showPashtoName !== false ? (
                        <div
                          id="invoice-header-pashto-name"
                          data-header-component="pashto-name"
                          {...getInteractive('companyPashtoName', 'Company Pashto Name')}
                          dir="rtl"
                          className={`font-bold tracking-normal mt-1 break-words ${getInteractive('companyPashtoName', 'Company Pashto Name').className || ''}`}
                          style={{
                            color: design.company.pashtoColor || design.title.secondaryColor || design.title.color || deepNavy,
                            fontSize: `${pashtoFontSize}px`,
                            fontStyle: design.company.italic ? 'italic' : 'normal',
                            textDecoration: design.company.underline ? 'underline' : 'none',
                            lineHeight: '1.5',
                            fontFamily: design.company.pashtoFontFamily || '"Scheherazade New", "Amiri", "Noto Naskh Arabic", Arial, sans-serif',
                          }}
                        >
                          {renderBadge('companyPashtoName', 'Company Pashto Name')}
                          {companyNamePashto}
                        </div>
                      ) : (
                        <div id="invoice-header-pashto-name" data-header-component="pashto-name" style={{ display: 'none' }} />
                      )}

                      {/* Slogan */}
                      {design.company.showSubtitle !== false ? (
                        <div
                          id="invoice-header-slogan"
                          data-header-component="slogan"
                          {...getInteractive('companySlogan', 'Company Slogan')}
                          dir="ltr"
                          className={`mt-1 break-words ${getInteractive('companySlogan', 'Company Slogan').className || ''}`}
                          style={{
                            color: sloganColor,
                            fontSize: `${sloganFontSize}px`,
                            fontWeight: design.company.sloganFontWeight || 'semibold',
                            fontStyle: design.company.sloganItalic ? 'italic' : 'normal',
                            textDecoration: design.company.sloganUnderline ? 'underline' : 'none',
                            lineHeight: design.company.sloganLineHeight !== undefined ? `${design.company.sloganLineHeight}` : '1.3',
                            letterSpacing: design.company.sloganLetterSpacing !== undefined ? `${design.company.sloganLetterSpacing}em` : '0.04em',
                            textAlign: design.company.sloganAlign || undefined,
                            fontFamily: design.company.sloganFontFamily || design.typography.fontFamily || 'Inter, system-ui, sans-serif',
                            maxWidth: design.company.sloganWidth ? `${design.company.sloganWidth}px` : undefined,
                            marginTop: design.company.sloganSpacing !== undefined ? `${design.company.sloganSpacing}px` : undefined,
                          }}
                        >
                          {renderBadge('companySlogan', 'Company Slogan')}
                          {sloganText}
                        </div>
                      ) : (
                        <div id="invoice-header-slogan" data-header-component="slogan" style={{ display: 'none' }} />
                      )}
                    </div>

                    {/* RIGHT: Partner / Secondary Logo 2 */}
                    {design.visibility.logo2 && design.logos.logo2.show ? (
                      <div
                        id="invoice-header-logo-2"
                        data-header-component="logo-2"
                        {...getInteractive('logoRight', 'Right Logo')}
                        className={`flex items-center justify-end shrink-0 relative z-30 ${getInteractive('logoRight', 'Right Logo').className || ''}`}
                        style={{
                          width: `${design.logos.logo2.width || 140}px`,
                          opacity: design.logos.logo2.opacity ?? 1,
                          alignSelf:
                            design.logos.logo2.alignment === 'top'
                              ? 'flex-start'
                              : design.logos.logo2.alignment === 'bottom'
                              ? 'flex-end'
                              : 'center',
                          margin: design.logos.logo2.margin ? `${design.logos.logo2.margin}px` : undefined,
                        }}
                      >
                        {renderBadge('logoRight', 'Right Logo')}
                        <img
                          src={safeLogo2Url}
                          alt="Company Partner Logo"
                          style={{
                            maxHeight: `${design.logos.logo2.height || 46}px`,
                            maxWidth: `${design.logos.logo2.width || 140}px`,
                            width: 'auto',
                            height: 'auto',
                            objectFit: 'contain',
                            display: 'block',
                          }}
                          onError={(e) => {
                            const target = e.currentTarget;
                            if (target.src !== '/dahua-logo.svg') {
                              target.src = '/dahua-logo.svg';
                            }
                          }}
                        />
                      </div>
                    ) : (
                      <div
                        id="invoice-header-logo-2"
                        data-header-component="logo-2"
                        {...getInteractive('logoRight', 'Right Logo')}
                        className={`${getInteractive('logoRight', 'Right Logo').className || ''}`}
                        style={{ width: `${design.logos.logo2.width || 140}px` }}
                      >
                        {renderBadge('logoRight', 'Right Logo')}
                      </div>
                    )}
                  </div>
                </div>
              ) : isFirstPage ? (
                <div id="invoice-header-section" data-section="invoice-header" style={{ display: 'none' }}>
                  <div id="invoice-header-logo-1" data-header-component="logo-1" />
                  <div id="invoice-header-company-name" data-header-component="company-name" />
                  <div id="invoice-header-pashto-name" data-header-component="pashto-name" />
                  <div id="invoice-header-slogan" data-header-component="slogan" />
                  <div id="invoice-header-logo-2" data-header-component="logo-2" />
                </div>
              ) : (
                /* Multi-Page Continuation Header (Page 2+) */
                <div
                  id="invoice-header-continuation-section"
                  data-section="invoice-header-continuation"
                  className="w-full pb-2 mb-2.5 border-b-2"
                  style={{ borderColor: deepNavy }}
                >
                  <div className="flex items-center justify-between text-xs">
                    <div className="flex items-center gap-3">
                      <span className="font-bold text-sm tracking-tight" style={{ color: deepNavy }}>
                        {companyNameEnglish}
                      </span>
                      <span className="text-slate-400">|</span>
                      <span className="font-semibold text-slate-800">Invoice: #{doc.billNumber}</span>
                      <span className="text-slate-400">|</span>
                      <span className="text-slate-600">{doc.displayDate}</span>
                    </div>
                    <div className="text-right">
                      <span className="font-semibold text-slate-800">Customer: {doc.customer.name}</span>
                      <span className="ml-3 text-xs text-slate-500 font-medium">(Page {pageNumber} of {totalPages})</span>
                    </div>
                  </div>
                </div>
              )}

              {/* ================= VOID BANNER ================= */}
              {doc.isVoid && (
                <div
                  id="invoice-void-banner"
                  data-section="invoice-void-banner"
                  className="w-full my-1.5 py-1 px-3 text-center font-bold tracking-widest text-xs flex items-center justify-center gap-2"
                  style={{
                    backgroundColor: '#FEE2E2',
                    color: '#991B1B',
                    border: '1px solid #F87171',
                    borderRadius: '4px',
                  }}
                >
                  <span className="uppercase tracking-widest font-black text-xs">*** VOID INVOICE — CANCELLED ***</span>
                </div>
              )}

              {/* ================= QUOTATION / REJECTED BANNER ================= */}
              {!doc.isVoid && doc.billingState === 'quotation' && (
                <div
                  id="invoice-quotation-banner"
                  data-section="invoice-quotation-banner"
                  className="w-full my-1.5 py-1 px-3 text-center font-bold tracking-widest text-xs flex items-center justify-center gap-2"
                  style={{
                    backgroundColor: '#FEF3C7',
                    color: '#92400E',
                    border: '1px solid #F59E0B',
                    borderRadius: '4px',
                  }}
                >
                  <span className="uppercase tracking-widest font-black text-xs">*** QUOTATION / PENDING APPROVAL — NOT A BILL ***</span>
                </div>
              )}
              {!doc.isVoid && doc.billingState === 'rejected' && (
                <div
                  id="invoice-rejected-banner"
                  data-section="invoice-rejected-banner"
                  className="w-full my-1.5 py-1 px-3 text-center font-bold tracking-widest text-xs flex items-center justify-center gap-2"
                  style={{
                    backgroundColor: '#F3F4F6',
                    color: '#4B5563',
                    border: '1px solid #9CA3AF',
                    borderRadius: '4px',
                  }}
                >
                  <span className="uppercase tracking-widest font-black text-xs">*** REJECTED QUOTATION ***</span>
                </div>
              )}

              {/* ================= 2. INVOICE TITLE + COMBINED INFORMATION ROW ================= */}
              {isFirstPage ? (
                <div
                  id="invoice-title-meta-section"
                  data-section="invoice-title-meta"
                  className="w-full"
                  style={{
                    width: '100%',
                    boxSizing: 'border-box',
                    marginBottom: `${design.spacing.customerToTable ?? (design.spacing as any).customerToTableSpacing ?? design.spacing.tableSpacing ?? design.spacing.sectionSpacing ?? 8}px`,
                  }}
                >
                  {/* Top: Invoice Title ("INVOICE") */}
                  {design.visibility.invoiceTitle && design.title.show ? (
                    <div
                      id="invoice-main-title"
                      data-component="invoice-title"
                      {...getInteractive('invoiceTitle', 'Invoice Title')}
                      className={`tracking-tight shrink-0 mb-1.5 ${getInteractive('invoiceTitle', 'Invoice Title').className || ''}`}
                      style={{
                        color: design.title.color || deepNavy,
                        fontSize: `${invoiceTitleFontSize}px`,
                        fontWeight: design.title.fontWeight || 'bold',
                        fontFamily: design.title.fontFamily || design.typography.headingFontFamily || fontFamily,
                        lineHeight: '1.1',
                        textAlign: design.title.alignment || 'left',
                        marginTop: `${design.title.marginTop ?? 0}px`,
                        marginBottom: `${design.title.marginBottom ?? 6}px`,
                      }}
                    >
                      {renderBadge('invoiceTitle', 'Invoice Title')}
                      {invoiceTitleText}
                    </div>
                  ) : (
                    <div id="invoice-main-title" data-component="invoice-title" style={{ display: 'none' }} />
                  )}

                  {/* ONE Horizontal Row: Left 40% Invoice Information | Right 60% Customer Information */}
                  <div
                    className="w-full flex items-stretch gap-3"
                    style={{
                      width: '100%',
                      boxSizing: 'border-box',
                    }}
                  >
                    {/* LEFT SIDE — INVOICE INFORMATION (~30% width) */}
                    {(design.visibility.invoiceNumber || design.visibility.date || design.visibility.collector) ? (
                      <div
                        id="invoice-bill-info-box"
                        data-component="invoice-bill-info"
                        {...getInteractive('invoiceMeta', 'Invoice Metadata')}
                        className={`w-[30%] min-w-0 text-[11px] shadow-2xs flex flex-col justify-start rounded border overflow-hidden ${getInteractive('invoiceMeta', 'Invoice Metadata').className || ''}`}
                        style={{
                          width: 'calc(30% - 6px)',
                          flex: '0 0 calc(30% - 6px)',
                          backgroundColor: design.invoiceMeta?.backgroundColor || design.invoiceNumber.backgroundColor || design.colors.background || '#FFFFFF',
                          borderColor: (design.invoiceMeta?.borderStyle || design.invoiceNumber.borderStyle || 'solid') === 'none'
                            ? 'transparent'
                            : (design.invoiceMeta?.borderColor || design.invoiceNumber.borderColor || '#E5E7EB'),
                          borderStyle: (design.invoiceMeta?.borderStyle || design.invoiceNumber.borderStyle || 'solid') as any,
                          borderWidth: (design.invoiceMeta?.borderStyle || design.invoiceNumber.borderStyle || 'solid') === 'none'
                            ? '0px'
                            : `${design.invoiceMeta?.borderWidth ?? design.invoiceNumber.borderWidth ?? 1}px`,
                          borderRadius: `${design.invoiceMeta?.borderRadius ?? design.invoiceNumber.borderRadius ?? 4}px`,
                          overflow: 'hidden',
                          boxSizing: 'border-box',
                        }}
                      >
                        {renderBadge('invoiceMeta', 'Invoice Metadata')}
                        {/* Header bar: Invoice Info */}
                        <div
                          {...getInteractive('tableHeader', 'Table Header')}
                          className={`flex items-center gap-1.5 py-1 px-2.5 border-b shrink-0 ${getInteractive('tableHeader', 'Table Header').className || ''}`}
                          style={{
                            backgroundColor: tableHeaderBg,
                            borderColor: design.invoiceNumber.borderColor || '#E2E8F0',
                          }}
                        >
                          <svg viewBox="0 0 24 24" className="w-3.5 h-3.5 fill-current shrink-0" style={{ color: tableHeaderTextColor }}>
                            <path d="M19 3H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.89 2-2V5c0-1.1-.9-2-2-2zm-5 14H7v-2h7v2zm3-4H7v-2h10v2zm0-4H7V7h10v2z" />
                          </svg>
                          <span
                            className="font-bold tracking-wide uppercase text-[10px]"
                            style={{
                              color: tableHeaderTextColor,
                              fontSize: `${design.typography.sectionHeadingFontSize || 10.5}px`,
                              fontFamily: design.typography.fontFamily || "'Inter', sans-serif",
                              lineHeight: '1.4',
                            }}
                          >
                            Invoice Info
                          </span>
                        </div>

                        <div className="w-full flex-1 bg-white divide-y divide-slate-100 flex flex-col justify-between">
                          {/* 1. Invoice Number */}
                          {design.visibility.invoiceNumber && design.invoiceNumber.show && (
                            <div
                              {...getInteractive('billNumber', 'Bill Number')}
                              className={`invoice-meta-row flex items-center justify-between gap-1.5 py-1 px-2.5 min-h-[22px] ${getInteractive('billNumber', 'Bill Number').className || ''}`}
                              style={{
                                lineHeight: '1.35',
                                boxSizing: 'border-box',
                                fontFamily: design.invoiceNumber.fontFamily || design.typography.fontFamily || 'Inter, system-ui, sans-serif',
                              }}
                            >
                              {renderBadge('billNumber', 'Bill Number')}
                              <span
                                className="font-bold shrink-0 text-[10.5px]"
                                style={{
                                  color: design.invoiceNumber.color || deepNavy,
                                  fontWeight: design.invoiceNumber.fontWeight || 'bold',
                                  fontSize: `${design.invoiceNumber.fontSize || 10.5}px`,
                                  fontStyle: design.invoiceNumber.italic ? 'italic' : 'normal',
                                  textDecoration: design.invoiceNumber.underline ? 'underline' : 'none',
                                }}
                              >
                                {design.invoiceNumber.label || 'Invoice Number:'}
                              </span>
                              <span
                                className="font-semibold font-mono text-right break-words flex-1 min-w-0 text-[10.5px]"
                                style={{
                                  color: design.invoiceNumber.valueColor || design.colors.text || '#0F172A',
                                  fontSize: `${design.invoiceNumber.fontSize || 10.5}px`,
                                  fontStyle: design.invoiceNumber.italic ? 'italic' : 'normal',
                                  textDecoration: design.invoiceNumber.underline ? 'underline' : 'none',
                                }}
                              >
                                {doc.billNumber}
                              </span>
                            </div>
                          )}

                          {/* 2. Invoice Date */}
                          {design.visibility.date && design.date.show && (
                            <div
                              {...getInteractive('invoiceDate', 'Invoice Date')}
                              className={`invoice-meta-row flex items-center justify-between gap-1.5 py-1 px-2.5 min-h-[22px] ${getInteractive('invoiceDate', 'Invoice Date').className || ''}`}
                              style={{
                                lineHeight: '1.35',
                                boxSizing: 'border-box',
                                fontFamily: design.date.fontFamily || design.typography.fontFamily || 'Inter, system-ui, sans-serif',
                              }}
                            >
                              {renderBadge('invoiceDate', 'Invoice Date')}
                              <span
                                className="font-bold shrink-0 text-[10.5px]"
                                style={{
                                  color: design.date.color || deepNavy,
                                  fontWeight: design.date.fontWeight || 'bold',
                                  fontSize: `${design.date.fontSize || 10.5}px`,
                                  fontStyle: design.date.italic ? 'italic' : 'normal',
                                  textDecoration: design.date.underline ? 'underline' : 'none',
                                }}
                              >
                                {design.date.label || 'Invoice Date:'}
                              </span>
                              <span
                                className="font-medium text-slate-800 text-right break-words flex-1 min-w-0 text-[10.5px]"
                                style={{
                                  color: design.date.valueColor || design.colors.text || '#0F172A',
                                  fontSize: `${design.date.fontSize || 10.5}px`,
                                  fontStyle: design.date.italic ? 'italic' : 'normal',
                                  textDecoration: design.date.underline ? 'underline' : 'none',
                                }}
                              >
                                {doc.displayDate}
                              </span>
                            </div>
                          )}

                          {/* 3. Collector */}
                          {design.visibility.collector && design.collector.show && (
                            <div
                              {...getInteractive('collector', 'Collector')}
                              className={`invoice-meta-row flex items-center justify-between gap-1.5 py-1 px-2.5 min-h-[22px] ${getInteractive('collector', 'Collector').className || ''}`}
                              style={{
                                lineHeight: '1.35',
                                boxSizing: 'border-box',
                                fontFamily: design.collector.fontFamily || design.typography.fontFamily || 'Inter, system-ui, sans-serif',
                              }}
                            >
                              {renderBadge('collector', 'Collector')}
                              <span
                                className="font-bold shrink-0 text-[10.5px]"
                                style={{
                                  color: design.collector.color || deepNavy,
                                  fontWeight: design.collector.fontWeight || 'bold',
                                  fontSize: `${design.collector.fontSize || 10.5}px`,
                                  fontStyle: design.collector.italic ? 'italic' : 'normal',
                                  textDecoration: design.collector.underline ? 'underline' : 'none',
                                }}
                              >
                                {design.collector.label || 'Collector:'}
                              </span>
                              <span
                                className="font-medium text-slate-800 text-right break-words flex-1 min-w-0 text-[10.5px]"
                                style={{
                                  color: design.collector.valueColor || design.colors.text || '#0F172A',
                                  fontSize: `${design.collector.fontSize || 10.5}px`,
                                  fontStyle: design.collector.italic ? 'italic' : 'normal',
                                  textDecoration: design.collector.underline ? 'underline' : 'none',
                                }}
                              >
                                {doc.assignedCollector?.name || '—'}
                              </span>
                            </div>
                          )}
                        </div>
                      </div>
                    ) : (
                      <div id="invoice-bill-info-box" data-component="invoice-bill-info" style={{ display: 'none' }} />
                    )}

                    {/* RIGHT SIDE — CUSTOMER INFORMATION (~70% width) */}
                    {(design.visibility.customerInfo && design.customer.show) ? (
                      <div
                        id="invoice-customer-section"
                        data-section="invoice-customer"
                        {...getInteractive('customerInfo', 'Customer Details')}
                        className={`w-[70%] min-w-0 text-[11px] shadow-2xs flex flex-col justify-start rounded border overflow-hidden ${getInteractive('customerInfo', 'Customer Details').className || ''}`}
                        style={{
                          width: 'calc(70% - 6px)',
                          flex: '0 0 calc(70% - 6px)',
                          borderColor: design.customer.borderColor || skyBorder,
                          backgroundColor: design.customer.backgroundColor || design.colors.background || '#FFFFFF',
                          boxSizing: 'border-box',
                        }}
                      >
                        {renderBadge('customerInfo', 'Customer Details')}
                        {/* Customer Information Header Bar */}
                        <div
                          {...getInteractive('tableHeader', 'Table Header')}
                          className={`flex items-center gap-1.5 py-1 px-2.5 border-b shrink-0 ${getInteractive('tableHeader', 'Table Header').className || ''}`}
                          style={{
                            backgroundColor: tableHeaderBg,
                            borderColor: design.customer.borderColor || '#E2E8F0',
                          }}
                        >
                          <svg viewBox="0 0 24 24" className="w-3.5 h-3.5 fill-current shrink-0" style={{ color: tableHeaderTextColor }}>
                            <path d="M12 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z" />
                          </svg>
                          <span
                            className="font-bold tracking-wide uppercase text-[10px]"
                            style={{
                              color: tableHeaderTextColor,
                              fontSize: `${design.typography.sectionHeadingFontSize || 10.5}px`,
                              fontFamily: design.typography.fontFamily || "'Inter', sans-serif",
                              lineHeight: '1.4',
                            }}
                          >
                            {design.customer.sectionTitle || 'Customer Information'}
                          </span>
                        </div>

                        {/* Customer Details Content - Exactly 4 Fields: Name, Phone, Company, Address (Email is NOT displayed) */}
                        <div
                          className="w-full flex-1 bg-white divide-y divide-slate-100 flex flex-col justify-between"
                          style={{
                            fontSize: `${customerFontSize}px`,
                            color: design.customer.color || deepNavy,
                          }}
                        >
                          {/* 1. Customer Name */}
                          {design.customer.showName && (
                            <div
                              {...getInteractive('customerName', 'Customer Name')}
                              className={`flex items-center justify-between gap-2 py-1 px-2.5 min-h-[22px] ${getInteractive('customerName', 'Customer Name').className || ''}`}
                              style={{
                                fontFamily: design.customer.nameFontFamily || design.customer.fontFamily || fontFamily,
                              }}
                            >
                              {renderBadge('customerName', 'Customer Name')}
                              <span
                                className="font-semibold shrink-0"
                                style={{
                                  color: design.customer.nameLabelColor || design.customer.color || deepNavy,
                                  fontWeight: design.customer.nameFontWeight || 600,
                                  fontSize: `${design.customer.nameFontSize || customerFontSize}px`,
                                  fontStyle: (design.customer as any).nameItalic !== undefined ? ((design.customer as any).nameItalic ? 'italic' : 'normal') : (design.customer.italic ? 'italic' : 'normal'),
                                  textDecoration: (design.customer as any).nameUnderline !== undefined ? ((design.customer as any).nameUnderline ? 'underline' : 'none') : (design.customer.underline ? 'underline' : 'none'),
                                  lineHeight: design.typography.lineHeight || 1.4,
                                }}
                              >
                                {design.customer.nameLabel || 'Customer Name:'}
                              </span>
                              <span
                                className="font-normal text-right break-words flex-1 min-w-0"
                                style={{
                                  color: design.customer.nameValueColor || '#0F172A',
                                  fontSize: `${design.customer.nameFontSize || customerFontSize}px`,
                                  fontStyle: (design.customer as any).nameItalic !== undefined ? ((design.customer as any).nameItalic ? 'italic' : 'normal') : (design.customer.italic ? 'italic' : 'normal'),
                                  textDecoration: (design.customer as any).nameUnderline !== undefined ? ((design.customer as any).nameUnderline ? 'underline' : 'none') : (design.customer.underline ? 'underline' : 'none'),
                                  lineHeight: design.typography.lineHeight || 1.4,
                                }}
                              >
                                {doc.customer.name || 'Walk-in Customer'}
                              </span>
                            </div>
                          )}

                          {/* 2. Customer Phone */}
                          {design.customer.showPhone && (
                            <div
                              {...getInteractive('customerPhone', 'Customer Phone')}
                              className={`flex items-center justify-between gap-2 py-1 px-2.5 min-h-[22px] ${getInteractive('customerPhone', 'Customer Phone').className || ''}`}
                              style={{
                                fontFamily: design.customer.phoneFontFamily || design.customer.fontFamily || fontFamily,
                              }}
                            >
                              {renderBadge('customerPhone', 'Customer Phone')}
                              <span
                                className="font-semibold shrink-0"
                                style={{
                                  color: design.customer.phoneLabelColor || design.customer.color || deepNavy,
                                  fontWeight: design.customer.phoneFontWeight || 600,
                                  fontSize: `${design.customer.phoneFontSize || customerFontSize}px`,
                                  fontStyle: (design.customer as any).phoneItalic !== undefined ? ((design.customer as any).phoneItalic ? 'italic' : 'normal') : (design.customer.italic ? 'italic' : 'normal'),
                                  textDecoration: (design.customer as any).phoneUnderline !== undefined ? ((design.customer as any).phoneUnderline ? 'underline' : 'none') : (design.customer.underline ? 'underline' : 'none'),
                                  lineHeight: design.typography.lineHeight || 1.4,
                                }}
                              >
                                {design.customer.phoneLabel || 'Phone:'}
                              </span>
                              <span
                                className="font-normal text-right break-words flex-1 min-w-0 font-mono"
                                style={{
                                  color: design.customer.phoneValueColor || '#0F172A',
                                  fontSize: `${design.customer.phoneFontSize || customerFontSize}px`,
                                  lineHeight: design.typography.lineHeight || 1.4,
                                }}
                              >
                                {doc.customer.phone || '—'}
                              </span>
                            </div>
                          )}

                          {/* 3. Customer Company */}
                          {design.customer.showCompany && (
                            <div
                              {...getInteractive('customerCompany', 'Customer Company')}
                              className={`flex items-center justify-between gap-2 py-1 px-2.5 min-h-[22px] ${getInteractive('customerCompany', 'Customer Company').className || ''}`}
                              style={{
                                fontFamily: design.customer.companyFontFamily || design.customer.fontFamily || fontFamily,
                              }}
                            >
                              {renderBadge('customerCompany', 'Customer Company')}
                              <span
                                className="font-semibold shrink-0"
                                style={{
                                  color: design.customer.companyColor || design.customer.color || deepNavy,
                                  fontWeight: design.customer.companyFontWeight || 600,
                                  fontSize: `${design.customer.companyFontSize || customerFontSize}px`,
                                  fontStyle: design.customer.companyItalic ? 'italic' : 'normal',
                                  textDecoration: design.customer.companyUnderline ? 'underline' : 'none',
                                  lineHeight: design.typography.lineHeight || 1.4,
                                }}
                              >
                                {design.customer.companyLabel || 'Company:'}
                              </span>
                              <span
                                className="font-normal text-right break-words flex-1 min-w-0"
                                style={{
                                  color: design.customer.companyValueColor || '#0F172A',
                                  fontSize: `${design.customer.companyFontSize || customerFontSize}px`,
                                  fontStyle: design.customer.companyItalic ? 'italic' : 'normal',
                                  textDecoration: design.customer.companyUnderline ? 'underline' : 'none',
                                  lineHeight: design.typography.lineHeight || 1.4,
                                }}
                              >
                                {doc.customer.companyName || '—'}
                              </span>
                            </div>
                          )}

                          {/* 4. Customer Address */}
                          {design.customer.showAddress && (
                            <div
                              {...getInteractive('customerAddress', 'Customer Address')}
                              className={`flex items-center justify-between gap-2 py-1 px-2.5 min-h-[22px] ${getInteractive('customerAddress', 'Customer Address').className || ''}`}
                              style={{
                                fontFamily: design.customer.addressFontFamily || design.customer.fontFamily || fontFamily,
                              }}
                            >
                              {renderBadge('customerAddress', 'Customer Address')}
                              <span
                                className="font-semibold shrink-0"
                                style={{
                                  color: design.customer.addressLabelColor || design.customer.color || deepNavy,
                                  fontWeight: design.customer.addressFontWeight || 600,
                                  fontSize: `${design.customer.addressFontSize || customerFontSize}px`,
                                  fontStyle: (design.customer as any).addressItalic !== undefined ? ((design.customer as any).addressItalic ? 'italic' : 'normal') : (design.customer.italic ? 'italic' : 'normal'),
                                  textDecoration: (design.customer as any).addressUnderline !== undefined ? ((design.customer as any).addressUnderline ? 'underline' : 'none') : (design.customer.underline ? 'underline' : 'none'),
                                  lineHeight: design.typography.lineHeight || 1.4,
                                }}
                              >
                                {design.customer.addressLabel || 'Address:'}
                              </span>
                              <span
                                className="font-normal text-right break-words flex-1 min-w-0 leading-normal"
                                style={{
                                  color: design.customer.addressValueColor || '#0F172A',
                                  fontSize: `${design.customer.addressFontSize || customerFontSize}px`,
                                  fontStyle: (design.customer as any).addressItalic !== undefined ? ((design.customer as any).addressItalic ? 'italic' : 'normal') : (design.customer.italic ? 'italic' : 'normal'),
                                  textDecoration: (design.customer as any).addressUnderline !== undefined ? ((design.customer as any).addressUnderline ? 'underline' : 'none') : (design.customer.underline ? 'underline' : 'none'),
                                  lineHeight: design.typography.lineHeight || 1.4,
                                }}
                              >
                                {doc.customer.address || '—'}
                              </span>
                            </div>
                          )}
                        </div>
                      </div>
                    ) : (
                      <div id="invoice-customer-section" data-section="invoice-customer" style={{ display: 'none' }} />
                    )}
                  </div>
                </div>
              ) : (
                <div id="invoice-title-meta-section" data-section="invoice-title-meta" style={{ display: 'none' }}>
                  <div id="invoice-main-title" data-component="invoice-title" />
                  <div id="invoice-bill-info-box" data-component="invoice-bill-info" />
                  <div id="invoice-customer-section" data-section="invoice-customer" />
                </div>
              )}

              {/* Continuation Header on Pages 2+ */}
              {!isFirstPage && (
                <div
                  className="w-full flex items-center justify-between pb-2 mb-2 border-b text-xs relative z-30"
                  style={{
                    borderColor: design.header.borderColor || skyBorder,
                    paddingTop: '4px',
                  }}
                >
                  <div className="flex items-center gap-2">
                    <span className="font-bold tracking-tight" style={{ color: design.title.color || deepNavy, fontSize: '13px' }}>
                      {companyNameEnglish}
                    </span>
                    <span className="text-slate-300">|</span>
                    <span className="text-slate-600 font-medium text-[11px]">
                      {invoiceTitleText} #{doc.billNumber || doc.invoiceNumber}
                    </span>
                  </div>
                  <div className="text-[11px] font-semibold text-slate-500 font-mono">
                    Page {pageNumber} of {totalPages}
                  </div>
                </div>
              )}

              {/* ================= 4. ITEMS TABLE (Auto-height, compact, natural sizing) ================= */}
              {design.visibility.itemsTable && design.itemsTable.show ? (
                <div
                  id="invoice-items-table-section"
                  data-section="invoice-items-table"
                  {...getInteractive('itemsTable', 'Items Table')}
                  className={`w-full overflow-hidden shadow-2xs ${getInteractive('itemsTable', 'Items Table').className || ''}`}
                  style={{
                    backgroundColor: design.itemsTable.backgroundColor || '#FFFFFF',
                    borderColor: (design.itemsTable.tableBorderStyle || 'solid') === 'none'
                      ? 'transparent'
                      : (design.itemsTable.tableBorderColor || design.itemsTable.borderColor || skyBorder),
                    borderStyle: (design.itemsTable.tableBorderStyle || 'solid') as any,
                    borderWidth: (design.itemsTable.tableBorderStyle || 'solid') === 'none'
                      ? '0px'
                      : `${design.itemsTable.tableBorderWidth ?? 1}px`,
                    borderRadius: `${design.itemsTable.tableBorderRadius ?? 4}px`,
                    width: '100%',
                    boxSizing: 'border-box',
                    marginBottom: `${design.spacing.tableToPayment ?? (design.spacing as any).tableToPaymentSpacing ?? design.spacing.paymentSpacing ?? design.spacing.sectionSpacing ?? 10}px`,
                  }}
                >
                  {renderBadge('itemsTable', 'Items Table')}
                  <table
                    className="w-full border-collapse"
                    style={{
                      width: '100%',
                      tableLayout: 'fixed',
                      boxSizing: 'border-box',
                    }}
                  >
                    <thead>
                      <tr
                        className="font-bold"
                        style={{
                          backgroundColor: tableHeaderBg,
                          color: tableHeaderTextColor,
                          fontSize: `${tableHeaderFontSize}px`,
                          fontWeight: design.itemsTable.headerFontWeight || 'bold',
                          fontStyle: design.itemsTable.headerItalic ? 'italic' : 'normal',
                          textDecoration: design.itemsTable.headerUnderline ? 'underline' : 'none',
                          fontFamily: design.itemsTable.headerFontFamily || design.typography.fontFamily || 'Inter, system-ui, sans-serif',
                          height: '28px',
                        }}
                      >
                        {columnKeys.map((colKey) => {
                          const colConfig: TableColumnConfig = design.itemsTable.columns[colKey];
                          const isNumeric = colKey === 'unitPrice' || colKey === 'totalAmount' || colKey === 'discount';
                          const isCenter = colKey === 'sNo' || colKey === 'quantity';

                          let label = colConfig?.label;
                          if (!label) {
                            if (colKey === 'sNo') label = '#';
                            else if (colKey === 'description') label = 'Item Description';
                            else if (colKey === 'quantity') label = 'Qty';
                            else if (colKey === 'unit') label = 'Unit';
                            else if (colKey === 'unitPrice') label = 'Unit Price';
                            else if (colKey === 'totalAmount') label = 'Total';
                            else if (colKey === 'discount') label = 'Discount';
                            else if (colKey === 'tax') label = 'Tax';
                          }

                          const colElementMap: Record<string, DesignerElement> = {
                            sNo: 'tableColumnSerial',
                            description: 'tableColumnDescription',
                            quantity: 'tableColumnQuantity',
                            unit: 'tableColumnUnit',
                            unitPrice: 'tableColumnUnitPrice',
                            discount: 'tableColumnDiscount',
                            tax: 'tableColumnTax',
                            totalAmount: 'tableColumnTotal',
                          };
                          const colElementKey = colElementMap[String(colKey)] || 'tableHeader';

                          return (
                            <th
                              key={colKey}
                              {...getInteractive(colElementKey, `Column: ${label}`)}
                              className={`border-r last:border-r-0 border-white/20 relative ${getInteractive(colElementKey, `Column: ${label}`).className || ''}`}
                              style={{
                                textAlign: colConfig?.align || (isNumeric ? 'right' : isCenter ? 'center' : 'left'),
                                verticalAlign: 'middle',
                                lineHeight: '1.4',
                                boxSizing: 'border-box',
                                paddingTop: `${colConfig?.padding ?? tablePadding}px`,
                                paddingBottom: `${colConfig?.padding ?? tablePadding}px`,
                                paddingLeft: `${Math.round((colConfig?.padding ?? tablePadding) * 2.5)}px`,
                                paddingRight: `${Math.round((colConfig?.padding ?? tablePadding) * 2.5)}px`,
                                width: colConfig?.width || (
                                  colKey === 'sNo'
                                    ? '6%'
                                    : colKey === 'quantity'
                                    ? '10%'
                                    : colKey === 'unitPrice'
                                    ? '18%'
                                    : colKey === 'totalAmount'
                                    ? '18%'
                                    : colKey === 'discount'
                                    ? '12%'
                                    : columnKeys.includes('discount')
                                    ? '36%'
                                    : '48%'
                                ),
                                fontFamily: colConfig?.fontFamily || design.itemsTable.headerFontFamily || design.typography.fontFamily || 'Inter, system-ui, sans-serif',
                                fontSize: colConfig?.fontSize ? `${colConfig.fontSize}px` : undefined,
                                fontWeight: colConfig?.fontWeight || undefined,
                                fontStyle: colConfig?.italic !== undefined ? (colConfig.italic ? 'italic' : 'normal') : undefined,
                                textDecoration: colConfig?.underline !== undefined ? (colConfig.underline ? 'underline' : 'none') : undefined,
                                color: colConfig?.headerTextColor || tableHeaderTextColor,
                                backgroundColor: colConfig?.headerBgColor || tableHeaderBg,
                                borderRightColor: colConfig?.borderColor || 'rgba(255, 255, 255, 0.2)',
                                borderRightWidth: colConfig?.borderWidth !== undefined ? `${colConfig.borderWidth}px` : undefined,
                                borderRightStyle: colConfig?.borderStyle || undefined,
                              }}
                            >
                              {label}
                              {renderBadge(colElementKey, label)}
                            </th>
                          );
                        })}
                      </tr>
                    </thead>
                    <tbody
                      style={{
                        fontFamily: design.itemsTable.bodyFontFamily || design.typography.fontFamily || 'Inter, system-ui, sans-serif',
                        fontWeight: design.itemsTable.bodyFontWeight || 'normal',
                        fontStyle: design.itemsTable.bodyItalic ? 'italic' : 'normal',
                        textDecoration: design.itemsTable.bodyUnderline ? 'underline' : 'none',
                      }}
                    >
                      {itemsChunk.map((item, index) => {
                        const isEven = index % 2 === 0;
                        const hasData = isPopulatedInvoiceItem(item);

                        return (
                          <tr
                            key={index}
                            className="border-b last:border-b-0"
                            style={{
                              borderColor: design.itemsTable.borderColor || skyBorder,
                              backgroundColor: isEven
                                ? pageBackground
                                : (design.itemsTable.useZebraStriping || (design.itemsTable as any).stripedRows ? (design.itemsTable.alternateRowColor || '#F9FBFF') : pageBackground),
                              height: `${tableRowHeight}px`,
                              minHeight: `${tableRowHeight}px`,
                              fontSize: `${tableBodyFontSize}px`,
                            }}
                          >
                            {columnKeys.map((colKey) => {
                              const colConfig: TableColumnConfig = design.itemsTable.columns[colKey];
                              const isNumeric = colKey === 'unitPrice' || colKey === 'totalAmount' || colKey === 'discount';
                              const isCenter = colKey === 'sNo' || colKey === 'quantity';

                              const colElementMap: Record<string, DesignerElement> = {
                                sNo: 'tableColumnSerial',
                                description: 'tableColumnDescription',
                                quantity: 'tableColumnQuantity',
                                unit: 'tableColumnUnit',
                                unitPrice: 'tableColumnUnitPrice',
                                discount: 'tableColumnDiscount',
                                tax: 'tableColumnTax',
                                totalAmount: 'tableColumnTotal',
                              };
                              const colElementKey = colElementMap[String(colKey)] || 'tableBody';

                              const cellFontFamily = colConfig?.fontFamily || undefined;
                              const cellFontSize = colConfig?.fontSize ? `${colConfig.fontSize}px` : undefined;
                              const cellFontWeight = colConfig?.fontWeight || undefined;
                              const cellFontStyle = colConfig?.italic !== undefined ? (colConfig.italic ? 'italic' : 'normal') : undefined;
                              const cellTextDecoration = colConfig?.underline !== undefined ? (colConfig.underline ? 'underline' : 'none') : undefined;
                              const cellColor = colConfig?.textColor || undefined;

                              let cellContent: React.ReactNode = '';
                              if (colKey === 'sNo') {
                                cellContent = hasData ? (
                                  <span
                                    className={cellFontWeight ? undefined : 'font-bold'}
                                    style={{
                                      color: cellColor || royalBlue,
                                      lineHeight: '1.4',
                                      fontWeight: cellFontWeight,
                                      fontFamily: cellFontFamily,
                                      fontSize: cellFontSize,
                                      fontStyle: cellFontStyle,
                                      textDecoration: cellTextDecoration,
                                    }}
                                  >
                                    {item.sNo}
                                  </span>
                                ) : '';
                              } else if (colKey === 'description') {
                                cellContent = hasData ? (
                                  <span
                                    className={`break-words leading-tight ${cellFontWeight ? '' : 'font-medium text-slate-900'}`}
                                    style={{
                                      color: cellColor,
                                      lineHeight: '1.4',
                                      fontWeight: cellFontWeight,
                                      fontFamily: cellFontFamily,
                                      fontSize: cellFontSize,
                                      fontStyle: cellFontStyle,
                                      textDecoration: cellTextDecoration,
                                    }}
                                  >
                                    {item.description}
                                  </span>
                                ) : '';
                              } else if (colKey === 'quantity') {
                                cellContent = hasData && item.quantity !== '' ? (
                                  <span
                                    className={cellFontWeight ? undefined : 'font-medium text-slate-800'}
                                    style={{
                                      color: cellColor,
                                      lineHeight: '1.4',
                                      fontWeight: cellFontWeight,
                                      fontFamily: cellFontFamily,
                                      fontSize: cellFontSize,
                                      fontStyle: cellFontStyle,
                                      textDecoration: cellTextDecoration,
                                    }}
                                  >
                                    {fmt(item.quantity)}
                                  </span>
                                ) : '';
                              } else if (colKey === 'unit') {
                                cellContent = hasData ? (
                                  <span
                                    className={cellFontWeight ? undefined : 'text-slate-800'}
                                    style={{
                                      color: cellColor,
                                      lineHeight: '1.4',
                                      fontWeight: cellFontWeight,
                                      fontFamily: cellFontFamily,
                                      fontSize: cellFontSize,
                                      fontStyle: cellFontStyle,
                                      textDecoration: cellTextDecoration,
                                    }}
                                  >
                                    {(item as any).unit || 'pcs'}
                                  </span>
                                ) : '';
                              } else if (colKey === 'unitPrice') {
                                cellContent = hasData && item.unitPrice !== '' ? (
                                  <span
                                    className={`${cellFontFamily ? '' : 'font-mono'} ${cellFontWeight ? '' : 'text-slate-800'}`}
                                    style={{
                                      color: cellColor,
                                      lineHeight: '1.4',
                                      fontWeight: cellFontWeight,
                                      fontFamily: cellFontFamily,
                                      fontSize: cellFontSize,
                                      fontStyle: cellFontStyle,
                                      textDecoration: cellTextDecoration,
                                    }}
                                  >
                                    {fmt(item.unitPrice)}
                                  </span>
                                ) : '';
                              } else if (colKey === 'discount') {
                                cellContent = hasData && item.discount ? (
                                  <span
                                    className={`${cellFontFamily ? '' : 'font-mono'} ${cellFontWeight ? '' : 'text-slate-800'}`}
                                    style={{
                                      color: cellColor,
                                      lineHeight: '1.4',
                                      fontWeight: cellFontWeight,
                                      fontFamily: cellFontFamily,
                                      fontSize: cellFontSize,
                                      fontStyle: cellFontStyle,
                                      textDecoration: cellTextDecoration,
                                    }}
                                  >
                                    {fmt(item.discount)}
                                  </span>
                                ) : (
                                  <span
                                    className={`${cellFontFamily ? '' : 'font-mono'} text-slate-800`}
                                    style={{
                                      color: cellColor,
                                      fontWeight: cellFontWeight,
                                      fontFamily: cellFontFamily,
                                      fontSize: cellFontSize,
                                      fontStyle: cellFontStyle,
                                      textDecoration: cellTextDecoration,
                                    }}
                                  >
                                    0
                                  </span>
                                );
                              } else if (colKey === 'tax') {
                                cellContent = hasData ? (
                                  <span
                                    className={`${cellFontFamily ? '' : 'font-mono'} ${cellFontWeight ? '' : 'text-slate-800'}`}
                                    style={{
                                      color: cellColor,
                                      lineHeight: '1.4',
                                      fontWeight: cellFontWeight,
                                      fontFamily: cellFontFamily,
                                      fontSize: cellFontSize,
                                      fontStyle: cellFontStyle,
                                      textDecoration: cellTextDecoration,
                                    }}
                                  >
                                    {taxRateDisplay}
                                  </span>
                                ) : '';
                              } else if (colKey === 'totalAmount') {
                                cellContent = hasData && item.totalAmount >= 0 ? (
                                  <span
                                    className={`${cellFontFamily ? '' : 'font-mono'} ${cellFontWeight ? '' : 'text-slate-900 font-bold'}`}
                                    style={{
                                      color: cellColor,
                                      lineHeight: '1.4',
                                      fontWeight: cellFontWeight,
                                      fontFamily: cellFontFamily,
                                      fontSize: cellFontSize,
                                      fontStyle: cellFontStyle,
                                      textDecoration: cellTextDecoration,
                                    }}
                                  >
                                    {fmt(item.totalAmount)}
                                  </span>
                                ) : '';
                              }

                              return (
                                <td
                                  key={colKey}
                                  {...getInteractive(colElementKey, `Column: ${colConfig?.label || String(colKey)}`)}
                                  className={`border-r last:border-r-0 relative ${getInteractive(colElementKey, `Column: ${colConfig?.label || String(colKey)}`).className || ''}`}
                                  style={{
                                    borderRightColor: colConfig?.borderColor || design.itemsTable.borderColor || skyBorder,
                                    borderRightWidth: colConfig?.borderWidth !== undefined ? `${colConfig.borderWidth}px` : undefined,
                                    borderRightStyle: colConfig?.borderStyle || undefined,
                                    backgroundColor: colConfig?.backgroundColor || undefined,
                                    textAlign: colConfig?.align || (isNumeric ? 'right' : isCenter ? 'center' : 'left'),
                                    verticalAlign: 'middle',
                                    lineHeight: '1.4',
                                    boxSizing: 'border-box',
                                    paddingTop: `${colConfig?.padding ?? tablePadding}px`,
                                    paddingBottom: `${colConfig?.padding ?? tablePadding}px`,
                                    paddingLeft: `${Math.round((colConfig?.padding ?? tablePadding) * 2.5)}px`,
                                    paddingRight: `${Math.round((colConfig?.padding ?? tablePadding) * 2.5)}px`,
                                    fontFamily: cellFontFamily,
                                    fontSize: cellFontSize,
                                    fontWeight: cellFontWeight,
                                    fontStyle: cellFontStyle,
                                    textDecoration: cellTextDecoration,
                                    color: cellColor,
                                  }}
                                >
                                  {cellContent}
                                </td>
                              );
                            })}
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              ) : (
                <div id="invoice-items-table-section" data-section="invoice-items-table" style={{ display: 'none' }} />
              )}

              {/* ================= 5. PAYMENT INFORMATION (Final Page, Right-Aligned 50% Width) ================= */}
              {isLastPage && (design.payment.show || design.visibility.total) ? (
                <div
                  id="invoice-payment-totals-section"
                  data-section="invoice-payment-totals"
                  className="w-full flex justify-end"
                  style={{
                    width: '100%',
                    boxSizing: 'border-box',
                    marginBottom: `${design.spacing.totalsToNotes ?? (design.spacing as any).totalsToNotesSpacing ?? design.spacing.totalsSpacing ?? design.spacing.sectionSpacing ?? 10}px`,
                  }}
                >
                  {/* Right: Payment Information Table (approx 50% width) */}
                  {design.payment.show ? (
                    <div
                      id="invoice-payment-info-section"
                      data-section="invoice-payment-info"
                      {...getInteractive('paymentInfo', 'Payment Details')}
                      className={`w-[50%] min-w-[260px] flex flex-col justify-start rounded border shadow-2xs overflow-hidden ${getInteractive('paymentInfo', 'Payment Details').className || ''}`}
                      style={{
                        width: '50%',
                        boxSizing: 'border-box',
                        borderColor: design.payment.borderColor || skyBorder,
                        backgroundColor: design.payment.backgroundColor || design.colors.background || '#FFFFFF',
                        fontFamily: design.payment.fontFamily || design.typography.fontFamily || 'Inter, system-ui, sans-serif',
                      }}
                    >
                      {renderBadge('paymentInfo', 'Payment Details')}
                      {/* Payment Information Header Bar */}
                      <div
                        {...getInteractive('tableHeader', 'Table Header')}
                        className={`flex items-center gap-1.5 py-1 px-2.5 border-b shrink-0 ${getInteractive('tableHeader', 'Table Header').className || ''}`}
                        style={{
                          backgroundColor: tableHeaderBg,
                          borderColor: design.payment.borderColor || '#E2E8F0',
                        }}
                      >
                        <svg
                          viewBox="0 0 24 24"
                          className="w-3.5 h-3.5 fill-current shrink-0"
                          style={{ color: tableHeaderTextColor }}
                        >
                          <path d="M20 4H4c-1.11 0-1.99.89-1.99 2L2 18c0 1.11.89 2 2 2h16c1.11 0 2-.89 2-2V6c0-1.11-.89-2-2-2zm0 14H4v-6h16v6zm0-10H4V6h16v2z" />
                        </svg>
                        <span
                          className="font-bold tracking-wide uppercase text-[10px]"
                          style={{
                            color: tableHeaderTextColor,
                            fontSize: `${sectionHeadingFontSize}px`,
                            lineHeight: design.typography.lineHeight || 1.4,
                            fontFamily: design.payment.fontFamily || design.typography.fontFamily || 'Inter, system-ui, sans-serif',
                          }}
                        >
                          Payment Information
                        </span>
                      </div>

                      <div
                        className="space-y-1.5"
                        style={{
                          padding: `${design.spacing.internalPadding ?? 8}px`,
                          fontSize: `${design.payment.fontSize || baseFontSize}px`,
                          lineHeight: design.typography.lineHeight || 1.4,
                          fontFamily: design.payment.fontFamily || design.typography.fontFamily || 'Inter, system-ui, sans-serif',
                          fontStyle: design.payment.italic ? 'italic' : 'normal',
                          textDecoration: design.payment.underline ? 'underline' : 'none',
                        }}
                      >
                        {/* 1. Total */}
                        <div
                          className="flex items-center justify-between gap-2 min-w-0 min-h-[22px] relative rounded-xs px-1"
                        >
                          <span className="font-bold shrink-0" style={{
                            color: design.payment.textColor || deepNavy,
                            lineHeight: design.typography.lineHeight || 1.4,
                          }}>
                            {design.payment.totalLabel || 'Total:'}
                          </span>
                          <span className="font-mono text-slate-900 font-bold text-right break-words flex-1 min-w-0" style={{
                            color: design.payment.textColor || undefined,
                            lineHeight: design.typography.lineHeight || 1.4,
                          }}>
                            {fmt(doc.totalPrice)}
                          </span>
                        </div>

                        {/* 2. Received */}
                        {design.payment.showPaid !== false && (
                          <div
                            {...getInteractive('paidAmount', 'Paid Amount')}
                            className={`flex items-center justify-between gap-2 min-w-0 min-h-[22px] relative rounded-xs px-1 ${getInteractive('paidAmount', 'Paid Amount').className || ''}`}
                            style={{
                              fontFamily: design.payment.paidFontFamily || undefined,
                              fontSize: design.payment.paidFontSize ? `${design.payment.paidFontSize}px` : undefined,
                              fontStyle: design.payment.paidItalic ? 'italic' : undefined,
                              textDecoration: design.payment.paidUnderline ? 'underline' : undefined,
                            }}
                          >
                            {renderBadge('paidAmount', 'Paid Amount')}
                            <span className="font-bold shrink-0" style={{
                              color: design.payment.paidColor || design.payment.textColor || deepNavy,
                              fontWeight: design.payment.paidFontWeight || 'bold',
                              lineHeight: design.typography.lineHeight || 1.4,
                            }}>
                              {design.payment.paidLabel || 'Received:'}
                            </span>
                            <span className="font-mono text-slate-800 font-semibold text-right break-words flex-1 min-w-0" style={{
                              color: design.payment.paidValueColor || design.payment.textColor || undefined,
                              lineHeight: design.typography.lineHeight || 1.4,
                            }}>
                              {fmt(doc.totalPaid)}
                            </span>
                          </div>
                        )}

                        {/* 3. Remaining */}
                        {design.payment.showRemaining !== false && (
                          <div
                            {...getInteractive('remainingAmount', 'Remaining Amount')}
                            className={`flex items-center justify-between gap-2 min-w-0 min-h-[22px] relative rounded-xs px-1 ${getInteractive('remainingAmount', 'Remaining Amount').className || ''}`}
                            style={{
                              fontFamily: design.payment.remainingFontFamily || undefined,
                              fontSize: design.payment.remainingFontSize ? `${design.payment.remainingFontSize}px` : undefined,
                              fontStyle: design.payment.remainingItalic ? 'italic' : undefined,
                              textDecoration: design.payment.remainingUnderline ? 'underline' : undefined,
                            }}
                          >
                            {renderBadge('remainingAmount', 'Remaining Amount')}
                            <span className="font-bold shrink-0" style={{
                              color: design.payment.remainingColor || design.payment.textColor || deepNavy,
                              fontWeight: design.payment.remainingFontWeight || 'bold',
                              lineHeight: design.typography.lineHeight || 1.4,
                            }}>
                              {design.payment.remainingLabel || 'Remaining:'}
                            </span>
                            <span className="font-mono text-slate-800 font-semibold text-right break-words flex-1 min-w-0" style={{
                              color: design.payment.remainingValueColor || design.payment.textColor || undefined,
                              lineHeight: design.typography.lineHeight || 1.4,
                            }}>
                              {fmt(doc.remainingBalance)}
                            </span>
                          </div>
                        )}

                        {/* 4. Payment Status */}
                        {design.payment.showPaymentStatusBadge !== false && (
                          <div
                            {...getInteractive('paymentStatus', 'Payment Status')}
                            className={`flex items-center justify-between gap-2 min-w-0 min-h-[22px] relative rounded-xs px-1 ${getInteractive('paymentStatus', 'Payment Status').className || ''}`}
                            style={{
                              fontFamily: design.payment.statusFontFamily || undefined,
                              fontSize: design.payment.statusFontSize ? `${design.payment.statusFontSize}px` : undefined,
                              fontStyle: design.payment.statusItalic ? 'italic' : undefined,
                              textDecoration: design.payment.statusUnderline ? 'underline' : undefined,
                            }}
                          >
                            {renderBadge('paymentStatus', 'Payment Status')}
                            <span className="font-bold shrink-0" style={{
                              color: design.payment.statusColor || design.payment.textColor || deepNavy,
                              fontWeight: design.payment.statusFontWeight || 'bold',
                              lineHeight: design.typography.lineHeight || 1.4,
                            }}>
                              {design.payment.statusLabel || 'Payment Status:'}
                            </span>
                            <span className="text-slate-800 font-medium text-right break-words flex-1 min-w-0" style={{
                              color: design.payment.statusValueColor || design.payment.textColor || undefined,
                              lineHeight: design.typography.lineHeight || 1.4,
                            }}>
                              {doc.status || 'Paid'}
                            </span>
                          </div>
                        )}
                      </div>
                    </div>
                  ) : (
                    <div id="invoice-payment-info-section" data-section="invoice-payment-info" />
                  )}
                </div>
              ) : isLastPage ? (
                <div id="invoice-payment-totals-section" data-section="invoice-payment-totals" style={{ display: 'none' }} />
              ) : null}

              {/* ================= 6. NOTES SECTION ================= */}
              {isLastPage && design.visibility.notes && design.notes.showInvoiceNote ? (
                <div
                  id="invoice-notes-section"
                  data-section="invoice-notes"
                  {...getInteractive('notes', 'Notes & Terms')}
                  className={`w-full rounded shadow-2xs ${getInteractive('notes', 'Notes & Terms').className || ''}`}
                  style={{
                    backgroundColor: design.notes.invoiceNoteBgColor || '#F8FAFC',
                    borderWidth: design.notes.invoiceNoteBorder !== false ? '1px' : '0px',
                    borderStyle: design.notes.invoiceNoteBorder !== false ? 'solid' : 'none',
                    borderColor: design.notes.invoiceNoteBorder !== false ? (design.notes.borderColor || skyBorder) : 'transparent',
                    padding: `${design.spacing.internalPadding ?? 8}px`,
                    width: '100%',
                    boxSizing: 'border-box',
                    marginBottom: `${design.spacing.notesToSignatures ?? (design.spacing as any).notesToSignaturesSpacing ?? design.spacing.sectionSpacing ?? 10}px`,
                  }}
                >
                  {renderBadge('notes', 'Notes & Terms')}
                  <div className="flex items-center gap-1.5 mb-1">
                    <svg
                      viewBox="0 0 24 24"
                      className="w-3.5 h-3.5 fill-current shrink-0"
                      style={{ color: royalBlue }}
                    >
                      <path d="M14 2H6c-1.1 0-1.99.9-1.99 2L4 20c0 1.1.89 2 1.99 2H18c1.1 0 2-.89 2-2V8l-6-6zm2 16H8v-2h8v2zm0-4H8v-2h8v2zm-3-5V3.5L18.5 9H13z" />
                    </svg>
                    <span className="font-bold" style={{ color: royalBlue, fontSize: `${design.typography.sectionHeadingFontSize || 11}px`, lineHeight: '1.4' }}>
                      {design.notes.notesLabel || 'Notes:'}
                    </span>
                  </div>
                  <div
                    className="text-slate-700 pl-5 leading-relaxed break-words min-w-0"
                    style={{
                      color: design.notes.invoiceNoteColor || '#334155',
                      fontSize: `${design.notes.invoiceNoteFontSize || 10.5}px`,
                      fontFamily: design.notes.invoiceNoteFontFamily || fontFamily,
                      textAlign: design.notes.invoiceNoteAlign || 'left',
                      direction: design.notes.invoiceNoteDirection || 'ltr',
                      lineHeight: '1.4',
                    }}
                  >
                    {doc.note || design.notes.invoiceNoteText || 'Thank you for your business. Please contact us if you have any questions regarding this invoice.'}
                  </div>
                </div>
              ) : isLastPage ? (
                <div id="invoice-notes-section" data-section="invoice-notes" style={{ display: 'none' }} />
              ) : null}

              {/* ================= 7. SIGNATURES SECTION ================= */}
              {isLastPage && design.visibility.signatures && design.signatures.show ? (
                <div
                  id="invoice-signatures-section"
                  data-section="invoice-signatures"
                  {...getInteractive('signatures', 'Signatures')}
                  className={`w-full grid grid-cols-2 gap-12 mt-2 mb-2 ${getInteractive('signatures', 'Signatures').className || ''}`}
                  style={{ width: '100%', boxSizing: 'border-box' }}
                >
                  {renderBadge('signatures', 'Signatures')}
                  {/* Left: Customer Signature */}
                  {design.signatures.showCustomerSignature ? (
                    <div
                      {...getInteractive('signatureCustomer', 'Customer Signature')}
                      className={`flex flex-col items-center justify-end ${getInteractive('signatureCustomer', 'Customer Signature').className || ''}`}
                      style={{
                        fontFamily: design.signatures.customerFontFamily || design.signatures.fontFamily || design.typography.fontFamily || 'Inter, system-ui, sans-serif',
                      }}
                    >
                      {renderBadge('signatureCustomer', 'Customer Signature')}
                      <div
                        className={`border-b pb-0.5 flex items-end justify-center ${(design.signatures.customerSignatureStyle || design.signatures.signatureStyle) === 'dotted_line' ? 'border-dashed' : 'border-solid'}`}
                        style={{
                          borderColor: design.signatures.customerBorderColor || design.signatures.borderColor || royalBlue,
                          width: design.signatures.customerWidth || (design.signatures.width && design.signatures.width !== '100%' ? design.signatures.width : '180px'),
                          minHeight: `${design.signatures.customerHeight || design.signatures.height || 28}px`,
                        }}
                      >
                        {design.signatures.customerSignatureImage && (
                          <img
                            src={design.signatures.customerSignatureImage}
                            alt="Customer Signature"
                            className="object-contain"
                            style={{ maxHeight: `${Math.max(24, (design.signatures.customerHeight || design.signatures.height || 40) - 8)}px` }}
                          />
                        )}
                      </div>
                      <span
                        className="font-bold text-center mt-1.5 leading-snug"
                        style={{
                          color: design.signatures.customerColor || design.signatures.color || deepNavy,
                          fontSize: `${design.signatures.customerFontSize || design.signatures.fontSize || Math.min(12, baseFontSize)}px`,
                          fontWeight: design.signatures.customerFontWeight || design.signatures.fontWeight || 'bold',
                          fontStyle: design.signatures.italic ? 'italic' : 'normal',
                          textDecoration: design.signatures.underline ? 'underline' : 'none',
                          lineHeight: design.typography.lineHeight || 1.4,
                        }}
                      >
                        {design.signatures.customerSignatureLabel || 'Customer Signature'}
                      </span>
                    </div>
                  ) : (
                    <div />
                  )}

                  {/* Right: Collector / Manager Signature */}
                  {design.signatures.showManagerSignature ? (
                    <div
                      {...getInteractive('signatureAuthorized', 'Authorized Signature')}
                      className={`flex flex-col items-center justify-end ${getInteractive('signatureAuthorized', 'Authorized Signature').className || ''}`}
                      style={{
                        fontFamily: design.signatures.managerFontFamily || design.signatures.fontFamily || design.typography.fontFamily || 'Inter, system-ui, sans-serif',
                      }}
                    >
                      {renderBadge('signatureAuthorized', 'Authorized Signature')}
                      <div
                        className={`border-b pb-0.5 flex items-end justify-center ${(design.signatures.managerSignatureStyle || design.signatures.signatureStyle) === 'dotted_line' ? 'border-dashed' : 'border-solid'}`}
                        style={{
                          borderColor: design.signatures.managerBorderColor || design.signatures.borderColor || royalBlue,
                          width: design.signatures.managerWidth || (design.signatures.width && design.signatures.width !== '100%' ? design.signatures.width : '180px'),
                          minHeight: `${design.signatures.managerHeight || design.signatures.height || 28}px`,
                        }}
                      >
                        {design.signatures.managerSignatureImage && (
                          <img
                            src={design.signatures.managerSignatureImage}
                            alt="Manager Signature"
                            className="object-contain"
                            style={{ maxHeight: `${Math.max(24, (design.signatures.managerHeight || design.signatures.height || 40) - 8)}px` }}
                          />
                        )}
                      </div>
                      <span
                        className="font-bold text-center mt-1.5 leading-snug"
                        style={{
                          color: design.signatures.managerColor || design.signatures.color || deepNavy,
                          fontSize: `${design.signatures.managerFontSize || design.signatures.fontSize || Math.min(12, baseFontSize)}px`,
                          fontWeight: design.signatures.managerFontWeight || design.signatures.fontWeight || 'bold',
                          fontStyle: design.signatures.italic ? 'italic' : 'normal',
                          textDecoration: design.signatures.underline ? 'underline' : 'none',
                          lineHeight: design.typography.lineHeight || 1.4,
                        }}
                      >
                        {design.signatures.managerSignatureLabel || 'Collector Signature'}
                      </span>
                    </div>
                  ) : (
                    <div />
                  )}
                </div>
              ) : isLastPage ? (
                <div id="invoice-signatures-section" data-section="invoice-signatures" style={{ display: 'none' }} />
              ) : null}
            </div>

            {/* ================= 8. FOOTER SECTION ================= */}
            {/* Matching reference: Deep navy angled bottom bar with gold accent line or flexible contained boxed footer */}
            {design.visibility.footer && design.footer.show ? (
              <div
                id="invoice-footer-section"
                data-section="invoice-footer"
                {...getInteractive('footer', 'Footer Banner')}
                className={`w-full mt-auto relative z-10 ${getInteractive('footer', 'Footer Banner').className || ''}`}
                style={{
                  width: design.footer.layoutMode === 'contained'
                    ? '100%'
                    : `calc(100% + ${(paperConfig.marginLeftMm ?? 12) + (paperConfig.marginRightMm ?? 12)}mm)`,
                  marginTop: 'auto',
                  marginRight: design.footer.layoutMode === 'contained' ? '0px' : `-${paperConfig.marginRightMm ?? 12}mm`,
                  marginBottom: design.footer.layoutMode === 'contained' ? '0px' : `-${paperConfig.marginBottomMm ?? 12}mm`,
                  marginLeft: design.footer.layoutMode === 'contained' ? '0px' : `-${paperConfig.marginLeftMm ?? 12}mm`,
                  boxSizing: 'border-box',
                }}
              >
                {renderBadge('footer', 'Footer Banner')}
                <div
                  className="w-full relative overflow-hidden"
                  style={{
                    backgroundColor: design.footer.backgroundColor || footerBgColor,
                    borderTopWidth: (design.footer.layoutMode !== 'contained' && design.footer.borderTop === false) || (design.footer.borderStyle || 'solid') === 'none'
                      ? '0px'
                      : `${design.footer.borderWidth ?? (design.footer.layoutMode === 'contained' ? 1 : 2.5)}px`,
                    borderRightWidth: design.footer.layoutMode === 'contained' && (design.footer.borderStyle || 'solid') !== 'none'
                      ? `${design.footer.borderWidth ?? 1}px`
                      : '0px',
                    borderBottomWidth: design.footer.layoutMode === 'contained' && (design.footer.borderStyle || 'solid') !== 'none'
                      ? `${design.footer.borderWidth ?? 1}px`
                      : '0px',
                    borderLeftWidth: design.footer.layoutMode === 'contained' && (design.footer.borderStyle || 'solid') !== 'none'
                      ? `${design.footer.borderWidth ?? 1}px`
                      : '0px',
                    borderStyle: (design.footer.borderStyle || 'solid') as any,
                    borderColor: (design.footer.borderStyle || 'solid') === 'none'
                      ? 'transparent'
                      : (design.footer.borderColor || footerAccentColor),
                    borderRadius: design.footer.borderRadius !== undefined
                      ? `${design.footer.borderRadius}px`
                      : (design.footer.layoutMode === 'contained' ? '6px' : '0px'),
                    paddingTop: `${design.footer.topSpacing ?? design.footer.paddingTop ?? 8}px`,
                    paddingBottom: `${design.footer.bottomSpacing ?? design.footer.paddingBottom ?? 8}px`,
                    paddingLeft: `${design.footer.paddingLeft ?? design.footer.padding ?? 40}px`,
                    paddingRight: `${design.footer.paddingRight ?? design.footer.padding ?? 40}px`,
                    minHeight: (design.footer as any).height ? `${(design.footer as any).height}px` : undefined,
                    boxSizing: 'border-box',
                  }}
                >
                  {/* Dynamic Reorderable Footer Elements (Thank You, Contacts, Page Number) */}
                  {footerElementsOrder.map((elementKey, index) => {
                    if (elementKey === 'thankYou') {
                      if (design.footer.showThankYou === false) return null;
                      return (
                        <div
                          key="footerThankYou"
                          {...getInteractive('footerThankYou', 'Footer Thank You Text')}
                          className={`flex items-center justify-center gap-3 relative z-30 ${index > 0 ? 'mt-1.5' : ''} ${getInteractive('footerThankYou', 'Footer Thank You Text').className || ''}`}
                          style={{
                            fontFamily: design.footer.thankYouFontFamily || design.footer.fontFamily || design.typography.fontFamily || 'Inter, system-ui, sans-serif',
                          }}
                        >
                          {renderBadge('footerThankYou', 'Thank You Text')}
                          {design.footer.showAccentLines !== false && (
                            <div
                              className="shrink-0"
                              style={{
                                width: `${design.footer.accentLineWidth || 56}px`,
                                height: `${design.footer.accentLineHeight || 1}px`,
                                backgroundColor: design.footer.accentLineColor || design.footer.accentColor || footerAccentColor,
                              }}
                            />
                          )}
                          <span
                            className="tracking-wide break-words text-center"
                            style={{
                              color: (design.footer as any).thankYouColor || footerTextColor,
                              fontSize: `${(design.footer as any).thankYouFontSize || footerFontSize}px`,
                              fontWeight: (design.footer as any).thankYouFontWeight || footerFontWeight,
                              fontStyle: design.footer.italic !== false ? 'italic' : 'normal',
                              textDecoration: design.footer.underline ? 'underline' : 'none',
                              lineHeight: footerLineHeight,
                            }}
                          >
                            {design.footer.footerText || 'Thank you for your business!'}
                          </span>
                          {design.footer.showAccentLines !== false && (
                            <div
                              className="shrink-0"
                              style={{
                                width: `${design.footer.accentLineWidth || 56}px`,
                                height: `${design.footer.accentLineHeight || 1}px`,
                                backgroundColor: design.footer.accentLineColor || design.footer.accentColor || footerAccentColor,
                              }}
                            />
                          )}
                        </div>
                      );
                    }

                    if (elementKey === 'contacts') {
                      if (!design.visibility.companyInfo) return null;
                      const footerEmail = doc.company.email || (design.company as any)?.email;
                      const footerWhatsapp = doc.company.whatsapp || (design.company as any)?.whatsapp;
                      const footerPhone = doc.company.phone || (design.company as any)?.phone;

                      return (
                        <div
                          key="footerContacts"
                          {...getInteractive('footerContacts', 'Footer Contacts')}
                          className={`${index > 0 ? 'mt-1.5 pt-0.5' : ''} flex flex-wrap items-center justify-center gap-x-4 gap-y-1 font-medium leading-normal break-words text-center relative z-30 ${getInteractive('footerContacts', 'Footer Contacts').className || ''}`}
                          style={{
                            color: (design.footer as any).contactsColor || footerTextColor,
                            fontSize: `${(design.footer as any).contactsFontSize || Math.max(8.5, footerFontSize * 0.88)}px`,
                            lineHeight: footerLineHeight,
                            opacity: 0.95,
                            fontFamily: design.footer.contactsFontFamily || design.footer.fontFamily || design.typography.fontFamily || 'Inter, system-ui, sans-serif',
                          }}
                        >
                          {renderBadge('footerContacts', 'Footer Contacts')}
                          {footerEmail && design.footer.showEmail !== false && (
                            <span>{(design.footer.emailLabel !== undefined && design.footer.emailLabel !== '') ? design.footer.emailLabel : 'Email:'} {footerEmail}</span>
                          )}
                          {footerEmail && design.footer.showEmail !== false && ((footerWhatsapp && design.footer.showWhatsapp !== false) || (footerPhone && design.footer.showPhone !== false)) && (
                            <span aria-hidden="true" className="opacity-40">|</span>
                          )}
                          {footerWhatsapp && design.footer.showWhatsapp !== false && (
                            <span>{(design.footer.whatsappLabel !== undefined && design.footer.whatsappLabel !== '') ? design.footer.whatsappLabel : 'WhatsApp:'} {footerWhatsapp}</span>
                          )}
                          {footerWhatsapp && design.footer.showWhatsapp !== false && (footerPhone && design.footer.showPhone !== false) && (
                            <span aria-hidden="true" className="opacity-40">|</span>
                          )}
                          {footerPhone && design.footer.showPhone !== false && (
                            <span>{(design.footer.phoneLabel !== undefined && design.footer.phoneLabel !== '') ? design.footer.phoneLabel : 'Phone:'} {footerPhone}</span>
                          )}
                        </div>
                      );
                    }

                    if (elementKey === 'pageNumber') {
                      if (!design.visibility.pageNumber || !design.pageNumber.show || (totalPages <= 1 && !isInteractive)) {
                        return null;
                      }
                      return (
                        <div
                          key="pageNumber"
                          {...getInteractive('pageNumber', 'Page Number')}
                          className={`${index > 0 ? 'mt-1' : ''} px-4 relative z-30 ${getInteractive('pageNumber', 'Page Number').className || ''}`}
                          style={{
                            textAlign: design.pageNumber.position === 'bottom_center' ? 'center' : design.pageNumber.position === 'bottom_left' ? 'left' : 'right',
                            fontSize: `${design.pageNumber.fontSize || 9}px`,
                            fontWeight: design.pageNumber.fontWeight || 'normal',
                            fontStyle: design.pageNumber.italic ? 'italic' : 'normal',
                            textDecoration: design.pageNumber.underline ? 'underline' : 'none',
                            fontFamily: design.pageNumber.fontFamily || design.typography.fontFamily || 'monospace',
                            color: design.pageNumber.color || '#94A3B8',
                          }}
                        >
                          {renderBadge('pageNumber', 'Page Number')}
                          {design.pageNumber.format === 'page_x'
                            ? `Page ${pageNumber}`
                            : design.pageNumber.format === 'simple'
                            ? `${pageNumber}/${totalPages}`
                            : `Page ${pageNumber} of ${totalPages}`}
                        </div>
                      );
                    }

                    return null;
                  })}
                </div>
              </div>
            ) : (
              <div id="invoice-footer-section" data-section="invoice-footer" style={{ display: 'none' }} />
            )}
          </div>
        );
      })}
    </div>
  );
};

export default InvoiceTemplate;
