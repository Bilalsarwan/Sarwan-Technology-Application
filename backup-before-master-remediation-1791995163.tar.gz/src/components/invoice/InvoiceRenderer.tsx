import React, { useMemo } from 'react';
import { Invoice, Payment, BusinessSettings, UserProfile } from '../../types';
import { CanonicalInvoiceDocumentModel } from '../../types/canonicalInvoiceDocument';
import { buildCanonicalInvoiceDocument } from '../../utils/canonicalInvoiceDocument';
import { CanonicalInvoiceDocument, CanonicalInvoiceDocumentProps } from './CanonicalInvoiceDocument';

export interface InvoiceRendererProps {
  document?: CanonicalInvoiceDocumentModel;
  invoice?: Invoice;
  payments?: Payment[];
  settings?: Partial<BusinessSettings>;
  userProfile?: UserProfile | null;
  totalPaidOverride?: number;
  id?: string;
  className?: string;
}

/**
 * InvoiceRenderer
 * Canonical component for rendering invoices across the application.
 * Accepts either a pre-built CanonicalInvoiceDocumentModel or raw invoice data with settings.
 */
export const InvoiceRenderer: React.FC<InvoiceRendererProps> = ({
  document: propDoc,
  invoice,
  payments,
  settings,
  userProfile,
  totalPaidOverride,
  id,
  className = '',
}) => {
  const doc = useMemo(() => {
    if (propDoc) return propDoc;
    if (invoice) {
      return buildCanonicalInvoiceDocument({
        invoice,
        payments,
        settings,
        userProfile,
        totalPaidOverride,
      });
    }
    return null;
  }, [propDoc, invoice, payments, settings, userProfile, totalPaidOverride]);

  if (!doc) {
    return null;
  }

  return (
    <CanonicalInvoiceDocument
      document={doc}
      id={id}
      className={className}
    />
  );
};

export default InvoiceRenderer;
