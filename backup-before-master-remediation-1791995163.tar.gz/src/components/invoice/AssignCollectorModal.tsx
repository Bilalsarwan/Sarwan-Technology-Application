import React, { useState, useEffect, useMemo } from 'react';
import { Invoice, UserProfile } from '../../types';
import { formatDate } from '../../utils/format';
import { assignCollectorToInvoice, subscribeToUsers } from '../../services/db';
import { isInvoiceLocked } from '../../utils/invoiceCalculator';
import { useAuth } from '../../context/AuthContext';
import {
  X,
  UserCheck,
  User,
  Clock,
  AlertCircle,
  Loader2,
  History,
  ShieldAlert,
} from 'lucide-react';

interface AssignCollectorModalProps {
  isOpen: boolean;
  onClose: () => void;
  invoice: Invoice | null;
  users?: UserProfile[];
  onAssigned?: () => void;
}

export const AssignCollectorModal: React.FC<AssignCollectorModalProps> = ({
  isOpen,
  onClose,
  invoice,
  users,
  onAssigned,
}) => {
  const { userProfile } = useAuth();
  const [localUsers, setLocalUsers] = useState<UserProfile[]>([]);
  const [selectedCollectorId, setSelectedCollectorId] = useState<string>('');
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [showHistory, setShowHistory] = useState<boolean>(false);

  // Fallback to real-time subscription only if users prop was not provided by parent
  useEffect(() => {
    if (users !== undefined) return;
    const unsub = subscribeToUsers((data) => {
      setLocalUsers(data);
    });
    return () => unsub();
  }, [users]);

  const availableUsers = users && users.length > 0 ? users : localUsers;

  // Active payment collectors only
  const activeCollectors = useMemo(() => {
    return (availableUsers || []).filter(
      (u) =>
        u.role === 'payment_collector' &&
        !u.isDeactivated &&
        u.status !== 'deactivated' &&
        u.status !== 'archived'
    );
  }, [availableUsers]);

  // Reset state when invoice changes or modal opens
  useEffect(() => {
    if (isOpen && invoice) {
      setSelectedCollectorId(invoice.assignedCollectorId || '');
      setShowHistory(false);
      if (isInvoiceLocked(invoice)) {
        setError(
          invoice.assignedCollectorId
            ? 'Cannot change the collector of a locked invoice.'
            : 'Cannot assign a collector to a locked invoice.'
        );
      } else if (invoice.isVoid || invoice.status === 'Void') {
        setError('Cannot assign a collector to a voided invoice.');
      } else {
        setError(null);
      }
    }
  }, [isOpen, invoice]);

  if (!isOpen || !invoice) return null;

  const isSuperAdminOrManager =
    userProfile?.role === 'super_admin' || userProfile?.role === 'invoice_manager';

  const isCurrentlyAssigned = Boolean(invoice.assignedCollectorId);
  const isVoid = Boolean(invoice.isVoid || invoice.status === 'Void');
  const isLocked = isInvoiceLocked(invoice);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!invoice) return;

    if (!isSuperAdminOrManager) {
      setError('Access Denied: Only Super Admin and Invoice Manager can assign collectors.');
      return;
    }

    if (isVoid) {
      setError('Cannot assign a collector to a voided invoice.');
      return;
    }

    if (isLocked) {
      setError(
        isCurrentlyAssigned
          ? 'Cannot change the collector of a locked invoice.'
          : 'Cannot assign a collector to a locked invoice.'
      );
      return;
    }

    if (!selectedCollectorId) {
      setError('Please select a payment collector from the list.');
      return;
    }

    if (isCurrentlyAssigned && selectedCollectorId === invoice.assignedCollectorId) {
      setError('This invoice is already assigned to the selected collector. Please select a different collector to reassign, or cancel.');
      return;
    }

    const collector = activeCollectors.find((c) => c.id === selectedCollectorId);
    if (!collector) {
      setError('Selected collector could not be found. Please choose an active collector.');
      return;
    }

    setIsSubmitting(true);
    setError(null);

    try {
      await assignCollectorToInvoice(
        invoice.id,
        collector.id,
        collector.name,
        userProfile?.id || '',
        userProfile?.name || 'Staff',
        invoice.assignedCollectorId,
        invoice.assignedCollectorName,
        invoice.assignmentHistory || []
      );

      if (onAssigned) {
        onAssigned();
      }
      onClose();
    } catch (err: any) {
      console.error('Error assigning collector:', err);
      setError(err?.message || 'Failed to assign collector. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs overflow-y-auto">
      <div className="bg-[var(--app-surface-modal,#FFFFFF)] text-[var(--app-text-primary,#0F172A)] rounded-xl shadow-2xl w-full max-w-lg overflow-hidden border border-[var(--app-border,#E2E8F0)]">
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-neutral-200 bg-neutral-900 text-white">
          <div className="flex items-center gap-2.5">
            <div className="p-1.5 bg-neutral-800 rounded-lg border border-neutral-700">
              <UserCheck className="w-4 h-4 text-orange-400" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-white">
                {isCurrentlyAssigned ? 'Reassign Collector' : 'Assign Collector'}
              </h3>
              <p className="text-[11px] text-neutral-400">
                Invoice <span className="font-mono font-bold text-orange-400">#{invoice.billNumber}</span>
                {invoice.customerSnapshot?.name ? ` • ${invoice.customerSnapshot.name}` : ''}
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1 rounded-lg text-neutral-400 hover:text-white hover:bg-neutral-800 transition cursor-pointer"
            title="Close"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        {!isSuperAdminOrManager ? (
          <div className="p-6 text-center space-y-3">
            <ShieldAlert className="w-10 h-10 text-rose-500 mx-auto" />
            <h4 className="text-sm font-bold text-neutral-900">Unauthorized Action</h4>
            <p className="text-xs text-neutral-500">
              Only users with Super Admin or Invoice Manager roles are permitted to assign or reassign collectors.
            </p>
            <div className="pt-2">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-1.5 text-xs font-semibold bg-neutral-900 text-white rounded-lg"
              >
                Close
              </button>
            </div>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="p-5 space-y-4">
            {error && (
              <div className="p-3 bg-rose-50 border border-rose-200 text-rose-700 text-xs rounded-lg flex items-start gap-2">
                <AlertCircle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
                <div className="flex-1">{error}</div>
              </div>
            )}

            {isVoid && (
              <div className="p-3 bg-neutral-100 border border-neutral-300 text-neutral-700 text-xs rounded-lg">
                This invoice is void. Collectors cannot be assigned to voided invoices.
              </div>
            )}

            {isLocked && (
              <div className="p-3 bg-amber-50 border border-amber-200 text-amber-800 text-xs rounded-lg flex items-start gap-2">
                <AlertCircle className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
                <div className="flex-1">
                  {isCurrentlyAssigned
                    ? 'Cannot change the collector of a locked invoice.'
                    : 'Cannot assign a collector to a locked invoice.'}
                </div>
              </div>
            )}

            {/* Current Assignment Status Box */}
            <div className="bg-neutral-50 border border-neutral-200 rounded-lg p-3 text-xs">
              <span className="text-[10px] font-bold uppercase tracking-wider text-neutral-500 block mb-1">
                Current Status
              </span>
              {isCurrentlyAssigned ? (
                <div className="space-y-1">
                  <div className="flex items-center justify-between">
                    <span className="text-neutral-600">Assigned Collector:</span>
                    <span className="font-bold text-neutral-900 flex items-center gap-1">
                      <User className="w-3.5 h-3.5 text-orange-500" />
                      {invoice.assignedCollectorName}
                    </span>
                  </div>
                  {invoice.assignedAt && (
                    <div className="flex items-center justify-between text-[11px] text-neutral-500">
                      <span>Assigned On:</span>
                      <span className="font-mono">{formatDate(invoice.assignedAt)}</span>
                    </div>
                  )}
                  {invoice.assignedByName && (
                    <div className="flex items-center justify-between text-[11px] text-neutral-500">
                      <span>Assigned By:</span>
                      <span>{invoice.assignedByName}</span>
                    </div>
                  )}
                </div>
              ) : (
                <p className="text-neutral-500 italic">
                  Currently Unassigned. No payment collector is assigned to this invoice.
                </p>
              )}
            </div>

            {/* Collector Selection Field */}
            <div>
              <label className="block text-xs font-semibold text-neutral-700 mb-1.5">
                {isCurrentlyAssigned ? 'Select New Payment Collector *' : 'Select Payment Collector *'}
              </label>

              {activeCollectors.length === 0 ? (
                <div className="p-3 bg-amber-50 border border-amber-200 rounded-lg text-xs text-amber-800">
                  No active payment collectors found in the system. Create or activate a user with the role <span className="font-semibold font-mono">Payment Collector</span> first.
                </div>
              ) : (
                <select
                  value={selectedCollectorId ?? ''}
                  onChange={(e) => setSelectedCollectorId(e.target.value)}
                  disabled={isSubmitting || isVoid || isLocked}
                  className="w-full text-xs border border-neutral-300 rounded-lg px-3 py-2 bg-white focus:outline-none focus:ring-1 focus:ring-orange-500 disabled:bg-neutral-100 disabled:cursor-not-allowed cursor-pointer"
                  required
                >
                  <option value="">-- Choose a Payment Collector --</option>
                  {activeCollectors.map((collector) => (
                    <option key={collector.id} value={collector.id}>
                      {collector.name} {collector.phone ? `(${collector.phone})` : ''}
                      {collector.id === invoice.assignedCollectorId ? ' [Current Collector]' : ''}
                    </option>
                  ))}
                </select>
              )}
              <p className="text-[11px] text-neutral-400 mt-1">
                Only active users with the Payment Collector role appear in this list.
              </p>
            </div>

            {/* Assignment History Section */}
            {invoice.assignmentHistory && invoice.assignmentHistory.length > 0 && (
              <div className="border-t border-neutral-200 pt-3">
                <button
                  type="button"
                  onClick={() => setShowHistory(!showHistory)}
                  className="w-full flex items-center justify-between text-xs font-semibold text-neutral-700 hover:text-neutral-900 cursor-pointer"
                >
                  <span className="flex items-center gap-1.5">
                    <History className="w-3.5 h-3.5 text-neutral-500" />
                    Previous Assignment History ({invoice.assignmentHistory.length})
                  </span>
                  <span className="text-[11px] text-orange-600 underline">
                    {showHistory ? 'Hide' : 'Show'}
                  </span>
                </button>

                {showHistory && (
                  <div className="mt-2.5 max-h-36 overflow-y-auto space-y-1.5 border border-neutral-200 rounded-lg p-2.5 bg-neutral-50">
                    {invoice.assignmentHistory.map((entry, idx) => (
                      <div
                        key={idx}
                        className="text-[11px] text-neutral-600 pb-1.5 border-b border-neutral-200 last:border-0 last:pb-0"
                      >
                        <div className="flex items-center justify-between font-medium text-neutral-800">
                          <span className="flex items-center gap-1">
                            <User className="w-3 h-3 text-neutral-400" />
                            {entry.collectorName}
                          </span>
                          <span className="text-neutral-400 font-mono text-[10px]">
                            {formatDate(entry.assignedAt)}
                          </span>
                        </div>
                        {entry.previousCollectorName && (
                          <p className="text-[10px] text-neutral-500 mt-0.5">
                            Reassigned from: <span className="font-semibold">{entry.previousCollectorName}</span>
                          </p>
                        )}
                        {entry.assignedByName && (
                          <p className="text-[10px] text-neutral-400">
                            By: {entry.assignedByName}
                          </p>
                        )}
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}

            {/* Modal Actions */}
            <div className="flex items-center justify-end gap-2 pt-2 border-t border-[var(--app-border-subtle,#E2E8F0)]">
              <button
                type="button"
                onClick={onClose}
                disabled={isSubmitting}
                className="px-3.5 py-1.5 text-xs font-semibold text-[var(--app-text-secondary,#475569)] hover:text-[var(--app-text-primary,#0F172A)] bg-[var(--app-surface-card,#FFFFFF)] hover:bg-[var(--color-interactive-hover,#F1F5F9)] border border-[var(--app-border,#CBD5E1)] rounded-lg transition disabled:opacity-50 cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={isSubmitting || isLocked || !selectedCollectorId || isVoid || activeCollectors.length === 0}
                className="px-4 py-1.5 text-xs font-bold text-white bg-[var(--color-primary,#2563EB)] hover:bg-[var(--color-primary-hover,#1D4ED8)] active:bg-[var(--color-primary-active,#1E40AF)] rounded-lg transition inline-flex items-center gap-1.5 shadow-xs active:scale-98 disabled:opacity-50 disabled:cursor-not-allowed cursor-pointer focus:outline-none focus-visible:ring-2 focus-visible:ring-[var(--color-primary,#2563EB)]"
              >
                {isSubmitting ? (
                  <>
                    <Loader2 className="w-3.5 h-3.5 animate-spin" />
                    Saving...
                  </>
                ) : (
                  <>
                    <UserCheck className="w-3.5 h-3.5" />
                    {isCurrentlyAssigned ? 'Reassign Collector' : 'Assign Collector'}
                  </>
                )}
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
};
