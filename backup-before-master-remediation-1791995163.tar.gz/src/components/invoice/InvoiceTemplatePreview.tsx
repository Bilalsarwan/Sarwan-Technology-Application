import React, { useMemo, useState, useRef, useEffect, useCallback } from 'react';
import { Invoice, Payment, BusinessSettings, InvoiceItem, CustomerSnapshot, CompanySnapshot } from '../../types';
import { InvoiceDesignSettings, DesignerElement } from '../../types/invoiceDesign';
import { buildCanonicalInvoiceDocument } from '../../utils/canonicalInvoiceDocument';
import { formatInvoiceNumber } from '../../utils/format';
import { InvoiceTemplate } from './InvoiceTemplate';
import { ZoomIn, ZoomOut, Maximize2, RotateCcw } from 'lucide-react';

export interface InvoiceTemplatePreviewProps {
  design: InvoiceDesignSettings;
  invoice?: Invoice | null;
  payments?: Payment[];
  settings?: BusinessSettings;
  zoom?: number;
  onZoomChange?: (zoom: number) => void;
  isFitMode?: boolean;
  onFitModeChange?: (isFit: boolean) => void;
  showControls?: boolean;
  className?: string;
  selectedElement?: DesignerElement | null;
  onSelectElement?: (element: DesignerElement | null) => void;
  isInteractive?: boolean;
  sourceToggle?: {
    source: 'sample' | 'real';
    onSourceChange: (source: 'sample' | 'real') => void;
    realInvoices?: Invoice[];
    selectedRealInvoiceId?: string;
    onSelectRealInvoice?: (id: string) => void;
  };
}

// Authentic Sarwan Technology CCTV security sample items for realistic preview
const SAMPLE_INVOICE_ITEMS: InvoiceItem[] = [
  { sNo: 1, description: '5MP HD Outdoor IR Bullet Camera (Dahua IPC-HFW)', quantity: 4, unitPrice: 2400, totalAmount: 9600 },
  { sNo: 2, description: '8-Channel 4K Network Video Recorder (NVR)', quantity: 1, unitPrice: 8500, totalAmount: 8500 },
  { sNo: 3, description: '2TB Surveillance Hard Drive (WD Purple)', quantity: 1, unitPrice: 4200, totalAmount: 4200 },
  { sNo: 4, description: '12V 10A Centralized Power Supply Box', quantity: 1, unitPrice: 1600, totalAmount: 1600 },
  { sNo: 5, description: 'Cat6 Pure Copper Network Cable (Roll 100m)', quantity: 2, unitPrice: 1800, totalAmount: 3600 },
  { sNo: 6, description: 'RJ45 Connectors & Waterproof Junction Boxes', quantity: 8, unitPrice: 120, totalAmount: 960 },
  { sNo: 7, description: 'System Installation, Wiring & Configuration', quantity: 1, unitPrice: 3500, totalAmount: 3500 },
];

export const InvoiceTemplatePreview: React.FC<InvoiceTemplatePreviewProps> = ({
  design,
  invoice: propInvoice,
  payments = [],
  settings,
  zoom: propZoom,
  onZoomChange,
  isFitMode: propIsFitMode,
  onFitModeChange,
  showControls = true,
  className = '',
  selectedElement,
  onSelectElement,
  isInteractive = false,
  sourceToggle,
}) => {
  // Fit to screen mode state
  const [internalIsFitMode, setInternalIsFitMode] = useState<boolean>(true);
  const isFit = propIsFitMode !== undefined ? propIsFitMode : internalIsFitMode;

  const [internalZoom, setInternalZoom] = useState<number>(0.85);
  const [calculatedFitZoom, setCalculatedFitZoom] = useState<number>(0.85);

  // Viewport dimensions measured from containerRef
  const [viewportDims, setViewportDims] = useState<{ width: number; height: number }>({
    width: 800,
    height: 1000,
  });

  const containerRef = useRef<HTMLDivElement>(null);
  const innerDocRef = useRef<HTMLDivElement>(null);

  // Active zoom scale: if in Fit mode, use dynamically calculated fit scale; otherwise use manual/prop zoom
  const activeZoom = isFit ? calculatedFitZoom : (propZoom !== undefined ? propZoom : internalZoom);

  const setFitState = (fit: boolean) => {
    if (onFitModeChange) {
      onFitModeChange(fit);
    } else {
      setInternalIsFitMode(fit);
    }
  };

  const handleManualZoom = (newZoom: number) => {
    const clamped = Math.max(0.3, Math.min(1.5, Math.round(newZoom * 100) / 100));
    setFitState(false);
    if (onZoomChange) {
      onZoomChange(clamped);
    } else {
      setInternalZoom(clamped);
    }
  };

  const handleFitClick = () => {
    setFitState(true);
    updateDimensionsAndScale();
  };

  // Safe sample customer & company data for visualization when no invoice provided
  const sampleCustomer: CustomerSnapshot = useMemo(() => ({
    id: 'cust-preview-sample',
    name: 'Ahmad Wali Rahmani',
    phone: '0799123456',
    email: 'ahmad.rahmani@example.af',
    address: 'Shahr-e-Naw, Kabul, Afghanistan',
    companyName: 'Rahmani Trading Co.',
  }), []);

  const sampleCompany: CompanySnapshot = useMemo(() => ({
    companyName: design.company?.name || design.title?.text || design.header?.headerText || settings?.companyName || 'Sarwan Technology',
    logo: design.logos?.logo1?.url || settings?.logo || '/sarwan-logo.png',
    logo2: design.logos?.logo2?.url || settings?.logo2 || '/dahua-logo.svg',
    phone: settings?.phone || '0731339014',
    whatsapp: settings?.whatsapp || '0778771020',
    email: settings?.email || 'Sarwantechnology.af@gmail.com',
    address: settings?.address || 'Kabul, Afghanistan',
    website: settings?.website || 'https://sarwantechnology.af',
    currency: settings?.currency || 'AFN',
    invoiceNote:
      design.notes.invoiceNoteText ||
      settings?.invoiceNote ||
      'Note: Goods once sold cannot be returned. This bill is valid only with authorized manager signature.',
    footerText: design.footer.footerText || settings?.footerText || 'Sarwan Technology - Comprehensive Security & Surveillance Solutions',
  }), [settings, design.company?.name, design.title?.text, design.header?.headerText, design.logos?.logo1?.url, design.logos?.logo2?.url, design.notes.invoiceNoteText, design.footer.footerText]);

  const sampleTotal = useMemo(() => {
    return SAMPLE_INVOICE_ITEMS.reduce((sum, item) => sum + (item.totalAmount || 0), 0);
  }, []);
  const samplePaid = 20000;

  // Active invoice for preview (either real invoice or safe sample invoice)
  const activeInvoice = useMemo(() => {
    if (propInvoice) {
      return propInvoice;
    }
    return {
      id: 'preview-inv',
      billNumber: `${settings?.invoicePrefix || 'ST-'}${settings?.nextInvoiceNumber || 1060}`,
      date: new Date().toISOString().split('T')[0],
      items: SAMPLE_INVOICE_ITEMS,
      totalAmount: sampleTotal,
      customerSnapshot: sampleCustomer,
      companySnapshot: sampleCompany,
      assignedCollectorName: 'Mohammad Bilal (Sarwan)',
      note: design.notes.invoiceNoteText || settings?.invoiceNote || '',
      status: 'Partially Paid' as const,
    };
  }, [propInvoice, settings, sampleTotal, sampleCustomer, sampleCompany, design.notes.invoiceNoteText]);

  const activeTotalPaid = useMemo(() => {
    if (propInvoice) {
      return typeof propInvoice.totalPaid === 'number' ? propInvoice.totalPaid : undefined;
    }
    return samplePaid;
  }, [propInvoice, samplePaid]);

  // Build the canonical invoice document using the SINGLE source of truth
  const canonicalDoc = useMemo(() => {
    return buildCanonicalInvoiceDocument({
      invoice: activeInvoice,
      totalPaidOverride: activeTotalPaid,
      payments,
      settings: {
        ...(settings || {}),
        invoiceDesign: design,
      },
    });
  }, [activeInvoice, activeTotalPaid, payments, settings, design]);

  // Responsive Fit Calculation:
  // Measures the actual available container width minus responsive horizontal padding,
  // and divides by the canonical A4 rendered width.
  const updateDimensionsAndScale = useCallback(() => {
    const container = containerRef.current;
    if (!container) return;

    const width = container.clientWidth;
    const height = container.clientHeight;
    if (width <= 0) return;

    setViewportDims({ width, height });

    // Responsive horizontal padding based on available viewport width:
    // 8px on mobile (<= 400px), 12px (401-640px), 16px (641-1024px), 24px on desktop (> 1024px)
    const minPadding = width <= 400 ? 8 : width <= 640 ? 12 : width <= 1024 ? 16 : 24;
    const totalHorizontalPadding = minPadding * 2;
    const availableWidth = Math.max(60, width - totalHorizontalPadding);

    // Standard A4 width is 210mm (approx 793.7px at 96 CSS DPI: 210 * 96 / 25.4)
    const paperWidthMm = canonicalDoc.paperConfig?.widthMm || 210;
    const renderedWidthPx = paperWidthMm * 3.779527559;

    const rawScale = availableWidth / renderedWidthPx;
    // Cap at 1.0 (actual 100% A4 size) so it doesn't inflate excessively on ultra-wide screens,
    // and floor at 0.20 for tiny screens
    const fitScale = Math.max(0.2, Math.min(1.0, Math.round(rawScale * 1000) / 1000));

    setCalculatedFitZoom(fitScale);
    if (onZoomChange && isFit) {
      onZoomChange(fitScale);
    }
  }, [canonicalDoc.paperConfig?.widthMm, onZoomChange, isFit]);

  // Observe container size changes using ResizeObserver
  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;

    // Initial measurement & fit scale calculation
    updateDimensionsAndScale();

    let resizeObserver: ResizeObserver | null = null;
    if (typeof ResizeObserver !== 'undefined') {
      resizeObserver = new ResizeObserver(() => {
        updateDimensionsAndScale();
      });
      resizeObserver.observe(container);
    }

    const handleWindowResize = () => {
      updateDimensionsAndScale();
    };

    window.addEventListener('resize', handleWindowResize);
    window.addEventListener('orientationchange', handleWindowResize);

    return () => {
      if (resizeObserver) resizeObserver.disconnect();
      window.removeEventListener('resize', handleWindowResize);
      window.removeEventListener('orientationchange', handleWindowResize);
    };
  }, [updateDimensionsAndScale]);

  // Canonical A4 base dimensions (in mm and px)
  const paperWidthMm = canonicalDoc.paperConfig?.widthMm || 210;
  const paperHeightMm = canonicalDoc.paperConfig?.heightMm || 297;
  const a4WidthPx = Math.round(paperWidthMm * 3.779527559);
  const a4HeightPx = Math.round(paperHeightMm * 3.779527559);

  // Scaled dimensions based on authoritative activeZoom
  const scaledWidthPx = Math.round(a4WidthPx * activeZoom);
  const scaledHeightPx = Math.round(a4HeightPx * activeZoom);

  // Centering Calculation:
  // leftOffset = max(minPadding, (viewportWidth - scaledPageWidth) / 2)
  const minPadding = viewportDims.width <= 400 ? 8 : viewportDims.width <= 640 ? 12 : viewportDims.width <= 1024 ? 16 : 24;
  const leftOffset = Math.max(minPadding, Math.floor((viewportDims.width - scaledWidthPx) / 2));

  // The stage occupies at least 100% of the viewport, expanding if the scaled page exceeds viewport
  const stageWidth = Math.max(viewportDims.width, scaledWidthPx + minPadding * 2);
  const stageHeight = Math.max(viewportDims.height, scaledHeightPx + 48); // 16px top + 32px bottom padding

  return (
    <div className={`flex flex-col h-full bg-neutral-100 rounded-xl border border-neutral-300 overflow-hidden ${className}`}>
      {/* Top Preview Controls Bar */}
      {showControls && (
        <div className="bg-white border-b border-neutral-200 px-3 sm:px-4 py-2 flex flex-wrap items-center justify-between gap-2 text-xs shrink-0">
          {/* Left: Source switcher if provided */}
          <div className="flex items-center gap-2">
            {sourceToggle ? (
              <div className="flex items-center gap-1.5">
                <span className="text-neutral-500 font-medium">Data:</span>
                <div className="inline-flex rounded-lg border border-neutral-300 p-0.5 bg-neutral-50">
                  <button
                    type="button"
                    onClick={() => sourceToggle.onSourceChange('sample')}
                    className={`px-2.5 py-1 text-xs font-semibold rounded-md transition ${
                      sourceToggle.source === 'sample'
                        ? 'bg-neutral-900 text-white shadow-xs'
                        : 'text-neutral-600 hover:text-neutral-900'
                    }`}
                  >
                    Sample CCTV Data
                  </button>
                  <button
                    type="button"
                    onClick={() => sourceToggle.onSourceChange('real')}
                    className={`px-2.5 py-1 text-xs font-semibold rounded-md transition ${
                      sourceToggle.source === 'real'
                        ? 'bg-neutral-900 text-white shadow-xs'
                        : 'text-neutral-600 hover:text-neutral-900'
                    }`}
                  >
                    Real Invoices ({sourceToggle.realInvoices?.length || 0})
                  </button>
                </div>

                {sourceToggle.source === 'real' && sourceToggle.realInvoices && sourceToggle.realInvoices.length > 0 && (
                  <select
                    value={sourceToggle.selectedRealInvoiceId ?? ''}
                    onChange={(e) => sourceToggle.onSelectRealInvoice?.(e.target.value)}
                    className="text-xs font-medium border border-neutral-300 rounded-md py-1 px-2 bg-white text-neutral-800"
                  >
                    {sourceToggle.realInvoices.map((inv) => (
                      <option key={inv.id} value={inv.id}>
                        {inv.billNumber || 'No #'} - {inv.customerSnapshot?.name || 'Walk-in'} (AFN {formatInvoiceNumber(inv.totalAmount)})
                      </option>
                    ))}
                  </select>
                )}
              </div>
            ) : (
              <div className="flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
                <span className="font-semibold text-neutral-800">
                  A4 Live Template Preview
                </span>
                <span className="text-neutral-400">|</span>
                <span className="text-neutral-500 text-[11px]">
                  Paper: {design.page.paperSize} ({design.page.orientation})
                </span>
              </div>
            )}
          </div>

          {/* Right: Responsive Zoom & Fit Controls */}
          <div className="flex items-center gap-1.5 ml-auto">
            {/* Fit to Screen button */}
            <button
              type="button"
              onClick={handleFitClick}
              className={`px-2 py-1 text-xs font-semibold rounded-md border transition flex items-center gap-1 ${
                isFit
                  ? 'bg-blue-600 text-white border-blue-600 shadow-2xs'
                  : 'bg-white text-neutral-700 border-neutral-300 hover:bg-neutral-50 hover:text-neutral-900'
              }`}
              title="Fit to Screen (Responsive Auto-Fit)"
            >
              <Maximize2 className="w-3.5 h-3.5" />
              <span>Fit</span>
            </button>

            {/* Zoom Out */}
            <button
              type="button"
              onClick={() => handleManualZoom(activeZoom - 0.1)}
              className="p-1.5 text-neutral-600 hover:text-neutral-900 hover:bg-neutral-100 rounded-md transition"
              title="Zoom Out"
            >
              <ZoomOut className="w-3.5 h-3.5" />
            </button>

            <span className="font-mono font-semibold text-neutral-700 w-12 text-center text-xs">
              {Math.round(activeZoom * 100)}%
            </span>

            {/* Zoom In */}
            <button
              type="button"
              onClick={() => handleManualZoom(activeZoom + 0.1)}
              className="p-1.5 text-neutral-600 hover:text-neutral-900 hover:bg-neutral-100 rounded-md transition"
              title="Zoom In"
            >
              <ZoomIn className="w-3.5 h-3.5" />
            </button>

            {/* 100% Actual Size */}
            <button
              type="button"
              onClick={() => handleManualZoom(1.0)}
              className="px-1.5 py-1 text-[11px] font-medium text-neutral-600 hover:text-neutral-900 hover:bg-neutral-100 rounded-md transition"
              title="Actual Size 100%"
            >
              100%
            </button>

            {/* Reset Zoom */}
            <button
              type="button"
              onClick={() => handleManualZoom(0.85)}
              className="p-1.5 text-neutral-600 hover:text-neutral-900 hover:bg-neutral-100 rounded-md transition"
              title="Reset Zoom to 85%"
            >
              <RotateCcw className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* 1. PREVIEW VIEWPORT (Dedicated scroll container with strict boundaries) */}
      {/* ========================================================================= */}
      <div
        ref={containerRef}
        data-preview-scroll-container="true"
        className="flex-1 w-full min-w-0 overflow-y-auto overflow-x-auto relative bg-neutral-200/70"
        style={{ contain: 'paint', boxSizing: 'border-box' }}
        onClick={(e) => {
          if (isInteractive && e.target === e.currentTarget) {
            onSelectElement?.(null);
          }
        }}
      >
        {/* ========================================================================= */}
        {/* 2. DEDICATED PREVIEW STAGE (Calculated dimensions from scaled A4 page)   */}
        {/* ========================================================================= */}
        <div
          data-preview-stage="true"
          className="relative select-none"
          style={{
            width: `${stageWidth}px`,
            minWidth: '100%',
            height: `${stageHeight}px`,
            minHeight: '100%',
            boxSizing: 'border-box',
          }}
          onClick={(e) => {
            if (isInteractive && e.target === e.currentTarget) {
              onSelectElement?.(null);
            }
          }}
        >
          {/* ========================================================================= */}
          {/* 3. A4 PAGE WRAPPER (Solid, unscaled bounding box placed via leftOffset)   */}
          {/* ========================================================================= */}
          <div
            data-a4-wrapper="true"
            className="absolute transition-all duration-150 ease-out"
            style={{
              top: '16px',
              left: `${leftOffset}px`,
              width: `${scaledWidthPx}px`,
              height: `${scaledHeightPx}px`,
            }}
            onClick={(e) => {
              if (isInteractive && e.target === e.currentTarget) {
                onSelectElement?.(null);
              }
            }}
          >
            {/* ========================================================================= */}
            {/* 4. CANONICAL 210mm x 297mm INVOICE (ONE visual scale transform, top-left) */}
            {/* ========================================================================= */}
            <div
              ref={innerDocRef}
              data-canonical-invoice-scaler="true"
              style={{
                position: 'absolute',
                top: 0,
                left: 0,
                width: `${a4WidthPx}px`,
                height: `${a4HeightPx}px`,
                transform: `scale(${activeZoom})`,
                transformOrigin: 'top left',
                transition: 'transform 0.15s ease-out',
              }}
              className="shadow-2xl rounded-xs bg-white select-text"
            >
              {/* Canonical Invoice Template */}
              <InvoiceTemplate
                document={canonicalDoc}
                design={design}
                id="template-live-preview"
                selectedElement={selectedElement}
                onSelectElement={onSelectElement}
                isInteractive={isInteractive}
              />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default InvoiceTemplatePreview;
