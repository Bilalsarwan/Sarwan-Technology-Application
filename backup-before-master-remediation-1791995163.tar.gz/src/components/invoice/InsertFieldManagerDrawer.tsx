import React, { useState, useMemo } from 'react';
import {
  InvoiceDesignSettings,
  DesignerElement,
  TableColumnKey,
} from '../../types/invoiceDesign';
import {
  getElementVisibility,
  setElementVisibility,
} from '../../utils/canonicalVisibility';
import {
  X,
  Eye,
  EyeOff,
  Lock,
  Unlock,
  Search,
  Building,
  FileText,
  Users,
  Table as TableIcon,
  CreditCard,
  Calculator,
  PenTool,
  ChevronDown,
  ChevronRight,
  CheckCircle2,
  PlusSquare,
} from 'lucide-react';

export interface InsertFieldManagerDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  design: InvoiceDesignSettings;
  updateDesign: (updater: (prev: InvoiceDesignSettings) => InvoiceDesignSettings) => void;
  selectedElement: DesignerElement | null;
  onSelectElement: (element: DesignerElement | null) => void;
}

export interface FieldItemDef {
  id: string;
  label: string;
  category: 'header' | 'meta' | 'customer' | 'table' | 'payment' | 'totals' | 'closing';
  designerElement?: DesignerElement;
  isVisible: (design: InvoiceDesignSettings) => boolean;
  onToggleVisible: (checked: boolean) => void;
  isLocked?: (design: InvoiceDesignSettings) => boolean;
  onToggleLock?: (locked: boolean) => void;
}

export const InsertFieldManagerDrawer: React.FC<InsertFieldManagerDrawerProps> = ({
  isOpen,
  onClose,
  design,
  updateDesign,
  selectedElement,
  onSelectElement,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [collapsedCategories, setCollapsedCategories] = useState<Record<string, boolean>>({});

  const toggleCategory = (catId: string) => {
    setCollapsedCategories((prev) => ({ ...prev, [catId]: !prev[catId] }));
  };

  const expandAll = () => setCollapsedCategories({});
  const collapseAll = () =>
    setCollapsedCategories({
      header: true,
      meta: true,
      customer: true,
      table: true,
      payment: true,
      totals: true,
      closing: true,
    });

  // All 7 Canonical Categories and their discrete independent field definitions
  const allFields: FieldItemDef[] = useMemo(() => {
    return [
      // CATEGORY A — HEADER
      {
        id: 'leftLogo',
        label: 'Left Logo',
        category: 'header',
        designerElement: 'logoLeft',
        isVisible: (d) => getElementVisibility('logoLeft', d),
        onToggleVisible: (checked) =>
          updateDesign((p) => setElementVisibility('logoLeft', checked, p)),
        isLocked: (d) => Boolean(d.logos.logo1.locked),
        onToggleLock: (locked) =>
          updateDesign((p) => ({
            ...p,
            logos: { ...p.logos, logo1: { ...p.logos.logo1, locked } },
          })),
      },
      {
        id: 'rightLogo',
        label: 'Right Logo',
        category: 'header',
        designerElement: 'logoRight',
        isVisible: (d) => getElementVisibility('logoRight', d),
        onToggleVisible: (checked) =>
          updateDesign((p) => setElementVisibility('logoRight', checked, p)),
        isLocked: (d) => Boolean(d.logos.logo2.locked),
        onToggleLock: (locked) =>
          updateDesign((p) => ({
            ...p,
            logos: { ...p.logos, logo2: { ...p.logos.logo2, locked } },
          })),
      },
      {
        id: 'companyEnglishName',
        label: 'Company English Name',
        category: 'header',
        designerElement: 'companyEnglishName',
        isVisible: (d) => getElementVisibility('companyEnglishName', d),
        onToggleVisible: (checked) =>
          updateDesign((p) => setElementVisibility('companyEnglishName', checked, p)),
        isLocked: (d) => Boolean((d.company as any).nameLocked),
        onToggleLock: (locked) =>
          updateDesign((p) => ({
            ...p,
            company: { ...p.company, nameLocked: locked } as any,
          })),
      },
      {
        id: 'companyPashtoName',
        label: 'Company Pashto Name',
        category: 'header',
        designerElement: 'companyPashtoName',
        isVisible: (d) => getElementVisibility('companyPashtoName', d),
        onToggleVisible: (checked) =>
          updateDesign((p) => setElementVisibility('companyPashtoName', checked, p)),
        isLocked: (d) => Boolean((d.company as any).pashtoLocked),
        onToggleLock: (locked) =>
          updateDesign((p) => ({
            ...p,
            company: { ...p.company, pashtoLocked: locked } as any,
          })),
      },
      {
        id: 'slogan',
        label: 'Slogan',
        category: 'header',
        designerElement: 'companySlogan',
        isVisible: (d) => getElementVisibility('companySlogan', d),
        onToggleVisible: (checked) =>
          updateDesign((p) => setElementVisibility('companySlogan', checked, p)),
        isLocked: (d) => Boolean((d.company as any).sloganLocked),
        onToggleLock: (locked) =>
          updateDesign((p) => ({
            ...p,
            company: { ...p.company, sloganLocked: locked } as any,
          })),
      },
      {
        id: 'shapeTopLeft',
        label: 'Top Left Shape',
        category: 'header',
        designerElement: 'shapeTopLeft',
        isVisible: (d) => getElementVisibility('shapeTopLeft', d),
        onToggleVisible: (checked) =>
          updateDesign((p) => setElementVisibility('shapeTopLeft', checked, p)),
        isLocked: (d) => Boolean(d.shapes.topLeft.locked),
        onToggleLock: (locked) =>
          updateDesign((p) => ({
            ...p,
            shapes: { ...p.shapes, topLeft: { ...p.shapes.topLeft, locked } },
          })),
      },
      {
        id: 'shapeTopRight',
        label: 'Top Right Shape',
        category: 'header',
        designerElement: 'shapeTopRight',
        isVisible: (d) => getElementVisibility('shapeTopRight', d),
        onToggleVisible: (checked) =>
          updateDesign((p) => setElementVisibility('shapeTopRight', checked, p)),
        isLocked: (d) => Boolean(d.shapes.topRight.locked),
        onToggleLock: (locked) =>
          updateDesign((p) => ({
            ...p,
            shapes: { ...p.shapes, topRight: { ...p.shapes.topRight, locked } },
          })),
      },
      {
        id: 'shapeGoldAccent',
        label: 'Gold Accent Shape',
        category: 'header',
        designerElement: 'shapeGoldAccent',
        isVisible: (d) => getElementVisibility('shapeGoldAccent', d),
        onToggleVisible: (checked) =>
          updateDesign((p) => setElementVisibility('shapeGoldAccent', checked, p)),
        isLocked: (d) => Boolean(d.shapes.goldAccent.locked),
        onToggleLock: (locked) =>
          updateDesign((p) => ({
            ...p,
            shapes: { ...p.shapes, goldAccent: { ...p.shapes.goldAccent, locked } },
          })),
      },

      // CATEGORY B — INVOICE INFORMATION
      {
        id: 'invoiceNumber',
        label: 'Invoice Number',
        category: 'meta',
        designerElement: 'billNumber',
        isVisible: (d) => getElementVisibility('billNumber', d),
        onToggleVisible: (checked) =>
          updateDesign((p) => setElementVisibility('billNumber', checked, p)),
      },
      {
        id: 'invoiceDate',
        label: 'Invoice Date',
        category: 'meta',
        designerElement: 'invoiceDate',
        isVisible: (d) => getElementVisibility('invoiceDate', d),
        onToggleVisible: (checked) =>
          updateDesign((p) => setElementVisibility('invoiceDate', checked, p)),
      },
      {
        id: 'dueDate',
        label: 'Due Date',
        category: 'meta',
        designerElement: 'dueDate',
        isVisible: (d) => getElementVisibility('dueDate', d),
        onToggleVisible: (checked) =>
          updateDesign((p) => setElementVisibility('dueDate', checked, p)),
      },
      {
        id: 'collector',
        label: 'Collector',
        category: 'meta',
        designerElement: 'collector',
        isVisible: (d) => getElementVisibility('collector', d),
        onToggleVisible: (checked) =>
          updateDesign((p) => setElementVisibility('collector', checked, p)),
      },

      // CATEGORY C — CUSTOMER INFORMATION
      {
        id: 'customerName',
        label: 'Customer Name',
        category: 'customer',
        designerElement: 'customerName',
        isVisible: (d) => getElementVisibility('customerName', d),
        onToggleVisible: (checked) =>
          updateDesign((p) => setElementVisibility('customerName', checked, p)),
      },
      {
        id: 'customerPhone',
        label: 'Customer Phone',
        category: 'customer',
        designerElement: 'customerPhone',
        isVisible: (d) => getElementVisibility('customerPhone', d),
        onToggleVisible: (checked) =>
          updateDesign((p) => setElementVisibility('customerPhone', checked, p)),
      },
      {
        id: 'customerAddress',
        label: 'Customer Address',
        category: 'customer',
        designerElement: 'customerAddress',
        isVisible: (d) => getElementVisibility('customerAddress', d),
        onToggleVisible: (checked) =>
          updateDesign((p) => setElementVisibility('customerAddress', checked, p)),
      },
      {
        id: 'customerEmail',
        label: 'Customer Email',
        category: 'customer',
        designerElement: 'customerEmail',
        isVisible: (d) => getElementVisibility('customerEmail', d),
        onToggleVisible: (checked) =>
          updateDesign((p) => setElementVisibility('customerEmail', checked, p)),
      },
      {
        id: 'customerCompany',
        label: 'Customer Company',
        category: 'customer',
        designerElement: 'customerCompany',
        isVisible: (d) => getElementVisibility('customerCompany', d),
        onToggleVisible: (checked) =>
          updateDesign((p) => setElementVisibility('customerCompany', checked, p)),
      },
      {
        id: 'customerId',
        label: 'Customer ID',
        category: 'customer',
        designerElement: 'customerId',
        isVisible: (d) => getElementVisibility('customerId', d),
        onToggleVisible: (checked) =>
          updateDesign((p) => setElementVisibility('customerId', checked, p)),
      },

      // CATEGORY D — ITEMS TABLE
      {
        id: 'col_sNo',
        label: '# (S.No)',
        category: 'table',
        designerElement: 'tableColumnSerial',
        isVisible: (d) => getElementVisibility('tableColumnSerial', d),
        onToggleVisible: (checked) =>
          updateDesign((p) => setElementVisibility('tableColumnSerial', checked, p)),
      },
      {
        id: 'col_description',
        label: 'Description / Item',
        category: 'table',
        designerElement: 'tableColumnDescription',
        isVisible: (d) => getElementVisibility('tableColumnDescription', d),
        onToggleVisible: (checked) =>
          updateDesign((p) => setElementVisibility('tableColumnDescription', checked, p)),
      },
      {
        id: 'col_quantity',
        label: 'Quantity',
        category: 'table',
        designerElement: 'tableColumnQuantity',
        isVisible: (d) => getElementVisibility('tableColumnQuantity', d),
        onToggleVisible: (checked) =>
          updateDesign((p) => setElementVisibility('tableColumnQuantity', checked, p)),
      },
      {
        id: 'col_unit',
        label: 'Unit',
        category: 'table',
        designerElement: 'tableColumnUnit',
        isVisible: (d) => getElementVisibility('tableColumnUnit', d),
        onToggleVisible: (checked) =>
          updateDesign((p) => setElementVisibility('tableColumnUnit', checked, p)),
      },
      {
        id: 'col_unitPrice',
        label: 'Unit Price',
        category: 'table',
        designerElement: 'tableColumnUnitPrice',
        isVisible: (d) => getElementVisibility('tableColumnUnitPrice', d),
        onToggleVisible: (checked) =>
          updateDesign((p) => setElementVisibility('tableColumnUnitPrice', checked, p)),
      },
      {
        id: 'col_discount',
        label: 'Discount',
        category: 'table',
        designerElement: 'tableColumnDiscount',
        isVisible: (d) => getElementVisibility('tableColumnDiscount', d),
        onToggleVisible: (checked) =>
          updateDesign((p) => setElementVisibility('tableColumnDiscount', checked, p)),
      },
      {
        id: 'col_tax',
        label: 'Tax',
        category: 'table',
        designerElement: 'tableColumnTax',
        isVisible: (d) => getElementVisibility('tableColumnTax', d),
        onToggleVisible: (checked) =>
          updateDesign((p) => setElementVisibility('tableColumnTax', checked, p)),
      },
      {
        id: 'col_total',
        label: 'Total',
        category: 'table',
        designerElement: 'tableColumnTotal',
        isVisible: (d) => getElementVisibility('tableColumnTotal', d),
        onToggleVisible: (checked) =>
          updateDesign((p) => setElementVisibility('tableColumnTotal', checked, p)),
      },

      // CATEGORY E — PAYMENT
      {
        id: 'paymentMethod',
        label: 'Payment Method',
        category: 'payment',
        designerElement: 'paymentMethod',
        isVisible: (d) => getElementVisibility('paymentMethod', d),
        onToggleVisible: (checked) =>
          updateDesign((p) => setElementVisibility('paymentMethod', checked, p)),
      },
      {
        id: 'paymentStatus',
        label: 'Payment Status',
        category: 'payment',
        designerElement: 'paymentStatus',
        isVisible: (d) => getElementVisibility('paymentStatus', d),
        onToggleVisible: (checked) =>
          updateDesign((p) => setElementVisibility('paymentStatus', checked, p)),
      },
      {
        id: 'paidAmount',
        label: 'Paid Amount',
        category: 'payment',
        designerElement: 'paidAmount',
        isVisible: (d) => getElementVisibility('paidAmount', d),
        onToggleVisible: (checked) =>
          updateDesign((p) => setElementVisibility('paidAmount', checked, p)),
      },
      {
        id: 'remainingAmount',
        label: 'Remaining Amount',
        category: 'payment',
        designerElement: 'remainingAmount',
        isVisible: (d) => getElementVisibility('remainingAmount', d),
        onToggleVisible: (checked) =>
          updateDesign((p) => setElementVisibility('remainingAmount', checked, p)),
      },

      // CATEGORY F — TOTALS / SUMMARY
      {
        id: 'subtotal',
        label: 'Subtotal',
        category: 'totals',
        designerElement: 'subtotal',
        isVisible: (d) => getElementVisibility('subtotal', d),
        onToggleVisible: (checked) =>
          updateDesign((p) => setElementVisibility('subtotal', checked, p)),
      },
      {
        id: 'discountTotal',
        label: 'Discount',
        category: 'totals',
        designerElement: 'discountTotal',
        isVisible: (d) => getElementVisibility('discountTotal', d),
        onToggleVisible: (checked) =>
          updateDesign((p) => setElementVisibility('discountTotal', checked, p)),
      },
      {
        id: 'taxTotal',
        label: 'Tax',
        category: 'totals',
        designerElement: 'taxTotal',
        isVisible: (d) => getElementVisibility('taxTotal', d),
        onToggleVisible: (checked) =>
          updateDesign((p) => setElementVisibility('taxTotal', checked, p)),
      },
      {
        id: 'grandTotal',
        label: 'Grand Total',
        category: 'totals',
        designerElement: 'grandTotal',
        isVisible: (d) => getElementVisibility('grandTotal', d),
        onToggleVisible: (checked) =>
          updateDesign((p) => setElementVisibility('grandTotal', checked, p)),
      },
      {
        id: 'totalPaid',
        label: 'Paid',
        category: 'totals',
        designerElement: 'totalPaid',
        isVisible: (d) => getElementVisibility('totalPaid', d),
        onToggleVisible: (checked) =>
          updateDesign((p) => setElementVisibility('totalPaid', checked, p)),
      },
      {
        id: 'remainingTotal',
        label: 'Remaining',
        category: 'totals',
        designerElement: 'remainingTotal',
        isVisible: (d) => getElementVisibility('remainingTotal', d),
        onToggleVisible: (checked) =>
          updateDesign((p) => setElementVisibility('remainingTotal', checked, p)),
      },
      {
        id: 'paymentStatusTotal',
        label: 'Payment Status',
        category: 'totals',
        designerElement: 'paymentStatusTotal',
        isVisible: (d) => getElementVisibility('paymentStatusTotal', d),
        onToggleVisible: (checked) =>
          updateDesign((p) => setElementVisibility('paymentStatusTotal', checked, p)),
      },

      // CATEGORY G — CLOSING
      {
        id: 'notes',
        label: 'Notes',
        category: 'closing',
        designerElement: 'notes',
        isVisible: (d) => getElementVisibility('notes', d),
        onToggleVisible: (checked) =>
          updateDesign((p) => setElementVisibility('notes', checked, p)),
      },
      {
        id: 'customerSignature',
        label: 'Customer Signature',
        category: 'closing',
        designerElement: 'signatureCustomer',
        isVisible: (d) => getElementVisibility('signatureCustomer', d),
        onToggleVisible: (checked) =>
          updateDesign((p) => setElementVisibility('signatureCustomer', checked, p)),
      },
      {
        id: 'authorizedSignature',
        label: 'Authorized Signature',
        category: 'closing',
        designerElement: 'signatureAuthorized',
        isVisible: (d) => getElementVisibility('signatureAuthorized', d),
        onToggleVisible: (checked) =>
          updateDesign((p) => setElementVisibility('signatureAuthorized', checked, p)),
      },
      {
        id: 'footerThankYou',
        label: 'Footer Thank You',
        category: 'closing',
        designerElement: 'footerThankYou',
        isVisible: (d) => getElementVisibility('footerThankYou', d),
        onToggleVisible: (checked) =>
          updateDesign((p) => setElementVisibility('footerThankYou', checked, p)),
      },
      {
        id: 'footerContacts',
        label: 'Footer Contacts',
        category: 'closing',
        designerElement: 'footerContacts',
        isVisible: (d) => getElementVisibility('footerContacts', d),
        onToggleVisible: (checked) =>
          updateDesign((p) => setElementVisibility('footerContacts', checked, p)),
      },
      {
        id: 'pageNumber',
        label: 'Page Number',
        category: 'closing',
        designerElement: 'pageNumber',
        isVisible: (d) => getElementVisibility('pageNumber', d),
        onToggleVisible: (checked) =>
          updateDesign((p) => setElementVisibility('pageNumber', checked, p)),
      },
    ];
  }, [updateDesign]);

  const categoryConfigs = [
    { id: 'header', name: 'Category A — Header & Branding', icon: Building, color: 'text-blue-600' },
    { id: 'meta', name: 'Category B — Invoice Information', icon: FileText, color: 'text-indigo-600' },
    { id: 'customer', name: 'Category C — Customer Information', icon: Users, color: 'text-emerald-600' },
    { id: 'table', name: 'Category D — Items Table Columns', icon: TableIcon, color: 'text-teal-600' },
    { id: 'payment', name: 'Category E — Payment Information', icon: CreditCard, color: 'text-amber-600' },
    { id: 'totals', name: 'Category F — Totals & Summary', icon: Calculator, color: 'text-purple-600' },
    { id: 'closing', name: 'Category G — Closing & Signatures', icon: PenTool, color: 'text-rose-600' },
  ];

  // Search filtering
  const filteredFields = useMemo(() => {
    const query = searchQuery.trim().toLowerCase();
    if (!query) return allFields;
    return allFields.filter(
      (f) =>
        f.label.toLowerCase().includes(query) ||
        f.category.toLowerCase().includes(query) ||
        (f.designerElement && f.designerElement.toLowerCase().includes(query))
    );
  }, [allFields, searchQuery]);

  if (!isOpen) return null;

  return (
    <div
      className="fixed inset-0 z-50 bg-black/40 backdrop-blur-xs flex items-center justify-end animate-in fade-in duration-150"
      onClick={onClose}
    >
      <div
        className="bg-white w-full sm:w-[480px] h-full shadow-2xl flex flex-col border-l border-neutral-200 animate-in slide-in-from-right duration-200 text-neutral-800"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="px-4 py-3 sm:px-5 border-b border-neutral-200 flex items-center justify-between bg-neutral-50/90 shrink-0">
          <div className="flex items-center gap-2.5 min-w-0">
            <div className="p-1.5 bg-emerald-100 text-emerald-700 rounded-md shrink-0">
              <PlusSquare className="w-4 h-4" />
            </div>
            <div className="min-w-0">
              <h3 className="text-sm font-bold text-neutral-900 truncate">Insert / Field Manager</h3>
              <p className="text-[11px] text-neutral-500 truncate">
                Toggle visibility & select canvas fields
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close Insert Manager"
            className="p-1.5 text-neutral-400 hover:text-neutral-700 rounded-md hover:bg-neutral-200/60 transition cursor-pointer"
            title="Close (Esc)"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Search & Bulk Collapse Controls */}
        <div className="p-3 border-b border-neutral-200 bg-white flex items-center gap-2 shrink-0">
          <div className="relative flex-1">
            <Search className="w-3.5 h-3.5 text-neutral-400 absolute left-2.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Search invoice fields..."
              value={searchQuery ?? ''}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full h-8 pl-8 pr-3 text-xs bg-neutral-50 border border-neutral-200 rounded-lg focus:outline-none focus:ring-1 focus:ring-emerald-500 focus:bg-white"
            />
            {searchQuery && (
              <button
                type="button"
                onClick={() => setSearchQuery('')}
                className="absolute right-2 top-1/2 -translate-y-1/2 text-neutral-400 hover:text-neutral-600 text-xs"
              >
                ✕
              </button>
            )}
          </div>
          <div className="flex items-center gap-1 shrink-0">
            <button
              type="button"
              onClick={expandAll}
              className="px-2 py-1 text-[11px] font-medium text-neutral-600 hover:bg-neutral-100 rounded border border-neutral-200 cursor-pointer"
              title="Expand all categories"
            >
              Expand
            </button>
            <button
              type="button"
              onClick={collapseAll}
              className="px-2 py-1 text-[11px] font-medium text-neutral-600 hover:bg-neutral-100 rounded border border-neutral-200 cursor-pointer"
              title="Collapse all categories"
            >
              Collapse
            </button>
          </div>
        </div>

        {/* Scrollable Categories List */}
        <div className="p-4 sm:p-5 overflow-y-auto space-y-4 flex-1 text-xs">
          {categoryConfigs.map((cat) => {
            const catFields = filteredFields.filter((f) => f.category === cat.id);
            if (catFields.length === 0) return null;

            const isCollapsed = Boolean(collapsedCategories[cat.id]);
            const visibleCount = catFields.filter((f) => f.isVisible(design)).length;

            return (
              <div key={cat.id} className="border border-neutral-200 rounded-xl overflow-hidden bg-white shadow-2xs">
                {/* Category Header */}
                <button
                  type="button"
                  onClick={() => toggleCategory(cat.id)}
                  className="w-full px-3 py-2 bg-neutral-50/80 hover:bg-neutral-100/70 border-b border-neutral-200 flex items-center justify-between transition cursor-pointer text-left"
                >
                  <div className="flex items-center gap-2 min-w-0">
                    {isCollapsed ? (
                      <ChevronRight className="w-3.5 h-3.5 text-neutral-400 shrink-0" />
                    ) : (
                      <ChevronDown className="w-3.5 h-3.5 text-neutral-400 shrink-0" />
                    )}
                    <cat.icon className={`w-3.5 h-3.5 ${cat.color} shrink-0`} />
                    <span className="font-bold text-neutral-800 text-[11px] truncate uppercase tracking-wider">
                      {cat.name}
                    </span>
                  </div>
                  <span className="text-[10px] font-semibold px-1.5 py-0.5 rounded-full bg-neutral-200/80 text-neutral-700 shrink-0">
                    {visibleCount}/{catFields.length}
                  </span>
                </button>

                {/* Category Field Rows */}
                {!isCollapsed && (
                  <div className="divide-y divide-neutral-100 p-1">
                    {catFields.map((field) => {
                      const isVisible = field.isVisible(design);
                      const isSelected = field.designerElement && selectedElement === field.designerElement;
                      const isLocked = field.isLocked ? field.isLocked(design) : false;

                      return (
                        <div
                          key={field.id}
                          className={`flex items-center justify-between px-2.5 py-2 rounded-lg transition-all ${
                            isSelected
                              ? 'bg-blue-50/80 border border-blue-200'
                              : 'hover:bg-neutral-50'
                          }`}
                        >
                          {/* Left: Eye Button + Click-to-Select Field Name */}
                          <div className="flex items-center gap-2.5 min-w-0 flex-1">
                            {/* Visibility Toggle Button */}
                            <button
                              type="button"
                              onClick={(e) => {
                                e.stopPropagation();
                                field.onToggleVisible(!isVisible);
                              }}
                              aria-label={`${isVisible ? 'Hide' : 'Show'} ${field.label}`}
                              title={`${isVisible ? 'Hide' : 'Show'} ${field.label} on invoice`}
                              className={`p-1.5 rounded-md transition cursor-pointer shrink-0 ${
                                isVisible
                                  ? 'bg-emerald-50 text-emerald-600 hover:bg-emerald-100'
                                  : 'bg-neutral-100 text-neutral-400 hover:bg-neutral-200 hover:text-neutral-600'
                              }`}
                            >
                              {isVisible ? (
                                <Eye className="w-3.5 h-3.5" />
                              ) : (
                                <EyeOff className="w-3.5 h-3.5" />
                              )}
                            </button>

                            {/* Field Name: Click to select/highlight element on Preview canvas */}
                            <button
                              type="button"
                              onClick={() => {
                                if (field.designerElement) {
                                  onSelectElement(field.designerElement);
                                }
                              }}
                              className={`text-left text-xs font-medium truncate flex-1 cursor-pointer transition ${
                                isVisible ? 'text-neutral-800 hover:text-blue-700' : 'text-neutral-400 line-through'
                              } ${isSelected ? 'font-bold text-blue-700' : ''}`}
                              title={
                                field.designerElement
                                  ? `Click to highlight "${field.label}" on preview`
                                  : field.label
                              }
                            >
                              {field.label}
                            </button>
                          </div>

                          {/* Right: Optional Lock/Unlock + Selection Indicator */}
                          <div className="flex items-center gap-1.5 shrink-0 ml-2">
                            {field.onToggleLock && (
                              <button
                                type="button"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  field.onToggleLock?.(!isLocked);
                                }}
                                aria-label={isLocked ? `Unlock ${field.label}` : `Lock ${field.label}`}
                                title={isLocked ? 'Unlocked element' : 'Lock element position'}
                                className={`p-1 rounded transition cursor-pointer ${
                                  isLocked
                                    ? 'text-amber-600 bg-amber-50 hover:bg-amber-100'
                                    : 'text-neutral-300 hover:text-neutral-600'
                                }`}
                              >
                                {isLocked ? (
                                  <Lock className="w-3 h-3" />
                                ) : (
                                  <Unlock className="w-3 h-3" />
                                )}
                              </button>
                            )}

                            {isSelected && (
                              <span className="text-[10px] font-semibold text-blue-700 bg-blue-100 px-1.5 py-0.5 rounded">
                                Selected
                              </span>
                            )}
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>
            );
          })}

          {filteredFields.length === 0 && (
            <div className="text-center py-8 text-neutral-400">
              <Search className="w-6 h-6 mx-auto mb-2 opacity-50" />
              <p className="text-xs">No fields matching "{searchQuery}"</p>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="px-4 py-3 sm:px-5 border-t border-neutral-200 bg-neutral-50 flex items-center justify-between shrink-0">
          <div className="flex items-center gap-1.5 text-[11px] text-neutral-500">
            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
            <span>Updates live on canvas</span>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-1.5 text-xs font-semibold text-white bg-emerald-600 hover:bg-emerald-700 active:bg-emerald-800 rounded-md shadow-2xs transition cursor-pointer"
          >
            Done
          </button>
        </div>
      </div>
    </div>
  );
};
