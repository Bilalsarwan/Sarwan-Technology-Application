import React, { useState, useEffect, useMemo } from 'react';
import { Invoice, UserProfile } from '../../types';
import { assignCollectorToInvoice } from '../../services/db';
import { isInvoiceLocked } from '../../utils/invoiceCalculator';
import { useAuth } from '../../context/AuthContext';
import { formatDate } from '../../utils/format';
import { toast } from '../../context/ToastContext';
import {
  X,
  UserCheck,
  UserPlus,
  AlertTriangle,
  CheckCircle2,
  Loader2,
  Clock,
  Shield,
  Phone,
  User,
  History,
} from 'lucide-react';

interface InvoiceAssignmentModalProps {
  isOpen: boolean;
  onClose: () => void;
  invoice: Invoice | null;
  users: UserProfile[];
  onSuccess?: (invoiceId: string) => void;
}

export const InvoiceAssignmentModal: React.FC<InvoiceAssignmentModalProps> = ({
  isOpen,
  onClose,
  invoice,
  users,
  onSuccess,
}) => {
  const { userProfile, permissions } = useAuth();

  const [selectedCollectorId, setSelectedCollectorId] = useState<string>('');
  const [confirmedReassignment, setConfirmedReassignment] = useState<boolean>(false);
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);
  const [showHistory, setShowHistory] = useState<boolean>(false);

  // Filter ONLY active users with payment_collector role
  // Excludes inactive, suspended, pending, rejected, or non-collector roles
  const eligibleCollectors = useMemo(() => {
    return users.filter(
      (u) =>
        u.role === 'payment_collector' &&
        u.status === 'active' &&
        (!u.customerId || u.customerId.trim().length === 0)
    );
  }, [users]);

  // Current assignment state on the invoice
  const currentCollectorId = invoice?.assignedCollectorId;
  const currentCollectorName = invoice?.assignedCollectorName;
  const isAlreadyAssigned = Boolean(currentCollectorId || currentCollectorName);

  // Authoritative Lock & Void states
  const isLocked = isInvoiceLocked(invoice);
  const isVoid = Boolean(invoice?.isVoid || invoice?.status === 'Void');

  // Find currently selected collector profile
  const selectedCollector = useMemo(() => {
    return users.find((u) => u.id === selectedCollectorId);
  }, [users, selectedCollectorId]);

  // Is this an active reassignment (changing from one collector to a different one)?
  const isChangingCollector = Boolean(
    isAlreadyAssigned &&
    selectedCollectorId &&
    selectedCollectorId !== currentCollectorId
  );

  // Permission verification: Super Admin or Invoice Manager only
  const isAuthorized = Boolean(
    userProfile?.role === 'super_admin' ||
    userProfile?.role === 'invoice_manager' ||
    permissions?.canManageStaff
  );

  // Initialize or reset form state whenever modal opens or invoice changes
  useEffect(() => {
    if (isOpen && invoice) {
      setSelectedCollectorId(invoice.assignedCollectorId || '');
      setConfirmedReassignment(false);
      setSuccessMessage(null);
      setShowHistory(false);
      setIsSubmitting(false);

      if (isInvoiceLocked(invoice)) {
        setErrorMessage(
          invoice.assignedCollectorId || invoice.assignedCollectorName
            ? 'Cannot change the collector of a locked invoice.'
            : 'Cannot assign a collector to a locked invoice.'
        );
      } else if (invoice.isVoid || invoice.status === 'Void') {
        setErrorMessage('Cannot assign a collector to a voided invoice.');
      } else {
        setErrorMessage(null);
      }
    }
  }, [isOpen, invoice]);

  if (!isOpen || !invoice) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);
    setSuccessMessage(null);

    // 0. Void & Locked checks
    if (isVoid) {
      setErrorMessage('Cannot assign a collector to a voided invoice.');
      return;
    }

    if (isLocked) {
      setErrorMessage(
        isAlreadyAssigned
          ? 'Cannot change the collector of a locked invoice.'
          : 'Cannot assign a collector to a locked invoice.'
      );
      return;
    }

    // 0c. Quotation & Rejected validation
    if (invoice.billingState === 'quotation') {
      setErrorMessage('Cannot assign a collector to a quotation. The quotation must first be accepted / marked as payable.');
      return;
    }
    if (invoice.billingState === 'rejected') {
      setErrorMessage('Cannot assign a collector to a rejected invoice.');
      return;
    }

    // 1. Permission check
    if (!isAuthorized) {
      setErrorMessage('Access Denied: Only Super Admin and Invoice Manager can assign collectors.');
      return;
    }

    // 2. Selection validation
    if (!selectedCollectorId) {
      setErrorMessage('Please select an eligible Invoice Collector to proceed.');
      return;
    }

    // 3. Duplicate check: Cannot reassign to the exact same collector
    if (isAlreadyAssigned && selectedCollectorId === currentCollectorId) {
      setErrorMessage(
        `${currentCollectorName || 'This collector'} is already assigned to this invoice.`
      );
      return;
    }

    // 4. Validate selected collector eligibility
    const collector = eligibleCollectors.find((u) => u.id === selectedCollectorId);
    if (!collector) {
      setErrorMessage(
        'The selected staff member is either inactive, suspended, or does not have the Invoice Collector role.'
      );
      return;
    }

    // 5. Reassignment confirmation validation
    if (isChangingCollector && !confirmedReassignment) {
      setErrorMessage(
        'Please confirm that you want to reassign this invoice to a new collector.'
      );
      return;
    }

    setIsSubmitting(true);

    try {
      await assignCollectorToInvoice(
        invoice.id,
        collector.id,
        collector.name,
        userProfile?.id || 'admin',
        userProfile?.name || 'Administrator',
        currentCollectorId,
        currentCollectorName,
        invoice.assignmentHistory || []
      );

      const notice = isChangingCollector
        ? `Invoice #${invoice.billNumber} successfully reassigned to ${collector.name}.`
        : `Invoice #${invoice.billNumber} successfully assigned to ${collector.name}.`;

      setSuccessMessage(notice);
      toast.success(notice);

      if (onSuccess) {
        onSuccess(invoice.id);
      }

      // Close modal after brief feedback
      setTimeout(() => {
        onClose();
      }, 700);
    } catch (err: any) {
      console.error('Invoice assignment failed:', err);
      const errMsg = err?.message || 'Failed to save invoice assignment. Please try again.';
      setErrorMessage(errMsg);
      toast.error(errMsg);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/60 backdrop-blur-xs overflow-y-auto">
      <div className="bg-[var(--app-surface-modal,#FFFFFF)] text-[var(--app-text-primary,#0F172A)] rounded-xl shadow-2xl w-full max-w-lg overflow-hidden border border-[var(--app-border,#E2E8F0)] flex flex-col my-auto max-h-[92vh]">
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-3.5 bg-neutral-900 text-white border-b border-neutral-800 shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="p-1.5 bg-[#F58220]/20 text-[#F58220] rounded-lg border border-[#F58220]/40">
              {isAlreadyAssigned ? (
                <UserCheck className="w-5 h-5" />
              ) : (
                <UserPlus className="w-5 h-5" />
              )}
            </div>
            <div>
              <h2 className="text-sm font-bold text-white">
                {isAlreadyAssigned ? 'Reassign Invoice Collector' : 'Assign Invoice Collector'}
              </h2>
              <p className="text-[11px] text-neutral-400 font-mono">
                Bill No: <span className="text-[#F58220] font-bold">{invoice.billNumber}</span> • {invoice.customerSnapshot?.name || 'Customer'}
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-lg text-neutral-400 hover:text-white hover:bg-neutral-800 transition cursor-pointer"
            title="Close"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Body */}
        <div className="p-5 overflow-y-auto flex-1 space-y-4 text-xs">
          {/* Permission Warning if not authorized */}
          {!isAuthorized && (
            <div className="p-3 bg-rose-50 border border-rose-200 text-rose-800 rounded-lg flex items-start gap-2">
              <AlertTriangle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
              <div>
                <p className="font-bold">Access Restricted</p>
                <p className="text-[11px] text-rose-700 mt-0.5">
                  Only Super Admin and Invoice Manager roles have permission to assign or reassign invoice collectors.
                </p>
              </div>
            </div>
          )}

          {/* Locked Invoice Warning */}
          {isLocked && (
            <div className="p-3 bg-amber-50 border border-amber-200 text-amber-900 rounded-lg flex items-start gap-2">
              <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
              <div>
                <p className="font-bold">Invoice Locked</p>
                <p className="text-[11px] text-amber-800 mt-0.5">
                  {isAlreadyAssigned
                    ? 'Cannot change the collector of a locked invoice.'
                    : 'Cannot assign a collector to a locked invoice.'}
                </p>
              </div>
            </div>
          )}

          {/* Void Invoice Warning */}
          {isVoid && (
            <div className="p-3 bg-rose-50 border border-rose-200 text-rose-800 rounded-lg flex items-start gap-2">
              <AlertTriangle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
              <div>
                <p className="font-bold">Invoice Voided</p>
                <p className="text-[11px] text-rose-700 mt-0.5">
                  Cannot assign or reassign a collector to a voided invoice.
                </p>
              </div>
            </div>
          )}

          {/* Current Assignment Status Pill */}
          <div className="p-3 bg-neutral-50 rounded-lg border border-neutral-200">
            <span className="text-[11px] font-bold uppercase text-neutral-500 block mb-1">
              Current Assignment Status:
            </span>
            {isAlreadyAssigned ? (
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-sky-100 text-sky-800 border border-sky-200">
                    <UserCheck className="w-3 h-3 text-sky-700" />
                    Assigned
                  </span>
                  <span className="font-semibold text-neutral-900 text-xs">
                    {currentCollectorName || 'Collector'}
                  </span>
                </div>
                {invoice.assignedAt && (
                  <span className="text-[11px] text-neutral-500 font-mono">
                    Since {formatDate(invoice.assignedAt)}
                  </span>
                )}
              </div>
            ) : (
              <div className="flex items-center gap-2">
                <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-neutral-200 text-neutral-700">
                  Unassigned
                </span>
                <span className="text-[11px] text-neutral-500">
                  No collector is currently assigned to this invoice.
                </span>
              </div>
            )}
          </div>

          {/* Form */}
          <form onSubmit={handleSubmit} className="space-y-4">
            {/* Collector Selection Field */}
            <div>
              <label className="block text-xs font-bold text-neutral-800 mb-1.5">
                Select Eligible Invoice Collector *
              </label>

              {eligibleCollectors.length === 0 ? (
                <div className="p-4 bg-amber-50 border border-amber-200 rounded-lg text-amber-800 text-center">
                  <AlertTriangle className="w-5 h-5 text-amber-600 mx-auto mb-1.5" />
                  <p className="font-bold text-xs">No Active Collectors Found</p>
                  <p className="text-[11px] text-amber-700 mt-1">
                    There are currently no staff accounts with the <strong>Invoice Collector</strong> role and <strong>Active</strong> status. Please activate staff in the Staff Management section.
                  </p>
                </div>
              ) : (
                <div className="space-y-2 max-h-52 overflow-y-auto pr-1">
                  {eligibleCollectors.map((collector) => {
                    const isSelected = selectedCollectorId === collector.id;
                    const isCurrent = currentCollectorId === collector.id;

                    return (
                      <div
                        key={collector.id}
                        onClick={() => {
                          if (isLocked || isVoid) return;
                          setSelectedCollectorId(collector.id);
                        }}
                        className={`p-2.5 rounded-lg border transition flex items-center justify-between ${
                          isLocked || isVoid
                            ? 'opacity-60 cursor-not-allowed bg-neutral-50 border-neutral-200'
                            : isSelected
                            ? 'border-[#F58220] bg-orange-50/50 shadow-xs ring-1 ring-[#F58220] cursor-pointer'
                            : 'border-neutral-200 hover:border-neutral-300 hover:bg-neutral-50 cursor-pointer'
                        }`}
                      >
                        <div className="flex items-center gap-3">
                          {/* Collector Photo or Fallback Avatar */}
                          <div className="w-9 h-9 rounded-full bg-neutral-200 border border-neutral-300 overflow-hidden flex items-center justify-center shrink-0">
                            {collector.photoURL ? (
                              <img
                                src={collector.photoURL}
                                alt={collector.name}
                                className="w-full h-full object-cover"
                                onError={(e) => {
                                  (e.currentTarget as HTMLElement).style.display = 'none';
                                }}
                              />
                            ) : (
                              <User className="w-5 h-5 text-neutral-500" />
                            )}
                          </div>

                          <div>
                            <div className="flex items-center gap-1.5">
                              <span className="font-bold text-xs text-neutral-900">
                                {collector.name}
                              </span>
                              {isCurrent && (
                                <span className="text-[9px] px-1.5 py-0.2 bg-neutral-200 text-neutral-700 rounded font-semibold">
                                  Current
                                </span>
                              )}
                            </div>
                            <div className="flex items-center gap-2 text-[11px] text-neutral-500 font-mono mt-0.5">
                              <span>@{collector.username || 'staff'}</span>
                              {collector.phone && (
                                <span className="flex items-center gap-0.5">
                                  <Phone className="w-3 h-3 text-neutral-400" />
                                  {collector.phone}
                                </span>
                              )}
                            </div>
                          </div>
                        </div>

                        {/* Selection Radio / Badge */}
                        <div className="shrink-0 flex items-center gap-1.5">
                          <span className="px-2 py-0.5 rounded-full text-[9px] font-bold bg-emerald-100 text-emerald-800 border border-emerald-200">
                            Active Collector
                          </span>
                          <input
                            type="radio"
                            name="collectorSelection"
                            checked={isSelected}
                            disabled={isLocked || isVoid}
                            onChange={() => !isLocked && !isVoid && setSelectedCollectorId(collector.id)}
                            className="w-4 h-4 text-[#F58220] focus:ring-[#F58220] cursor-pointer disabled:cursor-not-allowed"
                          />
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>

            {/* Selected Collector Summary Preview */}
            {selectedCollector && (
              <div className="p-3 bg-neutral-100/80 rounded-lg border border-neutral-200 flex items-center justify-between">
                <div className="flex items-center gap-2.5">
                  <div className="w-8 h-8 rounded-full bg-white border border-neutral-300 overflow-hidden flex items-center justify-center shrink-0">
                    {selectedCollector.photoURL ? (
                      <img
                        src={selectedCollector.photoURL}
                        alt={selectedCollector.name}
                        className="w-full h-full object-cover"
                      />
                    ) : (
                      <User className="w-4 h-4 text-neutral-600" />
                    )}
                  </div>
                  <div>
                    <span className="text-[10px] uppercase font-bold text-neutral-500 block">
                      Target Collector:
                    </span>
                    <span className="text-xs font-bold text-neutral-900">
                      {selectedCollector.name}
                    </span>
                  </div>
                </div>

                <span className="text-[11px] font-mono text-neutral-600">
                  ID: {selectedCollector.userId || `#${selectedCollector.id.slice(0, 6)}`}
                </span>
              </div>
            )}

            {/* Reassignment Confirmation Checkbox (Required when changing an existing collector) */}
            {isChangingCollector && (
              <div className="p-3 bg-amber-50 border border-amber-300 rounded-lg space-y-2">
                <div className="flex items-start gap-2">
                  <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
                  <div className="text-xs text-amber-900">
                    <p className="font-bold">Confirmation Required for Reassignment</p>
                    <p className="text-[11px] text-amber-800 mt-0.5">
                      This invoice is currently assigned to <strong>{currentCollectorName || 'another collector'}</strong>. Reassigning will transfer collection responsibilities to <strong>{selectedCollector?.name}</strong> and archive the previous assignment in the history log.
                    </p>
                  </div>
                </div>

                <label className="flex items-center gap-2 pt-1 cursor-pointer select-none text-xs font-semibold text-neutral-900">
                  <input
                    type="checkbox"
                    checked={confirmedReassignment}
                    onChange={(e) => setConfirmedReassignment(e.target.checked)}
                    className="w-4 h-4 text-[#F58220] rounded border-neutral-300 focus:ring-[#F58220]"
                    required
                  />
                  <span>I confirm changing the assigned collector for this invoice.</span>
                </label>
              </div>
            )}

            {/* Validation & Error Messages */}
            {errorMessage && (
              <div className="p-3 bg-rose-50 border border-rose-200 text-rose-800 text-xs rounded-lg flex items-center gap-2">
                <AlertTriangle className="w-4 h-4 text-rose-600 shrink-0" />
                <span>{errorMessage}</span>
              </div>
            )}

            {/* Success Message */}
            {successMessage && (
              <div className="p-3 bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs rounded-lg flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                <span>{successMessage}</span>
              </div>
            )}

            {/* Assignment History Section (if history exists) */}
            {invoice.assignmentHistory && invoice.assignmentHistory.length > 0 && (
              <div className="border-t border-neutral-200 pt-3">
                <button
                  type="button"
                  onClick={() => setShowHistory(!showHistory)}
                  className="text-xs font-bold text-neutral-600 hover:text-neutral-900 inline-flex items-center gap-1.5 cursor-pointer"
                >
                  <History className="w-3.5 h-3.5 text-neutral-500" />
                  <span>
                    {showHistory ? 'Hide' : 'View'} Assignment History ({invoice.assignmentHistory.length} logs)
                  </span>
                </button>

                {showHistory && (
                  <div className="mt-2 space-y-1.5 max-h-36 overflow-y-auto pr-1">
                    {invoice.assignmentHistory.map((h, idx) => (
                      <div
                        key={idx}
                        className="p-2 bg-neutral-50 border border-neutral-200 rounded text-[11px] text-neutral-700 flex items-center justify-between"
                      >
                        <div>
                          <span className="font-semibold text-neutral-900">
                            {h.collectorName}
                          </span>
                          {h.previousCollectorName && (
                            <span className="text-neutral-500 text-[10px] ml-1">
                              (replaced {h.previousCollectorName})
                            </span>
                          )}
                          <div className="text-[10px] text-neutral-500">
                            Assigned by {h.assignedByName || 'Admin'}
                          </div>
                        </div>
                        <span className="font-mono text-[10px] text-neutral-500">
                          {formatDate(h.assignedAt)}
                        </span>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}

            {/* Action Buttons */}
            <div className="flex items-center justify-end gap-2 pt-2 border-t border-neutral-100">
              <button
                type="button"
                onClick={onClose}
                disabled={isSubmitting}
                className="px-4 py-2 text-xs font-semibold rounded-lg bg-[var(--app-surface-card,#FFFFFF)] hover:bg-[var(--color-interactive-hover,#F1F5F9)] text-[var(--app-text-secondary,#475569)] hover:text-[var(--app-text-primary,#0F172A)] border border-[var(--app-border,#CBD5E1)] transition cursor-pointer disabled:opacity-50"
              >
                Cancel
              </button>

              <button
                type="submit"
                disabled={
                  isSubmitting ||
                  isLocked ||
                  isVoid ||
                  !isAuthorized ||
                  !selectedCollectorId ||
                  (isAlreadyAssigned && selectedCollectorId === currentCollectorId) ||
                  (isChangingCollector && !confirmedReassignment)
                }
                className="px-4 py-2 text-xs font-bold rounded-lg bg-[var(--color-primary,#2563EB)] hover:bg-[var(--color-primary-hover,#1D4ED8)] active:bg-[var(--color-primary-active,#1E40AF)] text-white transition inline-flex items-center gap-1.5 shadow-xs cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed focus:outline-none focus-visible:ring-2 focus-visible:ring-[var(--color-primary,#2563EB)]"
              >
                {isSubmitting ? (
                  <>
                    <Loader2 className="w-3.5 h-3.5 animate-spin" />
                    <span>Saving Assignment...</span>
                  </>
                ) : (
                  <>
                    <UserCheck className="w-3.5 h-3.5" />
                    <span>
                      {isChangingCollector
                        ? 'Confirm & Reassign'
                        : isAlreadyAssigned
                        ? 'Save Assignment'
                        : 'Assign Collector'}
                    </span>
                  </>
                )}
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};
