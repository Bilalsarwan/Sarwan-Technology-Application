import React from 'react';
import { InvoiceTemplate, InvoiceTemplateProps } from './InvoiceTemplate';

export type CanonicalInvoiceDocumentProps = InvoiceTemplateProps;
export const CanonicalInvoiceDocument: React.FC<CanonicalInvoiceDocumentProps> = (props) => {
  return <InvoiceTemplate {...props} />;
};

export const InvoiceRenderer = CanonicalInvoiceDocument;
export type InvoiceRendererProps = CanonicalInvoiceDocumentProps;

export default CanonicalInvoiceDocument;
