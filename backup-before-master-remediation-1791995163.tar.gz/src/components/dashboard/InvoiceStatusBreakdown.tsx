import React, { useMemo } from 'react';
import {
  CheckCircle2,
  Clock,
  FileText,
  AlertCircle,
  PieChart,
  ArrowUpRight,
} from 'lucide-react';
import { Invoice, Payment } from '../../types';
import { getTodayDateString, formatCount, formatAFN } from '../../utils/format';

import {
  InvoiceCalculatedStatus,
  InvoiceStatusBreakdownItem,
  InvoiceStatusBreakdownData,
  calculateInvoiceStatusBreakdown,
} from '../../utils/invoiceCalculator';

export type InvoiceBreakdownStatus = InvoiceCalculatedStatus;
export type { InvoiceStatusBreakdownItem, InvoiceStatusBreakdownData };
export { calculateInvoiceStatusBreakdown };

export function calculatePaidInvoicesCount(
  invoices: Invoice[] = [],
  payments: Payment[] = []
): number {
  return calculateInvoiceStatusBreakdown(invoices, payments).paid.count;
}

export function calculateOverdueInvoicesCount(
  invoices: Invoice[] = [],
  payments: Payment[] = [],
  todayDateStr?: string
): number {
  return calculateInvoiceStatusBreakdown(invoices, payments, todayDateStr).overdue.count;
}

export function calculatePartiallyPaidInvoicesCount(
  invoices: Invoice[] = [],
  payments: Payment[] = []
): number {
  return calculateInvoiceStatusBreakdown(invoices, payments).partiallyPaid.count;
}

export function calculateUnpaidInvoicesCount(
  invoices: Invoice[] = [],
  payments: Payment[] = []
): number {
  return calculateInvoiceStatusBreakdown(invoices, payments).unpaid.count;
}

export interface InvoiceStatusBreakdownProps {
  invoices: Invoice[];
  payments?: Payment[];
  todayDate?: string;
  className?: string;
  onSelectStatus?: (status: InvoiceBreakdownStatus) => void;
  onSelectInvoice?: (invoice: Invoice) => void;
  onViewAllInvoices?: () => void;
}

/**
 * Invoice Status Breakdown Component
 * Categorizes valid invoices (isVoid !== true) into Paid, Overdue, Partially Paid, and Unpaid.
 * Displays counts, percentages, and financial summaries in AFN currency.
 */
export const InvoiceStatusBreakdown: React.FC<InvoiceStatusBreakdownProps> = ({
  invoices = [],
  payments = [],
  todayDate,
  className = '',
  onSelectStatus,
  onSelectInvoice,
  onViewAllInvoices,
}) => {
  const breakdown = useMemo(() => {
    return calculateInvoiceStatusBreakdown(invoices, payments, todayDate);
  }, [invoices, payments, todayDate]);

  return (
    <div id="invoice-status-breakdown-section" className={`space-y-3 sm:space-y-4 ${className}`}>
      {/* Section Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
        <div>
          <div className="flex items-center gap-2">
            <PieChart className="w-4 h-4 text-[var(--brand-orange,#F7941D)] shrink-0" />
            <h2
              id="invoice-status-breakdown-title"
              className="text-base font-bold text-[var(--app-text-primary,#0F172A)] tracking-tight"
            >
              Invoice Status Breakdown
            </h2>
          </div>
          <p id="invoice-status-breakdown-subtitle" className="text-xs text-[var(--app-text-muted,#64748B)] mt-0.5">
            Overview of current invoice distribution by status
          </p>
        </div>

        <div className="flex items-center gap-2 self-start sm:self-auto">
          <span
            id="breakdown-total-valid-badge"
            className="text-[11px] font-semibold font-mono px-2.5 py-1 rounded-md bg-[var(--app-bg-muted,#F1F5F9)] text-[var(--app-text-secondary,#475569)] border border-[var(--app-border,#E2E8F0)]"
          >
            Total Valid: {formatCount(breakdown.totalValidCount)}
          </span>
          {onViewAllInvoices && (
            <button
              onClick={onViewAllInvoices}
              className="text-xs font-semibold text-[var(--brand-orange,#F7941D)] hover:opacity-80 transition flex items-center gap-1 cursor-pointer"
            >
              <span>View All</span>
              <ArrowUpRight className="w-3.5 h-3.5" />
            </button>
          )}
        </div>
      </div>

      {/* Proportional Distribution Bar (Chart) */}
      {breakdown.totalValidCount > 0 ? (
        <div className="bg-neutral-100 rounded-lg p-2 border border-neutral-200 space-y-1.5">
          <div className="h-2.5 w-full bg-neutral-200 rounded-full flex overflow-hidden">
            {breakdown.paid.count > 0 && (
              <div
                style={{
                  width: `${(breakdown.paid.count / breakdown.totalValidCount) * 100}%`,
                }}
                className="bg-emerald-500 transition-all duration-500 hover:opacity-90"
                title={`Paid: ${breakdown.paid.count} (${breakdown.paid.percentage}%)`}
              />
            )}
            {breakdown.overdue.count > 0 && (
              <div
                style={{
                  width: `${(breakdown.overdue.count / breakdown.totalValidCount) * 100}%`,
                }}
                className="bg-rose-500 transition-all duration-500 hover:opacity-90"
                title={`Overdue: ${breakdown.overdue.count} (${breakdown.overdue.percentage}%)`}
              />
            )}
            {breakdown.partiallyPaid.count > 0 && (
              <div
                style={{
                  width: `${(breakdown.partiallyPaid.count / breakdown.totalValidCount) * 100}%`,
                }}
                className="bg-amber-500 transition-all duration-500 hover:opacity-90"
                title={`Partially Paid: ${breakdown.partiallyPaid.count} (${breakdown.partiallyPaid.percentage}%)`}
              />
            )}
            {breakdown.unpaid.count > 0 && (
              <div
                style={{
                  width: `${(breakdown.unpaid.count / breakdown.totalValidCount) * 100}%`,
                }}
                className="bg-sky-500 transition-all duration-500 hover:opacity-90"
                title={`Unpaid: ${breakdown.unpaid.count} (${breakdown.unpaid.percentage}%)`}
              />
            )}
          </div>
          <div className="flex flex-wrap items-center justify-between text-[10px] text-neutral-500 px-1 gap-1">
            <span className="flex items-center gap-1">
              <span className="w-2 h-2 rounded-full bg-emerald-500 inline-block" /> Paid (
              {breakdown.paid.percentage}%)
            </span>
            <span className="flex items-center gap-1">
              <span className="w-2 h-2 rounded-full bg-rose-500 inline-block" /> Overdue (
              {breakdown.overdue.percentage}%)
            </span>
            <span className="flex items-center gap-1">
              <span className="w-2 h-2 rounded-full bg-amber-500 inline-block" /> Partially Paid (
              {breakdown.partiallyPaid.percentage}%)
            </span>
            <span className="flex items-center gap-1">
              <span className="w-2 h-2 rounded-full bg-sky-500 inline-block" /> Unpaid (
              {breakdown.unpaid.percentage}%)
            </span>
          </div>
        </div>
      ) : (
        <div className="bg-neutral-50 rounded-lg p-3 border border-neutral-200 text-center text-xs text-neutral-500">
          No valid invoices recorded yet
        </div>
      )}

      {/* 4 Status Cards Grid */}
      <div
        id="invoice-status-breakdown-container"
        className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4"
      >
        {/* 1. Paid Card */}
        <div
          id="breakdown-card-paid"
          onClick={() => onSelectStatus?.('Paid')}
          className={`bg-[var(--app-surface-card,#FFFFFF)] rounded-xl p-4 border border-emerald-200/80 bg-emerald-50/15 shadow-xs flex flex-col justify-between min-w-0 transition-colors ${
            onSelectStatus ? 'cursor-pointer hover:border-emerald-300 hover:shadow-sm' : ''
          }`}
        >
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-2">
              <div className="w-7 h-7 rounded-lg bg-emerald-100 text-emerald-700 flex items-center justify-center shrink-0">
                <CheckCircle2 className="w-4 h-4" />
              </div>
              <div>
                <span
                  id="breakdown-label-paid"
                  className="text-[11px] font-bold uppercase tracking-wide text-emerald-800 block"
                >
                  Paid
                </span>
                <span className="text-[10px] text-neutral-400">Fully collected</span>
              </div>
            </div>
            <span
              id="breakdown-percentage-paid"
              className="px-2 py-0.5 text-xs font-bold font-mono rounded-md bg-emerald-100 text-emerald-800"
            >
              {breakdown.paid.percentage}%
            </span>
          </div>

          <div>
            <div className="flex items-baseline justify-between gap-2">
              <p
                id="breakdown-count-paid"
                className="text-xl sm:text-2xl font-bold font-mono text-emerald-700 tracking-tight"
              >
                {formatCount(breakdown.paid.count)}
              </p>
              <span className="text-[11px] font-semibold text-neutral-500">
                {breakdown.paid.count === 1 ? 'invoice' : 'invoices'}
              </span>
            </div>
            <div className="mt-2 pt-2 border-t border-emerald-100 flex items-center justify-between text-[11px]">
              <span className="text-neutral-400">Settled Amount:</span>
              <span
                id="breakdown-amount-paid"
                className="font-mono font-bold text-emerald-800 truncate"
                title={formatAFN(breakdown.paid.totalAmount, true)}
              >
                {formatAFN(breakdown.paid.totalAmount, true)}
              </span>
            </div>
          </div>
        </div>

        {/* 2. Overdue Card */}
        <div
          id="breakdown-card-overdue"
          onClick={() => onSelectStatus?.('Overdue')}
          className={`bg-[var(--app-surface-card,#FFFFFF)] rounded-xl p-4 border border-rose-200/80 bg-rose-50/15 shadow-xs flex flex-col justify-between min-w-0 transition-colors ${
            onSelectStatus ? 'cursor-pointer hover:border-rose-300 hover:shadow-sm' : ''
          }`}
        >
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-2">
              <div className="w-7 h-7 rounded-lg bg-rose-100 text-rose-700 flex items-center justify-center shrink-0">
                <AlertCircle className="w-4 h-4" />
              </div>
              <div>
                <span
                  id="breakdown-label-overdue"
                  className="text-[11px] font-bold uppercase tracking-wide text-rose-800 block"
                >
                  Overdue
                </span>
                <span className="text-[10px] text-neutral-400">Past payment deadline</span>
              </div>
            </div>
            <span
              id="breakdown-percentage-overdue"
              className="px-2 py-0.5 text-xs font-bold font-mono rounded-md bg-rose-100 text-rose-800"
            >
              {breakdown.overdue.percentage}%
            </span>
          </div>

          <div>
            <div className="flex items-baseline justify-between gap-2">
              <p
                id="breakdown-count-overdue"
                className="text-xl sm:text-2xl font-bold font-mono text-rose-700 tracking-tight"
              >
                {formatCount(breakdown.overdue.count)}
              </p>
              <span className="text-[11px] font-semibold text-neutral-500">
                {breakdown.overdue.count === 1 ? 'invoice' : 'invoices'}
              </span>
            </div>
            <div className="mt-2 pt-2 border-t border-rose-100 flex items-center justify-between text-[11px]">
              <span className="text-neutral-400">Past Due Balance:</span>
              <span
                id="breakdown-amount-overdue"
                className="font-mono font-bold text-rose-800 truncate"
                title={formatAFN(breakdown.overdue.remainingAmount, true)}
              >
                {formatAFN(breakdown.overdue.remainingAmount, true)}
              </span>
            </div>
          </div>
        </div>

        {/* 3. Partially Paid Card */}
        <div
          id="breakdown-card-partially-paid"
          onClick={() => onSelectStatus?.('Partially Paid')}
          className={`bg-[var(--app-surface-card,#FFFFFF)] rounded-xl p-4 border border-amber-200/80 bg-amber-50/15 shadow-xs flex flex-col justify-between min-w-0 transition-colors ${
            onSelectStatus ? 'cursor-pointer hover:border-amber-300 hover:shadow-sm' : ''
          }`}
        >
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-2">
              <div className="w-7 h-7 rounded-lg bg-amber-100 text-amber-700 flex items-center justify-center shrink-0">
                <Clock className="w-4 h-4" />
              </div>
              <div>
                <span
                  id="breakdown-label-partially-paid"
                  className="text-[11px] font-bold uppercase tracking-wide text-amber-800 block"
                >
                  Partially Paid
                </span>
                <span className="text-[10px] text-neutral-400">Partially settled</span>
              </div>
            </div>
            <span
              id="breakdown-percentage-partially-paid"
              className="px-2 py-0.5 text-xs font-bold font-mono rounded-md bg-amber-100 text-amber-800"
            >
              {breakdown.partiallyPaid.percentage}%
            </span>
          </div>

          <div>
            <div className="flex items-baseline justify-between gap-2">
              <p
                id="breakdown-count-partially-paid"
                className="text-xl sm:text-2xl font-bold font-mono text-amber-700 tracking-tight"
              >
                {formatCount(breakdown.partiallyPaid.count)}
              </p>
              <span className="text-[11px] font-semibold text-neutral-500">
                {breakdown.partiallyPaid.count === 1 ? 'invoice' : 'invoices'}
              </span>
            </div>
            <div className="mt-2 pt-2 border-t border-amber-100 flex items-center justify-between text-[11px]">
              <span className="text-neutral-400">Remaining Due:</span>
              <span
                id="breakdown-amount-partially-paid"
                className="font-mono font-bold text-amber-800 truncate"
                title={formatAFN(breakdown.partiallyPaid.remainingAmount, true)}
              >
                {formatAFN(breakdown.partiallyPaid.remainingAmount, true)}
              </span>
            </div>
          </div>
        </div>

        {/* 4. Unpaid Card */}
        <div
          id="breakdown-card-unpaid"
          onClick={() => onSelectStatus?.('Unpaid')}
          className={`bg-[var(--app-surface-card,#FFFFFF)] rounded-xl p-4 border border-sky-200/80 bg-sky-50/15 shadow-xs flex flex-col justify-between min-w-0 transition-colors ${
            onSelectStatus ? 'cursor-pointer hover:border-sky-300 hover:shadow-sm' : ''
          }`}
        >
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-2">
              <div className="w-7 h-7 rounded-lg bg-sky-100 text-sky-700 flex items-center justify-center shrink-0">
                <FileText className="w-4 h-4" />
              </div>
              <div>
                <span
                  id="breakdown-label-unpaid"
                  className="text-[11px] font-bold uppercase tracking-wide text-sky-800 block"
                >
                  Unpaid
                </span>
                <span className="text-[10px] text-neutral-400">Awaiting full payment</span>
              </div>
            </div>
            <span
              id="breakdown-percentage-unpaid"
              className="px-2 py-0.5 text-xs font-bold font-mono rounded-md bg-sky-100 text-sky-800"
            >
              {breakdown.unpaid.percentage}%
            </span>
          </div>

          <div>
            <div className="flex items-baseline justify-between gap-2">
              <p
                id="breakdown-count-unpaid"
                className="text-xl sm:text-2xl font-bold font-mono text-sky-700 tracking-tight"
              >
                {formatCount(breakdown.unpaid.count)}
              </p>
              <span className="text-[11px] font-semibold text-neutral-500">
                {breakdown.unpaid.count === 1 ? 'invoice' : 'invoices'}
              </span>
            </div>
            <div className="mt-2 pt-2 border-t border-sky-100 flex items-center justify-between text-[11px]">
              <span className="text-neutral-400">Total Unpaid:</span>
              <span
                id="breakdown-amount-unpaid"
                className="font-mono font-bold text-sky-800 truncate"
                title={formatAFN(breakdown.unpaid.remainingAmount, true)}
              >
                {formatAFN(breakdown.unpaid.remainingAmount, true)}
              </span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
