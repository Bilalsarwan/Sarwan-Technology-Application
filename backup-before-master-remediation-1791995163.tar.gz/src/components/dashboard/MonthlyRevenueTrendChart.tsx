import React, { useState, useMemo } from 'react';
import {
  ResponsiveContainer,
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
} from 'recharts';
import { Invoice, Payment } from '../../types';
import { formatAFN, formatCount } from '../../utils/format';
import {
  TrendingUp,
  Calendar,
  Banknote,
  FileText,
  Percent,
  Wallet,
  ArrowUpRight,
  ArrowDownRight,
} from 'lucide-react';

export type RevenueTrendRange = '6M' | '12M' | 'All';

export interface MonthlyRevenueDataPoint {
  month: string; // YYYY-MM
  label: string; // "Mar 2026"
  shortLabel: string; // "Mar"
  fullLabel: string; // "March 2026"
  invoiced: number;
  collected: number;
  invoicesCount: number;
  paymentsCount: number;
  collectionRate: number; // percentage (0 - 100+)
  netVariance: number; // collected - invoiced
}

export interface MonthlyRevenueTrendsSummary {
  dataPoints: MonthlyRevenueDataPoint[];
  totalInvoiced: number;
  totalCollected: number;
  overallCollectionRate: number;
  netVariance: number;
  activeMonthsCount: number;
}

const MONTH_SHORT_NAMES = [
  'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
  'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec',
];

const MONTH_FULL_NAMES = [
  'January', 'February', 'March', 'April', 'May', 'June',
  'July', 'August', 'September', 'October', 'November', 'December',
];

/**
 * Extracts a normalized "YYYY-MM" month key from a date string (YYYY-MM-DD or ISO).
 */
export function extractYearMonth(dateStr?: string | null): string | null {
  if (!dateStr || typeof dateStr !== 'string') return null;
  const trimmed = dateStr.trim();
  const match = trimmed.match(/^(\d{4})[-/](\d{1,2})/);
  if (match) {
    const year = match[1];
    const month = match[2].padStart(2, '0');
    return `${year}-${month}`;
  }
  const d = new Date(trimmed);
  if (!isNaN(d.getTime())) {
    const year = d.getFullYear();
    const month = String(d.getMonth() + 1).padStart(2, '0');
    return `${year}-${month}`;
  }
  return null;
}

/**
 * Converts a "YYYY-MM" string into friendly labels.
 */
export function formatMonthLabels(yearMonth: string): {
  label: string;
  shortLabel: string;
  fullLabel: string;
} {
  const parts = yearMonth.split('-');
  const year = parseInt(parts[0], 10);
  const monthIdx = parseInt(parts[1], 10) - 1;

  if (isNaN(year) || isNaN(monthIdx) || monthIdx < 0 || monthIdx > 11) {
    return { label: yearMonth, shortLabel: yearMonth, fullLabel: yearMonth };
  }

  const shortMonth = MONTH_SHORT_NAMES[monthIdx];
  const fullMonth = MONTH_FULL_NAMES[monthIdx];

  return {
    label: `${shortMonth} ${year}`,
    shortLabel: shortMonth,
    fullLabel: `${fullMonth} ${year}`,
  };
}

/**
 * Generates contiguous "YYYY-MM" month keys.
 */
export function generateContiguousMonthKeys(
  monthsCount: number,
  referenceDate?: Date
): string[] {
  const ref = referenceDate ? new Date(referenceDate) : new Date();
  const result: string[] = [];

  for (let i = monthsCount - 1; i >= 0; i--) {
    const d = new Date(ref.getFullYear(), ref.getMonth() - i, 1);
    const y = d.getFullYear();
    const m = String(d.getMonth() + 1).padStart(2, '0');
    result.push(`${y}-${m}`);
  }

  return result;
}

/**
 * Deterministically aggregates valid invoices and payments into monthly trendline points.
 * - Invoices: excludes isVoid:true, status:'Void', and non-billable draft quotations
 * - Payments: excludes isVoid:true (reversed)
 */
export function calculateMonthlyRevenueTrends(
  invoices: Invoice[] = [],
  payments: Payment[] = [],
  rangeOption: RevenueTrendRange = '6M',
  referenceDate?: Date
): MonthlyRevenueTrendsSummary {
  const validInvoices = Array.isArray(invoices)
    ? invoices.filter(
        (inv) =>
          inv &&
          typeof inv === 'object' &&
          Boolean(inv.id) &&
          inv.isVoid !== true &&
          inv.status !== 'Void' &&
          inv.billingState !== 'quotation' &&
          inv.billingState !== 'rejected'
      )
    : [];

  const validPayments = Array.isArray(payments)
    ? payments.filter(
        (p) => p && typeof p === 'object' && Boolean(p.id) && p.isVoid !== true
      )
    : [];

  // Group invoices by month
  const invoicesByMonth = new Map<string, { total: number; count: number }>();
  for (const inv of validInvoices) {
    const ym = extractYearMonth(inv.date || inv.createdAt);
    if (!ym) continue;

    const amt =
      typeof inv.totalAmount === 'number'
        ? inv.totalAmount
        : parseFloat(String(inv.totalAmount ?? 0));
    const safeAmt = Number.isFinite(amt) && amt > 0 ? amt : 0;

    const current = invoicesByMonth.get(ym) || { total: 0, count: 0 };
    invoicesByMonth.set(ym, {
      total: current.total + safeAmt,
      count: current.count + 1,
    });
  }

  // Group payments by month
  const paymentsByMonth = new Map<string, { total: number; count: number }>();
  for (const p of validPayments) {
    const ym = extractYearMonth(p.date || p.createdAt);
    if (!ym) continue;

    const amt =
      typeof p.amount === 'number' ? p.amount : parseFloat(String(p.amount ?? 0));
    const safeAmt = Number.isFinite(amt) && amt > 0 ? amt : 0;

    const current = paymentsByMonth.get(ym) || { total: 0, count: 0 };
    paymentsByMonth.set(ym, {
      total: current.total + safeAmt,
      count: current.count + 1,
    });
  }

  // Determine contiguous month keys
  let monthKeys: string[] = [];

  if (rangeOption === '6M') {
    monthKeys = generateContiguousMonthKeys(6, referenceDate);
  } else if (rangeOption === '12M') {
    monthKeys = generateContiguousMonthKeys(12, referenceDate);
  } else {
    // 'All' time range: scan all existing keys from invoices & payments
    const allEncountered = new Set<string>([
      ...invoicesByMonth.keys(),
      ...paymentsByMonth.keys(),
    ]);

    if (allEncountered.size === 0) {
      monthKeys = generateContiguousMonthKeys(6, referenceDate);
    } else {
      const sortedKeys = Array.from(allEncountered).sort();
      const minKey = sortedKeys[0];
      const maxKey = sortedKeys[sortedKeys.length - 1];
      const nowKey = extractYearMonth(
        (referenceDate || new Date()).toISOString()
      )!;

      const upperKey = maxKey > nowKey ? maxKey : nowKey;

      const [minY, minM] = minKey.split('-').map((v) => parseInt(v, 10));
      const [maxY, maxM] = upperKey.split('-').map((v) => parseInt(v, 10));

      const start = new Date(minY, minM - 1, 1);
      const end = new Date(maxY, maxM - 1, 1);

      const generated: string[] = [];
      const cursor = new Date(start);
      while (cursor <= end) {
        const y = cursor.getFullYear();
        const m = String(cursor.getMonth() + 1).padStart(2, '0');
        generated.push(`${y}-${m}`);
        cursor.setMonth(cursor.getMonth() + 1);
      }
      monthKeys = generated.slice(-24); // Cap at 24 months for chart readability
    }
  }

  // Build data points
  let totalInvoiced = 0;
  let totalCollected = 0;
  let activeMonthsCount = 0;

  const dataPoints: MonthlyRevenueDataPoint[] = monthKeys.map((ym) => {
    const invData = invoicesByMonth.get(ym) || { total: 0, count: 0 };
    const payData = paymentsByMonth.get(ym) || { total: 0, count: 0 };

    const invoiced = Math.round(invData.total);
    const collected = Math.round(payData.total);

    if (invoiced > 0 || collected > 0) {
      activeMonthsCount++;
    }

    totalInvoiced += invoiced;
    totalCollected += collected;

    const collectionRate =
      invoiced > 0 ? Math.round((collected / invoiced) * 100) : collected > 0 ? 100 : 0;

    const { label, shortLabel, fullLabel } = formatMonthLabels(ym);

    return {
      month: ym,
      label,
      shortLabel,
      fullLabel,
      invoiced,
      collected,
      invoicesCount: invData.count,
      paymentsCount: payData.count,
      collectionRate,
      netVariance: collected - invoiced,
    };
  });

  const overallCollectionRate =
    totalInvoiced > 0
      ? Math.round((totalCollected / totalInvoiced) * 100)
      : totalCollected > 0
      ? 100
      : 0;

  return {
    dataPoints,
    totalInvoiced,
    totalCollected,
    overallCollectionRate,
    netVariance: totalCollected - totalInvoiced,
    activeMonthsCount,
  };
}

/**
 * Custom Tooltip Component for Recharts
 */
const CustomTooltip = ({ active, payload, label }: any) => {
  if (!active || !payload || !payload.length) return null;

  const dataPoint: MonthlyRevenueDataPoint = payload[0]?.payload;
  if (!dataPoint) return null;

  return (
    <div className="bg-[var(--app-surface-card,#FFFFFF)] border border-[var(--app-border,#E2E8F0)] rounded-xl shadow-xl p-3.5 min-w-[210px] text-xs space-y-2.5 z-50">
      <div className="flex items-center justify-between border-b border-[var(--app-border-subtle,#F1F5F9)] pb-2">
        <span className="font-bold text-[var(--app-text-primary,#0F172A)] text-xs flex items-center gap-1.5">
          <Calendar className="w-3.5 h-3.5 text-neutral-400" />
          {dataPoint.fullLabel}
        </span>
        <span
          className={`text-[10px] font-bold px-1.5 py-0.5 rounded ${
            dataPoint.collectionRate >= 80
              ? 'bg-emerald-100 text-emerald-800'
              : dataPoint.collectionRate >= 40
              ? 'bg-amber-100 text-amber-800'
              : 'bg-neutral-100 text-neutral-600'
          }`}
        >
          {dataPoint.collectionRate}% Collected
        </span>
      </div>

      <div className="space-y-1.5">
        {/* Invoiced */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded-full bg-[#2563EB] shrink-0" />
            <span className="text-[var(--app-text-muted,#64748B)]">Invoiced:</span>
          </div>
          <div className="text-right">
            <span className="font-mono font-bold text-[var(--app-text-primary,#0F172A)]">
              {formatAFN(dataPoint.invoiced, true)}
            </span>
            <span className="text-[10px] text-neutral-400 block">
              {dataPoint.invoicesCount} {dataPoint.invoicesCount === 1 ? 'bill' : 'bills'}
            </span>
          </div>
        </div>

        {/* Collected */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded-full bg-[#10B981] shrink-0" />
            <span className="text-[var(--app-text-muted,#64748B)]">Collected:</span>
          </div>
          <div className="text-right">
            <span className="font-mono font-bold text-emerald-600">
              {formatAFN(dataPoint.collected, true)}
            </span>
            <span className="text-[10px] text-neutral-400 block">
              {dataPoint.paymentsCount} {dataPoint.paymentsCount === 1 ? 'receipt' : 'receipts'}
            </span>
          </div>
        </div>

        {/* Net Period Variance */}
        <div className="pt-1.5 border-t border-[var(--app-border-subtle,#F1F5F9)] flex items-center justify-between text-[11px]">
          <span className="text-[var(--app-text-muted,#64748B)]">Net Difference:</span>
          <span
            className={`font-mono font-bold ${
              dataPoint.netVariance >= 0 ? 'text-emerald-600' : 'text-rose-600'
            }`}
          >
            {dataPoint.netVariance >= 0 ? '+' : ''}
            {formatAFN(dataPoint.netVariance, true)}
          </span>
        </div>
      </div>
    </div>
  );
};

export interface MonthlyRevenueTrendChartProps {
  invoices: Invoice[];
  payments: Payment[];
  className?: string;
  defaultRange?: RevenueTrendRange;
  title?: string;
  subtitle?: string;
}

export const MonthlyRevenueTrendChart: React.FC<MonthlyRevenueTrendChartProps> = ({
  invoices = [],
  payments = [],
  className = '',
  defaultRange = '6M',
  title = 'Monthly Revenue Trends',
  subtitle = 'Invoiced billing vs. cash collected over time',
}) => {
  const [range, setRange] = useState<RevenueTrendRange>(defaultRange);

  const summary = useMemo(() => {
    return calculateMonthlyRevenueTrends(invoices, payments, range);
  }, [invoices, payments, range]);

  const hasActivity = summary.totalInvoiced > 0 || summary.totalCollected > 0;

  return (
    <div
      id="monthly-revenue-trends-section"
      className={`bg-[var(--app-surface-card,#FFFFFF)] rounded-xl border border-[var(--app-border,#E2E8F0)] shadow-xs p-5 space-y-4 transition-colors ${className}`}
    >
      {/* Header & Controls */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-[var(--app-border-subtle,#F1F5F9)] pb-3">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-lg bg-blue-500/10 text-[#2563EB] flex items-center justify-center shrink-0">
            <TrendingUp className="w-4 h-4" />
          </div>
          <div>
            <h2
              id="monthly-revenue-trends-title"
              className="text-sm sm:text-base font-bold text-[var(--app-text-primary,#0F172A)] tracking-tight"
            >
              {title}
            </h2>
            <p
              id="monthly-revenue-trends-subtitle"
              className="text-xs text-[var(--app-text-muted,#64748B)]"
            >
              {subtitle}
            </p>
          </div>
        </div>

        {/* Time Window Range Switcher */}
        <div className="flex items-center bg-[var(--app-bg-muted,#F1F5F9)] p-1 rounded-lg self-start sm:self-auto border border-[var(--app-border-subtle,#F1F5F9)]">
          <button
            type="button"
            id="trend-range-6m-btn"
            onClick={() => setRange('6M')}
            className={`px-3 py-1 text-xs font-semibold rounded-md transition cursor-pointer ${
              range === '6M'
                ? 'bg-white text-neutral-900 shadow-xs font-bold'
                : 'text-neutral-500 hover:text-neutral-900'
            }`}
          >
            6 Months
          </button>
          <button
            type="button"
            id="trend-range-12m-btn"
            onClick={() => setRange('12M')}
            className={`px-3 py-1 text-xs font-semibold rounded-md transition cursor-pointer ${
              range === '12M'
                ? 'bg-white text-neutral-900 shadow-xs font-bold'
                : 'text-neutral-500 hover:text-neutral-900'
            }`}
          >
            12 Months
          </button>
          <button
            type="button"
            id="trend-range-all-btn"
            onClick={() => setRange('All')}
            className={`px-3 py-1 text-xs font-semibold rounded-md transition cursor-pointer ${
              range === 'All'
                ? 'bg-white text-neutral-900 shadow-xs font-bold'
                : 'text-neutral-500 hover:text-neutral-900'
            }`}
          >
            All Time
          </button>
        </div>
      </div>

      {/* Aggregate KPI Summary Badges for Period */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        {/* Total Invoiced */}
        <div
          id="trend-stat-invoiced"
          className="p-3 rounded-lg bg-[var(--app-bg-muted,#F8FAFC)] border border-[var(--app-border-subtle,#F1F5F9)] flex flex-col justify-between"
        >
          <div className="flex items-center justify-between text-neutral-500 mb-1">
            <span className="text-[10px] font-bold uppercase tracking-wide text-neutral-500">
              Total Invoiced
            </span>
            <FileText className="w-3.5 h-3.5 text-[#2563EB]" />
          </div>
          <p className="text-base sm:text-lg font-bold font-mono text-[var(--app-text-primary,#0F172A)] truncate">
            {formatAFN(summary.totalInvoiced, true)}
          </p>
          <span className="text-[10px] text-neutral-400 mt-0.5">
            {range === '6M' ? 'Past 6 months' : range === '12M' ? 'Past 12 months' : 'All recorded'}
          </span>
        </div>

        {/* Cash Collected */}
        <div
          id="trend-stat-collected"
          className="p-3 rounded-lg bg-emerald-50/50 border border-emerald-100 flex flex-col justify-between"
        >
          <div className="flex items-center justify-between text-emerald-800 mb-1">
            <span className="text-[10px] font-bold uppercase tracking-wide text-emerald-800">
              Cash Collected
            </span>
            <Banknote className="w-3.5 h-3.5 text-emerald-600" />
          </div>
          <p className="text-base sm:text-lg font-bold font-mono text-emerald-700 truncate">
            {formatAFN(summary.totalCollected, true)}
          </p>
          <span className="text-[10px] text-neutral-400 mt-0.5">Recorded cash in</span>
        </div>

        {/* Collection Efficiency Rate */}
        <div
          id="trend-stat-collection-rate"
          className="p-3 rounded-lg bg-[var(--app-bg-muted,#F8FAFC)] border border-[var(--app-border-subtle,#F1F5F9)] flex flex-col justify-between"
        >
          <div className="flex items-center justify-between text-neutral-500 mb-1">
            <span className="text-[10px] font-bold uppercase tracking-wide text-neutral-500">
              Collection Rate
            </span>
            <Percent className="w-3.5 h-3.5 text-amber-500" />
          </div>
          <p className="text-base sm:text-lg font-bold font-mono text-[var(--app-text-primary,#0F172A)] truncate">
            {summary.overallCollectionRate}%
          </p>
          <span className="text-[10px] text-neutral-400 mt-0.5">Collected / Invoiced</span>
        </div>

        {/* Net Period Balance */}
        <div
          id="trend-stat-net-period"
          className="p-3 rounded-lg bg-[var(--app-bg-muted,#F8FAFC)] border border-[var(--app-border-subtle,#F1F5F9)] flex flex-col justify-between"
        >
          <div className="flex items-center justify-between text-neutral-500 mb-1">
            <span className="text-[10px] font-bold uppercase tracking-wide text-neutral-500">
              Period Variance
            </span>
            {summary.netVariance >= 0 ? (
              <ArrowUpRight className="w-3.5 h-3.5 text-emerald-500" />
            ) : (
              <ArrowDownRight className="w-3.5 h-3.5 text-rose-500" />
            )}
          </div>
          <p
            className={`text-base sm:text-lg font-bold font-mono truncate ${
              summary.netVariance >= 0 ? 'text-emerald-700' : 'text-rose-600'
            }`}
          >
            {summary.netVariance >= 0 ? '+' : ''}
            {formatAFN(summary.netVariance, true)}
          </p>
          <span className="text-[10px] text-neutral-400 mt-0.5">Cash In - Invoiced</span>
        </div>
      </div>

      {/* Chart Canvas */}
      <div id="monthly-revenue-trends-chart" className="w-full h-72 sm:h-80 pt-2">
        <ResponsiveContainer width="100%" height="100%">
          <LineChart
            data={summary.dataPoints}
            margin={{ top: 12, right: 16, left: 0, bottom: 4 }}
          >
            <CartesianGrid
              strokeDasharray="3 3"
              stroke="var(--app-border, #E2E8F0)"
              opacity={0.6}
              vertical={false}
            />
            <XAxis
              dataKey="shortLabel"
              stroke="var(--app-text-muted, #64748B)"
              fontSize={11}
              tickLine={false}
              axisLine={{ stroke: 'var(--app-border, #E2E8F0)' }}
              dy={6}
            />
            <YAxis
              stroke="var(--app-text-muted, #64748B)"
              fontSize={10}
              tickLine={false}
              axisLine={{ stroke: 'var(--app-border, #E2E8F0)' }}
              tickFormatter={(val: number) => {
                if (val >= 1000000) return `${(val / 1000000).toFixed(1)}M`;
                if (val >= 1000) return `${Math.round(val / 1000)}k`;
                return `${val}`;
              }}
              dx={-4}
            />
            <Tooltip content={<CustomTooltip />} />
            <Legend
              verticalAlign="top"
              align="right"
              iconType="circle"
              iconSize={8}
              wrapperStyle={{
                paddingBottom: '12px',
                fontSize: '11px',
                fontWeight: 600,
              }}
            />
            <Line
              type="monotone"
              dataKey="invoiced"
              name="Invoiced Revenue"
              stroke="#2563EB"
              strokeWidth={2.5}
              dot={{ r: 3.5, strokeWidth: 1.5, fill: '#FFFFFF', stroke: '#2563EB' }}
              activeDot={{ r: 6, strokeWidth: 2, fill: '#2563EB', stroke: '#FFFFFF' }}
            />
            <Line
              type="monotone"
              dataKey="collected"
              name="Cash Collected"
              stroke="#10B981"
              strokeWidth={2.5}
              dot={{ r: 3.5, strokeWidth: 1.5, fill: '#FFFFFF', stroke: '#10B981' }}
              activeDot={{ r: 6, strokeWidth: 2, fill: '#10B981', stroke: '#FFFFFF' }}
            />
          </LineChart>
        </ResponsiveContainer>
      </div>

      {!hasActivity && (
        <div className="text-center py-2 text-xs text-neutral-400">
          No invoice billing or cash payment records found in this selected time range.
        </div>
      )}
    </div>
  );
};
