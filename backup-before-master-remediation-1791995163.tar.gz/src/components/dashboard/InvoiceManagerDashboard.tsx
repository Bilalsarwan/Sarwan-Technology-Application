import React from 'react';
import { InvoiceManagerDashboardData } from '../../services/dashboardAuthorization';
import { Invoice, Payment, BusinessSettings, CustomerRequest } from '../../types';
import {
  formatAFN,
  formatDate,
  calculateTotalPaidForInvoice,
  calculateRemaining,
} from '../../utils/format';
import {
  FileText,
  Users,
  DollarSign,
  AlertCircle,
  Plus,
  ChevronRight,
  Clock,
  CheckCircle2,
  MessageSquare,
  UserCheck,
  Receipt,
  UserX,
  Send,
} from 'lucide-react';
import { ActiveTab } from '../layout/Sidebar';
import { ExpenseStatusBadge } from '../../utils/expenseStatus';
import { MonthlyRevenueTrendChart } from './MonthlyRevenueTrendChart';

interface InvoiceManagerDashboardProps {
  data: InvoiceManagerDashboardData;
  settings: BusinessSettings;
  onNewInvoice: () => void;
  onNewCustomer: () => void;
  onAddPayment: () => void;
  onSelectInvoice: (invoice: Invoice) => void;
  onSelectPayment?: (payment: Payment) => void;
  onTabChange?: (tab: ActiveTab) => void;
  payments: Payment[];
  invoices?: Invoice[];
  monthlyRevenueChart?: React.ReactNode;
}

export const InvoiceManagerDashboard: React.FC<InvoiceManagerDashboardProps> = ({
  data,
  settings,
  onNewInvoice,
  onNewCustomer,
  onAddPayment,
  onSelectInvoice,
  onSelectPayment,
  onTabChange,
  payments,
  invoices,
  monthlyRevenueChart,
}) => {
  return (
    <div className="space-y-6">
      {/* Top Banner: Invoice Manager Console */}
      <div className="bg-neutral-900 text-white rounded-2xl p-6 sm:p-7 shadow-xs border border-neutral-800 flex flex-col lg:flex-row items-start lg:items-center justify-between gap-6">
        <div className="flex items-center gap-4">
          <div
            className="w-14 h-14 bg-white flex items-center justify-center shrink-0 overflow-hidden shadow-xs p-1.5"
            style={{ borderRadius: '100%', border: 'none' }}
          >
            <img
              src={settings?.logo || '/sarwan-logo.png'}
              alt="Sarwan Technology"
              className="max-h-full max-w-full object-contain"
              onError={(e) => {
                const target = e.currentTarget;
                if (target.src.endsWith('.png')) target.src = '/sarwan-logo.svg';
              }}
            />
          </div>
          <div>
            <div className="flex items-center gap-2 flex-wrap">
              <h1 className="text-xl sm:text-2xl font-black tracking-tight text-white">
                Invoice Manager Console
              </h1>
              <span className="text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 bg-sky-500/20 text-sky-400 border border-sky-500/30 rounded-full flex items-center gap-1">
                <FileText className="w-3 h-3" />
                Billing Operations
              </span>
            </div>
            <p className="text-xs text-neutral-400 mt-1">
              Manage billing documents, customer accounts, collector assignments, and incoming service requests.
            </p>
          </div>
        </div>

        {/* Quick Actions (Role-Permitted Only) */}
        <div className="flex flex-wrap items-center gap-2 w-full lg:w-auto">
          {data.quickActionsAllowed.canCreateInvoice && (
            <button
              onClick={onNewInvoice}
              className="flex-1 sm:flex-initial px-3.5 py-2 bg-[#2563EB] hover:bg-[#1D4ED8] active:bg-[#1E40AF] text-white text-xs font-bold rounded-lg shadow-xs transition inline-flex items-center justify-center gap-1.5 cursor-pointer active:scale-98 focus:outline-none focus-visible:ring-2 focus-visible:ring-[#2563EB]"
            >
              <Plus className="w-4 h-4" />
              New Invoice
            </button>
          )}

          {data.quickActionsAllowed.canManageCustomers && (
            <button
              onClick={onNewCustomer}
              className="flex-1 sm:flex-initial px-3 py-2 bg-neutral-800 hover:bg-neutral-700 text-white text-xs font-semibold rounded-lg border border-neutral-700 transition inline-flex items-center justify-center gap-1.5 cursor-pointer"
            >
              <Users className="w-3.5 h-3.5 text-orange-400" />
              New Customer
            </button>
          )}

          {data.quickActionsAllowed.canCollectPayment && (
            <button
              onClick={onAddPayment}
              className="flex-1 sm:flex-initial px-3 py-2 bg-neutral-800 hover:bg-neutral-700 text-white text-xs font-semibold rounded-lg border border-neutral-700 transition inline-flex items-center justify-center gap-1.5 cursor-pointer"
            >
              <DollarSign className="w-3.5 h-3.5 text-emerald-400" />
              Add Payment
            </button>
          )}

          {data.quickActionsAllowed.canManageRequests && onTabChange && (
            <button
              onClick={() => onTabChange('requests')}
              className="flex-1 sm:flex-initial px-3 py-2 bg-neutral-800 hover:bg-neutral-700 text-white text-xs font-semibold rounded-lg border border-neutral-700 transition inline-flex items-center justify-center gap-1.5 cursor-pointer"
            >
              <MessageSquare className="w-3.5 h-3.5 text-amber-400" />
              Requests ({data.customerRequests.pendingCount})
            </button>
          )}
        </div>
      </div>

      {/* Primary Metrics: Customers, Invoices, Outstanding */}
      <div className="grid grid-cols-2 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white rounded-xl p-4 border border-neutral-200 shadow-xs">
          <div className="flex items-center justify-between text-neutral-500 mb-2">
            <span className="text-[11px] font-bold uppercase tracking-wide">Total Customers</span>
            <Users className="w-4 h-4 text-orange-500" />
          </div>
          <p className="text-2xl font-bold font-mono text-neutral-900">{data.totalCustomersCount}</p>
          <span className="text-[10px] text-neutral-400 mt-1 block">Active client directory</span>
        </div>

        <div className="bg-white rounded-xl p-4 border border-neutral-200 shadow-xs">
          <div className="flex items-center justify-between text-neutral-500 mb-2">
            <span className="text-[11px] font-bold uppercase tracking-wide">Total Invoices</span>
            <FileText className="w-4 h-4 text-sky-500" />
          </div>
          <p className="text-2xl font-bold font-mono text-neutral-900">{data.totalInvoicesCount}</p>
          <span className="text-[10px] text-neutral-400 mt-1 block">Generated ST bills</span>
        </div>

        <div className="bg-neutral-900 text-white rounded-xl p-4 shadow-xs border border-neutral-800">
          <div className="flex items-center justify-between text-orange-400 mb-2">
            <span className="text-[11px] font-bold uppercase tracking-wide">Outstanding Balance</span>
            <DollarSign className="w-4 h-4 text-orange-400" />
          </div>
          <p className="text-xl sm:text-2xl font-black font-mono text-white truncate">
            {formatAFN(data.totalOutstandingAmount)}
          </p>
          <span className="text-[10px] text-neutral-400 mt-1 block">Receivable across all invoices</span>
        </div>

        <div className="bg-white rounded-xl p-4 border border-neutral-200 shadow-xs">
          <div className="flex items-center justify-between text-neutral-500 mb-2">
            <span className="text-[11px] font-bold uppercase tracking-wide">Customer Requests</span>
            <MessageSquare className="w-4 h-4 text-amber-500" />
          </div>
          <p className="text-2xl font-bold font-mono text-amber-600">{data.customerRequests.pendingCount}</p>
          <span className="text-[10px] text-neutral-400 mt-1 block">Awaiting review/quotation</span>
        </div>
      </div>

      {/* Invoice Status & Assignment Distribution */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3">
        <div className="bg-white p-4 rounded-xl border border-rose-100 bg-rose-50/20 shadow-xs">
          <span className="text-[11px] font-bold uppercase text-rose-700 block">Pending Invoices</span>
          <p className="text-xl font-bold font-mono text-rose-700 mt-1">{data.pendingInvoicesCount}</p>
          <p className="text-[10px] text-neutral-400 mt-0.5">Unpaid documents</p>
        </div>

        <div className="bg-white p-4 rounded-xl border border-amber-100 bg-amber-50/20 shadow-xs">
          <span className="text-[11px] font-bold uppercase text-amber-700 block">Partial Invoices</span>
          <p className="text-xl font-bold font-mono text-amber-700 mt-1">{data.partialInvoicesCount}</p>
          <p className="text-[10px] text-neutral-400 mt-0.5">Partially paid</p>
        </div>

        <div className="bg-white p-4 rounded-xl border border-emerald-100 bg-emerald-50/20 shadow-xs">
          <span className="text-[11px] font-bold uppercase text-emerald-700 block">Paid Invoices</span>
          <p className="text-xl font-bold font-mono text-emerald-700 mt-1">{data.paidInvoicesCount}</p>
          <p className="text-[10px] text-neutral-400 mt-0.5">Fully collected</p>
        </div>

        {/* Collector Assignment Status */}
        <div className="bg-white p-4 rounded-xl border border-sky-100 bg-sky-50/20 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-bold uppercase text-sky-800 block">Assigned Invoices</span>
            <UserCheck className="w-3.5 h-3.5 text-sky-600" />
          </div>
          <p className="text-xl font-bold font-mono text-sky-700 mt-1">{data.assignedInvoicesCount}</p>
          <p className="text-[10px] text-neutral-400 mt-0.5">Assigned to collectors</p>
        </div>

        <div className="bg-white p-4 rounded-xl border border-orange-100 bg-orange-50/20 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-bold uppercase text-orange-800 block">Unassigned Invoices</span>
            <UserX className="w-3.5 h-3.5 text-orange-600" />
          </div>
          <p className="text-xl font-bold font-mono text-orange-700 mt-1">{data.unassignedInvoicesCount}</p>
          <p className="text-[10px] text-neutral-400 mt-0.5">Need collector routing</p>
        </div>
      </div>

      {/* Collector Expenses Awaiting Manager Approval (Active Manager Queue) */}
      {data.pendingExpenses && data.pendingExpenses.count > 0 && (
        <div className="bg-white rounded-xl border border-amber-200 shadow-xs p-5 bg-gradient-to-r from-amber-50/40 to-transparent">
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-2">
              <Receipt className="w-4 h-4 text-amber-600" />
              <h3 className="text-sm font-bold text-neutral-900">
                Collector Expenses Awaiting Manager Approval
              </h3>
              <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-100 text-amber-800 border border-amber-200">
                {data.pendingExpenses.count} Pending Review
              </span>
            </div>
            {onTabChange && (
              <button
                type="button"
                onClick={() => {
                  const firstWithInvoice = data.pendingExpenses?.items.find((i) => i.invoiceId);
                  if (firstWithInvoice && invoices) {
                    const inv = invoices.find((i) => i.id === firstWithInvoice.invoiceId);
                    if (inv) {
                      onSelectInvoice(inv);
                      return;
                    }
                  }
                  onTabChange('invoices');
                }}
                className="text-xs text-amber-700 hover:text-amber-800 font-bold transition cursor-pointer"
              >
                Review All ({data.pendingExpenses.count})
              </button>
            )}
          </div>
          <p className="text-xs text-neutral-500 mb-3">
            Payment Collectors have submitted expense requests requiring your initial verification before routing to Super Admin.
          </p>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-2.5">
            {data.pendingExpenses.items.map((exp) => (
              <div
                key={exp.id}
                onClick={() => {
                  if (exp.invoiceId && invoices) {
                    const inv = invoices.find((i) => i.id === exp.invoiceId);
                    if (inv) {
                      onSelectInvoice(inv);
                      return;
                    }
                  }
                  onTabChange?.('invoices');
                }}
                className="p-3 rounded-xl bg-white border border-neutral-200 hover:border-amber-400 hover:shadow-xs transition cursor-pointer flex flex-col justify-between"
                title="Click to open invoice & review expense"
              >
                <div>
                  <div className="flex items-start justify-between gap-1">
                    <p className="font-bold text-neutral-900 text-xs truncate">{exp.title}</p>
                    <span className="font-mono font-bold text-xs text-neutral-900 shrink-0">
                      {formatAFN(exp.amount)}
                    </span>
                  </div>
                  <p className="text-[10px] text-neutral-500 mt-1 truncate">
                    Collector: <span className="font-semibold text-neutral-700">{exp.requestedByName || 'Collector'}</span>
                    {exp.billNumber ? ` • #${exp.billNumber}` : ''}
                  </p>
                </div>
                <div className="mt-2.5 pt-2 border-t border-neutral-100 flex items-center justify-between">
                  <ExpenseStatusBadge expense={exp} size="sm" />
                  <span className="text-[10px] text-amber-700 font-semibold hover:underline">
                    Review in Invoice &rarr;
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Monthly Revenue Trends Line Chart (Recharts) */}
      {monthlyRevenueChart ? (
        monthlyRevenueChart
      ) : (
        <MonthlyRevenueTrendChart
          invoices={invoices || []}
          payments={payments || []}
        />
      )}

      {/* Main Grid: Recent Invoices & Customer Service Requests */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Recent Invoices Table (2 cols) */}
        <div className="lg:col-span-2 bg-white rounded-xl border border-neutral-200 shadow-xs overflow-hidden">
          <div className="p-4 border-b border-neutral-200 flex items-center justify-between">
            <div>
              <h3 className="text-sm font-bold text-neutral-900">Recent Invoices &amp; Assignment</h3>
              <p className="text-xs text-neutral-500">Track invoice balances and assigned staff</p>
            </div>
            {onTabChange && (
              <button
                onClick={() => onTabChange('invoices')}
                className="text-xs text-orange-600 hover:text-orange-700 font-bold inline-flex items-center gap-1 transition cursor-pointer"
              >
                All Invoices <ChevronRight className="w-3.5 h-3.5" />
              </button>
            )}
          </div>

          {data.recentInvoices.length === 0 ? (
            <div className="p-8 text-center text-neutral-400 text-xs">
              <FileText className="w-7 h-7 text-neutral-300 mx-auto mb-2" />
              No invoices generated yet.
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-xs">
                <thead>
                  <tr className="bg-neutral-50 text-neutral-500 font-semibold border-b border-neutral-200 text-left">
                    <th className="py-2.5 px-3">Bill No.</th>
                    <th className="py-2.5 px-3">Customer</th>
                    <th className="py-2.5 px-3 text-right">Total</th>
                    <th className="py-2.5 px-3 text-center">Collector</th>
                    <th className="py-2.5 px-3 text-center">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-neutral-100">
                  {data.recentInvoices.map((inv) => (
                    <tr
                      key={inv.id}
                      onClick={() => onSelectInvoice(inv)}
                      className="hover:bg-neutral-50 cursor-pointer transition"
                    >
                      <td className="py-2.5 px-3 font-mono font-bold text-neutral-900">
                        {inv.billNumber}
                      </td>
                      <td className="py-2.5 px-3 font-medium text-neutral-800 truncate max-w-[140px]">
                        {inv.customerSnapshot?.name || 'Customer'}
                      </td>
                      <td className="py-2.5 px-3 text-right font-mono font-bold text-neutral-900">
                        {formatAFN(inv.totalAmount)}
                      </td>
                      <td className="py-2.5 px-3 text-center">
                        {inv.assignedCollectorName ? (
                          <span className="px-2 py-0.5 rounded-full text-[9px] font-semibold bg-sky-50 text-sky-700 border border-sky-200">
                            {inv.assignedCollectorName}
                          </span>
                        ) : (
                          <span className="px-2 py-0.5 rounded-full text-[9px] font-semibold bg-neutral-100 text-neutral-500">
                            Unassigned
                          </span>
                        )}
                      </td>
                      <td className="py-2.5 px-3 text-center">
                        <span
                          className={`px-2 py-0.5 rounded-full text-[9px] font-bold ${
                            inv.status === 'Paid'
                              ? 'bg-emerald-100 text-emerald-800'
                              : inv.status === 'Partially Paid'
                              ? 'bg-amber-100 text-amber-800'
                              : 'bg-rose-100 text-rose-800'
                          }`}
                        >
                          {inv.status}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>

        {/* Customer Service Requests Panel (1 col) */}
        <div className="bg-white rounded-xl border border-neutral-200 shadow-xs p-5">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              <MessageSquare className="w-4 h-4 text-amber-500" />
              <h3 className="text-sm font-bold text-neutral-900">Customer Requests</h3>
            </div>
            {onTabChange && (
              <button
                onClick={() => onTabChange('requests')}
                className="text-xs text-orange-600 hover:text-orange-700 font-bold transition cursor-pointer"
              >
                Manage ({data.customerRequests.pendingCount})
              </button>
            )}
          </div>

          {data.customerRequests.items.length === 0 ? (
            <div className="py-8 text-center text-neutral-400 text-xs">
              <CheckCircle2 className="w-6 h-6 text-emerald-500 mx-auto mb-1.5" />
              No pending customer requests right now.
            </div>
          ) : (
            <div className="space-y-2.5">
              {data.customerRequests.items.map((req) => (
                <div
                  key={req.id}
                  onClick={() => onTabChange && onTabChange('requests')}
                  className="p-3 rounded-xl bg-neutral-50 border border-neutral-200 hover:border-orange-200 transition cursor-pointer"
                >
                  <div className="flex items-start justify-between gap-2">
                    <p className="font-bold text-neutral-900 text-xs truncate">{req.title}</p>
                    <span className="text-[9px] font-bold uppercase px-1.5 py-0.5 rounded bg-amber-100 text-amber-800 shrink-0">
                      {req.status}
                    </span>
                  </div>
                  <p className="text-[11px] text-neutral-500 mt-1 line-clamp-2">{req.description}</p>
                  <div className="flex items-center justify-between text-[10px] text-neutral-400 mt-2">
                    <span>{req.customerName}</span>
                    <span>{formatDate(req.createdAt)}</span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Relevant Payments */}
      <div className="bg-white rounded-xl border border-neutral-200 shadow-xs overflow-hidden">
        <div className="p-4 border-b border-neutral-200 flex items-center justify-between">
          <div>
            <h3 className="text-sm font-bold text-neutral-900">Recent Cash Receipts</h3>
            <p className="text-xs text-neutral-500">Incoming payments applied to invoices</p>
          </div>
          {onTabChange && (
            <button
              onClick={() => onTabChange('payments')}
              className="text-xs text-emerald-700 hover:text-emerald-800 font-bold inline-flex items-center gap-1 transition cursor-pointer"
            >
              Payment Ledger <ChevronRight className="w-3.5 h-3.5" />
            </button>
          )}
        </div>

        {data.relevantPayments.length === 0 ? (
          <p className="text-xs text-neutral-400 py-8 text-center">No cash receipts recorded yet.</p>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-xs">
              <thead>
                <tr className="bg-neutral-50 text-neutral-500 font-semibold border-b border-neutral-200 text-left">
                  <th className="py-2.5 px-3">Date</th>
                  <th className="py-2.5 px-3">Bill No.</th>
                  <th className="py-2.5 px-3">Customer</th>
                  <th className="py-2.5 px-3 text-right">Amount</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-neutral-100">
                {data.relevantPayments.map((p) => (
                  <tr
                    key={p.id}
                    onClick={() => onSelectPayment && onSelectPayment(p)}
                    className="hover:bg-neutral-50 cursor-pointer transition"
                  >
                    <td className="py-2.5 px-3 text-neutral-500">{formatDate(p.date)}</td>
                    <td className="py-2.5 px-3 font-mono font-bold text-neutral-900">{p.billNumber}</td>
                    <td className="py-2.5 px-3 font-medium text-neutral-800 truncate max-w-[130px]">
                      {p.customerName || 'Customer'}
                    </td>
                    <td className="py-2.5 px-3 text-right font-mono font-bold text-emerald-700">
                      {formatAFN(p.amount)}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};
