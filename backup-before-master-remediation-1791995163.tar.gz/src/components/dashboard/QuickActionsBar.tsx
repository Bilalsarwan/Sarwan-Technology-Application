import React, { useState, useRef, useEffect } from 'react';
import {
  Plus,
  DollarSign,
  Users,
  Receipt,
  UserCheck,
  ChevronDown,
  Sparkles,
} from 'lucide-react';

export interface QuickActionsPermissions {
  canCreateInvoice?: boolean;
  canCollectPayment?: boolean;
  canManageCustomers?: boolean;
  canManageStaff?: boolean;
}

interface QuickActionsBarProps {
  onNewInvoice: () => void;
  onAddPayment: () => void;
  onNewCustomer: () => void;
  onManageStaff: () => void;
  permissions?: QuickActionsPermissions;
}

export const QuickActionsBar: React.FC<QuickActionsBarProps> = ({
  onNewInvoice,
  onAddPayment,
  onNewCustomer,
  onManageStaff,
  permissions = {
    canCreateInvoice: true,
    canCollectPayment: true,
    canManageCustomers: true,
    canManageStaff: true,
  },
}) => {
  const [isMoreOpen, setIsMoreOpen] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  const moreRef = useRef<HTMLDivElement>(null);
  const mobileRef = useRef<HTMLDivElement>(null);

  // Close dropdowns on outside click or Escape
  useEffect(() => {
    const handleOutsideClick = (e: MouseEvent) => {
      if (moreRef.current && !moreRef.current.contains(e.target as Node)) {
        setIsMoreOpen(false);
      }
      if (mobileRef.current && !mobileRef.current.contains(e.target as Node)) {
        setIsMobileMenuOpen(false);
      }
    };

    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        setIsMoreOpen(false);
        setIsMobileMenuOpen(false);
      }
    };

    document.addEventListener('mousedown', handleOutsideClick);
    document.addEventListener('keydown', handleKeyDown);
    return () => {
      document.removeEventListener('mousedown', handleOutsideClick);
      document.removeEventListener('keydown', handleKeyDown);
    };
  }, []);

  const hasMoreItems = Boolean(permissions.canManageStaff);

  return (
    <div
      id="quick-actions-bar"
      className="bg-white rounded-xl border border-neutral-200 shadow-xs p-3 sm:p-3.5 flex items-center justify-between gap-3"
    >
      <div className="flex items-center gap-2 shrink-0">
        <div className="w-8 h-8 rounded-lg bg-orange-50 text-[#F58220] flex items-center justify-center font-bold text-xs shrink-0 border border-orange-100">
          <Sparkles className="w-4 h-4" />
        </div>
        <div>
          <h3 className="text-xs sm:text-sm font-bold text-neutral-900 leading-tight">
            Quick Actions
          </h3>
          <p className="text-[11px] text-neutral-400 hidden sm:block leading-tight">
            Perform daily operations in 1-click
          </p>
        </div>
      </div>

      {/* 1. DESKTOP VIEW (lg+ / xl): All 5 actions in exact specified order */}
      <div className="hidden lg:flex items-center gap-2">
        {permissions.canCreateInvoice && (
          <button
            type="button"
            id="qa-desktop-new-invoice"
            onClick={onNewInvoice}
            className="px-3.5 py-2 bg-[#2563EB] hover:bg-[#1D4ED8] active:bg-[#1E40AF] text-white text-xs font-bold rounded-lg shadow-xs transition inline-flex items-center gap-1.5 cursor-pointer active:scale-98 whitespace-nowrap focus:outline-none focus-visible:ring-2 focus-visible:ring-[#2563EB]"
          >
            <Plus className="w-4 h-4" />
            <span>New Invoice</span>
          </button>
        )}

        {permissions.canCollectPayment && (
          <button
            type="button"
            id="qa-desktop-add-payment"
            onClick={onAddPayment}
            className="px-3 py-2 bg-neutral-100 hover:bg-neutral-200 active:bg-neutral-300 text-neutral-800 text-xs font-semibold rounded-lg border border-neutral-200/90 transition inline-flex items-center gap-1.5 cursor-pointer whitespace-nowrap active:scale-[0.98] focus:outline-none focus-visible:ring-2 focus-visible:ring-neutral-400"
          >
            <DollarSign className="w-3.5 h-3.5 text-emerald-600" />
            <span>Add Payment</span>
          </button>
        )}

        {permissions.canManageCustomers && (
          <button
            type="button"
            id="qa-desktop-new-customer"
            onClick={onNewCustomer}
            className="px-3 py-2 bg-neutral-100 hover:bg-neutral-200 active:bg-neutral-300 text-neutral-800 text-xs font-semibold rounded-lg border border-neutral-200/90 transition inline-flex items-center gap-1.5 cursor-pointer whitespace-nowrap active:scale-[0.98] focus:outline-none focus-visible:ring-2 focus-visible:ring-neutral-400"
          >
            <Users className="w-3.5 h-3.5 text-blue-600" />
            <span>New Customer</span>
          </button>
        )}

        {permissions.canManageStaff && (
          <button
            type="button"
            id="qa-desktop-manage-staff"
            onClick={onManageStaff}
            className="px-3 py-2 bg-neutral-100 hover:bg-neutral-200 active:bg-neutral-300 text-neutral-800 text-xs font-semibold rounded-lg border border-neutral-200/90 transition inline-flex items-center gap-1.5 cursor-pointer whitespace-nowrap active:scale-[0.98] focus:outline-none focus-visible:ring-2 focus-visible:ring-neutral-400"
          >
            <UserCheck className="w-3.5 h-3.5 text-sky-600" />
            <span>Manage Staff</span>
          </button>
        )}
      </div>

      {/* 2. TABLET VIEW (sm to lg): New Invoice | Add Payment | New Customer | More ▾ */}
      <div className="hidden sm:flex lg:hidden items-center gap-2">
        {permissions.canCreateInvoice && (
          <button
            type="button"
            id="qa-tablet-new-invoice"
            onClick={onNewInvoice}
            className="px-3 py-2 bg-[#2563EB] hover:bg-[#1D4ED8] active:bg-[#1E40AF] text-white text-xs font-bold rounded-lg shadow-xs transition inline-flex items-center gap-1.5 cursor-pointer active:scale-98 whitespace-nowrap focus:outline-none focus-visible:ring-2 focus-visible:ring-[#2563EB]"
          >
            <Plus className="w-4 h-4" />
            <span>New Invoice</span>
          </button>
        )}

        {permissions.canCollectPayment && (
          <button
            type="button"
            id="qa-tablet-add-payment"
            onClick={onAddPayment}
            className="px-3 py-2 bg-neutral-100 hover:bg-neutral-200 active:bg-neutral-300 text-neutral-800 text-xs font-semibold rounded-lg border border-neutral-200/90 transition inline-flex items-center gap-1.5 cursor-pointer whitespace-nowrap active:scale-[0.98] focus:outline-none focus-visible:ring-2 focus-visible:ring-neutral-400"
          >
            <DollarSign className="w-3.5 h-3.5 text-emerald-600" />
            <span>Add Payment</span>
          </button>
        )}

        {permissions.canManageCustomers && (
          <button
            type="button"
            id="qa-tablet-new-customer"
            onClick={onNewCustomer}
            className="px-3 py-2 bg-neutral-100 hover:bg-neutral-200 active:bg-neutral-300 text-neutral-800 text-xs font-semibold rounded-lg border border-neutral-200/90 transition inline-flex items-center gap-1.5 cursor-pointer whitespace-nowrap active:scale-[0.98] focus:outline-none focus-visible:ring-2 focus-visible:ring-neutral-400"
          >
            <Users className="w-3.5 h-3.5 text-blue-600" />
            <span>New Customer</span>
          </button>
        )}

        {hasMoreItems && (
          <div className="relative" ref={moreRef}>
            <button
              type="button"
              id="qa-tablet-more-btn"
              onClick={() => setIsMoreOpen((prev) => !prev)}
              className={`px-3 py-2 text-xs font-semibold rounded-lg border transition inline-flex items-center gap-1.5 cursor-pointer whitespace-nowrap active:scale-[0.98] focus:outline-none focus-visible:ring-2 focus-visible:ring-neutral-400 ${
                isMoreOpen
                  ? 'border-blue-500 bg-blue-50 text-blue-700'
                  : 'bg-neutral-100 hover:bg-neutral-200 active:bg-neutral-300 text-neutral-800 border-neutral-200/90'
              }`}
              aria-expanded={isMoreOpen}
              aria-haspopup="true"
            >
              <span>More</span>
              <ChevronDown
                className={`w-3.5 h-3.5 transition-transform duration-150 ${
                  isMoreOpen ? 'rotate-180 text-blue-600' : 'text-neutral-500'
                }`}
              />
            </button>

            {isMoreOpen && (
              <div className="absolute right-0 mt-2 w-48 bg-neutral-900 border border-neutral-700 rounded-xl shadow-2xl py-1.5 z-50 animate-in fade-in zoom-in-95 duration-100">
                <div className="px-3 py-1 text-[10px] uppercase font-bold tracking-wider text-neutral-400 border-b border-neutral-800 mb-1">
                  Additional Actions
                </div>
                {permissions.canManageStaff && (
                  <button
                    type="button"
                    onClick={() => {
                      setIsMoreOpen(false);
                      onManageStaff();
                    }}
                    className="w-full px-3.5 py-2 text-left text-xs text-neutral-200 hover:text-white hover:bg-neutral-800 transition flex items-center gap-2.5 cursor-pointer font-medium"
                  >
                    <UserCheck className="w-3.5 h-3.5 text-sky-400 shrink-0" />
                    <span>Manage Staff</span>
                  </button>
                )}
              </div>
            )}
          </div>
        )}
      </div>

      {/* 3. MOBILE VIEW (< sm): Single compact "+ Quick Actions ▾" dropdown */}
      <div className="relative block sm:hidden" ref={mobileRef}>
        <button
          type="button"
          id="qa-mobile-toggle-btn"
          onClick={() => setIsMobileMenuOpen((prev) => !prev)}
          className="px-3 py-1.5 bg-[#2563EB] hover:bg-[#1D4ED8] active:bg-[#1E40AF] text-white text-xs font-bold rounded-lg shadow-xs transition inline-flex items-center gap-1.5 cursor-pointer active:scale-98 whitespace-nowrap focus:outline-none focus-visible:ring-2 focus-visible:ring-[#2563EB]"
          aria-expanded={isMobileMenuOpen}
          aria-haspopup="true"
        >
          <Plus className="w-4 h-4" />
          <span>Quick Actions</span>
          <ChevronDown
            className={`w-3.5 h-3.5 transition-transform duration-150 ${
              isMobileMenuOpen ? 'rotate-180' : ''
            }`}
          />
        </button>

        {isMobileMenuOpen && (
          <div className="absolute right-0 mt-2 w-52 bg-neutral-900 border border-neutral-700 rounded-xl shadow-2xl py-1.5 z-50 animate-in fade-in zoom-in-95 duration-100">
            <div className="px-3.5 py-1 text-[10px] uppercase font-bold tracking-wider text-neutral-400 border-b border-neutral-800 mb-1">
              Quick Actions
            </div>

            {permissions.canCreateInvoice && (
              <button
                type="button"
                onClick={() => {
                  setIsMobileMenuOpen(false);
                  onNewInvoice();
                }}
                className="w-full px-3.5 py-2 text-left text-xs text-white hover:bg-neutral-800 transition flex items-center gap-2.5 cursor-pointer font-semibold"
              >
                <div className="p-1 rounded-md bg-blue-500/20 text-blue-400">
                  <Plus className="w-3.5 h-3.5" />
                </div>
                <span>New Invoice</span>
              </button>
            )}

            {permissions.canCollectPayment && (
              <button
                type="button"
                onClick={() => {
                  setIsMobileMenuOpen(false);
                  onAddPayment();
                }}
                className="w-full px-3.5 py-2 text-left text-xs text-neutral-200 hover:text-white hover:bg-neutral-800 transition flex items-center gap-2.5 cursor-pointer font-medium"
              >
                <div className="p-1 rounded-md bg-emerald-500/10 text-emerald-400">
                  <DollarSign className="w-3.5 h-3.5" />
                </div>
                <span>Add Payment</span>
              </button>
            )}

            {permissions.canManageCustomers && (
              <button
                type="button"
                onClick={() => {
                  setIsMobileMenuOpen(false);
                  onNewCustomer();
                }}
                className="w-full px-3.5 py-2 text-left text-xs text-neutral-200 hover:text-white hover:bg-neutral-800 transition flex items-center gap-2.5 cursor-pointer font-medium"
              >
                <div className="p-1 rounded-md bg-blue-500/10 text-blue-400">
                  <Users className="w-3.5 h-3.5" />
                </div>
                <span>New Customer</span>
              </button>
            )}

            {permissions.canManageStaff && (
              <button
                type="button"
                onClick={() => {
                  setIsMobileMenuOpen(false);
                  onManageStaff();
                }}
                className="w-full px-3.5 py-2 text-left text-xs text-neutral-200 hover:text-white hover:bg-neutral-800 transition flex items-center gap-2.5 cursor-pointer font-medium"
              >
                <div className="p-1 rounded-md bg-sky-500/10 text-sky-400">
                  <UserCheck className="w-3.5 h-3.5" />
                </div>
                <span>Manage Staff</span>
              </button>
            )}
          </div>
        )}
      </div>
    </div>
  );
};
