import React from 'react';
import { UserProfile } from '../../types';
import { getOfficialUserId, isProfileComplete } from '../../utils/profileCompletion';

interface StaffCardProps {
  user: UserProfile;
  onClick: () => void;
}

/**
 * Standard Staff Card matching the required final visual hierarchy:
 * 
 *       [ Profile Photo ]
 *          Full Name ✓
 *      Job Title / Position
 *           ST-U-5000
 *           ● Active
 * 
 * - All main card content centered.
 * - Profile Completion indicator (Blue ✓ or Red ✕) immediately to the right of Full Name.
 * - Position below Full Name.
 * - User ID pill badge below Position.
 * - Account Status badge (Active / Inactive / Suspended) at the bottom area.
 * - Entire card clickable with clean hover/touch feedback.
 */
export const StaffCard: React.FC<StaffCardProps> = ({ user, onClick }) => {
  const officialId = getOfficialUserId(user);
  const complete = isProfileComplete(user);

  // Determine canonical Account Status: 'active' | 'inactive' | 'suspended'
  const accountStatus: 'active' | 'inactive' | 'suspended' =
    user.status === 'suspended'
      ? 'suspended'
      : user.status === 'inactive' || user.isDeactivated
      ? 'inactive'
      : 'active';

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' || e.key === ' ') {
      e.preventDefault();
      onClick();
    }
  };

  return (
    <div
      role="button"
      tabIndex={0}
      onClick={onClick}
      onKeyDown={handleKeyDown}
      aria-label={`Staff member ${user.name}, ${user.jobTitle || 'No position'}, User ID ${officialId}, Profile ${complete ? 'Complete' : 'Incomplete'}, Account Status ${accountStatus}`}
      className="group bg-white rounded-2xl border border-neutral-200 p-5 shadow-2xs hover:shadow-md hover:border-orange-300 hover:bg-neutral-50/20 active:scale-[0.985] transition-all duration-150 cursor-pointer flex flex-col items-center text-center justify-between min-h-[224px] select-none h-full focus:outline-none focus-visible:ring-2 focus-visible:ring-orange-500"
    >
      {/* 1. Profile Photo (Top Center) */}
      <div className="w-16 h-16 rounded-full overflow-hidden border-2 border-neutral-200 group-hover:border-orange-400 shadow-2xs transition-colors shrink-0 flex items-center justify-center bg-neutral-100 mb-3">
        {user.photoURL ? (
          <img
            src={user.photoURL}
            alt={user.name}
            className="w-full h-full object-cover"
            referrerPolicy="no-referrer"
          />
        ) : (
          <span className="font-bold text-neutral-600 text-xl group-hover:text-orange-600 transition-colors">
            {user.name?.charAt(0).toUpperCase() || 'U'}
          </span>
        )}
      </div>

      {/* 2. Full Name + Profile Completion Indicator (Directly attached to the right of the name) */}
      <div className="w-full px-2 flex items-center justify-center gap-1.5 min-w-0">
        <span
          className="text-sm font-bold text-neutral-900 group-hover:text-orange-600 transition-colors truncate max-w-[85%]"
          title={user.name}
        >
          {user.name}
        </span>
        {complete ? (
          <span
            title="Profile Complete (All required verification fields filled)"
            className="text-blue-600 font-black text-sm shrink-0 leading-none select-none"
            aria-label="Profile Complete"
          >
            ✓
          </span>
        ) : (
          <span
            title="Profile Incomplete (Required fields missing - click to view and complete)"
            className="text-red-600 font-black text-sm shrink-0 leading-none select-none"
            aria-label="Profile Incomplete"
          >
            ✕
          </span>
        )}
      </div>

      {/* 3. Position / Job Title (Below Full Name) */}
      <p
        className="text-xs text-neutral-500 mt-1 truncate w-full px-2"
        title={user.jobTitle || 'No position specified'}
      >
        {user.jobTitle ? (
          user.jobTitle
        ) : (
          <span className="text-neutral-400 italic">No position specified</span>
        )}
      </p>

      {/* 4. User ID (Small clean pill badge below Position) */}
      <div className="mt-2.5">
        <span
          className="inline-flex items-center justify-center font-mono text-xs font-bold text-orange-700 bg-orange-50/90 px-2.5 py-0.5 rounded-full border border-orange-200 tracking-wider"
          title={`Permanent User ID: ${officialId}`}
        >
          {officialId}
        </span>
      </div>

      {/* 5. Account Status (Bottom of Card, Visually Separate from Profile Completion) */}
      <div className="mt-4 pt-3 w-full border-t border-neutral-150 flex items-center justify-center">
        {accountStatus === 'active' && (
          <span className="inline-flex items-center gap-1.5 text-xs font-semibold px-2.5 py-0.5 rounded-full bg-emerald-50 text-emerald-700 border border-emerald-200">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
            Active
          </span>
        )}
        {accountStatus === 'inactive' && (
          <span className="inline-flex items-center gap-1.5 text-xs font-semibold px-2.5 py-0.5 rounded-full bg-red-50 text-red-700 border border-red-200">
            <span className="w-1.5 h-1.5 rounded-full bg-red-500" />
            Inactive
          </span>
        )}
        {accountStatus === 'suspended' && (
          <span className="inline-flex items-center gap-1.5 text-xs font-semibold px-2.5 py-0.5 rounded-full bg-amber-50 text-amber-800 border border-amber-300">
            <span className="w-1.5 h-1.5 rounded-full bg-amber-500" />
            Suspended
          </span>
        )}
      </div>
    </div>
  );
};
