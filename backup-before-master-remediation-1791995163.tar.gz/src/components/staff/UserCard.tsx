import React, { useRef, useState } from 'react';
import { UserProfile, BusinessSettings } from '../../types';
import { getOfficialUserId, isProfileComplete, getProfileCompletionDetails } from '../../utils/profileCompletion';
import { safeHtml2Canvas } from '../../utils/pdf';
import { jsPDF } from 'jspdf';
import {
  Download,
  CheckCircle2,
  XCircle,
  Mail,
  Phone,
  Briefcase,
  Building2,
  Shield,
  Calendar,
  CreditCard,
  Loader2,
  Award,
  Sparkles,
  MapPin,
  IdCard,
} from 'lucide-react';

interface UserCardProps {
  user: UserProfile;
  settings?: BusinessSettings;
  onClose?: () => void;
  autoDownload?: boolean;
}

export const UserCard: React.FC<UserCardProps> = ({ user, settings, onClose, autoDownload = false }) => {
  const cardRef = useRef<HTMLDivElement>(null);
  const [downloading, setDownloading] = useState<boolean>(false);
  const [downloadSuccess, setDownloadSuccess] = useState<boolean>(false);

  const officialId = getOfficialUserId(user);
  const complete = isProfileComplete(user);
  const completionDetails = getProfileCompletionDetails(user);

  const companyName = settings?.companyName || 'SARWAN TECHNOLOGY';
  const companyPhone = settings?.phone || '+93 78 677 1010';
  const companyEmail = settings?.email || 'info@sarwantechnology.com';

  const roleLabels: Record<string, string> = {
    super_admin: 'Super Admin',
    invoice_manager: 'Invoice Manager',
    payment_collector: 'Payment Collector',
    customer: 'Customer',
  };

  // Auto trigger download if requested
  React.useEffect(() => {
    if (autoDownload && cardRef.current) {
      const timer = setTimeout(() => {
        handleDownloadPdf();
      }, 350);
      return () => clearTimeout(timer);
    }
  }, [autoDownload]);

  const handleDownloadPdf = async () => {
    if (!cardRef.current) return;
    setDownloading(true);
    setDownloadSuccess(false);

    try {
      // Capture element as high-DPI canvas
      const canvas = await safeHtml2Canvas(cardRef.current, {
        scale: 2.5,
        useCORS: true,
        allowTaint: true,
        backgroundColor: '#ffffff',
        logging: false,
      });

      const imgData = canvas.toDataURL('image/png');

      // Create PDF in standard credit-card / ID card proportion or A6 landscape
      // Card dimensions in mm: 140mm width x 90mm height (spacious high-definition badge)
      const pdf = new jsPDF({
        orientation: 'landscape',
        unit: 'mm',
        format: [140, 92],
      });

      pdf.addImage(imgData, 'PNG', 0, 0, 140, 92);
      pdf.save(`UserCard_${officialId}_${user.name.replace(/[^a-zA-Z0-9]/g, '_')}.pdf`);

      setDownloadSuccess(true);
      setTimeout(() => setDownloadSuccess(false), 3500);
    } catch (err) {
      console.error('Error generating PDF user card with canvas:', err);
      // Fallback direct jsPDF text-based generation if canvas capture failed
      try {
        const doc = new jsPDF({ orientation: 'landscape', unit: 'mm', format: [140, 92] });
        doc.setFillColor(30, 41, 59);
        doc.rect(0, 0, 140, 20, 'F');
        doc.setTextColor(255, 255, 255);
        doc.setFontSize(14);
        doc.setFont('helvetica', 'bold');
        doc.text(companyName, 70, 10, { align: 'center' });
        doc.setFontSize(8);
        doc.text('OFFICIAL EMPLOYEE IDENTIFICATION CARD', 70, 16, { align: 'center' });

        doc.setTextColor(15, 23, 42);
        doc.setFontSize(14);
        doc.text(user.name, 15, 32);

        doc.setFontSize(10);
        doc.setTextColor(245, 130, 32);
        doc.text(`ID: ${officialId}`, 15, 40);

        doc.setTextColor(51, 65, 85);
        doc.setFontSize(9);
        doc.text(`Position: ${user.jobTitle || 'Staff Member'}`, 15, 48);
        doc.text(`Department: ${user.department || 'General Operations'}`, 15, 54);
        doc.text(`Role: ${roleLabels[user.role] || user.role}`, 15, 60);
        doc.text(`Email: ${user.email}`, 15, 66);
        doc.text(`Phone: ${user.phone || '—'}`, 15, 72);
        doc.text(`Profile Status: ${complete ? 'COMPLETE (Verified)' : 'INCOMPLETE'}`, 15, 78);

        doc.save(`UserCard_${officialId}.pdf`);
        setDownloadSuccess(true);
      } catch (fallbackErr) {
        console.error('Fallback PDF generation also failed:', fallbackErr);
      }
    } finally {
      setDownloading(false);
    }
  };

  return (
    <div className="space-y-4">
      {/* Action Bar */}
      <div className="flex items-center justify-between bg-neutral-50 p-3 rounded-xl border border-neutral-200">
        <div className="flex items-center gap-2">
          <CreditCard className="w-4 h-4 text-orange-600" />
          <span className="text-xs font-bold text-neutral-800">
            Digital Employee ID Card
          </span>
        </div>
        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={handleDownloadPdf}
            disabled={downloading}
            className="inline-flex items-center gap-1.5 px-3.5 py-1.5 bg-[#2563EB] hover:bg-[#1D4ED8] active:bg-[#1E40AF] text-white text-xs font-bold rounded-lg shadow-xs transition cursor-pointer active:scale-98 disabled:opacity-50 focus:outline-none focus-visible:ring-2 focus-visible:ring-[#2563EB]"
          >
            {downloading ? (
              <>
                <Loader2 className="w-3.5 h-3.5 animate-spin" />
                <span>Generating PDF...</span>
              </>
            ) : (
              <>
                <Download className="w-3.5 h-3.5" />
                <span>Download User Card (PDF)</span>
              </>
            )}
          </button>
        </div>
      </div>

      {downloadSuccess && (
        <div className="p-2.5 bg-emerald-50 text-emerald-800 border border-emerald-200 rounded-lg text-xs font-semibold flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-600" />
          <span>Official User Card PDF downloaded successfully.</span>
        </div>
      )}

      {/* The Actual Badge Card Element (Designed for clean capture & print) */}
      <div className="flex justify-center p-2">
        <div
          ref={cardRef}
          className="w-[490px] h-[320px] bg-white rounded-2xl shadow-xl border border-neutral-300 overflow-hidden flex flex-col justify-between relative select-none font-sans"
          style={{ width: '490px', height: '320px', minWidth: '490px', minHeight: '320px' }}
        >
          {/* Card Top Brand Banner */}
          <div className="bg-gradient-to-r from-neutral-900 via-neutral-800 to-neutral-900 text-white px-5 py-3 flex items-center justify-between border-b-2 border-orange-500">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-lg bg-white/10 flex items-center justify-center font-black text-orange-400 border border-white/20 text-sm">
                ST
              </div>
              <div>
                <h4 className="text-xs font-black tracking-wider uppercase text-white leading-tight">
                  {companyName}
                </h4>
                <p className="text-[9px] text-neutral-400 uppercase tracking-widest font-semibold">
                  Commercial Security &amp; Technology
                </p>
              </div>
            </div>

            <div className="text-right">
              <span className="inline-block px-2 py-0.5 bg-orange-500 text-white text-[9px] font-mono font-bold rounded uppercase tracking-wider">
                Official Staff ID
              </span>
            </div>
          </div>

          {/* Card Body */}
          <div className="px-5 py-3 flex-1 flex gap-4 items-center">
            {/* Left: Profile Photo & ID */}
            <div className="flex flex-col items-center gap-2">
              <div className="relative">
                {user.photoURL ? (
                  <img
                    src={user.photoURL}
                    alt={user.name}
                    className="w-22 h-22 rounded-xl object-cover border-2 border-orange-500 shadow-sm bg-neutral-100"
                  />
                ) : (
                  <div className="w-22 h-22 rounded-xl bg-neutral-100 border-2 border-orange-400 flex items-center justify-center font-black text-neutral-700 text-2xl shadow-inner">
                    {user.name?.charAt(0).toUpperCase() || 'U'}
                  </div>
                )}
                {/* Status dot */}
                <div
                  className={`absolute -bottom-1 -right-1 w-5 h-5 rounded-full border-2 border-white flex items-center justify-center shadow-xs ${
                    user.status === 'active' && !user.isDeactivated ? 'bg-emerald-500 text-white' : 'bg-red-500 text-white'
                  }`}
                  title={user.status === 'active' ? 'Active' : 'Inactive'}
                >
                  <span className="text-[9px] font-bold">
                    {user.status === 'active' && !user.isDeactivated ? '✓' : '!'}
                  </span>
                </div>
              </div>

              {/* Immutable Official User ID Badge */}
              <div className="bg-neutral-900 text-orange-400 px-3 py-1 rounded-md text-center shadow-xs border border-neutral-700">
                <span className="text-[11px] font-mono font-black tracking-wider block">
                  {officialId}
                </span>
              </div>
            </div>

            {/* Right: Employee Details */}
            <div className="flex-1 space-y-1.5">
              <div>
                <h3 className="text-base font-black text-neutral-900 leading-tight">
                  {user.name}
                </h3>
                <p className="text-[11px] text-orange-600 font-bold tracking-tight">
                  {user.jobTitle || 'Staff Member'}
                </p>
              </div>

              <div className="grid grid-cols-2 gap-x-3 gap-y-1 text-[10px] text-neutral-600 pt-1 border-t border-neutral-150">
                <div>
                  <span className="text-neutral-400 block text-[9px] uppercase font-semibold">
                    Department
                  </span>
                  <span className="font-bold text-neutral-800 truncate block">
                    {user.department || 'General Operations'}
                  </span>
                </div>

                <div>
                  <span className="text-neutral-400 block text-[9px] uppercase font-semibold">
                    System Role
                  </span>
                  <span className="font-bold text-neutral-800 capitalize truncate block">
                    {roleLabels[user.role] || user.role}
                  </span>
                </div>

                <div>
                  <span className="text-neutral-400 block text-[9px] uppercase font-semibold">
                    Phone
                  </span>
                  <span className="font-mono font-semibold text-neutral-800 truncate block">
                    {user.phone || '—'}
                  </span>
                </div>

                <div>
                  <span className="text-neutral-400 block text-[9px] uppercase font-semibold">
                    Email
                  </span>
                  <span className="font-mono text-neutral-800 truncate block text-[9px]">
                    {user.email}
                  </span>
                </div>
              </div>

              {/* Profile Completion Indicator */}
              <div className="pt-1.5 flex items-center justify-between border-t border-neutral-150">
                <div className="flex items-center gap-1.5">
                  <span className="text-[9px] text-neutral-400 uppercase font-semibold">
                    Profile Verification:
                  </span>
                  {complete ? (
                    <span className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded text-[10px] font-bold bg-blue-100 text-blue-800 border border-blue-200">
                      <CheckCircle2 className="w-3 h-3 text-blue-600" />
                      <span>Verified ✓</span>
                    </span>
                  ) : (
                    <span className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded text-[10px] font-bold bg-red-100 text-red-800 border border-red-200">
                      <XCircle className="w-3 h-3 text-red-600" />
                      <span>Incomplete ✕ ({completionDetails.percentage}%)</span>
                    </span>
                  )}
                </div>

                {user.nationalId && (
                  <span className="text-[9px] font-mono text-neutral-500">
                    ID#: {user.nationalId}
                  </span>
                )}
              </div>
            </div>
          </div>

          {/* Card Footer Bar */}
          <div className="bg-neutral-50 px-5 py-2 border-t border-neutral-200 flex items-center justify-between text-[8px] text-neutral-400 font-mono">
            <span>Property of {companyName}</span>
            <span>Tel: {companyPhone}</span>
            <span className="font-bold text-neutral-500">SECURITY CREDENTIAL</span>
          </div>
        </div>
      </div>
    </div>
  );
};
