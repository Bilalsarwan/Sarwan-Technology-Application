import React, { useState, useEffect, useRef } from 'react';
import { UserProfile, BusinessSettings, EmployeeDocument, EmploymentStatus } from '../../types';
import { getOfficialUserId, isProfileComplete, getProfileCompletionDetails, REQUIRED_PROFILE_FIELDS } from '../../utils/profileCompletion';
import { updateUserProfile, getEmployeeDocuments } from '../../services/db';
import { uploadEmployeePdf, downloadEmployeePdf, deleteEmployeePdf, getDocumentBlobUrl, validatePdfFile } from '../../services/employeeDocuments';
import { ProfilePhotoUpload } from '../common/ProfilePhotoUpload';
import { toast } from '../../context/ToastContext';
import { UserCard } from './UserCard';
import {
  X,
  User,
  FileText,
  CreditCard,
  CheckCircle2,
  XCircle,
  Upload,
  Download,
  Trash2,
  Eye,
  Loader2,
  Calendar,
  Phone,
  Mail,
  Building2,
  Briefcase,
  Shield,
  AlertCircle,
  FileCheck,
  FileX,
  Info,
  Clock,
  ExternalLink,
  Palette,
} from 'lucide-react';
import { THEME_CATALOG } from '../../themes/catalog';

interface UserProfileModalProps {
  user: UserProfile;
  settings?: BusinessSettings;
  currentAdminId: string;
  currentAdminName: string;
  initialTab?: 'profile' | 'edit' | 'documents' | 'card';
  onClose: () => void;
  onProfileUpdated: (updatedUser: UserProfile) => void;
}

export const UserProfileModal: React.FC<UserProfileModalProps> = ({
  user,
  settings,
  currentAdminId,
  currentAdminName,
  initialTab = 'profile',
  onClose,
  onProfileUpdated,
}) => {
  const [activeTab, setActiveTab] = useState<'profile' | 'edit' | 'documents' | 'card'>(initialTab);

  // Form states for editing profile
  const [formData, setFormData] = useState({
    name: user.name || '',
    phone: user.phone || '',
    photoURL: user.photoURL || '',
    jobTitle: user.jobTitle || '',
    department: user.department || '',
    dateOfBirth: user.dateOfBirth || '',
    gender: user.gender || '',
    nationalId: user.nationalId || '',
    address: user.address || '',
    emergencyContactName: user.emergencyContactName || '',
    emergencyContactPhone: user.emergencyContactPhone || '',
    employmentStartDate: user.employmentStartDate || '',
    employmentStatus: user.employmentStatus || (user.status === 'active' ? 'active' : 'contract'),
    employeeCode: user.employeeCode || '',
    notes: user.notes || '',
    themePreference: user.themePreference || '',
  });

  const [savingProfile, setSavingProfile] = useState<boolean>(false);
  const [saveMessage, setSaveMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  // Documents state
  const [documents, setDocuments] = useState<EmployeeDocument[]>([]);
  const [loadingDocs, setLoadingDocs] = useState<boolean>(true);
  const [uploadingDoc, setUploadingDoc] = useState<boolean>(false);
  const [docUploadError, setDocUploadError] = useState<string | null>(null);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [docTitle, setDocTitle] = useState<string>('');
  const [isDragging, setIsDragging] = useState<boolean>(false);
  const [previewDocUrl, setPreviewDocUrl] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const officialId = getOfficialUserId(user);
  const completion = getProfileCompletionDetails(user);

  // Fetch employee documents
  useEffect(() => {
    let isMounted = true;
    async function loadDocs() {
      setLoadingDocs(true);
      try {
        const docs = await getEmployeeDocuments(user.id);
        if (isMounted) {
          setDocuments(docs);
        }
      } catch (err) {
        console.error('Error loading documents:', err);
      } finally {
        if (isMounted) setLoadingDocs(false);
      }
    }
    loadDocs();
    return () => {
      isMounted = false;
    };
  }, [user.id]);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleSaveProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaveMessage(null);

    if (!formData.name.trim()) {
      setSaveMessage({ type: 'error', text: 'Full Name is required.' });
      return;
    }

    setSavingProfile(true);
    try {
      const updated = await updateUserProfile(
        user.id,
        {
          name: formData.name.trim(),
          phone: formData.phone.trim(),
          photoURL: formData.photoURL.trim(),
          jobTitle: formData.jobTitle.trim(),
          department: formData.department.trim(),
          dateOfBirth: formData.dateOfBirth.trim(),
          gender: formData.gender as any,
          nationalId: formData.nationalId.trim(),
          address: formData.address.trim(),
          emergencyContactName: formData.emergencyContactName.trim(),
          emergencyContactPhone: formData.emergencyContactPhone.trim(),
          employmentStartDate: formData.employmentStartDate.trim(),
          employmentStatus: formData.employmentStatus as EmploymentStatus,
          employeeCode: formData.employeeCode.trim(),
          notes: formData.notes.trim(),
          themePreference: formData.themePreference || '',
        },
        currentAdminId,
        currentAdminName
      );

      setSaveMessage({
        type: 'success',
        text: 'Employee profile updated successfully. Status recalculated automatically.',
      });
      toast.success('Employee profile updated successfully.');
      onProfileUpdated(updated);
      setTimeout(() => setSaveMessage(null), 3000);
    } catch (err: any) {
      console.error('Error updating user profile:', err);
      const errMsg = err?.message || 'Failed to update profile.';
      setSaveMessage({ type: 'error', text: errMsg });
      toast.error(errMsg);
    } finally {
      setSavingProfile(false);
    }
  };

  // PDF File Selection & Drag-and-Drop
  const handleFileSelect = (file: File) => {
    setDocUploadError(null);
    const validation = validatePdfFile(file);
    if (!validation.isValid) {
      setDocUploadError(validation.error || 'Invalid file. Only genuine PDF documents up to 15MB are allowed.');
      setSelectedFile(null);
      return;
    }
    setSelectedFile(file);
    if (!docTitle) {
      // Suggest clean document title from file name
      const cleanName = file.name.replace(/\.pdf$/i, '').replace(/[_-]/g, ' ');
      setDocTitle(cleanName);
    }
  };

  const handleUploadDocument = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedFile) {
      setDocUploadError('Please select a PDF document to upload.');
      return;
    }

    setUploadingDoc(true);
    setDocUploadError(null);

    try {
      const newDoc = await uploadEmployeePdf({
        userId: user.id,
        file: selectedFile,
        documentName: docTitle.trim() || selectedFile.name,
        uploadedBy: currentAdminName,
      });

      setDocuments((prev) => [newDoc, ...prev]);
      toast.success(`Document "${newDoc.documentName}" uploaded successfully.`);
      setSelectedFile(null);
      setDocTitle('');
      if (fileInputRef.current) fileInputRef.current.value = '';
    } catch (err: any) {
      console.error('Document upload error:', err);
      const errMsg = err?.message || 'Failed to upload document.';
      setDocUploadError(errMsg);
      toast.error(errMsg);
    } finally {
      setUploadingDoc(false);
    }
  };

  const handleViewPdf = async (doc: EmployeeDocument) => {
    try {
      const blobUrl = await getDocumentBlobUrl(doc);
      setPreviewDocUrl(blobUrl);
    } catch (err: any) {
      toast.error(`Unable to open PDF preview: ${err?.message || 'File not accessible'}`);
    }
  };

  const handleDeleteDoc = async (docId: string, docName: string) => {
    if (!confirm(`Are you sure you want to permanently delete the document "${docName}"?`)) {
      return;
    }

    try {
      await deleteEmployeePdf(user.id, docId, currentAdminId, currentAdminName);
      setDocuments((prev) => prev.filter((d) => d.id !== docId));
      toast.success(`Document "${docName}" deleted successfully.`);
    } catch (err: any) {
      toast.error(`Failed to delete document: ${err?.message || 'Unknown error'}`);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-5 overflow-y-auto">
      <div className="w-full max-w-4xl bg-white rounded-2xl shadow-2xl border border-neutral-200 overflow-hidden my-auto flex flex-col max-h-[92vh]">
        {/* Header with User Snapshot & Navigation Tabs */}
        <div className="bg-neutral-900 text-white p-5 border-b border-neutral-800">
          <div className="flex items-start justify-between gap-4">
            <div className="flex items-center gap-4">
              {user.photoURL ? (
                <img
                  src={user.photoURL}
                  alt={user.name}
                  className="w-14 h-14 rounded-xl object-cover border-2 border-orange-500 shadow-sm"
                />
              ) : (
                <div className="w-14 h-14 rounded-xl bg-neutral-800 border-2 border-orange-500/60 flex items-center justify-center font-bold text-orange-400 text-xl shadow-inner">
                  {user.name?.charAt(0).toUpperCase() || 'U'}
                </div>
              )}

              <div>
                <div className="flex items-center gap-2 flex-wrap">
                  <h2 className="text-lg font-bold text-white tracking-tight">{user.name}</h2>
                  {/* Immutable User ID */}
                  <span className="px-2 py-0.5 bg-neutral-800 border border-neutral-700 text-orange-400 font-mono text-xs font-bold rounded">
                    {officialId}
                  </span>
                  {/* Status */}
                  <span
                    className={`px-2 py-0.5 text-[10px] font-bold rounded-full ${
                      user.status === 'active' && !user.isDeactivated
                        ? 'bg-emerald-950 text-emerald-300 border border-emerald-800'
                        : 'bg-red-950 text-red-300 border border-red-800'
                    }`}
                  >
                    {user.status === 'active' && !user.isDeactivated ? 'Active' : 'Inactive'}
                  </span>
                </div>

                <div className="flex items-center gap-3 text-xs text-neutral-400 mt-1 flex-wrap">
                  <span className="text-orange-400 font-semibold">{user.jobTitle || 'Staff Member'}</span>
                  <span>•</span>
                  <span>{user.department || 'Operations'}</span>
                  <span>•</span>
                  <span className="font-mono">@{user.username}</span>
                </div>
              </div>
            </div>

            <button
              type="button"
              onClick={onClose}
              className="p-1.5 text-neutral-400 hover:text-white rounded-lg hover:bg-neutral-800 transition cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Profile Completion Indicator Strip */}
          <div className="mt-4 pt-3 border-t border-neutral-800 flex items-center justify-between flex-wrap gap-2 text-xs">
            <div className="flex items-center gap-2">
              <span className="text-neutral-400">Profile Completion:</span>
              {completion.isComplete ? (
                <span className="inline-flex items-center gap-1 px-2 py-0.5 bg-blue-950/80 text-blue-300 border border-blue-800 rounded font-bold text-xs">
                  <CheckCircle2 className="w-3.5 h-3.5 text-blue-400" />
                  <span>Verified 100% Complete ✓</span>
                </span>
              ) : (
                <span className="inline-flex items-center gap-1 px-2 py-0.5 bg-red-950/80 text-red-300 border border-red-800 rounded font-bold text-xs">
                  <XCircle className="w-3.5 h-3.5 text-red-400" />
                  <span>Incomplete ({completion.percentage}%) ✕</span>
                </span>
              )}
            </div>

            <div className="w-48 bg-neutral-800 rounded-full h-2 overflow-hidden">
              <div
                className={`h-full transition-all duration-500 ${
                  completion.isComplete ? 'bg-blue-500' : 'bg-orange-500'
                }`}
                style={{ width: `${completion.percentage}%` }}
              />
            </div>
          </div>

          {/* Navigation Tabs */}
          <div className="flex items-center gap-1 mt-4 overflow-x-auto scrollbar-none">
            <button
              type="button"
              onClick={() => setActiveTab('profile')}
              className={`px-4 py-2 text-xs font-bold rounded-lg transition cursor-pointer flex items-center gap-1.5 ${
                activeTab === 'profile'
                  ? 'bg-white text-neutral-900 shadow-sm'
                  : 'text-neutral-400 hover:text-white hover:bg-neutral-800'
              }`}
            >
              <User className="w-3.5 h-3.5" />
              <span>Profile Overview</span>
            </button>

            <button
              type="button"
              onClick={() => setActiveTab('edit')}
              className={`px-4 py-2 text-xs font-bold rounded-lg transition cursor-pointer flex items-center gap-1.5 ${
                activeTab === 'edit'
                  ? 'bg-white text-neutral-900 shadow-sm'
                  : 'text-neutral-400 hover:text-white hover:bg-neutral-800'
              }`}
            >
              <Briefcase className="w-3.5 h-3.5" />
              <span>Edit / Complete Profile</span>
            </button>

            <button
              type="button"
              onClick={() => setActiveTab('documents')}
              className={`px-4 py-2 text-xs font-bold rounded-lg transition cursor-pointer flex items-center gap-1.5 ${
                activeTab === 'documents'
                  ? 'bg-white text-neutral-900 shadow-sm'
                  : 'text-neutral-400 hover:text-white hover:bg-neutral-800'
              }`}
            >
              <FileText className="w-3.5 h-3.5" />
              <span>Employee Documents ({documents.length})</span>
            </button>

            <button
              type="button"
              onClick={() => setActiveTab('card')}
              className={`px-4 py-2 text-xs font-bold rounded-lg transition cursor-pointer flex items-center gap-1.5 ${
                activeTab === 'card'
                  ? 'bg-white text-neutral-900 shadow-sm'
                  : 'text-neutral-400 hover:text-white hover:bg-neutral-800'
              }`}
            >
              <CreditCard className="w-3.5 h-3.5" />
              <span>Digital User Card</span>
            </button>
          </div>
        </div>

        {/* Modal Body */}
        <div className="flex-1 overflow-y-auto p-5 sm:p-6 bg-neutral-50/50">
          {/* TAB 1: PROFILE OVERVIEW */}
          {activeTab === 'profile' && (
            <div className="space-y-6">
              {/* Profile Completion Checklist Banner */}
              {!completion.isComplete ? (
                <div className="bg-red-50 border border-red-200 rounded-xl p-4 flex items-start gap-3">
                  <XCircle className="w-5 h-5 text-red-600 shrink-0 mt-0.5" />
                  <div className="flex-1 text-xs">
                    <h4 className="font-bold text-red-900">Profile Is Incomplete</h4>
                    <p className="text-red-700 mt-0.5">
                      This user account is fully active and functional, but missing required employee verification fields:
                    </p>
                    <div className="flex flex-wrap gap-1.5 mt-2">
                      {completion.missingFields.map((f) => (
                        <span
                          key={f.key}
                          className="px-2 py-0.5 bg-red-100 text-red-800 rounded font-semibold text-[11px]"
                        >
                          ✕ {f.label}
                        </span>
                      ))}
                    </div>
                    <button
                      type="button"
                      onClick={() => setActiveTab('edit')}
                      className="mt-3 px-3 py-1.5 bg-red-600 hover:bg-red-700 text-white rounded-lg font-bold text-xs transition cursor-pointer"
                    >
                      Complete Profile Now
                    </button>
                  </div>
                </div>
              ) : (
                <div className="bg-blue-50 border border-blue-200 rounded-xl p-4 flex items-center justify-between gap-3 text-xs">
                  <div className="flex items-center gap-2.5">
                    <CheckCircle2 className="w-5 h-5 text-blue-600 shrink-0" />
                    <div>
                      <h4 className="font-bold text-blue-900">Profile Complete &amp; Verified</h4>
                      <p className="text-blue-700 mt-0.5">
                        All mandatory employee identity, employment, and contact fields have been submitted and verified.
                      </p>
                    </div>
                  </div>
                  <span className="px-2.5 py-1 bg-blue-100 text-blue-800 font-bold rounded-md font-mono">
                    ✓ Verified
                  </span>
                </div>
              )}

              {/* 3 Detail Grid Cards */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                {/* 1. Personal Information */}
                <div className="bg-white rounded-xl border border-neutral-200 p-4 shadow-xs space-y-3">
                  <div className="flex items-center gap-2 pb-2 border-b border-neutral-100">
                    <User className="w-4 h-4 text-orange-600" />
                    <h4 className="text-xs font-bold text-neutral-800 uppercase tracking-wider">
                      Personal Information
                    </h4>
                  </div>

                  <div className="space-y-2 text-xs">
                    <div>
                      <span className="text-[10px] text-neutral-400 block uppercase font-semibold">Full Name</span>
                      <span className="font-semibold text-neutral-900">{user.name}</span>
                    </div>
                    <div>
                      <span className="text-[10px] text-neutral-400 block uppercase font-semibold">National ID / Tazkira</span>
                      <span className="font-mono text-neutral-800">{user.nationalId || '—'}</span>
                    </div>
                    <div>
                      <span className="text-[10px] text-neutral-400 block uppercase font-semibold">Date of Birth</span>
                      <span className="text-neutral-800">{user.dateOfBirth || '—'}</span>
                    </div>
                    <div>
                      <span className="text-[10px] text-neutral-400 block uppercase font-semibold">Gender</span>
                      <span className="text-neutral-800 capitalize">{user.gender || '—'}</span>
                    </div>
                    <div>
                      <span className="text-[10px] text-neutral-400 block uppercase font-semibold">Address</span>
                      <span className="text-neutral-800">{user.address || '—'}</span>
                    </div>
                  </div>
                </div>

                {/* 2. Employment Information */}
                <div className="bg-white rounded-xl border border-neutral-200 p-4 shadow-xs space-y-3">
                  <div className="flex items-center gap-2 pb-2 border-b border-neutral-100">
                    <Briefcase className="w-4 h-4 text-orange-600" />
                    <h4 className="text-xs font-bold text-neutral-800 uppercase tracking-wider">
                      Employment Information
                    </h4>
                  </div>

                  <div className="space-y-2 text-xs">
                    <div>
                      <span className="text-[10px] text-neutral-400 block uppercase font-semibold">Immutable User ID</span>
                      <span className="font-mono font-bold text-orange-600 bg-orange-50 px-2 py-0.5 rounded inline-block">
                        {officialId}
                      </span>
                    </div>
                    <div>
                      <span className="text-[10px] text-neutral-400 block uppercase font-semibold">Position / Job Title</span>
                      <span className="font-semibold text-neutral-900">{user.jobTitle || '—'}</span>
                    </div>
                    <div>
                      <span className="text-[10px] text-neutral-400 block uppercase font-semibold">Department</span>
                      <span className="text-neutral-800">{user.department || '—'}</span>
                    </div>
                    <div>
                      <span className="text-[10px] text-neutral-400 block uppercase font-semibold">System Role</span>
                      <span className="text-neutral-800 capitalize font-medium">{user.role.replace('_', ' ')}</span>
                    </div>
                    <div>
                      <span className="text-[10px] text-neutral-400 block uppercase font-semibold">Employment Status</span>
                      <span className="capitalize text-neutral-800">{user.employmentStatus || 'Active'}</span>
                    </div>
                    <div>
                      <span className="text-[10px] text-neutral-400 block uppercase font-semibold">Start Date</span>
                      <span className="text-neutral-800">{user.employmentStartDate || '—'}</span>
                    </div>
                  </div>
                </div>

                {/* 3. Contact & Emergency Details */}
                <div className="bg-white rounded-xl border border-neutral-200 p-4 shadow-xs space-y-3">
                  <div className="flex items-center gap-2 pb-2 border-b border-neutral-100">
                    <Phone className="w-4 h-4 text-orange-600" />
                    <h4 className="text-xs font-bold text-neutral-800 uppercase tracking-wider">
                      Contact &amp; Emergency
                    </h4>
                  </div>

                  <div className="space-y-2 text-xs">
                    <div>
                      <span className="text-[10px] text-neutral-400 block uppercase font-semibold">Phone</span>
                      <span className="font-mono font-medium text-neutral-900">{user.phone || '—'}</span>
                    </div>
                    <div>
                      <span className="text-[10px] text-neutral-400 block uppercase font-semibold">Email</span>
                      <span className="font-mono text-neutral-800">{user.email}</span>
                    </div>
                    <div>
                      <span className="text-[10px] text-neutral-400 block uppercase font-semibold">Emergency Contact</span>
                      <span className="font-semibold text-neutral-800">{user.emergencyContactName || '—'}</span>
                    </div>
                    <div>
                      <span className="text-[10px] text-neutral-400 block uppercase font-semibold">Emergency Phone</span>
                      <span className="font-mono text-neutral-800">{user.emergencyContactPhone || '—'}</span>
                    </div>
                    <div>
                      <span className="text-[10px] text-neutral-400 block uppercase font-semibold">Administrative Notes</span>
                      <span className="text-neutral-600 italic">{user.notes || 'No administrative notes recorded.'}</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* TAB 2: EDIT / COMPLETE PROFILE */}
          {activeTab === 'edit' && (
            <form onSubmit={handleSaveProfile} className="space-y-6">
              {saveMessage && (
                <div
                  className={`p-3 rounded-xl text-xs font-semibold flex items-center gap-2 border ${
                    saveMessage.type === 'success'
                      ? 'bg-emerald-50 text-emerald-800 border-emerald-200'
                      : 'bg-red-50 text-red-800 border-red-200'
                  }`}
                >
                  {saveMessage.type === 'success' ? (
                    <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                  ) : (
                    <AlertCircle className="w-4 h-4 text-red-600" />
                  )}
                  <span>{saveMessage.text}</span>
                </div>
              )}

              {/* Immutable User ID Notice */}
              <div className="bg-amber-50 border border-amber-200 rounded-xl p-3 flex items-center justify-between text-xs">
                <div className="flex items-center gap-2">
                  <Shield className="w-4 h-4 text-amber-600" />
                  <span className="text-amber-900 font-semibold">
                    Immutable Official User ID:
                  </span>
                  <span className="px-2 py-0.5 bg-white border border-amber-300 font-mono font-bold text-amber-800 rounded">
                    {officialId}
                  </span>
                </div>
                <span className="text-[11px] text-amber-700 italic">
                  Read-only &amp; permanent (ST-U-XXXX standard)
                </span>
              </div>

              {/* Profile Photo */}
              <div className="bg-white p-4 rounded-xl border border-neutral-200 shadow-xs">
                <label className="block text-xs font-bold text-neutral-800 mb-2">
                  Profile Photo
                </label>
                <ProfilePhotoUpload
                  value={formData.photoURL ?? ''}
                  currentPhotoURL={formData.photoURL ?? ''}
                  onChange={(url) => setFormData((prev) => ({ ...prev, photoURL: url }))}
                  onPhotoChange={(url) => setFormData((prev) => ({ ...prev, photoURL: url }))}
                  name={formData.name || 'Staff Member'}
                />
              </div>

              {/* Section 1: Personal Information */}
              <div className="bg-white p-5 rounded-xl border border-neutral-200 shadow-xs space-y-4">
                <h4 className="text-xs font-bold text-neutral-800 uppercase tracking-wider flex items-center gap-2 pb-2 border-b border-neutral-100">
                  <User className="w-4 h-4 text-orange-600" />
                  <span>Personal Information</span>
                </h4>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-semibold text-neutral-700 mb-1">
                      Full Name <span className="text-red-500">*</span>
                    </label>
                    <input
                      type="text"
                      name="name"
                      value={formData.name ?? ''}
                      onChange={handleInputChange}
                      required
                      placeholder="e.g. Ahmad Tariq"
                      className="w-full px-3 py-2 border border-neutral-300 rounded-lg text-xs focus:ring-1 focus:ring-orange-500 focus:outline-none"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-neutral-700 mb-1">
                      National ID / Identification Number (Tazkira) <span className="text-red-500">*</span>
                    </label>
                    <input
                      type="text"
                      name="nationalId"
                      value={formData.nationalId ?? ''}
                      onChange={handleInputChange}
                      placeholder="e.g. 1402-98765"
                      className="w-full px-3 py-2 border border-neutral-300 rounded-lg text-xs focus:ring-1 focus:ring-orange-500 focus:outline-none"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-neutral-700 mb-1">
                      Date of Birth
                    </label>
                    <input
                      type="date"
                      name="dateOfBirth"
                      value={formData.dateOfBirth ?? ''}
                      onChange={handleInputChange}
                      className="w-full px-3 py-2 border border-neutral-300 rounded-lg text-xs focus:ring-1 focus:ring-orange-500 focus:outline-none"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-neutral-700 mb-1">
                      Gender
                    </label>
                    <select
                      name="gender"
                      value={formData.gender ?? ''}
                      onChange={handleInputChange}
                      className="w-full px-3 py-2 border border-neutral-300 rounded-lg text-xs focus:ring-1 focus:ring-orange-500 focus:outline-none bg-white"
                    >
                      <option value="">Select gender...</option>
                      <option value="male">Male</option>
                      <option value="female">Female</option>
                      <option value="other">Other</option>
                    </select>
                  </div>

                  <div className="sm:col-span-2">
                    <label className="block text-xs font-semibold text-neutral-700 mb-1">
                      Residential / Contact Address <span className="text-red-500">*</span>
                    </label>
                    <input
                      type="text"
                      name="address"
                      value={formData.address ?? ''}
                      onChange={handleInputChange}
                      placeholder="e.g. Street 4, Shahr-e-Naw, Kabul, Afghanistan"
                      className="w-full px-3 py-2 border border-neutral-300 rounded-lg text-xs focus:ring-1 focus:ring-orange-500 focus:outline-none"
                    />
                  </div>
                </div>
              </div>

              {/* Section 2: Contact Information */}
              <div className="bg-white p-5 rounded-xl border border-neutral-200 shadow-xs space-y-4">
                <h4 className="text-xs font-bold text-neutral-800 uppercase tracking-wider flex items-center gap-2 pb-2 border-b border-neutral-100">
                  <Phone className="w-4 h-4 text-orange-600" />
                  <span>Contact &amp; Emergency Details</span>
                </h4>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-semibold text-neutral-700 mb-1">
                      Phone Number <span className="text-red-500">*</span>
                    </label>
                    <input
                      type="tel"
                      name="phone"
                      value={formData.phone ?? ''}
                      onChange={handleInputChange}
                      placeholder="+93 78 123 4567"
                      className="w-full px-3 py-2 border border-neutral-300 rounded-lg text-xs focus:ring-1 focus:ring-orange-500 focus:outline-none"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-neutral-700 mb-1">
                      Email Address (Permanent Account ID)
                    </label>
                    <input
                      type="email"
                      value={user.email || ''}
                      disabled
                      className="w-full px-3 py-2 border border-neutral-200 bg-neutral-100 rounded-lg text-xs text-neutral-500 cursor-not-allowed font-mono"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-neutral-700 mb-1">
                      Emergency Contact Name
                    </label>
                    <input
                      type="text"
                      name="emergencyContactName"
                      value={formData.emergencyContactName ?? ''}
                      onChange={handleInputChange}
                      placeholder="e.g. Mohammad Tariq (Brother)"
                      className="w-full px-3 py-2 border border-neutral-300 rounded-lg text-xs focus:ring-1 focus:ring-orange-500 focus:outline-none"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-neutral-700 mb-1">
                      Emergency Contact Phone
                    </label>
                    <input
                      type="tel"
                      name="emergencyContactPhone"
                      value={formData.emergencyContactPhone ?? ''}
                      onChange={handleInputChange}
                      placeholder="+93 79 987 6543"
                      className="w-full px-3 py-2 border border-neutral-300 rounded-lg text-xs focus:ring-1 focus:ring-orange-500 focus:outline-none"
                    />
                  </div>
                </div>
              </div>

              {/* Section 3: Employment Information */}
              <div className="bg-white p-5 rounded-xl border border-neutral-200 shadow-xs space-y-4">
                <h4 className="text-xs font-bold text-neutral-800 uppercase tracking-wider flex items-center gap-2 pb-2 border-b border-neutral-100">
                  <Briefcase className="w-4 h-4 text-orange-600" />
                  <span>Employment Information</span>
                </h4>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-semibold text-neutral-700 mb-1">
                      Position / Job Title <span className="text-red-500">*</span>
                    </label>
                    <input
                      type="text"
                      name="jobTitle"
                      value={formData.jobTitle ?? ''}
                      onChange={handleInputChange}
                      placeholder="e.g. CCTV &amp; Security Technician"
                      className="w-full px-3 py-2 border border-neutral-300 rounded-lg text-xs focus:ring-1 focus:ring-orange-500 focus:outline-none"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-neutral-700 mb-1">
                      Department <span className="text-red-500">*</span>
                    </label>
                    <input
                      type="text"
                      name="department"
                      value={formData.department ?? ''}
                      onChange={handleInputChange}
                      placeholder="e.g. Technical Operations / Finance"
                      className="w-full px-3 py-2 border border-neutral-300 rounded-lg text-xs focus:ring-1 focus:ring-orange-500 focus:outline-none"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-neutral-700 mb-1">
                      Employment Status
                    </label>
                    <select
                      name="employmentStatus"
                      value={formData.employmentStatus ?? 'active'}
                      onChange={handleInputChange}
                      className="w-full px-3 py-2 border border-neutral-300 rounded-lg text-xs focus:ring-1 focus:ring-orange-500 focus:outline-none bg-white"
                    >
                      <option value="active">Active (Full-Time)</option>
                      <option value="permanent">Permanent</option>
                      <option value="contract">Contract</option>
                      <option value="probation">Probationary Period</option>
                      <option value="on_leave">On Leave</option>
                      <option value="terminated">Terminated</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-neutral-700 mb-1">
                      Employment Start Date
                    </label>
                    <input
                      type="date"
                      name="employmentStartDate"
                      value={formData.employmentStartDate ?? ''}
                      onChange={handleInputChange}
                      className="w-full px-3 py-2 border border-neutral-300 rounded-lg text-xs focus:ring-1 focus:ring-orange-500 focus:outline-none"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-neutral-700 mb-1">
                      Employee Code (Optional)
                    </label>
                    <input
                      type="text"
                      name="employeeCode"
                      value={formData.employeeCode ?? ''}
                      onChange={handleInputChange}
                      placeholder="e.g. EMP-101"
                      className="w-full px-3 py-2 border border-neutral-300 rounded-lg text-xs focus:ring-1 focus:ring-orange-500 focus:outline-none"
                    />
                  </div>

                  <div className="sm:col-span-2">
                    <label className="block text-xs font-semibold text-neutral-700 mb-1">
                      Administrative Notes
                    </label>
                    <textarea
                      name="notes"
                      rows={2}
                      value={formData.notes ?? ''}
                      onChange={handleInputChange}
                      placeholder="Internal administrative comments, certifications, skills, etc."
                      className="w-full px-3 py-2 border border-neutral-300 rounded-lg text-xs focus:ring-1 focus:ring-orange-500 focus:outline-none"
                    />
                  </div>
                </div>
              </div>

              {/* Section 4: Workspace Theme Preference */}
              <div className="bg-white p-5 rounded-xl border border-neutral-200 shadow-xs space-y-4">
                <h4 className="text-xs font-bold text-neutral-800 uppercase tracking-wider flex items-center gap-2 pb-2 border-b border-neutral-100">
                  <Palette className="w-4 h-4 text-orange-600" />
                  <span>Workspace Theme Preference</span>
                </h4>

                <div>
                  <label className="block text-xs font-semibold text-neutral-700 mb-1">
                    Select Personal Theme
                  </label>
                  <select
                    name="themePreference"
                    value={formData.themePreference ?? ''}
                    onChange={handleInputChange}
                    className="w-full px-3 py-2 border border-neutral-300 rounded-lg text-xs focus:ring-1 focus:ring-orange-500 focus:outline-none bg-white"
                  >
                    <option value="">Default (Sarwan Classic Light)</option>
                    {THEME_CATALOG.map((t) => (
                      <option key={t.id} value={t.id}>
                        {t.name} — {t.mode.toUpperCase()} ({t.tagline})
                      </option>
                    ))}
                  </select>
                  <p className="text-[11px] text-neutral-500 mt-1.5">
                    Customizes the interface colors, buttons, and surfaces when you are logged into your account.
                  </p>
                </div>
              </div>

              {/* Submit Buttons */}
              <div className="flex items-center justify-end gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => {
                    if (initialTab === 'edit') {
                      onClose();
                    } else {
                      setActiveTab('profile');
                    }
                  }}
                  className="px-4 py-2 border border-neutral-300 rounded-xl text-xs font-semibold text-neutral-700 hover:bg-neutral-100 transition cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={savingProfile}
                  className="inline-flex items-center gap-2 px-5 py-2 bg-[#2563EB] hover:bg-[#1D4ED8] active:bg-[#1E40AF] text-white text-xs font-bold rounded-xl shadow-xs transition cursor-pointer disabled:opacity-50 focus:outline-none focus-visible:ring-2 focus-visible:ring-[#2563EB]"
                >
                  {savingProfile ? (
                    <>
                      <Loader2 className="w-4 h-4 animate-spin" />
                      <span>Saving Profile...</span>
                    </>
                  ) : (
                    <span>Save &amp; Update Profile</span>
                  )}
                </button>
              </div>
            </form>
          )}

          {/* TAB 3: EMPLOYEE DOCUMENTS (PDF ONLY) */}
          {activeTab === 'documents' && (
            <div className="space-y-6">
              {/* PDF Upload Card */}
              <div className="bg-white p-5 rounded-xl border border-neutral-200 shadow-xs space-y-4">
                <div>
                  <h4 className="text-xs font-bold text-neutral-800 uppercase tracking-wider flex items-center gap-2">
                    <Upload className="w-4 h-4 text-orange-600" />
                    <span>Upload Employee Document (PDF Only)</span>
                  </h4>
                  <p className="text-[11px] text-neutral-500 mt-0.5">
                    Official employee documentation. Strictly Adobe PDF (.pdf) format, maximum 15 MB.
                  </p>
                </div>

                {docUploadError && (
                  <div className="p-3 bg-red-50 text-red-800 border border-red-200 rounded-lg text-xs font-semibold flex items-center gap-2">
                    <FileX className="w-4 h-4 text-red-600 shrink-0" />
                    <span>{docUploadError}</span>
                  </div>
                )}

                <form onSubmit={handleUploadDocument} className="space-y-4">
                  {/* Drop zone */}
                  <div
                    onDragOver={(e) => {
                      e.preventDefault();
                      setIsDragging(true);
                    }}
                    onDragLeave={() => setIsDragging(false)}
                    onDrop={(e) => {
                      e.preventDefault();
                      setIsDragging(false);
                      if (e.dataTransfer.files && e.dataTransfer.files[0]) {
                        handleFileSelect(e.dataTransfer.files[0]);
                      }
                    }}
                    onClick={() => fileInputRef.current?.click()}
                    className={`border-2 border-dashed rounded-xl p-6 text-center cursor-pointer transition flex flex-col items-center justify-center gap-2 ${
                      isDragging
                        ? 'border-orange-500 bg-orange-50/50'
                        : selectedFile
                        ? 'border-emerald-400 bg-emerald-50/30'
                        : 'border-neutral-300 hover:border-orange-400 bg-neutral-50/50'
                    }`}
                  >
                    <input
                      ref={fileInputRef}
                      type="file"
                      accept=".pdf,application/pdf"
                      className="hidden"
                      onChange={(e) => {
                        if (e.target.files && e.target.files[0]) {
                          handleFileSelect(e.target.files[0]);
                        }
                      }}
                    />

                    {selectedFile ? (
                      <>
                        <div className="w-10 h-10 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center">
                          <FileCheck className="w-5 h-5" />
                        </div>
                        <div>
                          <p className="text-xs font-bold text-neutral-900">{selectedFile.name}</p>
                          <p className="text-[11px] text-emerald-600 font-semibold">
                            {(selectedFile.size / (1024 * 1024)).toFixed(2)} MB • Ready to upload
                          </p>
                        </div>
                        <span className="text-[10px] text-neutral-400 underline">Click to choose another PDF</span>
                      </>
                    ) : (
                      <>
                        <div className="w-10 h-10 rounded-full bg-orange-100 text-orange-600 flex items-center justify-center">
                          <Upload className="w-5 h-5" />
                        </div>
                        <div>
                          <p className="text-xs font-bold text-neutral-800">
                            Drag &amp; drop PDF file here, or click to browse
                          </p>
                          <p className="text-[11px] text-neutral-500 mt-0.5">
                            PDF only • Maximum 15 MB per file
                          </p>
                        </div>
                      </>
                    )}
                  </div>

                  {/* Title and Upload Action */}
                  <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3">
                    <div className="flex-1">
                      <input
                        type="text"
                        value={docTitle ?? ''}
                        onChange={(e) => setDocTitle(e.target.value)}
                        placeholder="Document title (e.g. National ID Copy, Employment Contract, Tazkira)"
                        className="w-full px-3 py-2 border border-neutral-300 rounded-lg text-xs focus:ring-1 focus:ring-orange-500 focus:outline-none"
                      />
                    </div>

                    <button
                      type="submit"
                      disabled={!selectedFile || uploadingDoc}
                      className="inline-flex items-center justify-center gap-2 px-4 py-2 bg-[#2563EB] hover:bg-[#1D4ED8] active:bg-[#1E40AF] text-white text-xs font-bold rounded-xl shadow-xs transition cursor-pointer disabled:opacity-40 focus:outline-none focus-visible:ring-2 focus-visible:ring-[#2563EB]"
                    >
                      {uploadingDoc ? (
                        <>
                          <Loader2 className="w-4 h-4 animate-spin" />
                          <span>Uploading...</span>
                        </>
                      ) : (
                        <>
                          <Upload className="w-4 h-4" />
                          <span>Save PDF Document</span>
                        </>
                      )}
                    </button>
                  </div>
                </form>
              </div>

              {/* Documents List */}
              <div className="bg-white rounded-xl border border-neutral-200 shadow-xs overflow-hidden">
                <div className="px-5 py-3 border-b border-neutral-200 bg-neutral-50 flex items-center justify-between">
                  <h4 className="text-xs font-bold text-neutral-800 uppercase tracking-wider">
                    Associated Documents ({documents.length})
                  </h4>
                  <span className="text-[11px] text-neutral-500 font-mono">
                    User: {officialId}
                  </span>
                </div>

                {loadingDocs ? (
                  <div className="p-8 text-center text-xs text-neutral-500 flex items-center justify-center gap-2">
                    <Loader2 className="w-4 h-4 animate-spin text-orange-500" />
                    <span>Loading employee documents...</span>
                  </div>
                ) : documents.length === 0 ? (
                  <div className="p-8 text-center text-xs text-neutral-500">
                    <FileText className="w-8 h-8 mx-auto mb-2 text-neutral-300" />
                    <p className="font-semibold text-neutral-700">No documents uploaded yet</p>
                    <p className="text-[11px] text-neutral-400 mt-0.5">
                      Upload employee national identification, employment agreements, or certifications in PDF format.
                    </p>
                  </div>
                ) : (
                  <div className="divide-y divide-neutral-100">
                    {documents.map((doc) => (
                      <div
                        key={doc.id}
                        className="p-4 flex items-center justify-between gap-3 hover:bg-neutral-50/50 transition"
                      >
                        <div className="flex items-center gap-3">
                          <div className="w-9 h-9 rounded-lg bg-red-100 text-red-600 flex items-center justify-center shrink-0 font-bold text-xs">
                            PDF
                          </div>
                          <div>
                            <p className="text-xs font-bold text-neutral-900">{doc.documentName}</p>
                            <div className="flex items-center gap-2 text-[10px] text-neutral-400 mt-0.5 flex-wrap">
                              <span className="font-mono text-neutral-600">{doc.fileName}</span>
                              <span>•</span>
                              <span>{doc.fileSizeFormatted}</span>
                              <span>•</span>
                              <span>Uploaded by {doc.uploadedBy || 'Admin'}</span>
                              <span>•</span>
                              <span>{new Date(doc.uploadedAt).toLocaleDateString()}</span>
                            </div>
                          </div>
                        </div>

                        <div className="flex items-center gap-1.5 shrink-0">
                          <button
                            type="button"
                            onClick={() => handleViewPdf(doc)}
                            title="View/Open PDF"
                            className="p-1.5 text-neutral-600 hover:text-orange-600 hover:bg-orange-50 rounded-lg transition cursor-pointer"
                          >
                            <Eye className="w-4 h-4" />
                          </button>

                          <button
                            type="button"
                            onClick={() => downloadEmployeePdf(doc)}
                            title="Download PDF"
                            className="p-1.5 text-neutral-600 hover:text-emerald-600 hover:bg-emerald-50 rounded-lg transition cursor-pointer"
                          >
                            <Download className="w-4 h-4" />
                          </button>

                          <button
                            type="button"
                            onClick={() => handleDeleteDoc(doc.id, doc.documentName)}
                            title="Delete Document"
                            className="p-1.5 text-neutral-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition cursor-pointer"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          )}

          {/* TAB 4: DIGITAL USER CARD */}
          {activeTab === 'card' && (
            <div>
              <UserCard user={user} settings={settings} />
            </div>
          )}
        </div>
      </div>

      {/* Embedded PDF Viewer Modal */}
      {previewDocUrl && (
        <div className="fixed inset-0 z-60 bg-black/80 flex items-center justify-center p-4">
          <div className="w-full max-w-4xl h-[85vh] bg-white rounded-2xl overflow-hidden flex flex-col shadow-2xl">
            <div className="bg-neutral-900 text-white px-4 py-3 flex items-center justify-between">
              <span className="text-xs font-bold font-mono">PDF Preview</span>
              <button
                type="button"
                onClick={() => setPreviewDocUrl(null)}
                className="p-1 text-neutral-400 hover:text-white rounded-lg hover:bg-neutral-800 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            <iframe
              src={previewDocUrl}
              title="PDF Document Viewer"
              className="flex-1 w-full border-none"
            />
          </div>
        </div>
      )}
    </div>
  );
};
