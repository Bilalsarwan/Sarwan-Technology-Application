import React, { useEffect, useState } from 'react';
import { ShieldAlert, Lock, ArrowRight, Home, RefreshCw, AlertTriangle, ShieldCheck } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { UserRole, UserPermissions } from '../../types';
import { ActiveTab } from '../layout/Sidebar';

export interface RouteGuardProps {
  children: React.ReactNode;
  /**
   * List of allowed Firestore roles that can access this route.
   * If not provided, role access is checked via requiredRole or requiredPermission.
   */
  allowedRoles?: UserRole[];
  /**
   * A single required role (e.g., 'super_admin').
   */
  requiredRole?: UserRole;
  /**
   * A specific permission flag from UserPermissions (e.g., 'canManageSettings' or 'canViewAuditLogs').
   */
  requiredPermission?: keyof UserPermissions;
  /**
   * The canonical route path (e.g. '/settings' or '/audit-log').
   */
  routePath?: string;
  /**
   * A human-friendly display name for the protected route.
   */
  routeName?: string;
  /**
   * Where to redirect unauthorized users (defaults to 'dashboard').
   */
  redirectTo?: ActiveTab;
  /**
   * Callback invoked when a redirect is triggered (e.g. to update activeTab in state).
   */
  onRedirect?: (targetTab: ActiveTab) => void;
  /**
   * Redirection behavior:
   * - 'both': Shows an unauthorized notice with countdown, then redirects (user can also click button immediately).
   * - 'immediate': Redirects right away without displaying the access denied notice.
   * - 'fallback_only': Renders the fallback notice and does not auto-redirect.
   */
  behavior?: 'both' | 'immediate' | 'fallback_only';
  /**
   * Countdown delay in seconds before auto-redirect when behavior is 'both' (default: 3 seconds).
   */
  autoRedirectDelay?: number;
  /**
   * Optional custom fallback UI to render when unauthorized.
   */
  fallback?: React.ReactNode;
}

/**
 * Route access metadata dictionary for canonical application routes.
 */
export const RESTRICTED_ROUTES: Record<
  string,
  {
    path: string;
    tab: ActiveTab;
    name: string;
    allowedRoles: UserRole[];
    requiredPermission: keyof UserPermissions;
    description: string;
  }
> = {
  '/settings': {
    path: '/settings',
    tab: 'settings',
    name: 'System & Company Settings',
    allowedRoles: ['super_admin'],
    requiredPermission: 'canManageSettings',
    description: 'Company credentials, prefix configurations, authorized emails, and invoice design.',
  },
  '/audit-log': {
    path: '/audit-log',
    tab: 'audit',
    name: 'System Audit Trail',
    allowedRoles: ['super_admin'],
    requiredPermission: 'canViewAuditLogs',
    description: 'Immutable security log of financial transactions, role changes, and system modifications.',
  },
  '/audit': {
    path: '/audit',
    tab: 'audit',
    name: 'System Audit Trail',
    allowedRoles: ['super_admin'],
    requiredPermission: 'canViewAuditLogs',
    description: 'Immutable security log of financial transactions, role changes, and system modifications.',
  },
  '/staff': {
    path: '/staff',
    tab: 'staff',
    name: 'Staff & Role-Based Access Control',
    allowedRoles: ['super_admin'],
    requiredPermission: 'canManageStaff',
    description: 'Manage staff accounts, assign Firestore roles, and configure system permissions.',
  },
  '/backup': {
    path: '/backup',
    tab: 'backup',
    name: 'Backup & Disaster Recovery',
    allowedRoles: ['super_admin'],
    requiredPermission: 'canExportBackup',
    description: 'Full database JSON export and snapshot restoration tools.',
  },
  '/reports': {
    path: '/reports',
    tab: 'reports',
    name: 'Financial Reports & Analytics',
    allowedRoles: ['super_admin', 'invoice_manager'],
    requiredPermission: 'canViewReports',
    description: 'Revenue breakdowns, profit/loss calculations, and transaction reports.',
  },
  '/expenses': {
    path: '/expenses',
    tab: 'invoices',
    name: 'Operating Expenses (Retired)',
    allowedRoles: [],
    requiredPermission: 'canViewInvoices',
    description: 'Retired standalone module. All expenses are managed inside invoices.',
  },
  '/payments': {
    path: '/payments',
    tab: 'payments',
    name: 'Payment Ledger',
    allowedRoles: ['super_admin', 'invoice_manager', 'payment_collector'],
    requiredPermission: 'canViewPayments',
    description: 'Customer payment collections, receipts, and supervisor corrections.',
  },
  '/invoices': {
    path: '/invoices',
    tab: 'invoices',
    name: 'Invoice Management',
    allowedRoles: ['super_admin', 'invoice_manager', 'payment_collector'],
    requiredPermission: 'canViewInvoices',
    description: 'Creating, viewing, and printing bilingual commercial invoices.',
  },
  '/customers': {
    path: '/customers',
    tab: 'customers',
    name: 'Customer Accounts',
    allowedRoles: ['super_admin', 'invoice_manager', 'payment_collector'],
    requiredPermission: 'canViewCustomers',
    description: 'Customer database and account statements.',
  },
  '/dashboard': {
    path: '/dashboard',
    tab: 'dashboard',
    name: 'Business Dashboard',
    allowedRoles: ['super_admin', 'invoice_manager', 'payment_collector'],
    requiredPermission: 'canViewDashboard',
    description: 'Executive overview and real-time business metrics.',
  },
};

/**
 * RouteGuard Component
 *
 * Uses the user's Firestore-backed role and permissions from AuthContext to conditionally
 * render protected content or redirect unauthorized users away from restricted routes.
 */
export const RouteGuard: React.FC<RouteGuardProps> = ({
  children,
  allowedRoles,
  requiredRole,
  requiredPermission,
  routePath = '/settings',
  routeName,
  redirectTo = 'dashboard',
  onRedirect,
  behavior = 'both',
  autoRedirectDelay = 3,
  fallback,
}) => {
  const {
    userProfile,
    permissions,
    loading: authLoading,
    isAuthorized,
  } = useAuth();

  const [secondsLeft, setSecondsLeft] = useState<number>(autoRedirectDelay);

  // Derive route metadata if available from canonical registry
  const routeMeta = RESTRICTED_ROUTES[routePath];
  const effectiveRouteName = routeName || routeMeta?.name || routePath;

  // Determine authorized roles
  const effectiveAllowedRoles: UserRole[] = React.useMemo(() => {
    if (allowedRoles && allowedRoles.length > 0) return allowedRoles;
    if (requiredRole) return [requiredRole];
    if (routeMeta?.allowedRoles) return routeMeta.allowedRoles;
    return ['super_admin'];
  }, [allowedRoles, requiredRole, routeMeta]);

  // Determine required permission flag
  const effectivePermission = requiredPermission || routeMeta?.requiredPermission;

  // Check role authorization from Firestore profile
  const currentRole = userProfile?.role;
  const isSuperAdmin = currentRole === 'super_admin';

  const roleMatches = currentRole ? effectiveAllowedRoles.includes(currentRole) : false;
  const permissionMatches = effectivePermission ? Boolean(permissions[effectivePermission]) : true;

  // User is authorized if signed in, has a valid Firestore profile, and role/permission conditions pass
  const hasAccess = Boolean(isAuthorized && userProfile && (isSuperAdmin || (roleMatches && permissionMatches)));

  // Redirect execution helper
  const executeRedirect = React.useCallback(() => {
    // 1. Update URL pathname or hash cleanly
    try {
      const targetPath = `/${redirectTo}`;
      if (window.location.pathname !== targetPath) {
        window.history.pushState(null, '', targetPath);
      }
    } catch {
      // Ignore in sandbox environments
    }

    // 2. Notify parent router / state
    if (onRedirect) {
      onRedirect(redirectTo);
    }
  }, [onRedirect, redirectTo]);

  // Immediate redirect effect
  useEffect(() => {
    if (authLoading) return;

    if (!hasAccess && behavior === 'immediate') {
      executeRedirect();
    }
  }, [authLoading, hasAccess, behavior, executeRedirect]);

  // Countdown effect for 'both' behavior
  useEffect(() => {
    if (authLoading || hasAccess || behavior !== 'both') return;

    if (secondsLeft <= 0) {
      executeRedirect();
      return;
    }

    const timer = setTimeout(() => {
      setSecondsLeft((prev) => prev - 1);
    }, 1000);

    return () => clearTimeout(timer);
  }, [authLoading, hasAccess, behavior, secondsLeft, executeRedirect]);

  // 1. Loading state while Firestore authentication & profile sync initializes
  if (authLoading) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[360px] p-8 text-center bg-white rounded-2xl border border-neutral-200 shadow-xs">
        <RefreshCw className="w-8 h-8 text-orange-500 animate-spin mb-3" />
        <p className="text-sm font-semibold text-neutral-800">Verifying Firestore Role &amp; Route Permissions...</p>
        <p className="text-xs text-neutral-500 mt-1">Inspecting access rights for {effectiveRouteName}</p>
      </div>
    );
  }

  // 2. Access Granted: Render protected page
  if (hasAccess) {
    return <>{children}</>;
  }

  // 3. Access Denied: If custom fallback provided, render that
  if (fallback) {
    return <>{fallback}</>;
  }

  // 4. Standard Professional Unauthorized Access UI
  return (
    <div className="max-w-2xl mx-auto my-8 p-6 sm:p-8 bg-white rounded-2xl border border-red-200 shadow-lg text-neutral-900 animate-in fade-in zoom-in-95 duration-200">
      {/* Header Banner */}
      <div className="flex items-start gap-4">
        <div className="w-12 h-12 rounded-xl bg-red-100 border border-red-200 flex items-center justify-center shrink-0 text-red-600">
          <ShieldAlert className="w-6 h-6" />
        </div>
        <div className="flex-1">
          <div className="flex items-center gap-2 flex-wrap">
            <span className="px-2.5 py-0.5 bg-red-100 text-red-800 text-[11px] font-bold rounded-full uppercase tracking-wider">
              Restricted Route
            </span>
            <span className="font-mono text-xs text-neutral-500 bg-neutral-100 px-2 py-0.5 rounded-md">
              {routePath}
            </span>
          </div>
          <h2 className="text-xl font-bold text-neutral-900 mt-1.5">
            Unauthorized Access: {effectiveRouteName}
          </h2>
          <p className="text-xs text-neutral-600 mt-1 leading-relaxed">
            Your current Firestore user account lacks the required role permissions to view or interact with this restricted route.
          </p>
        </div>
      </div>

      {/* Role Comparison Details */}
      <div className="mt-6 grid grid-cols-1 sm:grid-cols-2 gap-3 p-4 bg-neutral-50 rounded-xl border border-neutral-200 text-xs">
        <div>
          <span className="text-neutral-500 font-medium block">Your Current Firestore Role:</span>
          <div className="flex items-center gap-1.5 mt-1 font-semibold text-neutral-800">
            <span className="w-2 h-2 rounded-full bg-amber-500"></span>
            <span className="capitalize">
              {currentRole ? currentRole.replace('_', ' ') : 'Unassigned / Guest'}
            </span>
          </div>
          <span className="text-[11px] text-neutral-500 mt-0.5 block truncate">
            {userProfile?.email || 'No active session email'}
          </span>
        </div>

        <div>
          <span className="text-neutral-500 font-medium block">Required Role:</span>
          <div className="flex items-center gap-1.5 mt-1 font-semibold text-red-700">
            <Lock className="w-3.5 h-3.5" />
            <span>
              {effectiveAllowedRoles.map((r) => r.replace('_', ' ').toUpperCase()).join(' or ')}
            </span>
          </div>
          <span className="text-[11px] text-neutral-500 mt-0.5 block">
            Backed by Firestore security rules
          </span>
        </div>
      </div>

      {/* Auto-redirect Alert */}
      {behavior === 'both' && (
        <div className="mt-4 p-3 bg-amber-50 border border-amber-200 rounded-lg flex items-center justify-between text-xs text-amber-900">
          <div className="flex items-center gap-2">
            <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0" />
            <span>
              Redirecting you to <strong className="capitalize">{redirectTo}</strong> in{' '}
              <strong className="text-amber-700 font-bold">{secondsLeft}</strong> second
              {secondsLeft === 1 ? '' : 's'}...
            </span>
          </div>
          <button
            onClick={executeRedirect}
            className="text-[11px] font-bold text-amber-800 hover:text-amber-950 underline cursor-pointer"
          >
            Redirect Now
          </button>
        </div>
      )}

      {/* Action Footer */}
      <div className="mt-6 pt-5 border-t border-neutral-200 flex flex-col sm:flex-row items-center justify-between gap-3">
        <button
          onClick={executeRedirect}
          className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-4 py-2 bg-[#2563EB] hover:bg-[#1D4ED8] active:bg-[#1E40AF] text-white text-xs font-bold rounded-lg shadow-xs transition cursor-pointer active:scale-98 focus:outline-none focus-visible:ring-2 focus-visible:ring-[#2563EB]"
        >
          <Home className="w-4 h-4" />
          <span>Return to {redirectTo.toUpperCase()}</span>
          <ArrowRight className="w-3.5 h-3.5" />
        </button>
      </div>
    </div>
  );
};

export default RouteGuard;
