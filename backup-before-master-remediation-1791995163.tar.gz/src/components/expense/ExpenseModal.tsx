import React, { useEffect, useRef } from 'react';
import {
  X,
  AlertCircle,
  PlusCircle,
  Pencil,
  RotateCcw,
  Loader2,
  Receipt,
} from 'lucide-react';
import { Expense, Invoice } from '../../types';

export interface ExpenseModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSubmit: (e: React.FormEvent) => void;
  invoice?: Invoice | null;
  editingExpense?: Expense | null;
  expenseTitle: string;
  setExpenseTitle: (val: string) => void;
  expenseAmount: number | '';
  setExpenseAmount: (val: number | '') => void;
  expenseDate: string;
  setExpenseDate: (val: string) => void;
  expenseCategory: string;
  setExpenseCategory: (val: string) => void;
  expenseNote: string;
  setExpenseNote: (val: string) => void;
  expenseCorrections?: string;
  setExpenseCorrections?: (val: string) => void;
  expenseFormError?: string | null;
  savingExpense?: boolean;
  lastFocusedTrigger?: HTMLElement | null;
  // Legacy / convenience fallback props
  expenseToEdit?: Expense | null;
  onSuccess?: () => void;
}

/**
 * Dedicated Expense Modal Dialog
 * Used for Add Expense, Edit Expense, and Resubmit Rejected Expense workflows.
 * Fully accessible, keyboard navigable (ESC to close, auto-focus & focus return),
 * responsive across mobile, tablet, and desktop, with theme support for
 * Sarwan Light and Sarwan Dark.
 */
export const ExpenseModal: React.FC<ExpenseModalProps> = ({
  isOpen,
  onClose,
  onSubmit,
  invoice,
  editingExpense: propEditingExpense,
  expenseTitle,
  setExpenseTitle,
  expenseAmount,
  setExpenseAmount,
  expenseDate,
  setExpenseDate,
  expenseCategory,
  setExpenseCategory,
  expenseNote,
  setExpenseNote,
  expenseCorrections = '',
  setExpenseCorrections,
  expenseFormError = null,
  savingExpense = false,
  lastFocusedTrigger,
  expenseToEdit,
}) => {
  const activeExpense = propEditingExpense || expenseToEdit || null;
  const isResubmitting = activeExpense?.status === 'rejected';
  const isEditing = Boolean(activeExpense && !isResubmitting);

  const titleInputRef = useRef<HTMLInputElement>(null);
  const modalContainerRef = useRef<HTMLDivElement>(null);

  // 1. Prevent background scrolling while modal is open & restore on close/unmount
  useEffect(() => {
    if (!isOpen) return;

    const originalOverflow = document.body.style.overflow;
    document.body.style.overflow = 'hidden';

    return () => {
      document.body.style.overflow = originalOverflow;
    };
  }, [isOpen]);

  // 2. Auto-focus the first input field on open & restore focus to trigger button on close
  useEffect(() => {
    if (isOpen) {
      const timer = setTimeout(() => {
        if (titleInputRef.current) {
          titleInputRef.current.focus();
        }
      }, 50);
      return () => clearTimeout(timer);
    } else {
      if (lastFocusedTrigger && typeof lastFocusedTrigger.focus === 'function') {
        lastFocusedTrigger.focus();
      }
    }
  }, [isOpen, lastFocusedTrigger]);

  // 3. Close on Escape key press (guarded against in-flight saves)
  useEffect(() => {
    if (!isOpen) return;

    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        if (!savingExpense) {
          e.preventDefault();
          onClose();
        }
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, savingExpense, onClose]);

  if (!isOpen) return null;

  const modalTitle = isResubmitting
    ? 'Edit & Resubmit Rejected Expense'
    : isEditing
    ? 'Edit Expense'
    : 'Add Expense';

  const submitButtonLabel = isResubmitting
    ? 'Resubmit Expense'
    : isEditing
    ? 'Update Expense'
    : 'Save Expense';

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="expense-modal-title"
      aria-describedby="expense-modal-subtitle"
      className="fixed inset-0 z-60 flex items-center justify-center p-3 sm:p-4 bg-black/65 backdrop-blur-xs animate-in fade-in duration-200"
      onClick={(e) => {
        // Close when clicking directly on the backdrop (outside modal dialog container)
        if (e.target === e.currentTarget && !savingExpense) {
          onClose();
        }
      }}
    >
      <div
        ref={modalContainerRef}
        className="relative w-full max-w-lg max-h-[90vh] flex flex-col rounded-2xl shadow-2xl border border-[var(--app-border,#E2E8F0)] bg-[var(--app-surface-modal,#FFFFFF)] text-[var(--app-text-primary,#0F172A)] overflow-hidden transition-all"
      >
        {/* ============================================================ */}
        {/* MODAL HEADER                                                 */}
        {/* ============================================================ */}
        <div className="shrink-0 p-4 sm:p-5 border-b border-[var(--app-border,#E2E8F0)] flex items-center justify-between bg-[var(--app-surface-modal,#FFFFFF)]">
          <div className="flex items-center gap-3 min-w-0">
            <div
              className={`p-2 sm:p-2.5 rounded-xl shrink-0 border ${
                isResubmitting
                  ? 'bg-blue-50 dark:bg-blue-950/40 text-[#2563EB] border-blue-200 dark:border-blue-800'
                  : isEditing
                  ? 'bg-orange-50 dark:bg-orange-950/40 text-orange-600 border-orange-200 dark:border-orange-800'
                  : 'bg-blue-50 dark:bg-blue-950/40 text-[#2563EB] border-blue-200 dark:border-blue-800'
              }`}
            >
              {isResubmitting ? (
                <RotateCcw className="w-5 h-5 text-[#2563EB]" />
              ) : isEditing ? (
                <Pencil className="w-5 h-5 text-orange-600" />
              ) : (
                <PlusCircle className="w-5 h-5 text-[#2563EB]" />
              )}
            </div>
            <div className="min-w-0">
              <h3
                id="expense-modal-title"
                className="text-sm sm:text-base font-bold text-[var(--app-text-primary,#0F172A)] tracking-tight leading-tight truncate"
              >
                {modalTitle}
              </h3>
              <p
                id="expense-modal-subtitle"
                className="text-[11px] sm:text-xs text-[var(--app-text-secondary,#475569)] truncate mt-0.5 font-medium flex items-center gap-1.5"
              >
                {invoice ? (
                  <>
                    <Receipt className="w-3 h-3 text-neutral-400 shrink-0" />
                    <span>Bill #{invoice.billNumber}</span>
                    {invoice.customerName && (
                      <span className="text-neutral-400 truncate">• {invoice.customerName}</span>
                    )}
                  </>
                ) : (
                  <span>Record operational invoice expenditure</span>
                )}
              </p>
            </div>
          </div>

          <button
            type="button"
            id="btn-close-expense-modal"
            onClick={onClose}
            disabled={savingExpense}
            className="p-1.5 sm:p-2 rounded-lg text-[var(--app-text-secondary,#475569)] hover:text-[var(--app-text-primary,#0F172A)] hover:bg-[var(--app-surface-card,#F1F5F9)] focus:outline-hidden focus:ring-2 focus:ring-[#2563EB] transition cursor-pointer disabled:opacity-50"
            aria-label="Close expense modal"
            title="Close without saving"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* ============================================================ */}
        {/* MODAL BODY (SCROLLABLE) & FORM                               */}
        {/* ============================================================ */}
        <form
          id="expense-dialog-form"
          onSubmit={onSubmit}
          className="flex-1 flex flex-col min-h-0 overflow-hidden"
        >
          <div className="flex-1 overflow-y-auto p-4 sm:p-5 space-y-3.5 overscroll-contain">
            {/* Inline Error Alert */}
            {expenseFormError && (
              <div
                id="expense-modal-error-alert"
                role="alert"
                className="p-3 bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-800 text-rose-800 dark:text-rose-200 text-xs rounded-xl flex items-start gap-2.5 animate-in fade-in duration-150"
              >
                <AlertCircle className="w-4 h-4 text-rose-600 dark:text-rose-400 shrink-0 mt-0.5" />
                <span className="leading-relaxed font-medium">{expenseFormError}</span>
              </div>
            )}

            {/* Rejection Details & Corrections Input for Resubmission */}
            {isResubmitting && (
              <div className="p-3.5 bg-amber-50 dark:bg-amber-950/30 border border-amber-200 dark:border-amber-800 rounded-xl space-y-2.5">
                <div className="text-xs text-amber-900 dark:text-amber-200 font-semibold flex items-start gap-2">
                  <AlertCircle className="w-4 h-4 text-amber-600 dark:text-amber-400 shrink-0 mt-0.5" />
                  <div>
                    <span className="font-bold">Rejection Reason: </span>
                    <span className="font-medium">
                      {activeExpense?.rejectionReason || 'No reason provided'}
                    </span>
                  </div>
                </div>
                <div>
                  <label
                    htmlFor="expense-corrections-textarea"
                    className="text-[11px] font-semibold text-amber-950 dark:text-amber-200 block mb-1"
                  >
                    Correction Summary / Notes for Resubmission <span className="text-rose-600">*</span>
                  </label>
                  <textarea
                    id="expense-corrections-textarea"
                    rows={2}
                    required
                    value={expenseCorrections ?? ''}
                    onChange={(e) => setExpenseCorrections && setExpenseCorrections(e.target.value)}
                    placeholder="Describe corrections made before resubmitting for approval (required, at least 3 characters)..."
                    className="w-full text-xs border border-amber-300 dark:border-amber-700 rounded-lg p-2.5 bg-white dark:bg-slate-800 text-neutral-900 dark:text-white placeholder-neutral-400 dark:placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-amber-500 font-sans"
                  />
                </div>
              </div>
            )}

            {/* Field 1: Description */}
            <div>
              <label
                htmlFor="expense-title-input"
                className="text-[11px] sm:text-xs font-semibold text-neutral-700 dark:text-slate-300 block mb-1"
              >
                Expense Description <span className="text-rose-600">*</span>
              </label>
              <input
                id="expense-title-input"
                ref={titleInputRef}
                type="text"
                value={expenseTitle ?? ''}
                onChange={(e) => setExpenseTitle(e.target.value)}
                placeholder="e.g., Fiber optic patch cord, Technician site transport..."
                className="w-full text-xs sm:text-sm border border-[var(--app-border,#CBD5E1)] dark:border-slate-700 rounded-lg px-3 py-2 bg-white dark:bg-slate-800 text-[var(--app-text-primary,#0F172A)] dark:text-white placeholder-neutral-400 dark:placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-[#2563EB]"
                required
              />
            </div>

            {/* Field 2 & 3: Amount and Date */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label
                  htmlFor="expense-amount-input"
                  className="text-[11px] sm:text-xs font-semibold text-neutral-700 dark:text-slate-300 block mb-1"
                >
                  Amount (AFN) <span className="text-rose-600">*</span>
                </label>
                <input
                  id="expense-amount-input"
                  type="number"
                  min="1"
                  step="any"
                  value={expenseAmount ?? ''}
                  onChange={(e) =>
                    setExpenseAmount(e.target.value === '' ? '' : Number(e.target.value))
                  }
                  placeholder="e.g., 1500"
                  className="w-full text-xs sm:text-sm font-mono border border-[var(--app-border,#CBD5E1)] dark:border-slate-700 rounded-lg px-3 py-2 bg-white dark:bg-slate-800 text-[var(--app-text-primary,#0F172A)] dark:text-white placeholder-neutral-400 dark:placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-[#2563EB]"
                  required
                />
              </div>

              <div>
                <label
                  htmlFor="expense-date-input"
                  className="text-[11px] sm:text-xs font-semibold text-neutral-700 dark:text-slate-300 block mb-1"
                >
                  Expense Date <span className="text-rose-600">*</span>
                </label>
                <input
                  id="expense-date-input"
                  type="date"
                  value={expenseDate ?? ''}
                  onChange={(e) => setExpenseDate(e.target.value)}
                  className="w-full text-xs sm:text-sm font-mono border border-[var(--app-border,#CBD5E1)] dark:border-slate-700 rounded-lg px-3 py-2 bg-white dark:bg-slate-800 text-[var(--app-text-primary,#0F172A)] dark:text-white focus:outline-none focus:ring-2 focus:ring-[#2563EB]"
                  required
                />
              </div>
            </div>

            {/* Field 4: Category */}
            <div>
              <label
                htmlFor="expense-category-select"
                className="text-[11px] sm:text-xs font-semibold text-neutral-700 dark:text-slate-300 block mb-1"
              >
                Category (Optional)
              </label>
              <select
                id="expense-category-select"
                value={expenseCategory ?? 'General Operations'}
                onChange={(e) => setExpenseCategory(e.target.value)}
                className="w-full text-xs sm:text-sm border border-[var(--app-border,#CBD5E1)] dark:border-slate-700 rounded-lg px-3 py-2 bg-white dark:bg-slate-800 text-[var(--app-text-primary,#0F172A)] dark:text-white focus:outline-none focus:ring-2 focus:ring-[#2563EB]"
              >
                <option value="General Operations">General Operations</option>
                <option value="Materials & Supplies">Materials & Supplies</option>
                <option value="Tools & Equipment">Tools & Equipment</option>
                <option value="Transport & Fuel">Transport & Fuel</option>
                <option value="Labor & Services">Labor & Services</option>
                <option value="Maintenance & Repairs">Maintenance & Repairs</option>
                <option value="Other">Other</option>
              </select>
            </div>

            {/* Field 5: Notes */}
            <div>
              <label
                htmlFor="expense-note-input"
                className="text-[11px] sm:text-xs font-semibold text-neutral-700 dark:text-slate-300 block mb-1"
              >
                Notes (Optional)
              </label>
              <input
                id="expense-note-input"
                type="text"
                value={expenseNote ?? ''}
                onChange={(e) => setExpenseNote(e.target.value)}
                placeholder="Additional notes or vendor reference..."
                className="w-full text-xs sm:text-sm border border-[var(--app-border,#CBD5E1)] dark:border-slate-700 rounded-lg px-3 py-2 bg-white dark:bg-slate-800 text-[var(--app-text-primary,#0F172A)] dark:text-white placeholder-neutral-400 dark:placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-[#2563EB]"
              />
            </div>
          </div>

          {/* ============================================================ */}
          {/* MODAL FOOTER (STICKY / FIXED)                                */}
          {/* ============================================================ */}
          <div className="shrink-0 p-3.5 sm:p-4 border-t border-[var(--app-border,#E2E8F0)] flex items-center justify-end gap-2.5 bg-[var(--app-surface-modal,#FFFFFF)]">
            <button
              type="button"
              id="btn-cancel-expense-modal"
              onClick={onClose}
              disabled={savingExpense}
              className="px-3.5 py-2 text-xs sm:text-sm font-semibold rounded-lg border border-[var(--app-border,#CBD5E1)] dark:border-slate-700 text-[var(--app-text-secondary,#475569)] dark:text-slate-300 hover:bg-[var(--app-surface-card,#F8FAFC)] dark:hover:bg-slate-800 transition cursor-pointer disabled:opacity-50"
            >
              Cancel
            </button>
            <button
              type="submit"
              id="btn-submit-expense-modal"
              disabled={savingExpense}
              className="px-4 py-2 bg-[#2563EB] hover:bg-[#1D4ED8] active:bg-[#1E40AF] text-white text-xs sm:text-sm font-bold rounded-lg shadow-xs transition disabled:opacity-50 cursor-pointer flex items-center gap-2 focus:outline-none focus-visible:ring-2 focus-visible:ring-[#2563EB]"
            >
              {savingExpense && <Loader2 className="w-4 h-4 animate-spin shrink-0" />}
              <span>{submitButtonLabel}</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
