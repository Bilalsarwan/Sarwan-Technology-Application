import React, { useMemo } from 'react';
import { Expense, UserProfile, ExpenseTimelineEntry } from '../../types';
import { formatDate, formatAFN } from '../../utils/format';
import {
  formatRoleLabel,
  getActorInitials,
  normalizeExpenseTimeline,
} from './ExpenseAuditHistoryModal';
import {
  CheckCircle2,
  Clock,
  XCircle,
  RotateCcw,
  User,
  ShieldCheck,
  Building,
  Check,
  AlertCircle,
  DollarSign,
  History,
} from 'lucide-react';

export interface ExpenseWorkflowInfoBoxProps {
  expense: Expense;
  users?: UserProfile[];
  className?: string;
  isCompact?: boolean;
}

/**
 * Responsive, comprehensive workflow identity and audit information box.
 * Displays requester, approver, rejecter identity (photo, full name, job title/role, stable user ID),
 * stage timestamps, rejection reasons, and complete revision history.
 * 
 * Supports both desktop horizontal layout and mobile stacked layout.
 */
export const ExpenseWorkflowInfoBox: React.FC<ExpenseWorkflowInfoBoxProps> = ({
  expense,
  users = [],
  className = '',
  isCompact = false,
}) => {
  // Pre-index users by id, userId, username, authUid for instant identity resolution
  const userMap = useMemo(() => {
    const map: Record<string, UserProfile> = {};
    if (users && Array.isArray(users)) {
      for (const u of users) {
        if (!u) continue;
        if (u.id) map[u.id.toLowerCase()] = u;
        if (u.userId) map[u.userId.toLowerCase()] = u;
        if (u.username) map[u.username.toLowerCase()] = u;
        if (u.authUid) map[u.authUid.toLowerCase()] = u;
      }
    }
    return map;
  }, [users]);

  // Chronological timeline of events
  const timeline = useMemo(() => {
    return normalizeExpenseTimeline(expense);
  }, [expense]);

  // Identity helper
  const resolveActor = (
    userId?: string,
    fallbackName?: string,
    fallbackRole?: string,
    fallbackTitle?: string,
    fallbackPhoto?: string
  ) => {
    const user = userId ? userMap[userId.toLowerCase()] : undefined;
    const name = user?.name || user?.username || fallbackName || 'Authorized Staff';
    const role = user?.role || fallbackRole || 'staff';
    const jobTitle = user?.jobTitle || fallbackTitle || '';
    const photoURL = user?.photoURL || fallbackPhoto || '';
    const stableId = user?.id || user?.userId || userId || '';
    return { name, role, jobTitle, photoURL, stableId };
  };

  const requester = resolveActor(
    expense.requestedBy,
    expense.requestedByName,
    expense.requestedByRole,
    expense.requestedByJobTitle,
    expense.requestedByPhotoURL
  );

  const managerApprover = expense.managerApprovedBy
    ? resolveActor(
        expense.managerApprovedBy,
        expense.managerApprovedByName,
        'invoice_manager',
        expense.managerApprovedByJobTitle,
        expense.managerApprovedByPhotoURL
      )
    : null;

  const adminApprover = expense.adminApprovedBy
    ? resolveActor(
        expense.adminApprovedBy,
        expense.adminApprovedByName,
        'super_admin',
        expense.adminApprovedByJobTitle,
        expense.adminApprovedByPhotoURL
      )
    : null;

  const rejecter = expense.rejectedBy
    ? resolveActor(
        expense.rejectedBy,
        expense.rejectedByName,
        expense.requestedByRole === 'payment_collector' && !expense.managerApprovedBy
          ? 'invoice_manager'
          : 'super_admin',
        expense.rejectedByJobTitle,
        expense.rejectedByPhotoURL
      )
    : null;

  const disburser = expense.executedBy
    ? resolveActor(
        expense.executedBy,
        expense.executedByName,
        'super_admin',
        expense.executedByJobTitle,
        expense.executedByPhotoURL
      )
    : null;

  const currentStatus = expense.status || 'draft';
  const revisionCount = expense.revision || 1;
  const hasRevisions = Array.isArray(expense.revisions) && expense.revisions.length > 0;

  return (
    <div
      data-testid="expense-workflow-info-box"
      className={`bg-neutral-50 rounded-xl border border-neutral-200 p-3 sm:p-4 text-xs space-y-3.5 shadow-2xs ${className}`}
    >
      {/* Workflow Header: Current Status & Revision Meta */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-2.5 border-b border-neutral-200">
        <div className="flex items-center gap-2 flex-wrap">
          <span className="font-bold uppercase tracking-wider text-[10px] text-neutral-500">
            Workflow Audit &amp; Identity
          </span>
          {revisionCount > 1 && (
            <span className="px-1.5 py-0.5 rounded text-[10px] font-bold bg-blue-100 text-blue-800 border border-blue-200">
              Revision {revisionCount}
            </span>
          )}
        </div>
        <div className="flex items-center gap-2 flex-wrap">
          <span className="text-[11px] text-neutral-500">
            Status: <strong className="text-neutral-800 capitalize">{currentStatus.replace('_', ' ')}</strong>
          </span>
          {expense.date && (
            <span className="text-[11px] text-neutral-400 font-mono">
              • Date: {formatDate(expense.date)}
            </span>
          )}
        </div>
      </div>

      {/* Prominent Rejection Reason Banner if rejected */}
      {currentStatus === 'rejected' && expense.rejectionReason && (
        <div
          data-testid="rejection-reason-callout"
          className="p-3 bg-rose-50 border border-rose-200 rounded-lg text-rose-900 space-y-1.5 animate-in fade-in duration-150"
        >
          <div className="flex items-start gap-2">
            <XCircle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
            <div className="min-w-0 flex-1">
              <div className="font-bold text-rose-800 text-[11px] uppercase tracking-wide flex items-center justify-between flex-wrap gap-1">
                <span>Expense Request Rejected</span>
                {expense.rejectedAt && (
                  <span className="font-mono text-[10px] font-normal text-rose-600">
                    {formatDate(expense.rejectedAt)}
                  </span>
                )}
              </div>
              <p className="text-xs text-rose-900 mt-1 font-medium break-words leading-relaxed">
                &ldquo;{expense.rejectionReason}&rdquo;
              </p>
              {rejecter && (
                <div className="mt-2 flex items-center gap-2 pt-1.5 border-t border-rose-200/60 text-[11px]">
                  <AvatarPreview
                    name={rejecter.name}
                    photoURL={rejecter.photoURL}
                    size="xs"
                  />
                  <div className="min-w-0 truncate">
                    <span className="font-bold text-rose-950">{rejecter.name}</span>
                    <span className="text-rose-700 ml-1.5 text-[10px]">
                      ({formatRoleLabel(rejecter.role, rejecter.jobTitle)})
                    </span>
                    {rejecter.stableId && (
                      <span className="font-mono text-[9px] text-rose-600 ml-1.5">
                        ID: {rejecter.stableId}
                      </span>
                    )}
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Resubmission Corrections Banner if available */}
      {expense.resubmissionCorrections && (
        <div
          data-testid="resubmission-corrections-callout"
          className="p-2.5 bg-blue-50 border border-blue-200 rounded-lg text-blue-900 space-y-1"
        >
          <div className="flex items-center gap-1.5 font-bold text-[11px] text-blue-800 uppercase tracking-wide">
            <RotateCcw className="w-3.5 h-3.5 text-blue-600 shrink-0" />
            <span>Resubmission Correction Note</span>
          </div>
          <p className="text-xs text-blue-950 break-words leading-relaxed">
            {expense.resubmissionCorrections}
          </p>
        </div>
      )}

      {/* Structured Workflow Stages Grid - Responsive: Stacked on Mobile, Multi-col on Large */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-2.5 sm:gap-3">
        {/* Stage 1: Requester */}
        <div className="bg-white p-3 rounded-lg border border-neutral-200 space-y-2 flex flex-col justify-between">
          <div className="space-y-1.5">
            <div className="flex items-center justify-between">
              <span className="text-[10px] font-bold uppercase tracking-wider text-neutral-400 flex items-center gap-1">
                <User className="w-3 h-3 text-neutral-500" />
                1. Requested By
              </span>
              <span className="px-1.5 py-0.5 text-[9px] font-bold rounded bg-neutral-100 text-neutral-700">
                Initiator
              </span>
            </div>

            <div className="flex items-start gap-2.5 pt-1">
              <AvatarPreview
                name={requester.name}
                photoURL={requester.photoURL}
                size="sm"
              />
              <div className="min-w-0 flex-1">
                <div className="font-bold text-neutral-900 text-xs truncate" title={requester.name}>
                  {requester.name}
                </div>
                <div className="text-[11px] text-neutral-600 font-medium truncate" title={formatRoleLabel(requester.role, requester.jobTitle)}>
                  {formatRoleLabel(requester.role, requester.jobTitle)}
                </div>
                {requester.stableId && (
                  <div className="text-[9px] font-mono text-neutral-400 mt-0.5 truncate" title={`User ID: ${requester.stableId}`}>
                    ID: {requester.stableId}
                  </div>
                )}
              </div>
            </div>
          </div>

          <div className="pt-2 border-t border-neutral-100 text-[10px] text-neutral-400 flex items-center justify-between">
            <span>Requested On:</span>
            <span className="font-mono text-neutral-600">
              {expense.createdAt ? formatDate(expense.createdAt) : expense.date ? formatDate(expense.date) : '—'}
            </span>
          </div>
        </div>

        {/* Stage 2: Invoice Manager Review */}
        <div className="bg-white p-3 rounded-lg border border-neutral-200 space-y-2 flex flex-col justify-between">
          <div className="space-y-1.5">
            <div className="flex items-center justify-between">
              <span className="text-[10px] font-bold uppercase tracking-wider text-neutral-400 flex items-center gap-1">
                <Building className="w-3 h-3 text-neutral-500" />
                2. Manager Review
              </span>
              {expense.managerApprovedAt ? (
                <span className="px-1.5 py-0.5 text-[9px] font-bold rounded bg-emerald-100 text-emerald-800 flex items-center gap-1">
                  <Check className="w-2.5 h-2.5" /> Approved
                </span>
              ) : currentStatus === 'rejected' && rejecter && rejecter.role === 'invoice_manager' ? (
                <span className="px-1.5 py-0.5 text-[9px] font-bold rounded bg-rose-100 text-rose-800 flex items-center gap-1">
                  <XCircle className="w-2.5 h-2.5" /> Rejected
                </span>
              ) : currentStatus === 'pending_manager' ? (
                <span className="px-1.5 py-0.5 text-[9px] font-bold rounded bg-amber-100 text-amber-800 flex items-center gap-1">
                  <Clock className="w-2.5 h-2.5" /> Pending
                </span>
              ) : (
                <span className="px-1.5 py-0.5 text-[9px] font-bold rounded bg-neutral-100 text-neutral-500">
                  {expense.requestedByRole === 'invoice_manager' ? 'Self Created' : 'Skipped / Direct'}
                </span>
              )}
            </div>

            {managerApprover ? (
              <div className="flex items-start gap-2.5 pt-1">
                <AvatarPreview
                  name={managerApprover.name}
                  photoURL={managerApprover.photoURL}
                  size="sm"
                />
                <div className="min-w-0 flex-1">
                  <div className="font-bold text-neutral-900 text-xs truncate" title={managerApprover.name}>
                    {managerApprover.name}
                  </div>
                  <div className="text-[11px] text-neutral-600 font-medium truncate" title={formatRoleLabel('invoice_manager', managerApprover.jobTitle)}>
                    {formatRoleLabel('invoice_manager', managerApprover.jobTitle)}
                  </div>
                  {managerApprover.stableId && (
                    <div className="text-[9px] font-mono text-neutral-400 mt-0.5 truncate" title={`User ID: ${managerApprover.stableId}`}>
                      ID: {managerApprover.stableId}
                    </div>
                  )}
                </div>
              </div>
            ) : currentStatus === 'pending_manager' ? (
              <div className="pt-2 text-neutral-500 italic text-[11px] flex items-center gap-1.5">
                <Clock className="w-3.5 h-3.5 text-amber-500 shrink-0" />
                <span>Awaiting Invoice Manager authorization...</span>
              </div>
            ) : (
              <div className="pt-2 text-neutral-400 text-[11px]">
                {expense.requestedByRole === 'invoice_manager'
                  ? 'Request initiated directly by Manager; proceeds to Super Admin.'
                  : 'No manager review recorded.'}
              </div>
            )}
          </div>

          <div className="pt-2 border-t border-neutral-100 text-[10px] text-neutral-400 flex items-center justify-between">
            <span>Reviewed On:</span>
            <span className="font-mono text-neutral-600">
              {expense.managerApprovedAt ? formatDate(expense.managerApprovedAt) : '—'}
            </span>
          </div>
        </div>

        {/* Stage 3: Super Admin Approval & Execution */}
        <div className="bg-white p-3 rounded-lg border border-neutral-200 space-y-2 flex flex-col justify-between">
          <div className="space-y-1.5">
            <div className="flex items-center justify-between">
              <span className="text-[10px] font-bold uppercase tracking-wider text-neutral-400 flex items-center gap-1">
                <ShieldCheck className="w-3 h-3 text-neutral-500" />
                3. Super Admin Review
              </span>
              {expense.status === 'executed' ? (
                <span className="px-1.5 py-0.5 text-[9px] font-bold rounded bg-emerald-100 text-emerald-800 flex items-center gap-1">
                  <CheckCircle2 className="w-2.5 h-2.5" /> Executed
                </span>
              ) : expense.adminApprovedAt || expense.status === 'approved' ? (
                <span className="px-1.5 py-0.5 text-[9px] font-bold rounded bg-emerald-100 text-emerald-800 flex items-center gap-1">
                  <Check className="w-2.5 h-2.5" /> Approved
                </span>
              ) : currentStatus === 'rejected' && rejecter && (rejecter.role === 'super_admin' || expense.requestedByRole === 'invoice_manager') ? (
                <span className="px-1.5 py-0.5 text-[9px] font-bold rounded bg-rose-100 text-rose-800 flex items-center gap-1">
                  <XCircle className="w-2.5 h-2.5" /> Rejected
                </span>
              ) : currentStatus === 'pending_admin' ? (
                <span className="px-1.5 py-0.5 text-[9px] font-bold rounded bg-amber-100 text-amber-800 flex items-center gap-1">
                  <Clock className="w-2.5 h-2.5" /> Pending
                </span>
              ) : (
                <span className="px-1.5 py-0.5 text-[9px] font-bold rounded bg-neutral-100 text-neutral-500">
                  Waiting
                </span>
              )}
            </div>

            {adminApprover ? (
              <div className="flex items-start gap-2.5 pt-1">
                <AvatarPreview
                  name={adminApprover.name}
                  photoURL={adminApprover.photoURL}
                  size="sm"
                />
                <div className="min-w-0 flex-1">
                  <div className="font-bold text-neutral-900 text-xs truncate" title={adminApprover.name}>
                    {adminApprover.name}
                  </div>
                  <div className="text-[11px] text-neutral-600 font-medium truncate" title={formatRoleLabel('super_admin', adminApprover.jobTitle)}>
                    {formatRoleLabel('super_admin', adminApprover.jobTitle)}
                  </div>
                  {adminApprover.stableId && (
                    <div className="text-[9px] font-mono text-neutral-400 mt-0.5 truncate" title={`User ID: ${adminApprover.stableId}`}>
                      ID: {adminApprover.stableId}
                    </div>
                  )}
                </div>
              </div>
            ) : currentStatus === 'pending_admin' ? (
              <div className="pt-2 text-neutral-500 italic text-[11px] flex items-center gap-1.5">
                <Clock className="w-3.5 h-3.5 text-amber-500 shrink-0" />
                <span>Awaiting Super Admin authorization...</span>
              </div>
            ) : (
              <div className="pt-2 text-neutral-400 text-[11px]">
                {currentStatus === 'pending_manager'
                  ? 'Awaiting Stage 1 approval before Super Admin review.'
                  : 'Awaiting Super Admin review.'}
              </div>
            )}
          </div>

          <div className="pt-2 border-t border-neutral-100 text-[10px] text-neutral-400 flex items-center justify-between">
            <span>Approved On:</span>
            <span className="font-mono text-neutral-600">
              {expense.adminApprovedAt ? formatDate(expense.adminApprovedAt) : '—'}
            </span>
          </div>
        </div>
      </div>

      {/* Disbursement Details if executed */}
      {expense.status === 'executed' && disburser && (
        <div className="p-3 bg-emerald-50/60 border border-emerald-200 rounded-lg text-emerald-950 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
            <div className="min-w-0">
              <span className="font-bold text-xs">Funds Disbursed &amp; Executed</span>
              <div className="text-[11px] text-emerald-800">
                Disbursed by <strong className="text-emerald-950">{disburser.name}</strong> ({formatRoleLabel('super_admin', disburser.jobTitle)})
                {disburser.stableId && <span className="font-mono text-[9px] ml-1">ID: {disburser.stableId}</span>}
              </div>
            </div>
          </div>
          <div className="text-right sm:shrink-0 text-[11px] font-mono text-emerald-900">
            {expense.executedAt && <div>{formatDate(expense.executedAt)}</div>}
            {expense.disbursedAmount && (
              <div className="font-bold text-xs">{formatAFN(expense.disbursedAmount)} ({expense.disbursementMethod || 'Direct'})</div>
            )}
          </div>
        </div>
      )}

      {/* Revisions History Drawer / Summary if multiple revisions exist */}
      {hasRevisions && (
        <div className="p-2.5 bg-neutral-100 rounded-lg border border-neutral-200 space-y-1.5">
          <div className="flex items-center gap-1.5 font-bold text-[11px] text-neutral-700">
            <History className="w-3.5 h-3.5 text-neutral-600" />
            <span>Previous Revisions ({expense.revisions?.length})</span>
          </div>
          <div className="space-y-1">
            {expense.revisions?.map((rev, idx) => (
              <div key={idx} className="text-[11px] text-neutral-600 flex justify-between items-baseline gap-2 bg-white px-2 py-1 rounded border border-neutral-200">
                <span className="font-semibold text-neutral-800">
                  Revision #{rev.revisionNumber || idx + 1}: {rev.rejectionReason ? `Rejected ("${rev.rejectionReason}")` : 'Resubmitted'}
                </span>
                <span className="font-mono text-[10px] text-neutral-400 shrink-0">
                  {rev.rejectedAt ? formatDate(rev.rejectedAt) : rev.timestamp ? formatDate(rev.timestamp) : ''}
                </span>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

/**
 * Safe, robust Avatar renderer with image failure fallback to initials.
 */
interface AvatarPreviewProps {
  name: string;
  photoURL?: string;
  size?: 'xs' | 'sm' | 'md';
}

export const AvatarPreview: React.FC<AvatarPreviewProps> = ({
  name,
  photoURL,
  size = 'sm',
}) => {
  const [imgError, setImgError] = React.useState(false);

  const sizeClasses = {
    xs: 'w-5 h-5 text-[9px]',
    sm: 'w-7 h-7 text-[10px]',
    md: 'w-9 h-9 text-xs',
  }[size];

  const initials = getActorInitials(name);

  if (photoURL && !imgError) {
    return (
      <img
        src={photoURL}
        alt={name}
        onError={() => setImgError(true)}
        className={`${sizeClasses} rounded-full object-cover shrink-0 ring-1 ring-neutral-200 bg-neutral-100`}
      />
    );
  }

  return (
    <div
      className={`${sizeClasses} rounded-full bg-neutral-800 text-white font-bold flex items-center justify-center shrink-0 ring-1 ring-neutral-300 select-none shadow-2xs`}
      title={name}
      aria-label={name}
    >
      {initials}
    </div>
  );
};
