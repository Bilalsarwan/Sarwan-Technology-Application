import React, { useEffect, useMemo, useState } from 'react';
import {
  X,
  History,
  CheckCircle2,
  XCircle,
  Clock,
  RotateCcw,
  Calendar,
  FileEdit,
  User,
  Check,
  Receipt,
  FileText,
  Circle,
} from 'lucide-react';
import { Expense, ExpenseTimelineEntry, UserProfile } from '../../types';
import { formatAFN, formatDateTime } from '../../utils/format';
import { getUsersByIds, resolveUserPhoto } from '../../services/db';
import { ExpenseStatusBadge } from '../../utils/expenseStatus';

export interface ExpenseAuditHistoryModalProps {
  expense: Expense;
  onClose: () => void;
  isOpen?: boolean;
  users?: UserProfile[];
}

export type SemanticWorkflowStatus =
  | 'approved'
  | 'rejected'
  | 'pending'
  | 'submitted'
  | 'resubmitted'
  | 'executed';

/**
 * Exact semantic status colors required by the Sarwan Technology Design System:
 * - Submitted: blue #2563EB
 * - Pending Manager Approval: blue #2563EB
 * - Pending Super Admin Approval: blue #2563EB
 * - Approved: green #16A34A
 * - Rejected: red #DC2626
 * - Resubmitted: blue #2563EB
 * - Executed & Disbursed: green #16A34A
 */
export const WORKFLOW_SEMANTIC_COLORS: Record<SemanticWorkflowStatus, string> = {
  approved: '#16A34A',
  rejected: '#DC2626',
  pending: '#2563EB',
  submitted: '#2563EB',
  resubmitted: '#2563EB',
  executed: '#16A34A',
};

/**
 * Resolves the semantic workflow status for a timeline entry.
 * CRITICAL RULE: Evaluates each event independently. Never uses the expense's current
 * overall status for every historical event. A submission or resubmission event will
 * NEVER display a green approved indicator.
 */
export function resolveEventStatus(entry: ExpenseTimelineEntry): SemanticWorkflowStatus {
  const actionLower = (entry.action || '').toLowerCase();

  // 1. Rejection: explicit rejectionReason or action contains 'reject'
  if (Boolean(entry.rejectionReason) || actionLower.includes('reject')) {
    return 'rejected'; // red #DC2626
  }

  // 2. Resubmitted: explicit corrections / correctionDescription or action contains 'resubmit'
  if (
    Boolean(entry.correctionDescription) ||
    Boolean(entry.corrections) ||
    actionLower.includes('resubmit')
  ) {
    return 'resubmitted'; // blue #2563EB
  }

  // 3. Executed & Disbursed: action contains 'executed' or 'disburs'
  if (actionLower.includes('executed') || actionLower.includes('disburs')) {
    return 'executed'; // green #16A34A
  }

  const entryStatus = entry.status as string | undefined;

  // 4. Pending: action mentions 'pending' or status is pending review
  if (
    actionLower.includes('pending') ||
    entryStatus === 'pending_manager' ||
    entryStatus === 'pending_admin' ||
    entryStatus === 'pending'
  ) {
    return 'pending'; // blue #2563EB
  }

  // 5. Approved: action explicitly mentions 'approv'
  if (actionLower.includes('approv')) {
    return 'approved'; // green #16A34A
  }

  // 6. Submitted: action mentions 'submit', 'request', 'created', or 'draft'
  if (
    actionLower.includes('submit') ||
    actionLower.includes('request') ||
    actionLower.includes('created') ||
    actionLower.includes('draft')
  ) {
    return 'submitted'; // blue #2563EB
  }

  // 7. Check entry.status only if action didn't resolve
  if (entryStatus) {
    if (entryStatus === 'rejected') return 'rejected';
    if (entryStatus === 'executed') return 'executed';
    if (entryStatus === 'approved') return 'approved';
    if (entryStatus === 'resubmitted') return 'resubmitted';
    if (
      entryStatus === 'pending_manager' ||
      entryStatus === 'pending_admin' ||
      entryStatus === 'pending'
    ) {
      return 'pending';
    }
    if (entryStatus === 'draft' || entryStatus === 'submitted') return 'submitted';
  }

  return 'submitted';
}

/**
 * Returns UI configuration matching exact semantic color and icon for each status.
 */
export function getStatusConfig(status: SemanticWorkflowStatus) {
  switch (status) {
    case 'approved':
      return {
        status,
        color: WORKFLOW_SEMANTIC_COLORS.approved, // #16A34A
        badgeLabel: 'Approved',
        icon: CheckCircle2,
        bgTint: '#16A34A12',
        borderTint: '#16A34A30',
        badgeBg: 'bg-emerald-50 dark:bg-emerald-950/40',
        badgeText: 'text-emerald-700 dark:text-emerald-300',
        badgeBorder: 'border-emerald-200 dark:border-emerald-800',
      };
    case 'rejected':
      return {
        status,
        color: WORKFLOW_SEMANTIC_COLORS.rejected, // #DC2626
        badgeLabel: 'Expense Request Rejected',
        icon: XCircle,
        bgTint: '#DC262612',
        borderTint: '#DC262630',
        badgeBg: 'bg-rose-50 dark:bg-rose-950/40',
        badgeText: 'text-rose-700 dark:text-rose-300',
        badgeBorder: 'border-rose-200 dark:border-rose-800',
      };
    case 'executed':
      return {
        status,
        color: WORKFLOW_SEMANTIC_COLORS.executed, // #16A34A
        badgeLabel: 'Executed & Disbursed',
        icon: CheckCircle2,
        bgTint: '#16A34A18',
        borderTint: '#16A34A35',
        badgeBg: 'bg-emerald-100 dark:bg-emerald-900/40',
        badgeText: 'text-emerald-800 dark:text-emerald-200',
        badgeBorder: 'border-emerald-300 dark:border-emerald-700',
      };
    case 'resubmitted':
      return {
        status,
        color: WORKFLOW_SEMANTIC_COLORS.resubmitted, // #2563EB
        badgeLabel: 'Expense Request Resubmitted',
        icon: RotateCcw,
        bgTint: '#2563EB12',
        borderTint: '#2563EB30',
        badgeBg: 'bg-blue-50 dark:bg-blue-950/40',
        badgeText: 'text-blue-700 dark:text-blue-300',
        badgeBorder: 'border-blue-200 dark:border-blue-800',
      };
    case 'pending':
      return {
        status,
        color: WORKFLOW_SEMANTIC_COLORS.pending, // #2563EB
        badgeLabel: 'Pending Review',
        icon: Clock,
        bgTint: '#2563EB12',
        borderTint: '#2563EB30',
        badgeBg: 'bg-blue-50 dark:bg-blue-950/40',
        badgeText: 'text-blue-700 dark:text-blue-300',
        badgeBorder: 'border-blue-200 dark:border-blue-800',
      };
    case 'submitted':
    default:
      return {
        status: 'submitted' as SemanticWorkflowStatus,
        color: WORKFLOW_SEMANTIC_COLORS.submitted, // #2563EB
        badgeLabel: 'Expense Request Submitted',
        icon: Check,
        bgTint: '#2563EB12',
        borderTint: '#2563EB30',
        badgeBg: 'bg-blue-50 dark:bg-blue-950/40',
        badgeText: 'text-blue-700 dark:text-blue-300',
        badgeBorder: 'border-blue-200 dark:border-blue-800',
      };
  }
}

/**
 * Normalizes an expense's timeline into an authoritative chronological list.
 * Includes revisions, submission, manager approval, super admin approval,
 * rejections, and execution events.
 */
export function normalizeExpenseTimeline(expense: Expense): ExpenseTimelineEntry[] {
  const existingEntries: ExpenseTimelineEntry[] = [];

  if (Array.isArray(expense.timeline) && expense.timeline.length > 0) {
    existingEntries.push(...expense.timeline);
  } else {
    // Reconstruct chronological timeline from historical record fields
    // 1. Initial Request Submission
    existingEntries.push({
      action: 'Expense Request Submitted',
      performedBy: expense.requestedBy || 'requester',
      performedByName: expense.requestedByName || 'Authorized Requester',
      performedByRole: expense.requestedByRole || 'staff',
      performedByJobTitle: expense.requestedByJobTitle,
      performedByPhotoURL: expense.requestedByPhotoURL,
      timestamp: expense.createdAt || expense.date || '',
      note: expense.note,
      status: 'submitted',
    });

    // 2. Revisions if recorded in expense.revisions
    if (Array.isArray(expense.revisions) && expense.revisions.length > 0) {
      expense.revisions.forEach((rev) => {
        // Rejection event for revision
        existingEntries.push({
          action: 'Expense Request Rejected',
          performedBy: rev.rejectedBy || 'reviewer',
          performedByName: rev.rejectedByName || 'Reviewer',
          performedByRole: 'invoice_manager',
          timestamp: rev.rejectedAt || rev.timestamp || '',
          rejectionReason: rev.rejectionReason,
          revision: rev.revisionNumber,
          status: 'rejected',
        });

        // Resubmission event for revision
        existingEntries.push({
          action: 'Expense Request Resubmitted',
          performedBy: expense.requestedBy || 'requester',
          performedByName: expense.requestedByName || 'Authorized Requester',
          performedByRole: expense.requestedByRole || 'staff',
          performedByJobTitle: expense.requestedByJobTitle,
          performedByPhotoURL: expense.requestedByPhotoURL,
          timestamp: rev.timestamp || '',
          corrections: rev.corrections || rev.correctionDescription,
          correctionDescription: rev.correctionDescription || rev.corrections,
          revision: (rev.revisionNumber || 1) + 1,
          status: 'resubmitted',
        });
      });
    }

    // 3. Manager Approval if recorded
    if (expense.managerApprovedAt) {
      existingEntries.push({
        action: 'Invoice Manager Approved',
        performedBy: expense.managerApprovedBy || 'manager',
        performedByName: expense.managerApprovedByName || 'Invoice Manager',
        performedByRole: 'invoice_manager',
        performedByJobTitle: expense.managerApprovedByJobTitle,
        performedByPhotoURL: expense.managerApprovedByPhotoURL,
        timestamp: expense.managerApprovedAt,
        status: 'approved',
      });
    }

    // 4. Admin Approval if recorded
    if (expense.adminApprovedAt) {
      existingEntries.push({
        action: 'Super Admin Approved',
        performedBy: expense.adminApprovedBy || 'admin',
        performedByName: expense.adminApprovedByName || 'Super Admin',
        performedByRole: 'super_admin',
        performedByJobTitle: expense.adminApprovedByJobTitle,
        performedByPhotoURL: expense.adminApprovedByPhotoURL,
        timestamp: expense.adminApprovedAt,
        status: 'approved',
      });
    }

    // 5. Current rejection if currently rejected
    if (expense.status === 'rejected' && expense.rejectionReason) {
      existingEntries.push({
        action: 'Expense Request Rejected',
        performedBy: expense.rejectedBy || 'reviewer',
        performedByName: expense.rejectedByName || 'Reviewer',
        performedByRole:
          expense.requestedByRole === 'payment_collector' && !expense.managerApprovedBy
            ? 'invoice_manager'
            : 'super_admin',
        performedByJobTitle: expense.rejectedByJobTitle,
        performedByPhotoURL: expense.rejectedByPhotoURL,
        timestamp: expense.rejectedAt || expense.updatedAt || '',
        rejectionReason: expense.rejectionReason,
        status: 'rejected',
      });
    }

    // 6. Execution / Disbursement if recorded
    if (expense.status === 'executed' || expense.executionStatus === 'executed') {
      existingEntries.push({
        action: 'Expense Executed & Disbursed',
        performedBy: expense.executedBy || 'finance',
        performedByName: expense.executedByName || 'Finance Admin',
        performedByRole: 'super_admin',
        performedByJobTitle: expense.executedByJobTitle,
        performedByPhotoURL: expense.executedByPhotoURL,
        timestamp: expense.executedAt || expense.updatedAt || '',
        status: 'executed',
      });
    }
  }

  // Enrich timeline entries with job titles from top-level fields if missing
  for (const entry of existingEntries) {
    if (!entry.performedByJobTitle) {
      const actLower = (entry.action || '').toLowerCase();
      if (actLower.includes('submit') || actLower.includes('request')) {
        entry.performedByJobTitle = expense.requestedByJobTitle;
      } else if (actLower.includes('manager approv')) {
        entry.performedByJobTitle = expense.managerApprovedByJobTitle;
      } else if (actLower.includes('admin approv')) {
        entry.performedByJobTitle = expense.adminApprovedByJobTitle;
      } else if (actLower.includes('reject')) {
        entry.performedByJobTitle = expense.rejectedByJobTitle;
      } else if (actLower.includes('executed')) {
        entry.performedByJobTitle = expense.executedByJobTitle;
      }
    }
  }

  // Deduplicate entries by timestamp + action + revision + performedBy
  const seenKeys = new Set<string>();
  const deduplicated: ExpenseTimelineEntry[] = [];

  for (const entry of existingEntries) {
    const key = `${entry.timestamp || ''}_${entry.action || ''}_${entry.revision || ''}_${entry.performedBy || ''}`;
    if (!seenKeys.has(key)) {
      seenKeys.add(key);
      deduplicated.push(entry);
    }
  }

  // Chronological sort: oldest events first
  const sorted = deduplicated.sort((a, b) => {
    const timeA = a.timestamp ? new Date(a.timestamp).getTime() : 0;
    const timeB = b.timestamp ? new Date(b.timestamp).getTime() : 0;
    return timeA - timeB;
  });

  return sorted;
}

/**
 * Returns human-readable role display name with safe fallback.
 */
export function formatRoleLabel(role?: string, jobTitle?: string): string {
  if (jobTitle && jobTitle.trim()) {
    if (role && role !== 'staff' && !jobTitle.toLowerCase().includes(role.replace('_', ' '))) {
      return `${jobTitle.trim()} • ${formatRoleName(role)}`;
    }
    return jobTitle.trim();
  }
  return formatRoleName(role);
}

function formatRoleName(role?: string): string {
  if (!role) return 'Authorized Staff';
  switch (role) {
    case 'super_admin':
      return 'Super Admin';
    case 'invoice_manager':
      return 'Invoice Manager';
    case 'payment_collector':
      return 'Payment Collector';
    case 'customer':
      return 'Customer';
    default:
      return role.replace(/_/g, ' ').replace(/\b\w/g, (c) => c.toUpperCase());
  }
}

/**
 * Derives safe two-letter initials from name or fallback.
 */
export function getActorInitials(name?: string): string {
  if (!name || !name.trim()) return 'ST';
  const parts = name.trim().split(/\s+/);
  if (parts.length === 1) {
    return parts[0].slice(0, 2).toUpperCase();
  }
  return (parts[0][0] + parts[parts.length - 1][0]).toUpperCase();
}

/**
 * Resolves the real profile photo URL for an actor.
 * Checks the actor's live user profile (photoURL / photoUrl / avatar)
 * as well as immutable timeline snapshot photo URLs.
 */
export function resolveActorPhoto(
  entry: ExpenseTimelineEntry,
  userProfile?: Partial<UserProfile> | null
): string | null {
  // 1. Live profile photo from users collection
  const livePhoto = resolveUserPhoto(userProfile);
  if (livePhoto) return livePhoto;

  // 2. Snapshot photo recorded in timeline entry
  const entryPhoto =
    entry.performedByPhotoURL ||
    (entry as any).photoURL ||
    (entry as any).photoUrl ||
    (entry as any).avatar;
  if (typeof entryPhoto === 'string' && entryPhoto.trim()) {
    return entryPhoto.trim();
  }

  return null;
}

/**
 * Resolves the display name for a timeline actor without leaking user IDs.
 */
export function resolveActorName(
  entry: ExpenseTimelineEntry,
  userProfile?: Partial<UserProfile> | null
): string {
  if (userProfile?.name && userProfile.name.trim()) {
    const raw = (entry.performedByName || '').trim().toLowerCase();
    // If the entry stored a generic placeholder like 'Staff' or 'Reviewer', upgrade to live real name
    if (
      !raw ||
      raw === 'staff' ||
      raw === 'reviewer' ||
      raw === 'authorized requester' ||
      raw === 'unknown'
    ) {
      return userProfile.name.trim();
    }
    return entry.performedByName!.trim();
  }

  if (entry.performedByName && entry.performedByName.trim()) {
    return entry.performedByName.trim();
  }

  return formatRoleName(entry.performedByRole);
}

/**
 * Resolves the display stage title for a recorded timeline event.
 */
export function getEventStageTitle(
  entry: ExpenseTimelineEntry,
  semanticStatus: SemanticWorkflowStatus
): string {
  const actionLower = (entry.action || '').toLowerCase();
  if (semanticStatus === 'rejected' || actionLower.includes('reject')) {
    return 'Rejection Event';
  }
  if (semanticStatus === 'resubmitted' || actionLower.includes('resubmit')) {
    return 'Resubmission Event';
  }
  if (
    semanticStatus === 'executed' ||
    actionLower.includes('execut') ||
    actionLower.includes('disburs')
  ) {
    return 'Expense Executed & Disbursed';
  }
  if (actionLower.includes('super admin') && actionLower.includes('approv')) {
    return 'Super Admin Approval';
  }
  if (actionLower.includes('manager') && actionLower.includes('approv')) {
    return 'Manager Approval';
  }
  if (actionLower.includes('approv')) {
    return 'Approval Granted';
  }
  if (
    actionLower.includes('submit') ||
    actionLower.includes('request') ||
    actionLower.includes('created') ||
    actionLower.includes('draft') ||
    semanticStatus === 'submitted'
  ) {
    return 'Request Submitted';
  }
  return entry.action || 'Workflow Event';
}

/**
 * Resolves the action description phrase for the actor/action flow.
 */
export function getActionDescription(
  entry: ExpenseTimelineEntry,
  semanticStatus: SemanticWorkflowStatus,
  amount?: number
): string {
  if (entry.details && entry.details.trim()) {
    return entry.details.trim();
  }

  const actionLower = (entry.action || '').toLowerCase();
  if (semanticStatus === 'rejected' || actionLower.includes('reject')) {
    return 'Expense request rejected during review process.';
  }
  if (semanticStatus === 'resubmitted' || actionLower.includes('resubmit')) {
    return 'Expense request updated with corrections and resubmitted for review.';
  }
  if (
    semanticStatus === 'executed' ||
    actionLower.includes('execut') ||
    actionLower.includes('disburs')
  ) {
    return 'Expense payment disbursed and recorded in billing system.';
  }
  if (actionLower.includes('super admin') && actionLower.includes('approv')) {
    return 'Super Admin granted final approval for expense execution.';
  }
  if (actionLower.includes('manager') && actionLower.includes('approv')) {
    return 'Invoice Manager approved request and forwarded to Super Admin.';
  }
  if (actionLower.includes('approv')) {
    return 'Expense request approved.';
  }
  if (
    actionLower.includes('submit') ||
    actionLower.includes('request') ||
    actionLower.includes('created') ||
    semanticStatus === 'submitted'
  ) {
    return amount
      ? `Submitted expense request for ${formatAFN(amount)}.`
      : 'Submitted expense request for approval.';
  }

  return entry.action || 'Workflow action recorded.';
}

/**
 * Visual Approval Milestone structure for the timeline.
 */
export interface ApprovalMilestone {
  id: 'submitted' | 'manager_approval' | 'admin_approval' | 'execution';
  label: string;
  roleHint: string;
  status: 'completed' | 'current' | 'rejected' | 'upcoming';
  statusLabel: string;
  timestamp?: string;
  actorName?: string;
}

/**
 * Derives the workflow stages and completion states according to the requester's role.
 * Collector: Submitted -> Manager Review -> Super Admin Approval -> Disbursement (4 stages)
 * Invoice Manager: Submitted -> Super Admin Review -> Disbursement (3 stages)
 */
export function getApprovalProgressStages(expense: Expense): ApprovalMilestone[] {
  const isCollector = expense.requestedByRole === 'payment_collector';
  const rawStatus = (expense.status || '').toLowerCase();
  const isRejected = rawStatus === 'rejected';
  const isExecuted = rawStatus === 'executed' || expense.executionStatus === 'executed';
  const isApproved = rawStatus === 'approved' || isExecuted;

  // 1. Submission stage (Always completed once the expense exists)
  const submittedStage: ApprovalMilestone = {
    id: 'submitted',
    label: 'Request Submitted',
    roleHint: formatRoleLabel(expense.requestedByRole, expense.requestedByJobTitle) || 'Authorized Requester',
    status: 'completed',
    statusLabel: 'Submitted',
    timestamp: expense.createdAt || expense.date,
    actorName: expense.requestedByName,
  };

  if (isCollector) {
    // 2. Collector Stage: Invoice Manager Approval
    const managerApproved = Boolean(expense.managerApprovedAt || expense.managerApprovedBy);
    const isCurrentManager =
      rawStatus === 'pending_manager' ||
      rawStatus === 'draft' ||
      (rawStatus as string) === 'requested';
    const isRejectedAtManager = isRejected && !managerApproved;

    let managerStatus: ApprovalMilestone['status'] = 'upcoming';
    let managerStatusLabel = 'Upcoming';
    if (isRejectedAtManager) {
      managerStatus = 'rejected';
      managerStatusLabel = 'Rejected by Manager';
    } else if (managerApproved || isApproved || rawStatus === 'pending_admin') {
      managerStatus = 'completed';
      managerStatusLabel = 'Approved by Manager';
    } else if (isCurrentManager) {
      managerStatus = 'current';
      managerStatusLabel = 'Awaiting Manager Review';
    }

    const managerStage: ApprovalMilestone = {
      id: 'manager_approval',
      label: 'Manager Approval',
      roleHint: 'Invoice Manager',
      status: managerStatus,
      statusLabel: managerStatusLabel,
      timestamp: expense.managerApprovedAt,
      actorName: expense.managerApprovedByName,
    };

    // 3. Collector Stage: Super Admin Approval
    const adminApproved = Boolean(expense.adminApprovedAt || expense.adminApprovedBy || isApproved);
    const isCurrentAdmin = rawStatus === 'pending_admin';
    const isRejectedAtAdmin = isRejected && managerApproved;

    let adminStatus: ApprovalMilestone['status'] = 'upcoming';
    let adminStatusLabel = 'Upcoming';
    if (isRejectedAtAdmin) {
      adminStatus = 'rejected';
      adminStatusLabel = 'Rejected by Super Admin';
    } else if (adminApproved) {
      adminStatus = 'completed';
      adminStatusLabel = 'Approved by Super Admin';
    } else if (isCurrentAdmin) {
      adminStatus = 'current';
      adminStatusLabel = 'Awaiting Super Admin';
    }

    const adminStage: ApprovalMilestone = {
      id: 'admin_approval',
      label: 'Super Admin Approval',
      roleHint: 'Super Admin',
      status: adminStatus,
      statusLabel: adminStatusLabel,
      timestamp: expense.adminApprovedAt,
      actorName: expense.adminApprovedByName,
    };

    // 4. Collector Stage: Execution / Disbursement
    let executionStatus: ApprovalMilestone['status'] = 'upcoming';
    let executionStatusLabel = 'Upcoming';
    if (isExecuted) {
      executionStatus = 'completed';
      executionStatusLabel = 'Disbursed';
    } else if (rawStatus === 'approved') {
      executionStatus = 'current';
      executionStatusLabel = 'Ready for Disbursement';
    }

    const executionStage: ApprovalMilestone = {
      id: 'execution',
      label: 'Disbursement',
      roleHint: 'Super Admin / Finance',
      status: executionStatus,
      statusLabel: executionStatusLabel,
      timestamp: expense.executedAt,
      actorName: expense.executedByName,
    };

    return [submittedStage, managerStage, adminStage, executionStage];
  } else {
    // Invoice Manager Workflow: Submitted -> Super Admin Approval -> Disbursement
    const adminApproved = Boolean(expense.adminApprovedAt || expense.adminApprovedBy || isApproved);
    const isCurrentAdmin =
      rawStatus === 'pending_admin' ||
      rawStatus === 'pending_manager' ||
      rawStatus === 'draft' ||
      (rawStatus as string) === 'requested';

    let adminStatus: ApprovalMilestone['status'] = 'upcoming';
    let adminStatusLabel = 'Upcoming';
    if (isRejected) {
      adminStatus = 'rejected';
      adminStatusLabel = 'Rejected by Super Admin';
    } else if (adminApproved) {
      adminStatus = 'completed';
      adminStatusLabel = 'Approved by Super Admin';
    } else if (isCurrentAdmin) {
      adminStatus = 'current';
      adminStatusLabel = 'Awaiting Super Admin Review';
    }

    const adminStage: ApprovalMilestone = {
      id: 'admin_approval',
      label: 'Super Admin Approval',
      roleHint: 'Super Admin',
      status: adminStatus,
      statusLabel: adminStatusLabel,
      timestamp: expense.adminApprovedAt,
      actorName: expense.adminApprovedByName,
    };

    // Execution / Disbursement
    let executionStatus: ApprovalMilestone['status'] = 'upcoming';
    let executionStatusLabel = 'Upcoming';
    if (isExecuted) {
      executionStatus = 'completed';
      executionStatusLabel = 'Disbursed';
    } else if (rawStatus === 'approved') {
      executionStatus = 'current';
      executionStatusLabel = 'Ready for Disbursement';
    }

    const executionStage: ApprovalMilestone = {
      id: 'execution',
      label: 'Disbursement',
      roleHint: 'Super Admin / Finance',
      status: executionStatus,
      statusLabel: executionStatusLabel,
      timestamp: expense.executedAt,
      actorName: expense.executedByName,
    };

    return [submittedStage, adminStage, executionStage];
  }
}

/**
 * Item representing an upcoming or pending milestone along the continuous vertical timeline.
 */
export interface PendingStageItem {
  id: string;
  stageName: string;
  status: 'current' | 'upcoming';
  statusBadgeLabel: string;
  roleHint: string;
  description: string;
}

/**
 * Computes pending workflow milestones that follow the recorded activity history
 * along the continuous vertical timeline.
 */
export function getPendingStagesForTimeline(expense: Expense): PendingStageItem[] {
  const rawStatus = (expense.status || '').toLowerCase();
  const isExecuted = rawStatus === 'executed' || expense.executionStatus === 'executed';
  if (isExecuted) return [];

  const isRejected = rawStatus === 'rejected';
  if (isRejected) {
    return [
      {
        id: 'resubmission',
        stageName: 'Request Resubmission',
        status: 'current',
        statusBadgeLabel: 'Awaiting Resubmission',
        roleHint:
          formatRoleLabel(expense.requestedByRole, expense.requestedByJobTitle) ||
          'Authorized Requester',
        description:
          'Review the rejection feedback above, adjust expense details or attachments, and resubmit.',
      },
    ];
  }

  const isApproved =
    rawStatus === 'approved' ||
    (Boolean(expense.adminApprovedAt) && !isExecuted && rawStatus !== 'rejected');
  if (isApproved) {
    return [
      {
        id: 'execution',
        stageName: 'Disbursement & Payment Execution',
        status: 'current',
        statusBadgeLabel: 'Ready for Disbursement',
        roleHint: 'Super Admin / Finance',
        description:
          'Expense has received all required authorizations and is queued for fund disbursement.',
      },
    ];
  }

  const isCollector = expense.requestedByRole === 'payment_collector';
  const managerApproved = Boolean(expense.managerApprovedAt || expense.managerApprovedBy);

  if (isCollector && !managerApproved && rawStatus !== 'pending_admin') {
    return [
      {
        id: 'manager_approval',
        stageName: 'Manager Approval',
        status: 'current',
        statusBadgeLabel: 'Awaiting Manager Review',
        roleHint: 'Invoice Manager',
        description: 'Pending review and verification by the assigned Invoice Manager.',
      },
      {
        id: 'admin_approval',
        stageName: 'Super Admin Approval',
        status: 'upcoming',
        statusBadgeLabel: 'Pending Super Admin',
        roleHint: 'Super Admin',
        description: 'Pending secondary review and executive authorization by Super Admin.',
      },
      {
        id: 'execution',
        stageName: 'Disbursement',
        status: 'upcoming',
        statusBadgeLabel: 'Pending Disbursement',
        roleHint: 'Super Admin / Finance',
        description: 'Pending final payment execution upon completion of all approvals.',
      },
    ];
  }

  // Awaiting Super Admin Review
  return [
    {
      id: 'admin_approval',
      stageName: 'Super Admin Approval',
      status: 'current',
      statusBadgeLabel: 'Awaiting Super Admin Review',
      roleHint: 'Super Admin',
      description: isCollector
        ? 'Invoice Manager has approved. Awaiting final executive authorization by Super Admin.'
        : 'Direct submission awaiting final executive review and authorization by Super Admin.',
    },
    {
      id: 'execution',
      stageName: 'Disbursement',
      status: 'upcoming',
      statusBadgeLabel: 'Pending Disbursement',
      roleHint: 'Super Admin / Finance',
      description: 'Pending payment disbursement once Super Admin approves.',
    },
  ];
}

export const ExpenseAuditHistoryModal: React.FC<ExpenseAuditHistoryModalProps> = ({
  expense,
  onClose,
  isOpen = true,
  users = [],
}) => {
  // Close on Escape key
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        onClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [onClose]);

  // Compute normalized chronological timeline of actual events
  const timelineEvents = useMemo(() => {
    return normalizeExpenseTimeline(expense);
  }, [expense]);

  // Compute approval progress milestones for status calculations
  const progressMilestones = useMemo(() => {
    return getApprovalProgressStages(expense);
  }, [expense]);

  // Compute pending workflow milestones along the continuous vertical line
  const pendingStages = useMemo(() => {
    return getPendingStagesForTimeline(expense);
  }, [expense]);

  // Derived expense reference identifier (non-fabricated)
  const expenseReference = useMemo(() => {
    if (expense.billNumber) return `#${expense.billNumber}`;
    if (expense.id) {
      return expense.id.length > 10 ? `#${expense.id.slice(0, 8).toUpperCase()}` : `#${expense.id}`;
    }
    return null;
  }, [expense]);

  // Unified items along the single continuous vertical timeline
  const unifiedTimelineItems = useMemo(() => {
    const items: Array<
      | { kind: 'recorded'; entry: ExpenseTimelineEntry; key: string }
      | { kind: 'pending'; stage: PendingStageItem; key: string }
    > = [];

    // Chronological recorded events
    for (let i = 0; i < timelineEvents.length; i++) {
      const entry = timelineEvents[i];
      items.push({
        kind: 'recorded',
        entry,
        key: `event-${entry.timestamp || ''}-${entry.action || ''}-${i}`,
      });
    }

    // Followed by upcoming/pending workflow stages
    for (let j = 0; j < pendingStages.length; j++) {
      const stage = pendingStages[j];
      items.push({
        kind: 'pending',
        stage,
        key: `pending-stage-${stage.id}`,
      });
    }

    return items;
  }, [timelineEvents, pendingStages]);

  const completedStagesCount = useMemo(() => {
    return progressMilestones.filter((m) => m.status === 'completed').length;
  }, [progressMilestones]);

  const totalStagesCount = progressMilestones.length;

  // State to hold resolved user profiles for each actor
  const [userProfilesMap, setUserProfilesMap] = useState<Record<string, UserProfile>>(() => {
    const initialMap: Record<string, UserProfile> = {};
    if (users && users.length > 0) {
      for (const u of users) {
        if (!u) continue;
        if (u.id) initialMap[u.id] = u;
        if (u.userId) initialMap[u.userId] = u;
        if (u.authUid) initialMap[u.authUid] = u;
        if (u.googleUid) initialMap[u.googleUid] = u;
        if (u.username) initialMap[u.username] = u;
      }
    }
    return initialMap;
  });

  const [loadingProfiles, setLoadingProfiles] = useState<boolean>(true);
  const [failedImages, setFailedImages] = useState<Record<string, boolean>>({});

  // Asynchronously resolve actor profiles for all timeline events
  useEffect(() => {
    let isCancelled = false;

    // 1. Preload any profiles available in `users` prop
    const map: Record<string, UserProfile> = {};
    if (users && users.length > 0) {
      for (const u of users) {
        if (!u) continue;
        if (u.id) map[u.id] = u;
        if (u.userId) map[u.userId] = u;
        if (u.authUid) map[u.authUid] = u;
        if (u.googleUid) map[u.googleUid] = u;
        if (u.username) map[u.username] = u;
      }
    }

    // 2. Identify actor IDs in timelineEvents that are not yet in map
    const missingIds = timelineEvents
      .map((entry) => (entry.performedBy || '').trim())
      .filter((id): id is string => {
        return (
          id.length > 0 &&
          id !== 'unknown' &&
          id !== 'system' &&
          !id.startsWith('pending_') &&
          !map[id]
        );
      });

    // Also include top-level requester, reviewer, and executor IDs if missing
    const topLevelIds = [
      expense.requestedBy,
      expense.managerApprovedBy,
      expense.adminApprovedBy,
      expense.rejectedBy,
      expense.executedBy,
    ]
      .filter((id): id is string => Boolean(id && typeof id === 'string'))
      .map((id) => id.trim())
      .filter((id) => Boolean(id && !map[id]));

    const allMissingIds = Array.from(new Set([...missingIds, ...topLevelIds]));

    if (allMissingIds.length === 0) {
      setUserProfilesMap((prev) => ({ ...prev, ...map }));
      setLoadingProfiles(false);
      return;
    }

    getUsersByIds(allMissingIds)
      .then((fetchedUsersMap) => {
        if (isCancelled) return;
        for (const [keyId, u] of Object.entries(fetchedUsersMap)) {
          if (!u) continue;
          if (keyId) map[keyId] = u;
          if (u.id) map[u.id] = u;
          if (u.userId) map[u.userId] = u;
          if (u.authUid) map[u.authUid] = u;
          if (u.googleUid) map[u.googleUid] = u;
          if (u.username) map[u.username] = u;
        }
        setUserProfilesMap((prev) => ({ ...prev, ...map }));
      })
      .catch((err) => {
        console.warn('ExpenseAuditHistoryModal: Failed to fetch actor profiles:', err);
      })
      .finally(() => {
        if (!isCancelled) {
          setLoadingProfiles(false);
        }
      });

    return () => {
      isCancelled = true;
    };
  }, [timelineEvents, users, expense]);

  if (!isOpen) return null;

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="expense-audit-history-title"
      className="fixed inset-0 z-50 flex items-center justify-center p-2.5 sm:p-4 bg-black/60 backdrop-blur-xs animate-in fade-in duration-200"
      onClick={(e) => {
        if (e.target === e.currentTarget) {
          onClose();
        }
      }}
    >
      <div className="relative w-full max-w-3xl max-h-[92vh] flex flex-col rounded-2xl shadow-2xl border border-[var(--app-border,#E2E8F0)] bg-[var(--app-surface-modal,#FFFFFF)] text-[var(--app-text-primary,#0F172A)] overflow-hidden transition-all">
        {/* ============================================================ */}
        {/* 1. MODAL HEADER                                              */}
        {/* ============================================================ */}
        <div className="sticky top-0 z-20 flex items-center justify-between p-3.5 sm:p-5 border-b border-[var(--app-border,#E2E8F0)] bg-[var(--app-surface-modal,#FFFFFF)] shrink-0">
          <div className="flex items-center gap-2.5 sm:gap-3 min-w-0">
            <div className="p-2 sm:p-2.5 rounded-xl bg-blue-50 dark:bg-blue-950/40 text-[#2563EB] border border-blue-200 dark:border-blue-800 shrink-0">
              <History className="w-4 h-4 sm:w-5 sm:h-5 text-[#2563EB]" />
            </div>
            <div className="min-w-0">
              <div className="flex items-center gap-2 flex-wrap">
                <h3
                  id="expense-audit-history-title"
                  className="text-sm sm:text-base font-bold text-[var(--app-text-primary,#0F172A)] tracking-tight leading-tight truncate"
                >
                  Expense Approval Audit History
                </h3>
                {expenseReference && (
                  <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded bg-[var(--app-surface-card,#FFFFFF)] border border-[var(--app-border,#E2E8F0)] text-[var(--app-text-secondary,#475569)] shrink-0">
                    {expenseReference}
                  </span>
                )}
              </div>
              <p className="text-[11px] sm:text-xs text-[var(--app-text-secondary,#475569)] truncate mt-0.5 font-medium">
                {expense.title}
              </p>
            </div>
          </div>
          <button
            type="button"
            id="expense-audit-history-close-btn"
            onClick={onClose}
            className="p-1.5 sm:p-2 rounded-lg text-[var(--app-text-secondary,#475569)] hover:text-[var(--app-text-primary,#0F172A)] hover:bg-[var(--app-surface-card,#FFFFFF)] focus:outline-hidden focus:ring-2 focus:ring-[#2563EB] transition cursor-pointer"
            aria-label="Close audit history modal"
          >
            <X className="w-4.5 h-4.5 sm:w-5 sm:h-5" />
          </button>
        </div>

        {/* ============================================================ */}
        {/* 2. EXPENSE SUMMARY CARDS (4 DISTINCT CARDS)                  */}
        {/* ============================================================ */}
        <div className="px-3.5 sm:px-6 py-3 bg-[var(--app-bg-muted,#F1F5F9)]/70 border-b border-[var(--app-border,#E2E8F0)] shrink-0">
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 sm:gap-3">
            {/* Card 1: Amount */}
            <div className="rounded-xl p-2.5 sm:p-3 bg-[var(--app-surface-card,#FFFFFF)] border border-[var(--app-border,#E2E8F0)] shadow-2xs min-w-0 flex flex-col justify-between">
              <div className="flex items-center justify-between gap-1 text-[var(--app-text-muted,#64748B)] mb-1">
                <span className="text-[10px] sm:text-[10.5px] font-semibold uppercase tracking-wider truncate">
                  Amount
                </span>
                <Receipt className="w-3.5 h-3.5 text-[var(--app-text-muted,#64748B)] shrink-0" />
              </div>
              <div>
                <div className="font-mono font-bold text-xs sm:text-sm text-[var(--app-text-primary,#0F172A)] truncate">
                  {formatAFN(expense.amount)}
                </div>
                <div className="text-[10px] text-[var(--app-text-muted,#64748B)] mt-0.5 truncate">
                  {expense.category || 'Direct Expense'}
                </div>
              </div>
            </div>

            {/* Card 2: Current Status */}
            <div className="rounded-xl p-2.5 sm:p-3 bg-[var(--app-surface-card,#FFFFFF)] border border-[var(--app-border,#E2E8F0)] shadow-2xs min-w-0 flex flex-col justify-between">
              <div className="flex items-center justify-between gap-1 text-[var(--app-text-muted,#64748B)] mb-1">
                <span className="text-[10px] sm:text-[10.5px] font-semibold uppercase tracking-wider truncate">
                  Current Status
                </span>
                <Clock className="w-3.5 h-3.5 text-[var(--app-text-muted,#64748B)] shrink-0" />
              </div>
              <div className="mt-0.5">
                <ExpenseStatusBadge expense={expense} />
              </div>
            </div>

            {/* Card 3: Requester */}
            <div className="rounded-xl p-2.5 sm:p-3 bg-[var(--app-surface-card,#FFFFFF)] border border-[var(--app-border,#E2E8F0)] shadow-2xs min-w-0 flex flex-col justify-between">
              <div className="flex items-center justify-between gap-1 text-[var(--app-text-muted,#64748B)] mb-1">
                <span className="text-[10px] sm:text-[10.5px] font-semibold uppercase tracking-wider truncate">
                  Requested By: {formatRoleLabel(expense.requestedByRole, expense.requestedByJobTitle)}
                </span>
                <User className="w-3.5 h-3.5 text-[var(--app-text-muted,#64748B)] shrink-0" />
              </div>
              <div>
                <div
                  className="font-bold text-xs sm:text-sm text-[var(--app-text-primary,#0F172A)] truncate leading-tight"
                  title={expense.requestedByName || 'Authorized Requester'}
                >
                  {expense.requestedByName || 'Authorized Requester'}
                </div>
                <div className="text-[10px] text-[var(--app-text-secondary,#475569)] mt-0.5 truncate">
                  {formatRoleLabel(expense.requestedByRole, expense.requestedByJobTitle)}
                </div>
              </div>
            </div>

            {/* Card 4: Linked Invoice */}
            <div className="rounded-xl p-2.5 sm:p-3 bg-[var(--app-surface-card,#FFFFFF)] border border-[var(--app-border,#E2E8F0)] shadow-2xs min-w-0 flex flex-col justify-between">
              <div className="flex items-center justify-between gap-1 text-[var(--app-text-muted,#64748B)] mb-1">
                <span className="text-[10px] sm:text-[10.5px] font-semibold uppercase tracking-wider truncate">
                  Linked Invoice
                </span>
                <FileText className="w-3.5 h-3.5 text-[var(--app-text-muted,#64748B)] shrink-0" />
              </div>
              <div>
                <div
                  className="font-mono font-bold text-xs sm:text-sm text-[var(--app-text-primary,#0F172A)] truncate"
                  title={
                    expense.billNumber
                      ? `#${expense.billNumber}`
                      : expense.invoiceId
                      ? `#${expense.invoiceId}`
                      : 'Not linked'
                  }
                >
                  {expense.billNumber
                    ? `#${expense.billNumber}`
                    : expense.invoiceId
                    ? `#${expense.invoiceId.length > 10 ? expense.invoiceId.slice(0, 8) : expense.invoiceId}`
                    : 'Not linked'}
                </div>
                <div className="text-[10px] text-[var(--app-text-muted,#64748B)] mt-0.5 truncate">
                  {expense.invoiceId || expense.billNumber ? 'Associated Invoice' : 'Unlinked direct cost'}
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* ============================================================ */}
        {/* 3. UNIFIED APPROVAL PROGRESS & ACTIVITY HISTORY TIMELINE     */}
        {/* ============================================================ */}
        <div className="flex-1 overflow-y-auto px-3.5 sm:px-6 py-4 sm:py-5 space-y-0">
          <div className="flex items-center justify-between pb-2.5 mb-3 border-b border-[var(--app-border-subtle,#F1F5F9)]">
            <div className="flex items-center gap-1.5">
              <CheckCircle2 className="w-3.5 h-3.5 text-[#2563EB]" />
              <h4 className="text-[10.5px] sm:text-xs font-bold text-[var(--app-text-secondary,#475569)] uppercase tracking-wider">
                Approval Progress &amp; Activity History
              </h4>
            </div>
            <span className="text-[10px] sm:text-[11px] text-[var(--app-text-muted,#64748B)] font-medium">
              {completedStagesCount} of {totalStagesCount} stages completed
            </span>
          </div>

          {unifiedTimelineItems.length === 0 ? (
            <div className="p-8 text-center rounded-xl bg-[var(--app-bg-muted,#F1F5F9)] border border-dashed border-[var(--app-border,#E2E8F0)] text-[var(--app-text-muted,#64748B)] text-xs">
              <History className="w-7 h-7 mx-auto text-[var(--app-text-muted,#64748B)] mb-2 opacity-50" />
              <p className="font-semibold text-[var(--app-text-primary,#0F172A)]">
                No recorded workflow transitions yet
              </p>
              <p className="text-[11px] text-[var(--app-text-muted,#64748B)] mt-0.5">
                Workflow transitions and audit events will appear here in sequence.
              </p>
            </div>
          ) : (
            <div className="relative pl-1 sm:pl-2">
              {unifiedTimelineItems.map((item, index) => {
                const isLast = index === unifiedTimelineItems.length - 1;

                if (item.kind === 'recorded') {
                  const entry = item.entry;
                  const semanticStatus = resolveEventStatus(entry);
                  const config = getStatusConfig(semanticStatus);

                  const actorId = (entry.performedBy || '').trim();
                  const actorProfile =
                    userProfilesMap[actorId] ||
                    (users || []).find(
                      (u) =>
                        u.id === actorId ||
                        u.userId === actorId ||
                        u.authUid === actorId ||
                        u.googleUid === actorId ||
                        u.username === actorId
                    );

                  // Resolve real photo URL (live profile prioritized over historical snapshot)
                  const actorPhotoURL = resolveActorPhoto(entry, actorProfile);

                  // Resolve real display name without leaking internal IDs
                  const actorDisplayName = resolveActorName(entry, actorProfile);

                  // Resolve role and job title
                  const roleLabel = formatRoleLabel(
                    actorProfile?.role || entry.performedByRole,
                    actorProfile?.jobTitle || entry.performedByJobTitle
                  );

                  const initials = getActorInitials(actorDisplayName);
                  const avatarKey = `${entry.timestamp}_${actorId}_${index}`;
                  const hasImageFailed = Boolean(failedImages[avatarKey]);

                  const eventDateFormatted = formatDateTime(
                    entry.timestamp,
                    'Date/Time not recorded'
                  );

                  // Determine stage title & action flow description
                  const eventStageTitle = getEventStageTitle(entry, semanticStatus);
                  const actionDescriptionText = getActionDescription(
                    entry,
                    semanticStatus,
                    expense.amount
                  );

                  let MarkerIcon = Check;
                  if (semanticStatus === 'rejected') MarkerIcon = XCircle;
                  else if (semanticStatus === 'resubmitted') MarkerIcon = RotateCcw;
                  else if (semanticStatus === 'pending') MarkerIcon = Clock;

                  return (
                    <div key={item.key} className="relative flex items-start group pb-4 sm:pb-5 last:pb-0">
                      {/* CONTINUOUS VERTICAL CONNECTING LINE */}
                      {!isLast && (
                        <span
                          className="absolute left-[13px] top-3.5 bottom-0 w-0.5 bg-[var(--app-border,#E2E8F0)] z-0"
                          aria-hidden="true"
                        />
                      )}

                      {/* COMPACT CIRCULAR STATUS INDICATOR ALIGNED PRECISELY ALONG THE LINE */}
                      <div
                        className="relative z-10 w-7 h-7 mt-0.5 rounded-full flex items-center justify-center shrink-0 border-[1.5px] shadow-2xs transition-transform duration-150 group-hover:scale-105 bg-[var(--app-surface-card,#FFFFFF)]"
                        style={{
                          borderColor: config.color,
                          backgroundColor: config.bgTint,
                        }}
                        title={`Status: ${config.badgeLabel}`}
                        aria-label={`Status: ${config.badgeLabel}`}
                      >
                        <MarkerIcon
                          className="w-3.5 h-3.5"
                          style={{ color: config.color }}
                        />
                      </div>

                      {/* RESPONSIVE USER ACTION CARD */}
                      <div className="flex-1 ml-3 sm:ml-3.5 rounded-xl border border-[var(--app-border,#E2E8F0)] bg-[var(--app-surface-card,#FFFFFF)] p-3 sm:p-3.5 shadow-2xs hover:shadow-xs transition duration-150 min-w-0">
                        {/* CARD HEADER: EVENT TITLE & SEPARATED STATUS BADGE */}
                        <div className="flex items-center justify-between gap-2 pb-2.5 border-b border-[var(--app-border-subtle,#F1F5F9)]">
                          <div className="flex items-center gap-2 min-w-0">
                            <h5 className="font-bold text-xs sm:text-[13px] text-[var(--app-text-primary,#0F172A)] truncate leading-tight">
                              {eventStageTitle}
                            </h5>
                            {entry.revision && (
                              <span className="text-[10px] font-semibold px-2 py-0.5 rounded bg-[var(--app-bg-muted,#F1F5F9)] text-[var(--app-text-secondary,#475569)] border border-[var(--app-border,#E2E8F0)] shrink-0">
                                Revision {entry.revision}
                              </span>
                            )}
                          </div>

                          {/* SEPARATED STATUS BADGE */}
                          <div className="shrink-0">
                            <span
                              className={`inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[11px] font-bold border ${config.badgeBg} ${config.badgeText} ${config.badgeBorder}`}
                            >
                              <span
                                className="w-1.5 h-1.5 rounded-full shrink-0"
                                style={{ backgroundColor: config.color }}
                              />
                              <span>{config.badgeLabel}</span>
                            </span>
                          </div>
                        </div>

                        {/* RESPONSIVE ACTOR & ACTION FLOW DESCRIPTION */}
                        {/* Mobile & narrow screens: vertical flow (flex-col) */}
                        {/* Large screens: horizontal flow (md:flex-row md:items-center md:justify-between) */}
                        <div className="pt-2.5 flex flex-col md:flex-row md:items-center md:justify-between gap-2 md:gap-4">
                          {/* 1. Actor details */}
                          <div className="flex items-center gap-2 sm:gap-2.5 min-w-0 shrink-0">
                            {/* Profile photo or fallback initials */}
                            <div className="w-7 h-7 sm:w-8 sm:h-8 rounded-full overflow-hidden shrink-0 border border-[var(--app-border,#E2E8F0)] bg-[var(--app-bg-muted,#F1F5F9)] flex items-center justify-center text-[11px] font-bold text-[var(--app-text-primary,#0F172A)] shadow-2xs relative">
                              {actorPhotoURL && !hasImageFailed ? (
                                <img
                                  src={actorPhotoURL}
                                  alt={actorDisplayName}
                                  className="w-full h-full object-cover rounded-full"
                                  referrerPolicy="no-referrer"
                                  onError={() => {
                                    setFailedImages((prev) => ({ ...prev, [avatarKey]: true }));
                                  }}
                                />
                              ) : loadingProfiles && !actorPhotoURL && actorId && !actorId.startsWith('pending_') ? (
                                <div
                                  className="w-full h-full rounded-full bg-neutral-200 dark:bg-neutral-800 animate-pulse flex items-center justify-center"
                                  title="Loading profile photo..."
                                >
                                  <User className="w-3.5 h-3.5 text-neutral-400 opacity-60" />
                                </div>
                              ) : (
                                <span>{initials}</span>
                              )}
                            </div>

                            <div className="min-w-0">
                              {/* Full actor name (ZERO raw user IDs) */}
                              <div
                                className="font-bold text-xs sm:text-[13px] text-[var(--app-text-primary,#0F172A)] truncate leading-tight"
                                title={actorDisplayName}
                              >
                                {actorDisplayName}
                              </div>
                              {/* Job title and role */}
                              <div className="text-[10.5px] sm:text-[11px] text-[var(--app-text-secondary,#475569)] truncate mt-0.5">
                                {roleLabel}
                              </div>
                            </div>
                          </div>

                          {/* 2. Action flow description */}
                          <div className="flex-1 min-w-0 md:px-2">
                            <p className="text-xs text-[var(--app-text-secondary,#475569)] leading-relaxed">
                              {actionDescriptionText}
                            </p>
                          </div>

                          {/* 3. Event timestamp: clean alignment */}
                          <div className="flex items-center gap-1.5 text-[10.5px] sm:text-[11px] font-mono text-[var(--app-text-secondary,#475569)] shrink-0 self-start md:self-center">
                            <Calendar className="w-3.5 h-3.5 text-[var(--app-text-muted,#64748B)] shrink-0" />
                            <span title={`Recorded timestamp: ${eventDateFormatted}`}>
                              {eventDateFormatted}
                            </span>
                          </div>
                        </div>

                        {/* REJECTION EVENT SECTION (COMPLETE VISIBLE REASON, NEVER TRUNCATED) */}
                        {semanticStatus === 'rejected' && (
                          <div className="mt-2.5 p-2.5 sm:p-3 rounded-lg bg-rose-50 dark:bg-rose-950/30 border border-rose-200 dark:border-rose-900/50 text-rose-950 dark:text-rose-100 space-y-1">
                            <div className="flex items-center gap-1.5 text-xs font-bold text-rose-700 dark:text-rose-400">
                              <XCircle className="w-3.5 h-3.5 text-[#DC2626] shrink-0" />
                              <span>Rejection Reason:</span>
                            </div>
                            <p className="text-xs font-normal whitespace-pre-wrap break-words leading-relaxed text-rose-900 dark:text-rose-200 pl-5">
                              {entry.rejectionReason && entry.rejectionReason.trim()
                                ? entry.rejectionReason.trim()
                                : 'Rejection reason was not recorded.'}
                            </p>
                          </div>
                        )}

                        {/* RESUBMISSION CORRECTION SECTION (EXACT CORRECTION DESCRIPTION VISIBLE) */}
                        {semanticStatus === 'resubmitted' && (
                          <div className="mt-2.5 p-2.5 sm:p-3 rounded-lg bg-blue-50 dark:bg-blue-950/30 border border-blue-200 dark:border-blue-900/50 text-blue-950 dark:text-blue-100 space-y-1">
                            <div className="flex items-center justify-between gap-1.5 text-xs font-bold text-blue-700 dark:text-blue-400">
                              <div className="flex items-center gap-1.5">
                                <FileEdit className="w-3.5 h-3.5 text-[#2563EB] shrink-0" />
                                <span>Correction Description &amp; Revision Notes:</span>
                              </div>
                              {entry.revision && (
                                <span className="text-[10px] px-1.5 py-0.5 rounded bg-blue-100 dark:bg-blue-900/60 text-blue-800 dark:text-blue-200 font-semibold border border-blue-200 dark:border-blue-800">
                                  Rev {entry.revision}
                                </span>
                              )}
                            </div>
                            <p className="text-xs font-normal whitespace-pre-wrap break-words leading-relaxed text-blue-900 dark:text-blue-200 pl-5">
                              {entry.correctionDescription ||
                                entry.corrections ||
                                (entry.note && entry.note.trim()) ||
                                'Corrections were updated and resubmitted.'}
                            </p>
                          </div>
                        )}

                        {/* GENERAL NOTE IF PRESENT AND NOT ALREADY DISPLAYED */}
                        {entry.note &&
                          entry.note !== entry.rejectionReason &&
                          entry.note !== entry.corrections &&
                          entry.note !== entry.correctionDescription && (
                            <div className="mt-2 text-xs text-[var(--app-text-muted,#64748B)] italic bg-[var(--app-bg-muted,#F1F5F9)] rounded p-2 border border-[var(--app-border-subtle,#F1F5F9)]">
                              <span className="font-medium not-italic text-[var(--app-text-secondary,#475569)]">
                                Note:{' '}
                              </span>
                              <span className="break-words">{entry.note}</span>
                            </div>
                          )}
                      </div>
                    </div>
                  );
                }

                // PENDING / UPCOMING WORKFLOW STAGE
                const stage = item.stage;
                const isCurrent = stage.status === 'current';

                return (
                  <div key={item.key} className="relative flex items-start group pb-4 sm:pb-5 last:pb-0">
                    {/* CONTINUOUS VERTICAL CONNECTING LINE */}
                    {!isLast && (
                      <span
                        className="absolute left-[13px] top-3.5 bottom-0 w-0.5 bg-[var(--app-border,#E2E8F0)] z-0"
                        aria-hidden="true"
                      />
                    )}

                    {/* COMPACT CIRCULAR STATUS INDICATOR */}
                    <div
                      className={`relative z-10 w-7 h-7 mt-0.5 rounded-full flex items-center justify-center shrink-0 border-[1.5px] shadow-2xs transition-transform duration-150 group-hover:scale-105 ${
                        isCurrent
                          ? 'bg-blue-50 dark:bg-blue-950/40 border-[#2563EB] ring-2 ring-blue-500/20 text-[#2563EB]'
                          : 'bg-[var(--app-surface-card,#FFFFFF)] border-neutral-300 dark:border-neutral-700 text-neutral-400 dark:text-neutral-500'
                      }`}
                      title={`Stage: ${stage.stageName} (${stage.statusBadgeLabel})`}
                      aria-label={`Stage: ${stage.stageName} (${stage.statusBadgeLabel})`}
                    >
                      {isCurrent ? (
                        <Clock className="w-3.5 h-3.5 text-[#2563EB]" />
                      ) : (
                        <Circle className="w-3.5 h-3.5 text-neutral-400 dark:text-neutral-500" />
                      )}
                    </div>

                    {/* UPCOMING / PENDING STAGE CARD */}
                    <div
                      className={`flex-1 ml-3 sm:ml-3.5 rounded-xl border p-3 sm:p-3.5 shadow-2xs transition duration-150 min-w-0 ${
                        isCurrent
                          ? 'border-blue-200 dark:border-blue-900/50 bg-blue-50/20 dark:bg-blue-950/20'
                          : 'border-dashed border-[var(--app-border,#E2E8F0)] bg-[var(--app-surface-card,#FFFFFF)]/70 opacity-90'
                      }`}
                    >
                      {/* CARD HEADER: STAGE TITLE & SEPARATED STATUS BADGE */}
                      <div className="flex items-center justify-between gap-2 pb-2.5 border-b border-[var(--app-border-subtle,#F1F5F9)]">
                        <div className="flex items-center gap-2 min-w-0">
                          <h5 className="font-bold text-xs sm:text-[13px] text-[var(--app-text-primary,#0F172A)] truncate leading-tight">
                            {stage.stageName}
                          </h5>
                        </div>

                        {/* SEPARATED STATUS BADGE */}
                        <div className="shrink-0">
                          <span
                            className={`inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[10.5px] font-bold border shrink-0 ${
                              isCurrent
                                ? 'bg-blue-50 dark:bg-blue-950/40 text-blue-700 dark:text-blue-300 border-blue-200 dark:border-blue-800'
                                : 'bg-neutral-100 dark:bg-neutral-800 text-neutral-600 dark:text-neutral-400 border-neutral-200 dark:border-neutral-700'
                            }`}
                          >
                            <span
                              className={`w-1.5 h-1.5 rounded-full shrink-0 ${
                                isCurrent ? 'bg-[#2563EB]' : 'bg-neutral-400'
                              }`}
                            />
                            <span>{stage.statusBadgeLabel}</span>
                          </span>
                        </div>
                      </div>

                      {/* RESPONSIVE ACTOR ROLE & ACTION FLOW DESCRIPTION */}
                      {/* Mobile & narrow screens: vertical flow (flex-col) */}
                      {/* Large screens: horizontal flow (md:flex-row md:items-center md:justify-between) */}
                      <div className="pt-2.5 flex flex-col md:flex-row md:items-center md:justify-between gap-2 md:gap-4">
                        {/* Role Hint */}
                        <div className="flex items-center gap-2 min-w-0 shrink-0">
                          <div className="w-7 h-7 sm:w-8 sm:h-8 rounded-full border border-[var(--app-border,#E2E8F0)] bg-[var(--app-bg-muted,#F1F5F9)] flex items-center justify-center shrink-0 text-[var(--app-text-muted,#64748B)]">
                            {isCurrent ? (
                              <Clock className="w-3.5 h-3.5 text-[#2563EB]" />
                            ) : (
                              <Circle className="w-3.5 h-3.5 text-neutral-400 dark:text-neutral-500" />
                            )}
                          </div>
                          <div className="min-w-0">
                            <div className="text-[11px] font-semibold text-[var(--app-text-primary,#0F172A)] truncate">
                              Role: {stage.roleHint}
                            </div>
                            <div className="text-[10px] text-[var(--app-text-muted,#64748B)] truncate">
                              {isCurrent ? 'Action required next' : 'Awaiting previous approval'}
                            </div>
                          </div>
                        </div>

                        {/* Action description */}
                        <div className="flex-1 min-w-0 md:px-2">
                          <p className="text-xs text-[var(--app-text-secondary,#475569)] leading-relaxed">
                            {stage.description}
                          </p>
                        </div>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        {/* ============================================================ */}
        {/* 4. MODAL FOOTER                                              */}
        {/* ============================================================ */}
        <div className="flex items-center justify-between p-3.5 sm:p-4 border-t border-[var(--app-border,#E2E8F0)] bg-[var(--app-bg-muted,#F1F5F9)] shrink-0">
          <div className="text-[11px] text-[var(--app-text-muted,#64748B)] truncate max-w-[220px] sm:max-w-none">
            Sarwan Technology &bull; Immutable Audit Trail
          </div>
          <button
            type="button"
            id="expense-audit-history-footer-close-btn"
            onClick={onClose}
            className="px-4 py-2 text-xs font-bold rounded-lg bg-[var(--brand-black,#111827)] hover:bg-black dark:bg-[var(--brand-white,#FFFFFF)] dark:text-[var(--brand-black,#111827)] text-white transition cursor-pointer shadow-xs focus:outline-hidden focus:ring-2 focus:ring-[#2563EB]"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
