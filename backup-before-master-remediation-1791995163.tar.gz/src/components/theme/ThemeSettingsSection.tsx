import React from 'react';
import {
  Shield,
  Sparkles,
  Sun,
  Moon,
  RotateCcw,
  Undo2,
  Check,
} from 'lucide-react';
import { useTheme } from '../../context/ThemeContext';
import { useAuth } from '../../context/AuthContext';
import { ThemeId } from '../../themes/types';
import { toast } from '../../context/ToastContext';

export const ThemeSettingsSection: React.FC = () => {
  const {
    mode,
    themeId,
    setTheme,
    globalDefaultTheme,
    setGlobalDefaultTheme,
    themeSource,
    hasPersonalPreference,
    clearPersonalPreference,
    resetToBrandTheme,
  } = useTheme();

  const { isSuperAdmin } = useAuth();

  const isLightActive = mode === 'light' || themeId === 'sarwan_light' || (themeId as string) === 'sarwan_classic_light';
  const isDarkActive = mode === 'dark' || themeId === 'sarwan_dark';

  const isOrgDefaultLight = globalDefaultTheme === 'sarwan_light' || (globalDefaultTheme as string) === 'sarwan_classic_light';
  const isOrgDefaultDark = globalDefaultTheme === 'sarwan_dark';

  const handleToggleMode = async (targetId: ThemeId) => {
    try {
      await setTheme(targetId);
      const name = targetId === 'sarwan_dark' ? 'Dark Mode' : 'Light Mode';
      toast.success(`Appearance updated to ${name}`);
    } catch (err) {
      console.error('[ThemeSettings] Failed to update theme:', err);
      toast.error('Failed to change theme mode');
    }
  };

  const handleSetOrgDefault = async (targetId: ThemeId) => {
    if (!isSuperAdmin) return;
    try {
      await setGlobalDefaultTheme(targetId);
      const name = targetId === 'sarwan_dark' ? 'Dark Mode' : 'Light Mode';
      toast.success(`Organization default set to ${name}`);
    } catch (err) {
      console.error('[ThemeSettings] Failed to set org default:', err);
    }
  };

  return (
    <div className="w-full max-w-3xl space-y-3.5 sm:space-y-5">
      {/* 1. Primary Appearance Setting Card */}
      <div className="w-full bg-[var(--app-surface-card,#FFFFFF)] border border-[var(--app-border,#E2E8F0)] rounded-xl sm:rounded-2xl p-3.5 sm:p-5 shadow-xs transition-colors">
        {/* Main Setting Row: Info + Compact Toggle Switch */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3.5 sm:gap-4">
          {/* Left: Icon & Description */}
          <div className="flex items-start gap-2.5 sm:gap-3 min-w-0">
            <div className="w-9 h-9 sm:w-10 sm:h-10 rounded-xl bg-[var(--brand-orange,#F7941D)]/10 text-[var(--brand-orange,#F7941D)] flex items-center justify-center shrink-0 mt-0.5 sm:mt-0">
              <Sparkles className="w-4 h-4 sm:w-5 sm:h-5" />
            </div>
            <div className="min-w-0 flex-1">
              <div className="flex items-center gap-1.5 sm:gap-2 flex-wrap">
                <h3 className="text-xs sm:text-sm font-bold text-[var(--app-text-primary,#0F172A)] truncate">
                  Theme Appearance
                </h3>
                {themeSource === 'personal' && (
                  <span className="text-[10px] font-semibold px-2 py-0.5 rounded-full bg-purple-100 text-purple-700 dark:bg-purple-950/70 dark:text-purple-300 whitespace-nowrap">
                    Personal Preference
                  </span>
                )}
                {themeSource === 'global_default' && (
                  <span className="text-[10px] font-semibold px-2 py-0.5 rounded-full bg-blue-100 text-blue-700 dark:bg-blue-950/70 dark:text-blue-300 whitespace-nowrap">
                    Organization Default
                  </span>
                )}
              </div>
              <p className="text-[11px] sm:text-xs text-[var(--app-text-secondary,#475569)] mt-0.5 leading-relaxed">
                {isDarkActive
                  ? 'Sarwan Dark Mode — layered charcoal canvas with high-readability text.'
                  : 'Sarwan Light Mode — crisp white surfaces with corporate blue accents.'}
              </p>
            </div>
          </div>

          {/* Right: Compact Accessible Toggle Switch */}
          <div className="shrink-0 w-full sm:w-auto">
            <div
              role="radiogroup"
              aria-label="Theme Mode Selection"
              className="inline-flex w-full sm:w-auto items-center p-1 bg-[var(--app-bg-muted,#F1F5F9)] rounded-xl border border-[var(--app-border-subtle,#E2E8F0)]"
            >
              {/* Light Mode Button */}
              <button
                type="button"
                role="radio"
                aria-checked={isLightActive}
                tabIndex={isLightActive ? 0 : -1}
                aria-label="Switch to Light Mode"
                onClick={() => handleToggleMode('sarwan_light')}
                onKeyDown={(e) => {
                  if (e.key === 'ArrowRight' || e.key === 'ArrowDown') {
                    e.preventDefault();
                    handleToggleMode('sarwan_dark');
                  }
                }}
                className={`flex-1 sm:flex-initial min-h-[40px] px-3 sm:px-4 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center justify-center gap-1.5 cursor-pointer select-none outline-none focus-visible:ring-2 focus-visible:ring-[var(--color-primary,#2563EB)] whitespace-nowrap active:scale-[0.98] ${
                  isLightActive
                    ? 'bg-[var(--app-surface-card,#FFFFFF)] text-[var(--app-text-primary,#0F172A)] shadow-xs border border-[var(--app-border,#CBD5E1)]'
                    : 'text-[var(--app-text-secondary,#475569)] hover:text-[var(--app-text-primary,#0F172A)] hover:bg-[var(--color-interactive-hover,#E2E8F0)]/50'
                }`}
              >
                <Sun className={`w-4 h-4 ${isLightActive ? 'text-amber-500 fill-amber-500/20' : 'text-neutral-400'}`} />
                <span>Light</span>
              </button>

              {/* Dark Mode Button */}
              <button
                type="button"
                role="radio"
                aria-checked={isDarkActive}
                tabIndex={isDarkActive ? 0 : -1}
                aria-label="Switch to Dark Mode"
                onClick={() => handleToggleMode('sarwan_dark')}
                onKeyDown={(e) => {
                  if (e.key === 'ArrowLeft' || e.key === 'ArrowUp') {
                    e.preventDefault();
                    handleToggleMode('sarwan_light');
                  }
                }}
                className={`flex-1 sm:flex-initial min-h-[40px] px-3 sm:px-4 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center justify-center gap-1.5 cursor-pointer select-none outline-none focus-visible:ring-2 focus-visible:ring-[var(--color-primary,#2563EB)] whitespace-nowrap active:scale-[0.98] ${
                  isDarkActive
                    ? 'bg-[var(--app-surface-card,#FFFFFF)] text-[var(--app-text-primary,#0F172A)] shadow-xs border border-[var(--app-border,#CBD5E1)]'
                    : 'text-[var(--app-text-secondary,#475569)] hover:text-[var(--app-text-primary,#0F172A)] hover:bg-[var(--color-interactive-hover,#E2E8F0)]/50'
                }`}
              >
                <Moon className={`w-4 h-4 ${isDarkActive ? 'text-blue-400 fill-blue-400/20' : 'text-neutral-400'}`} />
                <span>Dark</span>
              </button>
            </div>
          </div>
        </div>

        {/* Sub-row: Actions & Preference Reset */}
        <div className="mt-3.5 pt-3 border-t border-[var(--app-border-subtle,#F1F5F9)] flex flex-col xs:flex-row xs:items-center justify-between gap-2.5 text-xs">
          <div className="flex items-center gap-1.5 text-[var(--app-text-secondary,#475569)] min-w-0">
            <span className="inline-block w-2 h-2 rounded-full bg-[var(--brand-orange,#F7941D)] shrink-0" />
            <span className="font-medium text-[11px] sm:text-xs truncate">
              {hasPersonalPreference
                ? 'Custom personal preference active'
                : 'Using organization default appearance'}
            </span>
          </div>

          <div className="flex items-center gap-2 flex-wrap shrink-0">
            {hasPersonalPreference && (
              <button
                type="button"
                onClick={async () => {
                  await clearPersonalPreference();
                  toast.success('Reverted to Organization Default');
                }}
                className="px-2.5 py-1.5 text-xs font-semibold text-[var(--color-primary,#2563EB)] bg-[var(--color-primary,#2563EB)]/10 hover:bg-[var(--color-primary,#2563EB)]/20 rounded-lg transition inline-flex items-center gap-1.5 cursor-pointer active:scale-98"
                title="Clear personal preference and follow the Organization Default mode"
              >
                <Undo2 className="w-3.5 h-3.5 shrink-0" />
                <span>Follow Org Default</span>
              </button>
            )}

            <button
              type="button"
              onClick={async () => {
                await resetToBrandTheme();
                toast.success('Reset to Sarwan Light Mode');
              }}
              className="px-2.5 py-1.5 text-xs font-semibold text-[var(--app-text-secondary,#475569)] hover:text-[var(--app-text-primary,#0F172A)] bg-[var(--app-bg-muted,#F1F5F9)] hover:bg-[var(--color-interactive-active,#E2E8F0)] rounded-lg transition inline-flex items-center gap-1.5 cursor-pointer active:scale-98"
              title="Reset theme to Sarwan Light Mode"
            >
              <RotateCcw className="w-3.5 h-3.5 shrink-0" />
              <span>Reset to Default</span>
            </button>
          </div>
        </div>
      </div>

      {/* 2. Super Admin Organization Default Row */}
      {isSuperAdmin && (
        <div className="w-full bg-[var(--app-surface-card,#FFFFFF)] border border-[var(--app-border,#E2E8F0)] rounded-xl sm:rounded-2xl p-3.5 sm:p-5 shadow-xs transition-colors">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3.5 sm:gap-4">
            <div className="flex items-start gap-2.5 sm:gap-3 min-w-0">
              <div className="w-9 h-9 sm:w-10 sm:h-10 rounded-xl bg-blue-500/10 text-blue-600 dark:text-blue-400 flex items-center justify-center shrink-0 mt-0.5 sm:mt-0">
                <Shield className="w-4 h-4 sm:w-5 sm:h-5" />
              </div>
              <div className="min-w-0 flex-1">
                <div className="flex items-center gap-1.5 sm:gap-2 flex-wrap">
                  <h4 className="text-xs sm:text-sm font-bold text-[var(--app-text-primary,#0F172A)]">
                    Organization Default Mode
                  </h4>
                  <span className="text-[10px] font-semibold px-2 py-0.5 rounded-full bg-blue-500/10 text-blue-600 dark:text-blue-400 whitespace-nowrap">
                    Super Admin
                  </span>
                </div>
                <p className="text-[11px] sm:text-xs text-[var(--app-text-secondary,#475569)] mt-0.5 leading-relaxed">
                  Default mode for new users and accounts without an explicit personal preference.
                </p>
              </div>
            </div>

            {/* Org Default Toggle Controls */}
            <div className="shrink-0 w-full sm:w-auto">
              <div
                role="radiogroup"
                aria-label="Organization Default Mode Selection"
                className="inline-flex w-full sm:w-auto items-center p-1 bg-[var(--app-bg-muted,#F1F5F9)] rounded-xl border border-[var(--app-border-subtle,#E2E8F0)]"
              >
                <button
                  type="button"
                  role="radio"
                  aria-checked={isOrgDefaultLight}
                  tabIndex={isOrgDefaultLight ? 0 : -1}
                  onClick={() => handleSetOrgDefault('sarwan_light')}
                  className={`flex-1 sm:flex-initial min-h-[40px] px-2.5 sm:px-3.5 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center justify-center gap-1.5 cursor-pointer outline-none focus-visible:ring-2 focus-visible:ring-[var(--color-primary,#2563EB)] whitespace-nowrap active:scale-[0.98] ${
                    isOrgDefaultLight
                      ? 'bg-[var(--app-surface-card,#FFFFFF)] text-[var(--app-text-primary,#0F172A)] shadow-xs border border-[var(--app-border,#CBD5E1)]'
                      : 'text-[var(--app-text-secondary,#475569)] hover:text-[var(--app-text-primary,#0F172A)] hover:bg-[var(--color-interactive-hover,#E2E8F0)]/50'
                  }`}
                >
                  <Sun className={`w-3.5 h-3.5 ${isOrgDefaultLight ? 'text-amber-500' : 'text-neutral-400'}`} />
                  <span>Org Light</span>
                  {isOrgDefaultLight && <Check className="w-3 h-3 text-blue-600 dark:text-blue-400 ml-0.5" />}
                </button>

                <button
                  type="button"
                  role="radio"
                  aria-checked={isOrgDefaultDark}
                  tabIndex={isOrgDefaultDark ? 0 : -1}
                  onClick={() => handleSetOrgDefault('sarwan_dark')}
                  className={`flex-1 sm:flex-initial min-h-[40px] px-2.5 sm:px-3.5 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center justify-center gap-1.5 cursor-pointer outline-none focus-visible:ring-2 focus-visible:ring-[var(--color-primary,#2563EB)] whitespace-nowrap active:scale-[0.98] ${
                    isOrgDefaultDark
                      ? 'bg-[var(--app-surface-card,#FFFFFF)] text-[var(--app-text-primary,#0F172A)] shadow-xs border border-[var(--app-border,#CBD5E1)]'
                      : 'text-[var(--app-text-secondary,#475569)] hover:text-[var(--app-text-primary,#0F172A)] hover:bg-[var(--color-interactive-hover,#E2E8F0)]/50'
                  }`}
                >
                  <Moon className={`w-3.5 h-3.5 ${isOrgDefaultDark ? 'text-blue-400' : 'text-neutral-400'}`} />
                  <span>Org Dark</span>
                  {isOrgDefaultDark && <Check className="w-3 h-3 text-blue-600 dark:text-blue-400 ml-0.5" />}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
