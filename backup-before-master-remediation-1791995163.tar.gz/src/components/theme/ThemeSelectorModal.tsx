import React, { useState, useEffect, useRef } from 'react';
import {
  Sun,
  Moon,
  Check,
  X,
  Shield,
  Sparkles,
  Undo2,
} from 'lucide-react';
import { useTheme } from '../../context/ThemeContext';
import { useAuth } from '../../context/AuthContext';
import { ThemeId } from '../../themes/types';
import { toast } from '../../context/ToastContext';

export const ThemeSelectorModal: React.FC = () => {
  const {
    themeId,
    setTheme,
    globalDefaultTheme,
    setGlobalDefaultTheme,
    themeSource,
    hasPersonalPreference,
    clearPersonalPreference,
    isThemeSelectorOpen,
    closeThemeSelector,
    previewTheme,
    previewThemeId,
  } = useTheme();

  const { isSuperAdmin } = useAuth();

  const [selectedCandidateId, setSelectedCandidateId] = useState<ThemeId>(themeId);
  const [isSaving, setIsSaving] = useState(false);
  const [alsoUpdateOrgDefault, setAlsoUpdateOrgDefault] = useState(false);

  const triggerElementRef = useRef<HTMLElement | null>(null);

  // Initialize candidate to current active theme whenever modal opens
  useEffect(() => {
    if (isThemeSelectorOpen) {
      triggerElementRef.current = document.activeElement as HTMLElement;
      setSelectedCandidateId(themeId);
      setAlsoUpdateOrgDefault(false);
    } else {
      if (triggerElementRef.current && typeof triggerElementRef.current.focus === 'function') {
        triggerElementRef.current.focus();
      }
    }
  }, [isThemeSelectorOpen, themeId]);

  // Handle keyboard events (Escape to cancel and close)
  useEffect(() => {
    if (!isThemeSelectorOpen) return;

    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        e.preventDefault();
        handleCancel();
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isThemeSelectorOpen]);

  if (!isThemeSelectorOpen) return null;

  // Preview mode temporarily on click
  const handleSelectMode = (id: ThemeId) => {
    setSelectedCandidateId(id);
    previewTheme(id);
  };

  // Discard preview and close modal
  const handleCancel = () => {
    previewTheme(null);
    closeThemeSelector();
  };

  // Persist selected theme mode
  const handleSaveTheme = async () => {
    setIsSaving(true);
    try {
      await setTheme(selectedCandidateId);
      if (isSuperAdmin && alsoUpdateOrgDefault) {
        await setGlobalDefaultTheme(selectedCandidateId);
      }
      const modeName = selectedCandidateId === 'sarwan_dark' ? 'Dark Mode' : 'Light Mode';
      toast.success(`Theme updated to ${modeName}`);
      closeThemeSelector();
    } catch (err) {
      console.error('[ThemeSelector] Failed to persist theme:', err);
      toast.error('Failed to save theme mode');
    } finally {
      setIsSaving(false);
    }
  };

  const isLightCandidate = selectedCandidateId === 'sarwan_light' || (selectedCandidateId as string) === 'sarwan_classic_light';
  const isDarkCandidate = selectedCandidateId === 'sarwan_dark';

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/60 backdrop-blur-xs animate-in fade-in duration-200"
      onClick={handleCancel}
      role="dialog"
      aria-modal="true"
      aria-labelledby="theme-modal-title"
    >
      <div
        className="w-full max-w-md flex flex-col bg-[var(--app-surface-modal,#FFFFFF)] text-[var(--app-text-primary,#0F172A)] rounded-2xl shadow-2xl border border-[var(--app-border,#E2E8F0)] overflow-hidden animate-in zoom-in-95 duration-150 transition-colors"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Modal Header */}
        <div className="flex items-center justify-between px-4 sm:px-5 py-4 border-b border-[var(--app-border-subtle,#F1F5F9)]">
          <div className="flex items-center gap-2.5 min-w-0">
            <div className="w-9 h-9 rounded-xl bg-[var(--brand-orange,#F7941D)]/10 text-[var(--brand-orange,#F7941D)] flex items-center justify-center shrink-0">
              <Sparkles className="w-4 h-4" />
            </div>
            <div className="min-w-0">
              <h3 id="theme-modal-title" className="text-sm font-bold truncate">
                Theme Appearance
              </h3>
              <p className="text-[11px] text-[var(--app-text-secondary,#475569)] truncate">
                Select your display mode preference
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={handleCancel}
            className="p-1.5 text-[var(--app-text-muted,#64748B)] hover:text-[var(--app-text-primary,#0F172A)] hover:bg-[var(--color-interactive-hover,#F1F5F9)] rounded-lg transition cursor-pointer"
            aria-label="Close modal"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Modal Body: Compact Toggle & Preview Summary */}
        <div className="p-4 sm:p-5 space-y-4">
          {/* Compact Accessible Toggle Switch */}
          <div>
            <label className="text-xs font-semibold text-[var(--app-text-secondary,#475569)] block mb-2">
              Display Mode
            </label>
            <div
              role="radiogroup"
              aria-label="Theme mode switcher"
              className="grid grid-cols-2 p-1 bg-[var(--app-bg-muted,#F1F5F9)] rounded-xl border border-[var(--app-border-subtle,#E2E8F0)]"
            >
              {/* Light Option */}
              <button
                type="button"
                role="radio"
                aria-checked={isLightCandidate}
                tabIndex={isLightCandidate ? 0 : -1}
                onClick={() => handleSelectMode('sarwan_light')}
                onKeyDown={(e) => {
                  if (e.key === 'ArrowRight' || e.key === 'ArrowDown') {
                    e.preventDefault();
                    handleSelectMode('sarwan_dark');
                  }
                }}
                className={`min-h-[42px] py-2 px-2.5 sm:px-3 text-xs font-bold rounded-lg transition-all flex items-center justify-center gap-1.5 sm:gap-2 cursor-pointer outline-none focus-visible:ring-2 focus-visible:ring-[var(--color-primary,#2563EB)] whitespace-nowrap active:scale-[0.98] ${
                  isLightCandidate
                    ? 'bg-[var(--app-surface-card,#FFFFFF)] text-[var(--app-text-primary,#0F172A)] shadow-xs border border-[var(--app-border,#CBD5E1)]'
                    : 'text-[var(--app-text-secondary,#475569)] hover:text-[var(--app-text-primary,#0F172A)]'
                }`}
              >
                <Sun className={`w-4 h-4 shrink-0 ${isLightCandidate ? 'text-amber-500 fill-amber-500/20' : 'text-neutral-400'}`} />
                <span>Light Mode</span>
                {isLightCandidate && <Check className="w-3.5 h-3.5 text-blue-600 dark:text-blue-400 ml-0.5 shrink-0" />}
              </button>

              {/* Dark Option */}
              <button
                type="button"
                role="radio"
                aria-checked={isDarkCandidate}
                tabIndex={isDarkCandidate ? 0 : -1}
                onClick={() => handleSelectMode('sarwan_dark')}
                onKeyDown={(e) => {
                  if (e.key === 'ArrowLeft' || e.key === 'ArrowUp') {
                    e.preventDefault();
                    handleSelectMode('sarwan_light');
                  }
                }}
                className={`min-h-[42px] py-2 px-2.5 sm:px-3 text-xs font-bold rounded-lg transition-all flex items-center justify-center gap-1.5 sm:gap-2 cursor-pointer outline-none focus-visible:ring-2 focus-visible:ring-[var(--color-primary,#2563EB)] whitespace-nowrap active:scale-[0.98] ${
                  isDarkCandidate
                    ? 'bg-[var(--app-surface-card,#FFFFFF)] text-[var(--app-text-primary,#0F172A)] shadow-xs border border-[var(--app-border,#CBD5E1)]'
                    : 'text-[var(--app-text-secondary,#475569)] hover:text-[var(--app-text-primary,#0F172A)]'
                }`}
              >
                <Moon className={`w-4 h-4 shrink-0 ${isDarkCandidate ? 'text-blue-400 fill-blue-400/20' : 'text-neutral-400'}`} />
                <span>Dark Mode</span>
                {isDarkCandidate && <Check className="w-3.5 h-3.5 text-blue-600 dark:text-blue-400 ml-0.5 shrink-0" />}
              </button>
            </div>
          </div>

          {/* Mode Summary Banner */}
          <div className="p-3 rounded-xl bg-[var(--app-bg-muted,#F1F5F9)] border border-[var(--app-border-subtle,#E2E8F0)] text-xs space-y-1">
            <div className="flex items-center justify-between">
              <span className="font-bold text-[var(--app-text-primary,#0F172A)]">
                {isDarkCandidate ? 'Sarwan Dark Mode' : 'Sarwan Light Mode'}
              </span>
              <span className="text-[10px] font-semibold text-[var(--brand-orange,#F7941D)]">
                Live Preview
              </span>
            </div>
            <p className="text-[11px] text-[var(--app-text-secondary,#475569)] leading-relaxed">
              {isDarkCandidate
                ? 'High-contrast dark appearance with deep charcoal cards and signature orange highlights.'
                : 'High-contrast light appearance with clean white surfaces and signature blue accents.'}
            </p>
          </div>

          {/* Super Admin Option: Update Org Default */}
          {isSuperAdmin && (
            <label className="flex items-start gap-2.5 p-2.5 rounded-lg border border-[var(--app-border-subtle,#E2E8F0)] hover:bg-[var(--color-interactive-hover,#F1F5F9)] transition cursor-pointer select-none">
              <input
                type="checkbox"
                checked={alsoUpdateOrgDefault}
                onChange={(e) => setAlsoUpdateOrgDefault(e.target.checked)}
                className="mt-0.5 rounded border-[var(--app-border,#CBD5E1)] text-[var(--color-primary,#2563EB)] focus:ring-[var(--color-primary,#2563EB)]"
              />
              <div className="text-xs">
                <span className="font-semibold text-[var(--app-text-primary,#0F172A)] flex items-center gap-1">
                  <Shield className="w-3 h-3 text-blue-600 dark:text-blue-400" />
                  Also set as Organization Default
                </span>
                <p className="text-[11px] text-[var(--app-text-secondary,#475569)] mt-0.5">
                  Applies to all members who have not chosen a personal preference.
                </p>
              </div>
            </label>
          )}

          {/* Revert Personal Preference */}
          {hasPersonalPreference && (
            <div className="flex items-center justify-between text-xs pt-1">
              <span className="text-[11px] text-[var(--app-text-muted,#64748B)]">
                Following custom preference
              </span>
              <button
                type="button"
                onClick={async () => {
                  previewTheme(null);
                  await clearPersonalPreference();
                  toast.success('Reverted to Organization Default');
                  closeThemeSelector();
                }}
                className="text-[11px] font-semibold text-[var(--color-primary,#2563EB)] hover:underline inline-flex items-center gap-1 cursor-pointer"
              >
                <Undo2 className="w-3 h-3" />
                Follow Org Default
              </button>
            </div>
          )}
        </div>

        {/* Modal Footer */}
        <div className="flex items-center justify-end gap-2 px-4 sm:px-5 py-3 border-t border-[var(--app-border-subtle,#F1F5F9)] bg-[var(--app-bg-muted,#F1F5F9)]/50">
          <button
            type="button"
            onClick={handleCancel}
            className="px-3.5 py-2 text-xs font-semibold text-[var(--app-text-secondary,#475569)] hover:text-[var(--app-text-primary,#0F172A)] rounded-lg hover:bg-[var(--color-interactive-hover,#F1F5F9)] transition cursor-pointer min-h-[36px]"
          >
            Cancel
          </button>
          <button
            type="button"
            onClick={handleSaveTheme}
            disabled={isSaving}
            className="px-4 py-2 text-xs font-bold text-white bg-[var(--color-primary,#2563EB)] hover:bg-[var(--color-primary-hover,#1D4ED8)] active:bg-[var(--color-primary-active,#1E40AF)] rounded-lg shadow-xs transition flex items-center gap-1.5 cursor-pointer disabled:opacity-50 min-h-[36px]"
          >
            <Check className="w-3.5 h-3.5" />
            <span>{isSaving ? 'Saving...' : 'Save Preference'}</span>
          </button>
        </div>
      </div>
    </div>
  );
};
