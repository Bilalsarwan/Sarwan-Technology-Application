import React, { useState, useMemo, useEffect, useRef } from 'react';
import { Customer, CustomerStatus, CustomerType, Invoice, Payment, UserProfile, AuditLog } from '../../types';
import {
  calculateCustomerSummary,
  formatAFN,
  formatDate,
} from '../../utils/format';
import {
  setCustomerStatus,
  deleteCustomerSafely,
  linkCustomerToUserAccount,
  unlinkCustomerUserAccount,
} from '../../services/db';
import { createApplicationUser } from '../../services/security';
import { useAuth } from '../../context/AuthContext';
import { normalizeCustomerStatus } from '../../utils/customerValidation';
import { toast } from '../../context/ToastContext';
import {
  X,
  User,
  Phone,
  Building,
  MapPin,
  Mail,
  FileText,
  DollarSign,
  Archive,
  RotateCcw,
  Clock,
  ChevronRight,
  AlertCircle,
  ShieldCheck,
  Key,
  Trash2,
  Copy,
  Check,
  ExternalLink,
  MessageCircle,
  History,
  Lock,
  Eye,
  Plus,
  AlertTriangle,
  PauseCircle,
  CheckCircle2,
  ShieldAlert,
  Calendar,
  CreditCard,
  Receipt,
  MoreVertical,
  Edit2,
  Settings,
} from 'lucide-react';

interface CustomerDetailModalProps {
  customer: Customer | null;
  invoices: Invoice[];
  payments: Payment[];
  users?: UserProfile[];
  auditLogs?: AuditLog[];
  isOpen: boolean;
  onClose: () => void;
  onSelectInvoice?: (invoice: Invoice) => void;
  onEditCustomer?: (customer: Customer) => void;
  onNewInvoice?: (customer: Customer) => void;
  onAddPayment?: (customer: Customer) => void;
  onRefresh?: () => void;
}

export const CustomerDetailModal: React.FC<CustomerDetailModalProps> = ({
  customer,
  invoices,
  payments,
  users = [],
  auditLogs = [],
  isOpen,
  onClose,
  onSelectInvoice,
  onEditCustomer,
  onNewInvoice,
  onAddPayment,
  onRefresh,
}) => {
  const { userProfile, permissions } = useAuth();
  const isSuperAdmin = userProfile?.role === 'super_admin';
  const canManage = permissions?.canManageCustomers;

  const [activeTab, setActiveTab] = useState<'overview' | 'invoices' | 'payments' | 'activity'>('overview');
  const [statusUpdating, setStatusUpdating] = useState<boolean>(false);
  const [copiedPhone, setCopiedPhone] = useState<boolean>(false);
  const [copiedCode, setCopiedCode] = useState<boolean>(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);

  // More menu dropdown state
  const [showMoreMenu, setShowMoreMenu] = useState<boolean>(false);

  // Delete modal confirmation
  const [showDeleteConfirm, setShowDeleteConfirm] = useState<boolean>(false);
  const [deleting, setDeleting] = useState<boolean>(false);

  // Settings menu button & popover ref for outside click & escape key
  const settingsMenuRef = useRef<HTMLDivElement>(null);

  // Scroll container and tab body refs for unified mobile & desktop scroll control
  const scrollContainerRef = useRef<HTMLDivElement>(null);
  const tabBodyRef = useRef<HTMLDivElement>(null);

  // Reset scroll container position to top whenever active tab changes to allow fresh top-to-bottom scrolling
  useEffect(() => {
    if (scrollContainerRef.current) {
      scrollContainerRef.current.scrollTop = 0;
    }
    if (tabBodyRef.current) {
      tabBodyRef.current.scrollTop = 0;
    }
  }, [activeTab]);

  // Reset active tab to overview and scroll container to top when modal opens
  useEffect(() => {
    if (isOpen) {
      setActiveTab('overview');
      if (scrollContainerRef.current) {
        scrollContainerRef.current.scrollTop = 0;
      }
      if (tabBodyRef.current) {
        tabBodyRef.current.scrollTop = 0;
      }
    }
  }, [isOpen, customer?.id]);

  useEffect(() => {
    if (!showMoreMenu) return;

    const handleClickOutside = (event: MouseEvent) => {
      if (settingsMenuRef.current && !settingsMenuRef.current.contains(event.target as Node)) {
        setShowMoreMenu(false);
      }
    };

    const handleKeyDown = (event: KeyboardEvent) => {
      if (event.key === 'Escape') {
        setShowMoreMenu(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    document.addEventListener('keydown', handleKeyDown);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
      document.removeEventListener('keydown', handleKeyDown);
    };
  }, [showMoreMenu]);

  // Portal Account inline link state
  const [isLinkingPortal, setIsLinkingPortal] = useState<boolean>(false);
  const [selectedUserToLink, setSelectedUserToLink] = useState<string>('');
  const [isCreatingNewPortalUser, setIsCreatingNewPortalUser] = useState<boolean>(false);
  const [newPortalUsername, setNewPortalUsername] = useState<string>('');
  const [newPortalPassword, setNewPortalPassword] = useState<string>('');
  const [submittingPortal, setSubmittingPortal] = useState<boolean>(false);

  const customerId = customer?.id || '';
  const customerCode = customer ? (customer.customerCode || customer.customerId || customer.id) : '';
  const customerStatus = customer ? normalizeCustomerStatus(customer.status, customer.isArchived) : 'Active';
  const customerType: CustomerType = customer
    ? customer.customerType || (customer.companyName && customer.companyName.trim().length > 0 ? 'Business' : 'Individual')
    : 'Individual';

  const {
    totalInvoices,
    totalSales,
    totalPaid,
    remainingBalance,
    customerInvoices,
    customerPayments,
    hasOverdue,
    financialStatus,
  } = useMemo(() => {
    if (!customer) {
      return {
        totalInvoices: 0,
        totalSales: 0,
        totalPaid: 0,
        remainingBalance: 0,
        customerInvoices: [] as Invoice[],
        customerPayments: [] as Payment[],
        hasOverdue: false,
        financialStatus: 'Paid' as const,
      };
    }
    return calculateCustomerSummary(customer.id, invoices, payments);
  }, [customer, invoices, payments]);

  const hasFinancialTransactions = customerInvoices.length > 0 || customerPayments.length > 0;

  // Resolve linked user account if exists
  const linkedUser = customer
    ? (customer.userId
      ? users.find((u) => u.id === customer.userId || u.customerId === customer.id)
      : users.find((u) => u.customerId === customer.id))
    : undefined;

  // Unlinked user accounts available to link
  const unlinkedUsers = users.filter(
    (u) => u.role === 'customer' && !u.customerId && u.id !== customer?.userId
  );

  const initials = customer
    ? (customer.name || 'C')
        .split(' ')
        .filter(Boolean)
        .slice(0, 2)
        .map((w) => w[0]?.toUpperCase())
        .join('') || 'C'
    : 'C';

  const handleCopyPhone = () => {
    if (!customer.phone) return;
    navigator.clipboard.writeText(customer.phone);
    setCopiedPhone(true);
    setTimeout(() => setCopiedPhone(false), 2000);
  };

  const handleCopyCode = () => {
    navigator.clipboard.writeText(customerCode);
    setCopiedCode(true);
    setTimeout(() => setCopiedCode(false), 2000);
  };

  const handleStatusChange = async (newStatus: CustomerStatus) => {
    setStatusUpdating(true);
    setErrorMessage(null);
    setSuccessMessage(null);
    setShowMoreMenu(false);
    try {
      await setCustomerStatus(
        customer.id,
        newStatus,
        userProfile?.id || 'system',
        userProfile?.name || 'Staff',
        userProfile?.role || 'super_admin'
      );
      const msg = `Customer status successfully updated to ${newStatus}.`;
      setSuccessMessage(msg);
      toast.success(msg);
      if (onRefresh) onRefresh();
    } catch (err: any) {
      console.error('Error changing customer status:', err);
      const errMsg = err.message || 'Failed to update customer status.';
      setErrorMessage(errMsg);
      toast.error(errMsg);
    } finally {
      setStatusUpdating(false);
    }
  };

  const handleDeleteCustomer = async () => {
    setDeleting(true);
    setErrorMessage(null);
    try {
      await deleteCustomerSafely(
        customer.id,
        userProfile?.id || 'system',
        userProfile?.name || 'Staff'
      );
      toast.success(`Customer "${customer.name}" deleted successfully.`);
      setShowDeleteConfirm(false);
      onClose();
      if (onRefresh) onRefresh();
    } catch (err: any) {
      console.warn('Customer deletion notice:', err.message || err);
      const errMsg = err.message || 'Cannot delete customer.';
      setErrorMessage(errMsg);
      toast.error(errMsg);
      setShowDeleteConfirm(false);
    } finally {
      setDeleting(false);
    }
  };

  const handleLinkExistingUser = async () => {
    if (!selectedUserToLink) {
      setErrorMessage('Please select a user account to link.');
      return;
    }
    setSubmittingPortal(true);
    setErrorMessage(null);
    try {
      await linkCustomerToUserAccount(
        customer.id,
        selectedUserToLink,
        userProfile?.id || 'system',
        userProfile?.name || 'Staff'
      );
      const msg = 'Customer portal account linked successfully.';
      setSuccessMessage(msg);
      toast.success(msg);
      setIsLinkingPortal(false);
      setSelectedUserToLink('');
      if (onRefresh) onRefresh();
    } catch (err: any) {
      const errMsg = err.message || 'Failed to link user account.';
      setErrorMessage(errMsg);
      toast.error(errMsg);
    } finally {
      setSubmittingPortal(false);
    }
  };

  const handleCreateNewPortalUser = async () => {
    const uname = newPortalUsername.trim().toLowerCase();
    if (!uname || uname.length < 3) {
      setErrorMessage('Username must be at least 3 characters.');
      return;
    }
    if (!newPortalPassword || newPortalPassword.length < 6) {
      setErrorMessage('Initial password must be at least 6 characters.');
      return;
    }
    const emailToUse = customer.email?.trim() || `${uname}@customer.sarwan.local`;

    setSubmittingPortal(true);
    setErrorMessage(null);
    try {
      await createApplicationUser({
        name: customer.name,
        username: uname,
        email: emailToUse,
        phone: customer.phone,
        address: customer.address,
        defaultPassword: newPortalPassword,
        role: 'customer',
        status: 'active',
        customerId: customer.id,
        creatorId: userProfile?.id || 'system',
        creatorName: userProfile?.name || 'Staff',
      });
      const msg = 'Customer portal user created and linked successfully.';
      setSuccessMessage(msg);
      toast.success(msg);
      setIsCreatingNewPortalUser(false);
      setNewPortalUsername('');
      setNewPortalPassword('');
      if (onRefresh) onRefresh();
    } catch (err: any) {
      const errMsg = err.message || 'Failed to create portal user account.';
      setErrorMessage(errMsg);
      toast.error(errMsg);
    } finally {
      setSubmittingPortal(false);
    }
  };

  const handleUnlinkPortal = async () => {
    if (!window.confirm(`Unlink portal access from customer "${customer.name}"?`)) {
      return;
    }
    setSubmittingPortal(true);
    setErrorMessage(null);
    try {
      await unlinkCustomerUserAccount(
        customer.id,
        userProfile?.id || 'system',
        userProfile?.name || 'Staff'
      );
      const msg = 'Portal account unlinked.';
      setSuccessMessage(msg);
      toast.info(msg);
      if (onRefresh) onRefresh();
    } catch (err: any) {
      const errMsg = err.message || 'Failed to unlink portal account.';
      setErrorMessage(errMsg);
      toast.error(errMsg);
    } finally {
      setSubmittingPortal(false);
    }
  };

  // Build Chronological Unified Activity List
  const activityList = useMemo(() => {
    if (!customer) return [];
    const events: Array<{
      id: string;
      title: string;
      description: string;
      date: string;
      type: 'created' | 'updated' | 'invoice' | 'payment' | 'status' | 'portal';
      actor?: string;
    }> = [];

    // 1. Audit Logs
    const relevantLogs = auditLogs.filter(
      (l) => l.entityId === customer.id || l.referenceNumber === customerCode
    );
    relevantLogs.forEach((l) => {
      let t: 'created' | 'updated' | 'status' | 'portal' = 'updated';
      if (l.action === 'create_customer') t = 'created';
      else if (l.summary?.toLowerCase().includes('status')) t = 'status';
      events.push({
        id: `audit-${l.id}`,
        title: l.summary || 'Customer update',
        description: `Action: ${l.action} by ${l.userName} (${l.userRole || 'Staff'})`,
        date: l.dateTime,
        type: t,
        actor: l.userName,
      });
    });

    // 2. Invoices Created
    customerInvoices.forEach((inv) => {
      events.push({
        id: `inv-${inv.id}`,
        title: `Invoice Generated: ${inv.billNumber}`,
        description: `Total: ${formatAFN(inv.totalAmount)} • Status: ${inv.status} • Billing State: ${inv.billingState || 'quotation'}`,
        date: inv.createdAt || inv.date,
        type: 'invoice',
        actor: inv.createdByName,
      });
    });

    // 3. Payments Received
    customerPayments.forEach((p) => {
      events.push({
        id: `pay-${p.id}`,
        title: `Payment Received: ${formatAFN(p.amount)}`,
        description: `Invoice: ${p.billNumber} • Method: ${p.method} • Recorded by ${p.recordedByName || 'Staff'}`,
        date: p.createdAt || p.date,
        type: 'payment',
        actor: p.recordedByName,
      });
    });

    // Sort newest first
    return events.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
  }, [auditLogs, customer, customerCode, customerInvoices, customerPayments]);

  if (!isOpen || !customer) return null;

  const canCreateNewInvoice = customerStatus === 'Active';
  const hasPayableInvoices = customerInvoices.some(
    (inv) =>
      inv.status !== 'Paid' &&
      inv.status !== 'Void' &&
      !inv.isVoid &&
      inv.billingState === 'payable'
  );
  const canAddPayment = customerStatus === 'Active' || hasPayableInvoices;

  return (
    <div
      id="customer-detail-modal-overlay"
      className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-6 bg-black/60 backdrop-blur-xs overflow-y-auto"
      role="dialog"
      aria-modal="true"
      aria-labelledby="customer-detail-title"
    >
      <div
        id="customer-detail-modal-container"
        className="bg-white rounded-xl shadow-2xl w-full max-w-4xl max-h-[92vh] max-h-[92dvh] flex flex-col overflow-hidden border border-neutral-200 my-auto"
      >
        {/* Fixed Header: Customer Avatar | Name | Status Badge | ID | Settings & Close */}
        <div className="px-4 sm:px-6 py-3 sm:py-4 border-b border-neutral-200 bg-neutral-900 text-white shrink-0">
          <div className="flex items-center justify-between gap-2.5 sm:gap-3">
            {/* Left side: Avatar + Identity block */}
            <div className="flex items-center gap-2.5 sm:gap-3.5 min-w-0 flex-1">
              {/* Customer Avatar with Messenger-style Status Dot */}
              <div className="relative shrink-0">
                <div
                  className="w-10 h-10 sm:w-11 sm:h-11 rounded-full border-2 border-orange-400 overflow-hidden bg-neutral-800 flex items-center justify-center shrink-0 shadow-xs"
                  aria-hidden="true"
                >
                  {customer.photoURL ? (
                    <img
                      src={customer.photoURL}
                      alt={customer.name}
                      className="w-full h-full object-cover"
                      referrerPolicy="no-referrer"
                    />
                  ) : (
                    <span className="text-xs sm:text-sm font-bold text-orange-400 select-none">
                      {initials}
                    </span>
                  )}
                </div>

                {/* Customer Status Dot Indicator at bottom-right corner of avatar */}
                <span
                  id="customer-status-indicator"
                  role="status"
                  aria-label={`Status: ${customerStatus}`}
                  title={`Status: ${customerStatus}`}
                  className={`absolute -bottom-0.5 -right-0.5 w-3 h-3 sm:w-3.5 sm:h-3.5 rounded-full border-2 border-neutral-900 shadow-xs pointer-events-auto ${
                    customerStatus === 'Active'
                      ? 'bg-emerald-500'
                      : customerStatus === 'Inactive'
                      ? 'bg-neutral-400'
                      : 'bg-rose-500'
                  }`}
                >
                  <span id="customer-status-badge" className="sr-only">
                    {customerStatus}
                  </span>
                </span>
              </div>

              {/* Identity details: Row 1 = Name + Code/Type; Row 2 (desktop) = Company + Phone */}
              <div className="min-w-0 flex-1">
                {/* Main Header Row: Avatar, Name, Code together */}
                <div className="flex items-center gap-2 flex-wrap sm:flex-nowrap min-w-0">
                  <h2
                    id="customer-detail-title"
                    className="text-base sm:text-lg font-bold text-white truncate max-w-[130px] xs:max-w-[200px] sm:max-w-md shrink min-w-0"
                    title={customer.name}
                  >
                    {customer.name}
                  </h2>

                  {/* Customer ID Badge */}
                  <button
                    type="button"
                    onClick={handleCopyCode}
                    className="font-mono text-xs font-bold px-2 py-0.5 rounded bg-neutral-800 text-orange-400 border border-neutral-700 hover:bg-neutral-700 hover:border-orange-500/50 transition inline-flex items-center gap-1 shrink-0 cursor-pointer"
                    title="Click to copy Customer ID"
                    aria-label={`Copy Customer ID: ${customerCode}`}
                  >
                    <span>{customerCode}</span>
                    {copiedCode ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3 text-neutral-400" />}
                  </button>

                  {/* Customer Type Badge */}
                  <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-neutral-800 text-neutral-300 border border-neutral-700 shrink-0 hidden sm:inline-block">
                    {customerType}
                  </span>
                </div>

                {/* Secondary Line on Desktop: Company name & Phone number */}
                <div className="hidden sm:flex flex-wrap items-center gap-x-2 gap-y-0.5 text-xs text-neutral-400 font-mono mt-0.5">
                  {customer.companyName && (
                    <span className="text-neutral-300 font-sans font-medium truncate max-w-[240px] flex items-center gap-1">
                      <Building className="w-3 h-3 text-neutral-500 shrink-0" aria-hidden="true" />
                      {customer.companyName}
                    </span>
                  )}
                  {customer.companyName && customer.phone && (
                    <span className="text-neutral-600" aria-hidden="true">•</span>
                  )}
                  {customer.phone && (
                    <div className="flex items-center gap-1.5 text-neutral-300">
                      <Phone className="w-3 h-3 text-neutral-500 shrink-0" aria-hidden="true" />
                      <span>{customer.phone}</span>
                      <button
                        type="button"
                        onClick={handleCopyPhone}
                        className="text-neutral-400 hover:text-white p-0.5 rounded transition cursor-pointer"
                        title="Copy phone"
                        aria-label="Copy phone number"
                      >
                        {copiedPhone ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                      </button>
                      <a
                        href={`https://wa.me/${customer.phone.replace(/[^0-9]/g, '')}`}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-emerald-400 hover:text-emerald-300 p-0.5 rounded transition"
                        title="Open WhatsApp chat"
                        aria-label="Open WhatsApp chat"
                      >
                        <MessageCircle className="w-3 h-3" />
                      </a>
                    </div>
                  )}
                </div>
              </div>
            </div>

            {/* Right side: Action Header with Settings Popover & Close button */}
            <div className="flex items-center gap-1.5 sm:gap-2 shrink-0">
              {/* Settings Menu and Customer Actions Popover */}
              <div className="relative" ref={settingsMenuRef}>
                <button
                  id="btn-customer-settings"
                  type="button"
                  onClick={() => setShowMoreMenu((prev) => !prev)}
                  className={`p-2 rounded-lg border transition flex items-center justify-center cursor-pointer ${
                    showMoreMenu
                      ? 'bg-neutral-800 text-white border-neutral-600 ring-2 ring-orange-500/50'
                      : 'text-neutral-300 hover:text-white hover:bg-neutral-800 border-neutral-700'
                  }`}
                  title="Settings & Customer Actions"
                  aria-label="Settings and customer actions"
                  aria-expanded={showMoreMenu}
                  aria-haspopup="menu"
                >
                  <Settings className="w-4 h-4" aria-hidden="true" />
                </button>

                {showMoreMenu && (
                  <div
                    id="customer-settings-menu"
                    role="menu"
                    aria-label="Customer actions menu"
                    className="absolute right-0 mt-2 w-64 bg-white rounded-xl shadow-2xl border border-neutral-200 py-1.5 z-50 text-xs text-neutral-800 animate-in fade-in zoom-in-95 duration-100"
                  >
                    {/* Header Label */}
                    <div className="px-3.5 py-1.5 border-b border-neutral-100 flex items-center justify-between">
                      <span className="font-bold text-[10px] text-neutral-400 uppercase tracking-wider">
                        Customer Actions
                      </span>
                      <span className="font-mono text-[10px] text-neutral-500 font-medium">
                        {customerCode}
                      </span>
                    </div>

                    {/* Action 1: Edit */}
                    {canManage && onEditCustomer && (
                      <button
                        id="btn-menu-edit-customer"
                        role="menuitem"
                        type="button"
                        onClick={() => {
                          setShowMoreMenu(false);
                          onClose();
                          onEditCustomer(customer);
                        }}
                        className="w-full text-left px-3.5 py-2.5 hover:bg-neutral-50 flex items-center gap-2.5 font-medium transition cursor-pointer"
                      >
                        <Edit2 className="w-4 h-4 text-neutral-600 shrink-0" aria-hidden="true" />
                        <div className="flex-1 min-w-0">
                          <p className="font-semibold text-neutral-900">Edit</p>
                          <p className="text-[10px] text-neutral-500">Update customer profile &amp; contacts</p>
                        </div>
                      </button>
                    )}

                    {/* Action 2: New Invoice */}
                    {onNewInvoice && (
                      <button
                        id="btn-menu-new-invoice"
                        role="menuitem"
                        type="button"
                        disabled={!canCreateNewInvoice}
                        onClick={() => {
                          if (!canCreateNewInvoice) return;
                          setShowMoreMenu(false);
                          onClose();
                          onNewInvoice(customer);
                        }}
                        className={`w-full text-left px-3.5 py-2.5 flex items-center gap-2.5 font-medium transition ${
                          canCreateNewInvoice
                            ? 'hover:bg-orange-50 text-orange-900 cursor-pointer'
                            : 'opacity-50 cursor-not-allowed text-neutral-400'
                        }`}
                        title={
                          !canCreateNewInvoice
                            ? `Cannot create invoice for an ${customerStatus} customer`
                            : 'Create a new invoice for this customer'
                        }
                      >
                        <Plus className="w-4 h-4 text-orange-600 shrink-0" aria-hidden="true" />
                        <div className="flex-1 min-w-0">
                          <p className="font-semibold text-neutral-900">New Invoice</p>
                          <p className="text-[10px] text-neutral-500">Generate fresh bill or quote</p>
                        </div>
                      </button>
                    )}

                    {/* Action 3: Add Payment */}
                    {onAddPayment && (
                      <button
                        id="btn-menu-add-payment"
                        role="menuitem"
                        type="button"
                        disabled={!canAddPayment}
                        onClick={() => {
                          if (!canAddPayment) {
                            setErrorMessage(
                              `Cannot record payment: Customer is ${customerStatus} and has no outstanding payable invoices.`
                            );
                            return;
                          }
                          setShowMoreMenu(false);
                          onClose();
                          onAddPayment(customer);
                        }}
                        className={`w-full text-left px-3.5 py-2.5 flex items-center gap-2.5 font-medium transition ${
                          canAddPayment
                            ? 'hover:bg-emerald-50 text-emerald-900 cursor-pointer'
                            : 'opacity-50 cursor-not-allowed text-neutral-400'
                        }`}
                        title={
                          !canAddPayment
                            ? `Cannot record standalone payments for an ${customerStatus} customer with no outstanding invoices`
                            : 'Record payment against customer invoice'
                        }
                      >
                        <DollarSign className="w-4 h-4 text-emerald-600 shrink-0" aria-hidden="true" />
                        <div className="flex-1 min-w-0">
                          <p className="font-semibold text-neutral-900">Add Payment</p>
                          <p className="text-[10px] text-neutral-500">Record cash/bank settlement</p>
                        </div>
                      </button>
                    )}

                    {/* Status Management Section */}
                    <div className="border-t border-neutral-100 my-1" />
                    <div className="px-3.5 py-1 font-bold text-[10px] text-neutral-400 uppercase tracking-wider">
                      Status Management
                    </div>

                    {customerStatus !== 'Active' && (
                      <button
                        role="menuitem"
                        type="button"
                        disabled={customerStatus === 'Blocked' && !isSuperAdmin}
                        onClick={() => handleStatusChange('Active')}
                        className="w-full text-left px-3.5 py-2 hover:bg-neutral-50 flex items-center gap-2 font-medium disabled:opacity-50 disabled:cursor-not-allowed text-neutral-700"
                      >
                        <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                        <span>{customerStatus === 'Blocked' ? 'Unblock Customer (Super Admin)' : 'Mark as Active'}</span>
                      </button>
                    )}

                    {customerStatus !== 'Inactive' && (
                      <button
                        role="menuitem"
                        type="button"
                        onClick={() => handleStatusChange('Inactive')}
                        className="w-full text-left px-3.5 py-2 hover:bg-neutral-50 flex items-center gap-2 font-medium text-neutral-700"
                      >
                        <PauseCircle className="w-3.5 h-3.5 text-neutral-600 shrink-0" />
                        <span>Mark as Inactive</span>
                      </button>
                    )}

                    {customerStatus !== 'Blocked' && isSuperAdmin && (
                      <button
                        role="menuitem"
                        type="button"
                        onClick={() => handleStatusChange('Blocked')}
                        className="w-full text-left px-3.5 py-2 hover:bg-neutral-50 flex items-center gap-2 font-medium text-rose-600"
                      >
                        <Lock className="w-3.5 h-3.5 text-rose-600 shrink-0" />
                        <span>Block Customer Account</span>
                      </button>
                    )}

                    {/* Danger zone / Delete */}
                    <div className="border-t border-neutral-100 my-1" />
                    <button
                      id="btn-menu-delete-customer"
                      role="menuitem"
                      type="button"
                      onClick={() => {
                        setShowMoreMenu(false);
                        setShowDeleteConfirm(true);
                      }}
                      className="w-full text-left px-3.5 py-2 hover:bg-rose-50 flex items-center gap-2 font-medium text-rose-600 transition cursor-pointer"
                    >
                      <Trash2 className="w-3.5 h-3.5 shrink-0" />
                      <span>Delete Customer</span>
                    </button>
                  </div>
                )}
              </div>

              {/* Modal Close Button */}
              <button
                id="btn-close-customer-detail"
                type="button"
                onClick={onClose}
                className="p-2 rounded-lg text-neutral-400 hover:text-white hover:bg-neutral-800 transition cursor-pointer"
                title="Close modal"
                aria-label="Close customer details"
              >
                <X className="w-5 h-5" aria-hidden="true" />
              </button>
            </div>
          </div>
        </div>

        {/* Mobile Contact Information Row: Immediately below the fixed header */}
        {(customer.phone || customer.companyName) && (
          <div
            id="customer-mobile-contact-row"
            className="sm:hidden px-4 py-2 bg-neutral-800/90 border-b border-neutral-700/80 flex items-center justify-between gap-2.5 text-xs text-neutral-300 shrink-0"
          >
            {/* Phone & Company */}
            <div className="flex items-center gap-2 min-w-0 flex-1 overflow-hidden">
              {customer.phone && (
                <div className="flex items-center gap-1.5 font-mono text-neutral-200 shrink-0">
                  <Phone className="w-3.5 h-3.5 text-neutral-400 shrink-0" aria-hidden="true" />
                  <span>{customer.phone}</span>
                  <button
                    type="button"
                    onClick={handleCopyPhone}
                    className="p-0.5 text-neutral-400 hover:text-white rounded transition cursor-pointer"
                    title="Copy phone"
                    aria-label="Copy phone number"
                  >
                    {copiedPhone ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3 text-neutral-400" />}
                  </button>
                </div>
              )}

              {customer.phone && customer.companyName && (
                <span className="text-neutral-500 shrink-0" aria-hidden="true">•</span>
              )}

              {customer.companyName && (
                <span className="text-neutral-300 font-sans font-medium truncate flex items-center gap-1 min-w-0">
                  <Building className="w-3.5 h-3.5 text-neutral-400 shrink-0" aria-hidden="true" />
                  <span className="truncate">{customer.companyName}</span>
                </span>
              )}
            </div>

            {/* WhatsApp message icon/button */}
            {customer.phone && (
              <a
                id="btn-whatsapp-mobile"
                href={`https://wa.me/${customer.phone.replace(/[^0-9]/g, '')}`}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-1 px-2.5 py-1 rounded bg-emerald-600/20 text-emerald-400 border border-emerald-600/40 hover:bg-emerald-600/30 transition shrink-0 text-xs font-semibold cursor-pointer"
                title="Open WhatsApp chat"
                aria-label="Open WhatsApp chat"
              >
                <MessageCircle className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                <span className="text-[11px]">WhatsApp</span>
              </a>
            )}
          </div>
        )}

        {/* Scrollable Container on Mobile / Flex Column on Desktop */}
        <div
          ref={scrollContainerRef}
          id="customer-modal-scroll-container"
          className="overflow-y-auto sm:overflow-visible flex-1 flex flex-col min-h-0"
        >
          {/* Status / Alert Messages */}
          {errorMessage && (
            <div className="mx-4 sm:mx-6 mt-4 p-3 bg-red-50 border border-red-200 text-red-700 text-xs rounded-lg flex items-start gap-2">
              <AlertCircle className="w-4 h-4 shrink-0 text-red-500 mt-0.5" />
              <div className="flex-1">{errorMessage}</div>
              <button onClick={() => setErrorMessage(null)} className="text-red-500 hover:text-red-700">
                <X className="w-3.5 h-3.5" />
              </button>
            </div>
          )}
          {successMessage && (
            <div className="mx-4 sm:mx-6 mt-4 p-3 bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs rounded-lg flex items-start gap-2">
              <Check className="w-4 h-4 shrink-0 text-emerald-600 mt-0.5" />
              <div className="flex-1">{successMessage}</div>
              <button onClick={() => setSuccessMessage(null)} className="text-emerald-600 hover:text-emerald-800">
                <X className="w-3.5 h-3.5" />
              </button>
            </div>
          )}

          {/* Financial Summary Cards Strip: Total Invoiced | Total Paid | Outstanding (Scrolls naturally on mobile) */}
          <div className="px-4 sm:px-6 pt-4 shrink-0">
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div className="bg-neutral-50 p-3.5 rounded-xl border border-neutral-200">
                <span className="text-[11px] font-bold text-neutral-500 uppercase tracking-wide block">
                  Total Invoiced (Payable)
                </span>
                <p className="text-lg font-black font-mono text-neutral-900 mt-1">
                  {formatAFN(totalSales)}
                </p>
                <span className="text-[10px] text-neutral-400 mt-0.5 block">
                  {customerInvoices.length} total invoice(s)
                </span>
              </div>

              <div className="bg-emerald-50/60 p-3.5 rounded-xl border border-emerald-200">
                <span className="text-[11px] font-bold text-emerald-800 uppercase tracking-wide block">
                  Total Paid
                </span>
                <p className="text-lg font-black font-mono text-emerald-700 mt-1">
                  {formatAFN(totalPaid)}
                </p>
                <span className="text-[10px] text-emerald-600 mt-0.5 block">
                  {customerPayments.length} recorded payment(s)
                </span>
              </div>

              <div
                className={`p-3.5 rounded-xl border ${
                  remainingBalance > 0
                    ? 'bg-rose-50/70 border-rose-200 text-rose-950'
                    : 'bg-emerald-50/60 border-emerald-200 text-emerald-950'
                }`}
              >
                <span className="text-[11px] font-bold uppercase tracking-wide block">
                  Outstanding Balance
                </span>
                <p className="text-lg font-black font-mono mt-1">
                  {formatAFN(remainingBalance)}
                </p>
                <span className="text-[10px] font-semibold mt-0.5 block">
                  {hasOverdue ? '⚠️ Overdue invoice(s) present' : remainingBalance > 0 ? 'Payment outstanding' : 'Fully settled (AFN 0)'}
                </span>
              </div>
            </div>
          </div>

          {/* 4 Tabs: Overview | Invoices | Payments | Activity — Sticky on Mobile directly under the fixed header */}
          <div className="sticky top-0 z-20 bg-white px-4 sm:px-6 pt-4 border-b border-neutral-200 flex items-center gap-3 sm:gap-4 text-xs font-bold overflow-x-auto shrink-0 shadow-xs sm:shadow-none">
            <button
              type="button"
              onClick={() => setActiveTab('overview')}
              className={`pb-2.5 border-b-2 transition shrink-0 cursor-pointer ${
                activeTab === 'overview'
                  ? 'border-orange-500 text-orange-600'
                  : 'border-transparent text-neutral-500 hover:text-neutral-900'
              }`}
            >
              Overview
            </button>
            <button
              type="button"
              onClick={() => setActiveTab('invoices')}
              className={`pb-2.5 border-b-2 transition flex items-center gap-1.5 shrink-0 cursor-pointer ${
                activeTab === 'invoices'
                  ? 'border-orange-500 text-orange-600'
                  : 'border-transparent text-neutral-500 hover:text-neutral-900'
              }`}
            >
              Invoices
              <span className="text-[10px] font-mono px-1.5 py-0.2 rounded-full bg-neutral-100 text-neutral-700">
                {customerInvoices.length}
              </span>
            </button>
            <button
              type="button"
              onClick={() => setActiveTab('payments')}
              className={`pb-2.5 border-b-2 transition flex items-center gap-1.5 shrink-0 cursor-pointer ${
                activeTab === 'payments'
                  ? 'border-orange-500 text-orange-600'
                  : 'border-transparent text-neutral-500 hover:text-neutral-900'
              }`}
            >
              Payments
              <span className="text-[10px] font-mono px-1.5 py-0.2 rounded-full bg-neutral-100 text-neutral-700">
                {customerPayments.length}
              </span>
            </button>
            <button
              type="button"
              onClick={() => setActiveTab('activity')}
              className={`pb-2.5 border-b-2 transition flex items-center gap-1.5 shrink-0 cursor-pointer ${
                activeTab === 'activity'
                  ? 'border-orange-500 text-orange-600'
                  : 'border-transparent text-neutral-500 hover:text-neutral-900'
              }`}
            >
              Activity
              <span className="text-[10px] font-mono px-1.5 py-0.2 rounded-full bg-neutral-100 text-neutral-700">
                {activityList.length}
              </span>
            </button>
          </div>

          {/* Tab Body: scrolls naturally in mobile unified container, or with its own scroll container on desktop */}
          <div
            ref={tabBodyRef}
            id="customer-modal-tab-body"
            className="p-4 sm:p-6 pb-8 sm:pb-6 sm:overflow-y-auto flex-1 flex flex-col min-h-full sm:min-h-0 space-y-4"
          >
          {/* TAB 1: OVERVIEW */}
          {activeTab === 'overview' && (
            <div key="tab-overview" className="flex-1 space-y-4 min-w-0">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {/* Contact & Location Card */}
                <div className="bg-neutral-50 p-4 rounded-xl border border-neutral-200 space-y-3 text-xs">
                  <span className="text-[11px] font-bold text-neutral-500 uppercase tracking-wider block">
                    Contact &amp; Location Information
                  </span>

                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <span className="text-[10px] text-neutral-400 block">Customer ID</span>
                      <span className="font-mono font-bold text-neutral-900">{customerCode}</span>
                    </div>
                    <div>
                      <span className="text-[10px] text-neutral-400 block">Customer Type</span>
                      <span className="font-semibold text-neutral-900">{customerType}</span>
                    </div>
                  </div>

                  <div>
                    <span className="text-[10px] text-neutral-400 block">Full Name</span>
                    <span className="font-bold text-neutral-900">{customer.name}</span>
                  </div>

                  {customer.companyName && (
                    <div>
                      <span className="text-[10px] text-neutral-400 block">Company / Business Name</span>
                      <span className="font-medium text-neutral-900">{customer.companyName}</span>
                    </div>
                  )}

                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <span className="text-[10px] text-neutral-400 block">Primary Phone</span>
                      <div className="flex items-center gap-1.5 font-mono font-bold text-neutral-900">
                        <span>{customer.phone}</span>
                        <button
                          type="button"
                          onClick={handleCopyPhone}
                          className="text-neutral-400 hover:text-neutral-700"
                          title="Copy"
                        >
                          {copiedPhone ? <Check className="w-3 h-3 text-emerald-600" /> : <Copy className="w-3 h-3" />}
                        </button>
                        {customer.phone && (
                          <a
                            href={`https://wa.me/${customer.phone.replace(/[^0-9]/g, '')}`}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="text-emerald-600 hover:text-emerald-700"
                            title="WhatsApp"
                          >
                            <MessageCircle className="w-3.5 h-3.5" />
                          </a>
                        )}
                      </div>
                    </div>

                    <div>
                      <span className="text-[10px] text-neutral-400 block">Alternate Phone</span>
                      <span className="font-mono text-neutral-800">{customer.alternatePhone || '—'}</span>
                    </div>
                  </div>

                  <div>
                    <span className="text-[10px] text-neutral-400 block">Email Address</span>
                    {customer.email ? (
                      <a href={`mailto:${customer.email}`} className="text-blue-600 hover:underline">
                        {customer.email}
                      </a>
                    ) : (
                      <span className="text-neutral-400">—</span>
                    )}
                  </div>

                  <div>
                    <span className="text-[10px] text-neutral-400 block">Street / Physical Address</span>
                    <span className="text-neutral-800">{customer.address || '—'}</span>
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <span className="text-[10px] text-neutral-400 block">City</span>
                      <span className="text-neutral-800 font-medium">{customer.city || 'Kabul'}</span>
                    </div>
                    <div>
                      <span className="text-[10px] text-neutral-400 block">Province</span>
                      <span className="text-neutral-800 font-medium">{customer.province || 'Kabul'}</span>
                    </div>
                  </div>
                </div>

                {/* System & Portal Account Card */}
                <div className="bg-neutral-50 p-4 rounded-xl border border-neutral-200 space-y-3 text-xs">
                  <span className="text-[11px] font-bold text-neutral-500 uppercase tracking-wider block">
                    Account Status &amp; Audit Metadata
                  </span>

                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <span className="text-[10px] text-neutral-400 block">Status</span>
                      <span className="font-bold text-neutral-900">{customerStatus}</span>
                    </div>
                    <div>
                      <span className="text-[10px] text-neutral-400 block">Portal Access</span>
                      <span className="font-semibold text-neutral-900">
                        {linkedUser || customer.userId ? 'Enabled' : 'Disabled'}
                      </span>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <span className="text-[10px] text-neutral-400 block">Created At</span>
                      <span className="text-neutral-800">{formatDate(customer.createdAt)}</span>
                    </div>
                    <div>
                      <span className="text-[10px] text-neutral-400 block">Created By</span>
                      <span className="text-neutral-800">{customer.createdByName || customer.createdBy || 'System'}</span>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <span className="text-[10px] text-neutral-400 block">Last Updated</span>
                      <span className="text-neutral-800">{formatDate(customer.updatedAt)}</span>
                    </div>
                    <div>
                      <span className="text-[10px] text-neutral-400 block">Updated By</span>
                      <span className="text-neutral-800">{customer.updatedByName || customer.updatedBy || '—'}</span>
                    </div>
                  </div>

                  {/* Notes */}
                  <div>
                    <span className="text-[10px] text-neutral-400 block">Administrative Notes</span>
                    <p className="text-neutral-700 bg-white p-2 rounded border border-neutral-200 mt-1 whitespace-pre-wrap">
                      {customer.notes || customer.note || 'No notes recorded for this customer.'}
                    </p>
                  </div>

                  {/* Portal Integration Actions */}
                  <div className="pt-2 border-t border-neutral-200">
                    <span className="text-[10px] font-bold text-neutral-500 uppercase tracking-wider block mb-1.5">
                      Portal Self-Service Management
                    </span>
                    {linkedUser || customer.userId ? (
                      <div className="flex items-center justify-between p-2 bg-white rounded border border-neutral-200">
                        <div className="flex items-center gap-2">
                          <ShieldCheck className="w-4 h-4 text-emerald-600" />
                          <span className="font-mono text-neutral-800 font-bold">
                            @{linkedUser?.username || customer.userUsername || 'portal_user'}
                          </span>
                        </div>
                        <button
                          type="button"
                          onClick={handleUnlinkPortal}
                          disabled={submittingPortal}
                          className="text-rose-600 hover:text-rose-700 text-[11px] font-semibold"
                        >
                          Unlink
                        </button>
                      </div>
                    ) : (
                      <div className="space-y-2">
                        <p className="text-[11px] text-neutral-500">
                          This customer does not have a linked portal user account.
                        </p>
                        <div className="flex items-center gap-2">
                          <button
                            type="button"
                            onClick={() => setIsCreatingNewPortalUser(true)}
                            className="px-2.5 py-1 text-[11px] font-bold bg-[#2563EB] hover:bg-[#1D4ED8] active:bg-[#1E40AF] text-white rounded-md shadow-2xs transition cursor-pointer"
                          >
                            Create Portal Account
                          </button>
                          {unlinkedUsers.length > 0 && (
                            <button
                              type="button"
                              onClick={() => setIsLinkingPortal(true)}
                              className="px-2.5 py-1 text-[11px] font-semibold bg-white border border-neutral-300 text-neutral-700 rounded-md hover:bg-neutral-50 transition cursor-pointer"
                            >
                              Link Existing User
                            </button>
                          )}
                        </div>
                      </div>
                    )}

                    {/* Inline Create Portal User */}
                    {isCreatingNewPortalUser && (
                      <div className="mt-2 p-3 bg-white rounded border border-neutral-200 space-y-2">
                        <span className="font-bold text-[11px] text-neutral-800 block">
                          Create New Portal User Account
                        </span>
                        <input
                          type="text"
                          placeholder="Username (min 3 chars)"
                          value={newPortalUsername ?? ''}
                          onChange={(e) => setNewPortalUsername(e.target.value)}
                          className="w-full text-xs px-2.5 py-1 border border-neutral-300 rounded font-mono"
                        />
                        <input
                          type="password"
                          placeholder="Temporary Password (min 6 chars)"
                          value={newPortalPassword ?? ''}
                          onChange={(e) => setNewPortalPassword(e.target.value)}
                          className="w-full text-xs px-2.5 py-1 border border-neutral-300 rounded font-mono"
                        />
                        <div className="flex items-center justify-end gap-2">
                          <button
                            type="button"
                            onClick={() => setIsCreatingNewPortalUser(false)}
                            className="text-xs text-neutral-500 hover:text-neutral-700"
                          >
                            Cancel
                          </button>
                          <button
                            type="button"
                            disabled={submittingPortal}
                            onClick={handleCreateNewPortalUser}
                            className="px-3 py-1 text-xs font-bold bg-[#2563EB] hover:bg-[#1D4ED8] active:bg-[#1E40AF] text-white rounded-md shadow-2xs transition cursor-pointer"
                          >
                            Create
                          </button>
                        </div>
                      </div>
                    )}

                    {/* Inline Link Existing User */}
                    {isLinkingPortal && (
                      <div className="mt-2 p-3 bg-white rounded border border-neutral-200 space-y-2">
                        <span className="font-bold text-[11px] text-neutral-800 block">
                          Link to Existing User Account
                        </span>
                        <select
                          value={selectedUserToLink ?? ''}
                          onChange={(e) => setSelectedUserToLink(e.target.value)}
                          className="w-full text-xs px-2.5 py-1 border border-neutral-300 rounded"
                        >
                          <option value="">Select unlinked user...</option>
                          {unlinkedUsers.map((u) => (
                            <option key={u.id} value={u.id}>
                              {u.name} (@{u.username})
                            </option>
                          ))}
                        </select>
                        <div className="flex items-center justify-end gap-2">
                          <button
                            type="button"
                            onClick={() => setIsLinkingPortal(false)}
                            className="text-xs text-neutral-500 hover:text-neutral-700"
                          >
                            Cancel
                          </button>
                          <button
                            type="button"
                            disabled={submittingPortal || !selectedUserToLink}
                            onClick={handleLinkExistingUser}
                            className="px-3 py-1 text-xs font-bold bg-[#2563EB] hover:bg-[#1D4ED8] active:bg-[#1E40AF] text-white rounded-md shadow-2xs transition cursor-pointer"
                          >
                            Link
                          </button>
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* TAB 2: INVOICES (Invoice No | Date | Amount | Paid | Remaining | Status) */}
          {activeTab === 'invoices' && (
            <div key="tab-invoices" className="flex-1 space-y-3 min-w-0">
              {customerInvoices.length === 0 ? (
                <div className="p-8 text-center text-xs text-neutral-500 bg-neutral-50 rounded-xl border border-neutral-200 space-y-2">
                  <FileText className="w-8 h-8 text-neutral-400 mx-auto" />
                  <p className="font-bold text-neutral-700">No invoices generated for this customer</p>
                  {canCreateNewInvoice && onNewInvoice && (
                    <button
                      type="button"
                      onClick={() => {
                        onClose();
                        onNewInvoice(customer);
                      }}
                      className="mt-2 px-3.5 py-1.5 text-xs font-bold bg-[#2563EB] hover:bg-[#1D4ED8] active:bg-[#1E40AF] text-white rounded-lg shadow-xs inline-flex items-center gap-1.5 cursor-pointer focus:outline-none focus-visible:ring-2 focus-visible:ring-[#2563EB]"
                    >
                      <Plus className="w-3.5 h-3.5" />
                      Generate First Invoice
                    </button>
                  )}
                </div>
              ) : (
                <div className="overflow-x-auto rounded-xl border border-neutral-200">
                  <table className="w-full border-collapse text-xs">
                    <thead>
                      <tr className="bg-neutral-900 text-white font-semibold text-left">
                        <th className="py-2.5 px-3 whitespace-nowrap">Invoice No</th>
                        <th className="py-2.5 px-3">Date</th>
                        <th className="py-2.5 px-3 text-right">Amount</th>
                        <th className="py-2.5 px-3 text-right">Paid</th>
                        <th className="py-2.5 px-3 text-right">Remaining</th>
                        <th className="py-2.5 px-3 text-center">Status</th>
                        <th className="py-2.5 px-3 text-right">Actions</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-neutral-200">
                      {customerInvoices.map((inv) => {
                        const invPaid = customerPayments
                          .filter((p) => p.invoiceId === inv.id && !p.isVoid)
                          .reduce((s, p) => s + (Number(p.amount) || 0), 0);
                        const invRemaining = Math.max(0, (Number(inv.totalAmount) || 0) - invPaid);

                        return (
                          <tr
                            key={inv.id}
                            className="hover:bg-neutral-50 cursor-pointer transition"
                            onClick={() => onSelectInvoice && onSelectInvoice(inv)}
                          >
                            <td className="py-2.5 px-3 font-mono font-bold text-neutral-900 whitespace-nowrap">
                              {inv.billNumber}
                            </td>
                            <td className="py-2.5 px-3 text-neutral-600 whitespace-nowrap">
                              {formatDate(inv.date)}
                            </td>
                            <td className="py-2.5 px-3 text-right font-mono font-bold text-neutral-900 whitespace-nowrap">
                              {formatAFN(inv.totalAmount)}
                            </td>
                            <td className="py-2.5 px-3 text-right font-mono font-bold text-emerald-700 whitespace-nowrap">
                              {formatAFN(invPaid)}
                            </td>
                            <td className="py-2.5 px-3 text-right font-mono font-bold whitespace-nowrap">
                              <span className={invRemaining > 0 ? 'text-rose-600' : 'text-neutral-400'}>
                                {formatAFN(invRemaining)}
                              </span>
                            </td>
                            <td className="py-2.5 px-3 text-center whitespace-nowrap">
                              <span
                                className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                                  inv.status === 'Paid'
                                    ? 'bg-emerald-100 text-emerald-800'
                                    : inv.status === 'Partially Paid'
                                    ? 'bg-orange-100 text-orange-800'
                                    : inv.status === 'Void'
                                    ? 'bg-neutral-200 text-neutral-600'
                                    : 'bg-red-100 text-red-800'
                                }`}
                              >
                                {inv.status}
                              </span>
                            </td>
                            <td className="py-2.5 px-3 text-right whitespace-nowrap">
                              <button
                                type="button"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  if (onSelectInvoice) onSelectInvoice(inv);
                                }}
                                className="px-2 py-1 text-xs text-orange-600 hover:text-orange-700 font-bold hover:bg-orange-50 rounded transition"
                              >
                                View
                              </button>
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          )}

          {/* TAB 3: PAYMENTS (Date | Invoice | Amount | Method | Reference) */}
          {activeTab === 'payments' && (
            <div key="tab-payments" className="flex-1 space-y-3 min-w-0">
              {customerPayments.length === 0 ? (
                <div className="p-8 text-center text-xs text-neutral-500 bg-neutral-50 rounded-xl border border-neutral-200 space-y-2">
                  <CreditCard className="w-8 h-8 text-neutral-400 mx-auto" />
                  <p className="font-bold text-neutral-700">No payment records found for this customer</p>
                </div>
              ) : (
                <div className="overflow-x-auto rounded-xl border border-neutral-200">
                  <table className="w-full border-collapse text-xs">
                    <thead>
                      <tr className="bg-neutral-900 text-white font-semibold text-left">
                        <th className="py-2.5 px-3">Date</th>
                        <th className="py-2.5 px-3">Invoice</th>
                        <th className="py-2.5 px-3 text-right">Amount</th>
                        <th className="py-2.5 px-3 text-center">Method</th>
                        <th className="py-2.5 px-3">Reference / Note</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-neutral-200">
                      {customerPayments.map((p) => (
                        <tr key={p.id} className="hover:bg-neutral-50">
                          <td className="py-2.5 px-3 whitespace-nowrap text-neutral-700">
                            {formatDate(p.date)}
                          </td>
                          <td className="py-2.5 px-3 font-mono font-bold text-neutral-900 whitespace-nowrap">
                            {p.billNumber}
                          </td>
                          <td className="py-2.5 px-3 text-right font-mono font-bold text-emerald-700 whitespace-nowrap">
                            {formatAFN(p.amount)}
                          </td>
                          <td className="py-2.5 px-3 text-center whitespace-nowrap">
                            <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-neutral-100 text-neutral-700">
                              {p.method}
                            </span>
                          </td>
                          <td className="py-2.5 px-3 text-neutral-600 truncate max-w-[200px]">
                            {p.note || '—'}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          )}

          {/* TAB 4: ACTIVITY (Chronological Audit / History Timeline) */}
          {activeTab === 'activity' && (
            <div key="tab-activity" className="flex-1 space-y-3 min-w-0">
              {activityList.length === 0 ? (
                <div className="p-8 text-center text-xs text-neutral-500 bg-neutral-50 rounded-xl border border-neutral-200 space-y-2">
                  <History className="w-8 h-8 text-neutral-400 mx-auto" />
                  <p className="font-bold text-neutral-700">No activity logged yet</p>
                </div>
              ) : (
                <div className="relative pl-6 space-y-4 before:absolute before:left-2.5 before:top-2 before:bottom-2 before:w-0.5 before:bg-neutral-200">
                  {activityList.map((ev) => (
                    <div key={ev.id} className="relative text-xs">
                      <div className="absolute -left-6 top-1 w-2.5 h-2.5 rounded-full bg-orange-500 ring-4 ring-white" />
                      <div className="bg-neutral-50 p-3 rounded-lg border border-neutral-200">
                        <div className="flex items-center justify-between gap-2">
                          <span className="font-bold text-neutral-900">{ev.title}</span>
                          <span className="text-[10px] text-neutral-400 font-mono">
                            {formatDate(ev.date)}
                          </span>
                        </div>
                        <p className="text-[11px] text-neutral-600 mt-0.5">{ev.description}</p>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}
          </div>
        </div>

        {/* Delete Confirmation Modal / Financial History Warning */}
        {showDeleteConfirm && (
          <div
            id="delete-customer-confirm-dialog"
            className="fixed inset-0 z-60 flex items-center justify-center p-4 bg-black/70 backdrop-blur-xs"
          >
            <div className="bg-white rounded-xl shadow-2xl p-6 max-w-md w-full border border-neutral-200 space-y-4">
              <div className="flex items-start gap-3">
                {hasFinancialTransactions ? (
                  <ShieldAlert className="w-6 h-6 text-amber-600 shrink-0" />
                ) : (
                  <Trash2 className="w-6 h-6 text-rose-600 shrink-0" />
                )}
                <div>
                  <h3 className="font-bold text-sm text-neutral-900">
                    {hasFinancialTransactions
                      ? 'Deletion Blocked: Financial History Exists'
                      : 'Permanently Delete Customer Account?'}
                  </h3>
                  <p className="text-xs text-neutral-600 mt-1">
                    {hasFinancialTransactions ? (
                      <>
                        Customer <strong>{customer.name}</strong> ({customerCode}) has{' '}
                        <strong>{customerInvoices.length} historical invoice(s)</strong> and{' '}
                        <strong>{customerPayments.length} payment(s)</strong>. Accounting ledgers must
                        remain intact for tax and financial auditing.
                        <br />
                        <br />
                        Would you like to mark this customer as <strong>Inactive</strong> instead?
                      </>
                    ) : (
                      <>
                        Are you sure you want to delete customer <strong>{customer.name}</strong> (
                        {customerCode})? This action cannot be undone.
                      </>
                    )}
                  </p>
                </div>
              </div>

              <div className="flex items-center justify-end gap-2 pt-2 border-t border-neutral-100">
                <button
                  type="button"
                  disabled={deleting}
                  onClick={() => setShowDeleteConfirm(false)}
                  className="px-3 py-1.5 text-xs font-semibold text-neutral-600 hover:bg-neutral-100 rounded-lg"
                >
                  Cancel
                </button>

                {hasFinancialTransactions ? (
                  <button
                    type="button"
                    onClick={() => {
                      setShowDeleteConfirm(false);
                      handleStatusChange('Inactive');
                    }}
                    className="px-3.5 py-1.5 text-xs font-bold text-white bg-amber-600 hover:bg-amber-700 active:bg-amber-800 rounded-lg shadow-xs cursor-pointer transition focus:outline-none focus-visible:ring-2 focus-visible:ring-amber-500"
                  >
                    Mark as Inactive
                  </button>
                ) : (
                  <button
                    type="button"
                    disabled={deleting}
                    onClick={handleDeleteCustomer}
                    className="px-3.5 py-1.5 text-xs font-bold text-white bg-red-600 hover:bg-red-700 active:bg-red-800 rounded-lg shadow-xs transition cursor-pointer active:scale-[0.98] focus:outline-none focus-visible:ring-2 focus-visible:ring-red-500 disabled:opacity-50"
                  >
                    {deleting ? 'Deleting...' : 'Confirm Delete'}
                  </button>
                )}
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
