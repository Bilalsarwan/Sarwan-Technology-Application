import React, { useEffect, useRef } from 'react';
import {
  Receipt,
  MessageSquare,
  Sparkles,
  BarChart3,
  UserCheck,
  ShieldAlert,
  Database,
  Palette,
  Settings,
  LogOut,
  X,
  ChevronRight,
  Shield,
} from 'lucide-react';
import { ActiveTab } from './Sidebar';
import { useAuth } from '../../context/AuthContext';
import { useTheme } from '../../context/ThemeContext';

interface MobileMoreSheetProps {
  isOpen: boolean;
  onClose: () => void;
  activeTab: ActiveTab;
  onTabChange: (tab: ActiveTab) => void;
}

export const MobileMoreSheet: React.FC<MobileMoreSheetProps> = ({
  isOpen,
  onClose,
  activeTab,
  onTabChange,
}) => {
  const { userProfile, signOutUser, permissions } = useAuth();
  const { currentTheme, openThemeSelector } = useTheme();
  const sheetRef = useRef<HTMLDivElement>(null);

  // Close on Escape
  useEffect(() => {
    if (!isOpen) return;
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  // Prevent background body scroll when bottom sheet is open
  useEffect(() => {
    if (isOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = '';
    }
    return () => {
      document.body.style.overflow = '';
    };
  }, [isOpen]);

  if (!isOpen) return null;

  const moreItems: {
    id: ActiveTab;
    label: string;
    icon: React.ReactNode;
    show: boolean;
    description: string;
  }[] = [
    {
      id: 'requests',
      label: 'Customer Requests',
      icon: <MessageSquare className="w-5 h-5" />,
      show: permissions.canManageRequests || permissions.canCreateInvoice,
      description: 'Service inquiries & quotes',
    },
    {
      id: 'projects',
      label: 'Security Showcase',
      icon: <Sparkles className="w-5 h-5" />,
      show: permissions.canManageProjects,
      description: 'Portfolio & client installations',
    },
    {
      id: 'reports',
      label: 'Financial Reports',
      icon: <BarChart3 className="w-5 h-5" />,
      show: permissions.canViewReports,
      description: 'Analytics, revenue & summaries',
    },
    {
      id: 'staff',
      label: 'Staff & Roles',
      icon: <UserCheck className="w-5 h-5" />,
      show: permissions.canManageUsers || permissions.canManageStaff,
      description: 'Team permissions & credentials',
    },
    {
      id: 'audit',
      label: 'Audit Logs',
      icon: <ShieldAlert className="w-5 h-5" />,
      show: permissions.canViewAuditLogs,
      description: 'Security records & activity',
    },
    {
      id: 'backup',
      label: 'Backup & Restore',
      icon: <Database className="w-5 h-5" />,
      show: permissions.canExportBackup,
      description: 'Database export & data safety',
    },
    {
      id: 'invoice_design',
      label: 'Invoice Design',
      icon: <Palette className="w-5 h-5" />,
      show: permissions.canManageSettings,
      description: 'A4 templates, layout & branding',
    },
    {
      id: 'settings',
      label: 'Business Settings',
      icon: <Settings className="w-5 h-5" />,
      show: permissions.canManageSettings,
      description: 'Company info, prefix & themes',
    },
  ];

  const handleSelectTab = (tab: ActiveTab) => {
    onTabChange(tab);
    onClose();
  };

  const handleOpenThemeSelector = () => {
    onClose();
    openThemeSelector();
  };

  return (
    <div
      className="fixed inset-0 z-50 flex flex-col justify-end lg:hidden bg-black/60 backdrop-blur-xs animate-in fade-in duration-200"
      onClick={onClose}
      role="dialog"
      aria-modal="true"
      aria-label="More navigation options"
    >
      <div
        ref={sheetRef}
        onClick={(e) => e.stopPropagation()}
        className="w-full max-h-[85vh] bg-[var(--app-surface-modal,#FFFFFF)] text-[var(--app-text-primary,#0F172A)] rounded-t-3xl shadow-2xl border-t border-[var(--app-border,#E2E8F0)] flex flex-col overflow-hidden animate-in slide-in-from-bottom duration-300 transition-colors"
      >
        {/* Drag handle & Header */}
        <div className="pt-3 pb-2 px-5 flex flex-col items-center border-b border-[var(--app-border-subtle,#F1F5F9)]">
          <div className="w-12 h-1.5 rounded-full bg-[var(--app-border-strong,#CBD5E1)] mb-3" />
          <div className="w-full flex items-center justify-between">
            <div>
              <h3 className="text-sm font-bold text-[var(--app-text-primary,#0F172A)]">
                More Sections
              </h3>
              <p className="text-[11px] text-[var(--app-text-muted,#64748B)]">
                Sarwan Technology Billing &amp; Business
              </p>
            </div>
            <button
              type="button"
              onClick={onClose}
              className="p-1.5 text-[var(--app-text-muted,#64748B)] hover:text-[var(--app-text-primary,#0F172A)] rounded-full hover:bg-[var(--color-interactive-hover,#F1F5F9)] transition cursor-pointer"
              aria-label="Close sheet"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Scrollable links list */}
        <div className="overflow-y-auto p-4 space-y-1.5 flex-1">
          {/* Quick Theme Switcher Action Card */}
          <div
            onClick={handleOpenThemeSelector}
            className="w-full p-3 rounded-xl bg-orange-50/80 dark:bg-orange-950/40 border border-orange-200/80 dark:border-orange-800/60 flex items-center justify-between transition cursor-pointer hover:bg-orange-100/80 dark:hover:bg-orange-900/40"
          >
            <div className="flex items-center gap-3 min-w-0">
              <div className="w-9 h-9 rounded-xl bg-orange-500 text-white flex items-center justify-center shadow-xs shrink-0">
                <Palette className="w-5 h-5" />
              </div>
              <div className="text-left min-w-0">
                <p className="text-xs font-bold text-neutral-900 dark:text-white truncate">
                  Theme &amp; Appearance
                </p>
                <p className="text-[11px] text-orange-700 dark:text-orange-400 truncate">
                  Current: {currentTheme.name}
                </p>
              </div>
            </div>
            <span className="text-xs font-semibold text-orange-600 dark:text-orange-400 flex items-center gap-1 shrink-0">
              Change
              <ChevronRight className="w-4 h-4" />
            </span>
          </div>

          <div className="py-2">
            <p className="text-[10px] font-bold uppercase tracking-wider text-neutral-400 dark:text-neutral-500 px-2 pb-1">
              Modules &amp; Tools
            </p>
            <div className="space-y-1">
              {moreItems
                .filter((item) => item.show)
                .map((item) => {
                  const isActive = activeTab === item.id;
                  return (
                    <button
                      key={item.id}
                      type="button"
                      onClick={() => handleSelectTab(item.id)}
                      className={`w-full flex items-center justify-between p-2.5 rounded-xl transition text-left cursor-pointer ${
                        isActive
                          ? 'bg-orange-500/10 text-orange-600 dark:text-orange-400 font-bold border border-orange-500/30'
                          : 'hover:bg-neutral-100 dark:hover:bg-neutral-800 text-neutral-700 dark:text-neutral-200'
                      }`}
                    >
                      <div className="flex items-center gap-3 min-w-0">
                        <div
                          className={`w-8 h-8 rounded-lg flex items-center justify-center shrink-0 ${
                            isActive
                              ? 'bg-orange-500 text-white shadow-2xs'
                              : 'bg-neutral-100 dark:bg-neutral-800 text-neutral-600 dark:text-neutral-400'
                          }`}
                        >
                          {item.icon}
                        </div>
                        <div className="min-w-0">
                          <p className="text-xs font-semibold truncate">{item.label}</p>
                          <p className="text-[10px] text-neutral-400 dark:text-neutral-500 truncate">
                            {item.description}
                          </p>
                        </div>
                      </div>
                      <ChevronRight className="w-4 h-4 text-neutral-400 shrink-0" />
                    </button>
                  );
                })}
            </div>
          </div>
        </div>

        {/* Footer: User & Sign Out */}
        <div className="p-4 border-t border-neutral-100 dark:border-neutral-800 bg-neutral-50/70 dark:bg-neutral-900/90 flex items-center justify-between">
          <div className="flex items-center gap-2.5 min-w-0">
            <div className="w-8 h-8 rounded-full bg-neutral-800 dark:bg-neutral-700 text-orange-400 font-bold text-xs flex items-center justify-center shrink-0">
              {userProfile?.name?.charAt(0) || 'U'}
            </div>
            <div className="min-w-0">
              <p className="text-xs font-semibold text-neutral-900 dark:text-white truncate">
                {userProfile?.name || 'User'}
              </p>
              <div className="flex items-center gap-1 text-[10px] text-neutral-500">
                <Shield className="w-2.5 h-2.5 text-orange-500" />
                <span className="capitalize">{userProfile?.role?.replace('_', ' ') || 'Staff'}</span>
              </div>
            </div>
          </div>

          <button
            type="button"
            onClick={signOutUser}
            className="px-3 py-1.5 text-xs font-semibold text-red-600 dark:text-red-400 hover:bg-red-50 dark:hover:bg-red-950/50 rounded-lg transition flex items-center gap-1.5 cursor-pointer"
          >
            <LogOut className="w-3.5 h-3.5" />
            Sign Out
          </button>
        </div>
      </div>
    </div>
  );
};
