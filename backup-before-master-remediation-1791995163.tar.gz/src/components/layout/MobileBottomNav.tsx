import React, { useState } from 'react';
import {
  LayoutDashboard,
  Users,
  FileText,
  DollarSign,
  Menu,
} from 'lucide-react';
import { ActiveTab } from './Sidebar';
import { MobileMoreSheet } from './MobileMoreSheet';

interface MobileBottomNavProps {
  activeTab: ActiveTab;
  onTabChange: (tab: ActiveTab) => void;
}

export const MobileBottomNav: React.FC<MobileBottomNavProps> = ({
  activeTab,
  onTabChange,
}) => {
  const [isMoreOpen, setIsMoreOpen] = useState(false);

  const primaryNavItems: {
    id: ActiveTab;
    label: string;
    icon: React.ReactNode;
  }[] = [
    {
      id: 'dashboard',
      label: 'Home',
      icon: <LayoutDashboard className="w-5 h-5" />,
    },
    {
      id: 'customers',
      label: 'Customers',
      icon: <Users className="w-5 h-5" />,
    },
    {
      id: 'invoices',
      label: 'Invoices',
      icon: <FileText className="w-5 h-5" />,
    },
    {
      id: 'payments',
      label: 'Payments',
      icon: <DollarSign className="w-5 h-5" />,
    },
  ];

  // If the active tab is none of the 4 main bottom items, then it is inside "More"
  const isMoreActive =
    isMoreOpen ||
    !primaryNavItems.some((item) => item.id === activeTab);

  return (
    <>
      <nav
        id="mobile-bottom-nav"
        className="fixed bottom-0 left-0 right-0 z-40 lg:hidden bg-[var(--app-surface-header,#FFFFFF)]/95 backdrop-blur-md border-t border-[var(--app-border,#E2E8F0)] shadow-[0_-4px_16px_rgba(0,0,0,0.06)] pb-[env(safe-area-inset-bottom)] transition-colors"
        aria-label="Mobile Bottom Navigation"
      >
        <div className="flex items-center justify-around h-16 px-1">
          {primaryNavItems.map((item) => {
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                type="button"
                id={`mobile-nav-${item.id}`}
                onClick={() => onTabChange(item.id)}
                className={`flex-1 flex flex-col items-center justify-center py-1 px-1 transition-all select-none cursor-pointer group ${
                  isActive
                    ? 'text-[var(--brand-orange,#F7941D)] font-bold scale-105'
                    : 'text-[var(--app-text-muted,#64748B)] hover:text-[var(--app-text-primary,#0F172A)]'
                }`}
              >
                <div
                  className={`relative p-1 rounded-full transition-transform ${
                    isActive ? 'text-[var(--brand-orange,#F7941D)]' : 'text-[var(--app-text-muted,#64748B)]'
                  }`}
                >
                  {item.icon}
                  {isActive && (
                    <span className="absolute -bottom-0.5 left-1/2 -translate-x-1/2 w-1.5 h-1.5 rounded-full bg-[var(--brand-orange,#F7941D)]" />
                  )}
                </div>
                <span className="text-[11px] tracking-tight truncate mt-0.5">
                  {item.label}
                </span>
              </button>
            );
          })}

          {/* More Button */}
          <button
            type="button"
            id="mobile-nav-more"
            onClick={() => setIsMoreOpen(true)}
            className={`flex-1 flex flex-col items-center justify-center py-1 px-1 transition-all select-none cursor-pointer group ${
              isMoreActive
                ? 'text-[var(--brand-orange,#F7941D)] font-bold scale-105'
                : 'text-[var(--app-text-muted,#64748B)] hover:text-[var(--app-text-primary,#0F172A)]'
            }`}
          >
            <div
              className={`relative p-1 rounded-full transition-transform ${
                isMoreActive ? 'text-[var(--brand-orange,#F7941D)]' : 'text-[var(--app-text-muted,#64748B)]'
              }`}
            >
              <Menu className="w-5 h-5" />
              {isMoreActive && (
                <span className="absolute -bottom-0.5 left-1/2 -translate-x-1/2 w-1.5 h-1.5 rounded-full bg-[var(--brand-orange,#F7941D)]" />
              )}
            </div>
            <span className="text-[11px] tracking-tight truncate mt-0.5">
              More
            </span>
          </button>
        </div>
      </nav>

      {/* Slide-up sheet */}
      <MobileMoreSheet
        isOpen={isMoreOpen}
        onClose={() => setIsMoreOpen(false)}
        activeTab={activeTab}
        onTabChange={onTabChange}
      />
    </>
  );
};
