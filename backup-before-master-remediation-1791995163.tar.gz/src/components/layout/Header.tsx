import React, { useState, useEffect, useRef } from 'react';
import { Menu, ShieldCheck, Bell, Clock, User, KeyRound, LogOut, Shield, ChevronRight, Palette, RefreshCw } from 'lucide-react';
import { ActiveTab } from './Sidebar';
import { useAuth } from '../../context/AuthContext';
import { useTheme } from '../../context/ThemeContext';
import { AppNotification, BusinessSettings } from '../../types';
import { UserProfileModal } from '../staff/UserProfileModal';
import { ChangePasswordModal } from '../auth/ChangePasswordModal';

interface HeaderProps {
  activeTab: ActiveTab;
  onOpenMobileMenu: () => void;
  onNewInvoice?: () => void;
  logo?: string;
  settings?: BusinessSettings;
  notifications?: AppNotification[];
  onMarkNotificationRead?: (id: string) => void;
  onTabChange?: (tab: ActiveTab) => void;
}

export const Header: React.FC<HeaderProps> = ({
  activeTab,
  onOpenMobileMenu,
  logo = '/sarwan-logo.png',
  settings,
  notifications = [],
  onMarkNotificationRead,
  onTabChange,
}) => {
  const { userProfile, permissions, signOutUser, updateCurrentUserProfile } = useAuth();
  const { currentTheme, openThemeSelector } = useTheme();
  const [isNotifOpen, setIsNotifOpen] = useState<boolean>(false);
  const [isProfileMenuOpen, setIsProfileMenuOpen] = useState<boolean>(false);
  const [isEditProfileOpen, setIsEditProfileOpen] = useState<boolean>(false);
  const [isChangePasswordOpen, setIsChangePasswordOpen] = useState<boolean>(false);

  // Dynamic sync state: 'online' (🟢), 'syncing' (🟠), 'offline' (🔴)
  const [syncState, setSyncState] = useState<'online' | 'syncing' | 'offline'>('online');

  // Authenticated User Presence state: 'online' (🟢), 'connecting' (🟡), 'offline' (⚪)
  const [userPresence, setUserPresence] = useState<'online' | 'connecting' | 'offline'>('online');

  const profileMenuRef = useRef<HTMLDivElement>(null);

  // Track dynamic real Firestore / Network sync status
  useEffect(() => {
    const handleOnline = () => {
      setSyncState('syncing');
      setTimeout(() => {
        setSyncState(typeof navigator !== 'undefined' && navigator.onLine ? 'online' : 'offline');
      }, 600);
    };

    const handleOffline = () => {
      setSyncState('offline');
    };

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    // Initial check
    if (typeof navigator !== 'undefined') {
      setSyncState(navigator.onLine ? 'online' : 'offline');
    }

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  // Authenticated user presence detection (online/offline/reconnecting/tab close/logout)
  useEffect(() => {
    // Only detect presence for currently authenticated user
    if (!userProfile?.id) {
      setUserPresence('offline');
      return;
    }

    // Initial presence check based on browser network and authentication session
    const isNetworkOnline = typeof navigator !== 'undefined' ? navigator.onLine : true;
    setUserPresence(isNetworkOnline ? 'online' : 'offline');

    let reconnectTimer: NodeJS.Timeout | null = null;

    const handlePresenceOnline = () => {
      // Transition through connecting/reconnecting state before confirming active online
      setUserPresence('connecting');
      if (reconnectTimer) clearTimeout(reconnectTimer);
      reconnectTimer = setTimeout(() => {
        if (typeof navigator !== 'undefined' && navigator.onLine) {
          setUserPresence('online');
        } else {
          setUserPresence('offline');
        }
      }, 700);
    };

    const handlePresenceOffline = () => {
      if (reconnectTimer) clearTimeout(reconnectTimer);
      setUserPresence('offline');
    };

    const handleVisibilityChange = () => {
      if (document.visibilityState === 'hidden') {
        // Tab is hidden / backgrounded
      } else if (document.visibilityState === 'visible') {
        if (typeof navigator !== 'undefined' && !navigator.onLine) {
          setUserPresence('offline');
        } else {
          setUserPresence('online');
        }
      }
    };

    const handleBeforeUnload = () => {
      // Clean presence transition when user closes browser tab or navigates away
      setUserPresence('offline');
    };

    window.addEventListener('online', handlePresenceOnline);
    window.addEventListener('offline', handlePresenceOffline);
    document.addEventListener('visibilitychange', handleVisibilityChange);
    window.addEventListener('beforeunload', handleBeforeUnload);

    return () => {
      if (reconnectTimer) clearTimeout(reconnectTimer);
      window.removeEventListener('online', handlePresenceOnline);
      window.removeEventListener('offline', handlePresenceOffline);
      document.removeEventListener('visibilitychange', handleVisibilityChange);
      window.removeEventListener('beforeunload', handleBeforeUnload);
    };
  }, [userProfile?.id]);

  // Close profile dropdown when clicking outside or pressing Escape
  useEffect(() => {
    if (!isProfileMenuOpen) return;

    const handleClickOutside = (event: MouseEvent) => {
      if (profileMenuRef.current && !profileMenuRef.current.contains(event.target as Node)) {
        setIsProfileMenuOpen(false);
      }
    };

    const handleKeyDown = (event: KeyboardEvent) => {
      if (event.key === 'Escape') {
        setIsProfileMenuOpen(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    document.addEventListener('keydown', handleKeyDown);

    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
      document.removeEventListener('keydown', handleKeyDown);
    };
  }, [isProfileMenuOpen]);

  // Manual Sync Refresh trigger within profile clickable box
  const handleTriggerSyncRefresh = async () => {
    setSyncState('syncing');
    try {
      // Trigger network/database sync verification
      if (typeof navigator !== 'undefined' && !navigator.onLine) {
        setSyncState('offline');
        setUserPresence('offline');
        return;
      }
      // Re-evaluate presence and sync state smoothly
      setUserPresence('connecting');
      await new Promise((res) => setTimeout(res, 650));
      setSyncState(typeof navigator !== 'undefined' && navigator.onLine ? 'online' : 'offline');
      setUserPresence(typeof navigator !== 'undefined' && navigator.onLine ? 'online' : 'offline');
    } catch {
      setSyncState('offline');
      setUserPresence('offline');
    }
  };

  const unreadCount = notifications.filter((n) => !n.isRead).length;

  const titles: Record<ActiveTab, string> = {
    dashboard: 'Business Dashboard',
    invoices: 'Invoice Management',
    customers: 'Customer Accounts & Ledger',
    payments: 'Cash Payment Transactions',
    requests: 'Customer Service Requests & Quotes',
    projects: 'CCTV & Security Showcase',
    reports: 'Financial Reports & Analytics',
    staff: 'Staff & Role-Based Access Control',
    audit: 'Audit Logs',
    backup: 'System Backup & Recovery',
    invoice_design: 'Invoice Designer',
    settings: 'System & Company Settings',
    notifications: 'Notifications & Alerts',
  };

  const getRoleDisplayName = (role?: string) => {
    if (!role) return 'Authorized User';
    switch (role) {
      case 'super_admin':
        return 'Super Admin';
      case 'invoice_manager':
        return 'Invoice Manager';
      case 'payment_collector':
        return 'Payment Collector';
      case 'customer':
        return 'Customer';
      default:
        return role.replace(/_/g, ' ');
    }
  };

  const userDisplayName = userProfile?.name || 'Authorized User';
  const userDisplayEmail = userProfile?.email || (userProfile?.username ? `@${userProfile.username}` : 'account@sarwan.af');
  const userInitial = userProfile?.name ? userProfile.name.charAt(0).toUpperCase() : 'U';

  return (
    <>
      <header className="sticky top-0 z-30 relative bg-[var(--app-surface-header,#FFFFFF)] border-b border-[var(--app-border,#E2E8F0)] px-3 sm:px-6 py-2.5 sm:py-3 flex items-center justify-between shadow-xs transition-colors">
        {/* LEFT: Business Dashboard title & Current User Role */}
        <div className="flex items-center gap-2.5 sm:gap-3 min-w-0">
          {/* Mobile menu toggle - hidden to prevent duplicate navigation; MobileBottomNav handles mobile navigation */}
          <button
            onClick={onOpenMobileMenu}
            className="hidden p-1.5 rounded-lg text-[var(--app-text-secondary,#475569)] hover:text-[var(--app-text-primary,#0F172A)] hover:bg-[var(--color-interactive-hover,#F1F5F9)] transition shrink-0 cursor-pointer"
            aria-label="Toggle navigation menu"
          >
            <Menu className="w-5 h-5" />
          </button>

          {/* Title & Dynamic authenticated user role directly underneath */}
          <div className="min-w-0">
            <h1
              id="header-page-title"
              className="text-sm sm:text-base lg:text-lg font-bold text-[var(--app-text-primary,#0F172A)] tracking-tight leading-tight truncate"
            >
              {activeTab === 'dashboard' ? 'Business Dashboard' : (titles[activeTab] || 'Sarwan Technology')}
            </h1>
            <div className="mt-1 flex items-center">
              <span
                id="header-user-role-badge"
                className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-md bg-[var(--app-bg-muted,#F1F5F9)] border border-[var(--app-border,#E2E8F0)] text-[var(--app-text-secondary,#475569)] text-[10.5px] sm:text-[11px] font-semibold tracking-tight shrink-0 shadow-2xs"
                title={`Role: ${getRoleDisplayName(userProfile?.role)}`}
              >
                <Shield className="w-2.5 h-2.5 sm:w-3 sm:h-3 text-[var(--brand-orange,#F7941D)] shrink-0" />
                <span className="truncate max-w-[140px] sm:max-w-none">{getRoleDisplayName(userProfile?.role)}</span>
              </span>
            </div>
          </div>
        </div>

        {/* CENTER & RIGHT SECTION */}
        <div className="flex items-center gap-1.5 sm:gap-2.5 shrink-0">
          {/* Notifications Bell */}
          <div className="sm:relative shrink-0">
            <button
              type="button"
              id="header-notification-bell-btn"
              onClick={() => setIsNotifOpen(!isNotifOpen)}
              className="p-2 rounded-lg text-[var(--app-text-secondary,#475569)] hover:text-[var(--app-text-primary,#0F172A)] hover:bg-[var(--color-interactive-hover,#F1F5F9)] transition relative cursor-pointer"
              aria-label="Notifications"
              aria-expanded={isNotifOpen}
            >
              <Bell className="w-4 h-4" />
              {unreadCount > 0 && (
                <span className="absolute top-1 right-1 w-4 h-4 bg-[var(--brand-orange,#F7941D)] text-white rounded-full text-[9px] font-bold flex items-center justify-center pointer-events-none">
                  {unreadCount > 9 ? '9+' : unreadCount}
                </span>
              )}
            </button>

            {isNotifOpen && (
              <>
                <div
                  className="fixed inset-0 z-40 bg-black/10 sm:bg-transparent"
                  onClick={() => setIsNotifOpen(false)}
                />
                <div
                  id="header-notifications-popover"
                  className="absolute left-1/2 -translate-x-1/2 sm:left-auto sm:right-0 sm:translate-x-0 top-full mt-1.5 sm:mt-2 w-[calc(100vw-24px)] sm:w-96 max-w-sm sm:max-w-md bg-[var(--app-surface-dropdown,#FFFFFF)] text-[var(--app-text-primary,#0F172A)] rounded-xl shadow-xl border border-[var(--app-border,#E2E8F0)] z-50 text-xs animate-in fade-in zoom-in-95 duration-100"
                >
                  {/* Subtle triangle caret pointing up to the notification bell */}
                  <div
                    className="sm:hidden absolute -top-1.5 right-[56px] w-3 h-3 bg-[var(--app-bg-muted,#F1F5F9)] border-t border-l border-[var(--app-border-subtle,#E2E8F0)] rotate-45 pointer-events-none z-20"
                    aria-hidden="true"
                  />
                  <div
                    className="hidden sm:block absolute -top-1.5 right-3 w-3 h-3 bg-[var(--app-bg-muted,#F1F5F9)] border-t border-l border-[var(--app-border-subtle,#E2E8F0)] rotate-45 pointer-events-none z-20"
                    aria-hidden="true"
                  />

                  {/* Header */}
                  <div className="p-3 border-b border-[var(--app-border-subtle,#F1F5F9)] bg-[var(--app-bg-muted,#F1F5F9)] rounded-t-xl flex items-center justify-between gap-2 relative z-10">
                    <div className="flex items-center gap-2 min-w-0">
                      <span className="font-bold text-[var(--app-text-primary,#0F172A)] text-xs sm:text-sm truncate">Notifications</span>
                      {unreadCount > 0 && (
                        <span className="px-1.5 py-0.5 bg-orange-500/15 text-[var(--brand-orange,#F7941D)] rounded-full text-[10px] font-bold shrink-0 whitespace-nowrap">
                          {unreadCount} new
                        </span>
                      )}
                    </div>
                    {unreadCount > 0 && onMarkNotificationRead && (
                      <button
                        type="button"
                        id="header-mark-all-notifications-read"
                        onClick={() => {
                          notifications
                            .filter((n) => !n.isRead)
                            .forEach((n) => onMarkNotificationRead(n.id));
                        }}
                        className="text-[11px] text-[var(--brand-orange,#F7941D)] hover:opacity-80 font-semibold cursor-pointer shrink-0 whitespace-nowrap"
                      >
                        Mark all read
                      </button>
                    )}
                  </div>

                  {/* Notification items list */}
                  <div className="max-h-[min(60vh,22rem)] sm:max-h-80 overflow-y-auto overflow-x-hidden divide-y divide-[var(--app-border-subtle,#F1F5F9)] bg-[var(--app-surface-dropdown,#FFFFFF)]">
                    {notifications.length === 0 ? (
                      <div className="p-6 text-center text-neutral-400">
                        <Bell className="w-8 h-8 mx-auto mb-2 text-neutral-300" />
                        <p>No notifications yet</p>
                      </div>
                    ) : (
                      notifications.slice(0, 10).map((notif) => (
                        <div
                          key={notif.id}
                          onClick={() => {
                            if (!notif.isRead && onMarkNotificationRead) {
                              onMarkNotificationRead(notif.id);
                            }
                            if (notif.type === 'invoice' && onTabChange) onTabChange('invoices');
                            if (notif.type === 'payment' && onTabChange) onTabChange('payments');
                            if (notif.type === 'expense' && onTabChange) onTabChange('invoices');
                            if (notif.type === 'request' && onTabChange) onTabChange('requests');
                            if (notif.type === 'project' && onTabChange) onTabChange('projects');
                            if (notif.type === 'system' && onTabChange && permissions.canViewAuditLogs) onTabChange('audit');
                            setIsNotifOpen(false);
                          }}
                          className={`p-3 hover:bg-[var(--color-interactive-hover,#F1F5F9)] transition cursor-pointer flex items-start gap-2.5 ${
                            !notif.isRead ? 'bg-[var(--brand-orange,#F7941D)]/10' : ''
                          }`}
                        >
                          <div
                            className={`w-2 h-2 rounded-full mt-1.5 shrink-0 ${
                              !notif.isRead ? 'bg-[var(--brand-orange,#F7941D)]' : 'bg-transparent'
                            }`}
                          />
                          <div className="flex-1 min-w-0">
                            <p className="font-bold text-[var(--app-text-primary,#0F172A)] text-xs break-words [overflow-wrap:anywhere] leading-snug">
                              {notif.title}
                            </p>
                            <p className="text-[var(--app-text-secondary,#475569)] text-[11px] sm:text-xs line-clamp-3 mt-0.5 break-words [overflow-wrap:anywhere] leading-relaxed">
                              {notif.message}
                            </p>
                            <span className="text-[10px] text-[var(--app-text-muted,#64748B)] mt-1 block break-words">
                              {new Date(notif.createdAt).toLocaleString()}
                            </span>
                          </div>
                        </div>
                      ))
                    )}
                  </div>

                  {/* View All Notifications Action */}
                  <div className="p-2.5 border-t border-[var(--app-border-subtle,#F1F5F9)] bg-[var(--app-bg-muted,#F1F5F9)] rounded-b-xl text-center">
                    <button
                      type="button"
                      id="header-view-all-notifications"
                      onClick={() => {
                        setIsNotifOpen(false);
                        if (onTabChange) onTabChange('notifications');
                      }}
                      className="w-full py-1.5 text-xs text-[var(--brand-orange,#F7941D)] hover:brightness-90 font-bold transition cursor-pointer flex items-center justify-center gap-1"
                    >
                      <span>View All Notifications</span>
                      <ChevronRight className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              </>
            )}
          </div>

          {/* Logged-In User Profile Avatar & Dropdown (Far Right - perfectly circular) */}
          <div className="relative shrink-0" ref={profileMenuRef}>
            <button
              type="button"
              id="header-user-profile-button"
              onClick={() => setIsProfileMenuOpen((prev) => !prev)}
              className="flex items-center justify-center p-0.5 rounded-full hover:ring-2 hover:ring-[var(--brand-orange,#F7941D)]/50 transition cursor-pointer focus:outline-none focus:ring-2 focus:ring-[var(--brand-orange,#F7941D)] shrink-0"
              aria-label={`User profile and account menu (${userDisplayName} is ${userPresence})`}
              aria-expanded={isProfileMenuOpen}
              aria-haspopup="true"
            >
              <div className="relative">
                <div
                  className="w-8 h-8 sm:w-8.5 sm:h-8.5 rounded-full overflow-hidden shrink-0 border border-neutral-300 dark:border-neutral-700 bg-neutral-100 dark:bg-neutral-800 flex items-center justify-center shadow-xs"
                  style={{ borderRadius: '50%' }}
                >
                  {userProfile?.photoURL ? (
                    <img
                      src={userProfile.photoURL}
                      alt={userDisplayName}
                      className="w-full h-full object-cover rounded-full"
                      style={{ borderRadius: '50%', objectFit: 'cover' }}
                      referrerPolicy="no-referrer"
                    />
                  ) : (
                    <div
                      className="w-full h-full flex items-center justify-center font-bold text-xs sm:text-sm text-[var(--brand-orange,#F7941D)] bg-orange-50 dark:bg-orange-950/30"
                      style={{ borderRadius: '50%' }}
                    >
                      {userInitial}
                    </div>
                  )}
                </div>

                {/* Messenger-style Online/Offline Presence & Sync Indicator */}
                <span
                  id="header-user-presence-dot"
                  className={`absolute bottom-0 ltr:right-0 rtl:left-0 right-0 w-2.5 h-2.5 rounded-full border-2 border-[var(--app-surface-header,#FFFFFF)] shadow-xs transition-colors duration-200 pointer-events-none ${
                    syncState === 'syncing' || userPresence === 'connecting'
                      ? 'bg-amber-400 animate-pulse'
                      : syncState === 'offline' || userPresence === 'offline'
                      ? 'bg-neutral-400 dark:bg-neutral-500'
                      : 'bg-emerald-500'
                  }`}
                  title={`Status: ${syncState === 'syncing' ? 'Syncing...' : userPresence === 'online' ? 'Online (Synced)' : userPresence === 'connecting' ? 'Connecting...' : 'Offline'}`}
                  aria-label={`Status: ${syncState === 'syncing' ? 'Syncing' : userPresence}`}
                />
              </div>
            </button>

            {/* Profile Dropdown Popover */}
            {isProfileMenuOpen && (
              <div
                id="header-user-profile-dropdown"
                className="absolute right-0 mt-2 w-64 max-w-[calc(100vw-1.5rem)] bg-neutral-900 border border-neutral-700 rounded-xl shadow-2xl p-3 z-50 animate-in fade-in zoom-in-95 duration-100 text-xs"
              >
                {/* Circular User Avatar */}
                <div className="flex flex-col items-center pt-1 pb-2">
                  <div
                    className="w-14 h-14 rounded-full overflow-hidden shrink-0 border-2 border-[var(--brand-orange,#F7941D)] bg-neutral-800 flex items-center justify-center shadow-md mb-2"
                    style={{ borderRadius: '50%' }}
                  >
                    {userProfile?.photoURL ? (
                      <img
                        src={userProfile.photoURL}
                        alt={userDisplayName}
                        className="w-full h-full object-cover rounded-full"
                        style={{ borderRadius: '50%', objectFit: 'cover' }}
                        referrerPolicy="no-referrer"
                      />
                    ) : (
                      <div
                        className="w-full h-full flex items-center justify-center font-bold text-lg text-orange-400 bg-neutral-800"
                        style={{ borderRadius: '50%' }}
                      >
                        {userInitial}
                      </div>
                    )}
                  </div>

                  {/* Separator */}
                  <div className="w-full border-t border-neutral-800 my-1.5" />

                  {/* User Information: User Name & Logged-in Email */}
                  <div className="w-full text-center px-1">
                    <p className="font-bold text-sm text-white truncate" title={userDisplayName}>
                      {userDisplayName}
                    </p>
                    <p className="text-[11px] text-neutral-400 truncate mt-0.5" title={userDisplayEmail}>
                      {userDisplayEmail}
                    </p>
                    {userProfile?.role && (
                      <div className="mt-1.5 inline-flex items-center gap-1 px-2 py-0.5 bg-neutral-800 border border-neutral-700 rounded-full text-[10px] text-orange-400 font-medium">
                        <Shield className="w-2.5 h-2.5 text-orange-400 shrink-0" />
                        <span>{getRoleDisplayName(userProfile.role)}</span>
                      </div>
                    )}
                  </div>
                </div>

                {/* Separator */}
                <div className="border-t border-neutral-800 my-2" />

                {/* Profile Actions */}
                <div className="space-y-1">
                  {/* Sync & Refresh Status */}
                  <button
                    type="button"
                    id="profile-dropdown-sync-refresh"
                    onClick={handleTriggerSyncRefresh}
                    disabled={syncState === 'syncing'}
                    className="w-full px-3 py-2 text-left text-neutral-200 hover:text-white hover:bg-neutral-800 rounded-lg transition flex items-center justify-between cursor-pointer font-medium disabled:opacity-75"
                    title="Refresh and synchronize workspace data with server"
                  >
                    <div className="flex items-center gap-2.5 min-w-0">
                      <div
                        className={`p-1 rounded-md shrink-0 ${
                          syncState === 'syncing'
                            ? 'bg-amber-500/10 text-amber-400'
                            : syncState === 'online'
                            ? 'bg-emerald-500/10 text-emerald-400'
                            : 'bg-rose-500/10 text-rose-400'
                        }`}
                      >
                        <RefreshCw
                          className={`w-3.5 h-3.5 ${
                            syncState === 'syncing' ? 'animate-spin' : ''
                          }`}
                        />
                      </div>
                      <span>Sync Refresh</span>
                    </div>
                    <div className="flex items-center gap-1.5 shrink-0">
                      <span
                        className={`w-2 h-2 rounded-full shrink-0 ${
                          syncState === 'online'
                            ? 'bg-emerald-500'
                            : syncState === 'syncing'
                            ? 'bg-amber-500 animate-pulse'
                            : 'bg-rose-500'
                        }`}
                      />
                      <span
                        className={`text-[10px] font-semibold capitalize ${
                          syncState === 'online'
                            ? 'text-emerald-400'
                            : syncState === 'syncing'
                            ? 'text-amber-400'
                            : 'text-rose-400'
                        }`}
                      >
                        {syncState === 'syncing' ? 'Syncing...' : syncState}
                      </span>
                    </div>
                  </button>

                  {/* Edit Profile */}
                  <button
                    type="button"
                    id="profile-dropdown-edit-profile"
                    onClick={() => {
                      setIsProfileMenuOpen(false);
                      setIsEditProfileOpen(true);
                    }}
                    className="w-full px-3 py-2 text-left text-neutral-200 hover:text-white hover:bg-neutral-800 rounded-lg transition flex items-center gap-2.5 cursor-pointer font-medium"
                  >
                    <div className="p-1 rounded-md bg-sky-500/10 text-sky-400 shrink-0">
                      <User className="w-3.5 h-3.5" />
                    </div>
                    <span>Edit Profile</span>
                  </button>

                  {/* Change Password */}
                  <button
                    type="button"
                    id="profile-dropdown-change-password"
                    onClick={() => {
                      setIsProfileMenuOpen(false);
                      setIsChangePasswordOpen(true);
                    }}
                    className="w-full px-3 py-2 text-left text-neutral-200 hover:text-white hover:bg-neutral-800 rounded-lg transition flex items-center gap-2.5 cursor-pointer font-medium"
                  >
                    <div className="p-1 rounded-md bg-amber-500/10 text-amber-400 shrink-0">
                      <KeyRound className="w-3.5 h-3.5" />
                    </div>
                    <span>Change Password</span>
                  </button>

                  {/* Theme & Appearance */}
                  <button
                    type="button"
                    id="profile-dropdown-theme-switcher"
                    onClick={() => {
                      setIsProfileMenuOpen(false);
                      openThemeSelector();
                    }}
                    className="w-full px-3 py-2 text-left text-neutral-200 hover:text-white hover:bg-neutral-800 rounded-lg transition flex items-center justify-between cursor-pointer font-medium"
                  >
                    <div className="flex items-center gap-2.5 min-w-0">
                      <div className="p-1 rounded-md bg-orange-500/10 text-orange-400 shrink-0">
                        <Palette className="w-3.5 h-3.5" />
                      </div>
                      <span>Theme</span>
                    </div>
                    <span className="text-[10px] text-orange-400 font-semibold truncate max-w-[90px]">
                      {currentTheme.name}
                    </span>
                  </button>

                  {/* Log Out */}
                  <button
                    type="button"
                    id="profile-dropdown-log-out"
                    onClick={async () => {
                      setIsProfileMenuOpen(false);
                      await signOutUser();
                    }}
                    className="w-full px-3 py-2 text-left text-rose-400 hover:text-rose-300 hover:bg-rose-950/30 rounded-lg transition flex items-center gap-2.5 cursor-pointer font-medium"
                  >
                    <div className="p-1 rounded-md bg-rose-500/10 text-rose-400 shrink-0">
                      <LogOut className="w-3.5 h-3.5" />
                    </div>
                    <span>Log Out</span>
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      </header>

      {/* Profile Modals */}
      {isEditProfileOpen && userProfile && (
        <UserProfileModal
          user={userProfile}
          settings={settings}
          currentAdminId={userProfile.id}
          currentAdminName={userProfile.name || 'User'}
          initialTab="edit"
          onClose={() => setIsEditProfileOpen(false)}
          onProfileUpdated={(updated) => {
            updateCurrentUserProfile(updated);
          }}
        />
      )}

      {isChangePasswordOpen && (
        <ChangePasswordModal
          isVoluntary={true}
          onClose={() => setIsChangePasswordOpen(false)}
        />
      )}
    </>
  );
};



