import React, { useState } from 'react';
import {
  LayoutDashboard,
  FileText,
  Users,
  DollarSign,
  Receipt,
  BarChart3,
  Settings,
  LogOut,
  Shield,
  MessageSquare,
  Sparkles,
  ShieldAlert,
  UserCheck,
  Database,
  ChevronLeft,
  ChevronRight,
  Palette,
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';

export type ActiveTab =
  | 'dashboard'
  | 'invoices'
  | 'customers'
  | 'payments'
  | 'requests'
  | 'projects'
  | 'reports'
  | 'staff'
  | 'audit'
  | 'backup'
  | 'invoice_design'
  | 'settings'
  | 'notifications';

interface SidebarProps {
  activeTab: ActiveTab;
  onTabChange: (tab: ActiveTab) => void;
  onNewInvoice?: () => void;
  isOpenOnMobile: boolean;
  onCloseMobile: () => void;
  logo?: string;
  onSwitchToCustomerPortal?: () => void;
  isCollapsed?: boolean;
  onToggleCollapse?: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  activeTab,
  onTabChange,
  isOpenOnMobile,
  onCloseMobile,
  logo = '/sarwan-logo.png',
  isCollapsed: propIsCollapsed,
  onToggleCollapse: propToggleCollapse,
}) => {
  const { userProfile, signOutUser, permissions } = useAuth();

  const [internalCollapsed, setInternalCollapsed] = useState(() => {
    if (typeof window !== 'undefined') {
      return localStorage.getItem('sarwan_sidebar_collapsed') === 'true';
    }
    return false;
  });

  const isCollapsed = propIsCollapsed !== undefined ? propIsCollapsed : internalCollapsed;

  const handleToggleCollapse = () => {
    if (propToggleCollapse) {
      propToggleCollapse();
    } else {
      setInternalCollapsed((prev) => {
        const next = !prev;
        try {
          localStorage.setItem('sarwan_sidebar_collapsed', String(next));
        } catch {
          // ignore localStorage error
        }
        return next;
      });
    }
  };

  const navItems: { id: ActiveTab; label: string; href: string; icon: React.ReactNode; show: boolean }[] = [
    { id: 'dashboard', label: 'Business Dashboard', href: '/dashboard', icon: <LayoutDashboard className="w-4 h-4" />, show: permissions.canViewDashboard ?? true },
    { id: 'invoices', label: 'Invoices', href: '/invoices', icon: <FileText className="w-4 h-4" />, show: permissions.canViewInvoices },
    { id: 'customers', label: 'Customers', href: '/customers', icon: <Users className="w-4 h-4" />, show: permissions.canViewCustomers },
    { id: 'payments', label: 'Payments', href: '/payments', icon: <DollarSign className="w-4 h-4" />, show: permissions.canViewPayments },
    { id: 'requests', label: 'Customer Requests', href: '/requests', icon: <MessageSquare className="w-4 h-4" />, show: permissions.canManageRequests || permissions.canCreateInvoice },
    { id: 'projects', label: 'Security Showcase', href: '/projects', icon: <Sparkles className="w-4 h-4" />, show: permissions.canManageProjects },
    { id: 'reports', label: 'Financial Reports', href: '/reports', icon: <BarChart3 className="w-4 h-4" />, show: permissions.canViewReports },
    { id: 'staff', label: 'Staff & Roles', href: '/staff', icon: <UserCheck className="w-4 h-4" />, show: permissions.canManageUsers || permissions.canManageStaff },
    { id: 'audit', label: 'Audit Logs', href: '/audit-log', icon: <ShieldAlert className="w-4 h-4" />, show: permissions.canViewAuditLogs },
    { id: 'backup', label: 'Backup & Restore', href: '/backup', icon: <Database className="w-4 h-4" />, show: permissions.canExportBackup },
    { id: 'invoice_design', label: 'Invoice Design', href: '/invoice-design', icon: <Palette className="w-4 h-4" />, show: permissions.canManageSettings },
    { id: 'settings', label: 'Settings', href: '/settings', icon: <Settings className="w-4 h-4" />, show: permissions.canManageSettings },
  ];

  return (
    <>
      {/* Backdrop on mobile */}
      {isOpenOnMobile && (
        <div
          onClick={onCloseMobile}
          className="fixed inset-0 z-40 bg-black/50 lg:hidden backdrop-blur-xs"
        />
      )}

      <aside
        id="app-sidebar"
        data-mobile-open={isOpenOnMobile ? 'true' : 'false'}
        className={`fixed top-0 bottom-0 left-0 z-40 bg-neutral-950 text-neutral-200 border-r border-neutral-800 flex flex-col justify-between transition-all duration-300 ease-in-out lg:translate-x-0 ${
          isOpenOnMobile ? 'translate-x-0 w-64' : '-translate-x-full'
        } ${
          isCollapsed ? 'lg:w-20' : 'lg:w-64'
        }`}
      >
        <div className="overflow-y-auto flex-1 no-scrollbar [scrollbar-width:none] [-ms-overflow-style:none] [&::-webkit-scrollbar]:hidden">
          {/* Brand Header */}
          <div
            className={`border-b border-neutral-800 flex items-center sticky top-0 bg-neutral-950 z-10 transition-all duration-300 ${
              isCollapsed ? 'p-3 flex-col gap-2.5 justify-center' : 'p-4 justify-between gap-3'
            }`}
          >
            <div
              className={`flex items-center gap-3 overflow-hidden ${
                isCollapsed ? 'justify-center w-full' : ''
              }`}
            >
              <div
                className={`${isCollapsed ? 'w-8 h-8' : 'w-10 h-10'} bg-white shrink-0 flex items-center justify-center overflow-hidden p-1 shadow-xs`}
                style={{ borderRadius: '100%', border: 'none' }}
              >
                <img
                  src={logo || '/sarwan-logo.png'}
                  alt="Sarwan Technology"
                  className="max-h-full max-w-full object-contain transition-all"
                  onError={(e) => {
                    const target = e.currentTarget;
                    if (target.src.endsWith('.png')) target.src = '/sarwan-logo.svg';
                  }}
                />
              </div>
              {!isCollapsed && (
                <div className="overflow-hidden">
                  <h1 className="text-sm font-bold text-white tracking-wide truncate">
                    SARWAN TECHNOLOGY
                  </h1>
                  <p className="text-[10px] text-orange-400 font-semibold tracking-wider uppercase">
                    Billing &amp; Business
                  </p>
                </div>
              )}
            </div>

            {/* Desktop Collapse / Expand Button */}
            <button
              id="sidebar-collapse-toggle-btn"
              type="button"
              onClick={handleToggleCollapse}
              className={`hidden lg:flex p-1.5 text-neutral-400 hover:text-white hover:bg-neutral-800 rounded-lg transition shrink-0 cursor-pointer items-center justify-center ${
                isCollapsed ? 'w-full bg-neutral-900 border border-neutral-800 py-1' : ''
              }`}
              title={isCollapsed ? 'Expand Sidebar' : 'Collapse Sidebar'}
              aria-label={isCollapsed ? 'Expand Sidebar' : 'Collapse Sidebar'}
            >
              {isCollapsed ? (
                <ChevronRight className="w-4 h-4 text-orange-400" />
              ) : (
                <ChevronLeft className="w-4 h-4" />
              )}
            </button>
          </div>

          {/* Navigation Links */}
          <nav className="px-2 py-2 space-y-1">
            {navItems
              .filter((item) => item.show)
              .map((item) => {
                const isActive = activeTab === item.id;
                return (
                  <a
                    key={item.id}
                    id={`nav-${item.id}`}
                    href={item.href}
                    title={item.label}
                    onClick={(e) => {
                      e.preventDefault();
                      onTabChange(item.id);
                      if (isOpenOnMobile) onCloseMobile();
                    }}
                    className={`w-full flex items-center text-xs font-semibold rounded-lg transition text-left cursor-pointer no-underline select-none ${
                      isCollapsed ? 'justify-center p-2.5' : 'gap-3 px-3 py-2'
                    } ${
                      isActive
                        ? isCollapsed
                          ? 'bg-neutral-800 text-orange-400 border border-orange-500/50 shadow-xs font-bold'
                          : 'bg-neutral-800 text-orange-400 border-l-2 border-orange-500 font-bold'
                        : 'text-neutral-400 hover:text-white hover:bg-neutral-900'
                    }`}
                  >
                    <span className={`shrink-0 ${isActive ? 'text-orange-400' : 'text-neutral-400'}`}>
                      {item.icon}
                    </span>
                    {!isCollapsed && <span className="truncate">{item.label}</span>}
                  </a>
                );
              })}
          </nav>
        </div>

        {/* User Info & Sign Out Footer */}
        <div
          className={`border-t border-neutral-800 bg-neutral-900/50 transition-all duration-300 ${
            isCollapsed ? 'p-2' : 'p-3'
          }`}
        >
          {isCollapsed ? (
            <div className="flex flex-col items-center gap-2">
              <div
                className="w-8 h-8 rounded-full bg-neutral-800 border border-neutral-700 flex items-center justify-center text-xs font-bold text-orange-400 shrink-0 cursor-default"
                title={`${userProfile?.name || 'Administrator'} (${userProfile?.role?.replace('_', ' ') || 'Admin'})`}
              >
                {userProfile?.name?.charAt(0) || 'A'}
              </div>
              <button
                id="sidebar-signout-btn"
                onClick={signOutUser}
                className="p-2 text-neutral-400 hover:text-white hover:bg-neutral-800 rounded-md transition cursor-pointer"
                title="Sign Out"
                aria-label="Sign Out"
              >
                <LogOut className="w-4 h-4" />
              </button>
            </div>
          ) : (
            <div className="flex items-center justify-between gap-2">
              <div className="flex items-center gap-2 overflow-hidden">
                <div className="w-7 h-7 rounded-full bg-neutral-800 border border-neutral-700 flex items-center justify-center text-xs font-bold text-orange-400 shrink-0">
                  {userProfile?.name?.charAt(0) || 'A'}
                </div>
                <div className="overflow-hidden">
                  <p className="text-xs font-medium text-white truncate">
                    {userProfile?.name || 'Administrator'}
                  </p>
                  <div className="flex items-center gap-1 text-[10px] text-neutral-400">
                    <Shield className="w-2.5 h-2.5 text-orange-400" />
                    <span className="capitalize">{userProfile?.role?.replace('_', ' ') || 'Admin'}</span>
                  </div>
                </div>
              </div>

              <button
                id="sidebar-signout-btn"
                onClick={signOutUser}
                className="p-1.5 text-neutral-400 hover:text-white hover:bg-neutral-800 rounded-md transition cursor-pointer"
                title="Sign Out"
                aria-label="Sign Out"
              >
                <LogOut className="w-4 h-4" />
              </button>
            </div>
          )}
        </div>
      </aside>
    </>
  );
};
