import React from 'react';
import { Loader2 } from 'lucide-react';

export type ButtonVariant =
  | 'primary'
  | 'secondary'
  | 'outline'
  | 'ghost'
  | 'destructive'
  | 'destructive-soft'
  | 'success'
  | 'success-soft';

export type ButtonSize = 'xs' | 'sm' | 'md' | 'lg';

export interface ButtonOptions {
  variant?: ButtonVariant;
  size?: ButtonSize;
  className?: string;
  disabled?: boolean;
  loading?: boolean;
  fullWidth?: boolean;
}

/**
 * Returns standardized Tailwind + CSS classes for the Sarwan Technology Button Design System
 * Primary color: Modern Blue #2563EB
 * Style: Soft, clean, modern, accessible
 */
export function getButtonClasses({
  variant = 'primary',
  size = 'sm',
  className = '',
  disabled = false,
  loading = false,
  fullWidth = false,
}: ButtonOptions = {}): string {
  const base =
    'inline-flex items-center justify-center font-semibold transition select-none outline-none focus:outline-none focus-visible:ring-2 focus-visible:ring-offset-1 cursor-pointer disabled:cursor-not-allowed disabled:pointer-events-none disabled:opacity-50 whitespace-nowrap active:scale-[0.98]';

  const sizeClasses: Record<ButtonSize, string> = {
    xs: 'text-[11px] px-2.5 py-1 gap-1 rounded-md min-h-[28px]',
    sm: 'text-xs px-3 py-1.5 gap-1.5 rounded-lg min-h-[34px]',
    md: 'text-xs sm:text-sm px-4 py-2 gap-2 rounded-lg min-h-[38px]',
    lg: 'text-sm sm:text-base px-5 py-2.5 gap-2.5 rounded-xl min-h-[44px]',
  };

  const variantClasses: Record<ButtonVariant, string> = {
    primary:
      'bg-[var(--color-primary,#2563EB)] hover:bg-[var(--color-primary-hover,#1D4ED8)] active:bg-[var(--color-primary-active,#1E40AF)] text-[var(--color-primary-text,#FFFFFF)] shadow-xs focus-visible:ring-[var(--color-primary,#2563EB)]',
    secondary:
      'bg-[var(--app-bg-muted,#F1F5F9)] hover:bg-[var(--color-interactive-active,#E2E8F0)] active:bg-[var(--app-border-strong,#CBD5E1)] text-[var(--app-text-primary,#0F172A)] border border-[var(--app-border,#E2E8F0)] focus-visible:ring-[var(--color-primary,#2563EB)]',
    outline:
      'bg-[var(--app-surface-card,#FFFFFF)] hover:bg-[var(--color-interactive-hover,#F1F5F9)] active:bg-[var(--color-interactive-active,#E2E8F0)] text-[var(--app-text-primary,#0F172A)] border border-[var(--app-border,#CBD5E1)] hover:border-[var(--app-border-strong,#94A3B8)] shadow-2xs focus-visible:ring-[var(--color-primary,#2563EB)]',
    ghost:
      'bg-transparent hover:bg-[var(--color-interactive-hover,#F1F5F9)] active:bg-[var(--color-interactive-active,#E2E8F0)] text-[var(--app-text-secondary,#475569)] hover:text-[var(--app-text-primary,#0F172A)] focus-visible:ring-[var(--color-primary,#2563EB)]',
    destructive:
      'bg-[var(--color-danger,#DC2626)] hover:brightness-95 active:brightness-90 text-white shadow-xs focus-visible:ring-[var(--color-danger,#DC2626)]',
    'destructive-soft':
      'bg-[var(--color-danger-bg,#FEF2F2)] hover:opacity-90 active:opacity-80 text-[var(--color-danger-text,#991B1B)] border border-[var(--color-danger-border,#FECACA)] focus-visible:ring-[var(--color-danger,#DC2626)]',
    success:
      'bg-[var(--color-success,#16A34A)] hover:brightness-95 active:brightness-90 text-white shadow-xs focus-visible:ring-[var(--color-success,#16A34A)]',
    'success-soft':
      'bg-[var(--color-success-bg,#ECFDF5)] hover:opacity-90 active:opacity-80 text-[var(--color-success-text,#065F46)] border border-[var(--color-success-border,#A7F3D0)] focus-visible:ring-[var(--color-success,#16A34A)]',
  };

  const widthClass = fullWidth ? 'w-full' : '';
  const stateClass = disabled || loading ? 'opacity-50 pointer-events-none transform-none' : '';

  return [base, sizeClasses[size], variantClasses[variant], widthClass, stateClass, className]
    .filter(Boolean)
    .join(' ');
}

export interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: ButtonVariant;
  size?: ButtonSize;
  loading?: boolean;
  icon?: React.ReactNode;
  iconPosition?: 'left' | 'right';
  fullWidth?: boolean;
}

export const Button = React.forwardRef<HTMLButtonElement, ButtonProps>(
  (props, ref) => {
    const {
      children,
      variant = 'primary',
      size = 'sm',
      loading = false,
      disabled = false,
      icon,
      iconPosition = 'left',
      fullWidth = false,
      className = '',
      type = 'button',
      ...rest
    } = props;

    const combinedClasses = getButtonClasses({
      variant: variant as ButtonVariant,
      size: size as ButtonSize,
      className,
      disabled,
      loading,
      fullWidth,
    });

    const isInteractiveDisabled = disabled || loading;

    return (
      <button
        ref={ref}
        type={type}
        disabled={isInteractiveDisabled}
        aria-busy={loading ? 'true' : undefined}
        className={combinedClasses}
        {...rest}
      >
        {loading ? (
          <Loader2 className="w-3.5 h-3.5 animate-spin shrink-0" aria-hidden="true" />
        ) : icon && iconPosition === 'left' ? (
          <span className="shrink-0 flex items-center">{icon}</span>
        ) : null}

        {children && <span>{children}</span>}

        {!loading && icon && iconPosition === 'right' && (
          <span className="shrink-0 flex items-center">{icon}</span>
        )}
      </button>
    );
  }
);

Button.displayName = 'Button';

export interface IconButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: ButtonVariant;
  size?: 'xs' | 'sm' | 'md' | 'lg';
  icon: React.ReactNode;
  'aria-label': string;
}

export const IconButton = React.forwardRef<HTMLButtonElement, IconButtonProps>(
  (
    {
      variant = 'ghost',
      size = 'sm',
      icon,
      className = '',
      disabled = false,
      type = 'button',
      ...rest
    },
    ref
  ) => {
    const sizeClasses = {
      xs: 'p-1 rounded-md min-h-[26px] min-w-[26px]',
      sm: 'p-1.5 rounded-lg min-h-[32px] min-w-[32px]',
      md: 'p-2 rounded-lg min-h-[38px] min-w-[38px]',
      lg: 'p-2.5 rounded-xl min-h-[44px] min-w-[44px]',
    };

    const variantClasses: Record<ButtonVariant, string> = {
      primary:
        'bg-[var(--color-primary,#2563EB)] hover:bg-[var(--color-primary-hover,#1D4ED8)] active:bg-[var(--color-primary-active,#1E40AF)] text-[var(--color-primary-text,#FFFFFF)] shadow-xs focus-visible:ring-[var(--color-primary,#2563EB)]',
      secondary:
        'bg-neutral-100 hover:bg-neutral-200 active:bg-neutral-300 text-neutral-800 border border-neutral-200/90 focus-visible:ring-neutral-400',
      outline:
        'bg-white hover:bg-neutral-50 active:bg-neutral-100 text-neutral-700 hover:text-neutral-900 border border-neutral-300 hover:border-neutral-400 shadow-2xs focus-visible:ring-[#2563EB]',
      ghost:
        'bg-transparent hover:bg-neutral-100 active:bg-neutral-200 text-neutral-600 hover:text-neutral-900 focus-visible:ring-neutral-400',
      destructive:
        'bg-red-600 hover:bg-red-700 active:bg-red-800 text-white shadow-xs focus-visible:ring-red-500',
      'destructive-soft':
        'bg-red-50 hover:bg-red-100 active:bg-red-200 text-red-700 border border-red-200 focus-visible:ring-red-400',
      success:
        'bg-emerald-600 hover:bg-emerald-700 active:bg-emerald-800 text-white shadow-xs focus-visible:ring-emerald-500',
      'success-soft':
        'bg-emerald-50 hover:bg-emerald-100 active:bg-emerald-200 text-emerald-800 border border-emerald-200 focus-visible:ring-emerald-400',
    };

    const classes = [
      'inline-flex items-center justify-center transition select-none outline-none focus:outline-none focus-visible:ring-2 focus-visible:ring-offset-1 cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed active:scale-[0.98]',
      sizeClasses[size],
      variantClasses[variant],
      className,
    ].join(' ');

    return (
      <button ref={ref} type={type} disabled={disabled} className={classes} {...rest}>
        {icon}
      </button>
    );
  }
);

IconButton.displayName = 'IconButton';
