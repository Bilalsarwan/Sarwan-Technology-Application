import React, { useRef, useState } from 'react';
import { Camera, Upload, Trash2, RefreshCw, AlertCircle, Check } from 'lucide-react';

interface ProfilePhotoUploadProps {
  value?: string;
  currentPhotoURL?: string;
  photoURL?: string;
  onChange?: (dataUrl: string) => void;
  onPhotoChange?: (dataUrl: string) => void;
  name?: string;
  className?: string;
  disabled?: boolean;
}

export const ProfilePhotoUpload: React.FC<ProfilePhotoUploadProps> = ({
  value,
  currentPhotoURL,
  photoURL,
  onChange,
  onPhotoChange,
  name = 'Customer',
  className = '',
  disabled = false,
}) => {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [dragOver, setDragOver] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [processing, setProcessing] = useState(false);

  // Normalize active photo value across all naming variants
  const activePhoto = value ?? currentPhotoURL ?? photoURL ?? '';

  // Safe change notifier supporting both onChange and onPhotoChange callbacks
  const notifyChange = (dataUrl: string) => {
    if (typeof onChange === 'function') {
      onChange(dataUrl);
    }
    if (typeof onPhotoChange === 'function') {
      onPhotoChange(dataUrl);
    }
  };

  // Derive fallback initials from name
  const initials = (name || 'C')
    .split(' ')
    .filter(Boolean)
    .slice(0, 2)
    .map((w) => w[0]?.toUpperCase())
    .join('') || 'C';

  const processFile = (file: File) => {
    setError(null);

    // Validate mime type
    if (!file.type.startsWith('image/')) {
      setError('Please upload a valid image file (PNG, JPEG, or WebP).');
      return;
    }

    // Validate size (max 5MB)
    if (file.size > 5 * 1024 * 1024) {
      setError('Image file is too large (max 5MB). Please choose a smaller photo.');
      return;
    }

    setProcessing(true);

    const reader = new FileReader();
    reader.onload = (e) => {
      const img = new window.Image();
      img.onload = () => {
        try {
          // Scale down image to max 280x280 for fast rendering and minimal Firestore payload (<40KB)
          const maxDim = 280;
          let width = img.width;
          let height = img.height;

          if (width > height) {
            if (width > maxDim) {
              height = Math.round((height * maxDim) / width);
              width = maxDim;
            }
          } else {
            if (height > maxDim) {
              width = Math.round((width * maxDim) / height);
              height = maxDim;
            }
          }

          const canvas = document.createElement('canvas');
          canvas.width = width;
          canvas.height = height;
          const ctx = canvas.getContext('2d');

          if (!ctx) {
            throw new Error('Canvas rendering context unavailable');
          }

          ctx.drawImage(img, 0, 0, width, height);
          const compressedDataUrl = canvas.toDataURL('image/jpeg', 0.85);

          notifyChange(compressedDataUrl);
          setError(null);
        } catch (err: any) {
          console.error('Image compression failed:', err);
          setError('Failed to process image. Please try another image.');
        } finally {
          setProcessing(false);
        }
      };

      img.onerror = () => {
        setProcessing(false);
        setError('Failed to load image. File may be corrupted.');
      };

      if (typeof e.target?.result === 'string') {
        img.src = e.target.result;
      }
    };

    reader.onerror = () => {
      setProcessing(false);
      setError('Failed to read file from disk.');
    };

    reader.readAsDataURL(file);
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      processFile(file);
    }
    // Clear input so selecting the same file again works
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setDragOver(false);
    if (disabled) return;
    const file = e.dataTransfer.files?.[0];
    if (file) {
      processFile(file);
    }
  };

  const handleRemove = (e: React.MouseEvent) => {
    e.stopPropagation();
    notifyChange('');
    setError(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  return (
    <div className={`space-y-2 ${className}`}>
      <input
        ref={fileInputRef}
        type="file"
        accept="image/png,image/jpeg,image/webp,image/jpg"
        className="hidden"
        onChange={handleFileChange}
        disabled={disabled || processing}
      />

      <div className="flex items-center gap-4">
        {/* Photo Container */}
        <div
          onClick={() => !disabled && !processing && fileInputRef.current?.click()}
          onDragOver={(e) => {
            e.preventDefault();
            if (!disabled) setDragOver(true);
          }}
          onDragLeave={() => setDragOver(false)}
          onDrop={handleDrop}
          className={`relative w-20 h-20 rounded-full border-2 flex items-center justify-center overflow-hidden transition cursor-pointer select-none shrink-0 ${
            dragOver
              ? 'border-orange-500 bg-orange-50 scale-105'
              : 'border-neutral-200 hover:border-orange-400 bg-neutral-100'
          } ${disabled ? 'opacity-60 cursor-not-allowed' : ''}`}
          title={activePhoto ? 'Click to change photo' : 'Click or drop to upload photo'}
        >
          {activePhoto ? (
            <img
              src={activePhoto}
              alt={name}
              className="w-full h-full object-cover"
              referrerPolicy="no-referrer"
            />
          ) : (
            <div className="flex flex-col items-center justify-center text-neutral-400">
              <span className="text-sm font-bold text-neutral-600">{initials}</span>
              <Camera className="w-4 h-4 text-neutral-400 mt-0.5" />
            </div>
          )}

          {processing && (
            <div className="absolute inset-0 bg-black/50 flex items-center justify-center text-white">
              <RefreshCw className="w-5 h-5 animate-spin" />
            </div>
          )}
        </div>

        {/* Action Controls & Info */}
        <div className="flex-1 min-w-0">
          <div className="flex flex-wrap items-center gap-2">
            <button
              type="button"
              disabled={disabled || processing}
              onClick={() => fileInputRef.current?.click()}
              className="px-3 py-1.5 bg-neutral-100 hover:bg-neutral-200 active:bg-neutral-300 text-neutral-800 text-xs font-semibold rounded-lg transition inline-flex items-center gap-1.5 disabled:opacity-50"
            >
              {activePhoto ? (
                <>
                  <RefreshCw className="w-3.5 h-3.5 text-neutral-600" />
                  Change Photo
                </>
              ) : (
                <>
                  <Upload className="w-3.5 h-3.5 text-neutral-600" />
                  Upload Photo
                </>
              )}
            </button>

            {activePhoto && (
              <button
                type="button"
                disabled={disabled || processing}
                onClick={handleRemove}
                className="px-2.5 py-1.5 text-red-600 hover:bg-red-50 active:bg-red-100 text-xs font-semibold rounded-lg transition inline-flex items-center gap-1 disabled:opacity-50"
                title="Remove photo"
              >
                <Trash2 className="w-3.5 h-3.5" />
                Remove
              </button>
            )}
          </div>

          <p className="text-[11px] text-neutral-400 mt-1">
            PNG, JPG or WebP. Auto-optimized &amp; stored securely.
          </p>
        </div>
      </div>

      {error && (
        <div className="flex items-center gap-1.5 p-2 bg-red-50 border border-red-200 text-red-700 text-xs rounded-lg">
          <AlertCircle className="w-3.5 h-3.5 shrink-0" />
          <span>{error}</span>
        </div>
      )}
    </div>
  );
};

