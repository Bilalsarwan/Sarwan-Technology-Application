import React from 'react';

interface LogoProps {
  className?: string;
  size?: 'sm' | 'md' | 'lg' | 'xl' | 'custom';
  showText?: boolean;
  variant?: 'full' | 'symbol-only';
  alt?: string;
  src?: string;
}

export const Logo: React.FC<LogoProps> = ({
  className = '',
  size = 'md',
  alt = 'Sarwan Technology',
  src = '/sarwan-logo.png',
}) => {
  // Equal width and height presets for perfectly circular container
  const sizeClasses = {
    sm: 'w-8 h-8 p-0.5',
    md: 'w-12 h-12 p-1',
    lg: 'w-16 h-16 p-1.5',
    xl: 'w-24 h-24 p-2',
    custom: '',
  };

  const chosenSizeClass = sizeClasses[size] || sizeClasses.md;

  return (
    <div
      className={`inline-flex items-center justify-center select-none overflow-hidden shrink-0 bg-white ${chosenSizeClass} ${className}`}
      style={{ borderRadius: '100%', border: 'none' }}
    >
      <img
        src={src}
        alt={alt}
        className="max-h-full max-w-full object-contain"
        onError={(e) => {
          const target = e.currentTarget;
          if (target.src.endsWith('.png')) {
            target.src = '/sarwan-logo.svg';
          }
        }}
      />
    </div>
  );
};
