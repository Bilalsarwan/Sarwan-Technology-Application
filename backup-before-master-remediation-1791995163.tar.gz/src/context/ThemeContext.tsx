import React, {
  createContext,
  useContext,
  useState,
  useEffect,
  useMemo,
  useCallback,
  useRef,
} from 'react';
import { ThemeDefinition, ThemeId, ThemeMode } from '../themes/types';
import {
  THEME_CATALOG,
  INITIAL_USER_THEME_FALLBACK,
  getThemeById,
} from '../themes/catalog';
import {
  resolveEffectiveTheme,
  normalizeThemeId,
  ThemeResolutionSource,
} from '../themes/resolveTheme';
import { applyThemeToDOM } from '../themes/applyTheme';
import {
  THEME_STORAGE_KEYS,
  getStoredGlobalDefault,
  setStoredGlobalDefault,
  clearStoredGlobalDefault,
  getStoredUserTheme,
  setStoredUserTheme,
  clearStoredUserTheme,
  getStoredGuestTheme,
  setStoredGuestTheme,
  clearStoredGuestTheme,
  migrateLegacyThemeStorage,
  initEarlyTheme,
} from '../themes/storage';
import { useAuth } from './AuthContext';
import { updateBusinessSettings } from '../services/db';
import { toast } from './ToastContext';
import { BusinessSettings } from '../types';

export interface ThemeContextType {
  currentTheme: ThemeDefinition;
  themeId: ThemeId;
  mode: ThemeMode;
  setMode: (mode: ThemeMode) => Promise<void>;
  toggleMode: () => Promise<void>;
  themeCatalog: ThemeDefinition[];
  setTheme: (id: ThemeId) => Promise<void>;
  globalDefaultTheme: ThemeId;
  setGlobalDefaultTheme: (id: ThemeId) => Promise<void>;
  themeSource: ThemeResolutionSource;
  hasPersonalPreference: boolean;
  clearPersonalPreference: () => Promise<void>;
  revertToGlobalDefault: () => Promise<void>;
  isThemeSelectorOpen: boolean;
  openThemeSelector: () => void;
  closeThemeSelector: () => void;
  resetToBrandTheme: () => Promise<void>;
  previewTheme: (id: ThemeId | null) => void;
  previewThemeId: ThemeId | null;
}

const ThemeContext = createContext<ThemeContextType | undefined>(undefined);

interface ThemeProviderProps {
  children: React.ReactNode;
  settings?: BusinessSettings;
}

export const ThemeProvider: React.FC<ThemeProviderProps> = ({ children, settings }) => {
  const { userProfile, updateCurrentUserProfile, isSuperAdmin } = useAuth();
  const [isThemeSelectorOpen, setIsThemeSelectorOpen] = useState(false);

  const currentUserId = userProfile?.id || null;
  const prevUserIdRef = useRef<string | null>(currentUserId);

  // Local active personal preference override (used for immediate UI update before async DB sync)
  const [personalOverride, setPersonalOverride] = useState<ThemeId | null | undefined>(undefined);
  const [storageTick, setStorageTick] = useState(0);

  // Migrate any legacy un-scoped storage keys safely
  useEffect(() => {
    migrateLegacyThemeStorage(currentUserId);
  }, [currentUserId]);

  // Multi-tab synchronization: sync theme preference when updated in another tab
  useEffect(() => {
    if (typeof window === 'undefined') return;

    const handleStorageChange = (e: StorageEvent) => {
      if (!e.key) return;
      if (
        e.key === THEME_STORAGE_KEYS.GLOBAL_DEFAULT ||
        e.key === THEME_STORAGE_KEYS.GUEST_PREFERENCE ||
        (currentUserId && e.key === `${THEME_STORAGE_KEYS.USER_PREFERENCE_PREFIX}${currentUserId}`)
      ) {
        setPersonalOverride(undefined);
        setStorageTick(tick => tick + 1);
      }
    };

    window.addEventListener('storage', handleStorageChange);
    return () => {
      window.removeEventListener('storage', handleStorageChange);
    };
  }, [currentUserId]);

  // Temporary active preview theme ID (not persisted until user clicks Apply/Save)
  const [previewThemeId, setPreviewThemeId] = useState<ThemeId | null>(null);

  // Pure derivation of globalDefaultTheme without storage mutations during render
  const globalDefaultTheme: ThemeId = useMemo(() => {
    const fromSettings = normalizeThemeId(settings?.defaultTheme);
    if (fromSettings) {
      return fromSettings;
    }
    const fromStorage = getStoredGlobalDefault();
    if (fromStorage) {
      return fromStorage;
    }
    return INITIAL_USER_THEME_FALLBACK;
  }, [settings?.defaultTheme, storageTick]);

  // Synchronize authoritative backend settings into local storage cache in an effect
  useEffect(() => {
    const fromSettings = normalizeThemeId(settings?.defaultTheme);
    if (fromSettings) {
      setStoredGlobalDefault(fromSettings);
    }
  }, [settings?.defaultTheme]);

  // Handle user login / logout transitions
  useEffect(() => {
    if (prevUserIdRef.current !== currentUserId) {
      // User changed (login, logout, or account switch) -> clear in-memory optimistic override
      setPersonalOverride(undefined);
      setPreviewThemeId(null);
      prevUserIdRef.current = currentUserId;
    }
  }, [currentUserId]);

  // Determine effective personal preference candidate
  const effectivePersonalCandidate: ThemeId | null = useMemo(() => {
    // If optimistic override is explicitly set
    if (personalOverride !== undefined) {
      return personalOverride;
    }

    if (currentUserId) {
      // Authenticated User:
      // 1. Check userProfile preference
      const fromProfile = normalizeThemeId(userProfile?.themePreference);
      if (fromProfile) {
        return fromProfile;
      }
      // 2. Check user-scoped localStorage cache
      const fromUserStorage = getStoredUserTheme(currentUserId);
      if (fromUserStorage) {
        return fromUserStorage;
      }
      return null;
    }

    // Guest / Unauthenticated session:
    // Check guest localStorage preference
    const fromGuestStorage = getStoredGuestTheme();
    if (fromGuestStorage) {
      return fromGuestStorage;
    }
    return null;
  }, [personalOverride, currentUserId, userProfile?.themePreference, storageTick]);

  // Centralized resolution following strict precedence:
  // 1. Explicit Personal Preference -> 2. Global Default -> 3. Sarwan Classic Light Fallback
  const resolved = useMemo(() => {
    return resolveEffectiveTheme({
      personalPreference: effectivePersonalCandidate,
      globalDefault: globalDefaultTheme,
      fallback: INITIAL_USER_THEME_FALLBACK,
    });
  }, [effectivePersonalCandidate, globalDefaultTheme]);

  const activeThemeId = resolved.themeId;
  const currentTheme = resolved.theme;

  // Apply CSS variables and data attributes to DOM immediately
  // If previewThemeId is active, apply that; otherwise apply resolved currentTheme
  useEffect(() => {
    if (previewThemeId) {
      const previewDef = getThemeById(previewThemeId);
      applyThemeToDOM(previewDef);
    } else {
      applyThemeToDOM(currentTheme);
    }
  }, [currentTheme, previewThemeId]);

  // Preview theme temporarily without persisting
  const previewTheme = useCallback((rawId: ThemeId | null) => {
    if (rawId === null) {
      setPreviewThemeId(null);
      return;
    }
    const normalized = normalizeThemeId(rawId);
    if (normalized) {
      setPreviewThemeId(normalized);
    }
  }, []);

  // Set user's personal theme and persist
  const setTheme = useCallback(
    async (rawId: ThemeId) => {
      const normalized = normalizeThemeId(rawId);
      if (!normalized) return;

      // Clear any preview
      setPreviewThemeId(null);

      // 1. Instant local update
      setPersonalOverride(normalized);
      applyThemeToDOM(getThemeById(normalized));

      // 2. Persist in scoped storage
      if (currentUserId) {
        setStoredUserTheme(currentUserId, normalized);
      } else {
        setStoredGuestTheme(normalized);
      }

      // 3. Persist in user profile if authenticated
      if (currentUserId && updateCurrentUserProfile) {
        try {
          await updateCurrentUserProfile({ themePreference: normalized });
        } catch (err) {
          console.warn('[ThemeContext] Could not persist theme preference to user profile:', err);
        }
      }
    },
    [currentUserId, updateCurrentUserProfile]
  );

  // Clear personal theme preference (reverting to global default)
  const clearPersonalPreference = useCallback(async () => {
    setPreviewThemeId(null);

    // 1. Instant local update to revert to global default
    setPersonalOverride(null);

    // 2. Clear from scoped storage
    if (currentUserId) {
      clearStoredUserTheme(currentUserId);
    } else {
      clearStoredGuestTheme();
    }

    // 3. Clear from user profile in Firestore
    if (currentUserId && updateCurrentUserProfile) {
      try {
        await updateCurrentUserProfile({ themePreference: '' });
      } catch (err) {
        console.warn('[ThemeContext] Could not clear theme preference in user profile:', err);
      }
    }
  }, [currentUserId, updateCurrentUserProfile]);

  // Set Admin global default theme (Super Admin only) with rollback on backend failure
  const setGlobalDefaultTheme = useCallback(
    async (rawId: ThemeId) => {
      if (!isSuperAdmin) {
        toast.error('Only Super Admin can update the organization default theme');
        return;
      }
      const normalized = normalizeThemeId(rawId);
      if (!normalized) return;

      const previousStored = getStoredGlobalDefault();

      // Optimistic local update
      setStoredGlobalDefault(normalized);
      setStorageTick((tick) => tick + 1);

      try {
        await updateBusinessSettings(
          { defaultTheme: normalized },
          userProfile?.id,
          userProfile?.name || userProfile?.username,
          userProfile?.role || 'super_admin',
          userProfile?.email || userProfile?.authEmail || userProfile?.googleEmail
        );
        toast.success(`Organization default theme updated to ${getThemeById(normalized).name}`);
      } catch (err) {
        console.error('[ThemeContext] Failed to update global default theme:', err);
        // Roll back optimistic cache update on failure
        if (previousStored) {
          setStoredGlobalDefault(previousStored);
        } else {
          clearStoredGlobalDefault();
        }
        setStorageTick((tick) => tick + 1);
        toast.error('Failed to save organization default theme');
        throw err;
      }
    },
    [isSuperAdmin, userProfile]
  );

  const resetToBrandTheme = useCallback(async () => {
    setPreviewThemeId(null);
    await setTheme(INITIAL_USER_THEME_FALLBACK);
  }, [setTheme]);

  const openThemeSelector = useCallback(() => setIsThemeSelectorOpen(true), []);
  const closeThemeSelector = useCallback(() => {
    setPreviewThemeId(null);
    setIsThemeSelectorOpen(false);
  }, []);

  const mode = currentTheme.mode;

  const setMode = useCallback(
    async (newMode: ThemeMode) => {
      await setTheme(newMode === 'dark' ? 'sarwan_dark' : 'sarwan_light');
    },
    [setTheme]
  );

  const toggleMode = useCallback(async () => {
    const nextId: ThemeId = currentTheme.mode === 'dark' ? 'sarwan_light' : 'sarwan_dark';
    await setTheme(nextId);
  }, [currentTheme.mode, setTheme]);

  return (
    <ThemeContext.Provider
      value={{
        currentTheme,
        themeId: activeThemeId,
        mode,
        setMode,
        toggleMode,
        themeCatalog: THEME_CATALOG,
        setTheme,
        globalDefaultTheme,
        setGlobalDefaultTheme,
        themeSource: resolved.source,
        hasPersonalPreference: resolved.hasExplicitPersonalPreference,
        clearPersonalPreference,
        revertToGlobalDefault: clearPersonalPreference,
        isThemeSelectorOpen,
        openThemeSelector,
        closeThemeSelector,
        resetToBrandTheme,
        previewTheme,
        previewThemeId,
      }}
    >
      {children}
    </ThemeContext.Provider>
  );
};

export const useTheme = (): ThemeContextType => {
  const context = useContext(ThemeContext);
  if (!context) {
    throw new Error('useTheme must be used within a ThemeProvider');
  }
  return context;
};

// Export early initializer for index.html / main.tsx
export { initEarlyTheme };
