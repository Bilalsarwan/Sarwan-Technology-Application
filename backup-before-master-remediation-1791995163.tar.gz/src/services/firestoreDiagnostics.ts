/**
 * Lightweight, Development-Only Firestore Diagnostic Instrumentation
 *
 * Requirements:
 * - Disabled in production by default (or when SARWAN_DIAGNOSTICS_ENABLED is not set).
 * - Zero logging of sensitive user or customer data (names, phones, invoices, passwords).
 * - Records operation type, logical collection, query category, returned doc counts,
 *   cache vs server origin, listener lifecycle, and duplicate operation warnings.
 * - Provides exportable summary and in-memory reset.
 */

export type FirestoreOpType =
  | 'getDoc'
  | 'getDocs'
  | 'onSnapshot'
  | 'setDoc'
  | 'addDoc'
  | 'updateDoc'
  | 'deleteDoc'
  | 'runTransaction'
  | 'writeBatch';

export type QueryCategory =
  | 'single_doc'
  | 'bounded'
  | 'unbounded'
  | 'paginated'
  | 'listener';

export interface DiagnosticOperationRecord {
  id: string;
  timestamp: string;
  opType: FirestoreOpType;
  collection: string;
  category: QueryCategory;
  docCount?: number;
  fromCache?: boolean;
  durationMs?: number;
  isDuplicate?: boolean;
  success?: boolean;
  error?: string;
}

export interface DiagnosticsSummary {
  enabled: boolean;
  environment: string;
  totalQueryAttempts: number;
  totalDocumentsReturned: number;
  activeListenersCount: number;
  totalListenersStarted: number;
  totalListenersStopped: number;
  totalSnapshotEvents: number;
  totalCacheEvents: number;
  totalServerEvents: number;
  totalWriteAttempts: number;
  totalWriteSuccesses: number;
  totalWriteFailures: number;
  duplicateWarningsCount: number;
  operationsByCollection: Record<string, { reads: number; writes: number; docsReturned: number; listeners: number }>;
  operationsByType: Record<string, number>;
  recentOperations: DiagnosticOperationRecord[];
}

// In Vite, import.meta.env.DEV is true during `npm run dev` and test environments
const isDevEnvironment =
  typeof process !== 'undefined' && process.env?.NODE_ENV === 'test'
    ? true
    : typeof import.meta !== 'undefined' && Boolean((import.meta as any).env?.DEV);

let diagnosticsEnabled = isDevEnvironment;

// Maximum circular buffer size for recent operations
const MAX_RECENT_OPS = 200;

// State tracking
let opCounter = 0;
let totalQueryAttempts = 0;
let totalDocumentsReturned = 0;
let totalListenersStarted = 0;
let totalListenersStopped = 0;
let totalSnapshotEvents = 0;
let totalCacheEvents = 0;
let totalServerEvents = 0;
let totalWriteAttempts = 0;
let totalWriteSuccesses = 0;
let totalWriteFailures = 0;
let duplicateWarningsCount = 0;

const activeListenersMap = new Map<string, { collection: string; startTime: number }>();
const operationsByCollection: Record<string, { reads: number; writes: number; docsReturned: number; listeners: number }> = {};
const operationsByType: Record<string, number> = {};
const recentOperations: DiagnosticOperationRecord[] = [];

// Debounce tracker for duplicate queries (same opType + collection within 300ms)
const recentOpTimestamps = new Map<string, number>();

function getCollectionStats(col: string) {
  if (!operationsByCollection[col]) {
    operationsByCollection[col] = { reads: 0, writes: 0, docsReturned: 0, listeners: 0 };
  }
  return operationsByCollection[col];
}

function checkDuplicate(opType: FirestoreOpType, collection: string): boolean {
  const key = `${opType}:${collection}`;
  const now = Date.now();
  const lastTime = recentOpTimestamps.get(key);
  recentOpTimestamps.set(key, now);
  if (lastTime && now - lastTime < 300) {
    duplicateWarningsCount++;
    return true;
  }
  return false;
}

function pushRecord(record: DiagnosticOperationRecord) {
  recentOperations.unshift(record);
  if (recentOperations.length > MAX_RECENT_OPS) {
    recentOperations.pop();
  }
}

/**
 * Check if diagnostics is currently active
 */
export function isDiagnosticsEnabled(): boolean {
  return diagnosticsEnabled;
}

/**
 * Manually toggle diagnostics on or off (e.g. for development profiling)
 */
export function setDiagnosticsEnabled(enabled: boolean): void {
  diagnosticsEnabled = enabled;
}

/**
 * Record a read operation (getDoc or getDocs)
 */
export function recordReadAttempt(
  opType: 'getDoc' | 'getDocs',
  collection: string,
  category: QueryCategory,
  durationMs = 0,
  docCount = 0,
  fromCache?: boolean
): void {
  if (!diagnosticsEnabled) return;

  totalQueryAttempts++;
  totalDocumentsReturned += docCount;
  operationsByType[opType] = (operationsByType[opType] || 0) + 1;

  const colStats = getCollectionStats(collection);
  colStats.reads++;
  colStats.docsReturned += docCount;

  if (fromCache === true) {
    totalCacheEvents++;
  } else if (fromCache === false) {
    totalServerEvents++;
  }

  const isDuplicate = checkDuplicate(opType, collection);

  pushRecord({
    id: `op-${++opCounter}`,
    timestamp: new Date().toISOString(),
    opType,
    collection,
    category,
    docCount,
    fromCache,
    durationMs,
    isDuplicate,
    success: true,
  });
}

/**
 * Record start of an onSnapshot listener
 */
export function recordListenerStart(
  collection: string,
  category: QueryCategory = 'listener'
): string {
  if (!diagnosticsEnabled) return '';

  const listenerId = `lis-${++opCounter}`;
  totalListenersStarted++;
  operationsByType['onSnapshot'] = (operationsByType['onSnapshot'] || 0) + 1;

  const colStats = getCollectionStats(collection);
  colStats.listeners++;

  activeListenersMap.set(listenerId, { collection, startTime: Date.now() });

  const isDuplicate = checkDuplicate('onSnapshot', collection);

  pushRecord({
    id: listenerId,
    timestamp: new Date().toISOString(),
    opType: 'onSnapshot',
    collection,
    category,
    isDuplicate,
    success: true,
  });

  return listenerId;
}

/**
 * Record a listener snapshot reception event
 */
export function recordSnapshotEvent(
  listenerId: string,
  collection: string,
  docCount: number,
  fromCache?: boolean
): void {
  if (!diagnosticsEnabled) return;

  totalSnapshotEvents++;
  totalDocumentsReturned += docCount;

  const colStats = getCollectionStats(collection);
  colStats.docsReturned += docCount;

  if (fromCache === true) {
    totalCacheEvents++;
  } else if (fromCache === false) {
    totalServerEvents++;
  }

  pushRecord({
    id: `snap-${++opCounter}`,
    timestamp: new Date().toISOString(),
    opType: 'onSnapshot',
    collection,
    category: 'listener',
    docCount,
    fromCache,
    success: true,
  });
}

/**
 * Record listener unsubscription
 */
export function recordListenerStop(listenerId: string, collection: string): void {
  if (!diagnosticsEnabled) return;

  if (listenerId) {
    activeListenersMap.delete(listenerId);
  }
  totalListenersStopped++;
}

/**
 * Record a write operation attempt
 */
export function recordWriteAttempt(
  opType: 'setDoc' | 'addDoc' | 'updateDoc' | 'deleteDoc' | 'runTransaction' | 'writeBatch',
  collection: string,
  success: boolean,
  durationMs = 0,
  errorMsg?: string
): void {
  if (!diagnosticsEnabled) return;

  totalWriteAttempts++;
  operationsByType[opType] = (operationsByType[opType] || 0) + 1;

  if (success) {
    totalWriteSuccesses++;
  } else {
    totalWriteFailures++;
  }

  const colStats = getCollectionStats(collection);
  colStats.writes++;

  const isDuplicate = checkDuplicate(opType, collection);

  pushRecord({
    id: `wr-${++opCounter}`,
    timestamp: new Date().toISOString(),
    opType,
    collection,
    category: 'single_doc',
    durationMs,
    isDuplicate,
    success,
    error: errorMsg,
  });
}

/**
 * Retrieve current aggregated diagnostics summary
 */
export function getDiagnosticsSummary(): DiagnosticsSummary {
  return {
    enabled: diagnosticsEnabled,
    environment: isDevEnvironment ? 'development' : 'production',
    totalQueryAttempts,
    totalDocumentsReturned,
    activeListenersCount: activeListenersMap.size,
    totalListenersStarted,
    totalListenersStopped,
    totalSnapshotEvents,
    totalCacheEvents,
    totalServerEvents,
    totalWriteAttempts,
    totalWriteSuccesses,
    totalWriteFailures,
    duplicateWarningsCount,
    operationsByCollection: { ...operationsByCollection },
    operationsByType: { ...operationsByType },
    recentOperations: [...recentOperations],
  };
}

/**
 * Reset all diagnostics counters and buffers
 */
export function resetDiagnostics(): void {
  opCounter = 0;
  totalQueryAttempts = 0;
  totalDocumentsReturned = 0;
  totalListenersStarted = 0;
  totalListenersStopped = 0;
  totalSnapshotEvents = 0;
  totalCacheEvents = 0;
  totalServerEvents = 0;
  totalWriteAttempts = 0;
  totalWriteSuccesses = 0;
  totalWriteFailures = 0;
  duplicateWarningsCount = 0;
  activeListenersMap.clear();
  recentOpTimestamps.clear();

  for (const key of Object.keys(operationsByCollection)) {
    delete operationsByCollection[key];
  }
  for (const key of Object.keys(operationsByType)) {
    delete operationsByType[key];
  }
  recentOperations.length = 0;
}

/**
 * Export sanitized diagnostic report as JSON string
 */
export function exportSanitizedReport(): string {
  const summary = getDiagnosticsSummary();
  return JSON.stringify(summary, null, 2);
}

// Bind to window object in browser during dev mode for easy inspection
if (typeof window !== 'undefined' && isDevEnvironment) {
  (window as any).__sarwanFirestoreDiagnostics = {
    getSummary: getDiagnosticsSummary,
    reset: resetDiagnostics,
    exportReport: exportSanitizedReport,
    setEnabled: setDiagnosticsEnabled,
    isEnabled: isDiagnosticsEnabled,
  };
}
