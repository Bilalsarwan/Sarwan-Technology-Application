/**
 * Safely processes user profile photos for persistence.
 * 
 * In this application, profile photos uploaded via ProfilePhotoUpload are client-side resized
 * to max 280x280 and JPEG compressed to ~15KB-25KB data URLs, which are stored directly and
 * reliably within Firestore documents.
 *
 * This function:
 * 1. Returns empty string if no photo is provided.
 * 2. Returns external HTTP/HTTPS URLs directly if provided.
 * 3. Returns compact data URLs directly for Firestore persistence without requiring external
 *    storage bucket infrastructure or incurring retry-limit-exceeded failures.
 */
export async function uploadUserProfilePhoto(_userId: string, dataUrl?: string | null): Promise<string> {
  if (!dataUrl || typeof dataUrl !== 'string' || !dataUrl.trim()) {
    return '';
  }

  const trimmed = dataUrl.trim();

  // If it's already an http/https URL, return directly
  if (trimmed.startsWith('http://') || trimmed.startsWith('https://')) {
    return trimmed;
  }

  // If it's a data URL, return it directly for Firestore storage
  if (trimmed.startsWith('data:')) {
    return trimmed;
  }

  return trimmed;
}

