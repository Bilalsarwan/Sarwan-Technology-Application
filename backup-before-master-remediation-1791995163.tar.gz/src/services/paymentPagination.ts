import {
  collection,
  query,
  where,
  orderBy,
  limit,
  startAfter,
  getDocs,
  getAggregateFromServer,
  sum,
  count,
  QueryDocumentSnapshot,
  DocumentData,
  QueryConstraint,
  documentId,
} from 'firebase/firestore';
import { db } from './firebase';
import {
  recordReadAttempt,
} from './firestoreDiagnostics';
import {
  Payment,
  PaymentDatePreset,
  PaymentStatusFilter,
  PaymentSortField,
  PaymentSortDirection,
} from '../types';

export const DEFAULT_PAYMENTS_PAGE_SIZE = 25;

export interface FetchPaginatedPaymentsOptions {
  pageSize?: number;
  cursor?: QueryDocumentSnapshot<DocumentData> | null;
  search?: string;
  datePreset?: PaymentDatePreset;
  customStartDate?: string;
  customEndDate?: string;
  status?: PaymentStatusFilter;
  method?: string;
  collector?: string;
  minAmount?: number;
  maxAmount?: number;
  sortField?: PaymentSortField;
  sortDirection?: PaymentSortDirection;
  todayStr?: string;
  currentMonthPrefix?: string;
  userRole?: string;
  userId?: string;
}

export interface PaginatedPaymentsResponse {
  payments: Payment[];
  hasMore: boolean;
  nextCursor: QueryDocumentSnapshot<DocumentData> | null;
  cursorSnapshot?: QueryDocumentSnapshot<DocumentData> | null;
  error?: string;
}

export interface PaymentSummaryServerMetrics {
  totalCollectedAmount: number;
  completedPaymentsCount: number;
  todayAmount: number;
  todayPaymentsCount: number;
  thisMonthAmount: number;
  thisMonthPaymentsCount: number;
}

/**
 * Server-Side Paginated Query for Payment Records.
 *
 * Requirements:
 * - Default 25 records per page (retrieves ONLY the required records from database).
 * - Cursor-based pagination using startAfter(...).
 * - Resets cursor when filters or sorting change.
 * - Handles empty pages, failed requests, and missing composite indexes gracefully.
 */
export async function fetchPaginatedPaymentsFromFirestore(
  options: FetchPaginatedPaymentsOptions
): Promise<PaginatedPaymentsResponse> {
  const pageSize = options.pageSize || DEFAULT_PAYMENTS_PAGE_SIZE;
  const constraints: QueryConstraint[] = [];

  // 1. Role-based Authorization: payment collectors can only query their own payments
  if (options.userRole === 'payment_collector' && options.userId) {
    constraints.push(where('recordedBy', '==', options.userId));
  }

  // 2. Status Filter at DB level
  if (options.status === 'reversed') {
    constraints.push(where('isVoid', '==', true));
  }

  // 3. Payment Method Filter at DB level
  if (options.method && options.method !== 'all') {
    constraints.push(where('method', '==', options.method.toUpperCase()));
  }

  // 4. Collector Filter at DB level (for super_admin/invoice_manager)
  if (options.collector && options.collector !== 'all' && options.userRole !== 'payment_collector') {
    constraints.push(where('recordedByName', '==', options.collector));
  }

  // 5. Date Filtering at DB level
  if (options.datePreset === 'today' && options.todayStr) {
    constraints.push(where('date', '==', options.todayStr));
  } else if (options.datePreset === 'this_month' && options.currentMonthPrefix) {
    constraints.push(where('date', '>=', `${options.currentMonthPrefix}-01`));
    constraints.push(where('date', '<=', `${options.currentMonthPrefix}-31`));
  } else if (options.datePreset === 'custom') {
    if (options.customStartDate) {
      constraints.push(where('date', '>=', options.customStartDate));
    }
    if (options.customEndDate) {
      constraints.push(where('date', '<=', options.customEndDate));
    }
  }

  // 6. Sorting
  const sortDirection: PaymentSortDirection = options.sortDirection || 'desc';
  const sortField: PaymentSortField = options.sortField || 'date';

  if (sortField === 'amount') {
    constraints.push(orderBy('amount', sortDirection));
  } else if (sortField === 'customer') {
    constraints.push(orderBy('customerName', sortDirection));
  } else if (sortField === 'invoice') {
    constraints.push(orderBy('billNumber', sortDirection));
  } else {
    // Default: Payment Date Newest First
    constraints.push(orderBy('date', sortDirection));
  }

  // Secondary deterministic tie-breaker on documentId() for stable cursor pagination
  constraints.push(orderBy(documentId(), sortDirection));

  // 7. Cursor handling (startAfter)
  if (options.cursor) {
    constraints.push(startAfter(options.cursor));
  }

  // 8. Limit: Fetch pageSize + 1 to detect whether a next page exists without extra count queries
  constraints.push(limit(pageSize + 1));

  try {
    const paymentsQuery = query(collection(db, 'payments'), ...constraints);
    const startTime = Date.now();
    const snap = await getDocs(paymentsQuery);
    const durationMs = Date.now() - startTime;

    const docs = snap.docs;
    const hasMore = docs.length > pageSize;
    const pageDocs = hasMore ? docs.slice(0, pageSize) : docs;

    recordReadAttempt(
      'getDocs',
      'payments',
      'paginated',
      durationMs,
      pageDocs.length,
      snap.metadata?.fromCache
    );

    const payments: Payment[] = pageDocs.map((docSnap) => ({
      id: docSnap.id,
      ...(docSnap.data() as any),
    }));

    const nextCursor = hasMore ? pageDocs[pageDocs.length - 1] : null;

    return {
      payments,
      hasMore,
      nextCursor,
      cursorSnapshot: pageDocs.length > 0 ? pageDocs[pageDocs.length - 1] : null,
    };
  } catch (err: any) {
    console.warn('Paginated payments Firestore query warning (missing index or network):', err?.message || err);
    // Graceful degradation: return error and empty list so UI can handle smoothly
    return {
      payments: [],
      hasMore: false,
      nextCursor: null,
      cursorSnapshot: null,
      error: err?.message || 'Failed to query paginated payments',
    };
  }
}

/**
 * Server-Side Aggregate Queries for Payment Summary Cards.
 *
 * Requirements:
 * - Summary cards must NOT calculate totals from only the current 25 records.
 * - Computes full dataset totals via server-side aggregation (getAggregateFromServer)
 *   WITHOUT downloading thousands of payment document bodies.
 */
export async function fetchServerPaymentSummaryMetrics(
  todayStr: string,
  monthPrefix: string
): Promise<PaymentSummaryServerMetrics> {
  const paymentsColl = collection(db, 'payments');

  try {
    // 1. Total Collected & Completed Count (Full historical dataset, non-void)
    const totalQuery = query(paymentsColl, where('isVoid', '!=', true));
    const totalSnap = await getAggregateFromServer(totalQuery, {
      totalAmt: sum('amount'),
      totalCount: count(),
    });

    const totalCollectedAmount = Number(totalSnap.data().totalAmt) || 0;
    const completedPaymentsCount = Number(totalSnap.data().totalCount) || 0;

    // 2. Today's Collected & Count
    const todayQuery = query(
      paymentsColl,
      where('date', '==', todayStr),
      where('isVoid', '!=', true)
    );
    const todaySnap = await getAggregateFromServer(todayQuery, {
      todayAmt: sum('amount'),
      todayCount: count(),
    });

    const todayAmount = Number(todaySnap.data().todayAmt) || 0;
    const todayPaymentsCount = Number(todaySnap.data().todayCount) || 0;

    // 3. This Month's Collected & Count
    const monthQuery = query(
      paymentsColl,
      where('date', '>=', `${monthPrefix}-01`),
      where('date', '<=', `${monthPrefix}-31`),
      where('isVoid', '!=', true)
    );
    const monthSnap = await getAggregateFromServer(monthQuery, {
      monthAmt: sum('amount'),
      monthCount: count(),
    });

    const thisMonthAmount = Number(monthSnap.data().monthAmt) || 0;
    const thisMonthPaymentsCount = Number(monthSnap.data().monthCount) || 0;

    return {
      totalCollectedAmount,
      completedPaymentsCount,
      todayAmount,
      todayPaymentsCount,
      thisMonthAmount,
      thisMonthPaymentsCount,
    };
  } catch (err) {
    console.warn('Server aggregate query notice (operating with local/fallback metrics):', err);
    throw err;
  }
}
