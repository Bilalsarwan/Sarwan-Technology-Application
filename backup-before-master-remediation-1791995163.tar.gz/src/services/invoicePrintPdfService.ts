/**
 * invoicePrintPdfService
 * Centralized service for generating and downloading high-resolution PDFs of the Canonical Invoice Document,
 * verifying structural parity with the Invoice Preview, and managing DOM-based PDF rendering.
 */
export {
  isEmbeddedContext,
  downloadInvoicePdf,
  printInvoice,
  prepareInvoicePrintDocument,
  printPreparedInvoice,
  isInvoicePrintReady,
  generateInvoiceFilename,
  waitForImagesReady,
  ensureAllFontsLoaded,
  hasTransformedAncestor,
  forceLayoutAndStabilize,
  isInvoiceActionInProgress,
  resolveCanonicalDocument,
  verifyCanonicalInvoiceDocumentStructure,
} from '../utils/print';

export { downloadElementAsPdf } from '../utils/pdf';

export type {
  InvoicePrintOptions,
  InvoicePrintInput,
  CanonicalInvoiceVerificationReport,
} from '../utils/print';

export type { PdfExportOptions } from '../utils/pdf';
