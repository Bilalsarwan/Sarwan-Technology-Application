import {
  Invoice,
  Payment,
  Customer,
  Expense,
  UserProfile,
  UserPermissions,
  AuditLog,
  CustomerRequest,
  Project,
  AppNotification,
  UserRole,
} from '../types';
import {
  calculateTotalPaidForInvoice,
  calculateRemaining,
  getTodayDateString,
  calculateTotalUsers,
  calculateTotalCustomers,
  calculateTotalInvoices,
  calculateTotalPayments,
  calculateTotalOutstanding,
} from '../utils/format';
import { calculateFinancialPerformance } from '../utils/financialPerformance';
import { getRecentInvoices } from '../utils/recentInvoices';
import { getRecentPayments } from '../utils/recentPayments';

/**
 * Access Principle: Role → Permission → Data Ownership/Assignment → Access
 *
 * This module strictly verifies user role, permissions, and data ownership
 * before returning authorized data payloads for each Dashboard experience.
 */

// Helper to check if a date string falls within the last N days
function isWithinLastDays(dateStr: string | undefined, days: number): boolean {
  if (!dateStr) return false;
  const target = new Date(dateStr);
  if (isNaN(target.getTime())) return false;
  const now = new Date();
  const diffTime = now.getTime() - target.getTime();
  const diffDays = diffTime / (1000 * 3600 * 24);
  return diffDays >= 0 && diffDays <= days;
}

// =========================================================================
// 1. SUPER ADMIN AUTHORIZED DATA
// =========================================================================
export interface SuperAdminDashboardData {
  totalUsersCount: number;
  totalCustomersCount: number;
  totalInvoicesCount: number;
  pendingInvoicesCount: number;
  partialInvoicesCount: number;
  paidInvoicesCount: number;
  totalPaymentsAmount: number;
  totalOutstandingAmount: number;
  dailySummary: {
    sales: number;
    payments: number;
    expenses: number;
    net: number;
    invoicesCount: number;
    paymentsCount: number;
  };
  weeklySummary: {
    sales: number;
    payments: number;
    expenses: number;
    net: number;
  };
  monthlySummary: {
    sales: number;
    payments: number;
    expenses: number;
    net: number;
  };
  pendingExpenses: {
    count: number;
    amount: number;
    items: Expense[];
  };
  approvedExpenses: {
    count: number;
    amount: number;
  };
  recentPayments: Payment[];
  recentInvoices: Invoice[];
  recentActivities: AuditLog[];
  notifications: AppNotification[];
  quickActionsAllowed: {
    canCreateInvoice: boolean;
    canManageCustomers: boolean;
    canCollectPayment: boolean;
    canManageExpenses: boolean;
    canManageStaff: boolean;
    canManageSettings: boolean;
  };
}

export function getSuperAdminDashboardData(
  userProfile: UserProfile,
  permissions: UserPermissions,
  invoices: Invoice[] = [],
  customers: Customer[] = [],
  payments: Payment[] = [],
  expenses: Expense[] = [],
  users: UserProfile[] = [],
  auditLogs: AuditLog[] = [],
  notifications: AppNotification[] = []
): SuperAdminDashboardData {
  const role = (userProfile?.role || '').toLowerCase().trim();
  if (role !== 'super_admin') {
    throw new Error('Access Denied: Super Admin permissions required.');
  }

  const todayStr = getTodayDateString();
  const currentMonthPrefix = todayStr.slice(0, 7);

  // Active / non-void collections
  const activeInvoices = invoices.filter((i) => !i.isVoid);
  const activePayments = payments.filter((p) => !p.isVoid);
  const officialExpenses = expenses.filter(
    (e) => e.status === 'executed'
  );

  // Invoice breakdown
  const pendingInvoices = activeInvoices.filter((i) => i.status === 'Unpaid');
  const partialInvoices = activeInvoices.filter((i) => i.status === 'Partially Paid');
  const paidInvoices = activeInvoices.filter((i) => i.status === 'Paid');

  // Deterministic Organization KPIs based on database business rules
  const totalUsersCount = calculateTotalUsers(users);
  const totalCustomersCount = calculateTotalCustomers(customers);
  const totalInvoicesCount = calculateTotalInvoices(invoices);
  const totalPaymentsAmount = calculateTotalPayments(payments);
  const totalOutstandingAmount = calculateTotalOutstanding(invoices, payments);

  // Robust, audited Financial Performance Overview calculation
  const financialSummaries = calculateFinancialPerformance({
    invoices,
    payments,
    expenses,
  });

  // Expense requests breakdown for Super Admin
  // Strictly expenses awaiting Super Admin action ('pending_admin').
  // Newly submitted collector requests ('pending_manager') must NOT appear in Super Admin's pending queue
  // before mandatory Invoice Manager approval has occurred.
  const pendingExpensesList = expenses.filter(
    (e) => e.status === 'pending_admin'
  );
  const approvedExpensesList = expenses.filter(
    (e) => e.status === 'executed' || (e.status === 'approved' && e.executionStatus === 'executed')
  );

  return {
    totalUsersCount,
    totalCustomersCount,
    totalInvoicesCount,
    pendingInvoicesCount: pendingInvoices.length,
    partialInvoicesCount: partialInvoices.length,
    paidInvoicesCount: paidInvoices.length,
    totalPaymentsAmount,
    totalOutstandingAmount,
    dailySummary: financialSummaries.daily,
    weeklySummary: financialSummaries.weekly,
    monthlySummary: financialSummaries.monthly,
    pendingExpenses: {
      count: pendingExpensesList.length,
      amount: pendingExpensesList.reduce((s, e) => s + (Number(e.amount) || 0), 0),
      items: pendingExpensesList.slice(0, 5),
    },
    approvedExpenses: {
      count: approvedExpensesList.length,
      amount: approvedExpensesList.reduce((s, e) => s + (Number(e.amount) || 0), 0),
    },
    recentPayments: getRecentPayments(payments, invoices, 8),
    recentInvoices: getRecentInvoices(invoices, payments, 8, todayStr).map((r) => r.invoice),
    recentActivities: auditLogs.slice(0, 8),
    notifications: notifications.slice(0, 10),
    quickActionsAllowed: {
      canCreateInvoice: Boolean(permissions.canCreateInvoice),
      canManageCustomers: Boolean(permissions.canManageCustomers),
      canCollectPayment: Boolean(permissions.canCollectPayment),
      canManageExpenses: Boolean(permissions.canManageExpenses),
      canManageStaff: Boolean(permissions.canManageStaff),
      canManageSettings: Boolean(permissions.canManageSettings),
    },
  };
}

// =========================================================================
// 2. INVOICE MANAGER AUTHORIZED DATA
// =========================================================================
export interface InvoiceManagerDashboardData {
  totalCustomersCount: number;
  totalInvoicesCount: number;
  pendingInvoicesCount: number;
  partialInvoicesCount: number;
  paidInvoicesCount: number;
  totalOutstandingAmount: number;
  assignedInvoicesCount: number;
  unassignedInvoicesCount: number;
  recentInvoices: Invoice[];
  relevantPayments: Payment[];
  customerRequests: {
    total: number;
    pendingCount: number;
    items: CustomerRequest[];
  };
  notifications: AppNotification[];
  pendingExpenses?: {
    count: number;
    amount: number;
    items: Expense[];
  };
  quickActionsAllowed: {
    canCreateInvoice: boolean;
    canManageCustomers: boolean;
    canCollectPayment: boolean;
    canManageExpenses: boolean;
    canManageRequests: boolean;
  };
}

export function getInvoiceManagerDashboardData(
  userProfile: UserProfile,
  permissions: UserPermissions,
  invoices: Invoice[] = [],
  customers: Customer[] = [],
  payments: Payment[] = [],
  requests: CustomerRequest[] = [],
  notifications: AppNotification[] = [],
  expenses: Expense[] = []
): InvoiceManagerDashboardData {
  const role = (userProfile?.role || '').toLowerCase().trim();
  if (role !== 'invoice_manager' && role !== 'super_admin') {
    throw new Error('Access Denied: Invoice Manager permissions required.');
  }

  const activeInvoices = invoices.filter((i) => !i.isVoid);
  const activePayments = payments.filter((p) => !p.isVoid);

  const pendingInvoices = activeInvoices.filter((i) => i.status === 'Unpaid');
  const partialInvoices = activeInvoices.filter((i) => i.status === 'Partially Paid');
  const paidInvoices = activeInvoices.filter((i) => i.status === 'Paid');

  const totalOutstandingAmount = calculateTotalOutstanding(invoices, payments);

  // Invoices assigned to collectors vs unassigned
  const assignedInvoices = activeInvoices.filter((i) => Boolean(i.assignedCollectorId));
  const unassignedInvoices = activeInvoices.filter((i) => !i.assignedCollectorId);

  // Active customer requests
  const pendingRequests = requests.filter(
    (r) => r.status === 'New' || r.status === 'In Review' || r.status === 'Quoted'
  );

  // Newly submitted & resubmitted collector requests awaiting manager review
  const managerPendingExpenses = expenses.filter(
    (e) => e.status === 'pending_manager'
  );

  return {
    totalCustomersCount: calculateTotalCustomers(customers),
    totalInvoicesCount: calculateTotalInvoices(invoices),
    pendingInvoicesCount: pendingInvoices.length,
    partialInvoicesCount: partialInvoices.length,
    paidInvoicesCount: paidInvoices.length,
    totalOutstandingAmount,
    assignedInvoicesCount: assignedInvoices.length,
    unassignedInvoicesCount: unassignedInvoices.length,
    recentInvoices: activeInvoices.slice(0, 8),
    relevantPayments: activePayments.slice(0, 8),
    customerRequests: {
      total: requests.length,
      pendingCount: pendingRequests.length,
      items: pendingRequests.slice(0, 6),
    },
    notifications: notifications.slice(0, 8),
    pendingExpenses: {
      count: managerPendingExpenses.length,
      amount: managerPendingExpenses.reduce((s, e) => s + (Number(e.amount) || 0), 0),
      items: managerPendingExpenses.slice(0, 5),
    },
    quickActionsAllowed: {
      canCreateInvoice: Boolean(permissions.canCreateInvoice),
      canManageCustomers: Boolean(permissions.canManageCustomers),
      canCollectPayment: Boolean(permissions.canCollectPayment),
      canManageExpenses: Boolean(permissions.canManageExpenses),
      canManageRequests: Boolean(permissions.canManageRequests),
    },
  };
}

// =========================================================================
// 3. PAYMENT COLLECTOR AUTHORIZED DATA
// =========================================================================
export interface PaymentCollectorDashboardData {
  collectorId: string;
  collectorName: string;
  assignedInvoices: Invoice[];
  pendingCollectionsCount: number;
  partialPaymentsCount: number;
  fullyPaidInvoicesCount: number;
  totalRemainingToCollect: number;
  todayCollectionsAmount: number;
  totalCollectedByCollector: number;
  assignedCustomers: Customer[];
  recentPaymentsByCollector: Payment[];
  notifications: AppNotification[];
  quickActionsAllowed: {
    canCollectPayment: boolean;
    canManageExpenses: boolean; // Expense request permission
  };
}

export function getPaymentCollectorDashboardData(
  userProfile: UserProfile,
  permissions: UserPermissions,
  invoices: Invoice[] = [],
  customers: Customer[] = [],
  payments: Payment[] = [],
  notifications: AppNotification[] = []
): PaymentCollectorDashboardData {
  const role = (userProfile?.role || '').toLowerCase().trim();
  if (role !== 'payment_collector' && role !== 'super_admin') {
    throw new Error('Access Denied: Payment Collector permissions required.');
  }

  const todayStr = getTodayDateString();
  const collectorId = userProfile.id;
  const collectorName = userProfile.name?.toLowerCase() || '';

  // Data Ownership Filter: Only invoices assigned to this collector! Excludes quotations/rejected.
  const assignedInvoices = invoices.filter((inv) => {
    if (inv.isVoid || inv.status === 'Void') return false;
    if (inv.billingState === 'quotation' || inv.billingState === 'rejected') return false;
    const matchId = inv.assignedCollectorId === collectorId;
    const matchName = inv.assignedCollectorName && inv.assignedCollectorName.toLowerCase() === collectorName;
    return matchId || matchName;
  });

  const assignedInvoiceIds = new Set(assignedInvoices.map((i) => i.id));
  const assignedCustomerIds = new Set(assignedInvoices.map((i) => i.customerId).filter(Boolean));

  // Data Ownership Filter: Assigned customers only!
  const assignedCustomers = customers.filter(
    (c) => assignedCustomerIds.has(c.id) || assignedInvoices.some((i) => i.customerSnapshot?.phone === c.phone)
  );

  // Status breakdown of assigned invoices
  const pendingInvoices = assignedInvoices.filter((i) => i.status === 'Unpaid');
  const partialInvoices = assignedInvoices.filter((i) => i.status === 'Partially Paid');
  const paidInvoices = assignedInvoices.filter((i) => i.status === 'Paid');

  // Payments recorded by this collector OR made against assigned invoices
  const collectorPayments = payments.filter((p) => {
    if (p.isVoid) return false;
    const isRecordedBy = p.recordedBy === collectorId;
    const isAssignedInvoice = p.invoiceId && assignedInvoiceIds.has(p.invoiceId);
    return isRecordedBy || isAssignedInvoice;
  });

  // Calculate total remaining for collector's assigned invoices
  const totalAssignedInvoiceAmount = assignedInvoices.reduce(
    (sum, inv) => sum + (Number(inv.totalAmount) || 0),
    0
  );
  const totalAssignedPaid = assignedInvoices.reduce((sum, inv) => {
    return sum + calculateTotalPaidForInvoice(inv.id, payments);
  }, 0);
  const totalRemainingToCollect = Math.max(0, totalAssignedInvoiceAmount - totalAssignedPaid);

  // Today's collections by this collector
  const todayPayments = collectorPayments.filter(
    (p) => p.date === todayStr && (p.recordedBy === collectorId || !p.recordedBy)
  );
  const todayCollectionsAmount = todayPayments.reduce(
    (sum, p) => sum + (Number(p.amount) || 0),
    0
  );

  // Cumulative collections recorded by this collector
  const totalCollectedByCollector = collectorPayments
    .filter((p) => p.recordedBy === collectorId)
    .reduce((sum, p) => sum + (Number(p.amount) || 0), 0);

  return {
    collectorId,
    collectorName: userProfile.name,
    assignedInvoices,
    pendingCollectionsCount: pendingInvoices.length,
    partialPaymentsCount: partialInvoices.length,
    fullyPaidInvoicesCount: paidInvoices.length,
    totalRemainingToCollect,
    todayCollectionsAmount,
    totalCollectedByCollector,
    assignedCustomers,
    recentPaymentsByCollector: collectorPayments.slice(0, 8),
    notifications: notifications.slice(0, 6),
    quickActionsAllowed: {
      canCollectPayment: Boolean(permissions.canCollectPayment),
      canManageExpenses: Boolean(permissions.canManageExpenses || permissions.canCreateExpense || userProfile.role === 'payment_collector'),
    },
  };
}

// =========================================================================
// 4. CUSTOMER AUTHORIZED DATA
// =========================================================================
export interface CustomerDashboardData {
  customerId: string;
  customerName: string;
  myInvoices: Invoice[];
  unpaidInvoicesCount: number;
  partialInvoicesCount: number;
  paidInvoicesCount: number;
  totalInvoicedAmount: number;
  totalPaidAmount: number;
  totalOutstandingAmount: number;
  myPayments: Payment[];
  myRequests: CustomerRequest[];
  notifications: AppNotification[];
  projectsShowcase: Project[];
}

export function getCustomerDashboardData(
  userProfile: UserProfile,
  activeCustomer: Customer | null,
  invoices: Invoice[] = [],
  payments: Payment[] = [],
  requests: CustomerRequest[] = [],
  projects: Project[] = [],
  notifications: AppNotification[] = []
): CustomerDashboardData {
  const role = (userProfile?.role || '').toLowerCase().trim();
  if (role !== 'customer' && role !== 'super_admin') {
    throw new Error('Access Denied: Customer access required.');
  }

  // Resolve Customer identity strictly
  const customerId = userProfile.customerId || activeCustomer?.id || userProfile.id;
  const customerPhone = activeCustomer?.phone || userProfile.phone || '';
  const customerName = activeCustomer?.name || userProfile.name || '';
  const customerEmail = activeCustomer?.email || userProfile.email || '';

  // Data Ownership Filter: strictly this customer's invoices ONLY
  const myInvoices = invoices.filter((inv) => {
    if (inv.isVoid) return false;
    const matchId = inv.customerId === customerId;
    const matchPhone = customerPhone && inv.customerSnapshot?.phone === customerPhone;
    const matchEmail = customerEmail && inv.customerSnapshot?.email === customerEmail;
    const matchName =
      customerName && inv.customerSnapshot?.name?.toLowerCase() === customerName.toLowerCase();
    return matchId || matchPhone || matchEmail || matchName;
  });

  const myInvoiceIds = new Set(myInvoices.map((i) => i.id));

  // Payable confirmed invoices only (quotations & rejected are excluded from financial sales/balances)
  const payableInvoices = myInvoices.filter(
    (i) => !i.isVoid && i.status !== 'Void' && i.billingState !== 'quotation' && i.billingState !== 'rejected'
  );

  // Invoices breakdown (only payable sales)
  const unpaidInvoices = payableInvoices.filter((i) => i.status === 'Unpaid');
  const partialInvoices = payableInvoices.filter((i) => i.status === 'Partially Paid');
  const paidInvoices = payableInvoices.filter((i) => i.status === 'Paid');

  // Strictly this customer's payments ONLY
  const myPayments = payments.filter((p) => {
    if (p.isVoid) return false;
    const matchInvoice = p.invoiceId && myInvoiceIds.has(p.invoiceId);
    const matchCustId = p.customerId === customerId;
    const matchCustName = customerName && p.customerName?.toLowerCase() === customerName.toLowerCase();
    return matchInvoice || matchCustId || matchCustName;
  });

  // Financial totals: Only confirmed payable invoices
  const totalInvoicedAmount = payableInvoices.reduce(
    (sum, inv) => sum + (Number(inv.totalAmount) || 0),
    0
  );
  const totalPaidAmount = myPayments.reduce(
    (sum, p) => sum + (Number(p.amount) || 0),
    0
  );
  const totalOutstandingAmount = Math.max(0, totalInvoicedAmount - totalPaidAmount);

  // Strictly this customer's requests ONLY
  const myRequests = requests.filter((r) => {
    const matchId = r.customerId === customerId;
    const matchPhone = customerPhone && r.customerPhone === customerPhone;
    const matchEmail = customerEmail && r.customerEmail === customerEmail;
    const matchName = customerName && r.customerName?.toLowerCase() === customerName.toLowerCase();
    return matchId || matchPhone || matchEmail || matchName;
  });

  // Strictly customer-targeted notifications
  const myNotifications = notifications.filter((n) => {
    if (n.target === 'customer') {
      return !n.customerId || n.customerId === customerId;
    }
    return false;
  });

  // Published tech projects / surveillance showcase
  const publishedProjects = projects.filter((p) => p.isPublished);

  return {
    customerId,
    customerName,
    myInvoices,
    unpaidInvoicesCount: unpaidInvoices.length,
    partialInvoicesCount: partialInvoices.length,
    paidInvoicesCount: paidInvoices.length,
    totalInvoicedAmount,
    totalPaidAmount,
    totalOutstandingAmount,
    myPayments,
    myRequests,
    notifications: myNotifications.slice(0, 6),
    projectsShowcase: publishedProjects.slice(0, 6),
  };
}

// =========================================================================
// 5. PAYMENT AUTHORIZATION & FILTERING HELPERS (Prompt #6 Master Requirements)
// =========================================================================

/**
 * Filters payments to only those the authenticated user is strictly permitted to see.
 * - Super Admin / Invoice Manager: All authorized payments.
 * - Payment Collector: ONLY payments for invoices assigned to this collector, or recorded by this collector.
 * - Customer: ONLY payments for this customer's account.
 */
export function getAuthorizedPayments(
  userProfile: UserProfile | null | undefined,
  payments: Payment[] = [],
  invoices: Invoice[] = []
): Payment[] {
  if (!userProfile) return [];

  const role = (userProfile.role || '').toLowerCase().trim();

  // Super Admin and Invoice Manager can view all payments
  if (role === 'super_admin' || role === 'invoice_manager') {
    return payments;
  }

  // Payment Collector: Strictly assigned invoices OR recorded by this collector
  if (role === 'payment_collector') {
    const collectorId = userProfile.id;
    const collectorName = userProfile.name?.toLowerCase() || '';

    // Invoices assigned to this collector
    const assignedInvoiceIds = new Set(
      invoices
        .filter((inv) => {
          const matchId = inv.assignedCollectorId === collectorId;
          const matchName =
            inv.assignedCollectorName &&
            inv.assignedCollectorName.toLowerCase() === collectorName;
          return matchId || matchName;
        })
        .map((inv) => inv.id)
    );

    return payments.filter((p) => {
      const isRecordedBy = p.recordedBy === collectorId;
      const isAssigned = p.invoiceId && assignedInvoiceIds.has(p.invoiceId);
      return isRecordedBy || isAssigned;
    });
  }

  // Customer: Strictly this customer's payments
  if (role === 'customer') {
    const customerId = userProfile.customerId || userProfile.id;
    const customerName = userProfile.name?.toLowerCase() || '';

    const customerInvoiceIds = new Set(
      invoices
        .filter(
          (inv) =>
            inv.customerId === customerId ||
            (customerName &&
              inv.customerSnapshot?.name?.toLowerCase() === customerName)
        )
        .map((inv) => inv.id)
    );

    return payments.filter((p) => {
      const matchCustId = p.customerId === customerId;
      const matchInv = p.invoiceId && customerInvoiceIds.has(p.invoiceId);
      const matchCustName =
        customerName && p.customerName?.toLowerCase() === customerName;
      return matchCustId || matchInv || matchCustName;
    });
  }

  return [];
}

/**
 * Returns only invoices that the authenticated user is permitted to collect payments for.
 * - Super Admin / Invoice Manager: All active (non-void) invoices with balance remaining.
 * - Payment Collector: ONLY active invoices assigned to this collector with balance remaining.
 * - Customer: NONE (customers can never record payments).
 */
export function getAuthorizedInvoicesForPayments(
  userProfile: UserProfile | null | undefined,
  invoices: Invoice[] = []
): Invoice[] {
  if (!userProfile) return [];

  const role = (userProfile.role || '').toLowerCase().trim();

  // Customers cannot record payments
  if (role === 'customer') return [];

  const isEligibleInvoice = (inv: Invoice) => {
    if (inv.isVoid || inv.status === 'Void') return false;
    if (inv.billingState === 'quotation' || inv.billingState === 'rejected') return false;
    return true;
  };

  if (role === 'super_admin' || role === 'invoice_manager') {
    return invoices.filter(isEligibleInvoice);
  }

  if (role === 'payment_collector') {
    const collectorId = userProfile.id;
    const collectorName = userProfile.name?.toLowerCase() || '';

    return invoices.filter((inv) => {
      if (!isEligibleInvoice(inv)) return false;
      const matchId = inv.assignedCollectorId === collectorId;
      const matchName =
        inv.assignedCollectorName &&
        inv.assignedCollectorName.toLowerCase() === collectorName;
      return matchId || matchName;
    });
  }

  return [];
}

/**
 * Returns invoices that the authenticated user is authorized to view in the Invoices List.
 * - Super Admin / Invoice Manager: All invoices (full visibility).
 * - Payment Collector: ONLY invoices assigned to this collector (by assignedCollectorId or assignedCollectorName).
 * - Customer: Invoices belonging to customer's account.
 */
export function getAuthorizedInvoices(
  userProfile: UserProfile | null | undefined,
  invoices: Invoice[] = []
): Invoice[] {
  if (!userProfile) return [];
  const role = (userProfile.role || '').toLowerCase().trim();

  // Super Admin and Invoice Manager have full visibility
  if (role === 'super_admin' || role === 'invoice_manager') {
    return invoices;
  }

  // Payment Collector: authorized to see only assigned invoices
  if (role === 'payment_collector') {
    const collectorId = userProfile.id;
    const collectorName = userProfile.name?.toLowerCase() || '';

    return invoices.filter((inv) => {
      const matchId = Boolean(collectorId && inv.assignedCollectorId === collectorId);
      const matchName = Boolean(
        collectorName &&
        inv.assignedCollectorName &&
        inv.assignedCollectorName.toLowerCase() === collectorName
      );
      return matchId || matchName;
    });
  }

  // Customer role
  if (role === 'customer') {
    const customerId = userProfile.id;
    return invoices.filter((inv) => inv.customerId === customerId);
  }

  return [];
}


/**
 * Verifies whether a specific user is authorized to record a cash payment for a given invoice.
 */
export function canUserCollectForInvoice(
  userProfile: UserProfile | null | undefined,
  invoice: Invoice
): boolean {
  if (!userProfile || !invoice) return false;
  if (invoice.isVoid || invoice.status === 'Void') return false;
  if (invoice.billingState === 'quotation' || invoice.billingState === 'rejected') return false;

  const role = (userProfile.role || '').toLowerCase().trim();

  if (role === 'customer') return false;
  if (role === 'super_admin' || role === 'invoice_manager') return true;

  if (role === 'payment_collector') {
    const collectorId = userProfile.id;
    const collectorName = userProfile.name?.toLowerCase() || '';
    const matchId = invoice.assignedCollectorId === collectorId;
    const matchName =
      invoice.assignedCollectorName &&
      invoice.assignedCollectorName.toLowerCase() === collectorName;
    return Boolean(matchId || matchName);
  }

  return false;
}
