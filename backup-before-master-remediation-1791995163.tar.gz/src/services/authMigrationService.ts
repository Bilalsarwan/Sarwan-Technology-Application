/**
 * Sarwan Technology Billing System
 * Trusted Authentication Migration Service (Architecture Specification & Client Protocol)
 * 
 * DESIGN PRINCIPLE:
 * In accordance with Stage 3 Security Mandates:
 * 1. Untrusted browser clients MUST NOT independently create Firebase Authentication users
 *    or modify security-sensitive account mapping documents in Firestore.
 * 2. This service defines:
 *    - The canonical email mapping protocol (`${username}@auth.sarwan.tech`).
 *    - The contract for the trusted backend migration endpoint (Cloud Function / Express server).
 *    - Safe fallback client protocol with zero hardcoded bypasses and strict customer ambiguity protection.
 * 3. Historical application user IDs, customer IDs, and audit records remain 100% immutable.
 */

import { doc, getDoc, collection, query, where, getDocs, limit } from 'firebase/firestore';
import { signInWithEmailAndPassword, UserCredential } from 'firebase/auth';
import { db, auth } from './firebase';
import { UserProfile } from '../types';
import { normalizePhone, isPhoneMatch } from '../utils/customerValidation';

export const CANONICAL_AUTH_DOMAIN = 'auth.sarwan.tech';

/**
 * Derives the canonical internal Firebase Authentication email for a staff or customer username.
 * Guaranteed idempotent, lowercase, and strictly formatted.
 */
export function toCanonicalAuthEmail(username: string): string {
  const sanitized = username.trim().toLowerCase().replace(/[^a-z0-9._-]/g, '_');
  if (!sanitized) {
    throw new Error('Invalid username provided for authentication identity generation.');
  }
  return `${sanitized}@${CANONICAL_AUTH_DOMAIN}`;
}

/**
 * Result of customer lookup during login or migration.
 */
export interface CustomerLookupResult {
  status: 'FOUND' | 'AMBIGUOUS' | 'NOT_FOUND';
  customerId?: string;
  matchedCount?: number;
  error?: string;
}

/**
 * Ambiguity-Safe Customer Resolver:
 * Given a phone number or customer username, safely resolves the unique customer record.
 * If more than one customer matches the normalized phone number, it detects ambiguity
 * and REFUSES to bind or authenticate, protecting tenant data isolation.
 */
export async function resolveCustomerSafely(identifier: string): Promise<CustomerLookupResult> {
  const cleanInput = identifier.trim();
  if (!cleanInput) {
    return { status: 'NOT_FOUND', error: 'Identifier is required.' };
  }

  const customersCol = collection(db, 'customers');

  // 1. Check by customerId / customerCode (exact match)
  const custDocRef = doc(db, 'customers', cleanInput);
  try {
    const custSnap = await getDoc(custDocRef);
    if (custSnap.exists()) {
      return { status: 'FOUND', customerId: custSnap.id, matchedCount: 1 };
    }
  } catch (err) {
    console.warn('Direct customer ID check notice:', err);
  }

  // 2. Check if identifier is a phone number (normalize first)
  const normInput = normalizePhone(cleanInput);
  if (normInput.length >= 7) {
    // Targeted query for customers matching phone or alternatePhone
    try {
      const candidateDocMap = new Map<string, any>();

      // A. Exact phone query
      const snapPhone = await getDocs(query(customersCol, where('phone', '==', cleanInput), limit(5)));
      snapPhone.docs.forEach((d) => candidateDocMap.set(d.id, d.data()));

      // B. Normalized phone query
      if (candidateDocMap.size === 0 && normInput !== cleanInput) {
        const snapNorm = await getDocs(query(customersCol, where('phone', '==', normInput), limit(5)));
        snapNorm.docs.forEach((d) => candidateDocMap.set(d.id, d.data()));
      }

      // C. Alternate phone query
      const snapAlt = await getDocs(query(customersCol, where('alternatePhone', '==', cleanInput), limit(5)));
      snapAlt.docs.forEach((d) => candidateDocMap.set(d.id, d.data()));

      const matches: string[] = [];
      candidateDocMap.forEach((data, docId) => {
        if (
          (data.phone && isPhoneMatch(data.phone, cleanInput)) ||
          (data.alternatePhone && isPhoneMatch(data.alternatePhone, cleanInput))
        ) {
          matches.push(docId);
        }
      });

      if (matches.length === 1) {
        return { status: 'FOUND', customerId: matches[0], matchedCount: 1 };
      }
      if (matches.length > 1) {
        return {
          status: 'AMBIGUOUS',
          matchedCount: matches.length,
          error: `Multiple customer accounts (${matches.length}) share phone number "${cleanInput}". Automatic authentication is blocked for safety. Please contact Sarwan support to disambiguate your record.`,
        };
      }
    } catch (phoneErr) {
      console.warn('Customer phone scan notice:', phoneErr);
    }
  }

  return { status: 'NOT_FOUND', error: 'No matching customer profile found.' };
}

/**
 * Migration Request Interface sent to the trusted migration endpoint.
 */
export interface MigrationRequestPayload {
  username: string;
  passwordAttempt: string;
  clientTimestamp: number;
}

export interface MigrationResponsePayload {
  success: boolean;
  message?: string;
  authEmail?: string;
  authUid?: string;
  alreadyMigrated?: boolean;
}

/**
 * Attempts direct Firebase Authentication sign-in using the canonical internal email format.
 * Returns the credential if successful, or null if the user has not yet been provisioned in Firebase Auth.
 */
export async function attemptDirectFirebaseAuth(
  usernameOrEmail: string,
  pass: string
): Promise<UserCredential | null> {
  const cleanInput = usernameOrEmail.trim().toLowerCase();
  const emailToTry = cleanInput.includes('@')
    ? cleanInput
    : toCanonicalAuthEmail(cleanInput);

  try {
    const cred = await signInWithEmailAndPassword(auth, emailToTry, pass);
    return cred;
  } catch (err: any) {
    // If user-not-found or invalid-credential, returns null to allow fallback evaluation
    if (
      err.code === 'auth/user-not-found' ||
      err.code === 'auth/invalid-credential' ||
      err.code === 'auth/wrong-password' ||
      err.code === 'auth/invalid-email' ||
      err.code === 'auth/operation-not-allowed'
    ) {
      return null;
    }
    // Re-throw critical network or blocking errors
    throw err;
  }
}
