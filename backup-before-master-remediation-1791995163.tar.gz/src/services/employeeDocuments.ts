import { EmployeeDocument } from '../types';
import { saveEmployeeDocument, deleteEmployeeDocument as dbDeleteDoc } from './db';

const MAX_PDF_SIZE_BYTES = 15 * 1024 * 1024; // 15 Megabytes

const DB_NAME = 'SarwanEmployeeDocsCache';
const STORE_NAME = 'documents';

/**
 * Initializes client-side IndexedDB for robust local binary storage of PDF documents up to 15MB.
 */
function openDocIndexedDB(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    if (typeof window === 'undefined' || !window.indexedDB) {
      return reject(new Error('IndexedDB not supported'));
    }
    const request = indexedDB.open(DB_NAME, 1);
    request.onupgradeneeded = (e) => {
      const db = (e.target as IDBOpenDBRequest).result;
      if (!db.objectStoreNames.contains(STORE_NAME)) {
        db.createObjectStore(STORE_NAME, { keyPath: 'id' });
      }
    };
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
}

export async function storePdfInLocalCache(documentId: string, blob: Blob): Promise<void> {
  try {
    const db = await openDocIndexedDB();
    await new Promise<void>((resolve, reject) => {
      const tx = db.transaction(STORE_NAME, 'readwrite');
      const store = tx.objectStore(STORE_NAME);
      const req = store.put({ id: documentId, blob, timestamp: Date.now() });
      req.onsuccess = () => resolve();
      req.onerror = () => reject(req.error);
    });
  } catch (err) {
    console.warn('Notice: Local PDF caching failed:', err);
  }
}

export async function getPdfFromLocalCache(documentId: string): Promise<Blob | null> {
  try {
    const db = await openDocIndexedDB();
    return await new Promise<Blob | null>((resolve) => {
      const tx = db.transaction(STORE_NAME, 'readonly');
      const store = tx.objectStore(STORE_NAME);
      const req = store.get(documentId);
      req.onsuccess = () => {
        if (req.result && req.result.blob) {
          resolve(req.result.blob);
        } else {
          resolve(null);
        }
      };
      req.onerror = () => resolve(null);
    });
  } catch {
    return null;
  }
}

export async function deletePdfFromLocalCache(documentId: string): Promise<void> {
  try {
    const db = await openDocIndexedDB();
    await new Promise<void>((resolve) => {
      const tx = db.transaction(STORE_NAME, 'readwrite');
      const store = tx.objectStore(STORE_NAME);
      const req = store.delete(documentId);
      req.onsuccess = () => resolve();
      req.onerror = () => resolve();
    });
  } catch {
    // Ignore cleanup errors
  }
}

/**
 * Validates that the selected file is strictly a valid PDF file and within the 15MB limit.
 * Rejects images, videos, zip archives, executables, and any non-PDF files.
 */
export function validatePdfFile(file: File): { isValid: boolean; error?: string } {
  if (!file) {
    return { isValid: false, error: 'No file selected.' };
  }

  const name = file.name.toLowerCase();
  const extension = name.substring(name.lastIndexOf('.'));

  if (extension !== '.pdf') {
    return {
      isValid: false,
      error: `Invalid file format "${extension}". Only Adobe PDF (.pdf) documents are accepted. Images, videos, ZIP archives, and executables are strictly prohibited.`,
    };
  }

  // Check MIME type
  if (file.type && file.type !== 'application/pdf') {
    return {
      isValid: false,
      error: 'File MIME type is not application/pdf. Please upload a genuine PDF file.',
    };
  }

  // Check file size (max 15 MB)
  if (file.size > MAX_PDF_SIZE_BYTES) {
    const mb = (file.size / (1024 * 1024)).toFixed(1);
    return {
      isValid: false,
      error: `File size (${mb} MB) exceeds the maximum allowed limit of 15 MB.`,
    };
  }

  return { isValid: true };
}

export function formatFileSize(bytes: number): string {
  if (!bytes || bytes === 0) return '0 B';
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(2)} MB`;
}

/**
 * Uploads a verified employee PDF document.
 * Reads the file, caches in IndexedDB, extracts data URL if small enough, and saves metadata to Firestore.
 */
export async function uploadEmployeePdf(params: {
  userId: string;
  file: File;
  documentName: string;
  uploadedBy: string;
}): Promise<EmployeeDocument> {
  const { isValid, error } = validatePdfFile(params.file);
  if (!isValid || error) {
    throw new Error(error || 'Invalid PDF file.');
  }

  const cleanName = params.documentName.trim() || params.file.name.replace(/\.pdf$/i, '');
  const now = new Date().toISOString();

  // Read file as ArrayBuffer and Data URL
  const arrayBuffer = await params.file.arrayBuffer();
  const blob = new Blob([arrayBuffer], { type: 'application/pdf' });

  // For files <= 800 KB, generate a base64 data URL to store in Firestore for multi-device sync
  let storedDataUrl = '';
  if (params.file.size <= 800 * 1024) {
    storedDataUrl = await new Promise<string>((resolve) => {
      const reader = new FileReader();
      reader.onloadend = () => resolve(reader.result as string);
      reader.onerror = () => resolve('');
      reader.readAsDataURL(blob);
    });
  }

  // Create document in Firestore
  const savedDoc = await saveEmployeeDocument(params.userId, {
    userId: params.userId,
    documentName: cleanName,
    fileName: params.file.name,
    storagePath: `users/${params.userId}/documents/${params.file.name}`,
    downloadURL: storedDataUrl,
    fileType: 'application/pdf',
    fileSize: params.file.size,
    fileSizeFormatted: formatFileSize(params.file.size),
    uploadedBy: params.uploadedBy,
    uploadedAt: now,
  });

  // Store binary Blob in IndexedDB cache using the generated document ID
  await storePdfInLocalCache(savedDoc.id, blob);

  return savedDoc;
}

/**
 * Retrieves a usable Blob URL for viewing or downloading the document.
 */
export async function getDocumentBlobUrl(doc: EmployeeDocument): Promise<string> {
  // Check local IndexedDB cache first
  const cachedBlob = await getPdfFromLocalCache(doc.id);
  if (cachedBlob) {
    return URL.createObjectURL(cachedBlob);
  }

  // Check if dataUrl is stored in downloadURL
  if (doc.downloadURL && doc.downloadURL.startsWith('data:application/pdf')) {
    const res = await fetch(doc.downloadURL);
    const blob = await res.blob();
    // Cache for future instant access
    await storePdfInLocalCache(doc.id, blob);
    return URL.createObjectURL(blob);
  }

  if (doc.downloadURL && doc.downloadURL.startsWith('http')) {
    return doc.downloadURL;
  }

  throw new Error('Document binary content is not available on this device.');
}

/**
 * Downloads the employee PDF with proper file name.
 */
export async function downloadEmployeePdf(doc: EmployeeDocument): Promise<void> {
  const blobUrl = await getDocumentBlobUrl(doc);
  const a = document.createElement('a');
  a.href = blobUrl;
  const fileName = doc.fileName.endsWith('.pdf') ? doc.fileName : `${doc.documentName}.pdf`;
  a.download = fileName;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  // Revoke object URL after brief delay if it was a blob URL
  if (blobUrl.startsWith('blob:')) {
    setTimeout(() => URL.revokeObjectURL(blobUrl), 10000);
  }
}

/**
 * Deletes an employee PDF from both Firestore and local IndexedDB.
 */
export async function deleteEmployeePdf(
  userId: string,
  documentId: string,
  adminId: string = 'system',
  adminName: string = 'Administrator'
): Promise<void> {
  await dbDeleteDoc(userId, documentId, adminId, adminName);
  await deletePdfFromLocalCache(documentId);
}
