/**
 * SARWAN TECHNOLOGY BILLING SYSTEM
 * Test Suite: Responsive Navigation — Desktop Sidebar & Mobile Bottom Navigation
 *
 * Verifies:
 * 1. Desktop Behavior: Sidebar visible, mobile bottom nav hidden, expand/collapse preserved, content aligned.
 * 2. Mobile Behavior: Desktop sidebar hidden, fixed bottom nav displayed with Home, Customers, Invoices, Payments, More.
 * 3. Breakpoint & Non-Simultaneous Display: Strict breakpoint enforcement at lg (1024px) with zero visual overlap.
 * 4. Content Protection & Safe-Area: Content padded so it is not obscured by bottom nav.
 * 5. Theme Integration: Sarwan design tokens properly consumed across navigation elements.
 */

import { readFileSync, existsSync } from 'fs';
import { resolve } from 'path';

interface TestResult {
  suite: string;
  name: string;
  passed: boolean;
  error?: string;
}

const results: TestResult[] = [];

function test(suite: string, name: string, fn: () => void) {
  try {
    fn();
    results.push({ suite, name, passed: true });
  } catch (err: any) {
    results.push({ suite, name, passed: false, error: err?.message || String(err) });
  }
}

function expect(condition: boolean, msg: string) {
  if (!condition) throw new Error(msg);
}

export function runAllResponsiveNavigationTests(): { total: number; passed: number; failed: number } {
  const root = process.cwd();
  const appPath = resolve(root, 'src/App.tsx');
  const sidebarPath = resolve(root, 'src/components/layout/Sidebar.tsx');
  const bottomNavPath = resolve(root, 'src/components/layout/MobileBottomNav.tsx');
  const headerPath = resolve(root, 'src/components/layout/Header.tsx');
  const moreSheetPath = resolve(root, 'src/components/layout/MobileMoreSheet.tsx');
  const cssPath = resolve(root, 'src/index.css');

  expect(existsSync(appPath), 'App.tsx must exist');
  expect(existsSync(sidebarPath), 'Sidebar.tsx must exist');
  expect(existsSync(bottomNavPath), 'MobileBottomNav.tsx must exist');
  expect(existsSync(headerPath), 'Header.tsx must exist');
  expect(existsSync(moreSheetPath), 'MobileMoreSheet.tsx must exist');
  expect(existsSync(cssPath), 'index.css must exist');

  const appContent = readFileSync(appPath, 'utf8');
  const sidebarContent = readFileSync(sidebarPath, 'utf8');
  const bottomNavContent = readFileSync(bottomNavPath, 'utf8');
  const headerContent = readFileSync(headerPath, 'utf8');
  const moreSheetContent = readFileSync(moreSheetPath, 'utf8');
  const cssContent = readFileSync(cssPath, 'utf8');

  // =========================================================================
  // SUITE 1: DESKTOP BEHAVIOR (>= 1024px / lg)
  // =========================================================================
  test('Desktop Navigation', 'Sidebar displays on desktop viewports via lg:translate-x-0 and width toggling', () => {
    expect(
      sidebarContent.includes('lg:translate-x-0'),
      'Sidebar must have lg:translate-x-0 to be positioned on desktop'
    );
    expect(
      sidebarContent.includes("isCollapsed ? 'lg:w-20' : 'lg:w-64'"),
      'Sidebar must support collapsed (lg:w-20) and expanded (lg:w-64) widths'
    );
  });

  test('Desktop Navigation', 'Mobile bottom navigation is completely hidden on desktop viewports', () => {
    expect(
      bottomNavContent.includes('lg:hidden'),
      'MobileBottomNav element must include lg:hidden utility'
    );
    expect(
      cssContent.includes('@media (min-width: 1024px)') &&
      cssContent.includes('#mobile-bottom-nav') &&
      cssContent.includes('display: none !important'),
      'index.css must enforce #mobile-bottom-nav display: none !important on desktop viewports'
    );
  });

  test('Desktop Navigation', 'Sidebar expand/collapse control is present and accessible on desktop', () => {
    expect(
      sidebarContent.includes('id="sidebar-collapse-toggle-btn"'),
      'Sidebar collapse/expand toggle button must exist'
    );
    expect(
      sidebarContent.includes('hidden lg:flex'),
      'Collapse button must be hidden on mobile and visible on desktop (hidden lg:flex)'
    );
  });

  test('Desktop Navigation', 'Main content area padding dynamically adjusts to avoid sidebar overlap', () => {
    expect(
      appContent.includes("isSidebarCollapsed ? 'lg:pl-20' : 'lg:pl-64'"),
      'Main container must apply lg:pl-20 or lg:pl-64 to match sidebar width'
    );
  });

  test('Desktop Navigation', 'Desktop navigation destinations and active-route highlighting are intact', () => {
    const expectedRoutes = ['dashboard', 'invoices', 'customers', 'payments', 'requests', 'projects', 'reports', 'staff', 'audit', 'backup', 'invoice_design', 'settings'];
    for (const routeId of expectedRoutes) {
      expect(
        sidebarContent.includes(`id: '${routeId}'`),
        `Sidebar must define navigation destination '${routeId}'`
      );
    }
    expect(
      sidebarContent.includes('text-orange-400') && sidebarContent.includes('border-orange-500'),
      'Sidebar must apply orange brand highlighting to active route'
    );
  });

  // =========================================================================
  // SUITE 2: MOBILE BEHAVIOR (< 1024px)
  // =========================================================================
  test('Mobile Navigation', 'Desktop sidebar is completely hidden on mobile viewports', () => {
    expect(
      sidebarContent.includes('-translate-x-full'),
      'Sidebar must translate completely offscreen (-translate-x-full) on mobile'
    );
    expect(
      cssContent.includes('@media (max-width: 1023.98px)') &&
      cssContent.includes('#app-sidebar:not([data-mobile-open="true"])') &&
      cssContent.includes('display: none !important'),
      'index.css must enforce #app-sidebar display: none !important on mobile when not open'
    );
  });

  test('Mobile Navigation', 'Redundant mobile hamburger menu in Header is hidden to prevent dual navigation menus', () => {
    expect(
      headerContent.includes('className="hidden p-1.5 rounded-lg') ||
      !headerContent.includes('className="lg:hidden p-1.5 rounded-lg'),
      'Header mobile hamburger button must be hidden so it does not trigger a duplicate mobile drawer over bottom nav'
    );
  });

  test('Mobile Navigation', 'Fixed mobile bottom navigation is rendered with authoritative items', () => {
    expect(
      bottomNavContent.includes('id="mobile-bottom-nav"'),
      'MobileBottomNav element must have id="mobile-bottom-nav"'
    );
    expect(
      bottomNavContent.includes('fixed bottom-0 left-0 right-0 z-40'),
      'MobileBottomNav must be fixed at the bottom with z-40'
    );
    // Required 5 items
    const requiredItems = [
      { id: 'dashboard', label: 'Home' },
      { id: 'customers', label: 'Customers' },
      { id: 'invoices', label: 'Invoices' },
      { id: 'payments', label: 'Payments' },
    ];
    for (const item of requiredItems) {
      expect(
        bottomNavContent.includes(`id: '${item.id}'`) && bottomNavContent.includes(`label: '${item.label}'`),
        `MobileBottomNav must include ${item.label} (${item.id})`
      );
    }
    expect(
      bottomNavContent.includes('id="mobile-nav-more"'),
      'MobileBottomNav must include More button'
    );
  });

  test('Mobile Navigation', 'Active route indicator styling with brand orange dot is preserved', () => {
    expect(
      bottomNavContent.includes('text-[var(--brand-orange,#F7941D)]'),
      'Active item must use brand orange token'
    );
    expect(
      bottomNavContent.includes('bg-[var(--brand-orange,#F7941D)]'),
      'Active item must display bottom orange dot indicator'
    );
  });

  test('Mobile Navigation', 'Mobile More sheet integrates secondary sections smoothly', () => {
    expect(
      bottomNavContent.includes('<MobileMoreSheet'),
      'MobileBottomNav must render MobileMoreSheet'
    );
    const secondarySections = ['requests', 'projects', 'reports', 'staff', 'audit', 'backup', 'invoice_design', 'settings'];
    for (const section of secondarySections) {
      expect(
        moreSheetContent.includes(`id: '${section}'`),
        `MobileMoreSheet must provide access to '${section}'`
      );
    }
  });

  // =========================================================================
  // SUITE 3: CONTENT SPACING & SAFE-AREA PROTECTION
  // =========================================================================
  test('Content Protection', 'Page content has adequate bottom spacing on mobile so it is not obscured by bottom nav', () => {
    expect(
      appContent.includes('pb-24 lg:pb-6'),
      'Main container must apply pb-24 on mobile and lg:pb-6 on desktop'
    );
  });

  test('Content Protection', 'Mobile bottom nav supports iOS safe-area-inset-bottom spacing', () => {
    expect(
      bottomNavContent.includes('pb-[env(safe-area-inset-bottom)]'),
      'Mobile bottom nav must incorporate safe-area-inset-bottom for notched mobile displays'
    );
  });

  // =========================================================================
  // SUITE 4: RESPONSIVE BREAKPOINT & ZERO SIMULTANEOUS VISIBILITY
  // =========================================================================
  test('Responsive Breakpoint', 'Breakpoint lg (1024px) is universally utilized across layout components', () => {
    expect(
      sidebarContent.includes('lg:'),
      'Sidebar must use lg breakpoint'
    );
    expect(
      bottomNavContent.includes('lg:hidden'),
      'Bottom nav must use lg:hidden breakpoint'
    );
    expect(
      appContent.includes('lg:pl-'),
      'App layout must use lg breakpoint for content padding'
    );
  });

  test('Zero Simultaneous Display', 'App.tsx guards bottom navigation when mobile menu is active', () => {
    expect(
      appContent.includes('!isMobileMenuOpen && (') ||
      appContent.includes('!isMobileMenuOpen &&'),
      'App.tsx must guarantee MobileBottomNav and mobile menu drawer never appear simultaneously'
    );
  });

  // =========================================================================
  // SUITE 5: THEME INTEGRATION (SARWAN LIGHT & DARK)
  // =========================================================================
  test('Theme Integration', 'Mobile bottom navigation consumes semantic theme tokens', () => {
    expect(
      bottomNavContent.includes('var(--app-surface-header,'),
      'MobileBottomNav must consume --app-surface-header token'
    );
    expect(
      bottomNavContent.includes('var(--app-border,'),
      'MobileBottomNav must consume --app-border token'
    );
    expect(
      bottomNavContent.includes('var(--app-text-muted,'),
      'MobileBottomNav must consume --app-text-muted token'
    );
  });

  test('Theme Integration', 'Mobile More sheet consumes modal surface and text tokens', () => {
    expect(
      moreSheetContent.includes('var(--app-surface-modal,'),
      'MobileMoreSheet must consume --app-surface-modal token'
    );
    expect(
      moreSheetContent.includes('var(--app-text-primary,'),
      'MobileMoreSheet must consume --app-text-primary token'
    );
  });

  // =========================================================================
  // REPORTING
  // =========================================================================
  const suites = Array.from(new Set(results.map((r) => r.suite)));
  console.log('===============================================================');
  console.log('       RESPONSIVE NAVIGATION VERIFICATION RESULTS              ');
  console.log('===============================================================');

  let totalPassed = 0;
  let totalFailed = 0;

  for (const s of suites) {
    const suiteResults = results.filter((r) => r.suite === s);
    const suitePassed = suiteResults.filter((r) => r.passed).length;
    const suiteTotal = suiteResults.length;
    const allPassed = suitePassed === suiteTotal;

    console.log(`[${allPassed ? '✓ PASS' : '✗ FAIL'}] ${s} (${suitePassed}/${suiteTotal} passed)`);
    for (const r of suiteResults) {
      if (r.passed) {
        console.log(`  ✓ ${r.name}`);
        totalPassed++;
      } else {
        console.log(`  ✗ ${r.name}: ${r.error}`);
        totalFailed++;
      }
    }
  }

  console.log('---------------------------------------------------------------');
  console.log(`TOTAL: ${totalPassed}/${results.length} Tests Passed`);
  console.log(`OVERALL STATUS: ${totalFailed === 0 ? 'ALL TESTS PASSED' : 'SOME TESTS FAILED'}`);
  console.log('===============================================================');

  return { total: results.length, passed: totalPassed, failed: totalFailed };
}

if (import.meta.url === `file://${process.argv[1]}`) {
  const summary = runAllResponsiveNavigationTests();
  process.exit(summary.failed === 0 ? 0 : 1);
}
