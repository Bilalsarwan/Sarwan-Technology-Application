import React from 'react';
import {
  Clock,
  CheckCircle2,
  Check,
  XCircle,
  RotateCcw,
  Send,
} from 'lucide-react';
import { Expense, ExpenseStatus } from '../types';

/**
 * The 8 authoritative user-facing expense status labels for the Sarwan Technology Billing System.
 */
export type UserFacingExpenseStatus =
  | 'Requested'
  | 'Pending Manager Approval'
  | 'Approved by Manager'
  | 'Pending Super Admin Approval'
  | 'Rejected'
  | 'Approved'
  | 'Resubmitted'
  | 'Executed / Disbursed';

export type ExpenseSemanticColorType = 'blue' | 'green' | 'red';

/**
 * Exact semantic colors required by the Sarwan Technology Design System:
 * - Requested: blue #2563EB
 * - Pending Manager Approval: blue #2563EB
 * - Approved by Manager: green #16A34A (with clear indication Super Admin approval is still required)
 * - Pending Super Admin Approval: blue #2563EB
 * - Rejected: red #DC2626
 * - Approved: green #16A34A
 * - Resubmitted: blue #2563EB
 * - Executed / Disbursed: green #16A34A
 */
export const EXPENSE_STATUS_HEX_COLORS: Record<UserFacingExpenseStatus, string> = {
  'Requested': '#2563EB',
  'Pending Manager Approval': '#2563EB',
  'Approved by Manager': '#16A34A',
  'Pending Super Admin Approval': '#2563EB',
  'Rejected': '#DC2626',
  'Approved': '#16A34A',
  'Resubmitted': '#2563EB',
  'Executed / Disbursed': '#16A34A',
};

export interface ExpenseStatusInfo {
  status: UserFacingExpenseStatus;
  label: UserFacingExpenseStatus;
  color: string; // Exact HEX color #2563EB, #16A34A, #DC2626
  semanticType: ExpenseSemanticColorType;
  requiresSuperAdminNotice: boolean; // True for 'Approved by Manager'
  superAdminNoticeText?: string;
  badgeBg: string;
  badgeText: string;
  badgeBorder: string;
  isIntermediateApproval: boolean;
  isFinalApproved: boolean;
  isExecuted: boolean;
  isRejected: boolean;
  isResubmitted: boolean;
  rejectionReason?: string;
}

/**
 * Authoritatively determines the user-facing status information from an Expense record.
 * 
 * Rules:
 * 1. Executed / Disbursed: exp.status === 'executed' or exp.executionStatus === 'executed' -> green #16A34A
 * 2. Approved: exp.status === 'approved' -> green #16A34A (only when all required approvals are complete)
 * 3. Rejected: exp.status === 'rejected' -> red #DC2626
 * 4. Collector Request waiting for Super Admin (Manager already approved):
 *    exp.requestedByRole === 'payment_collector' && exp.status === 'pending_admin' && exp.managerApprovedBy
 *    -> 'Approved by Manager' (green #16A34A, with clear indication that Super Admin approval is still required)
 * 5. Invoice Manager Request (or direct admin queue):
 *    exp.status === 'pending_admin' -> 'Pending Super Admin Approval' (blue #2563EB)
 *    (No fictitious manager approval stage for Invoice Manager requests!)
 * 6. Collector Request waiting for Manager:
 *    exp.status === 'pending_manager' -> 'Pending Manager Approval' (blue #2563EB)
 * 7. Resubmitted request:
 *    exp.status === 'resubmitted' or (preferResubmitted && exp.resubmittedAt) -> 'Resubmitted' (blue #2563EB)
 * 8. Requested:
 *    exp.status === 'draft' or 'requested' -> 'Requested' (blue #2563EB)
 */
export function getExpenseStatusInfo(
  expense: Partial<Expense> | ExpenseStatus | string | null | undefined,
  options?: {
    preferResubmitted?: boolean;
    forSuperAdminQueue?: boolean;
  }
): ExpenseStatusInfo {
  if (!expense) {
    return createStatusInfo('Requested');
  }

  // Handle bare string status
  if (typeof expense === 'string') {
    switch (expense) {
      case 'executed':
        return createStatusInfo('Executed / Disbursed');
      case 'approved':
        return createStatusInfo('Approved');
      case 'rejected':
        return createStatusInfo('Rejected');
      case 'pending_admin':
        return createStatusInfo('Pending Super Admin Approval');
      case 'pending_manager':
        return createStatusInfo('Pending Manager Approval');
      case 'resubmitted':
        return createStatusInfo('Resubmitted');
      case 'draft':
      case 'requested':
      default:
        return createStatusInfo('Requested');
    }
  }

  const exp = expense as Partial<Expense>;
  const rawStatus = exp.status;

  // 1. Executed / Disbursed
  if (rawStatus === 'executed' || exp.executionStatus === 'executed') {
    return createStatusInfo('Executed / Disbursed', { isExecuted: true });
  }

  // 2. Approved (all required approvals complete)
  if (rawStatus === 'approved') {
    return createStatusInfo('Approved', { isFinalApproved: true });
  }

  // 3. Rejected
  if (rawStatus === 'rejected') {
    return createStatusInfo('Rejected', {
      isRejected: true,
      rejectionReason: exp.rejectionReason,
    });
  }

  // Check if resubmitted
  const hasResubmission = Boolean(
    (rawStatus as string) === 'resubmitted' ||
    exp.resubmittedAt ||
    exp.resubmissionCorrections ||
    (exp.revision && exp.revision > 1)
  );

  if (options?.preferResubmitted && hasResubmission && (rawStatus === 'pending_manager' || rawStatus === 'pending_admin')) {
    return createStatusInfo('Resubmitted', { isResubmitted: true });
  }

  if ((rawStatus as string) === 'resubmitted') {
    return createStatusInfo('Resubmitted', { isResubmitted: true });
  }

  // 4 & 5. Pending Admin review
  if (rawStatus === 'pending_admin') {
    const isCollector = exp.requestedByRole === 'payment_collector';
    const hasManagerApproved = Boolean(exp.managerApprovedBy || exp.managerApprovedAt);

    // For Payment Collector requests approved by Manager:
    // User-facing label: 'Approved by Manager' (green #16A34A) with clear indication Super Admin approval is required!
    if (isCollector && hasManagerApproved && !options?.forSuperAdminQueue) {
      return createStatusInfo('Approved by Manager', {
        requiresSuperAdminNotice: true,
        superAdminNoticeText: 'Awaiting Super Admin Approval',
        isIntermediateApproval: true,
        isResubmitted: hasResubmission,
      });
    }

    // Invoice Manager's own request: Submitted -> Pending Super Admin Approval -> Approved
    // (No fictitious manager approval stage!)
    return createStatusInfo('Pending Super Admin Approval', {
      isIntermediateApproval: false,
      isResubmitted: hasResubmission,
    });
  }

  // 6. Pending Manager review
  if (rawStatus === 'pending_manager') {
    return createStatusInfo('Pending Manager Approval', {
      isResubmitted: hasResubmission,
    });
  }

  // 7. Draft / Initial submission
  return createStatusInfo('Requested');
}

function createStatusInfo(
  status: UserFacingExpenseStatus,
  overrides?: Partial<ExpenseStatusInfo>
): ExpenseStatusInfo {
  const color = EXPENSE_STATUS_HEX_COLORS[status];
  let semanticType: ExpenseSemanticColorType = 'blue';
  let badgeBg = 'bg-blue-50 dark:bg-blue-950/40';
  let badgeText = 'text-blue-700 dark:text-blue-300';
  let badgeBorder = 'border-blue-200 dark:border-blue-800';

  if (status === 'Approved' || status === 'Executed / Disbursed' || status === 'Approved by Manager') {
    semanticType = 'green';
    badgeBg = 'bg-emerald-50 dark:bg-emerald-950/40';
    badgeText = 'text-emerald-700 dark:text-emerald-300';
    badgeBorder = 'border-emerald-200 dark:border-emerald-800';
  } else if (status === 'Rejected') {
    semanticType = 'red';
    badgeBg = 'bg-rose-50 dark:bg-rose-950/40';
    badgeText = 'text-rose-700 dark:text-rose-300';
    badgeBorder = 'border-rose-200 dark:border-rose-800';
  }

  return {
    status,
    label: status,
    color,
    semanticType,
    requiresSuperAdminNotice: status === 'Approved by Manager',
    superAdminNoticeText: status === 'Approved by Manager' ? 'Awaiting Super Admin Approval' : undefined,
    badgeBg,
    badgeText,
    badgeBorder,
    isIntermediateApproval: status === 'Approved by Manager',
    isFinalApproved: status === 'Approved',
    isExecuted: status === 'Executed / Disbursed',
    isRejected: status === 'Rejected',
    isResubmitted: status === 'Resubmitted' || Boolean(overrides?.isResubmitted),
    ...overrides,
  };
}

/**
 * Returns the status for the original requester's view of their own expense.
 * Guarantees that intermediate approval never appears as final approval.
 */
export function getRequesterExpenseStatus(expense: Partial<Expense>): ExpenseStatusInfo {
  return getExpenseStatusInfo(expense);
}

/**
 * Verifies whether an expense is fully approved across all mandatory stages.
 * Intermediate manager approval ALONE strictly returns false.
 */
export function isExpenseFullyApproved(expense: Partial<Expense> | null | undefined): boolean {
  if (!expense) return false;
  return expense.status === 'approved' || expense.status === 'executed';
}

/**
 * Checks if an expense is awaiting Super Admin approval.
 * Excludes newly submitted collector requests awaiting manager.
 * Excludes rejected, approved, or executed expenses.
 */
export function isPendingSuperAdminApproval(expense: Partial<Expense> | null | undefined): boolean {
  if (!expense) return false;
  return expense.status === 'pending_admin';
}

/**
 * Checks if an expense is awaiting Invoice Manager approval.
 * Excludes admin-stage expenses, approved, executed, and rejected expenses.
 */
export function isPendingManagerApproval(expense: Partial<Expense> | null | undefined): boolean {
  if (!expense) return false;
  return expense.status === 'pending_manager';
}

/**
 * Checks if an expense is in rejected status.
 */
export function isExpenseRejected(expense: Partial<Expense> | null | undefined): boolean {
  if (!expense) return false;
  return expense.status === 'rejected';
}

/**
 * Checks if an expense has reached full approval but is not yet executed/disbursed.
 */
export function isExpenseApproved(expense: Partial<Expense> | null | undefined): boolean {
  if (!expense) return false;
  return expense.status === 'approved';
}

/**
 * Checks if an expense has been officially executed and disbursed.
 */
export function isExpenseExecuted(expense: Partial<Expense> | null | undefined): boolean {
  if (!expense) return false;
  return expense.status === 'executed' || expense.executionStatus === 'executed';
}

/**
 * Checks if an expense represents a revised resubmission.
 */
export function isExpenseResubmitted(expense: Partial<Expense> | null | undefined): boolean {
  if (!expense) return false;
  return Boolean(
    (expense.status as string) === 'resubmitted' ||
    expense.resubmittedAt ||
    expense.resubmissionCorrections ||
    (expense.revision && expense.revision > 1)
  );
}

/**
 * Standardized Expense Status Badge Component with exact semantic colors and icons.
 */
export interface ExpenseStatusBadgeProps {
  expense: Partial<Expense> | ExpenseStatus | string;
  showIcon?: boolean;
  size?: 'sm' | 'md';
  preferResubmitted?: boolean;
  forSuperAdminQueue?: boolean;
  className?: string;
}

export const ExpenseStatusBadge: React.FC<ExpenseStatusBadgeProps> = ({
  expense,
  showIcon = true,
  size = 'sm',
  preferResubmitted = false,
  forSuperAdminQueue = false,
  className = '',
}) => {
  const info = getExpenseStatusInfo(expense, { preferResubmitted, forSuperAdminQueue });

  const getIcon = () => {
    switch (info.status) {
      case 'Executed / Disbursed':
        return <CheckCircle2 className="w-3 h-3 text-emerald-600 dark:text-emerald-400 shrink-0" />;
      case 'Approved':
        return <Check className="w-3 h-3 text-emerald-600 dark:text-emerald-400 shrink-0" />;
      case 'Approved by Manager':
        return <Check className="w-3 h-3 text-emerald-600 dark:text-emerald-400 shrink-0" />;
      case 'Rejected':
        return <XCircle className="w-3 h-3 text-rose-600 dark:text-rose-400 shrink-0" />;
      case 'Resubmitted':
        return <RotateCcw className="w-3 h-3 text-blue-600 dark:text-blue-400 shrink-0" />;
      case 'Pending Super Admin Approval':
      case 'Pending Manager Approval':
        return <Clock className="w-3 h-3 text-blue-600 dark:text-blue-400 shrink-0" />;
      case 'Requested':
      default:
        return <Send className="w-3 h-3 text-blue-600 dark:text-blue-400 shrink-0" />;
    }
  };

  const textClasses = size === 'sm' ? 'text-[10px] py-0.5 px-2' : 'text-xs py-1 px-2.5';

  return (
    <div className={`inline-flex flex-col items-start gap-1 ${className}`}>
      <span
        className={`inline-flex items-center gap-1 rounded-full font-bold border transition ${textClasses} ${info.badgeBg} ${info.badgeText} ${info.badgeBorder}`}
        title={`Expense Status: ${info.label}`}
      >
        {showIcon && getIcon()}
        <span>{info.label}</span>
      </span>

      {/* Clear intermediate notice for Manager Approval */}
      {info.requiresSuperAdminNotice && (
        <span
          className="inline-flex items-center gap-1 text-[9px] font-semibold text-blue-700 dark:text-blue-300 bg-blue-50 dark:bg-blue-950/40 border border-blue-200 dark:border-blue-800 rounded px-1.5 py-0.5"
          title="Super Admin approval is still required before disbursement"
        >
          <Clock className="w-2.5 h-2.5 text-blue-600 dark:text-blue-400 shrink-0" />
          <span>Super Admin approval required</span>
        </span>
      )}
    </div>
  );
};
