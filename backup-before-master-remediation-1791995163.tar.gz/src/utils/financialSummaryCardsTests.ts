/**
 * Verification Test Suite for Professional Financial Summary Cards on the Main Payments Page
 * 
 * Requirements tested:
 * 1. 4 Professional Financial Summary Cards:
 *    - Total Collected (completed payment records, click filters list)
 *    - Today (collected today, click filters list to today only)
 *    - This Month (collected during current month, click filters to current month only)
 *    - Outstanding (total remaining balance of not fully paid invoices, click filters to outstanding)
 * 2. Genuine Interaction:
 *    - Clicking card applies filter
 *    - Selected card has clear active/selected visual state
 *    - Clear / All control restores all records
 * 3. Data Accuracy:
 *    - Uses live data, no hardcoded values, currency formatting in Afghan Afghani (AFN)
 * 4. Responsive Layout:
 *    - Balanced horizontal layout on desktop, responsive wrapping on tablet/mobile
 * 5. Preservation:
 *    - Payments Header & Record Payment button remain intact
 */
import React from 'react';
import { renderToStaticMarkup } from 'react-dom/server';
import { PaymentsView } from '../views/PaymentsView';
import { AuthContext } from '../context/AuthContext';
import { UserProfile, UserPermissions, BusinessSettings, Payment, Invoice } from '../types';
import { getTodayDateString, formatAFN } from './format';
import { calculateAuthoritativeTotalOutstanding } from './invoiceCalculator';

interface TestResult {
  name: string;
  passed: boolean;
  error?: string;
}

const results: TestResult[] = [];

function test(name: string, fn: () => void) {
  try {
    fn();
    results.push({ name, passed: true });
  } catch (err: any) {
    results.push({ name, passed: false, error: err?.message || String(err) });
  }
}

function expect(condition: boolean, msg: string) {
  if (!condition) throw new Error(msg);
}

const mockSettings: BusinessSettings = {
  companyName: 'Sarwan Technology',
  phone: '0731339014',
  whatsapp: '0778771020',
  email: 'info@sarwan.af',
  address: 'Kabul, Afghanistan',
  currency: 'AFN',
  invoiceNote: 'Thank you for your business.',
} as BusinessSettings;

const mockPermissions: UserPermissions = {
  canViewDashboard: true,
  canViewInvoices: true,
  canCreateInvoice: true,
  canEditInvoice: true,
  canVoidInvoice: true,
  canViewPayments: true,
  canCollectPayment: true,
  canReversePayment: true,
  canViewCustomers: true,
  canManageCustomers: true,
  canViewExpenses: true,
  canManageExpenses: true,
  canViewReports: true,
  canExportReports: true,
  canManageSettings: true,
  canManageStaff: true,
  canManageUsers: true,
  canManageRequests: true,
  canManageProjects: true,
  canViewAuditLogs: true,
  canExportBackup: true,
};

const mockUserProfile: UserProfile = {
  id: 'usr-admin-1',
  name: 'Ahmad Admin',
  username: 'ahmad_admin',
  role: 'super_admin',
  status: 'active',
  email: 'admin@sarwan.af',
  createdAt: new Date().toISOString(),
};

function renderPaymentsView(
  payments: Payment[] = [],
  invoices: Invoice[] = [],
  onAddPaymentMock = () => {}
): string {
  const authContextValue: any = {
    currentUser: null,
    userProfile: mockUserProfile,
    userRole: 'super_admin',
    permissions: mockPermissions,
    isAuthorized: true,
    isSuperAdmin: true,
    isInvoiceManager: false,
    isPaymentCollector: false,
    isCustomer: false,
    loading: false,
    error: null,
    portalMode: 'staff',
    currentCustomer: null,
    activeCustomer: null,
    hasRole: () => true,
    hasPermission: () => true,
    signInWithGoogle: async () => {},
    signInWithUsernameAndPassword: async () => {},
    changeMandatoryPassword: async () => {},
    signOutUser: async () => {},
    clearError: () => {},
    updateCurrentUserProfile: async () => {},
  };

  return renderToStaticMarkup(
    React.createElement(
      AuthContext.Provider,
      { value: authContextValue },
      React.createElement(PaymentsView, {
        payments,
        invoices,
        settings: mockSettings,
        onAddPayment: onAddPaymentMock,
        onAddCorrection: () => {},
        onSelectInvoice: () => {},
      })
    )
  );
}

export function runFinancialSummaryCardsTests(): { total: number; passed: number; failed: number } {
  const todayStr = getTodayDateString();
  const currentMonthPrefix = todayStr.slice(0, 7);

  // Setup sample test dataset
  const testInvoices: Invoice[] = [
    {
      id: 'inv-1',
      billNumber: 'ST-001',
      customerName: 'Customer A',
      totalAmount: 100000,
      totalPaid: 60000,
      status: 'Partially Paid',
      date: `${currentMonthPrefix}-01`,
      createdAt: `${currentMonthPrefix}-01T08:00:00Z`,
      items: [],
    } as any,
    {
      id: 'inv-2',
      billNumber: 'ST-002',
      customerName: 'Customer B',
      totalAmount: 50000,
      totalPaid: 50000,
      status: 'Paid',
      date: `${currentMonthPrefix}-02`,
      createdAt: `${currentMonthPrefix}-02T08:00:00Z`,
      items: [],
    } as any,
    {
      id: 'inv-3',
      billNumber: 'ST-003',
      customerName: 'Customer C',
      totalAmount: 30000,
      totalPaid: 0,
      status: 'Unpaid',
      date: `${currentMonthPrefix}-03`,
      createdAt: `${currentMonthPrefix}-03T08:00:00Z`,
      items: [],
    } as any,
    {
      id: 'inv-void',
      billNumber: 'ST-VOID',
      customerName: 'Customer Void',
      totalAmount: 80000,
      totalPaid: 80000,
      status: 'Void',
      isVoid: true,
      date: `${currentMonthPrefix}-04`,
      createdAt: `${currentMonthPrefix}-04T08:00:00Z`,
      items: [],
    } as any,
  ];

  const testPayments: Payment[] = [
    // Today's payment (ST-001 installment)
    {
      id: 'pay-today-1',
      invoiceId: 'inv-1',
      billNumber: 'ST-001',
      customerId: 'cust-1',
      customerName: 'Customer A',
      amount: 40000,
      date: todayStr,
      note: 'Today payment 1',
      method: 'CASH',
      createdAt: `${todayStr}T09:00:00Z`,
    },
    // Another payment earlier this month (ST-001 initial installment)
    {
      id: 'pay-month-1',
      invoiceId: 'inv-1',
      billNumber: 'ST-001',
      customerId: 'cust-1',
      customerName: 'Customer A',
      amount: 20000,
      date: `${currentMonthPrefix}-01`,
      note: 'Installment 1',
      method: 'CASH',
      createdAt: `${currentMonthPrefix}-01T09:00:00Z`,
    },
    // Payment earlier this month for fully paid invoice ST-002
    {
      id: 'pay-month-2',
      invoiceId: 'inv-2',
      billNumber: 'ST-002',
      customerId: 'cust-2',
      customerName: 'Customer B',
      amount: 50000,
      date: `${currentMonthPrefix}-02`,
      note: 'Full payment',
      method: 'CASH',
      createdAt: `${currentMonthPrefix}-02T10:00:00Z`,
    },
    // Payment from previous month (last year / month)
    {
      id: 'pay-prev-month',
      invoiceId: 'inv-old',
      billNumber: 'ST-OLD',
      customerId: 'cust-old',
      customerName: 'Old Customer',
      amount: 15000,
      date: '2025-01-15',
      note: 'Old payment',
      method: 'CASH',
      createdAt: '2025-01-15T10:00:00Z',
    },
    // Void / Reversed payment (must be excluded from calculations)
    {
      id: 'pay-void',
      invoiceId: 'inv-1',
      billNumber: 'ST-001',
      customerId: 'cust-1',
      customerName: 'Customer A',
      amount: 25000,
      date: todayStr,
      note: 'Accidental double entry',
      method: 'CASH',
      isVoid: true,
      createdAt: `${todayStr}T11:00:00Z`,
    },
    // Payment on Void Invoice (must be excluded from calculations)
    {
      id: 'pay-void-inv',
      invoiceId: 'inv-void',
      billNumber: 'ST-VOID',
      customerId: 'cust-void',
      customerName: 'Customer Void',
      amount: 80000,
      date: todayStr,
      note: 'Payment on void invoice',
      method: 'CASH',
      createdAt: `${todayStr}T12:00:00Z`,
    },
  ];

  test('4 Financial Summary Cards Rendered in Responsive Layout', () => {
    const markup = renderPaymentsView(testPayments, testInvoices);

    // Verify container and responsive grid
    expect(
      markup.includes('id="financial-summary-cards"'),
      'Container has id financial-summary-cards'
    );
    expect(
      markup.includes('grid-cols-1 sm:grid-cols-2 lg:grid-cols-4'),
      'Uses responsive 4-column desktop, 2-column tablet, 1-column mobile grid'
    );

    // Verify all 4 card IDs exist
    expect(markup.includes('id="card-total-collected"'), 'Card 1: card-total-collected exists');
    expect(markup.includes('id="card-today"'), 'Card 2: card-today exists');
    expect(markup.includes('id="card-this-month"'), 'Card 3: card-this-month exists');
    expect(markup.includes('id="card-outstanding"'), 'Card 4: card-outstanding exists');

    // Verify card titles
    expect(markup.includes('Total Collected'), 'Card 1 has title "Total Collected"');
    expect(markup.includes('Today'), 'Card 2 has title "Today"');
    expect(markup.includes('This Month'), 'Card 3 has title "This Month"');
    expect(markup.includes('Outstanding'), 'Card 4 has title "Outstanding"');
  });

  test('Card 1: Total Collected Calculation & AFN Formatting', () => {
    const markup = renderPaymentsView(testPayments, testInvoices);

    // Valid payments:
    // pay-today-1: 40,000
    // pay-month-1: 20,000
    // pay-month-2: 50,000
    // pay-prev-month: 15,000
    // Excluded: pay-void (25,000), pay-void-inv (80,000)
    // Expected Total: 40000 + 20000 + 50000 + 15000 = 125,000 AFN
    const expectedTotal = 125000;
    const formatted = formatAFN(expectedTotal); // "125,000 AFN"

    expect(
      markup.includes(formatted),
      `Total Collected shows ${formatted}`
    );
    expect(
      markup.includes('4 completed payments'),
      'Shows 4 completed payments subtitle'
    );
  });

  test('Card 2: Today Calculation & AFN Formatting', () => {
    const markup = renderPaymentsView(testPayments, testInvoices);

    // Valid today payments:
    // pay-today-1: 40,000 (valid)
    // pay-void: 25,000 (excluded because isVoid: true)
    // pay-void-inv: 80,000 (excluded because belongs to void invoice)
    // Expected Today: 40,000 AFN
    const expectedToday = 40000;
    const formatted = formatAFN(expectedToday); // "40,000 AFN"

    expect(
      markup.includes(formatted),
      `Today card shows ${formatted}`
    );
    expect(
      markup.includes('1 payment today'),
      'Shows 1 payment today subtitle'
    );
  });

  test('Card 3: This Month Calculation & AFN Formatting', () => {
    const markup = renderPaymentsView(testPayments, testInvoices);

    // Valid this month payments:
    // pay-today-1: 40,000
    // pay-month-1: 20,000
    // pay-month-2: 50,000
    // pay-prev-month: excluded (2025-01)
    // pay-void & pay-void-inv: excluded
    // Expected This Month: 110,000 AFN
    const expectedMonth = 110000;
    const formatted = formatAFN(expectedMonth); // "110,000 AFN"

    expect(
      markup.includes(formatted),
      `This Month card shows ${formatted}`
    );
    expect(
      markup.includes('3 payments this month'),
      'Shows 3 payments this month subtitle'
    );
  });

  test('Card 4: Outstanding Balance Calculation matches authoritative rules', () => {
    const markup = renderPaymentsView(testPayments, testInvoices);

    // Invoices:
    // inv-1: total 100,000, paid 60,000 (40k + 20k from valid payments), remaining = 40,000 AFN
    // inv-2: total 50,000, paid 50,000, remaining = 0 AFN
    // inv-3: total 30,000, paid 0, remaining = 30,000 AFN
    // inv-void: void invoice, remaining = 0 AFN
    // Expected Total Outstanding = 40,000 + 30,000 = 70,000 AFN
    const authoritativeOutstanding = calculateAuthoritativeTotalOutstanding(testInvoices, testPayments);
    expect(authoritativeOutstanding === 70000, `Authoritative outstanding is 70,000 AFN, got ${authoritativeOutstanding}`);

    const formatted = formatAFN(authoritativeOutstanding); // "70,000 AFN"
    expect(
      markup.includes(formatted),
      `Outstanding card shows ${formatted}`
    );
    expect(
      markup.includes('2 invoices with balance'),
      'Shows 2 invoices with balance subtitle'
    );
  });

  test('Empty Dataset Graceful Safety', () => {
    const markup = renderPaymentsView([], []);

    // When payments and invoices are empty:
    // All cards show 0 AFN without throwing or NaN
    expect(markup.includes('0 AFN'), 'Zero amounts safely formatted as 0 AFN');
    expect(markup.includes('0 completed payments'), '0 completed payments');
    expect(markup.includes('0 payments today'), '0 payments today');
    expect(markup.includes('0 payments this month'), '0 payments this month');
    expect(markup.includes('0 invoices with balance'), '0 invoices with balance');
  });

  test('Interactive Accessibility & Clean Hierarchy', () => {
    const markup = renderPaymentsView(testPayments, testInvoices);

    // Buttons have role, type button, title, and aria-pressed attributes
    expect(markup.includes('type="button"'), 'Cards are native interactive button elements');
    expect(markup.includes('aria-pressed='), 'Cards support aria-pressed state');
    expect(markup.includes('cursor-pointer'), 'Cards have cursor-pointer styling');
    expect(!markup.includes('$'), 'No dollar signs present in cards UI');
  });

  test('Payment Overview Section - 3 Metrics in Balanced Row', () => {
    const markup = renderPaymentsView(testPayments, testInvoices);

    // Verify Payment Overview container directly exists
    expect(markup.includes('id="payment-overview"'), 'Payment Overview container has id payment-overview');
    expect(
      markup.includes('grid grid-cols-1 sm:grid-cols-3'),
      'Uses responsive balanced 3-column row layout on desktop'
    );

    // Verify 3 metrics exist
    expect(markup.includes('>Collected<'), 'Overview metric 1 label is "Collected"');
    expect(markup.includes('>Outstanding<'), 'Overview metric 2 label is "Outstanding"');
    expect(markup.includes('>Transactions<'), 'Overview metric 3 label is "Transactions"');

    // Verify values match live data
    // Collected: 125,000 AFN
    expect(
      markup.includes('id="overview-collected-amount"'),
      'Overview Collected amount element exists'
    );
    expect(markup.includes('125,000 AFN'), 'Overview Collected displays 125,000 AFN');

    // Outstanding: 70,000 AFN
    expect(
      markup.includes('id="overview-outstanding-amount"'),
      'Overview Outstanding amount element exists'
    );
    expect(markup.includes('70,000 AFN'), 'Overview Outstanding displays 70,000 AFN');

    // Transactions: 4
    expect(
      markup.includes('id="overview-transactions-count"'),
      'Overview Transactions count element exists'
    );
    expect(markup.includes('>4<'), 'Overview Transactions displays 4');
  });

  console.log('===============================================================');
  console.log('    FINANCIAL SUMMARY CARDS VERIFICATION TEST RESULTS          ');
  console.log('===============================================================');

  let passed = 0;
  let failed = 0;

  results.forEach((r) => {
    if (r.passed) {
      passed++;
      console.log(`[✓ PASS] ${r.name}`);
    } else {
      failed++;
      console.error(`[✗ FAIL] ${r.name}: ${r.error}`);
    }
  });

  console.log('---------------------------------------------------------------');
  console.log(`TOTAL: ${results.length} Tests | PASSED: ${passed} | FAILED: ${failed}`);
  console.log('===============================================================');

  return { total: results.length, passed, failed };
}

// Auto-run when executed directly
if (process.argv[1] && process.argv[1].endsWith('financialSummaryCardsTests.ts')) {
  const summary = runFinancialSummaryCardsTests();
  if (summary.failed > 0) {
    process.exit(1);
  }
}
