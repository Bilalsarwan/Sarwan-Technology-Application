/**
 * Verification test suite for Invoices -> Invoice List requirements.
 */
import { Invoice, Payment, UserProfile } from '../types';
import { getAuthorizedInvoices } from '../services/dashboardAuthorization';
import { calculateTotalPaidForInvoice, calculateRemaining, formatAfghani } from '../utils/format';
import { calculateSingleInvoiceStatus, isInvoiceLocked } from './invoiceCalculator';

interface TestResult {
  suite: string;
  name: string;
  passed: boolean;
  error?: string;
}

const results: TestResult[] = [];

function test(suite: string, name: string, fn: () => void) {
  try {
    fn();
    results.push({ suite, name, passed: true });
  } catch (err: any) {
    results.push({ suite, name, passed: false, error: err?.message || String(err) });
  }
}

function expect(condition: boolean, msg: string) {
  if (!condition) throw new Error(msg);
}

export function runAllInvoiceListTests(): { total: number; passed: number; failed: number } {
  // Mock Invoices
  const sampleInvoices: Invoice[] = [
    {
      id: 'inv-1',
      billNumber: 'ST-1060',
      customerId: 'cust-1',
      customerSnapshot: {
        id: 'cust-1',
        name: 'Ahmad Khan',
        phone: '0700123456',
        companyName: 'Kabul Traders LLC',
        address: 'Kabul, Afghanistan',
      },
      companySnapshot: {
        companyName: 'Sarwan Technology',
        logo: '/sarwan-logo.png',
        phone: '0700000000',
        whatsapp: '0700000000',
        email: 'info@sarwan.af',
        address: 'Kabul, Afghanistan',
        currency: 'AFN',
        invoiceNote: 'Thank you for your business',
      },
      date: '2026-09-01',
      dueDate: '2026-09-15',
      items: [{ sNo: 1, description: 'Network Setup', quantity: 1, unitPrice: 100000, totalAmount: 100000 }],
      totalAmount: 100000,
      totalPaid: 100000,
      remaining: 0,
      status: 'Paid',
      isLocked: true,
      note: '',
      assignedCollectorId: 'coll-1',
      assignedCollectorName: 'Zmarai Collector',
      createdAt: '2026-09-01T10:00:00Z',
      updatedAt: '2026-09-01T10:00:00Z',
    },
    {
      id: 'inv-2',
      billNumber: 'ST-1061',
      customerId: 'cust-2',
      customerSnapshot: {
        id: 'cust-2',
        name: 'Baryalai Safi',
        phone: '0799887766',
        companyName: 'Herat Logistics',
        address: 'Herat, Afghanistan',
      },
      companySnapshot: {
        companyName: 'Sarwan Technology',
        logo: '/sarwan-logo.png',
        phone: '0700000000',
        whatsapp: '0700000000',
        email: 'info@sarwan.af',
        address: 'Kabul, Afghanistan',
        currency: 'AFN',
        invoiceNote: 'Thank you for your business',
      },
      date: '2026-09-05',
      dueDate: '2026-09-20',
      items: [{ sNo: 1, description: 'CCTV System', quantity: 1, unitPrice: 50000, totalAmount: 50000 }],
      totalAmount: 50000,
      totalPaid: 20000,
      remaining: 30000,
      status: 'Partially Paid',
      note: '',
      assignedCollectorId: 'coll-1',
      assignedCollectorName: 'Zmarai Collector',
      createdAt: '2026-09-05T10:00:00Z',
      updatedAt: '2026-09-05T10:00:00Z',
    },
    {
      id: 'inv-3',
      billNumber: 'ST-1062',
      customerId: 'cust-3',
      customerSnapshot: {
        id: 'cust-3',
        name: 'Chinar Gul',
        phone: '0788112233',
        companyName: 'Mazar Soft',
        address: 'Mazar, Afghanistan',
      },
      companySnapshot: {
        companyName: 'Sarwan Technology',
        logo: '/sarwan-logo.png',
        phone: '0700000000',
        whatsapp: '0700000000',
        email: 'info@sarwan.af',
        address: 'Kabul, Afghanistan',
        currency: 'AFN',
        invoiceNote: 'Thank you for your business',
      },
      date: '2026-09-10',
      dueDate: '2026-09-25',
      items: [{ sNo: 1, description: 'Server Hardware', quantity: 1, unitPrice: 80000, totalAmount: 80000 }],
      totalAmount: 80000,
      totalPaid: 0,
      remaining: 80000,
      status: 'Unpaid',
      note: '',
      assignedCollectorId: 'coll-2',
      assignedCollectorName: 'Wahid Collector',
      createdAt: '2026-09-10T10:00:00Z',
      updatedAt: '2026-09-10T10:00:00Z',
    },
    {
      id: 'inv-void',
      billNumber: 'ST-1063',
      customerId: 'cust-4',
      customerSnapshot: {
        id: 'cust-4',
        name: 'Hamid Wardak',
        phone: '0777998877',
        companyName: 'Wardak Tech',
        address: 'Wardak, Afghanistan',
      },
      companySnapshot: {
        companyName: 'Sarwan Technology',
        logo: '/sarwan-logo.png',
        phone: '0700000000',
        whatsapp: '0700000000',
        email: 'info@sarwan.af',
        address: 'Kabul, Afghanistan',
        currency: 'AFN',
        invoiceNote: 'Thank you for your business',
      },
      date: '2026-09-08',
      dueDate: '2026-09-22',
      items: [{ sNo: 1, description: 'Cancelled Service', quantity: 1, unitPrice: 40000, totalAmount: 40000 }],
      totalAmount: 40000,
      totalPaid: 10000,
      remaining: 30000,
      status: 'Void',
      isVoid: true,
      note: 'Order cancelled by customer',
      createdAt: '2026-09-08T10:00:00Z',
      updatedAt: '2026-09-08T10:00:00Z',
    },
  ];

  // Mock Payments
  const samplePayments: Payment[] = [
    {
      id: 'pay-1',
      invoiceId: 'inv-1',
      billNumber: 'ST-1060',
      customerId: 'cust-1',
      customerName: 'Ahmad Khan',
      amount: 100000,
      date: '2026-09-02',
      method: 'CASH',
      note: 'Full payment',
      createdAt: '2026-09-02T12:00:00Z',
    },
    {
      id: 'pay-2',
      invoiceId: 'inv-2',
      billNumber: 'ST-1061',
      customerId: 'cust-2',
      customerName: 'Baryalai Safi',
      amount: 20000,
      date: '2026-09-06',
      method: 'CASH',
      note: 'Partial payment',
      createdAt: '2026-09-06T12:00:00Z',
    },
    {
      id: 'pay-void',
      invoiceId: 'inv-void',
      billNumber: 'ST-1063',
      customerId: 'cust-1',
      customerName: 'Ahmad Khan',
      amount: 10000,
      date: '2026-09-08',
      method: 'CASH',
      note: 'Deposit before void',
      createdAt: '2026-09-08T12:00:00Z',
    },
  ];

  // Suite 1: Paid Invoice Edit Restriction & Lock Behavior
  test('Paid Invoice Edit Restriction', 'Fully paid invoice is recognized as locked', () => {
    const inv1 = sampleInvoices[0];
    const paid = calculateTotalPaidForInvoice(inv1.id, samplePayments);
    const isLockedOrPaid = Boolean(
      inv1.isLocked ||
      inv1.status === 'Paid' ||
      (inv1.totalAmount > 0 && paid >= inv1.totalAmount)
    );
    expect(isLockedOrPaid === true, 'Fully paid invoice must be recognized as locked');
  });

  test('Paid Invoice Edit Restriction', 'Unpaid and partially paid invoices remain editable by authorized users', () => {
    const inv2 = sampleInvoices[1]; // partially paid
    const paid2 = calculateTotalPaidForInvoice(inv2.id, samplePayments);
    const isLocked2 = Boolean(
      inv2.isLocked ||
      inv2.status === 'Paid' ||
      (inv2.totalAmount > 0 && paid2 >= inv2.totalAmount)
    );
    expect(isLocked2 === false, 'Partially paid invoice should not be marked locked unless explicitly locked');

    const inv3 = sampleInvoices[2]; // unpaid
    const paid3 = calculateTotalPaidForInvoice(inv3.id, samplePayments);
    const isLocked3 = Boolean(
      inv3.isLocked ||
      inv3.status === 'Paid' ||
      (inv3.totalAmount > 0 && paid3 >= inv3.totalAmount)
    );
    expect(isLocked3 === false, 'Unpaid invoice should not be marked locked');
  });

  // Comprehensive Acceptance Tests 1-6
  test('Invoice Lock Lifecycle', 'TEST 1: Invoice total = 10,000 with no payments -> Edit button enabled', () => {
    const testInv: Invoice = {
      ...sampleInvoices[2],
      id: 'test-lifecycle-1',
      totalAmount: 10000,
      totalPaid: 0,
      remaining: 10000,
      status: 'Unpaid',
      isLocked: false,
    };
    const payments: Payment[] = [];
    const paid = calculateTotalPaidForInvoice(testInv.id, payments);
    const remaining = calculateRemaining(testInv.totalAmount, paid);
    const isLockedOrPaid = Boolean(
      testInv.isLocked ||
      testInv.status === 'Paid' ||
      (testInv.totalAmount > 0 && paid >= testInv.totalAmount) ||
      remaining <= 0
    );
    expect(isLockedOrPaid === false, 'TEST 1: Edit button must be ENABLED when no payment is made');
  });

  test('Invoice Lock Lifecycle', 'TEST 2: Add payment = 5,000 -> Remaining = 5,000, Edit button remains enabled', () => {
    const testInv: Invoice = {
      ...sampleInvoices[2],
      id: 'test-lifecycle-2',
      totalAmount: 10000,
      totalPaid: 5000,
      remaining: 5000,
      status: 'Partially Paid',
      isLocked: false,
    };
    const payments: Payment[] = [
      {
        id: 'test-pay-1',
        invoiceId: testInv.id,
        billNumber: testInv.billNumber,
        customerId: testInv.customerId,
        customerName: 'Test',
        amount: 5000,
        date: '2026-09-19',
        method: 'CASH',
        note: 'First payment',
        createdAt: '2026-09-19T10:00:00Z',
      },
    ];
    const paid = calculateTotalPaidForInvoice(testInv.id, payments);
    const remaining = calculateRemaining(testInv.totalAmount, paid);
    const isLockedOrPaid = Boolean(
      testInv.isLocked ||
      testInv.status === 'Paid' ||
      (testInv.totalAmount > 0 && paid >= testInv.totalAmount) ||
      remaining <= 0
    );
    expect(remaining === 5000, `Expected remaining 5000, got ${remaining}`);
    expect(isLockedOrPaid === false, 'TEST 2: Edit button must remain ENABLED for partially paid invoice');
  });

  test('Invoice Lock Lifecycle', 'TEST 3: Add second payment = 5,000 -> Total Paid = 10,000, Status = Paid, Locked = true, Edit button disabled', () => {
    const testInv: Invoice = {
      ...sampleInvoices[2],
      id: 'test-lifecycle-3',
      totalAmount: 10000,
      totalPaid: 10000,
      remaining: 0,
      status: 'Paid',
      isLocked: true,
    };
    const payments: Payment[] = [
      {
        id: 'test-pay-1',
        invoiceId: testInv.id,
        billNumber: testInv.billNumber,
        customerId: testInv.customerId,
        customerName: 'Test',
        amount: 5000,
        date: '2026-09-19',
        method: 'CASH',
        note: 'First payment',
        createdAt: '2026-09-19T10:00:00Z',
      },
      {
        id: 'test-pay-2',
        invoiceId: testInv.id,
        billNumber: testInv.billNumber,
        customerId: testInv.customerId,
        customerName: 'Test',
        amount: 5000,
        date: '2026-09-19',
        method: 'CASH',
        note: 'Second payment',
        createdAt: '2026-09-19T10:05:00Z',
      },
    ];
    const paid = calculateTotalPaidForInvoice(testInv.id, payments);
    const remaining = calculateRemaining(testInv.totalAmount, paid);
    const isLockedOrPaid = Boolean(
      testInv.isLocked ||
      testInv.status === 'Paid' ||
      (testInv.totalAmount > 0 && paid >= testInv.totalAmount) ||
      remaining <= 0
    );
    expect(paid === 10000, 'Total paid must equal 10000');
    expect(remaining === 0, 'Remaining must equal 0');
    expect(isLockedOrPaid === true, 'TEST 3: Edit button must be DISABLED when fully paid');
  });

  test('Invoice Lock Lifecycle', 'TEST 4: State reload simulation -> Invoice remains locked and Edit button remains disabled', () => {
    // Loaded fresh from DB
    const loadedFromDb: Invoice = {
      ...sampleInvoices[0],
      totalAmount: 10000,
      totalPaid: 10000,
      remaining: 0,
      status: 'Paid',
      isLocked: true,
    };
    const isLockedOrPaid = Boolean(
      loadedFromDb.isLocked ||
      loadedFromDb.status === 'Paid' ||
      (loadedFromDb.totalAmount > 0 && loadedFromDb.totalPaid >= loadedFromDb.totalAmount) ||
      loadedFromDb.remaining <= 0
    );
    expect(isLockedOrPaid === true, 'TEST 4: Re-loaded invoice must preserve disabled lock state');
  });

  test('Invoice Lock Lifecycle', 'TEST 5: Service/API rejection guard rejects locked or fully paid invoices', () => {
    const lockedInvoice: Invoice = {
      ...sampleInvoices[0],
      totalAmount: 10000,
      totalPaid: 10000,
      remaining: 0,
      status: 'Paid',
      isLocked: true,
    };
    const paymentsTotal = 10000;
    const canUpdate = !lockedInvoice.isLocked && !(paymentsTotal >= lockedInvoice.totalAmount);
    expect(canUpdate === false, 'TEST 5: Backend service/API must reject update for fully paid or locked invoice');
  });

  test('Invoice Lock Lifecycle', 'TEST 6: Mobile & UI disabled state contract verifies button attributes', () => {
    const isLockedOrPaid = true;
    const canEditPermission = true;
    const buttonDisabled = isLockedOrPaid || !canEditPermission;
    const ariaDisabled = isLockedOrPaid || !canEditPermission;
    const classes = isLockedOrPaid || !canEditPermission
      ? 'text-neutral-400 bg-neutral-100 border border-neutral-200 cursor-not-allowed opacity-60 pointer-events-none'
      : 'text-neutral-700 bg-white hover:bg-neutral-100 border border-neutral-300';

    expect(buttonDisabled === true, 'HTML button must have disabled attribute true');
    expect(ariaDisabled === true, 'Accessibility aria-disabled must be true');
    expect(classes.includes('pointer-events-none'), 'Must include pointer-events-none to prevent touch/click on mobile');
    expect(classes.includes('cursor-not-allowed'), 'Must include cursor-not-allowed to visually signify disabled state');
  });

  // Suite 2: Role-based Authorization
  test('Role-based Authorization', 'Super Admin sees all invoices', () => {
    const adminUser: UserProfile = {
      id: 'admin-1',
      name: 'Super Admin',
      username: 'admin',
      email: 'admin@sarwan.af',
      role: 'super_admin',
      status: 'active',
      createdAt: '2026-01-01T00:00:00Z',
    };
    const visible = getAuthorizedInvoices(adminUser, sampleInvoices);
    expect(visible.length === sampleInvoices.length, `Expected ${sampleInvoices.length} invoices for Super Admin, got ${visible.length}`);
  });

  test('Role-based Authorization', 'Invoice Manager sees all invoices', () => {
    const managerUser: UserProfile = {
      id: 'mgr-1',
      name: 'Invoice Manager',
      username: 'manager',
      email: 'manager@sarwan.af',
      role: 'invoice_manager',
      status: 'active',
      createdAt: '2026-01-01T00:00:00Z',
    };
    const visible = getAuthorizedInvoices(managerUser, sampleInvoices);
    expect(visible.length === sampleInvoices.length, `Expected ${sampleInvoices.length} invoices for Invoice Manager, got ${visible.length}`);
  });

  test('Role-based Authorization', 'Payment Collector sees only assigned invoices', () => {
    const collectorUser: UserProfile = {
      id: 'coll-1',
      name: 'Zmarai Collector',
      username: 'collector',
      email: 'zmarai@sarwan.af',
      role: 'payment_collector',
      status: 'active',
      createdAt: '2026-01-01T00:00:00Z',
    };
    const visible = getAuthorizedInvoices(collectorUser, sampleInvoices);
    expect(visible.length === 2, `Expected 2 assigned invoices for Zmarai, got ${visible.length}`);
    expect(visible.every((i) => i.assignedCollectorId === 'coll-1'), 'All returned invoices must belong to collector');
  });

  // Suite 3: Search Pipeline
  test('Search Pipeline', 'Searches by Bill Number', () => {
    const query = 'ST-1061';
    const match = sampleInvoices.filter((i) => i.billNumber.toLowerCase().includes(query.toLowerCase()));
    expect(match.length === 1 && match[0].id === 'inv-2', 'Failed to search by Bill Number');
  });

  test('Search Pipeline', 'Searches by Customer Name', () => {
    const query = 'Ahmad';
    const match = sampleInvoices.filter((i) => i.customerSnapshot.name.toLowerCase().includes(query.toLowerCase()));
    expect(match.length === 1 && match[0].id === 'inv-1', 'Failed to search by Customer Name');
  });

  test('Search Pipeline', 'Searches by Customer Phone (handles formatting like hyphens, spaces, and parentheses)', () => {
    const searchByPhone = (query: string, list: Invoice[]) => {
      const term = query.toLowerCase().trim();
      const cleanPhoneSearch = term.replace(/[\s\-()]/g, '');
      if (!cleanPhoneSearch) return [];
      return list.filter((i) => {
        const cleanStoredPhone = (i.customerSnapshot?.phone || '').toLowerCase().replace(/[\s\-()]/g, '');
        return cleanPhoneSearch.length > 0 && cleanStoredPhone.includes(cleanPhoneSearch);
      });
    };

    // Test 1: Exact unformatted search
    const matchExact = searchByPhone('0788112233', sampleInvoices);
    expect(matchExact.length === 1 && matchExact[0].id === 'inv-3', 'Failed unformatted phone search');

    // Test 2: Search with hyphens finding unformatted stored number (078-811-2233 -> 0788112233)
    const matchHyphens = searchByPhone('078-811-2233', sampleInvoices);
    expect(matchHyphens.length === 1 && matchHyphens[0].id === 'inv-3', 'Failed hyphenated phone search');

    // Test 3: Search with parentheses and spaces ((078) 811 2233)
    const matchParens = searchByPhone('(078) 811 2233', sampleInvoices);
    expect(matchParens.length === 1 && matchParens[0].id === 'inv-3', 'Failed parentheses/spaces phone search');

    // Test 4: Partial phone search with formatting (811-22)
    const matchPartial = searchByPhone('811-22', sampleInvoices);
    expect(matchPartial.length === 1 && matchPartial[0].id === 'inv-3', 'Failed partial formatted phone search');

    // Test 5: Formatted stored number matched by unformatted search
    const invoiceWithFormattedPhone: Invoice = {
      ...sampleInvoices[0],
      customerSnapshot: { ...sampleInvoices[0].customerSnapshot, phone: '(078) 123-4567' },
    };
    const matchStoredFormatted = searchByPhone('0781234567', [invoiceWithFormattedPhone]);
    expect(matchStoredFormatted.length === 1, 'Failed unformatted search on formatted stored phone');

    // Test 6: Removing formatting characters leaves empty search text - must NOT match every invoice
    const matchFormattingOnly = searchByPhone(' - () - ', sampleInvoices);
    expect(matchFormattingOnly.length === 0, 'Formatting-only search text must return 0 results');
  });

  test('Search Pipeline', 'Searches by Company Name', () => {
    const query = 'Herat Logistics';
    const match = sampleInvoices.filter((i) => (i.customerSnapshot.companyName || '').toLowerCase().includes(query.toLowerCase()));
    expect(match.length === 1 && match[0].id === 'inv-2', 'Failed to search by Company Name');
  });

  // Suite 4: Financial Calculations
  test('Financial Calculations', 'Calculates cash received and remaining balance accurately', () => {
    const paid1 = calculateTotalPaidForInvoice('inv-1', samplePayments);
    const rem1 = calculateRemaining(sampleInvoices[0].totalAmount, paid1);
    expect(paid1 === 100000, `Expected paid 100000, got ${paid1}`);
    expect(rem1 === 0, `Expected remaining 0, got ${rem1}`);

    const paid2 = calculateTotalPaidForInvoice('inv-2', samplePayments);
    const rem2 = calculateRemaining(sampleInvoices[1].totalAmount, paid2);
    expect(paid2 === 20000, `Expected paid 20000, got ${paid2}`);
    expect(rem2 === 30000, `Expected remaining 30000, got ${rem2}`);
  });

  // Suite 5: Void Status & Void Filter
  test('Void Status & Void Filter', 'Void invoice has status "Void" and isVoid flag, resolving to Void status', () => {
    const voidInv = sampleInvoices.find((i) => i.id === 'inv-void')!;
    expect(voidInv.status === 'Void', 'Invoice status must be Void');
    expect(voidInv.isVoid === true, 'Invoice isVoid must be true');

    const singleResult = calculateSingleInvoiceStatus(voidInv, 10000);
    expect(singleResult.status === 'Void', 'Single invoice status calculation must resolve to Void');
    expect(singleResult.outstanding === 0, 'Single invoice outstanding balance for void must be 0');
  });

  test('Void Status & Void Filter', 'Status filter "Void" correctly isolates all and only void invoices', () => {
    const voidFiltered = sampleInvoices.filter((i) => (i.isVoid === true || i.status === 'Void'));
    expect(voidFiltered.length === 1, `Expected 1 void invoice, got ${voidFiltered.length}`);
    expect(voidFiltered[0].id === 'inv-void', 'Void filter must return inv-void');
    expect(voidFiltered[0].billNumber === 'ST-1063', 'Void invoice billNumber must be ST-1063');
  });

  test('Void Status & Void Filter', 'Status filter "Void" works with multi-field search', () => {
    // Search for "Hamid" with status "Void"
    const term = 'hamid';
    const match = sampleInvoices.filter((i) => {
      const isVoid = i.isVoid === true || i.status === 'Void';
      if (!isVoid) return false;
      const matchName = i.customerSnapshot.name.toLowerCase().includes(term);
      return matchName;
    });
    expect(match.length === 1 && match[0].id === 'inv-void', 'Search "hamid" + Void must find inv-void');

    // Search for "Herat" with status "Void" (should find none)
    const matchNone = sampleInvoices.filter((i) => {
      const isVoid = i.isVoid === true || i.status === 'Void';
      if (!isVoid) return false;
      return (i.customerSnapshot.companyName || '').toLowerCase().includes('herat');
    });
    expect(matchNone.length === 0, 'Search "herat" + Void must return 0 results');
  });

  test('Void Status & Void Filter', 'Financial summaries exclude Void invoices from active sales', () => {
    // When statusFilter !== 'Void' (e.g., 'all' or active statuses), void invoices are excluded
    const activeInvoices = sampleInvoices.filter((i) => !(i.isVoid === true || i.status === 'Void'));
    const totalActiveSales = activeInvoices.reduce((sum, i) => sum + i.totalAmount, 0);
    expect(totalActiveSales === 230000, `Expected 230000 total active sales, got ${totalActiveSales}`);

    const totalActivePaid = activeInvoices.reduce(
      (sum, i) => sum + calculateTotalPaidForInvoice(i.id, samplePayments),
      0
    );
    expect(totalActivePaid === 120000, `Expected 120000 total active paid, got ${totalActivePaid}`);

    const totalActiveRemaining = Math.max(0, totalActiveSales - totalActivePaid);
    expect(totalActiveRemaining === 110000, `Expected 110000 total active remaining, got ${totalActiveRemaining}`);
  });

  test('Void Status & Void Filter', 'Historical payments recorded on void invoices remain intact and queryable', () => {
    const voidPayments = samplePayments.filter((p) => p.invoiceId === 'inv-void');
    expect(voidPayments.length === 1, `Expected 1 payment record for inv-void, got ${voidPayments.length}`);
    expect(voidPayments[0].amount === 10000, `Expected payment amount 10000, got ${voidPayments[0].amount}`);
    expect(voidPayments[0].note === 'Deposit before void', 'Payment note should be preserved');
  });

  test('Void Status & Void Filter', 'Void invoices are non-editable and cannot receive new payments', () => {
    const voidInv = sampleInvoices.find((i) => i.id === 'inv-void')!;
    const isEditDisabled = Boolean(
      voidInv.isLocked ||
      voidInv.isVoid ||
      voidInv.status === 'Void' ||
      voidInv.status === 'Paid'
    );
    expect(isEditDisabled === true, 'Edit must be disabled for void invoices');

    const canRecordPayment = Boolean(
      !voidInv.isVoid &&
      voidInv.status !== 'Void' &&
      voidInv.status !== 'Paid' &&
      !voidInv.isLocked
    );
    expect(canRecordPayment === false, 'Cannot record new payments on void invoice');
  });

  // Interactive Click-to-Sort Verification Suite
  test('Interactive Click-to-Sort', 'Header click toggles sort directions and sets correct default directions', () => {
    // Simulate the handleSort logic
    const simulateSortToggle = (currentSort: string, field: string) => {
      const isCurrentField = currentSort.startsWith(`${field}-`);
      const currentDirection = isCurrentField ? (currentSort.endsWith('-asc') ? 'asc' : 'desc') : null;

      if (currentDirection === 'desc') {
        return `${field}-asc`;
      } else if (currentDirection === 'asc') {
        return `${field}-desc`;
      } else {
        const defaultAsc = ['customer', 'status', 'collector'].includes(field);
        return `${field}-${defaultAsc ? 'asc' : 'desc'}`;
      }
    };

    // Starting from bill-desc
    let state = 'bill-desc';
    // Clicking 'bill' again should toggle to bill-asc
    state = simulateSortToggle(state, 'bill');
    expect(state === 'bill-asc', `Expected bill-asc, got ${state}`);

    // Clicking 'bill' again should toggle back to bill-desc
    state = simulateSortToggle(state, 'bill');
    expect(state === 'bill-desc', `Expected bill-desc, got ${state}`);

    // Clicking 'date' (inactive) should select date-desc (chronological default)
    state = simulateSortToggle(state, 'date');
    expect(state === 'date-desc', `Expected date-desc, got ${state}`);

    // Clicking 'date' again should toggle to date-asc
    state = simulateSortToggle(state, 'date');
    expect(state === 'date-asc', `Expected date-asc, got ${state}`);

    // Clicking 'customer' (inactive alphabetical) should select customer-asc
    state = simulateSortToggle(state, 'customer');
    expect(state === 'customer-asc', `Expected customer-asc, got ${state}`);

    // Clicking 'customer' again should toggle to customer-desc
    state = simulateSortToggle(state, 'customer');
    expect(state === 'customer-desc', `Expected customer-desc, got ${state}`);

    // Clicking 'amount' (inactive numeric) should select amount-desc
    state = simulateSortToggle(state, 'amount');
    expect(state === 'amount-desc', `Expected amount-desc, got ${state}`);

    // Clicking 'amount' again should toggle to amount-asc
    state = simulateSortToggle(state, 'amount');
    expect(state === 'amount-asc', `Expected amount-asc, got ${state}`);
  });

  test('Interactive Click-to-Sort', 'Reorders invoices correctly by Bill Number (asc / desc)', () => {
    const list = [...sampleInvoices];

    // Sort bill-desc
    const sortedDesc = [...list].sort((a, b) =>
      (b.billNumber || '').localeCompare(a.billNumber || '', undefined, { numeric: true })
    );
    expect(sortedDesc[0].billNumber === 'ST-1063', 'Latest bill should be first in bill-desc');
    expect(sortedDesc[sortedDesc.length - 1].billNumber === 'ST-1060', 'Oldest bill should be last in bill-desc');

    // Sort bill-asc
    const sortedAsc = [...list].sort((a, b) =>
      (a.billNumber || '').localeCompare(b.billNumber || '', undefined, { numeric: true })
    );
    expect(sortedAsc[0].billNumber === 'ST-1060', 'Oldest bill should be first in bill-asc');
    expect(sortedAsc[sortedAsc.length - 1].billNumber === 'ST-1063', 'Latest bill should be last in bill-asc');
  });

  test('Interactive Click-to-Sort', 'Reorders invoices correctly by Date (desc / asc)', () => {
    const list = [...sampleInvoices];

    // Sort date-desc
    const sortedDesc = [...list].sort((a, b) => b.date.localeCompare(a.date));
    expect(sortedDesc[0].date === '2026-09-10', `Expected newest date first (2026-09-10), got ${sortedDesc[0].date}`);
    expect(sortedDesc[sortedDesc.length - 1].date === '2026-09-01', `Expected oldest date last (2026-09-01), got ${sortedDesc[sortedDesc.length - 1].date}`);

    // Sort date-asc
    const sortedAsc = [...list].sort((a, b) => a.date.localeCompare(b.date));
    expect(sortedAsc[0].date === '2026-09-01', `Expected oldest date first (2026-09-01), got ${sortedAsc[0].date}`);
    expect(sortedAsc[sortedAsc.length - 1].date === '2026-09-10', `Expected newest date last (2026-09-10), got ${sortedAsc[sortedAsc.length - 1].date}`);
  });

  test('Interactive Click-to-Sort', 'Reorders invoices correctly by Total Amount (highest / lowest)', () => {
    const list = [...sampleInvoices];

    // Sort amount-desc
    const sortedDesc = [...list].sort((a, b) => (Number(b.totalAmount) || 0) - (Number(a.totalAmount) || 0));
    expect(sortedDesc[0].totalAmount === 100000, `Expected highest amount 100,000, got ${sortedDesc[0].totalAmount}`);
    expect(sortedDesc[sortedDesc.length - 1].totalAmount === 40000, `Expected lowest amount 40,000, got ${sortedDesc[sortedDesc.length - 1].totalAmount}`);

    // Sort amount-asc
    const sortedAsc = [...list].sort((a, b) => (Number(a.totalAmount) || 0) - (Number(b.totalAmount) || 0));
    expect(sortedAsc[0].totalAmount === 40000, `Expected lowest amount 40,000 first, got ${sortedAsc[0].totalAmount}`);
    expect(sortedAsc[sortedAsc.length - 1].totalAmount === 100000, `Expected highest amount 100,000 last, got ${sortedAsc[sortedAsc.length - 1].totalAmount}`);
  });

  test('Interactive Click-to-Sort', 'Reorders invoices correctly by Customer Name (A-Z / Z-A)', () => {
    const list = [...sampleInvoices];

    // Sort customer-asc
    const sortedAsc = [...list].sort((a, b) =>
      (a.customerSnapshot?.name || '').localeCompare(b.customerSnapshot?.name || '')
    );
    expect(sortedAsc[0].customerSnapshot?.name === 'Ahmad Khan', `Expected 'Ahmad Khan' first, got ${sortedAsc[0].customerSnapshot?.name}`);
    expect(sortedAsc[sortedAsc.length - 1].customerSnapshot?.name === 'Hamid Wardak', `Expected 'Hamid Wardak' last, got ${sortedAsc[sortedAsc.length - 1].customerSnapshot?.name}`);

    // Sort customer-desc
    const sortedDesc = [...list].sort((a, b) =>
      (b.customerSnapshot?.name || '').localeCompare(a.customerSnapshot?.name || '')
    );
    expect(sortedDesc[0].customerSnapshot?.name === 'Hamid Wardak', `Expected 'Hamid Wardak' first, got ${sortedDesc[0].customerSnapshot?.name}`);
    expect(sortedDesc[sortedDesc.length - 1].customerSnapshot?.name === 'Ahmad Khan', `Expected 'Ahmad Khan' last, got ${sortedDesc[sortedDesc.length - 1].customerSnapshot?.name}`);
  });

  // Invoice Collector Assignment Verification Suite
  test('Invoice Collector Assignment', 'Assign an unassigned invoice to an eligible collector', () => {
    const unassignedInvoice: Invoice = {
      ...sampleInvoices[0],
      id: 'inv-unassigned-test',
      billNumber: 'ST-9999',
      assignedCollectorId: undefined,
      assignedCollectorName: undefined,
      assignmentHistory: [],
    };

    expect(!unassignedInvoice.assignedCollectorId, 'Initial state must be unassigned');

    const collectorId = 'coll-101';
    const collectorName = 'Najeeb Collector';
    const adminId = 'admin-1';
    const adminName = 'Super Admin';
    const now = '2026-09-27T12:00:00.000Z';

    const entry = {
      collectorId,
      collectorName,
      assignedBy: adminId,
      assignedByName: adminName,
      assignedAt: now,
    };

    // Simulate save
    const assignedInvoice: Invoice = {
      ...unassignedInvoice,
      assignedCollectorId: collectorId,
      assignedCollectorName: collectorName,
      assignedBy: adminId,
      assignedByName: adminName,
      assignedAt: now,
      assignmentHistory: [entry],
    };

    expect(assignedInvoice.assignedCollectorId === collectorId, 'Collector ID must be saved');
    expect(assignedInvoice.assignedCollectorName === collectorName, 'Collector Name must be saved');
    expect(assignedInvoice.assignmentHistory?.length === 1, 'Assignment history entry must be created');
  });

  test('Invoice Collector Assignment', 'Page reload simulation preserves assigned collector and history', () => {
    // Serialized to JSON to simulate persistence across page refresh
    const originalInvoice: Invoice = {
      ...sampleInvoices[0],
      id: 'inv-persist-test',
      billNumber: 'ST-8888',
      assignedCollectorId: 'coll-101',
      assignedCollectorName: 'Najeeb Collector',
      assignedBy: 'admin-1',
      assignedByName: 'Super Admin',
      assignedAt: '2026-09-27T12:00:00.000Z',
      assignmentHistory: [
        {
          collectorId: 'coll-101',
          collectorName: 'Najeeb Collector',
          assignedBy: 'admin-1',
          assignedByName: 'Super Admin',
          assignedAt: '2026-09-27T12:00:00.000Z',
        },
      ],
    };

    const reloadedInvoice: Invoice = JSON.parse(JSON.stringify(originalInvoice));

    expect(reloadedInvoice.assignedCollectorId === 'coll-101', 'Assigned collector ID must persist across reload');
    expect(reloadedInvoice.assignedCollectorName === 'Najeeb Collector', 'Assigned collector name must persist');
    expect(reloadedInvoice.assignmentHistory?.length === 1, 'Assignment history must persist');
  });

  test('Invoice Collector Assignment', 'Reassign invoice to another collector without losing previous history', () => {
    const invoiceBeforeReassign: Invoice = {
      ...sampleInvoices[0],
      id: 'inv-reassign-test',
      billNumber: 'ST-7777',
      assignedCollectorId: 'coll-101',
      assignedCollectorName: 'Najeeb Collector',
      assignedBy: 'admin-1',
      assignedByName: 'Super Admin',
      assignedAt: '2026-09-27T12:00:00.000Z',
      assignmentHistory: [
        {
          collectorId: 'coll-101',
          collectorName: 'Najeeb Collector',
          assignedBy: 'admin-1',
          assignedByName: 'Super Admin',
          assignedAt: '2026-09-27T12:00:00.000Z',
        },
      ],
    };

    const newCollectorId = 'coll-102';
    const newCollectorName = 'Wahid Collector';
    const managerId = 'mgr-1';
    const managerName = 'Invoice Manager';
    const reassignTime = '2026-09-27T14:30:00.000Z';

    const reassignEntry = {
      collectorId: newCollectorId,
      collectorName: newCollectorName,
      assignedBy: managerId,
      assignedByName: managerName,
      assignedAt: reassignTime,
      previousCollectorId: invoiceBeforeReassign.assignedCollectorId,
      previousCollectorName: invoiceBeforeReassign.assignedCollectorName,
    };

    const reassignedInvoice: Invoice = {
      ...invoiceBeforeReassign,
      assignedCollectorId: newCollectorId,
      assignedCollectorName: newCollectorName,
      assignedBy: managerId,
      assignedByName: managerName,
      assignedAt: reassignTime,
      assignmentHistory: [...(invoiceBeforeReassign.assignmentHistory || []), reassignEntry],
    };

    expect(reassignedInvoice.assignedCollectorId === newCollectorId, 'New collector ID must be active');
    expect(reassignedInvoice.assignedCollectorName === newCollectorName, 'New collector name must be active');
    expect(reassignedInvoice.assignmentHistory?.length === 2, 'Previous assignment history must NOT be lost');
    expect(reassignedInvoice.assignmentHistory?.[0].collectorName === 'Najeeb Collector', 'Original entry preserved');
    expect(reassignedInvoice.assignmentHistory?.[1].previousCollectorName === 'Najeeb Collector', 'Prior collector recorded in entry');

    // Simulate reload after reassignment
    const reloadedAfterReassign: Invoice = JSON.parse(JSON.stringify(reassignedInvoice));
    expect(reloadedAfterReassign.assignedCollectorId === newCollectorId, 'Reassigned collector persists after reload');
    expect(reloadedAfterReassign.assignmentHistory?.length === 2, 'Complete history intact after reload');
  });

  test('Invoice Collector Assignment', 'Permission validation: Super Admin and Invoice Manager can assign; Collectors and Customers cannot', () => {
    const canUserAssign = (role: string) => {
      if (role === 'customer' || role === 'payment_collector') return false;
      if (role === 'super_admin' || role === 'invoice_manager') return true;
      return false;
    };

    expect(canUserAssign('super_admin') === true, 'Super Admin must be authorized to assign');
    expect(canUserAssign('invoice_manager') === true, 'Invoice Manager must be authorized to assign');
    expect(canUserAssign('payment_collector') === false, 'Payment Collector must NOT be allowed to assign');
    expect(canUserAssign('customer') === false, 'Customer must NOT be allowed to assign');
  });

  test('Invoice Collector Assignment', 'Validation rules: Inactive/suspended users and non-collector roles are rejected', () => {
    const candidateUsers = [
      { id: 'u1', name: 'Valid Collector', role: 'payment_collector', status: 'active' },
      { id: 'u2', name: 'Inactive Collector', role: 'payment_collector', status: 'inactive' },
      { id: 'u3', name: 'Suspended Collector', role: 'payment_collector', status: 'suspended' },
      { id: 'u4', name: 'Manager', role: 'invoice_manager', status: 'active' },
      { id: 'u5', name: 'Customer', role: 'customer', status: 'active' },
    ];

    const eligible = candidateUsers.filter(
      (u) => u.role === 'payment_collector' && u.status === 'active'
    );

    expect(eligible.length === 1, 'Only active payment_collector accounts are eligible');
    expect(eligible[0].id === 'u1', 'Valid Collector must be the only candidate');

    // Duplicate check validation
    const currentCollectorId = 'u1';
    const isDuplicate = currentCollectorId === eligible[0].id;
    expect(isDuplicate === true, 'Reassigning to same collector must be flagged as duplicate');
  });

  // Suite: Locked Invoice Collector Assignment Rules (Cases 1 - 9)
  test('Locked Invoice Collector Assignment Rules', 'CASE 1: Unlocked + no collector -> Assign Collector is available for authorized users', () => {
    const inv: Partial<Invoice> = {
      id: 'inv-unlocked-unassigned',
      isLocked: false,
      status: 'Unpaid',
      totalAmount: 1000,
      totalPaid: 0,
      assignedCollectorId: undefined,
    };
    const isLocked = isInvoiceLocked(inv);
    const isVoid = Boolean(inv.isVoid || inv.status === 'Void');
    const canUserAssign = true;
    const canAssignCollector = canUserAssign && !isLocked && !isVoid;

    expect(isLocked === false, 'Invoice must not be locked');
    expect(canAssignCollector === true, 'Assign action must be available for unlocked unassigned invoice');
  });

  test('Locked Invoice Collector Assignment Rules', 'CASE 2: Unlocked + collector assigned -> Change/Reassign Collector is available for authorized users', () => {
    const inv: Partial<Invoice> = {
      id: 'inv-unlocked-assigned',
      isLocked: false,
      status: 'Partially Paid',
      totalAmount: 1000,
      totalPaid: 300,
      assignedCollectorId: 'coll-1',
      assignedCollectorName: 'Collector One',
    };
    const isLocked = isInvoiceLocked(inv);
    const isVoid = Boolean(inv.isVoid || inv.status === 'Void');
    const canUserAssign = true;
    const canChangeCollector = canUserAssign && !isLocked && !isVoid;

    expect(isLocked === false, 'Invoice must not be locked');
    expect(canChangeCollector === true, 'Change/Reassign action must be available for unlocked assigned invoice');
  });

  test('Locked Invoice Collector Assignment Rules', 'CASE 3: Locked + no collector -> Assign Collector is NOT available', () => {
    const inv: Partial<Invoice> = {
      id: 'inv-locked-unassigned',
      isLocked: true,
      status: 'Unpaid',
      totalAmount: 1000,
      totalPaid: 0,
      assignedCollectorId: undefined,
    };
    const isLocked = isInvoiceLocked(inv);
    const isVoid = Boolean(inv.isVoid || inv.status === 'Void');
    const canUserAssign = true;
    const canAssignCollector = canUserAssign && !isLocked && !isVoid;

    expect(isLocked === true, 'Invoice must be recognized as locked');
    expect(canAssignCollector === false, 'Assign action must be blocked for locked invoice');
  });

  test('Locked Invoice Collector Assignment Rules', 'CASE 4: Locked + collector assigned -> Change/Reassign Collector is NOT available', () => {
    const inv: Partial<Invoice> = {
      id: 'inv-locked-assigned',
      isLocked: true,
      status: 'Paid',
      totalAmount: 1000,
      totalPaid: 1000,
      assignedCollectorId: 'coll-1',
      assignedCollectorName: 'Collector One',
    };
    const isLocked = isInvoiceLocked(inv);
    const isVoid = Boolean(inv.isVoid || inv.status === 'Void');
    const canUserAssign = true;
    const canChangeCollector = canUserAssign && !isLocked && !isVoid;

    expect(isLocked === true, 'Invoice must be recognized as locked');
    expect(canChangeCollector === false, 'Change/Reassign action must be blocked for locked invoice');
    expect(inv.assignedCollectorName === 'Collector One', 'Current collector name remains visible');
  });

  test('Locked Invoice Collector Assignment Rules', 'CASE 5: Void + no collector -> Assign Collector is NOT available', () => {
    const inv: Partial<Invoice> = {
      id: 'inv-void-unassigned',
      isVoid: true,
      status: 'Void',
      totalAmount: 1000,
      totalPaid: 0,
      assignedCollectorId: undefined,
    };
    const isLocked = isInvoiceLocked(inv);
    const isVoid = Boolean(inv.isVoid || inv.status === 'Void');
    const canUserAssign = true;
    const canAssignCollector = canUserAssign && !isLocked && !isVoid;

    expect(isVoid === true, 'Invoice must be void');
    expect(canAssignCollector === false, 'Assign action must be blocked for void invoice');
  });

  test('Locked Invoice Collector Assignment Rules', 'CASE 6: Void + collector assigned -> Change/Reassign Collector is NOT available', () => {
    const inv: Partial<Invoice> = {
      id: 'inv-void-assigned',
      isVoid: true,
      status: 'Void',
      totalAmount: 1000,
      totalPaid: 0,
      assignedCollectorId: 'coll-1',
      assignedCollectorName: 'Collector One',
    };
    const isLocked = isInvoiceLocked(inv);
    const isVoid = Boolean(inv.isVoid || inv.status === 'Void');
    const canUserAssign = true;
    const canChangeCollector = canUserAssign && !isLocked && !isVoid;

    expect(isVoid === true, 'Invoice must be void');
    expect(canChangeCollector === false, 'Change/Reassign action must be blocked for void invoice');
  });

  test('Locked Invoice Collector Assignment Rules', 'CASE 7: UI says invoice is unlocked, but Firestore latest state is locked before submit -> Rejection', () => {
    // Simulating database service validation
    const uiInvoiceState: Partial<Invoice> = {
      id: 'inv-stale-ui',
      isLocked: false,
      status: 'Unpaid',
    };
    const firestoreLatestState: Partial<Invoice> = {
      id: 'inv-stale-ui',
      isLocked: true,
      status: 'Paid',
      totalAmount: 5000,
      totalPaid: 5000,
    };

    let caughtError: string | null = null;
    const simulateAssign = (latestInv: Partial<Invoice>) => {
      if (latestInv.isVoid || latestInv.status === 'Void') {
        throw new Error('Cannot assign or reassign a collector to a voided invoice.');
      }
      if (latestInv.isLocked || isInvoiceLocked(latestInv)) {
        throw new Error('Cannot assign or reassign a collector because this invoice is locked.');
      }
    };

    try {
      simulateAssign(firestoreLatestState);
    } catch (err: any) {
      caughtError = err.message;
    }

    expect(
      caughtError === 'Cannot assign or reassign a collector because this invoice is locked.',
      'Database service must reject assignment when latest Firestore state is locked'
    );
  });

  test('Locked Invoice Collector Assignment Rules', 'CASE 8: Unauthorized user -> Assignment remains prohibited exactly as before', () => {
    const roles = ['customer', 'payment_collector'];
    for (const r of roles) {
      const canAssign = r === 'super_admin' || r === 'invoice_manager';
      expect(canAssign === false, `Role ${r} must be prohibited from assigning`);
    }
  });

  test('Locked Invoice Collector Assignment Rules', 'CASE 9: Successful assignment on unlocked invoice -> Fields update normally & history preserved', () => {
    const unlockedInvoice: Invoice = {
      ...sampleInvoices[0],
      id: 'inv-unlocked-success',
      totalAmount: 100000,
      totalPaid: 0,
      remaining: 100000,
      isLocked: false,
      status: 'Unpaid',
      assignedCollectorId: undefined,
      assignedCollectorName: undefined,
      assignmentHistory: [],
    };

    expect(!isInvoiceLocked(unlockedInvoice), 'Must be unlocked');
    const newCollectorId = 'coll-99';
    const newCollectorName = 'Test Collector';
    const updatedInvoice: Invoice = {
      ...unlockedInvoice,
      assignedCollectorId: newCollectorId,
      assignedCollectorName: newCollectorName,
      assignmentHistory: [
        {
          collectorId: newCollectorId,
          collectorName: newCollectorName,
          assignedBy: 'admin',
          assignedByName: 'Super Admin',
          assignedAt: new Date().toISOString(),
        },
      ],
    };

    expect(updatedInvoice.assignedCollectorId === newCollectorId, 'Collector ID updated');
    expect(updatedInvoice.assignedCollectorName === newCollectorName, 'Collector Name updated');
    expect(updatedInvoice.assignmentHistory?.length === 1, 'History preserved');
  });

  // Suite 8: Invoice Row Responsive Structure & Presentation (A2)
  test('Invoice Row Responsive Structure', 'Monetary amounts format correctly using Afghan Afghani symbol ؋ (no $)', () => {
    expect(formatAfghani(0) === '؋ 0', '0 must format as ؋ 0');
    expect(formatAfghani(50000) === '؋ 50,000', '50,000 must format as ؋ 50,000');
    expect(formatAfghani(125000) === '؋ 125,000', '125,000 must format as ؋ 125,000');
    expect(!formatAfghani(50000).includes('$'), 'Must never include $ symbol');
    expect(formatAfghani(null) === '؋ 0', 'Null must safely format as ؋ 0');
  });

  test('Invoice Row Responsive Structure', 'Small mobile shows only essential columns and hides secondary columns', () => {
    // Contract check for column visibility rules across breakpoints
    const smallMobileVisibleColumns = ['bill', 'customer', 'amount', 'status', 'actions'];
    const smallMobileHiddenColumns = ['date', 'paid', 'remaining', 'collector'];

    expect(smallMobileVisibleColumns.length === 5, 'Small mobile must show exactly 5 essential columns');
    expect(smallMobileHiddenColumns.includes('date'), 'Date must be hidden on small mobile');
    expect(smallMobileHiddenColumns.includes('paid'), 'Paid Amount must be hidden on small mobile');
    expect(smallMobileHiddenColumns.includes('remaining'), 'Remaining Balance must be hidden on small mobile');
    expect(smallMobileHiddenColumns.includes('collector'), 'Assigned Collector must be hidden on small mobile');
  });

  test('Invoice Row Responsive Structure', 'Progressive disclosure rules for large mobile, tablet, and desktop', () => {
    // sm: (640px+) reveals Date
    const smReveals = ['date'];
    expect(smReveals.includes('date'), 'Large mobile / tablet (sm:) reveals Date');

    // md: (768px+) reveals Paid and Remaining amounts
    const mdReveals = ['paid', 'remaining'];
    expect(mdReveals.includes('paid') && mdReveals.includes('remaining'), 'Tablet (md:) reveals Cash Received and Remaining');

    // lg: (1024px+) reveals Assigned Collector
    const lgReveals = ['collector'];
    expect(lgReveals.includes('collector'), 'Desktop (lg:) reveals Assigned Collector');
  });

  test('Invoice Row Responsive Structure', 'Payment status labels distinguish Unpaid, Partial, and Paid cleanly', () => {
    const statuses = ['Unpaid', 'Partially Paid', 'Paid', 'Void'];
    const getMobileLabel = (st: string) => (st === 'Partially Paid' ? 'Partial' : st);

    expect(getMobileLabel('Paid') === 'Paid', 'Paid maps to Paid');
    expect(getMobileLabel('Partially Paid') === 'Partial', 'Partially Paid maps to compact Partial on mobile');
    expect(getMobileLabel('Unpaid') === 'Unpaid', 'Unpaid maps to Unpaid');
    expect(getMobileLabel('Void') === 'Void', 'Void maps to Void');
  });

  test('Invoice Row Responsive Structure', 'Locked and paid invoices do not show active Edit/Update action', () => {
    const paidInv = sampleInvoices[0];
    const isLockedOrPaid = Boolean(
      paidInv.isLocked ||
      paidInv.status === 'Paid' ||
      (paidInv.totalAmount > 0 && paidInv.totalPaid >= paidInv.totalAmount)
    );
    const canEditPermission = true;
    const isEditDisabled = isLockedOrPaid || !canEditPermission;

    expect(isEditDisabled === true, 'Locked / paid invoice must have Edit disabled');
  });

  test('Invoice Row Responsive Structure', 'Long customer names have truncation safety classes', () => {
    const longName = 'Al-Haj Mohammad Ibrahim Khan Wardak Logistics & Trading Co.';
    const truncationClasses = 'truncate max-w-[100px] sm:max-w-[170px] md:max-w-none';
    expect(truncationClasses.includes('truncate'), 'Must include truncate class');
    expect(truncationClasses.includes('max-w-'), 'Must include responsive max width to prevent overflow');
  });

  // Suite 9: Date Filter Validation
  test('Date Filter Validation', 'Detects invalid date range when end date is earlier than start date and prevents silent empty result', () => {
    const filterByDates = (start: string, end: string, list: Invoice[]) => {
      const isInvalid = Boolean(start && end && end < start);
      return list.filter((inv) => {
        if (!isInvalid) {
          if (start && inv.date < start) return false;
          if (end && inv.date > end) return false;
        }
        return true;
      });
    };

    // Case 1: Valid date range (2026-09-01 to 2026-09-06)
    const validResult = filterByDates('2026-09-01', '2026-09-06', sampleInvoices);
    // inv-1 is 2026-09-01, inv-2 is 2026-09-05
    expect(validResult.length === 2, `Expected 2 invoices in valid range, got ${validResult.length}`);

    // Case 2: Invalid date range (start: 2026-09-15, end: 2026-09-01)
    const start = '2026-09-15';
    const end = '2026-09-01';
    const isInvalidDateRange = Boolean(start && end && end < start);
    expect(isInvalidDateRange === true, 'Must detect end date earlier than start date as invalid');

    // Case 3: Invalid date range does NOT silently return empty list
    const invalidResult = filterByDates(start, end, sampleInvoices);
    expect(invalidResult.length === sampleInvoices.length, 'Invalid range must not silently return 0 results');

    // Case 4: Single start date works
    const onlyStart = filterByDates('2026-09-08', '', sampleInvoices);
    // inv-3 (2026-09-10) and inv-void (2026-09-08)
    expect(onlyStart.length === 2, `Expected 2 invoices on or after 2026-09-08, got ${onlyStart.length}`);

    // Case 5: Single end date works
    const onlyEnd = filterByDates('', '2026-09-04', sampleInvoices);
    // inv-1 is 2026-09-01
    expect(onlyEnd.length === 1 && onlyEnd[0].id === 'inv-1', 'Expected only inv-1 before 2026-09-04');
  });

  // Suite 10: Pagination
  test('Pagination', 'Enforces exactly 10 invoices per page and calculates page slices accurately', () => {
    // Generate 24 dummy invoices
    const twentyFourInvoices: Invoice[] = Array.from({ length: 24 }, (_, i) => ({
      ...sampleInvoices[0],
      id: `inv-${i + 1}`,
      billNumber: `ST-${1000 + i + 1}`,
      totalAmount: 1000,
      totalPaid: 500,
      remaining: 500,
    }));

    const PAGE_SIZE = 10;
    const totalInvoices = twentyFourInvoices.length;
    const totalPages = Math.ceil(totalInvoices / PAGE_SIZE);

    expect(PAGE_SIZE === 10, 'Page size must be strictly 10');
    expect(totalPages === 3, '24 items with PAGE_SIZE 10 yields 3 total pages');

    // Page 1
    const p1Start = 0;
    const p1End = Math.min(p1Start + PAGE_SIZE, totalInvoices);
    const p1Slice = twentyFourInvoices.slice(p1Start, p1End);
    const p1Range = `Showing ${p1Start + 1}–${p1End} of ${totalInvoices} invoices`;
    const p1CanPrev = 1 > 1;
    const p1CanNext = 1 < totalPages;

    expect(p1Slice.length === 10, 'Page 1 has exactly 10 items');
    expect(p1Slice[0].billNumber === 'ST-1001', 'Page 1 first item is ST-1001');
    expect(p1Slice[9].billNumber === 'ST-1010', 'Page 1 last item is ST-1010');
    expect(p1Range === 'Showing 1–10 of 24 invoices', 'Page 1 range text is "Showing 1–10 of 24 invoices"');
    expect(!p1CanPrev, 'Previous button must be disabled on page 1');
    expect(p1CanNext, 'Next button must be enabled on page 1');

    // Page 2
    const p2Start = 10;
    const p2End = Math.min(p2Start + PAGE_SIZE, totalInvoices);
    const p2Slice = twentyFourInvoices.slice(p2Start, p2End);
    const p2Range = `Showing ${p2Start + 1}–${p2End} of ${totalInvoices} invoices`;
    const p2CanPrev = 2 > 1;
    const p2CanNext = 2 < totalPages;

    expect(p2Slice.length === 10, 'Page 2 has exactly 10 items');
    expect(p2Slice[0].billNumber === 'ST-1011', 'Page 2 first item is ST-1011');
    expect(p2Slice[9].billNumber === 'ST-1020', 'Page 2 last item is ST-1020');
    expect(p2Range === 'Showing 11–20 of 24 invoices', 'Page 2 range text is "Showing 11–20 of 24 invoices"');
    expect(p2CanPrev, 'Previous button must be enabled on page 2');
    expect(p2CanNext, 'Next button must be enabled on page 2');

    // Page 3
    const p3Start = 20;
    const p3End = Math.min(p3Start + PAGE_SIZE, totalInvoices);
    const p3Slice = twentyFourInvoices.slice(p3Start, p3End);
    const p3Range = `Showing ${p3Start + 1}–${p3End} of ${totalInvoices} invoices`;
    const p3CanPrev = 3 > 1;
    const p3CanNext = 3 < totalPages;

    expect(p3Slice.length === 4, 'Page 3 has exactly 4 items (remaining 4 of 24)');
    expect(p3Slice[0].billNumber === 'ST-1021', 'Page 3 first item is ST-1021');
    expect(p3Slice[3].billNumber === 'ST-1024', 'Page 3 last item is ST-1024');
    expect(p3Range === 'Showing 21–24 of 24 invoices', 'Page 3 range text is "Showing 21–24 of 24 invoices"');
    expect(p3CanPrev, 'Previous button must be enabled on page 3');
    expect(!p3CanNext, 'Next button must be disabled on page 3 (last page)');
  });

  test('Pagination', 'Resets page to 1 when search, filters, or sorting change', () => {
    let currentPage = 3;
    const resetPage = () => {
      currentPage = 1;
    };

    // Simulate search change
    resetPage();
    expect(currentPage === 1, 'Search change resets currentPage to 1');

    currentPage = 2;
    // Simulate status filter change
    resetPage();
    expect(currentPage === 1, 'Status filter change resets currentPage to 1');

    currentPage = 3;
    // Simulate date filter change
    resetPage();
    expect(currentPage === 1, 'Date filter change resets currentPage to 1');

    currentPage = 2;
    // Simulate sort change
    resetPage();
    expect(currentPage === 1, 'Sort change resets currentPage to 1');
  });

  test('Pagination', 'Summary totals are calculated based on all filtered invoices, not only the current page', () => {
    const twentyFourInvoices: Invoice[] = Array.from({ length: 24 }, (_, i) => ({
      ...sampleInvoices[0],
      id: `inv-${i + 1}`,
      totalAmount: 1000,
      totalPaid: 600,
      remaining: 400,
      isVoid: false,
    }));

    // Sliced page 1 (10 invoices)
    const page1Invoices = twentyFourInvoices.slice(0, 10);
    const page1TotalAmount = page1Invoices.reduce((sum, inv) => sum + inv.totalAmount, 0);
    expect(page1TotalAmount === 10000, 'Page 1 total amount is only 10,000');

    // Summary totals on full filtered set (24 invoices)
    const allFilteredTotalAmount = twentyFourInvoices.reduce((sum, inv) => sum + inv.totalAmount, 0);
    const allFilteredPaid = twentyFourInvoices.reduce((sum, inv) => sum + (inv.totalPaid || 0), 0);
    const allFilteredRemaining = twentyFourInvoices.reduce((sum, inv) => sum + (inv.remaining || 0), 0);

    expect(allFilteredTotalAmount === 24000, 'Summary total amount must cover all 24 invoices (24,000 AFN)');
    expect(allFilteredPaid === 14400, 'Summary total paid must cover all 24 invoices (14,400 AFN)');
    expect(allFilteredRemaining === 9600, 'Summary total remaining must cover all 24 invoices (9,600 AFN)');
  });

  test('Pagination', 'Preserves empty state when 0 invoices match criteria', () => {
    const emptyList: Invoice[] = [];
    const totalInvoices = emptyList.length;
    const isZeroMatches = totalInvoices === 0;

    expect(isZeroMatches === true, 'Empty filtered list triggers empty state block');
  });

  // Responsive A4 Invoice Preview Scaling Suite
  test('Responsive A4 Invoice Preview Scaling', 'Maintains 210x297mm A4 geometry and aspect ratio across all screen sizes', () => {
    const a4WidthMm = 210;
    const a4HeightMm = 297;
    const aspectRatio = a4HeightMm / a4WidthMm; // ~1.4142857

    expect(a4WidthMm === 210, 'A4 width remains strictly 210mm');
    expect(a4HeightMm === 297, 'A4 height remains strictly 297mm');
    expect(Math.abs(aspectRatio - 1.414) < 0.01, 'A4 aspect ratio is exactly 1.414');
  });

  test('Responsive A4 Invoice Preview Scaling', 'Scales complete A4 page to fit available width without horizontal overflow at desktop, tablet, and mobile widths', () => {
    const a4WidthPx = 793.7;
    const a4HeightPx = 1122.5;

    // Simulate container measurement logic in InvoiceDetailModal
    const calculateModalPreviewScale = (viewportWidth: number) => {
      // Modal max-w-4xl is 896px; viewport margins p-2/sm:p-4/md:p-6
      const modalMargin = viewportWidth <= 400 ? 16 : viewportWidth <= 640 ? 32 : 48;
      const modalWidth = Math.min(896, Math.max(280, viewportWidth - modalMargin));
      // Modal body inner padding (p-3.5 = 28px on mobile, p-6 = 48px on sm+)
      const bodyPadding = viewportWidth <= 640 ? 28 : 48;
      const containerWidth = Math.max(100, modalWidth - bodyPadding);

      // Inner preview container padding
      const minPadding = containerWidth <= 400 ? 8 : containerWidth <= 640 ? 12 : containerWidth <= 1024 ? 16 : 24;
      const availableWidth = Math.max(60, containerWidth - minPadding * 2);

      const rawScale = availableWidth / a4WidthPx;
      const scale = Math.max(0.2, Math.min(1.0, Math.round(rawScale * 1000) / 1000));
      const scaledWidth = Math.round(a4WidthPx * scale);
      const scaledHeight = Math.round(a4HeightPx * scale);

      const leftMargin = Math.floor((containerWidth - scaledWidth) / 2);
      const rightMargin = containerWidth - (leftMargin + scaledWidth);

      return {
        viewportWidth,
        containerWidth,
        scale,
        scaledWidth,
        scaledHeight,
        leftMargin,
        rightMargin,
        isCentered: Math.abs(leftMargin - rightMargin) <= 1,
        hasNoOverflow: scaledWidth <= containerWidth,
        isNotClipped: leftMargin >= 0 && rightMargin >= 0,
        aspectRatio: scaledHeight / scaledWidth,
      };
    };

    // User-required verification breakpoints:
    // 1920px desktop, 1366px desktop, 1024px tablet, 768px tablet, 430px mobile, 390px mobile, 360px mobile
    const breakpoints = [1920, 1366, 1024, 768, 430, 390, 360];

    for (const width of breakpoints) {
      const result = calculateModalPreviewScale(width);

      // 1. Fits within container without horizontal overflow
      expect(result.hasNoOverflow, `Width ${width}px: Scaled width (${result.scaledWidth}px) fits in container (${result.containerWidth}px)`);

      // 2. Not clipped on left or right
      expect(result.isNotClipped, `Width ${width}px: Left (${result.leftMargin}px) and Right (${result.rightMargin}px) edges not clipped`);

      // 3. Centered horizontally
      expect(result.isCentered, `Width ${width}px: Perfectly centered horizontally`);

      // 4. Desktop readable size (1.0 on 1024px+); scaled down on mobile/tablet
      if (width >= 1024) {
        expect(result.scale === 1.0, `Width ${width}px: Desktop displays at readable 100% scale (1.0)`);
      } else {
        expect(result.scale < 1.0, `Width ${width}px: Tablet/Mobile dynamically reduces scale (${result.scale})`);
        expect(result.scale >= 0.3, `Width ${width}px: Scale stays above minimum threshold`);
      }

      // 5. Strict A4 aspect ratio preserved
      expect(Math.abs(result.aspectRatio - 1.414) < 0.02, `Width ${width}px: Strict A4 aspect ratio preserved (${result.aspectRatio.toFixed(3)})`);
    }
  });

  const suites = Array.from(new Set(results.map((r) => r.suite)));
  console.log('===============================================================');
  console.log('         INVOICE LIST BEHAVIOR VERIFICATION RESULTS            ');
  console.log('===============================================================');

  let totalPassed = 0;
  let totalFailed = 0;

  for (const s of suites) {
    const suiteResults = results.filter((r) => r.suite === s);
    const suitePassed = suiteResults.filter((r) => r.passed).length;
    const suiteTotal = suiteResults.length;
    const allPassed = suitePassed === suiteTotal;

    console.log(`[${allPassed ? '✓ PASS' : '✗ FAIL'}] ${s} (${suitePassed}/${suiteTotal} passed)`);
    for (const r of suiteResults) {
      if (r.passed) {
        console.log(`  ✓ ${r.name}`);
        totalPassed++;
      } else {
        console.log(`  ✗ ${r.name}: ${r.error}`);
        totalFailed++;
      }
    }
  }

  console.log('---------------------------------------------------------------');
  console.log(`TOTAL: ${totalPassed}/${results.length} Tests Passed`);
  console.log(`OVERALL STATUS: ${totalFailed === 0 ? 'ALL TESTS PASSED' : 'SOME TESTS FAILED'}`);
  console.log('===============================================================');

  return { total: results.length, passed: totalPassed, failed: totalFailed };
}

if (import.meta.url === `file://${process.argv[1]}`) {
  const summary = runAllInvoiceListTests();
  process.exit(summary.failed === 0 ? 0 : 1);
}
