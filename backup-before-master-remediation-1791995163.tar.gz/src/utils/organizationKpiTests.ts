import fs from 'fs';
import path from 'path';
import {
  UserProfile,
  Customer,
  Invoice,
  Payment,
} from '../types';
import {
  calculateTotalUsers,
  calculateTotalCustomers,
  calculateTotalInvoices,
  calculateTotalPayments,
  calculateTotalOutstanding,
  calculateOrganizationKPIs,
} from './format';
import {
  calculateValidUsersCount,
  calculateValidCustomersCount,
  calculateValidInvoicesCount,
  calculateValidPaymentsAmount,
  calculateValidOutstandingAmount,
  formatMonetaryAFN,
  calculateInvoiceStatusBreakdown,
  calculatePaidInvoicesCount,
  calculatePartiallyPaidInvoicesCount,
  calculateUnpaidInvoicesCount,
  calculateOverdueInvoicesCount,
} from '../views/DashboardView';

/**
 * Individual test case result representation
 */
export interface TestCaseResult {
  name: string;
  passed: boolean;
  expected: any;
  actual: any;
  message?: string;
  details?: Record<string, any>;
}

/**
 * Test suite execution result
 */
export interface TestSuiteResult {
  suiteName: string;
  passed: boolean;
  totalTests: number;
  passedTests: number;
  failedTests: number;
  results: TestCaseResult[];
}

/**
 * Master summary of all executed KPI test suites
 */
export interface AllKpiTestsSummary {
  passed: boolean;
  totalSuites: number;
  passedSuites: number;
  failedSuites: number;
  totalTests: number;
  passedTests: number;
  failedTests: number;
  suites: Record<string, TestSuiteResult>;
}

// ---------------------------------------------------------------------------
// Mock Data Generators for Test Scenarios
// ---------------------------------------------------------------------------

export function createMockUser(overrides: Partial<UserProfile> = {}): UserProfile {
  return {
    id: `usr_${Math.random().toString(36).substring(2, 9)}`,
    name: 'Test User',
    username: 'testuser',
    email: 'user@sarwan.af',
    role: 'payment_collector',
    status: 'active',
    createdAt: '2026-01-01T00:00:00.000Z',
    ...overrides,
  };
}

export function createMockCustomer(overrides: Partial<Customer> = {}): Customer {
  return {
    id: `cust_${Math.random().toString(36).substring(2, 9)}`,
    name: 'Test Customer',
    companyName: 'Test Company',
    phone: '0700000000',
    address: 'Kabul, Afghanistan',
    note: '',
    createdAt: '2026-01-01T00:00:00.000Z',
    updatedAt: '2026-01-01T00:00:00.000Z',
    ...overrides,
  };
}

export function createMockInvoice(overrides: Partial<Invoice> = {}): Invoice {
  const id = overrides.id || `inv_${Math.random().toString(36).substring(2, 9)}`;
  const billNumber = overrides.billNumber || `ST-${Math.floor(1000 + Math.random() * 9000)}`;
  return {
    id,
    billNumber,
    customerId: 'cust_default',
    customerSnapshot: {
      id: 'cust_default',
      name: 'Snapshot Customer',
      companyName: 'Snapshot Co',
      phone: '0700000000',
      address: 'Kabul',
    },
    companySnapshot: {
      companyName: 'Sarwan Tech',
      logo: '',
      phone: '',
      whatsapp: '',
      email: '',
      address: '',
      currency: 'AFN',
      invoiceNote: '',
    },
    date: '2026-01-15',
    items: [
      { sNo: 1, description: 'Service Item', quantity: 1, unitPrice: 10000, totalAmount: 10000 }
    ],
    totalAmount: 10000,
    note: '',
    status: 'Unpaid',
    createdAt: '2026-01-15T10:00:00.000Z',
    updatedAt: '2026-01-15T10:00:00.000Z',
    isVoid: false,
    ...overrides,
  };
}

export function createMockPayment(overrides: Partial<Payment> = {}): Payment {
  return {
    id: `pay_${Math.random().toString(36).substring(2, 9)}`,
    invoiceId: 'inv_default',
    billNumber: 'ST-1000',
    customerId: 'cust_default',
    customerName: 'Snapshot Customer',
    amount: 5000,
    date: '2026-01-16',
    note: 'Cash payment',
    method: 'CASH',
    createdAt: '2026-01-16T12:00:00.000Z',
    isVoid: false,
    ...overrides,
  };
}

// ---------------------------------------------------------------------------
// 1. Total Users Test Suite
// Business Rule: Total Users = count of all existing user accounts (active, inactive, suspended, pending)
// ---------------------------------------------------------------------------
export function testTotalUsersCalculation(customUsers?: UserProfile[]): TestSuiteResult {
  const results: TestCaseResult[] = [];

  // Case 1: Standard account statuses all counted
  const standardUsers: UserProfile[] = [
    createMockUser({ id: 'u1', status: 'active' }),
    createMockUser({ id: 'u2', status: 'inactive' }),
    createMockUser({ id: 'u3', status: 'suspended' }),
    createMockUser({ id: 'u4', status: 'pending' }),
  ];
  const actualCount1 = calculateTotalUsers(standardUsers);
  results.push({
    name: 'Counts all accounts regardless of status (active, inactive, suspended, pending)',
    passed: actualCount1 === 4,
    expected: 4,
    actual: actualCount1,
  });

  // Case 2: Reject null, undefined, or empty-id items
  const corruptedUsers = [
    createMockUser({ id: 'u5' }),
    { id: '', name: 'Empty ID' } as any,
    null as any,
    undefined as any,
    {} as any,
  ];
  const actualCount2 = calculateTotalUsers(corruptedUsers);
  results.push({
    name: 'Excludes null, undefined, and empty-id objects',
    passed: actualCount2 === 1,
    expected: 1,
    actual: actualCount2,
  });

  // Case 3: Empty list returns 0
  const actualCount3 = calculateTotalUsers([]);
  results.push({
    name: 'Returns 0 when user collection is empty',
    passed: actualCount3 === 0,
    expected: 0,
    actual: actualCount3,
  });

  // Case 4: Optional custom users verification
  if (customUsers) {
    const customCount = calculateTotalUsers(customUsers);
    const expectedValid = customUsers.filter(u => u && u.id).length;
    results.push({
      name: 'Evaluates provided custom users collection correctly',
      passed: customCount === expectedValid,
      expected: expectedValid,
      actual: customCount,
    });
  }

  const passedTests = results.filter(r => r.passed).length;
  return {
    suiteName: 'Total Users Calculation',
    passed: passedTests === results.length,
    totalTests: results.length,
    passedTests,
    failedTests: results.length - passedTests,
    results,
  };
}

// ---------------------------------------------------------------------------
// 2. Total Customers Test Suite
// Business Rule: Total Customers = count(customers where isArchived !== true)
// ---------------------------------------------------------------------------
export function testTotalCustomersCalculation(customCustomers?: Customer[]): TestSuiteResult {
  const results: TestCaseResult[] = [];

  // Case 1: Excludes archived customers, includes active/unarchived
  const mixedCustomers: Customer[] = [
    createMockCustomer({ id: 'c1', isArchived: false }),
    createMockCustomer({ id: 'c2', isArchived: true }),
    createMockCustomer({ id: 'c3', isArchived: undefined }),
    createMockCustomer({ id: 'c4' }),
    createMockCustomer({ id: 'c5', isArchived: true }),
  ];
  const actualCount1 = calculateTotalCustomers(mixedCustomers);
  results.push({
    name: 'Excludes archived customers (isArchived === true)',
    passed: actualCount1 === 3,
    expected: 3,
    actual: actualCount1,
    details: { totalProvided: 5, archivedCount: 2, activeExpected: 3 },
  });

  // Case 2: Archiving a customer decrements the count by 1
  const beforeArchive = [
    createMockCustomer({ id: 'c10', isArchived: false }),
    createMockCustomer({ id: 'c11', isArchived: false }),
  ];
  const afterArchive = [
    createMockCustomer({ id: 'c10', isArchived: false }),
    createMockCustomer({ id: 'c11', isArchived: true }),
  ];
  const countBefore = calculateTotalCustomers(beforeArchive);
  const countAfter = calculateTotalCustomers(afterArchive);
  results.push({
    name: 'Archiving a customer decrements Total Customers count by 1',
    passed: countBefore === 2 && countAfter === 1,
    expected: '2 -> 1',
    actual: `${countBefore} -> ${countAfter}`,
  });

  // Case 3: Empty and invalid records
  const corruptedCustomers = [
    createMockCustomer({ id: 'c12', isArchived: false }),
    null as any,
    undefined as any,
    { id: '', name: 'Blank' } as any,
  ];
  const actualCount3 = calculateTotalCustomers(corruptedCustomers);
  results.push({
    name: 'Excludes invalid/empty customer records',
    passed: actualCount3 === 1,
    expected: 1,
    actual: actualCount3,
  });

  // Case 4: Optional custom customers
  if (customCustomers) {
    const customCount = calculateTotalCustomers(customCustomers);
    const expected = customCustomers.filter(c => c && c.id && c.isArchived !== true).length;
    results.push({
      name: 'Evaluates provided custom customers collection correctly',
      passed: customCount === expected,
      expected,
      actual: customCount,
    });
  }

  const passedTests = results.filter(r => r.passed).length;
  return {
    suiteName: 'Total Customers Calculation',
    passed: passedTests === results.length,
    totalTests: results.length,
    passedTests,
    failedTests: results.length - passedTests,
    results,
  };
}

// ---------------------------------------------------------------------------
// 3. Total Invoices Test Suite
// Business Rule: Total Invoices = count(invoices where isVoid !== true and status !== 'Void')
// ---------------------------------------------------------------------------
export function testTotalInvoicesCalculation(customInvoices?: Invoice[]): TestSuiteResult {
  const results: TestCaseResult[] = [];

  // Case 1: isVoid: true filtering
  const voidInvoices: Invoice[] = [
    createMockInvoice({ id: 'inv1', status: 'Unpaid', isVoid: false }),
    createMockInvoice({ id: 'inv2', status: 'Paid', isVoid: false }),
    createMockInvoice({ id: 'inv3', status: 'Partially Paid', isVoid: false }),
    createMockInvoice({ id: 'inv4', status: 'Void', isVoid: true }),
    createMockInvoice({ id: 'inv5', status: 'Unpaid', isVoid: true }),
  ];
  const actualCount1 = calculateTotalInvoices(voidInvoices);
  results.push({
    name: 'Excludes all invoices with isVoid: true',
    passed: actualCount1 === 3,
    expected: 3,
    actual: actualCount1,
  });

  // Case 2: status === 'Void' filtering even if isVoid flag was omitted
  const statusVoidInvoices: Invoice[] = [
    createMockInvoice({ id: 'inv6', status: 'Void', isVoid: false }),
    createMockInvoice({ id: 'inv7', status: 'Unpaid', isVoid: false }),
  ];
  const actualCount2 = calculateTotalInvoices(statusVoidInvoices);
  results.push({
    name: 'Excludes invoices with status: Void',
    passed: actualCount2 === 1,
    expected: 1,
    actual: actualCount2,
  });

  // Case 3: Invoices across Unpaid, Partially Paid, Paid, Overdue all counted
  const allStatuses: Invoice[] = [
    createMockInvoice({ id: 'inv8', status: 'Unpaid' }),
    createMockInvoice({ id: 'inv9', status: 'Partially Paid' }),
    createMockInvoice({ id: 'inv10', status: 'Paid' }),
  ];
  const actualCount3 = calculateTotalInvoices(allStatuses);
  results.push({
    name: 'Includes all active invoices across Unpaid, Partially Paid, and Paid statuses',
    passed: actualCount3 === 3,
    expected: 3,
    actual: actualCount3,
  });

  // Case 4: Voiding an invoice decrements Total Invoices count
  const preVoid = [
    createMockInvoice({ id: 'inv11', isVoid: false }),
    createMockInvoice({ id: 'inv12', isVoid: false }),
  ];
  const postVoid = [
    createMockInvoice({ id: 'inv11', isVoid: false }),
    createMockInvoice({ id: 'inv12', isVoid: true, status: 'Void' }),
  ];
  const beforeCount = calculateTotalInvoices(preVoid);
  const afterCount = calculateTotalInvoices(postVoid);
  results.push({
    name: 'Voiding an invoice decrements Total Invoices by exactly 1',
    passed: beforeCount === 2 && afterCount === 1,
    expected: '2 -> 1',
    actual: `${beforeCount} -> ${afterCount}`,
  });

  // Case 5: Empty and corrupted records
  const corruptedInvoices = [
    createMockInvoice({ id: 'inv13', isVoid: false }),
    null as any,
    undefined as any,
    { id: '', totalAmount: 5000 } as any,
  ];
  const actualCount5 = calculateTotalInvoices(corruptedInvoices);
  results.push({
    name: 'Ignores invalid/empty invoice records',
    passed: actualCount5 === 1,
    expected: 1,
    actual: actualCount5,
  });

  if (customInvoices) {
    const customCount = calculateTotalInvoices(customInvoices);
    const expected = customInvoices.filter(i => i && i.id && !i.isVoid && i.status !== 'Void').length;
    results.push({
      name: 'Evaluates provided custom invoices collection correctly',
      passed: customCount === expected,
      expected,
      actual: customCount,
    });
  }

  const passedTests = results.filter(r => r.passed).length;
  return {
    suiteName: 'Total Invoices Calculation',
    passed: passedTests === results.length,
    totalTests: results.length,
    passedTests,
    failedTests: results.length - passedTests,
    results,
  };
}

// ---------------------------------------------------------------------------
// 4. Total Payments Test Suite
// Business Rule: Total Payments = SUM(amount of all valid payments where isVoid !== true)
// ---------------------------------------------------------------------------
export function testTotalPaymentsCalculation(customPayments?: Payment[]): TestSuiteResult {
  const results: TestCaseResult[] = [];

  // Case 1: isVoid filtering (void / reversed payments excluded)
  const paymentsWithVoid: Payment[] = [
    createMockPayment({ id: 'p1', amount: 15000, isVoid: false }),
    createMockPayment({ id: 'p2', amount: 25000, isVoid: false }),
    createMockPayment({ id: 'p3', amount: 50000, isVoid: true }), // Excluded!
  ];
  const actualTotal1 = calculateTotalPayments(paymentsWithVoid);
  results.push({
    name: 'Excludes void/reversed payments (isVoid: true)',
    passed: actualTotal1 === 40000,
    expected: 40000,
    actual: actualTotal1,
  });

  // Case 2: Multiple payments for the same invoice are both summed
  const multiPaymentsForOneInvoice: Payment[] = [
    createMockPayment({ id: 'p4', invoiceId: 'inv_100', amount: 10000, isVoid: false }),
    createMockPayment({ id: 'p5', invoiceId: 'inv_100', amount: 15000, isVoid: false }),
    createMockPayment({ id: 'p6', invoiceId: 'inv_100', amount: 25000, isVoid: false }),
  ];
  const actualTotal2 = calculateTotalPayments(multiPaymentsForOneInvoice);
  results.push({
    name: 'Correctly sums multiple installments for the same invoice',
    passed: actualTotal2 === 50000,
    expected: 50000,
    actual: actualTotal2,
  });

  // Case 3: Reversing/voiding a payment reduces Total Payments by payment amount
  const preReversal = [
    createMockPayment({ id: 'p7', amount: 20000, isVoid: false }),
    createMockPayment({ id: 'p8', amount: 10000, isVoid: false }),
  ];
  const postReversal = [
    createMockPayment({ id: 'p7', amount: 20000, isVoid: false }),
    createMockPayment({ id: 'p8', amount: 10000, isVoid: true }),
  ];
  const totalBefore = calculateTotalPayments(preReversal);
  const totalAfter = calculateTotalPayments(postReversal);
  results.push({
    name: 'Reversing a payment decreases Total Payments by the exact amount',
    passed: totalBefore === 30000 && totalAfter === 20000,
    expected: '30000 -> 20000',
    actual: `${totalBefore} -> ${totalAfter}`,
  });

  // Case 4: Numeric resilience (string amounts, zero amounts, undefined amounts)
  const resilientPayments: any[] = [
    createMockPayment({ id: 'p9', amount: 10000 }),
    { id: 'p10', amount: '5000', isVoid: false },
    { id: 'p11', amount: 0, isVoid: false },
    { id: 'p12', amount: null, isVoid: false },
    { id: 'p13', amount: -500, isVoid: false }, // Negative payment ignored
    null,
  ];
  const actualTotal4 = calculateTotalPayments(resilientPayments);
  results.push({
    name: 'Safely parses numeric amounts without NaN or negative errors',
    passed: actualTotal4 === 15000,
    expected: 15000,
    actual: actualTotal4,
  });

  if (customPayments) {
    const customTotal = calculateTotalPayments(customPayments);
    const expected = customPayments
      .filter(p => p && p.id && !p.isVoid)
      .reduce((sum, p) => sum + (Number(p.amount) > 0 ? Number(p.amount) : 0), 0);
    results.push({
      name: 'Evaluates provided custom payments collection correctly',
      passed: customTotal === expected,
      expected,
      actual: customTotal,
    });
  }

  const passedTests = results.filter(r => r.passed).length;
  return {
    suiteName: 'Total Payments Calculation',
    passed: passedTests === results.length,
    totalTests: results.length,
    passedTests,
    failedTests: results.length - passedTests,
    results,
  };
}

// ---------------------------------------------------------------------------
// 5. Total Outstanding Test Suite
// Business Rule:
// For every valid invoice (where isVoid !== true and status !== 'Void'):
//   Invoice Paid Amount = SUM(all valid payments belonging to that invoice where isVoid !== true)
//   Invoice Outstanding = Math.max(0, Invoice Total Amount - Invoice Paid Amount)
// Total Outstanding = SUM(all valid invoice outstanding amounts)
// ---------------------------------------------------------------------------
export function testTotalOutstandingCalculation(
  customInvoices?: Invoice[],
  customPayments?: Payment[]
): TestSuiteResult {
  const results: TestCaseResult[] = [];

  // Case 1: Multi-payment summation on a single invoice
  // Invoice: 50,000 AFN
  // Payments: 10,000 + 15,000 + 5,000 = 30,000 AFN
  // Expected Outstanding: 20,000 AFN
  const invMulti = createMockInvoice({ id: 'inv_multi_1', totalAmount: 50000 });
  const paysMulti = [
    createMockPayment({ id: 'pm1', invoiceId: 'inv_multi_1', amount: 10000, isVoid: false }),
    createMockPayment({ id: 'pm2', invoiceId: 'inv_multi_1', amount: 15000, isVoid: false }),
    createMockPayment({ id: 'pm3', invoiceId: 'inv_multi_1', amount: 5000, isVoid: false }),
  ];
  const outstanding1 = calculateTotalOutstanding([invMulti], paysMulti);
  results.push({
    name: 'Correctly sums multi-payment installments for a single invoice',
    passed: outstanding1 === 20000,
    expected: 20000,
    actual: outstanding1,
    details: { invoiceTotal: 50000, paidSum: 30000, remainingExpected: 20000 },
  });

  // Case 2: isVoid payment filtering (void payments must NOT reduce outstanding balance)
  // Invoice: 40,000 AFN
  // Payment 1: 15,000 AFN (valid)
  // Payment 2: 25,000 AFN (isVoid: true)
  // Expected Outstanding: 40,000 - 15,000 = 25,000 AFN
  const invVoidPay = createMockInvoice({ id: 'inv_vp_1', totalAmount: 40000 });
  const paysVoidPay = [
    createMockPayment({ id: 'pv1', invoiceId: 'inv_vp_1', amount: 15000, isVoid: false }),
    createMockPayment({ id: 'pv2', invoiceId: 'inv_vp_1', amount: 25000, isVoid: true }),
  ];
  const outstanding2 = calculateTotalOutstanding([invVoidPay], paysVoidPay);
  results.push({
    name: 'Void payments (isVoid: true) do not reduce invoice outstanding balance',
    passed: outstanding2 === 25000,
    expected: 25000,
    actual: outstanding2,
    details: { invoiceTotal: 40000, validPaid: 15000, voidPaid: 25000, remainingExpected: 25000 },
  });

  // Case 3: isVoid invoice filtering (void invoices do NOT contribute to Total Outstanding)
  // Invoice 1: 100,000 AFN (isVoid: false, unpaid) -> 100,000 outstanding
  // Invoice 2: 200,000 AFN (isVoid: true, unpaid)  -> 0 outstanding (excluded!)
  // Invoice 3: 50,000 AFN (status: 'Void', unpaid) -> 0 outstanding (excluded!)
  const invWithVoid = [
    createMockInvoice({ id: 'inv_valid', totalAmount: 100000, isVoid: false }),
    createMockInvoice({ id: 'inv_void_1', totalAmount: 200000, isVoid: true }),
    createMockInvoice({ id: 'inv_void_2', totalAmount: 50000, status: 'Void' }),
  ];
  const outstanding3 = calculateTotalOutstanding(invWithVoid, []);
  results.push({
    name: 'Void invoices (isVoid: true or status: Void) do not contribute to Total Outstanding',
    passed: outstanding3 === 100000,
    expected: 100000,
    actual: outstanding3,
    details: { validTotal: 100000, voidTotalIgnored: 250000 },
  });

  // Case 4: Fully paid invoices contribute exactly 0 to Total Outstanding
  // Invoice 1: 30,000 AFN, paid 30,000 AFN -> 0
  // Invoice 2: 60,000 AFN, paid 20,000 AFN -> 40,000
  // Expected Total Outstanding: 40,000 AFN
  const invFullyPaid = [
    createMockInvoice({ id: 'inv_full', totalAmount: 30000, status: 'Paid' }),
    createMockInvoice({ id: 'inv_part', totalAmount: 60000, status: 'Partially Paid' }),
  ];
  const paysFullyPaid = [
    createMockPayment({ id: 'p_full_1', invoiceId: 'inv_full', amount: 30000 }),
    createMockPayment({ id: 'p_part_1', invoiceId: 'inv_part', amount: 20000 }),
  ];
  const outstanding4 = calculateTotalOutstanding(invFullyPaid, paysFullyPaid);
  results.push({
    name: 'Fully paid invoices contribute exactly 0 to Total Outstanding',
    passed: outstanding4 === 40000,
    expected: 40000,
    actual: outstanding4,
  });

  // Case 5: Overpayment clamping: Negative outstanding clamped to 0
  // Invoice: 50,000 AFN
  // Payments: 60,000 AFN (e.g. overpayment or data anomaly)
  // Math.max(0, 50,000 - 60,000) = 0
  // Another invoice: 20,000 AFN, unpaid.
  // Total Outstanding must be 20,000 AFN (the overpayment must NOT reduce other invoices' balances!)
  const invOverpaid = [
    createMockInvoice({ id: 'inv_over', totalAmount: 50000 }),
    createMockInvoice({ id: 'inv_other', totalAmount: 20000 }),
  ];
  const paysOverpaid = [
    createMockPayment({ id: 'p_over_1', invoiceId: 'inv_over', amount: 60000 }),
  ];
  const outstanding5 = calculateTotalOutstanding(invOverpaid, paysOverpaid);
  results.push({
    name: 'Clamps negative outstanding per invoice to 0 and avoids cross-invoice bleed',
    passed: outstanding5 === 20000,
    expected: 20000,
    actual: outstanding5,
    details: {
      invOverOutstanding: 'Math.max(0, 50000 - 60000) = 0',
      invOtherOutstanding: 20000,
      totalExpected: 20000,
    },
  });

  // Case 6: Fallback matching via billNumber when invoiceId is missing
  const invBillMatch = createMockInvoice({ id: 'inv_bm_1', billNumber: 'ST-5555', totalAmount: 75000 });
  const payBillMatch = [
    createMockPayment({ id: 'p_bm_1', invoiceId: '', billNumber: 'ST-5555', amount: 25000 }),
  ];
  const outstanding6 = calculateTotalOutstanding([invBillMatch], payBillMatch);
  results.push({
    name: 'Supports relational fallback matching by billNumber',
    passed: outstanding6 === 50000,
    expected: 50000,
    actual: outstanding6,
  });

  // Case 7: Optional custom invoices and payments
  if (customInvoices && customPayments) {
    const customResult = calculateTotalOutstanding(customInvoices, customPayments);
    results.push({
      name: 'Evaluates provided custom collections correctly',
      passed: typeof customResult === 'number' && !isNaN(customResult) && customResult >= 0,
      expected: 'Non-negative finite number',
      actual: customResult,
    });
  }

  const passedTests = results.filter(r => r.passed).length;
  return {
    suiteName: 'Total Outstanding Calculation',
    passed: passedTests === results.length,
    totalTests: results.length,
    passedTests,
    failedTests: results.length - passedTests,
    results,
  };
}

// ---------------------------------------------------------------------------
// 6. Integrated Scenario Test Suite
// Verifies all 5 KPIs simultaneously on a complex mixed realistic dataset
// ---------------------------------------------------------------------------
export function testIntegratedOrganizationKpis(): TestSuiteResult {
  const results: TestCaseResult[] = [];

  // Build a complete representative organization dataset
  const users: UserProfile[] = [
    createMockUser({ id: 'u1', name: 'Admin', role: 'super_admin', status: 'active' }),
    createMockUser({ id: 'u2', name: 'Manager', role: 'invoice_manager', status: 'active' }),
    createMockUser({ id: 'u3', name: 'Collector', role: 'payment_collector', status: 'suspended' }),
    createMockUser({ id: 'u4', name: 'Pending User', role: 'customer', status: 'pending' }),
  ]; // Total Users: 4

  const customers: Customer[] = [
    createMockCustomer({ id: 'c1', name: 'Active Cust 1', isArchived: false }),
    createMockCustomer({ id: 'c2', name: 'Active Cust 2' }), // isArchived undefined -> active
    createMockCustomer({ id: 'c3', name: 'Archived Cust', isArchived: true }), // Excluded!
  ]; // Total Customers: 2

  const invoices: Invoice[] = [
    createMockInvoice({ id: 'inv1', billNumber: 'ST-101', totalAmount: 100000, status: 'Partially Paid', isVoid: false }),
    createMockInvoice({ id: 'inv2', billNumber: 'ST-102', totalAmount: 50000, status: 'Paid', isVoid: false }),
    createMockInvoice({ id: 'inv3', billNumber: 'ST-103', totalAmount: 30000, status: 'Unpaid', isVoid: false }),
    createMockInvoice({ id: 'inv4', billNumber: 'ST-104', totalAmount: 20000, status: 'Void', isVoid: true }), // Excluded!
  ]; // Total Invoices: 3 (100k + 50k + 30k)

  const payments: Payment[] = [
    // On inv1 (100,000 total): multi-payments
    createMockPayment({ id: 'p1', invoiceId: 'inv1', billNumber: 'ST-101', amount: 30000, isVoid: false }),
    createMockPayment({ id: 'p2', invoiceId: 'inv1', billNumber: 'ST-101', amount: 20000, isVoid: false }),
    // Void payment on inv1 (must be excluded!):
    createMockPayment({ id: 'p3', invoiceId: 'inv1', billNumber: 'ST-101', amount: 40000, isVoid: true }),
    // On inv2 (50,000 total): fully paid
    createMockPayment({ id: 'p4', invoiceId: 'inv2', billNumber: 'ST-102', amount: 50000, isVoid: false }),
    // Void payment on void invoice inv4:
    createMockPayment({ id: 'p5', invoiceId: 'inv4', billNumber: 'ST-104', amount: 10000, isVoid: true }),
  ];
  // Valid payments: p1 (30k) + p2 (20k) + p4 (50k) = 100,000 AFN
  // Total Outstanding calculation:
  // inv1: total 100,000 - valid paid (30k + 20k = 50,000) = 50,000 AFN
  // inv2: total 50,000 - valid paid (50,000) = 0 AFN
  // inv3: total 30,000 - valid paid (0) = 30,000 AFN
  // inv4: void -> ignored
  // Total Outstanding = 50,000 + 0 + 30,000 = 80,000 AFN

  const kpis = calculateOrganizationKPIs({ users, customers, invoices, payments });

  results.push({
    name: 'Integrated KPI 1: Total Users (expect 4)',
    passed: kpis.totalUsersCount === 4,
    expected: 4,
    actual: kpis.totalUsersCount,
  });

  results.push({
    name: 'Integrated KPI 2: Total Customers (expect 2 active, 1 archived excluded)',
    passed: kpis.totalCustomersCount === 2,
    expected: 2,
    actual: kpis.totalCustomersCount,
  });

  results.push({
    name: 'Integrated KPI 3: Total Invoices (expect 3 valid, 1 void excluded)',
    passed: kpis.totalInvoicesCount === 3,
    expected: 3,
    actual: kpis.totalInvoicesCount,
  });

  results.push({
    name: 'Integrated KPI 4: Total Payments (expect 100,000 AFN, 50,000 void excluded)',
    passed: kpis.totalPaymentsAmount === 100000,
    expected: 100000,
    actual: kpis.totalPaymentsAmount,
  });

  results.push({
    name: 'Integrated KPI 5: Total Outstanding (expect 80,000 AFN)',
    passed: kpis.totalOutstandingAmount === 80000,
    expected: 80000,
    actual: kpis.totalOutstandingAmount,
  });

  const passedTests = results.filter(r => r.passed).length;
  return {
    suiteName: 'Integrated Organization KPIs Scenario',
    passed: passedTests === results.length,
    totalTests: results.length,
    passedTests,
    failedTests: results.length - passedTests,
    results,
  };
}

/**
 * Suite 7: DashboardView Calculation Functions Verification
 * Verifies that the functions implemented directly in DashboardView strictly satisfy
 * isVoid filtering, isArchived exclusion, multi-payment summing, and 'AFN' label.
 */
export function testDashboardViewCalculationFunctions(): TestSuiteResult {
  const results: TestCaseResult[] = [];

  // 1. Users
  const testUsers: UserProfile[] = [
    createMockUser({ id: 'u1', status: 'active' }),
    createMockUser({ id: 'u2', status: 'inactive' }),
    createMockUser({ id: 'u3', status: 'suspended' }),
    createMockUser({ id: 'u4', status: 'pending' }),
    { id: '' } as any,
  ];
  const usersCount = calculateValidUsersCount(testUsers);
  results.push({
    name: 'DashboardView calculateValidUsersCount counts all valid accounts regardless of status',
    passed: usersCount === 4,
    expected: 4,
    actual: usersCount,
  });

  // 2. Customers (isArchived exclusion)
  const testCustomers: Customer[] = [
    createMockCustomer({ id: 'c1', isArchived: false }),
    createMockCustomer({ id: 'c2', isArchived: undefined }),
    createMockCustomer({ id: 'c3', isArchived: true }),
  ];
  const custCount = calculateValidCustomersCount(testCustomers);
  results.push({
    name: 'DashboardView calculateValidCustomersCount excludes archived customers',
    passed: custCount === 2,
    expected: 2,
    actual: custCount,
  });

  // 3. Invoices (isVoid filtering)
  const testInvoices: Invoice[] = [
    createMockInvoice({ id: 'inv1', totalAmount: 10000, isVoid: false }),
    createMockInvoice({ id: 'inv2', totalAmount: 20000, isVoid: true }),
    createMockInvoice({ id: 'inv3', totalAmount: 30000, status: 'Void' }),
    createMockInvoice({ id: 'inv4', totalAmount: 40000, isVoid: undefined, status: 'Unpaid' }),
  ];
  const invCount = calculateValidInvoicesCount(testInvoices);
  results.push({
    name: 'DashboardView calculateValidInvoicesCount excludes isVoid:true and status:Void',
    passed: invCount === 2,
    expected: 2,
    actual: invCount,
  });

  // 4. Payments (isVoid filtering)
  const testPayments: Payment[] = [
    createMockPayment({ id: 'p1', amount: 5000, isVoid: false }),
    createMockPayment({ id: 'p2', amount: 15000, isVoid: true }),
    createMockPayment({ id: 'p3', amount: 25000, isVoid: undefined }),
  ];
  const paymentsAmt = calculateValidPaymentsAmount(testPayments);
  results.push({
    name: 'DashboardView calculateValidPaymentsAmount excludes isVoid payments',
    passed: paymentsAmt === 30000,
    expected: 30000,
    actual: paymentsAmt,
  });

  // 5. Outstanding with multi-payment and negative clamping
  const multiPayInvoices: Invoice[] = [
    createMockInvoice({ id: 'inv_multi', totalAmount: 50000, isVoid: false }),
    createMockInvoice({ id: 'inv_overpaid', totalAmount: 10000, isVoid: false }),
    createMockInvoice({ id: 'inv_void', totalAmount: 40000, isVoid: true }),
  ];
  const multiPayments: Payment[] = [
    createMockPayment({ id: 'p_m1', invoiceId: 'inv_multi', amount: 20000, isVoid: false }),
    createMockPayment({ id: 'p_m2', invoiceId: 'inv_multi', amount: 15000, isVoid: false }),
    createMockPayment({ id: 'p_m3_void', invoiceId: 'inv_multi', amount: 10000, isVoid: true }),
    createMockPayment({ id: 'p_over', invoiceId: 'inv_overpaid', amount: 15000, isVoid: false }), // overpaid by 5000
  ];
  // inv_multi: 50000 - 35000 = 15000
  // inv_overpaid: max(0, 10000 - 15000) = 0
  // inv_void: skipped = 0
  // Total = 15000
  const outstandingAmt = calculateValidOutstandingAmount(multiPayInvoices, multiPayments);
  results.push({
    name: 'DashboardView calculateValidOutstandingAmount sums multi-payments, respects isVoid, and clamps overpaid to 0',
    passed: outstandingAmt === 15000,
    expected: 15000,
    actual: outstandingAmt,
  });

  // 6. AFN currency label verification
  const formatted1 = formatMonetaryAFN(30000, true);
  const formatted2 = formatMonetaryAFN(15000, false);
  const formattedHasAFN = formatted1.includes('AFN') && formatted2.includes('AFN');
  results.push({
    name: "DashboardView formatMonetaryAFN always attaches the 'AFN' currency label",
    passed: formattedHasAFN,
    expected: true,
    actual: formattedHasAFN,
    details: { formatted1, formatted2 },
  });

  // 7. Organization Overview container grid classes verification in DashboardView.tsx
  const dashboardViewSrc = fs.readFileSync(path.join(process.cwd(), 'src/views/DashboardView.tsx'), 'utf8');
  const hasResponsiveGrid = dashboardViewSrc.includes('grid-cols-1 sm:grid-cols-2 lg:grid-cols-5');
  results.push({
    name: "DashboardView Organization Overview container applies 'grid-cols-1 sm:grid-cols-2 lg:grid-cols-5'",
    passed: hasResponsiveGrid,
    expected: true,
    actual: hasResponsiveGrid,
  });

  const passedTests = results.filter(r => r.passed).length;
  return {
    suiteName: 'DashboardView Calculation Functions Verification',
    passed: passedTests === results.length,
    totalTests: results.length,
    passedTests,
    failedTests: results.length - passedTests,
    results,
  };
}

/**
 * Test Suite 8: Invoice Status Breakdown Verification
 * Validates:
 * 1. Categorizes valid invoices (isVoid !== true) into Paid, Partially Paid, Unpaid, and Overdue statuses.
 * 2. Strictly excludes voided invoices (isVoid === true or status === 'Void') from all breakdown categories.
 * 3. Correctly handles multiple payment installments per invoice.
 * 4. Ignores void payments (isVoid: true).
 * 5. Calculates correct counts, percentages, and monetary amounts in AFN.
 * 6. Helper functions match breakdown results.
 * 7. DashboardView layout container applies grid-cols-1 sm:grid-cols-2 lg:grid-cols-4.
 */
export function testInvoiceStatusBreakdown(): TestSuiteResult {
  const results: TestCaseResult[] = [];
  const today = '2026-09-18';

  // Invoices fixture
  const sampleInvoices: Invoice[] = [
    // 1. Paid invoice via status
    createMockInvoice({
      id: 'inv-1',
      billNumber: 'INV-001',
      customerId: 'cust-1',
      totalAmount: 10000,
      totalPaid: 10000,
      remaining: 0,
      status: 'Paid',
      dueDate: '2026-10-01',
      isVoid: false,
    }),

    // 2. Paid invoice via multiple payments
    createMockInvoice({
      id: 'inv-2',
      billNumber: 'INV-002',
      customerId: 'cust-2',
      totalAmount: 20000,
      totalPaid: 0, // will be covered by payments
      remaining: 20000,
      status: 'Unpaid',
      dueDate: '2026-10-01',
      isVoid: false,
    }),

    // 3. Partially Paid invoice
    createMockInvoice({
      id: 'inv-3',
      billNumber: 'INV-003',
      customerId: 'cust-3',
      totalAmount: 15000,
      totalPaid: 5000,
      remaining: 10000,
      status: 'Partially Paid',
      dueDate: '2026-10-15',
      isVoid: false,
    }),

    // 4. Overdue invoice (dueDate earlier than today, unpaid)
    createMockInvoice({
      id: 'inv-4',
      billNumber: 'INV-004',
      customerId: 'cust-4',
      totalAmount: 30000,
      totalPaid: 0,
      remaining: 30000,
      status: 'Unpaid',
      dueDate: '2026-08-01', // past due
      isVoid: false,
    }),

    // 5. Unpaid invoice (future due date, 0 paid)
    createMockInvoice({
      id: 'inv-5',
      billNumber: 'INV-005',
      customerId: 'cust-5',
      totalAmount: 25000,
      totalPaid: 0,
      remaining: 25000,
      status: 'Unpaid',
      dueDate: '2026-11-01',
      isVoid: false,
    }),

    // 6. Void invoice (isVoid: true) - MUST BE STRICTLY EXCLUDED
    createMockInvoice({
      id: 'inv-void-1',
      billNumber: 'INV-VOID-1',
      customerId: 'cust-6',
      totalAmount: 50000,
      totalPaid: 50000,
      remaining: 0,
      status: 'Paid',
      isVoid: true,
    }),

    // 7. Void invoice (status: Void) - MUST BE STRICTLY EXCLUDED
    createMockInvoice({
      id: 'inv-void-2',
      billNumber: 'INV-VOID-2',
      customerId: 'cust-7',
      totalAmount: 40000,
      totalPaid: 0,
      remaining: 40000,
      status: 'Void',
    }),
  ];

  const samplePayments: Payment[] = [
    // Multiple installments for inv-2 covering it completely: 12000 + 8000 = 20000
    createMockPayment({
      id: 'pay-1',
      invoiceId: 'inv-2',
      amount: 12000,
      isVoid: false,
    }),
    createMockPayment({
      id: 'pay-2',
      invoiceId: 'inv-2',
      amount: 8000,
      isVoid: false,
    }),
    // Void payment for inv-5: should NOT make it partially paid
    createMockPayment({
      id: 'pay-void',
      invoiceId: 'inv-5',
      amount: 15000,
      isVoid: true,
    }),
  ];

  const breakdown = calculateInvoiceStatusBreakdown(sampleInvoices, samplePayments, today);

  // 1. Categorization count checks
  results.push({
    name: 'InvoiceStatusBreakdown accurately classifies Paid invoices (2 invoices: 1 via status, 1 via installments)',
    passed: breakdown.paid.count === 2,
    expected: 2,
    actual: breakdown.paid.count,
  });

  results.push({
    name: 'InvoiceStatusBreakdown accurately classifies Partially Paid invoices (1 invoice)',
    passed: breakdown.partiallyPaid.count === 1,
    expected: 1,
    actual: breakdown.partiallyPaid.count,
  });

  results.push({
    name: 'InvoiceStatusBreakdown accurately classifies Overdue invoices based on past dueDate (1 invoice)',
    passed: breakdown.overdue.count === 1,
    expected: 1,
    actual: breakdown.overdue.count,
  });

  results.push({
    name: 'InvoiceStatusBreakdown accurately classifies Unpaid invoices (1 invoice)',
    passed: breakdown.unpaid.count === 1,
    expected: 1,
    actual: breakdown.unpaid.count,
  });

  // 2. Void exclusion check
  results.push({
    name: 'InvoiceStatusBreakdown strictly excludes voided invoices (isVoid: true and status: Void)',
    passed:
      breakdown.totalValidCount === 5 &&
      !breakdown.paid.invoices.some((i) => i.id === 'inv-void-1' || i.id === 'inv-void-2') &&
      !breakdown.unpaid.invoices.some((i) => i.id === 'inv-void-1' || i.id === 'inv-void-2'),
    expected: 5,
    actual: breakdown.totalValidCount,
  });

  // 3. Void payments exclusion check
  results.push({
    name: 'InvoiceStatusBreakdown ignores void payments (isVoid: true) so invoice remains Unpaid',
    passed: breakdown.unpaid.invoices.some((i) => i.id === 'inv-5'),
    expected: true,
    actual: breakdown.unpaid.invoices.some((i) => i.id === 'inv-5'),
  });

  // 4. Financial totals & remaining checks
  results.push({
    name: 'InvoiceStatusBreakdown sums totalValidAmount and totalValidRemaining correctly',
    passed: breakdown.totalValidAmount === 100000 && breakdown.totalValidRemaining === 65000,
    expected: { totalValidAmount: 100000, totalValidRemaining: 65000 },
    actual: { totalValidAmount: breakdown.totalValidAmount, totalValidRemaining: breakdown.totalValidRemaining },
  });

  // 5. Percentages check (2/5 = 40%, 1/5 = 20% each)
  results.push({
    name: 'InvoiceStatusBreakdown computes accurate percentage distribution',
    passed:
      breakdown.paid.percentage === 40 &&
      breakdown.partiallyPaid.percentage === 20 &&
      breakdown.unpaid.percentage === 20 &&
      breakdown.overdue.percentage === 20,
    expected: { paid: 40, partial: 20, unpaid: 20, overdue: 20 },
    actual: {
      paid: breakdown.paid.percentage,
      partial: breakdown.partiallyPaid.percentage,
      unpaid: breakdown.unpaid.percentage,
      overdue: breakdown.overdue.percentage,
    },
  });

  // 6. Individual helper functions test
  const paidCount = calculatePaidInvoicesCount(sampleInvoices, samplePayments);
  const partialCount = calculatePartiallyPaidInvoicesCount(sampleInvoices, samplePayments);
  const unpaidCount = calculateUnpaidInvoicesCount(sampleInvoices, samplePayments);
  const overdueCount = calculateOverdueInvoicesCount(sampleInvoices, samplePayments, today);
  results.push({
    name: 'Individual calculation helper functions match breakdown counts',
    passed: paidCount === 2 && partialCount === 1 && unpaidCount === 1 && overdueCount === 1,
    expected: { paid: 2, partial: 1, unpaid: 1, overdue: 1 },
    actual: { paid: paidCount, partial: partialCount, unpaid: unpaidCount, overdue: overdueCount },
  });

  // 7. Component container & responsive grid verification in DashboardView.tsx
  const dashboardViewSrc = fs.readFileSync(path.join(process.cwd(), 'src/views/DashboardView.tsx'), 'utf8');
  const hasBreakdownGrid = dashboardViewSrc.includes('grid-cols-1 sm:grid-cols-2 lg:grid-cols-4');
  const hasBreakdownComponent = dashboardViewSrc.includes('export const InvoiceStatusBreakdown');
  results.push({
    name: 'DashboardView exports InvoiceStatusBreakdown and defines responsive 4-column grid',
    passed: hasBreakdownGrid && hasBreakdownComponent,
    expected: true,
    actual: hasBreakdownGrid && hasBreakdownComponent,
  });

  const passedTests = results.filter((r) => r.passed).length;
  return {
    suiteName: 'Invoice Status Breakdown Verification',
    passed: passedTests === results.length,
    totalTests: results.length,
    passedTests,
    failedTests: results.length - passedTests,
    results,
  };
}

// ---------------------------------------------------------------------------
// Master Runner: Executes All KPI Test Suites
// ---------------------------------------------------------------------------
export function runAllOrganizationKpiTests(options?: {
  silent?: boolean;
}): AllKpiTestsSummary {
  const silent = options?.silent ?? false;

  const usersSuite = testTotalUsersCalculation();
  const customersSuite = testTotalCustomersCalculation();
  const invoicesSuite = testTotalInvoicesCalculation();
  const paymentsSuite = testTotalPaymentsCalculation();
  const outstandingSuite = testTotalOutstandingCalculation();
  const integratedSuite = testIntegratedOrganizationKpis();
  const dashboardViewSuite = testDashboardViewCalculationFunctions();
  const invoiceBreakdownSuite = testInvoiceStatusBreakdown();

  const suites: Record<string, TestSuiteResult> = {
    users: usersSuite,
    customers: customersSuite,
    invoices: invoicesSuite,
    payments: paymentsSuite,
    outstanding: outstandingSuite,
    integrated: integratedSuite,
    dashboardView: dashboardViewSuite,
    invoiceBreakdown: invoiceBreakdownSuite,
  };

  const suiteList = Object.values(suites);
  const totalSuites = suiteList.length;
  const passedSuites = suiteList.filter(s => s.passed).length;
  const failedSuites = totalSuites - passedSuites;

  const totalTests = suiteList.reduce((sum, s) => sum + s.totalTests, 0);
  const passedTests = suiteList.reduce((sum, s) => sum + s.passedTests, 0);
  const failedTests = totalTests - passedTests;
  const passed = failedSuites === 0;

  if (!silent) {
    console.log('===============================================================');
    console.log('       ORGANIZATION KPIS VERIFICATION TEST SUITE RESULTS       ');
    console.log('===============================================================');
    for (const suite of suiteList) {
      const suiteSymbol = suite.passed ? '✓ PASS' : '✗ FAIL';
      console.log(`\n[${suiteSymbol}] ${suite.suiteName} (${suite.passedTests}/${suite.totalTests} passed)`);
      for (const t of suite.results) {
        const itemSymbol = t.passed ? '  ✓' : '  ✗';
        console.log(`${itemSymbol} ${t.name}`);
        if (!t.passed) {
          console.log(`     Expected: ${JSON.stringify(t.expected)}, Actual: ${JSON.stringify(t.actual)}`);
        }
      }
    }
    console.log('\n---------------------------------------------------------------');
    console.log(`TOTAL: ${passedSuites}/${totalSuites} Suites Passed, ${passedTests}/${totalTests} Tests Passed`);
    console.log(`OVERALL STATUS: ${passed ? 'ALL TESTS PASSED' : 'SOME TESTS FAILED'}`);
    console.log('===============================================================\n');
  }

  return {
    passed,
    totalSuites,
    passedSuites,
    failedSuites,
    totalTests,
    passedTests,
    failedTests,
    suites,
  };
}

// Self-executing if run directly via tsx / node
if (import.meta.url === `file://${process.argv[1]}`) {
  const summary = runAllOrganizationKpiTests();
  process.exit(summary.passed ? 0 : 1);
}
