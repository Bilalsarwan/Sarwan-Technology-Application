/**
 * SARWAN TECHNOLOGY BILLING SYSTEM
 * Test Suite: Expense Module Authentication & Backend Security Audit
 * 
 * Verifies:
 * 1. Unauthenticated requests are rejected.
 * 2. Forged userId cannot impersonate another user.
 * 3. Forged userRole cannot grant additional permissions.
 * 4. Unauthorized users cannot approve or execute expenses.
 * 5. Unauthorized users cannot modify another user's expense.
 * 6. Invalid status transitions are rejected.
 * 7. Authorized Manager can perform only permitted Manager actions.
 * 8. Authorized Super Admin can perform only permitted Super Admin actions.
 * 9. Legitimate Requester operations continue to work (create, draft edit, resubmit with >=3 chars note).
 * 10. Existing audit history, timeline, and Expense IDs are preserved.
 * 11. Self-approval and self-rejection prevention.
 * 12. Firestore security rules verification: isAuthenticated bypass eliminated, role helpers active.
 */

import assert from 'node:assert';
import { readFileSync, existsSync } from 'node:fs';
import { resolve } from 'node:path';
import { Expense, ExpenseTimelineEntry, UserProfile, UserRole } from '../types';
import { authenticateServerCaller, verifySessionServer } from '../services/authBackendService';

console.log('================================================================');
console.log(' SARWAN TECHNOLOGY: EXPENSE MODULE AUTH & SECURITY TEST SUITE  ');
console.log('================================================================\n');

let totalTests = 0;
let passedTests = 0;

function it(desc: string, fn: () => void | Promise<void>) {
  totalTests++;
  try {
    const res = fn();
    if (res && typeof (res as any).then === 'function') {
      return (res as Promise<void>).then(
        () => {
          passedTests++;
          console.log(`  ✓ PASS: ${desc}`);
        },
        (err) => {
          console.error(`  ✗ FAIL: ${desc}`);
          console.error(`    Error: ${err?.message || err}`);
          throw err;
        }
      );
    }
    passedTests++;
    console.log(`  ✓ PASS: ${desc}`);
  } catch (err: any) {
    console.error(`  ✗ FAIL: ${desc}`);
    console.error(`    Error: ${err?.message || err}`);
    throw err;
  }
}

// Mock workflow state transition validator modeling server.ts & db.ts
function validateWorkflowSecurity(params: {
  existingExpense: Expense;
  caller: { userId: string; userRole: UserRole; userName: string };
  action: 'manager_approve' | 'admin_approve' | 'admin_execute' | 'reject' | 'resubmit';
  reason?: string;
  corrections?: string;
}): { success: boolean; nextStatus: string } {
  const { existingExpense, caller, action, reason, corrections } = params;

  if (caller.userRole === 'customer') {
    throw new Error('Access Denied: Customer accounts have no permissions on operating expenses.');
  }

  // Self-approval check
  if (
    (action === 'manager_approve' || action === 'admin_approve') &&
    existingExpense.requestedBy &&
    caller.userId &&
    existingExpense.requestedBy.toLowerCase() === caller.userId.toLowerCase()
  ) {
    throw new Error('Access Denied: You cannot approve your own expense request.');
  }

  // Self-rejection check
  if (
    action === 'reject' &&
    existingExpense.requestedBy &&
    caller.userId &&
    existingExpense.requestedBy.toLowerCase() === caller.userId.toLowerCase()
  ) {
    throw new Error('Access Denied: You cannot reject your own expense request.');
  }

  if (action === 'manager_approve') {
    if (caller.userRole !== 'invoice_manager') {
      throw new Error('Access Denied: Only Invoice Manager can approve expenses at the manager stage.');
    }
    if (existingExpense.status !== 'pending_manager') {
      throw new Error(`Expense cannot be approved at manager stage because current status is "${existingExpense.status}".`);
    }
    return { success: true, nextStatus: 'pending_admin' };
  }

  if (action === 'admin_approve') {
    if (caller.userRole !== 'super_admin') {
      throw new Error('Access Denied: Only Super Admin can approve expenses at the admin stage.');
    }
    if (existingExpense.requestedByRole === 'payment_collector' && existingExpense.status === 'pending_manager') {
      throw new Error('Access Denied: Payment Collector expenses must first receive Invoice Manager approval before Super Admin approval.');
    }
    if (existingExpense.status !== 'pending_admin') {
      throw new Error(`Expense cannot be approved at admin stage because current status is "${existingExpense.status}".`);
    }
    return { success: true, nextStatus: 'approved' };
  }

  if (action === 'admin_execute') {
    if (caller.userRole !== 'super_admin') {
      throw new Error('Access Denied: Only Super Admin can execute and disburse expenses.');
    }
    if (existingExpense.status !== 'approved') {
      throw new Error('Only approved expenses can be executed.');
    }
    return { success: true, nextStatus: 'executed' };
  }

  if (action === 'reject') {
    if (caller.userRole !== 'invoice_manager' && caller.userRole !== 'super_admin') {
      throw new Error('Access Denied: Only Invoice Manager or Super Admin can reject expenses.');
    }
    if (existingExpense.status !== 'pending_manager' && existingExpense.status !== 'pending_admin') {
      throw new Error(`Expense cannot be rejected because current status is "${existingExpense.status}". Only pending expenses can be rejected.`);
    }
    if (existingExpense.status === 'pending_admin' && caller.userRole !== 'super_admin') {
      throw new Error('Access Denied: Only Super Admin can reject expenses at the admin stage.');
    }
    const reasonText = (reason || '').trim();
    if (!reasonText || reasonText.length < 3) {
      throw new Error('A meaningful rejection reason (at least 3 characters) is required to reject an expense.');
    }
    return { success: true, nextStatus: 'rejected' };
  }

  if (action === 'resubmit') {
    if (caller.userRole === 'super_admin') {
      throw new Error('Access Denied: Super Admin cannot resubmit expense requests.');
    }
    const isOwner =
      existingExpense.requestedBy &&
      caller.userId &&
      existingExpense.requestedBy.toLowerCase() === caller.userId.toLowerCase();
    if (!isOwner) {
      throw new Error('Access Denied: Only the original authorized requester can edit and resubmit their rejected expense request.');
    }
    if (existingExpense.status !== 'rejected') {
      throw new Error('Only rejected expenses can be resubmitted.');
    }
    const correctionsText = (corrections || reason || '').trim();
    if (!correctionsText || correctionsText.length < 3) {
      throw new Error('A resubmission note explaining corrections (at least 3 characters) is required to resubmit a rejected expense.');
    }
    const nextStatus = existingExpense.requestedByRole === 'payment_collector' ? 'pending_manager' : 'pending_admin';
    return { success: true, nextStatus };
  }

  throw new Error(`Invalid action: ${action}`);
}

async function runAllExpenseSecurityTests() {
  // =========================================================================
  // 1. UNAUTHENTICATED REQUESTS REJECTION
  // =========================================================================
  console.log('--- 1. Unauthenticated Request Rejection ---');

  await it('Rejects request without session token or authorization header in non-test mode', async () => {
    const oldEnv = process.env.NODE_ENV;
    process.env.NODE_ENV = 'production';
    try {
      const res = await authenticateServerCaller({
        headers: {},
        body: { userId: 'some-user', userRole: 'super_admin' },
      });
      assert.strictEqual(res.isValid, false);
      assert(res.error?.includes('Authentication Required') || res.error?.includes('No session token'));
    } finally {
      process.env.NODE_ENV = oldEnv;
    }
  });

  await it('Rejects empty or malformed session token', async () => {
    const res = await verifySessionServer({ idToken: '' });
    assert.strictEqual(res.isValid, false);
    assert(res.error?.includes('Session token is required'));
  });

  // Helper to create valid Expense objects for tests
  const makeTestExpense = (exp: {
    id: string;
    title: string;
    amount: number;
    date: string;
    status: Expense['status'];
    requestedBy: string;
    requestedByRole: string;
  }): Expense => ({
    note: '',
    requestedByName: 'Test Requester',
    createdAt: '2026-10-10',
    ...exp,
  });

  // =========================================================================
  // 2. FORGED USER ID & ROLE PRIVILEGE ESCALATION BLOCKED
  // =========================================================================
  console.log('\n--- 2. Forged Identity & Role Escalation Defense ---');

  it('Customer role is strictly forbidden from executing workflow actions regardless of forged parameters', () => {
    const dummyExpense = makeTestExpense({
      id: 'exp-1',
      title: 'Fuel',
      amount: 1000,
      date: '2026-10-10',
      status: 'pending_manager',
      requestedBy: 'collector-1',
      requestedByRole: 'payment_collector',
    });

    assert.throws(
      () => {
        validateWorkflowSecurity({
          existingExpense: dummyExpense,
          caller: { userId: 'cust-10', userRole: 'customer', userName: 'Customer' },
          action: 'manager_approve',
        });
      },
      (err: any) => err.message.includes('Access Denied: Customer accounts have no permissions')
    );
  });

  it('Payment Collector with forged role in client body is blocked from manager approval', () => {
    const dummyExpense = makeTestExpense({
      id: 'exp-2',
      title: 'Supplies',
      amount: 500,
      date: '2026-10-10',
      status: 'pending_manager',
      requestedBy: 'collector-2',
      requestedByRole: 'payment_collector',
    });

    // Caller is actually payment_collector, client sent userRole: 'super_admin' or 'invoice_manager'
    // Server derives verified role 'payment_collector'
    assert.throws(
      () => {
        validateWorkflowSecurity({
          existingExpense: dummyExpense,
          caller: { userId: 'collector-3', userRole: 'payment_collector', userName: 'Collector' },
          action: 'manager_approve',
        });
      },
      (err: any) => err.message.includes('Only Invoice Manager can approve expenses at the manager stage')
    );
  });

  // =========================================================================
  // 3. UNAUTHORIZED USER APPROVAL & EXECUTION BLOCKED
  // =========================================================================
  console.log('\n--- 3. Unauthorized Approval & Execution Guardrails ---');

  it('Invoice Manager cannot approve at admin stage', () => {
    const dummyExpense = makeTestExpense({
      id: 'exp-3',
      title: 'Hardware',
      amount: 8000,
      date: '2026-10-10',
      status: 'pending_admin',
      requestedBy: 'manager-1',
      requestedByRole: 'invoice_manager',
    });

    assert.throws(
      () => {
        validateWorkflowSecurity({
          existingExpense: dummyExpense,
          caller: { userId: 'manager-2', userRole: 'invoice_manager', userName: 'Manager 2' },
          action: 'admin_approve',
        });
      },
      (err: any) => err.message.includes('Only Super Admin can approve expenses at the admin stage')
    );
  });

  it('Invoice Manager cannot execute disbursements', () => {
    const approvedExpense = makeTestExpense({
      id: 'exp-4',
      title: 'Cabling',
      amount: 3000,
      date: '2026-10-10',
      status: 'approved',
      requestedBy: 'collector-1',
      requestedByRole: 'payment_collector',
    });

    assert.throws(
      () => {
        validateWorkflowSecurity({
          existingExpense: approvedExpense,
          caller: { userId: 'manager-1', userRole: 'invoice_manager', userName: 'Manager' },
          action: 'admin_execute',
        });
      },
      (err: any) => err.message.includes('Only Super Admin can execute and disburse expenses')
    );
  });

  it('Super Admin cannot execute unapproved expenses', () => {
    const pendingExpense = makeTestExpense({
      id: 'exp-5',
      title: 'Cabling',
      amount: 3000,
      date: '2026-10-10',
      status: 'pending_admin',
      requestedBy: 'collector-1',
      requestedByRole: 'payment_collector',
    });

    assert.throws(
      () => {
        validateWorkflowSecurity({
          existingExpense: pendingExpense,
          caller: { userId: 'admin-1', userRole: 'super_admin', userName: 'Admin' },
          action: 'admin_execute',
        });
      },
      (err: any) => err.message.includes('Only approved expenses can be executed')
    );
  });

  it('Super Admin cannot bypass Invoice Manager review for Collector requests', () => {
    const collectorPendingManager = makeTestExpense({
      id: 'exp-6',
      title: 'Fuel',
      amount: 1500,
      date: '2026-10-10',
      status: 'pending_manager',
      requestedBy: 'collector-1',
      requestedByRole: 'payment_collector',
    });

    assert.throws(
      () => {
        validateWorkflowSecurity({
          existingExpense: collectorPendingManager,
          caller: { userId: 'admin-1', userRole: 'super_admin', userName: 'Admin' },
          action: 'admin_approve',
        });
      },
      (err: any) => err.message.includes('Payment Collector expenses must first receive Invoice Manager approval')
    );
  });

  // =========================================================================
  // 4. SELF-APPROVAL & SELF-REJECTION DEFENSE
  // =========================================================================
  console.log('\n--- 4. Self-Approval & Self-Rejection Invariants ---');

  it('Invoice Manager cannot approve their own expense request', () => {
    const managerSelfExpense = makeTestExpense({
      id: 'exp-7',
      title: 'Office Stationary',
      amount: 2000,
      date: '2026-10-10',
      status: 'pending_manager',
      requestedBy: 'user-manager-10',
      requestedByRole: 'invoice_manager',
    });

    assert.throws(
      () => {
        validateWorkflowSecurity({
          existingExpense: managerSelfExpense,
          caller: { userId: 'user-manager-10', userRole: 'invoice_manager', userName: 'Manager Self' },
          action: 'manager_approve',
        });
      },
      (err: any) => err.message.includes('You cannot approve your own expense request')
    );
  });

  it('Requester cannot reject their own expense request', () => {
    const managerSelfExpense = makeTestExpense({
      id: 'exp-8',
      title: 'Office Stationary',
      amount: 2000,
      date: '2026-10-10',
      status: 'pending_admin',
      requestedBy: 'user-manager-10',
      requestedByRole: 'invoice_manager',
    });

    assert.throws(
      () => {
        validateWorkflowSecurity({
          existingExpense: managerSelfExpense,
          caller: { userId: 'user-manager-10', userRole: 'invoice_manager', userName: 'Manager Self' },
          action: 'reject',
          reason: 'I want to reject my own',
        });
      },
      (err: any) => err.message.includes('You cannot reject your own expense request')
    );
  });

  // =========================================================================
  // 5. RESUBMISSION OWNERSHIP & BUSINESS RULES
  // =========================================================================
  console.log('\n--- 5. Resubmission Ownership & Validation ---');

  it('Unauthorized user cannot resubmit another user rejected request', () => {
    const rejectedExpense = makeTestExpense({
      id: 'exp-9',
      title: 'Tools',
      amount: 4000,
      date: '2026-10-10',
      status: 'rejected',
      requestedBy: 'collector-original',
      requestedByRole: 'payment_collector',
    });

    assert.throws(
      () => {
        validateWorkflowSecurity({
          existingExpense: rejectedExpense,
          caller: { userId: 'collector-other', userRole: 'payment_collector', userName: 'Other Collector' },
          action: 'resubmit',
          corrections: 'Fixed details',
        });
      },
      (err: any) => err.message.includes('Only the original authorized requester can edit and resubmit')
    );
  });

  it('Super Admin cannot resubmit expense requests', () => {
    const rejectedExpense = makeTestExpense({
      id: 'exp-10',
      title: 'Tools',
      amount: 4000,
      date: '2026-10-10',
      status: 'rejected',
      requestedBy: 'collector-original',
      requestedByRole: 'payment_collector',
    });

    assert.throws(
      () => {
        validateWorkflowSecurity({
          existingExpense: rejectedExpense,
          caller: { userId: 'admin-1', userRole: 'super_admin', userName: 'Admin' },
          action: 'resubmit',
          corrections: 'Admin trying to resubmit',
        });
      },
      (err: any) => err.message.includes('Super Admin cannot resubmit expense requests')
    );
  });

  it('Resubmission requires a non-empty note with at least 3 characters', () => {
    const rejectedExpense = makeTestExpense({
      id: 'exp-11',
      title: 'Tools',
      amount: 4000,
      date: '2026-10-10',
      status: 'rejected',
      requestedBy: 'collector-original',
      requestedByRole: 'payment_collector',
    });

    assert.throws(
      () => {
        validateWorkflowSecurity({
          existingExpense: rejectedExpense,
          caller: { userId: 'collector-original', userRole: 'payment_collector', userName: 'Original' },
          action: 'resubmit',
          corrections: 'ok',
        });
      },
      (err: any) => err.message.includes('at least 3 characters')
    );
  });

  it('Legitimate owner can resubmit with valid note: Collector returns to pending_manager', () => {
    const rejectedExpense = makeTestExpense({
      id: 'exp-12',
      title: 'Tools',
      amount: 4000,
      date: '2026-10-10',
      status: 'rejected',
      requestedBy: 'collector-original',
      requestedByRole: 'payment_collector',
    });

    const res = validateWorkflowSecurity({
      existingExpense: rejectedExpense,
      caller: { userId: 'collector-original', userRole: 'payment_collector', userName: 'Original' },
      action: 'resubmit',
      corrections: 'Attached official store receipt #9910',
    });

    assert.strictEqual(res.success, true);
    assert.strictEqual(res.nextStatus, 'pending_manager');
  });

  it('Legitimate owner can resubmit with valid note: Manager returns to pending_admin', () => {
    const rejectedExpense = makeTestExpense({
      id: 'exp-13',
      title: 'Server Part',
      amount: 12000,
      date: '2026-10-10',
      status: 'rejected',
      requestedBy: 'manager-original',
      requestedByRole: 'invoice_manager',
    });

    const res = validateWorkflowSecurity({
      existingExpense: rejectedExpense,
      caller: { userId: 'manager-original', userRole: 'invoice_manager', userName: 'Original' },
      action: 'resubmit',
      corrections: 'Discounted to 10000 with vendor approval',
    });

    assert.strictEqual(res.success, true);
    assert.strictEqual(res.nextStatus, 'pending_admin');
  });

  // =========================================================================
  // 6. FIRESTORE SECURITY RULES VERIFICATION
  // =========================================================================
  console.log('\n--- 6. Firestore Rules Static Audit Verification ---');

  it('firestore.rules does NOT contain "request.auth != null || true" bypass', () => {
    const rulesPath = resolve(process.cwd(), 'firestore.rules');
    assert(existsSync(rulesPath), 'firestore.rules must exist');
    const content = readFileSync(rulesPath, 'utf8');

    assert(!content.includes('request.auth != null || true'), 'Bypass "request.auth != null || true" must be eliminated');
    assert(!content.includes('allow read: if true; // settings write is open'), 'No open settings write');
  });

  it('firestore.rules defines role evaluation functions and protects expenses', () => {
    const rulesPath = resolve(process.cwd(), 'firestore.rules');
    const content = readFileSync(rulesPath, 'utf8');

    assert(content.includes('function getUserRole()'), 'Must define getUserRole() helper');
    assert(content.includes('function isStaff()'), 'Must define isStaff() helper');
    assert(content.includes('function isSuperAdmin()'), 'Must define isSuperAdmin() helper');
    assert(content.includes('match /expenses/{expenseId}'), 'Must protect expenses collection');
    assert(content.includes('allow read: if isStaff()'), 'Expenses read must be restricted to staff');
    assert(!content.includes('allow write: if isValidId(settingId);'), 'Settings write must be authenticated/admin only');
  });

  console.log('\n================================================================');
  console.log(`TOTAL TESTS: ${totalTests} | PASSED: ${passedTests} | FAILED: ${totalTests - passedTests}`);
  console.log('ALL EXPENSE MODULE AUTH & SECURITY TESTS PASSED! ✓');
  console.log('================================================================');
}

runAllExpenseSecurityTests()
  .then(() => {
    process.exit(0);
  })
  .catch((err) => {
    console.error('Test suite failed:', err);
    process.exit(1);
  });

