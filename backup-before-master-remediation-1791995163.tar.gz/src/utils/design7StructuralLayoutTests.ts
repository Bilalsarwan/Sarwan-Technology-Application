/**
 * Design #7 Structural Layout & Acceptance Verification Test Suite
 * Tests 1 through 8 corresponding to the Design #7 Layout Update Specification.
 */
import React from 'react';
import { renderToStaticMarkup } from 'react-dom/server';
import { Invoice, InvoiceItem, BusinessSettings } from '../types';
import { DEFAULT_INVOICE_DESIGN } from '../types/invoiceDesign';
import { buildCanonicalInvoiceDocument } from './canonicalInvoiceDocument';
import { calculateInvoicePageChunks, InvoiceTemplate } from '../components/invoice/InvoiceTemplate';
import { resolveCanonicalDocument } from './print';

interface TestResult {
  suite: string;
  name: string;
  passed: boolean;
  error?: string;
}

const results: TestResult[] = [];

function test(suite: string, name: string, fn: () => void) {
  try {
    fn();
    results.push({ suite, name, passed: true });
  } catch (err: any) {
    results.push({ suite, name, passed: false, error: err?.message || String(err) });
  }
}

function expect(condition: boolean, msg: string) {
  if (!condition) throw new Error(msg);
}

export function runDesign7StructuralLayoutTests(): { total: number; passed: number; failed: number } {
  const sampleSettings: BusinessSettings = {
    companyName: 'Sarwan Technology',
    logo: '/sarwan-logo.png',
    logo2: '/dahua-logo.svg',
    phone: '0731339014',
    whatsapp: '0778771020',
    email: 'sarwanelectronic@gmail.com',
    address: 'Kabul, Afghanistan',
    currency: 'AFN',
    invoicePrefix: 'ST-',
    nextInvoiceNumber: 1001,
    invoiceNote: 'Thank you for choosing Sarwan Technology.',
    authorizedEmails: ['admin@sarwantechnology.com'],
    invoiceDesign: {
      ...DEFAULT_INVOICE_DESIGN,
    },
  };

  const baseInvoice: Invoice = {
    id: 'inv-layout-7',
    billNumber: 'ST-1001',
    date: '2026-10-04',
    dueDate: '2026-10-18',
    status: 'Paid',
    totalAmount: 25000,
    totalPaid: 25000,
    remaining: 0,
    note: 'Standard commercial invoice notes.',
    customerId: 'cust-layout-7',
    customerSnapshot: {
      id: 'cust-layout-7',
      name: 'Mohammad Rahim',
      companyName: 'Afghan United Traders',
      phone: '0799887766',
      email: 'customer@afghanunited.af',
      address: 'Dehbori Square, Kabul, Afghanistan',
    },
    companySnapshot: sampleSettings,
    items: [
      {
        sNo: 1,
        description: 'Dahua 4K IP Camera Dome 8MP',
        quantity: 5,
        unitPrice: 5000,
        totalAmount: 25000,
      },
    ],
    assignedCollectorId: 'col-1',
    assignedCollectorName: 'Ahmad Collector',
    createdAt: '2026-10-04T10:00:00Z',
    updatedAt: '2026-10-04T10:00:00Z',
  };

  // ==========================================
  // TEST 1 — ONE ITEM
  // ==========================================
  test('Design #7 Structural Tests', 'TEST 1: One-Item Invoice with page-bottom anchored footer', () => {
    const doc = buildCanonicalInvoiceDocument({ invoice: baseInvoice, settings: sampleSettings });
    expect(doc.items.length === 1, 'Invoice has exactly 1 item');

    const chunks = calculateInvoicePageChunks(doc.items, doc.paperConfig);
    expect(chunks.length === 1, '1-item invoice produces exactly 1 page chunk');

    const markup = renderToStaticMarkup(
      React.createElement(InvoiceTemplate, { document: doc })
    );

    // Section hierarchy verification
    const headerPos = markup.indexOf('id="invoice-header-section"');
    const metaPos = markup.indexOf('id="invoice-title-meta-section"');
    const customerPos = markup.indexOf('id="invoice-customer-section"');
    const tablePos = markup.indexOf('id="invoice-items-table-section"');
    const paymentPos = markup.indexOf('id="invoice-payment-totals-section"');
    const signaturesPos = markup.indexOf('id="invoice-signatures-section"');
    const footerPos = markup.indexOf('id="invoice-footer-section"');

    expect(headerPos !== -1, 'Header section is present');
    expect(metaPos > headerPos, 'Invoice Meta is below Header');
    expect(customerPos > metaPos, 'Customer Information is below Invoice Meta');
    expect(tablePos > customerPos, 'Items Table is below Customer Information');
    expect(paymentPos > tablePos, 'Payment/Totals is below Items Table');
    expect(signaturesPos > paymentPos, 'Signatures is below Payment/Totals');
    expect(footerPos > signaturesPos, 'Footer is below Signatures');

    // Page sheet geometry & footer bottom anchoring
    expect(markup.includes('297mm'), 'Page sheet includes 297mm A4 height');
    expect(markup.includes('margin-top:auto'), 'Footer is bottom-anchored with margin-top: auto');
  });

  // ==========================================
  // TEST 2 — MANY ITEMS
  // ==========================================
  test('Design #7 Structural Tests', 'TEST 2: Multi-Page Invoice with bottom footer on EVERY page', () => {
    // Generate 35 items to span multiple pages
    const multiItems: InvoiceItem[] = Array.from({ length: 35 }, (_, idx) => ({
      sNo: idx + 1,
      description: `Surveillance Component Model #${idx + 1} with high precision optics`,
      quantity: 2,
      unitPrice: 1000,
      totalAmount: 2000,
    }));

    const multiInvoice: Invoice = {
      ...baseInvoice,
      items: multiItems,
      totalAmount: 70000,
      totalPaid: 70000,
    };

    const doc = buildCanonicalInvoiceDocument({ invoice: multiInvoice, settings: sampleSettings });
    const chunks = calculateInvoicePageChunks(doc.items, doc.paperConfig);
    expect(chunks.length >= 2, `Multi-page chunks generated: ${chunks.length}`);

    const markup = renderToStaticMarkup(
      React.createElement(InvoiceTemplate, { document: doc })
    );

    // Count occurrences of page sheets and footers
    const sheetMatches = markup.match(/canonical-invoice-sheet/g) || [];
    const footerMatches = markup.match(/id="invoice-footer-section"/g) || [];

    expect(sheetMatches.length === chunks.length, `Sheet count (${sheetMatches.length}) matches chunk count (${chunks.length})`);
    expect(footerMatches.length === chunks.length, `Every page has its own footer: found ${footerMatches.length} footers for ${chunks.length} pages`);
  });

  // ==========================================
  // TEST 3 — FOOTER COLLISION
  // ==========================================
  test('Design #7 Structural Tests', 'TEST 3: Footer Collision Protection & Row Capacity Limits', () => {
    // Test pagination capacity boundaries
    const single14Items = Array.from({ length: 14 }, (_, idx) => ({
      id: `item-${idx + 1}`,
      description: `Item Row ${idx + 1}`,
      quantity: 1,
      unitPrice: 100,
      totalAmount: 100,
    }));

    const singleChunks = calculateInvoicePageChunks(single14Items as any, { paperSize: 'A4', orientation: 'portrait' });
    expect(singleChunks.length === 1, '14 items safely fit on 1 single page without colliding with footer');

    // 15 items should cleanly paginate to prevent footer collision
    const fifteenItems = Array.from({ length: 15 }, (_, idx) => ({
      id: `item-${idx + 1}`,
      description: `Item Row ${idx + 1}`,
      quantity: 1,
      unitPrice: 100,
      totalAmount: 100,
    }));

    const multiChunks = calculateInvoicePageChunks(fifteenItems as any, { paperSize: 'A4', orientation: 'portrait' });
    expect(multiChunks.length === 2, '15 items paginate to 2 pages to reserve space for payment/totals & signatures');
    expect(multiChunks[1].length <= 10, 'Last page item count is strictly bounded to prevent footer collision');
  });

  // ==========================================
  // TEST 4 — FINAL PAGE
  // ==========================================
  test('Design #7 Structural Tests', 'TEST 4: Final Page contains Payment/Totals -> Signatures -> Footer without overlap', () => {
    const doc = buildCanonicalInvoiceDocument({ invoice: baseInvoice, settings: sampleSettings });
    const markup = renderToStaticMarkup(
      React.createElement(InvoiceTemplate, { document: doc })
    );

    const paymentIdx = markup.indexOf('id="invoice-payment-totals-section"');
    const signaturesIdx = markup.indexOf('id="invoice-signatures-section"');
    const footerIdx = markup.indexOf('id="invoice-footer-section"');

    expect(paymentIdx !== -1, 'Payment/Totals present on final page');
    expect(signaturesIdx !== -1, 'Signatures present on final page');
    expect(footerIdx !== -1, 'Footer present on final page');
    expect(signaturesIdx > paymentIdx, 'Signatures appear after Payment/Totals');
    expect(footerIdx > signaturesIdx, 'Footer appears after Signatures');
  });

  // ==========================================
  // TEST 5 — CUSTOMER INFORMATION
  // ==========================================
  test('Design #7 Structural Tests', 'TEST 5: Customer Information shows ONLY Name, Phone, Company, Address (NO Email)', () => {
    const doc = buildCanonicalInvoiceDocument({ invoice: baseInvoice, settings: sampleSettings });
    const markup = renderToStaticMarkup(
      React.createElement(InvoiceTemplate, { document: doc })
    );

    // Extract customer section
    const customerSecStart = markup.indexOf('id="invoice-customer-section"');
    const customerSecEnd = markup.indexOf('id="invoice-items-table-section"');
    expect(customerSecStart !== -1, 'Customer section found');
    expect(customerSecEnd !== -1, 'Items table section found');
    const customerHtml = markup.slice(customerSecStart, customerSecEnd);

    // Must show:
    expect(customerHtml.includes('Mohammad Rahim'), 'Shows Customer Name');
    expect(customerHtml.includes('0799887766'), 'Shows Customer Phone');
    expect(customerHtml.includes('Afghan United Traders'), 'Shows Customer Company');
    expect(customerHtml.includes('Dehbori Square, Kabul, Afghanistan'), 'Shows Customer Address');

    // Must NOT show:
    expect(!customerHtml.includes('customer@afghanunited.af'), 'Email MUST NOT appear in customer information');
    expect(!customerHtml.includes('Email:'), 'Email label MUST NOT appear in customer information');
    expect(customerHtml.includes('70%'), 'Customer box occupies ~70% width in information row');

    // Verify side-by-side on same row:
    const invoiceBillPos = markup.indexOf('id="invoice-bill-info-box"');
    expect(invoiceBillPos !== -1, 'Invoice Info box found');
    expect(invoiceBillPos < customerSecStart, 'Invoice Info is to the left of Customer Info on the same row');
  });

  // ==========================================
  // TEST 6 — PAYMENT
  // ==========================================
  test('Design #7 Structural Tests', 'TEST 6: Payment Information contains ONLY Total, Received, Remaining, Payment Status and Totals table is removed', () => {
    const doc = buildCanonicalInvoiceDocument({ invoice: baseInvoice, settings: sampleSettings });
    const markup = renderToStaticMarkup(
      React.createElement(InvoiceTemplate, { document: doc })
    );

    // Totals table completely removed
    expect(!markup.includes('id="invoice-grand-total-row"'), 'Separate Grand Total banner is completely removed');
    expect(!markup.includes('Grand Total:'), 'Separate Grand Total table is completely removed');

    const paymentSecStart = markup.indexOf('id="invoice-payment-info-section"');
    const paymentSecEnd = markup.indexOf('id="invoice-signatures-section"');
    expect(paymentSecStart !== -1, 'Payment info section found');
    expect(paymentSecEnd !== -1, 'Signatures section found after payment');
    const paymentHtml = markup.slice(paymentSecStart, paymentSecEnd);

    // Must show:
    expect(paymentHtml.includes('Payment Information'), 'Shows Payment Information header');
    expect(paymentHtml.includes('Total:'), 'Shows Total label');
    expect(paymentHtml.includes('Received:'), 'Shows Received label');
    expect(paymentHtml.includes('Remaining:'), 'Shows Remaining label');
    expect(paymentHtml.includes('Payment Status:'), 'Shows Payment Status label');

    // Must NOT show method:
    expect(!paymentHtml.includes('Payment Method:'), 'Payment Method MUST NOT appear in Payment Information');

    // Payment section occupies 50% width and is right-aligned:
    expect(markup.includes('justify-end'), 'Payment table is right-aligned');
    expect(paymentHtml.includes('50%'), 'Payment section occupies 50% width');
  });

  // ==========================================
  // TEST 7 — FOOTER
  // ==========================================
  test('Design #7 Structural Tests', 'TEST 7: Footer visual changes (No triangles, Thank you remains, Email/WhatsApp/Phone below)', () => {
    const doc = buildCanonicalInvoiceDocument({ invoice: baseInvoice, settings: sampleSettings });
    const markup = renderToStaticMarkup(
      React.createElement(InvoiceTemplate, { document: doc })
    );

    // No triangle flaps in footer
    expect(!markup.includes('Bottom-Left Shape'), 'Bottom-left decorative triangle shape is removed');
    expect(!markup.includes('Bottom-Right Shape'), 'Bottom-right decorative triangle shape is removed');
    expect(!markup.includes('shapeBottomLeft'), 'shapeBottomLeft is not rendered');
    expect(!markup.includes('shapeBottomRight'), 'shapeBottomRight is not rendered');

    // Thank you text remains
    expect(markup.includes('Thank you for your business!'), 'Thank you message is displayed');

    // Email, WhatsApp, and Phone appear
    const footerSecStart = markup.indexOf('id="invoice-footer-section"');
    const footerHtml = markup.slice(footerSecStart);

    expect(footerHtml.includes('sarwanelectronic@gmail.com'), 'Company Email appears in footer');
    expect(footerHtml.includes('0778771020'), 'Company WhatsApp appears in footer');
    expect(footerHtml.includes('0731339014'), 'Company Phone appears in footer');
  });

  // ==========================================
  // TEST 8 — PREVIEW / PDF CONSISTENCY
  // ==========================================
  test('Design #7 Structural Tests', 'TEST 8: Preview and PDF use identical canonical document model and A4 geometry', () => {
    const previewDoc = buildCanonicalInvoiceDocument({ invoice: baseInvoice, settings: sampleSettings });
    const pdfDoc = resolveCanonicalDocument(baseInvoice, { settings: sampleSettings });

    expect(previewDoc.paperConfig.widthMm === 210, 'A4 width is exactly 210mm');
    expect(previewDoc.paperConfig.heightMm === 297, 'A4 height is exactly 297mm');
    expect(pdfDoc.paperConfig.widthMm === 210, 'PDF A4 width is exactly 210mm');
    expect(pdfDoc.paperConfig.heightMm === 297, 'PDF A4 height is exactly 297mm');

    // Model equivalence
    expect(previewDoc.billNumber === pdfDoc.billNumber, 'Invoice numbers match identically');
    expect(previewDoc.totalPrice === pdfDoc.totalPrice, 'Totals match identically');
    expect(previewDoc.totalPaid === pdfDoc.totalPaid, 'Total paid matches identically');
    expect(previewDoc.remainingBalance === pdfDoc.remainingBalance, 'Remaining balance matches identically');
    expect(previewDoc.items.length === pdfDoc.items.length, 'Item counts match identically');

    // Both render through the single canonical renderer
    const previewMarkup = renderToStaticMarkup(React.createElement(InvoiceTemplate, { document: previewDoc }));
    const pdfMarkup = renderToStaticMarkup(React.createElement(InvoiceTemplate, { document: pdfDoc }));
    expect(previewMarkup === pdfMarkup, 'Preview and PDF produce identical canonical HTML markup');
  });

  const passed = results.filter((r) => r.passed).length;
  const failed = results.filter((r) => !r.passed).length;
  return { total: results.length, passed, failed };
}

// Direct terminal execution
if (process.argv[1] && process.argv[1].includes('design7StructuralLayoutTests')) {
  console.log('===============================================================');
  console.log('       DESIGN #7 STRUCTURAL LAYOUT ACCEPTANCE TESTS            ');
  console.log('===============================================================');

  const { total, passed, failed } = runDesign7StructuralLayoutTests();

  results.forEach((r) => {
    if (r.passed) {
      console.log(`[✓ PASS] ${r.name}`);
    } else {
      console.error(`[✗ FAIL] ${r.name}: ${r.error}`);
    }
  });

  console.log('---------------------------------------------------------------');
  console.log(`TOTAL: ${passed}/${total} Acceptance Tests Passed`);
  if (failed > 0) {
    console.error(`FAILED: ${failed} tests failed.`);
    process.exit(1);
  } else {
    console.log('OVERALL STATUS: ALL ACCEPTANCE TESTS PASSED (100%)');
    console.log('===============================================================');
  }
}
