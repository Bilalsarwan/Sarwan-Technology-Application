/**
 * Verification Test Suite for FINAL MASTER PROMPT:
 * 1. Record Payment Modal — fully responsive UI/UX
 * 2. Payment List / History — Pending audit/removal
 * 3. Payment List / History — real server-side pagination
 * 4. Payment List / History — Outstanding Card navigation
 */
import React from 'react';
import { renderToStaticMarkup } from 'react-dom/server';
import { PaymentsView } from '../views/PaymentsView';
import { PaymentModal } from '../components/payment/PaymentModal';
import { AuthContext } from '../context/AuthContext';
import { UserProfile, UserPermissions, BusinessSettings, Payment, Invoice } from '../types';
import { formatAFN, getTodayDateString } from './format';

interface TestResult {
  name: string;
  passed: boolean;
  error?: string;
}

const results: TestResult[] = [];

function test(name: string, fn: () => void) {
  try {
    fn();
    results.push({ name, passed: true });
  } catch (err: any) {
    results.push({ name, passed: false, error: err?.message || String(err) });
  }
}

function expect(condition: boolean, msg: string) {
  if (!condition) throw new Error(msg);
}

const mockSettings: BusinessSettings = {
  companyName: 'Sarwan Technology',
  phone: '0731339014',
  whatsapp: '0778771020',
  email: 'info@sarwan.af',
  address: 'Kabul, Afghanistan',
  currency: 'AFN',
  invoiceNote: 'Thank you for your business.',
} as BusinessSettings;

const mockPermissions: UserPermissions = {
  canViewDashboard: true,
  canViewInvoices: true,
  canCreateInvoice: true,
  canEditInvoice: true,
  canVoidInvoice: true,
  canViewPayments: true,
  canCollectPayment: true,
  canReversePayment: true,
  canViewCustomers: true,
  canManageCustomers: true,
  canViewExpenses: true,
  canManageExpenses: true,
  canViewReports: true,
  canExportReports: true,
  canManageSettings: true,
  canManageStaff: true,
  canManageUsers: true,
  canManageRequests: true,
  canManageProjects: true,
  canViewAuditLogs: true,
  canExportBackup: true,
};

const mockUserProfile: UserProfile = {
  id: 'usr-admin-1',
  name: 'Ahmad Admin',
  username: 'ahmad_admin',
  role: 'super_admin',
  status: 'active',
  email: 'admin@sarwan.af',
  createdAt: new Date().toISOString(),
};

const todayStr = getTodayDateString();

// Generate 25 sample payments to rigorously test pagination
const samplePayments: Payment[] = Array.from({ length: 25 }, (_, idx) => {
  const num = String(idx + 1).padStart(3, '0');
  const day = Math.max(1, 28 - idx);
  const dateStr = `2026-09-${String(day).padStart(2, '0')}`;
  return {
    id: `pay-${num}`,
    invoiceId: `inv-${(idx % 5) + 1}`,
    billNumber: `ST-${1060 + (idx % 5)}`,
    customerId: `cust-${(idx % 3) + 1}`,
    customerName: `Customer ${(idx % 3) + 1}`,
    amount: (idx + 1) * 1000,
    date: dateStr,
    method: 'CASH',
    recordedByName: idx % 2 === 0 ? 'Collector Ali' : 'Super Admin',
    recordedBy: idx % 2 === 0 ? 'usr-col-1' : 'usr-admin-1',
    createdAt: `${dateStr}T10:00:00.000Z`,
    isVoid: idx === 1, // Second payment is void (rendered on page 1)
  };
});

const sampleInvoices: Invoice[] = [
  {
    id: 'inv-1',
    billNumber: 'ST-1060',
    customerId: 'cust-1',
    customerSnapshot: { id: 'cust-1', name: 'Customer 1', phone: '0799111222', email: 'c1@test.com', address: 'Kabul', companyName: 'Company 1' },
    companySnapshot: {
      companyName: 'Sarwan Technology',
      logo: '',
      phone: '0731339014',
      whatsapp: '0778771020',
      email: 'info@sarwan.af',
      address: 'Kabul',
      currency: 'AFN',
      invoiceNote: '',
    },
    date: '2026-09-01',
    items: [],
    totalAmount: 100000,
    totalPaid: 40000,
    remaining: 60000,
    status: 'Partially Paid',
    note: '',
    createdAt: '2026-09-01T10:00:00Z',
    updatedAt: '2026-09-01T10:00:00Z',
  },
  {
    id: 'inv-2',
    billNumber: 'ST-1061',
    customerId: 'cust-2',
    customerSnapshot: { id: 'cust-2', name: 'Customer 2', phone: '0799333444', email: 'c2@test.com', address: 'Kabul', companyName: 'Company 2' },
    companySnapshot: {
      companyName: 'Sarwan Technology',
      logo: '',
      phone: '0731339014',
      whatsapp: '0778771020',
      email: 'info@sarwan.af',
      address: 'Kabul',
      currency: 'AFN',
      invoiceNote: '',
    },
    date: '2026-09-02',
    items: [],
    totalAmount: 50000,
    totalPaid: 50000,
    remaining: 0,
    status: 'Paid',
    note: '',
    createdAt: '2026-09-02T10:00:00Z',
    updatedAt: '2026-09-02T10:00:00Z',
  },
];

function renderPaymentsView(propsOverrides: any = {}): string {
  const authContextValue: any = {
    currentUser: null,
    userProfile: mockUserProfile,
    userRole: 'super_admin',
    userRoleDefinition: { id: 'super_admin', name: 'Super Admin', permissions: mockPermissions },
    permissions: mockPermissions,
    loading: false,
    authLoading: false,
    sessionChecked: true,
    isSuperAdmin: true,
    isAuthorized: true,
    logout: async () => {},
  };

  return renderToStaticMarkup(
    React.createElement(
      AuthContext.Provider,
      { value: authContextValue },
      React.createElement(PaymentsView, {
        payments: samplePayments,
        invoices: sampleInvoices,
        settings: mockSettings,
        onAddPayment: () => {},
        onAddCorrection: () => {},
        onSelectInvoice: () => {},
        onNavigateToInvoices: () => {},
        ...propsOverrides,
      })
    )
  );
}

function renderPaymentModal(propsOverrides: any = {}): string {
  const authContextValue: any = {
    currentUser: null,
    userProfile: mockUserProfile,
    userRole: 'super_admin',
    userRoleDefinition: { id: 'super_admin', name: 'Super Admin', permissions: mockPermissions },
    permissions: mockPermissions,
    loading: false,
    authLoading: false,
    sessionChecked: true,
    isSuperAdmin: true,
    isAuthorized: true,
    logout: async () => {},
  };

  return renderToStaticMarkup(
    React.createElement(
      AuthContext.Provider,
      { value: authContextValue },
      React.createElement(PaymentModal, {
        isOpen: true,
        onClose: () => {},
        invoices: sampleInvoices,
        payments: samplePayments,
        ...propsOverrides,
      })
    )
  );
}

export function runMasterPaymentVerificationTests() {
  console.log('===============================================================');
  console.log('   FINAL MASTER PROMPT: PAYMENT VERIFICATION TEST RESULTS      ');
  console.log('===============================================================');

  // PART 1: Record Payment Modal — fully responsive UI/UX
  test('1. Record Payment Modal: Fully responsive layout and viewport containment', () => {
    const markup = renderPaymentModal();

    expect(markup.includes('id="record-payment-modal-overlay"'), 'Modal overlay exists');
    expect(markup.includes('id="record-payment-modal-container"'), 'Modal container exists');
    expect(markup.includes('overflow-y-auto'), 'Overlay has overflow-y-auto for small/short viewports');
    expect(markup.includes('max-h-[calc(100dvh-1.5rem)]'), 'Container constrained to viewport height (max-h 100dvh)');
    expect(markup.includes('flex flex-col'), 'Container is flex flex-col for internal scroll');
    expect(markup.includes('grid-cols-1 sm:grid-cols-2'), 'Inputs use responsive grid (1 column mobile, 2 columns sm)');
    expect(markup.includes('w-full sm:w-auto'), 'Action buttons adapt smoothly from full-width mobile to auto on desktop');
    expect(markup.includes('role="dialog"'), 'Accessible WAI-ARIA role="dialog"');
    expect(markup.includes('aria-modal="true"'), 'Accessible aria-modal="true"');
  });

  // PART 2: Payment List / History — Pending audit/removal
  test('2. Pending Audit/Removal: Zero "pending" status options or badges in Payment List', () => {
    const markup = renderPaymentsView();

    // The filter select must NOT contain a pending option
    expect(!markup.includes('<option value="pending">'), 'No <option value="pending"> in filter dropdown');

    // Filter pills must NOT display "Pending"
    expect(!markup.includes('appliedStatus === "pending"'), 'No pending logic in filter pills');

    // Payment table rows must only render Completed or Reversed
    expect(markup.includes('Completed'), 'Active payments display Completed status badge');
    expect(markup.includes('Reversed'), 'Void payment displays Reversed status badge');
    expect(!markup.includes('badge-pending'), 'No pending badge class in payments list');

    // Check that table rows do not render "Pending" badge text
    const tableIndex = markup.indexOf('id="payments-table"');
    const tableMarkup = markup.slice(tableIndex);
    // There should be no "Pending" badge in the table markup
    const hasPendingBadge = tableMarkup.includes('>Pending</span>');
    expect(!hasPendingBadge, 'Zero Pending badges rendered in payments table');
  });

  // PART 3: Payment List / History — real server-side pagination
  test('3. Pagination: Displays 10 payments per page with authoritative pagination controls', () => {
    const markup = renderPaymentsView();

    expect(markup.includes('id="payments-pagination"'), 'Pagination controls container exists');
    expect(markup.includes('id="btn-prev-payment-page"'), 'Previous page button exists');
    expect(markup.includes('id="btn-next-payment-page"'), 'Next page button exists');
    expect(markup.includes('Showing <span class="font-semibold text-neutral-900">1–10</span> of <span class="font-semibold text-neutral-900">25</span> payments'), 'Showing 1–10 of 25 payments indicator is accurate');
    expect(markup.includes('Page 1 of 3'), 'Page indicator shows Page 1 of 3');

    // Page 1 should only contain payments 1 through 10, not payment 15 or 25
    expect(markup.includes('id="payment-row-pay-001"'), 'Page 1 renders pay-001');
    expect(markup.includes('id="payment-row-pay-010"'), 'Page 1 renders pay-010');
    expect(!markup.includes('id="payment-row-pay-011"'), 'Page 1 does NOT render pay-011 (paginated to page 2)');
    expect(!markup.includes('id="payment-row-pay-025"'), 'Page 1 does NOT render pay-025 (paginated to page 3)');
  });

  // PART 4: Payment List / History — Outstanding Card navigation
  test('4. Outstanding Card Navigation: Provides direct navigation to Invoices with balance', () => {
    let navigated = false;
    const markup = renderPaymentsView({
      onNavigateToInvoices: () => {
        navigated = true;
      },
    });

    expect(markup.includes('id="card-outstanding"'), 'Outstanding summary card exists');
    expect(markup.includes('id="btn-nav-outstanding-invoices"'), 'Direct navigation link exists on Outstanding card');
    expect(markup.includes('Invoices'), 'Card shows Invoices navigation link');
  });

  test('5. Outstanding Filter Banner & Empty State Navigation', () => {
    // When active card filter is outstanding, navigation button appears in banner
    const markupWithOutstanding = renderPaymentsView();
    // Verify Outstanding card is present
    expect(markupWithOutstanding.includes('id="card-outstanding"'), 'Card outstanding is present');
  });

  test('6. Preservation: Record Cash Payment business rules remain intact', () => {
    const markup = renderPaymentModal();
    expect(markup.includes('Payment method: CASH ONLY • Overpayment Protected'), 'Overpayment protection banner intact');
    expect(markup.includes('Record Cash Payment'), 'Submit button intact');
    expect(markup.includes('Choose Authorized Invoice'), 'Authorized invoice selection intact');
  });

  // Print results summary
  let passedCount = 0;
  for (const r of results) {
    if (r.passed) {
      passedCount++;
      console.log(`[✓ PASS] ${r.name}`);
    } else {
      console.error(`[✗ FAIL] ${r.name}: ${r.error}`);
    }
  }

  console.log('---------------------------------------------------------------');
  console.log(`TOTAL: ${results.length} Tests | PASSED: ${passedCount} | FAILED: ${results.length - passedCount}`);
  console.log('===============================================================');

  if (passedCount !== results.length) {
    throw new Error(`${results.length - passedCount} test(s) failed`);
  }
}

if (process.argv[1]?.endsWith('finalMasterPaymentVerificationTests.ts')) {
  runMasterPaymentVerificationTests();
}
