/**
 * Automated Verification Test Suite for Invoice Expenses Management & Profit Summary Integration
 * Tests:
 * 1. Invoice-Specific Expenses Association & Independence
 * 2. Expense Summary Calculations (Total Expenses, Count, Latest Expense Date)
 * 3. Add Expense Validation (Description, Amount > 0, Date)
 * 4. Edit Expense & Metadata Preservation (No duplicates, Preserves creation metadata)
 * 5. Delete Expense Isolation (Never touches invoice, payments, or other expenses)
 * 6. Financial Separation (Zero impact on customer payments, balance, or invoice totals)
 * 7. Profit Summary Integration (Total Sales, Item Cost, Gross Profit, Expenses, Net Profit)
 * 8. Role-Based Access Control (super_admin & invoice_manager only; payment_collector & customer blocked)
 */

import {
  calculateInvoiceProfitSummary,
  calculateInvoiceExpenseSummary,
  canAccessPurchaseCost,
  sanitizeInvoiceForRole,
} from './purchaseCostCalculator';
import { Invoice, InvoiceItem, Expense, Payment, UserRole } from '../types';

let passed = 0;
let failed = 0;

function assert(condition: boolean, msg: string) {
  if (condition) {
    console.log(`  ✓ PASS: ${msg}`);
    passed++;
  } else {
    console.error(`  ✗ FAIL: ${msg}`);
    failed++;
  }
}

console.log('\n======================================================');
console.log('SARWAN TECHNOLOGY: INVOICE EXPENSES MANAGEMENT TESTS');
console.log('======================================================\n');

// --- 1. INVOICE-SPECIFIC EXPENSES ASSOCIATION & INDEPENDENCE ---
console.log('--- 1. INVOICE-SPECIFIC EXPENSES ASSOCIATION & INDEPENDENCE ---');

const invoice1Id = 'inv-test-101';
const invoice2Id = 'inv-test-102';

const allExpenses: Expense[] = [
  {
    id: 'exp-1',
    invoiceId: invoice1Id,
    billNumber: 'ST-INV-101',
    title: 'Fiber optic termination kit',
    amount: 1200,
    date: '2026-10-01',
    category: 'Materials & Supplies',
    note: 'Purchased for client site',
    requestedBy: 'user-manager',
    requestedByName: 'Manager Ahmad',
    requestedByRole: 'invoice_manager',
    status: 'approved',
    createdAt: '2026-10-01T09:00:00Z',
  },
  {
    id: 'exp-2',
    invoiceId: invoice1Id,
    billNumber: 'ST-INV-101',
    title: 'Technician site transportation',
    amount: 450,
    date: '2026-10-05',
    category: 'Transport & Fuel',
    note: 'Taxi to site',
    requestedBy: 'user-admin',
    requestedByName: 'Super Admin Bilal',
    requestedByRole: 'super_admin',
    status: 'approved',
    createdAt: '2026-10-05T14:30:00Z',
  },
  {
    id: 'exp-3',
    invoiceId: invoice2Id,
    billNumber: 'ST-INV-102',
    title: 'Router mounting bracket',
    amount: 300,
    date: '2026-10-03',
    category: 'Hardware',
    note: 'For invoice 102 only',
    requestedBy: 'user-manager',
    requestedByName: 'Manager Ahmad',
    requestedByRole: 'invoice_manager',
    status: 'approved',
    createdAt: '2026-10-03T11:00:00Z',
  },
];

const inv1Expenses = allExpenses.filter((e) => e.invoiceId === invoice1Id);
const inv2Expenses = allExpenses.filter((e) => e.invoiceId === invoice2Id);

assert(inv1Expenses.length === 2, 'Invoice 1 has exactly 2 linked expenses');
assert(inv2Expenses.length === 1, 'Invoice 2 has exactly 1 linked expense');
assert(!inv1Expenses.some((e) => e.invoiceId === invoice2Id), 'Invoice 1 contains zero expenses from Invoice 2');
assert(!inv2Expenses.some((e) => e.invoiceId === invoice1Id), 'Invoice 2 contains zero expenses from Invoice 1');

// --- 2. EXPENSE SUMMARY CALCULATIONS ---
console.log('\n--- 2. EXPENSE SUMMARY CALCULATIONS ---');

function computeExpenseSummary(expenses: Expense[]) {
  const total = expenses.reduce((sum, e) => sum + (Number(e.amount) || 0), 0);
  const count = expenses.length;
  let latestDate: string | null = null;
  expenses.forEach((e) => {
    if (e.date) {
      if (!latestDate || e.date > latestDate) {
        latestDate = e.date;
      }
    }
  });
  return {
    totalExpenses: Math.round(total * 100) / 100,
    count,
    latestDate,
  };
}

const summary1 = computeExpenseSummary(inv1Expenses);
assert(summary1.totalExpenses === 1650, 'Invoice 1 Total Expenses is exactly AFN 1,650 (1200 + 450)');
assert(summary1.count === 2, 'Invoice 1 Number of Expenses is 2');
assert(summary1.latestDate === '2026-10-05', 'Invoice 1 Latest Expense Date is 2026-10-05');

const summary2 = computeExpenseSummary(inv2Expenses);
assert(summary2.totalExpenses === 300, 'Invoice 2 Total Expenses is exactly AFN 300');
assert(summary2.count === 1, 'Invoice 2 Number of Expenses is 1');
assert(summary2.latestDate === '2026-10-03', 'Invoice 2 Latest Expense Date is 2026-10-03');

const emptySummary = computeExpenseSummary([]);
assert(emptySummary.totalExpenses === 0, 'Empty expenses list gives 0 Total Expenses');
assert(emptySummary.count === 0, 'Empty expenses list gives 0 count');
assert(emptySummary.latestDate === null, 'Empty expenses list gives null latest date');

// --- 3. ADD EXPENSE VALIDATION ---
console.log('\n--- 3. ADD EXPENSE VALIDATION ---');

function validateExpenseInput(params: { title: string; amount: number; date: string }) {
  if (!params.title || !params.title.trim()) {
    return { valid: false, error: 'Expense description is required.' };
  }
  const num = Number(params.amount);
  if (!Number.isFinite(num) || num <= 0) {
    return { valid: false, error: 'Expense amount must be greater than zero.' };
  }
  if (!params.date || !params.date.trim()) {
    return { valid: false, error: 'Expense date is required.' };
  }
  return { valid: true };
}

assert(validateExpenseInput({ title: 'Patch Cable', amount: 500, date: '2026-10-09' }).valid, 'Valid expense is accepted');
assert(!validateExpenseInput({ title: '', amount: 500, date: '2026-10-09' }).valid, 'Empty description is rejected');
assert(!validateExpenseInput({ title: '   ', amount: 500, date: '2026-10-09' }).valid, 'Whitespace description is rejected');
assert(!validateExpenseInput({ title: 'Cable', amount: 0, date: '2026-10-09' }).valid, 'Zero amount is rejected');
assert(!validateExpenseInput({ title: 'Cable', amount: -150, date: '2026-10-09' }).valid, 'Negative amount is rejected');
assert(!validateExpenseInput({ title: 'Cable', amount: NaN, date: '2026-10-09' }).valid, 'NaN amount is rejected');
assert(!validateExpenseInput({ title: 'Cable', amount: 500, date: '' }).valid, 'Empty date is rejected');

// --- 4. EDIT EXPENSE & METADATA PRESERVATION ---
console.log('\n--- 4. EDIT EXPENSE & METADATA PRESERVATION ---');

const originalExpense: Expense = {
  id: 'exp-edit-1',
  invoiceId: 'inv-test-101',
  billNumber: 'ST-INV-101',
  title: 'Original Part',
  amount: 800,
  date: '2026-10-02',
  category: 'Materials',
  note: 'Original note',
  requestedBy: 'user-creator',
  requestedByName: 'Original Creator',
  requestedByRole: 'invoice_manager',
  status: 'approved',
  createdAt: '2026-10-02T10:00:00Z',
};

// Simulate update
const updatedExpense: Expense = {
  ...originalExpense,
  title: 'Updated Part (Premium)',
  amount: 1100,
  category: 'Tools & Equipment',
  note: 'Upgraded to premium spec',
  updatedAt: '2026-10-09T12:00:00Z',
  updatedBy: 'user-admin',
  updatedByName: 'Super Admin Bilal',
};

assert(updatedExpense.id === originalExpense.id, 'Record ID is preserved on edit (no duplicate)');
assert(updatedExpense.createdAt === originalExpense.createdAt, 'createdAt timestamp is strictly preserved');
assert(updatedExpense.requestedBy === originalExpense.requestedBy, 'requestedBy creator ID is strictly preserved');
assert(updatedExpense.requestedByName === originalExpense.requestedByName, 'requestedByName is strictly preserved');
assert(updatedExpense.invoiceId === originalExpense.invoiceId, 'invoiceId link is strictly preserved');
assert(updatedExpense.amount === 1100, 'Amount is updated to AFN 1,100');
assert(updatedExpense.updatedAt !== undefined, 'updatedAt timestamp is recorded');

// --- 5. DELETE EXPENSE ISOLATION ---
console.log('\n--- 5. DELETE EXPENSE ISOLATION ---');

const invoiceBeforeDelete: Invoice = {
  id: 'inv-test-101',
  billNumber: 'ST-INV-101',
  customerId: 'cust-1',
  date: '2026-10-01',
  totalAmount: 15000,
  totalPaid: 5000,
  remaining: 10000,
  status: 'Partially Paid',
  customerSnapshot: {
    id: 'cust-1',
    name: 'Customer Test',
    phone: '0700000000',
    address: 'Kabul',
    companyName: 'Test Co',
  },
  companySnapshot: {
    companyName: 'Sarwan Technology',
    phone: '0799999999',
    address: 'Kabul',
  } as any,
  items: [],
  note: '',
  createdAt: '2026-10-01T08:00:00Z',
  updatedAt: '2026-10-01T08:00:00Z',
};

const paymentsBeforeDelete: Payment[] = [
  {
    id: 'pay-1',
    invoiceId: 'inv-test-101',
    billNumber: 'ST-INV-101',
    customerId: 'cust-1',
    customerName: 'Customer Test',
    amount: 5000,
    date: '2026-10-02',
    method: 'CASH',
    createdAt: '2026-10-02T10:00:00Z',
  },
];

// Deleting exp-2 from inv1Expenses
const expensesAfterDelete = inv1Expenses.filter((e) => e.id !== 'exp-2');

assert(expensesAfterDelete.length === 1, 'Only target expense was deleted (1 remaining)');
assert(expensesAfterDelete[0].id === 'exp-1', 'Remaining expense is exp-1');
assert(invoiceBeforeDelete.totalAmount === 15000, 'Invoice totalAmount is completely unchanged');
assert(invoiceBeforeDelete.totalPaid === 5000, 'Invoice totalPaid is completely unchanged');
assert(invoiceBeforeDelete.remaining === 10000, 'Invoice remaining balance is completely unchanged');
assert(paymentsBeforeDelete.length === 1, 'Payment records are completely untouched');
assert(paymentsBeforeDelete[0].amount === 5000, 'Payment amount is completely untouched');

// --- 6. PROFIT SUMMARY INTEGRATION ---
console.log('\n--- 6. PROFIT SUMMARY INTEGRATION ---');

const sampleItems: InvoiceItem[] = [
  {
    sNo: 1,
    description: 'MikroTik Router RB5009',
    quantity: 2,
    unitPrice: 10000,
    totalAmount: 20000,
    purchaseCost: 7500, // Cost per unit
  },
  {
    sNo: 2,
    description: 'Cat6 UTP Cable (Spool)',
    quantity: 1,
    unitPrice: 6000,
    totalAmount: 6000,
    purchaseCost: 4000,
  },
];

// Formula check:
// Total Sales = 20000 + 6000 = 26000
// Total Item Cost = (7500 * 2) + (4000 * 1) = 15000 + 4000 = 19000
// Gross Profit = 26000 - 19000 = 7000

// Scenario A: Zero expenses
const profitNoExpenses = calculateInvoiceProfitSummary(sampleItems, []);
assert(profitNoExpenses.totalSales === 26000, 'Total Sales is AFN 26,000');
assert(profitNoExpenses.totalItemCost === 19000, 'Total Item Cost is AFN 19,000');
assert(profitNoExpenses.grossProfit === 7000, 'Gross Profit is AFN 7,000');
assert(profitNoExpenses.totalExpenses === 0, 'Total Expenses is AFN 0');
assert(profitNoExpenses.netProfit === 7000, 'Net Profit equals Gross Profit (AFN 7,000) when zero expenses');
assert(profitNoExpenses.hasCompleteCostData === true, 'hasCompleteCostData is true');

// Scenario B: With invoice expenses (AFN 1,650)
const profitWithExpenses = calculateInvoiceProfitSummary(sampleItems, inv1Expenses);
assert(profitWithExpenses.totalSales === 26000, 'Total Sales remains AFN 26,000');
assert(profitWithExpenses.totalItemCost === 19000, 'Total Item Cost remains AFN 19,000');
assert(profitWithExpenses.grossProfit === 7000, 'Gross Profit remains AFN 7,000');
assert(profitWithExpenses.totalExpenses === 1650, 'Total Expenses is accurately AFN 1,650');
assert(profitWithExpenses.netProfit === 5350, 'Net Profit is exactly AFN 5,350 (7,000 - 1,650)');
assert(profitWithExpenses.invoiceExpensesCount === 2, 'invoiceExpensesCount is 2');

// Scenario C: Expenses exceed gross profit (Net Loss)
const highExpenses: Expense[] = [
  {
    id: 'exp-high',
    title: 'Emergency fiber splice team',
    amount: 9000,
    date: '2026-10-04',
    note: '',
    requestedBy: 'user-admin',
    requestedByName: 'Admin',
    requestedByRole: 'super_admin',
    status: 'approved',
    createdAt: '2026-10-04T10:00:00Z',
  },
];
const profitWithLoss = calculateInvoiceProfitSummary(sampleItems, highExpenses);
assert(profitWithLoss.grossProfit === 7000, 'Gross Profit is AFN 7,000');
assert(profitWithLoss.totalExpenses === 9000, 'Total Expenses is AFN 9,000');
assert(profitWithLoss.netProfit === -2000, 'Net Profit reflects exact loss of -AFN 2,000');

// Scenario D: Incomplete purchase cost on an item
const itemsWithMissingCost: InvoiceItem[] = [
  ...sampleItems,
  {
    sNo: 3,
    description: 'Unknown Legacy Part',
    quantity: 1,
    unitPrice: 3000,
    totalAmount: 3000,
    // purchaseCost is missing / undefined
  },
];
const profitIncomplete = calculateInvoiceProfitSummary(itemsWithMissingCost, inv1Expenses);
assert(profitIncomplete.hasCompleteCostData === false, 'hasCompleteCostData is false when item lacks purchase cost');
assert(profitIncomplete.missingCostItemsCount === 1, 'missingCostItemsCount is 1');
assert(profitIncomplete.totalSales === 29000, 'Total Sales includes item selling price');
assert(profitIncomplete.totalExpenses === 1650, 'Total Expenses is preserved reliably');

// --- 7. ROLE-BASED ACCESS CONTROL (RBAC) ---
console.log('\n--- 7. ROLE-BASED ACCESS CONTROL (RBAC) ---');

assert(canAccessPurchaseCost('super_admin') === true, 'super_admin is authorized to view expenses and profit');
assert(canAccessPurchaseCost('invoice_manager') === true, 'invoice_manager is authorized to view expenses and profit');
assert(canAccessPurchaseCost('payment_collector') === false, 'payment_collector is STRICTLY forbidden from viewing expenses');
assert(canAccessPurchaseCost('customer') === false, 'customer is STRICTLY forbidden from viewing expenses');
assert(canAccessPurchaseCost(null) === false, 'null role is forbidden');
assert(canAccessPurchaseCost(undefined) === false, 'undefined role is forbidden');

const fullInvoice: Invoice = {
  ...invoiceBeforeDelete,
  items: sampleItems,
  totalPurchaseCost: 19000,
  totalProfit: 7000,
  totalExpenses: 1650,
  netProfit: 5350,
};

// Sanitization check for customer / collector
const sanitizedForCollector = sanitizeInvoiceForRole(fullInvoice, 'payment_collector');
assert(sanitizedForCollector.totalPurchaseCost === undefined, 'totalPurchaseCost stripped for payment_collector');
assert(sanitizedForCollector.totalProfit === undefined, 'totalProfit stripped for payment_collector');
assert(sanitizedForCollector.items[0].purchaseCost === undefined, 'Item purchaseCost stripped for payment_collector');

const sanitizedForCustomer = sanitizeInvoiceForRole(fullInvoice, 'customer');
assert(sanitizedForCustomer.totalPurchaseCost === undefined, 'totalPurchaseCost stripped for customer');
assert(sanitizedForCustomer.items[0].purchaseCost === undefined, 'Item purchaseCost stripped for customer');

const preservedForAdmin = sanitizeInvoiceForRole(fullInvoice, 'super_admin');
assert(preservedForAdmin.totalPurchaseCost === 19000, 'totalPurchaseCost preserved for super_admin');
assert(preservedForAdmin.items[0].purchaseCost === 7500, 'Item purchaseCost preserved for super_admin');

// --- 8. DATABASE PERSISTENCE, REOPENING & ERROR HANDLING SIMULATION ---
console.log('\n--- 8. DATABASE PERSISTENCE, REOPENING & ERROR HANDLING SIMULATION ---');

// Mock in-memory database representing Firestore collection('expenses')
const inMemoryFirestoreExpenses: Record<string, Expense> = {
  'exp-persisted-1': {
    id: 'exp-persisted-1',
    invoiceId: 'inv-101',
    billNumber: 'ST-INV-101',
    title: 'Cat6 Cable Roll',
    amount: 4500,
    date: '2026-10-01',
    category: 'Materials & Supplies',
    note: '',
    requestedBy: 'user-manager',
    requestedByName: 'Manager Ahmad',
    requestedByRole: 'invoice_manager',
    status: 'approved',
    createdAt: '2026-10-01T10:00:00Z',
  },
  'exp-persisted-2': {
    id: 'exp-persisted-2',
    invoiceId: 'inv-102',
    billNumber: 'ST-INV-102',
    title: 'Site Travel Reimbursement',
    amount: 600,
    date: '2026-10-02',
    category: 'Transport & Fuel',
    note: '',
    requestedBy: 'user-admin',
    requestedByName: 'Bilal Admin',
    requestedByRole: 'super_admin',
    status: 'approved',
    createdAt: '2026-10-02T11:00:00Z',
  },
};

function queryExpensesByInvoice(invId: string): Expense[] {
  return Object.values(inMemoryFirestoreExpenses)
    .filter((e) => e.invoiceId === invId)
    .sort((a, b) => (b.date || '').localeCompare(a.date || ''));
}

// Initial query before closing
const initialQueryInv101 = queryExpensesByInvoice('inv-101');
assert(initialQueryInv101.length === 1, 'Initial query returns persisted expense');
assert(initialQueryInv101[0].id === 'exp-persisted-1', 'Correct expense ID fetched');

// Simulate modal close and reopen after page reload
const reopenedQueryInv101 = queryExpensesByInvoice('inv-101');
assert(reopenedQueryInv101.length === 1, 'Persisted record remains available after closing and reopening invoice');
assert(reopenedQueryInv101[0].amount === 4500, 'Reopened expense preserves exact persisted amount');

// Simulate simulated DB error handling (rejection without false positive toast)
let caughtDbError: string | null = null;
try {
  // Attempt invalid update with non-existent expense
  const fakeId = 'exp-nonexistent';
  if (!inMemoryFirestoreExpenses[fakeId]) {
    throw new Error('Expense record not found in database.');
  }
} catch (err: any) {
  caughtDbError = err.message;
}
assert(caughtDbError === 'Expense record not found in database.', 'Database errors trigger clear exception messages and prevent false success');

// --- 9. CONFIRMATION DIALOG CANCEL VS CONFIRM WORKFLOW ---
console.log('\n--- 9. CONFIRMATION DIALOG CANCEL VS CONFIRM WORKFLOW ---');

let targetExpenseToDelete: Expense | null = inMemoryFirestoreExpenses['exp-persisted-1'];
let dialogOpen = true;

// Action A: User clicks Cancel
dialogOpen = false;
targetExpenseToDelete = null;
assert(inMemoryFirestoreExpenses['exp-persisted-1'] !== undefined, 'Cancelling delete dialog leaves expense completely untouched in store');

// Action B: User clicks Confirm Delete
targetExpenseToDelete = inMemoryFirestoreExpenses['exp-persisted-1'];
delete inMemoryFirestoreExpenses[targetExpenseToDelete.id];
targetExpenseToDelete = null;
assert(inMemoryFirestoreExpenses['exp-persisted-1'] === undefined, 'Confirming deletion deletes target expense from store');
assert(inMemoryFirestoreExpenses['exp-persisted-2'] !== undefined, 'Deleting expense on invoice 101 does NOT touch invoice 102 expense');

// --- 10. MULTI-INVOICE SWITCHING & ZERO DATA LEAKAGE ---
console.log('\n--- 10. MULTI-INVOICE SWITCHING & ZERO DATA LEAKAGE ---');

const switchStore: Expense[] = [
  { id: 'e-invA-1', invoiceId: 'inv-A', title: 'Patch cord', amount: 200, date: '2026-10-01', note: '', status: 'approved', requestedBy: 'u1', requestedByName: 'Staff', requestedByRole: 'staff', createdAt: '2026-10-01T00:00:00Z' },
  { id: 'e-invA-2', invoiceId: 'inv-A', title: 'Mounting rack', amount: 800, date: '2026-10-02', note: '', status: 'approved', requestedBy: 'u1', requestedByName: 'Staff', requestedByRole: 'staff', createdAt: '2026-10-02T00:00:00Z' },
  { id: 'e-invB-1', invoiceId: 'inv-B', title: 'RJ45 connectors', amount: 350, date: '2026-10-03', note: '', status: 'approved', requestedBy: 'u1', requestedByName: 'Staff', requestedByRole: 'staff', createdAt: '2026-10-03T00:00:00Z' },
];

function filterForModal(invId: string) {
  return switchStore.filter((e) => e.invoiceId === invId);
}

// User opens Invoice A
const activeExpensesInvA = filterForModal('inv-A');
assert(activeExpensesInvA.length === 2, 'Invoice A modal receives exactly 2 expenses');
assert(!activeExpensesInvA.some((e) => e.id === 'e-invB-1'), 'Invoice A does NOT contain Invoice B expenses');

// User switches to Invoice B
const activeExpensesInvB = filterForModal('inv-B');
assert(activeExpensesInvB.length === 1, 'Invoice B modal receives exactly 1 expense');
assert(!activeExpensesInvB.some((e) => e.id.startsWith('e-invA')), 'Invoice B does NOT contain Invoice A expenses');

// User switches to Invoice C (zero expenses)
const activeExpensesInvC = filterForModal('inv-C');
assert(activeExpensesInvC.length === 0, 'Invoice C modal receives empty array');

// --- 11. INVARIANT CHECK: FINANCIAL ISOLATION FROM PAYMENTS & BALANCES ---
console.log('\n--- 11. INVARIANT CHECK: FINANCIAL ISOLATION FROM PAYMENTS & BALANCES ---');

const protectedInvoice: Invoice = {
  id: 'inv-safe-1',
  billNumber: 'ST-INV-200',
  customerId: 'cust-99',
  date: '2026-10-01',
  totalAmount: 50000,
  totalPaid: 20000,
  remaining: 30000,
  status: 'Partially Paid',
  customerSnapshot: { id: 'cust-99', name: 'Safe Corp', phone: '0700112233', address: 'Kabul', companyName: 'Safe Corp' },
  companySnapshot: { companyName: 'Sarwan Technology' } as any,
  items: [],
  note: '',
  updatedAt: '2026-10-01T00:00:00Z',
  createdAt: '2026-10-01T00:00:00Z',
};

const protectedPayments: Payment[] = [
  { id: 'p1', invoiceId: 'inv-safe-1', billNumber: 'ST-INV-200', customerId: 'cust-99', customerName: 'Safe Corp', amount: 20000, date: '2026-10-02', method: 'CASH', createdAt: '2026-10-02T00:00:00Z' },
];

// Snapshot values before any expense action
const preTotalAmount = protectedInvoice.totalAmount;
const preTotalPaid = protectedInvoice.totalPaid;
const preRemaining = protectedInvoice.remaining;
const preStatus = protectedInvoice.status;
const prePaymentsCount = protectedPayments.length;
const prePaymentsSum = protectedPayments.reduce((s, p) => s + p.amount, 0);

// Perform Expense Add, Edit, Delete simulation
const tempExpenses: Expense[] = [
  { id: 'te-1', invoiceId: 'inv-safe-1', title: 'Router shelf', amount: 1500, date: '2026-10-03', note: '', status: 'approved', requestedBy: 'u1', requestedByName: 'Staff', requestedByRole: 'staff', createdAt: '2026-10-03T00:00:00Z' },
];
// Edit
tempExpenses[0].amount = 1800;
// Delete
tempExpenses.pop();

// Assert strict immutability of invoice financial ledger
assert(protectedInvoice.totalAmount === preTotalAmount, 'Invoice totalAmount is 100% immutable across expense lifecycle');
assert(protectedInvoice.totalPaid === preTotalPaid, 'Invoice totalPaid is 100% immutable across expense lifecycle');
assert(protectedInvoice.remaining === preRemaining, 'Invoice remaining is 100% immutable across expense lifecycle');
assert(protectedInvoice.status === preStatus, 'Invoice status is 100% immutable across expense lifecycle');
assert(protectedPayments.length === prePaymentsCount, 'Payment count is 100% unaffected by expense operations');
assert(protectedPayments.reduce((s, p) => s + p.amount, 0) === prePaymentsSum, 'Customer payment sum is 100% unaffected');

// --- 12. SECURITY HARDENING: CROSS-INVOICE PROTECTION & FIRESTORE RULES AUDIT ---
console.log('\n--- 12. SECURITY HARDENING: CROSS-INVOICE PROTECTION & FIRESTORE RULES AUDIT ---');

// A. Non-existent invoice check simulation
function simulateInvoiceExpenseAdd(invoiceMap: Record<string, Invoice>, targetInvoiceId: string) {
  if (!invoiceMap[targetInvoiceId]) {
    throw new Error(`Referenced invoice "${targetInvoiceId}" does not exist.`);
  }
  return true;
}

let nonExistentInvError: string | null = null;
try {
  simulateInvoiceExpenseAdd({ 'inv-exists': protectedInvoice }, 'inv-non-existent-999');
} catch (e: any) {
  nonExistentInvError = e.message;
}
assert(
  nonExistentInvError?.includes('does not exist') === true,
  'Adding expense to non-existent invoice is strictly blocked'
);

// B. Cross-invoice reassignment prevention simulation
function simulateInvoiceExpenseUpdate(existingExp: Expense, targetInvoiceId: string) {
  if (existingExp.invoiceId && existingExp.invoiceId !== targetInvoiceId) {
    throw new Error(
      `Access Denied: Expense "${existingExp.id}" belongs to invoice "${existingExp.invoiceId}" and cannot be reassigned to invoice "${targetInvoiceId}".`
    );
  }
  return true;
}

let reassignError: string | null = null;
const expenseOnInv1: Expense = {
  id: 'exp-locked-1',
  invoiceId: 'inv-101',
  billNumber: 'ST-INV-101',
  title: 'Dedicated Cable',
  amount: 1500,
  date: '2026-10-01',
  note: '',
  status: 'approved',
  requestedBy: 'mgr-1',
  requestedByName: 'Manager',
  requestedByRole: 'invoice_manager',
  createdAt: '2026-10-01T00:00:00Z',
};

try {
  simulateInvoiceExpenseUpdate(expenseOnInv1, 'inv-102');
} catch (e: any) {
  reassignError = e.message;
}
assert(
  reassignError?.includes('Access Denied') === true,
  'Reassigning expense to different invoice is strictly rejected'
);

// C. Cross-invoice deletion prevention simulation
function simulateInvoiceExpenseDelete(existingExp: Expense, currentModalInvoiceId: string) {
  if (existingExp.invoiceId && existingExp.invoiceId !== currentModalInvoiceId) {
    throw new Error(
      `Access Denied: Expense "${existingExp.id}" belongs to invoice "${existingExp.invoiceId}" and cannot be deleted from invoice "${currentModalInvoiceId}".`
    );
  }
  if (existingExp.status === 'executed') {
    throw new Error('Executed expenses cannot be deleted as they represent recorded financial disbursements.');
  }
  return true;
}

let crossDeleteError: string | null = null;
try {
  simulateInvoiceExpenseDelete(expenseOnInv1, 'inv-999');
} catch (e: any) {
  crossDeleteError = e.message;
}
assert(
  crossDeleteError?.includes('cannot be deleted from invoice') === true,
  'Deleting expense using mismatching invoice ID is strictly blocked'
);

// D. Executed expense deletion protection simulation
let executedDeleteError: string | null = null;
const executedExpense: Expense = {
  ...expenseOnInv1,
  id: 'exp-executed-1',
  status: 'executed',
};
try {
  simulateInvoiceExpenseDelete(executedExpense, 'inv-101');
} catch (e: any) {
  executedDeleteError = e.message;
}
assert(
  executedDeleteError?.includes('Executed expenses cannot be deleted') === true,
  'Executed disbursement expenses are strictly protected from deletion'
);

// E. Firestore Rules `isValidExpense` audit simulation
function firestoreRulesIsValidExpense(data: any): boolean {
  return typeof data.amount === 'number' && data.amount > 0
    && typeof data.title === 'string' && data.title.length > 0 && data.title.length <= 500
    && typeof data.date === 'string' && data.date.length > 0
    && (!('category' in data) || typeof data.category === 'string')
    && (!('note' in data) || typeof data.note === 'string')
    && (!('status' in data) || ['draft', 'pending_manager', 'pending_admin', 'approved', 'executed', 'rejected'].includes(data.status))
    && (!('requestedBy' in data) || (typeof data.requestedBy === 'string' && data.requestedBy.length > 0))
    && (!('invoiceId' in data) || (typeof data.invoiceId === 'string' && data.invoiceId.length > 0 && data.invoiceId.length <= 128))
    && (!('billNumber' in data) || (typeof data.billNumber === 'string' && data.billNumber.length > 0 && data.billNumber.length <= 100));
}

assert(firestoreRulesIsValidExpense({ amount: 500, title: 'Item', date: '2026-10-09' }) === true, 'Firestore rule validates compliant expense');
assert(firestoreRulesIsValidExpense({ amount: 0, title: 'Item', date: '2026-10-09' }) === false, 'Firestore rule rejects zero amount');
assert(firestoreRulesIsValidExpense({ amount: -50, title: 'Item', date: '2026-10-09' }) === false, 'Firestore rule rejects negative amount');
assert(firestoreRulesIsValidExpense({ amount: 100, title: '', date: '2026-10-09' }) === false, 'Firestore rule rejects empty title');
assert(firestoreRulesIsValidExpense({ amount: 100, title: 'Item', date: '' }) === false, 'Firestore rule rejects empty date');
assert(firestoreRulesIsValidExpense({ amount: 100, title: 'Item', date: '2026-10-09', status: 'invalid_status' }) === false, 'Firestore rule rejects illegal status');
assert(firestoreRulesIsValidExpense({ amount: 100, title: 'Item', date: '2026-10-09', invoiceId: '' }) === false, 'Firestore rule rejects empty invoiceId');

// F. Role check in Firestore Rules creation
function firestoreRulesCanCreateInvoiceExpense(incoming: any): boolean {
  const isValid = firestoreRulesIsValidExpense(incoming);
  const roleAllowed = !('requestedByRole' in incoming) || ['super_admin', 'invoice_manager', 'payment_collector'].includes(incoming.requestedByRole);
  const invoiceRoleAllowed = !('invoiceId' in incoming) || ['super_admin', 'invoice_manager'].includes(incoming.requestedByRole);
  return isValid && roleAllowed && invoiceRoleAllowed;
}

assert(
  firestoreRulesCanCreateInvoiceExpense({ amount: 100, title: 'Item', date: '2026-10-09', invoiceId: 'inv-1', requestedByRole: 'super_admin' }) === true,
  'Super Admin allowed by Firestore rules to create invoice expense'
);
assert(
  firestoreRulesCanCreateInvoiceExpense({ amount: 100, title: 'Item', date: '2026-10-09', invoiceId: 'inv-1', requestedByRole: 'invoice_manager' }) === true,
  'Invoice Manager allowed by Firestore rules to create invoice expense'
);
assert(
  firestoreRulesCanCreateInvoiceExpense({ amount: 100, title: 'Item', date: '2026-10-09', invoiceId: 'inv-1', requestedByRole: 'payment_collector' }) === false,
  'Payment Collector BLOCKED by Firestore rules from creating invoice expense'
);
assert(
  firestoreRulesCanCreateInvoiceExpense({ amount: 100, title: 'Item', date: '2026-10-09', invoiceId: 'inv-1', requestedByRole: 'customer' }) === false,
  'Customer BLOCKED by Firestore rules from creating invoice expense'
);

// --- 13. AUTHORITATIVE SCENARIO VERIFICATION (SCENARIOS 1 - 8) ---
console.log('\n--- 13. AUTHORITATIVE SCENARIO VERIFICATION (SCENARIOS 1 - 8) ---');

const baseItems: InvoiceItem[] = [
  { sNo: 1, description: 'Cat6 Cable 305m', quantity: 2, unitPrice: 4000, totalAmount: 8000, purchaseCost: 3000 },
  { sNo: 2, description: 'RJ45 Connectors 100pk', quantity: 1, unitPrice: 1500, totalAmount: 1500, purchaseCost: 800 },
];
// Total Sales: 8000 + 1500 = 9500
// Total Item Cost: (3000 * 2) + (800 * 1) = 6000 + 800 = 6800
// Gross Profit: 9500 - 6800 = 2700

const baselineInvoice: Invoice = {
  id: 'inv-scenario-100',
  billNumber: 'ST-INV-100',
  customerId: 'cust-sc-1',
  date: '2026-10-01',
  totalAmount: 9500,
  totalPaid: 5000,
  remaining: 4500,
  status: 'Partially Paid',
  customerSnapshot: { id: 'cust-sc-1', name: 'Scenario Corp', phone: '0700112233', address: 'Kabul', companyName: 'Scenario Corp' },
  companySnapshot: { companyName: 'Sarwan Technology' } as any,
  items: baseItems,
  note: '',
  updatedAt: '2026-10-01T00:00:00Z',
  createdAt: '2026-10-01T00:00:00Z',
};

const baselinePayments: Payment[] = [
  { id: 'pay-sc-1', invoiceId: 'inv-scenario-100', billNumber: 'ST-INV-100', customerId: 'cust-sc-1', customerName: 'Scenario Corp', amount: 5000, date: '2026-10-02', method: 'CASH', createdAt: '2026-10-02T00:00:00Z' },
];

// SCENARIO 1: An invoice with no expenses
const sc1Expenses: Expense[] = [];
const sc1ExpenseSum = calculateInvoiceExpenseSummary(sc1Expenses, baselineInvoice.id);
const sc1Profit = calculateInvoiceProfitSummary(baselineInvoice.items, sc1Expenses, baselineInvoice.id);
assert(sc1ExpenseSum.totalExpenses === 0, 'Scenario 1: No expenses gives 0 total expenses');
assert(sc1ExpenseSum.count === 0, 'Scenario 1: No expenses gives 0 count');
assert(sc1ExpenseSum.latestDate === null, 'Scenario 1: No expenses gives null latest date');
assert(sc1Profit.grossProfit === 2700, 'Scenario 1: Gross Profit is 2,700 AFN');
assert(sc1Profit.netProfit === 2700, 'Scenario 1: Net Profit equals Gross Profit (2,700 AFN)');
assert(sc1Profit.totalExpenses === 0, 'Scenario 1: Profit summary totalExpenses is 0');

// SCENARIO 2: An invoice with one expense
const sc2Expenses: Expense[] = [
  { id: 'exp-sc-1', invoiceId: 'inv-scenario-100', billNumber: 'ST-INV-100', title: 'Site delivery taxi', amount: 500, date: '2026-10-03', note: '', status: 'approved', requestedBy: 'u1', requestedByName: 'Staff', requestedByRole: 'invoice_manager', createdAt: '2026-10-03T10:00:00Z' },
];
const sc2ExpenseSum = calculateInvoiceExpenseSummary(sc2Expenses, baselineInvoice.id);
const sc2Profit = calculateInvoiceProfitSummary(baselineInvoice.items, sc2Expenses, baselineInvoice.id);
assert(sc2ExpenseSum.totalExpenses === 500, 'Scenario 2: Single expense gives 500 AFN total');
assert(sc2ExpenseSum.count === 1, 'Scenario 2: Single expense gives count 1');
assert(sc2ExpenseSum.latestDate === '2026-10-03', 'Scenario 2: Latest expense date is 2026-10-03');
assert(sc2Profit.netProfit === 2200, 'Scenario 2: Net Profit is 2,200 AFN (2,700 - 500)');

// SCENARIO 3: An invoice with multiple expenses
const sc3Expenses: Expense[] = [
  ...sc2Expenses,
  { id: 'exp-sc-2', invoiceId: 'inv-scenario-100', billNumber: 'ST-INV-100', title: 'Special drill bit', amount: 350, date: '2026-10-05', note: '', status: 'approved', requestedBy: 'u1', requestedByName: 'Staff', requestedByRole: 'invoice_manager', createdAt: '2026-10-05T11:00:00Z' },
  { id: 'exp-sc-3', invoiceId: 'inv-scenario-100', billNumber: 'ST-INV-100', title: 'PVC Conduit clips', amount: 150, date: '2026-10-04', note: '', status: 'approved', requestedBy: 'u1', requestedByName: 'Staff', requestedByRole: 'invoice_manager', createdAt: '2026-10-04T12:00:00Z' },
];
const sc3ExpenseSum = calculateInvoiceExpenseSummary(sc3Expenses, baselineInvoice.id);
const sc3Profit = calculateInvoiceProfitSummary(baselineInvoice.items, sc3Expenses, baselineInvoice.id);
assert(sc3ExpenseSum.totalExpenses === 1000, 'Scenario 3: Multiple expenses sum accurately (500 + 350 + 150 = 1,000 AFN)');
assert(sc3ExpenseSum.count === 3, 'Scenario 3: Multiple expenses count is 3');
assert(sc3ExpenseSum.latestDate === '2026-10-05', 'Scenario 3: Correctly resolves latest date (2026-10-05)');
assert(sc3Profit.netProfit === 1700, 'Scenario 3: Net Profit is 1,700 AFN (2,700 - 1,000)');

// SCENARIO 4: Editing an expense amount
const sc4Expenses: Expense[] = sc3Expenses.map((e) =>
  e.id === 'exp-sc-2' ? { ...e, amount: 650, note: 'Updated to titanium drill bit' } : e
);
const sc4ExpenseSum = calculateInvoiceExpenseSummary(sc4Expenses, baselineInvoice.id);
const sc4Profit = calculateInvoiceProfitSummary(baselineInvoice.items, sc4Expenses, baselineInvoice.id);
assert(sc4ExpenseSum.totalExpenses === 1300, 'Scenario 4: Edited expense recalculates total accurately (500 + 650 + 150 = 1,300 AFN)');
assert(sc4ExpenseSum.count === 3, 'Scenario 4: Count remains 3 after edit (no duplicates)');
assert(sc4Profit.netProfit === 1400, 'Scenario 4: Net profit updates dynamically to 1,400 AFN (2,700 - 1,300)');

// SCENARIO 5: Deleting an expense
const sc5Expenses: Expense[] = sc4Expenses.filter((e) => e.id !== 'exp-sc-3');
const sc5ExpenseSum = calculateInvoiceExpenseSummary(sc5Expenses, baselineInvoice.id);
const sc5Profit = calculateInvoiceProfitSummary(baselineInvoice.items, sc5Expenses, baselineInvoice.id);
assert(sc5ExpenseSum.totalExpenses === 1150, 'Scenario 5: Deleting expense updates total immediately to 1,150 AFN');
assert(sc5ExpenseSum.count === 2, 'Scenario 5: Count updates to 2');
assert(sc5Profit.netProfit === 1550, 'Scenario 5: Net Profit updates to 1,550 AFN (2,700 - 1,150)');

// SCENARIO 6: Opening two different invoices with different expenses (Zero leakage)
const invoiceAlphaId = 'inv-alpha-99';
const invoiceBetaId = 'inv-beta-88';
const allMultiExpenses: Expense[] = [
  { id: 'exp-a-1', invoiceId: invoiceAlphaId, amount: 1200, title: 'Alpha Cable', date: '2026-10-01', status: 'approved', note: '', requestedBy: 'u1', requestedByName: 'Staff', requestedByRole: 'invoice_manager', createdAt: '2026-10-01T00:00:00Z' },
  { id: 'exp-b-1', invoiceId: invoiceBetaId, amount: 400, title: 'Beta Patch', date: '2026-10-02', status: 'approved', note: '', requestedBy: 'u1', requestedByName: 'Staff', requestedByRole: 'invoice_manager', createdAt: '2026-10-02T00:00:00Z' },
];
const alphaFiltered = allMultiExpenses.filter((e) => e.invoiceId === invoiceAlphaId);
const betaFiltered = allMultiExpenses.filter((e) => e.invoiceId === invoiceBetaId);
const alphaSum = calculateInvoiceExpenseSummary(alphaFiltered, invoiceAlphaId);
const betaSum = calculateInvoiceExpenseSummary(betaFiltered, invoiceBetaId);
assert(alphaSum.totalExpenses === 1200, 'Scenario 6: Invoice Alpha total is exactly 1,200 AFN');
assert(betaSum.totalExpenses === 400, 'Scenario 6: Invoice Beta total is exactly 400 AFN');
assert(!alphaSum.validExpenses.some((e) => e.invoiceId === invoiceBetaId), 'Scenario 6: Alpha contains zero Beta expenses');
assert(!betaSum.validExpenses.some((e) => e.invoiceId === invoiceAlphaId), 'Scenario 6: Beta contains zero Alpha expenses');

// SCENARIO 7: Refreshing the page after recording expenses (Persistence consistency)
const persistedJson = JSON.stringify(sc5Expenses);
const reloadedExpenses: Expense[] = JSON.parse(persistedJson);
const reloadedSum = calculateInvoiceExpenseSummary(reloadedExpenses, baselineInvoice.id);
assert(reloadedSum.totalExpenses === sc5ExpenseSum.totalExpenses, 'Scenario 7: Reloaded total matches persisted total (1,150 AFN)');
assert(reloadedSum.count === sc5ExpenseSum.count, 'Scenario 7: Reloaded count matches persisted count (2)');
assert(reloadedSum.latestDate === sc5ExpenseSum.latestDate, 'Scenario 7: Reloaded latest date matches persisted date');

// SCENARIO 8: Payment totals, customer balances and histories strictly unchanged across expense operations
assert(baselineInvoice.totalAmount === 9500, 'Scenario 8: Invoice total amount strictly 9,500 AFN');
assert(baselineInvoice.totalPaid === 5000, 'Scenario 8: Customer total paid strictly 5,000 AFN');
assert(baselineInvoice.remaining === 4500, 'Scenario 8: Outstanding balance strictly 4,500 AFN');
assert(baselinePayments.length === 1, 'Scenario 8: Payment history records count strictly 1');
assert(baselinePayments[0].amount === 5000, 'Scenario 8: Payment record amount strictly 5,000 AFN');

// DATA SAFETY & DEDUPLICATION CHECKS
const corruptedExpenses: Expense[] = [
  ...sc2Expenses,
  ...sc2Expenses, // duplicate of exp-sc-1
  { id: 'exp-neg', invoiceId: 'inv-scenario-100', amount: -200, title: 'Negative item', date: '2026-10-09', status: 'approved', note: '', requestedBy: 'u1', requestedByName: 'Staff', requestedByRole: 'invoice_manager', createdAt: '2026-10-09T00:00:00Z' },
  { id: 'exp-zero', invoiceId: 'inv-scenario-100', amount: 0, title: 'Zero item', date: '2026-10-09', status: 'approved', note: '', requestedBy: 'u1', requestedByName: 'Staff', requestedByRole: 'invoice_manager', createdAt: '2026-10-09T00:00:00Z' },
  { id: 'exp-nan', invoiceId: 'inv-scenario-100', amount: NaN, title: 'NaN item', date: '2026-10-09', status: 'approved', note: '', requestedBy: 'u1', requestedByName: 'Staff', requestedByRole: 'invoice_manager', createdAt: '2026-10-09T00:00:00Z' },
  { id: 'exp-foreign', invoiceId: 'inv-other-999', amount: 9999, title: 'Foreign invoice item', date: '2026-10-09', status: 'approved', note: '', requestedBy: 'u1', requestedByName: 'Staff', requestedByRole: 'invoice_manager', createdAt: '2026-10-09T00:00:00Z' },
  { id: 'exp-rejected', invoiceId: 'inv-scenario-100', amount: 800, title: 'Rejected item', date: '2026-10-09', status: 'rejected', note: '', requestedBy: 'u1', requestedByName: 'Staff', requestedByRole: 'invoice_manager', createdAt: '2026-10-09T00:00:00Z' },
];

const safeFiltered = calculateInvoiceExpenseSummary(corruptedExpenses, baselineInvoice.id);
assert(safeFiltered.totalExpenses === 500, 'Data Safety: Deduplicates duplicate ID, rejects negative, zero, NaN, foreign and rejected expenses');
assert(safeFiltered.count === 1, 'Data Safety: Only the single valid 500 AFN expense counted');

// --- 14. INVOICE EXPENSES PRINT, PDF & REPORTING INTEGRATION WORKFLOWS ---
console.log('\n--- 14. INVOICE EXPENSES PRINT, PDF & REPORTING INTEGRATION WORKFLOWS ---');

// Test 1: Invoice with no expenses
const zeroExpSummary = calculateInvoiceExpenseSummary([], 'inv-empty');
assert(zeroExpSummary.totalExpenses === 0, 'Workflow 1: Empty expense list gives total expenses 0 AFN');
assert(zeroExpSummary.count === 0, 'Workflow 1: Empty expense list gives count 0');
assert(zeroExpSummary.latestDate === null, 'Workflow 1: Empty expense list gives null latest date');
assert(zeroExpSummary.validExpenses.length === 0, 'Workflow 1: Valid expenses array is empty');

// Test 2: Invoice with one expense
const singleExp: Expense[] = [
  {
    id: 'exp-single-1',
    invoiceId: 'inv-single',
    billNumber: 'ST-INV-2001',
    title: 'Custom fiber patch cable 15m',
    amount: 1450,
    date: '2026-10-04',
    category: 'Materials & Supplies',
    note: 'Special order',
    requestedBy: 'user-manager',
    requestedByName: 'Ahmad Manager',
    requestedByRole: 'invoice_manager',
    status: 'approved',
    createdAt: '2026-10-04T10:00:00Z',
  },
];
const singleSummary = calculateInvoiceExpenseSummary(singleExp, 'inv-single');
assert(singleSummary.totalExpenses === 1450, 'Workflow 2: Single expense gives exactly 1,450 AFN total');
assert(singleSummary.count === 1, 'Workflow 2: Single expense count is 1');
assert(singleSummary.validExpenses[0].title === 'Custom fiber patch cable 15m', 'Workflow 2: Expense title preserved');
assert(singleSummary.validExpenses[0].category === 'Materials & Supplies', 'Workflow 2: Category preserved');
assert(singleSummary.validExpenses[0].billNumber === 'ST-INV-2001', 'Workflow 2: Bill number preserved');

// Test 3: Invoice with multiple expenses
const multiExp: Expense[] = [
  ...singleExp,
  {
    id: 'exp-multi-2',
    invoiceId: 'inv-single',
    billNumber: 'ST-INV-2001',
    title: 'Site transportation fuel',
    amount: 550,
    date: '2026-10-06',
    category: 'Transport & Fuel',
    note: 'Driver disbursement',
    requestedBy: 'user-admin',
    requestedByName: 'Bilal Admin',
    requestedByRole: 'super_admin',
    status: 'approved',
    createdAt: '2026-10-06T12:00:00Z',
  },
  {
    id: 'exp-multi-3',
    invoiceId: 'inv-single',
    billNumber: 'ST-INV-2001',
    title: 'High-grade RJ45 connectors pack',
    amount: 300,
    date: '2026-10-07',
    category: 'Tools & Equipment',
    note: 'Hardware supply',
    requestedBy: 'user-manager',
    requestedByName: 'Ahmad Manager',
    requestedByRole: 'invoice_manager',
    status: 'approved',
    createdAt: '2026-10-07T15:00:00Z',
  },
];
const multiSummary = calculateInvoiceExpenseSummary(multiExp, 'inv-single');
assert(multiSummary.totalExpenses === 2300, 'Workflow 3: Multiple expenses sum accurately (1450 + 550 + 300 = 2,300 AFN)');
assert(multiSummary.count === 3, 'Workflow 3: Multiple expenses count is 3');
assert(multiSummary.latestDate === '2026-10-07', 'Workflow 3: Latest expense date accurately resolved to 2026-10-07');

// Test 4: Expenses with long descriptions (text wrapping and data preservation)
const longDescText = 'Detailed hardware purchase order for 24-port PoE Gigabit Managed Switch with redundant dual power supply, high-density fiber uplink SFP+ ports, wall mount bracket kit, and customized surge protection modules installed on-premise for high-availability enterprise connectivity';
const longDescExp: Expense[] = [
  {
    id: 'exp-long-1',
    invoiceId: 'inv-long',
    billNumber: 'ST-INV-3001',
    title: longDescText,
    amount: 18500,
    date: '2026-10-08',
    category: 'Hardware',
    note: 'Purchased directly from authorized vendor with 2-year enterprise warranty coverage',
    requestedBy: 'user-manager',
    requestedByName: 'Ahmad Manager',
    requestedByRole: 'invoice_manager',
    status: 'approved',
    createdAt: '2026-10-08T09:00:00Z',
  },
];
const longDescSummary = calculateInvoiceExpenseSummary(longDescExp, 'inv-long');
assert(longDescSummary.validExpenses[0].title === longDescText, 'Workflow 4: Extremely long description preserved verbatim');
assert(longDescSummary.validExpenses[0].title.length > 200, 'Workflow 4: Description length is > 200 characters');
assert(longDescSummary.totalExpenses === 18500, 'Workflow 4: Long description does not distort amount calculation');

// Test 5: Large AFN amounts (e.g. 50,000,000 AFN enterprise fiber backbone deployment)
const largeAmountExp: Expense[] = [
  {
    id: 'exp-large-1',
    invoiceId: 'inv-large',
    billNumber: 'ST-INV-4001',
    title: 'Metro optical fiber civil works and trenching 12km',
    amount: 50000000,
    date: '2026-10-08',
    category: 'Labor & Services',
    note: 'Major infrastructure project',
    requestedBy: 'user-admin',
    requestedByName: 'Bilal Admin',
    requestedByRole: 'super_admin',
    status: 'approved',
    createdAt: '2026-10-08T08:00:00Z',
  },
  {
    id: 'exp-large-2',
    invoiceId: 'inv-large',
    billNumber: 'ST-INV-4001',
    title: 'Heavy machinery rental and asphalt restoration',
    amount: 25000000,
    date: '2026-10-08',
    category: 'Tools & Equipment',
    note: 'Subcontractor phase 1',
    requestedBy: 'user-admin',
    requestedByName: 'Bilal Admin',
    requestedByRole: 'super_admin',
    status: 'approved',
    createdAt: '2026-10-08T14:00:00Z',
  },
];
const largeSummary = calculateInvoiceExpenseSummary(largeAmountExp, 'inv-large');
assert(largeSummary.totalExpenses === 75000000, 'Workflow 5: Large AFN amounts (50M + 25M = 75,000,000 AFN) calculated without clipping');
assert(largeSummary.count === 2, 'Workflow 5: Large amounts count is 2');

// Test 6: Two invoices with different expense records (Strict isolation)
const invXExpenses = [multiExp[0], multiExp[1]]; // inv-single, 1450 + 550 = 2000 AFN
const invYExpenses = [largeAmountExp[0]]; // inv-large, 50,000,000 AFN
const combinedAll = [...invXExpenses, ...invYExpenses];

const filteredX = calculateInvoiceExpenseSummary(combinedAll, 'inv-single');
const filteredY = calculateInvoiceExpenseSummary(combinedAll, 'inv-large');
assert(filteredX.totalExpenses === 2000, 'Workflow 6: Invoice X contains only Invoice X expenses (2,000 AFN)');
assert(filteredX.count === 2, 'Workflow 6: Invoice X count is exactly 2');
assert(filteredY.totalExpenses === 50000000, 'Workflow 6: Invoice Y contains only Invoice Y expenses (50,000,000 AFN)');
assert(filteredY.count === 1, 'Workflow 6: Invoice Y count is exactly 1');
assert(!filteredX.validExpenses.some((e) => e.invoiceId === 'inv-large'), 'Workflow 6: Zero data leakage from Invoice Y into Invoice X');
assert(!filteredY.validExpenses.some((e) => e.invoiceId === 'inv-single'), 'Workflow 6: Zero data leakage from Invoice X into Invoice Y');

// Test 7: Role permissions & customer-facing privacy
assert(canAccessPurchaseCost('super_admin') === true, 'Workflow 7: super_admin has access to internal expense reports');
assert(canAccessPurchaseCost('invoice_manager') === true, 'Workflow 7: invoice_manager has access to internal expense reports');
assert(canAccessPurchaseCost('payment_collector') === false, 'Workflow 7: payment_collector is BLOCKED from internal expense reports');
assert(canAccessPurchaseCost('customer') === false, 'Workflow 7: customer is BLOCKED from internal expense reports');

// Sanitize invoice test: Customer invoice documents NEVER reveal internal expenses or purchase costs
const testInternalInvoice: Invoice = {
  id: 'inv-privacy-test',
  billNumber: 'ST-INV-9999',
  date: '2026-10-09',
  dueDate: '2026-10-20',
  customerId: 'cust-10',
  customerSnapshot: {
    id: 'cust-10',
    name: 'Al-Madina Trading',
    phone: '0799112233',
    email: 'info@almadina.af',
    address: 'Kabul, Afghanistan',
    companyName: 'Al-Madina Trading Co.',
  },
  status: 'Unpaid',
  billingState: 'payable',
  totalAmount: 45000,
  totalPaid: 15000,
  remaining: 30000,
  companySnapshot: { companyName: 'Sarwan Technology' } as any,
  note: '',
  items: [
    {
      sNo: 1,
      description: 'Optical Network Terminal',
      quantity: 5,
      unitPrice: 9000,
      totalAmount: 45000,
      purchaseCost: 6000,
      totalCost: 30000,
      totalProfit: 15000,
    },
  ],
  createdAt: '2026-10-09T08:00:00Z',
  updatedAt: '2026-10-09T08:00:00Z',
};

const customerSanitized = sanitizeInvoiceForRole(testInternalInvoice, 'customer');
assert(customerSanitized.items[0].purchaseCost === undefined, 'Workflow 7: purchaseCost stripped from customer invoice');
assert((customerSanitized.items[0] as any).totalCost === undefined, 'Workflow 7: totalCost stripped from customer invoice');
assert((customerSanitized.items[0] as any).totalProfit === undefined, 'Workflow 7: totalProfit stripped from customer invoice');
assert((customerSanitized as any).totalPurchaseCost === undefined, 'Workflow 7: totalPurchaseCost stripped from customer invoice');
assert(customerSanitized.totalAmount === 45000, 'Workflow 7: Customer sales total intact (45,000 AFN)');
assert(customerSanitized.totalPaid === 15000, 'Workflow 7: Customer payment total intact (15,000 AFN)');
assert(customerSanitized.remaining === 30000, 'Workflow 7: Customer remaining balance intact (30,000 AFN)');

// Test 8: Non-mutation invariants during print / report generation
const originalTotalAmount = testInternalInvoice.totalAmount;
const originalTotalPaid = testInternalInvoice.totalPaid;
const originalRemaining = testInternalInvoice.remaining;

// Simulate report generation
const simulatedReportExpenses = calculateInvoiceExpenseSummary(multiExp, testInternalInvoice.id);
const simulatedProfit = calculateInvoiceProfitSummary(testInternalInvoice.items, multiExp, testInternalInvoice.id);

assert(testInternalInvoice.totalAmount === originalTotalAmount, 'Workflow 8: Invoice totalAmount not mutated by report generation');
assert(testInternalInvoice.totalPaid === originalTotalPaid, 'Workflow 8: Invoice totalPaid not mutated by report generation');
assert(testInternalInvoice.remaining === originalRemaining, 'Workflow 8: Invoice remaining balance not mutated by report generation');
assert(simulatedProfit.totalSales === 45000, 'Workflow 8: Total sales matches invoice item sales (45,000 AFN)');
assert(simulatedProfit.totalExpenses === 0, 'Workflow 8: Zero expenses counted for mismatching invoice ID');

console.log('\n======================================================');
console.log(`TEST SUMMARY: ${passed} / ${passed + failed} TESTS PASSED`);
if (failed > 0) {
  console.error(`FAILED TESTS: ${failed}`);
  process.exit(1);
} else {
  console.log('ALL TESTS PASSED SUCCESSFULLY! ✓');
  console.log('======================================================\n');
}

