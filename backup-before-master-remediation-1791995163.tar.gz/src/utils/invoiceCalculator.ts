import { Invoice, Payment, InvoiceBillingState } from '../types';
import { getTodayDateString } from './format';

export type InvoiceCalculatedStatus = 'Paid' | 'Overdue' | 'Partially Paid' | 'Unpaid' | 'Void';

/**
 * Authoritative helper to determine invoice billing state with backward compatibility.
 * If billingState is present: returns that value ('quotation' | 'payable' | 'rejected').
 * If billingState is missing (legacy/historical invoice): safely returns 'payable'
 * so existing invoices are never erroneously converted to quotations.
 */
export function getInvoiceBillingState(inv: {
  billingState?: InvoiceBillingState;
  status?: string;
  totalPaid?: number;
  paidAmount?: number;
}): InvoiceBillingState {
  if (inv?.billingState) {
    return inv.billingState;
  }
  return 'payable';
}

/**
 * Checks whether an invoice is in the 'payable' billing state.
 * Returns true if billingState is 'payable' (or legacy default) and invoice is not void.
 * Quotation and rejected invoices return false.
 */
export function isInvoicePayable(inv: {
  billingState?: InvoiceBillingState;
  status?: string;
  isVoid?: boolean;
}): boolean {
  if (!inv) return false;
  if (inv.isVoid === true || inv.status === 'Void') return false;
  const state = inv.billingState || 'payable';
  return state === 'payable';
}

export function isInvoiceQuotation(inv: {
  billingState?: InvoiceBillingState;
}): boolean {
  return inv?.billingState === 'quotation';
}

export function isInvoiceRejected(inv: {
  billingState?: InvoiceBillingState;
}): boolean {
  return inv?.billingState === 'rejected';
}

export interface SingleInvoiceCalculationResult {
  status: InvoiceCalculatedStatus;
  totalAmount: number;
  paidAmount: number;
  outstanding: number;
}

export interface InvoiceStatusBreakdownItem {
  status: InvoiceCalculatedStatus;
  count: number;
  percentage: number;
  totalAmount: number;
  paidAmount: number;
  remainingAmount: number;
  invoices: Invoice[];
}

export interface InvoiceStatusBreakdownData {
  paid: InvoiceStatusBreakdownItem;
  overdue: InvoiceStatusBreakdownItem;
  partiallyPaid: InvoiceStatusBreakdownItem;
  unpaid: InvoiceStatusBreakdownItem;
  totalValidCount: number;
  totalValidAmount: number;
  totalValidRemaining: number;
}

/**
 * Checks whether an invoice is active, valid, and non-void.
 * Excludes:
 * - isVoid === true
 * - status === 'Void'
 * - deleted / non-existent records
 * - demo / fake records
 */
export function isValidInvoice(inv: unknown): inv is Invoice {
  if (!inv || typeof inv !== 'object') return false;
  const i = inv as Partial<Invoice>;
  if (!i.id || typeof i.id !== 'string' || i.id.trim() === '') return false;
  if (i.isVoid === true || i.status === 'Void') return false;
  if ((i as any).isDeleted === true) return false;
  if ((i as any).isDemo === true || (i as any).isFake === true) return false;
  return true;
}

/**
 * Checks whether a payment record is active, valid, and non-void.
 * Excludes:
 * - payment.isVoid === true
 * - payment.status === 'Void'
 * - deleted / fake / demo records
 * - payments belonging to a void invoice (via voidInvoiceIds or voidBillNumbers sets)
 */
export function isValidPayment(
  payment: unknown,
  voidInvoiceIds?: Set<string>,
  voidBillNumbers?: Set<string>
): payment is Payment {
  if (!payment || typeof payment !== 'object') return false;
  const p = payment as Partial<Payment>;
  if (!p.id || typeof p.id !== 'string' || p.id.trim() === '') return false;
  if (p.isVoid === true || (p as any).status === 'Void') return false;
  if ((p as any).isDeleted === true) return false;
  if ((p as any).isDemo === true || (p as any).isFake === true) return false;

  const invoiceId = p.invoiceId?.trim();
  const billNumber = p.billNumber?.trim();

  // Exclude payments belonging to void invoices
  if (invoiceId && voidInvoiceIds?.has(invoiceId)) return false;
  if (billNumber && voidBillNumbers?.has(billNumber)) return false;

  return true;
}

/**
 * Builds a fast lookup map of valid non-void payment sums indexed by invoiceId and billNumber.
 * 
 * Rules enforced:
 * 1. Exclude payment.isVoid === true and payment.status === 'Void'.
 * 2. Exclude payments belonging to a void invoice (isVoid === true or status === 'Void').
 * 3. Safely handle missing, null, undefined, NaN, Infinity, and negative amounts.
 * 4. Multiple payments for the same invoice are all summed together.
 */
export function getValidPaymentsPerInvoice(
  invoices: Invoice[] = [],
  payments: Payment[] = []
): {
  paymentsByInvoiceId: Map<string, number>;
  paymentsByBillNumber: Map<string, number>;
} {
  const paymentsByInvoiceId = new Map<string, number>();
  const paymentsByBillNumber = new Map<string, number>();

  // Index void invoices to exclude their payments
  const voidInvoiceIds = new Set<string>();
  const voidBillNumbers = new Set<string>();

  if (Array.isArray(invoices)) {
    for (const inv of invoices) {
      if (!inv || typeof inv !== 'object') continue;
      const isVoidInv = inv.isVoid === true || inv.status === 'Void';
      if (isVoidInv) {
        if (inv.id) voidInvoiceIds.add(String(inv.id).trim());
        if (inv.billNumber) voidBillNumbers.add(String(inv.billNumber).trim());
      }
    }
  }

  if (!Array.isArray(payments) || payments.length === 0) {
    return { paymentsByInvoiceId, paymentsByBillNumber };
  }

  for (const p of payments) {
    if (!isValidPayment(p, voidInvoiceIds, voidBillNumbers)) continue;

    const rawAmt = typeof p.amount === 'number' ? p.amount : parseFloat(String(p.amount ?? 0));
    const safeAmt = Number.isFinite(rawAmt) && rawAmt > 0 ? rawAmt : 0;
    if (safeAmt <= 0) continue;

    if (p.invoiceId) {
      const invId = String(p.invoiceId).trim();
      paymentsByInvoiceId.set(invId, (paymentsByInvoiceId.get(invId) || 0) + safeAmt);
    }
    if (p.billNumber) {
      const billNum = String(p.billNumber).trim();
      paymentsByBillNumber.set(billNum, (paymentsByBillNumber.get(billNum) || 0) + safeAmt);
    }
  }

  return { paymentsByInvoiceId, paymentsByBillNumber };
}

/**
 * Authoritative Single Invoice Status Calculator.
 * 
 * Rules:
 * - Paid Amount = SUM(valid payments for this invoice)
 * - Outstanding = Invoice Total - Paid Amount
 * - Clamp negative outstanding to 0
 * 
 * Exact Priority:
 * 1. Paid: Paid Amount >= Invoice Total
 * 2. Overdue: Outstanding > 0 AND dueDate has passed
 * 3. Partially Paid: Paid Amount > 0 AND Paid Amount < Invoice Total AND invoice is not overdue
 * 4. Unpaid: Paid Amount === 0 AND invoice is not overdue
 */
export function calculateSingleInvoiceStatus(
  inv: Invoice,
  paidAmount: number,
  todayDateStr?: string
): SingleInvoiceCalculationResult {
  const rawTotal =
    typeof inv.totalAmount === 'number'
      ? inv.totalAmount
      : parseFloat(String(inv.totalAmount ?? 0));
  const invoiceTotal = Number.isFinite(rawTotal) && rawTotal > 0 ? rawTotal : 0;
  const safePaid = Number.isFinite(paidAmount) && paidAmount > 0 ? paidAmount : 0;

  // Outstanding clamped to 0
  const outstanding = Math.max(0, invoiceTotal - safePaid);
  const today = todayDateStr || getTodayDateString();

  // Priority 0: Void (Absolute priority: Void invoices always resolve to Void with 0 outstanding)
  if (inv.isVoid === true || inv.status === 'Void') {
    return {
      status: 'Void',
      totalAmount: invoiceTotal,
      paidAmount: safePaid,
      outstanding: 0,
    };
  }

  // Priority 1: Paid (Paid Amount >= Invoice Total)
  // Fully paid invoice stays Paid even if due date has passed.
  if (invoiceTotal > 0 && safePaid >= invoiceTotal) {
    return {
      status: 'Paid',
      totalAmount: invoiceTotal,
      paidAmount: safePaid,
      outstanding: 0,
    };
  }

  if (invoiceTotal === 0) {
    return {
      status: 'Paid',
      totalAmount: 0,
      paidAmount: safePaid,
      outstanding: 0,
    };
  }

  // Outstanding is strictly > 0 here
  // Priority 2: Overdue (Outstanding > 0 AND dueDate has passed)
  const dueDateStr = inv.dueDate ? String(inv.dueDate).trim().slice(0, 10) : '';
  const isDueDatePassed = Boolean(dueDateStr) && dueDateStr < today;

  if (outstanding > 0 && isDueDatePassed) {
    return {
      status: 'Overdue',
      totalAmount: invoiceTotal,
      paidAmount: safePaid,
      outstanding,
    };
  }

  // Priority 3: Partially Paid (Paid Amount > 0 AND Paid Amount < Invoice Total AND not overdue)
  if (safePaid > 0 && safePaid < invoiceTotal) {
    return {
      status: 'Partially Paid',
      totalAmount: invoiceTotal,
      paidAmount: safePaid,
      outstanding,
    };
  }

  // Priority 4: Unpaid (Paid Amount === 0 AND not overdue)
  return {
    status: 'Unpaid',
    totalAmount: invoiceTotal,
    paidAmount: 0,
    outstanding,
  };
}

/**
 * Calculates dynamic Invoice Status Breakdown across all valid invoices.
 * 
 * Reused by:
 * - Invoice Status Breakdown Component
 * - SuperAdminDashboard
 * - DashboardView
 * - Organization Overview / KPI validators
 * 
 * Guaranteed properties:
 * - Paid + Overdue + Partially Paid + Unpaid = Total Valid Invoices
 * - Percentages calculated only from valid non-void invoices
 * - Total Valid Remaining = SUM(all valid invoice outstanding balances)
 */
export function calculateInvoiceStatusBreakdown(
  invoices: Invoice[] = [],
  payments: Payment[] = [],
  todayDateStr?: string
): InvoiceStatusBreakdownData {
  const today = todayDateStr || getTodayDateString();

  // Filter valid non-void invoices
  const validInvoices = Array.isArray(invoices)
    ? invoices.filter(isValidInvoice)
    : [];

  // Group valid non-void payments
  const { paymentsByInvoiceId, paymentsByBillNumber } = getValidPaymentsPerInvoice(
    invoices,
    payments
  );

  const hasPaymentsArray = Array.isArray(payments);

  const paidList: Invoice[] = [];
  const overdueList: Invoice[] = [];
  const partiallyPaidList: Invoice[] = [];
  const unpaidList: Invoice[] = [];

  const invoiceResults = new Map<string, SingleInvoiceCalculationResult>();

  for (const inv of validInvoices) {
    const rawTotal =
      typeof inv.totalAmount === 'number'
        ? inv.totalAmount
        : parseFloat(String(inv.totalAmount ?? 0));
    const invoiceTotal = Number.isFinite(rawTotal) && rawTotal > 0 ? rawTotal : 0;

    // Calculate actual paid amount from payment records
    let paidAmount = 0;
    const paymentFromId = inv.id ? paymentsByInvoiceId.get(inv.id) : undefined;
    const paymentFromBill = inv.billNumber ? paymentsByBillNumber.get(inv.billNumber) : undefined;

    if (paymentFromId !== undefined) {
      paidAmount = paymentFromId;
    } else if (paymentFromBill !== undefined) {
      paidAmount = paymentFromBill;
    } else if (!hasPaymentsArray && Number(inv.totalPaid) > 0) {
      // Fallback only if payments collection was not passed
      paidAmount = Number(inv.totalPaid) || 0;
    } else {
      paidAmount = 0;
    }

    const calcResult = calculateSingleInvoiceStatus(inv, paidAmount, today);
    invoiceResults.set(inv.id, calcResult);

    switch (calcResult.status) {
      case 'Paid':
        paidList.push(inv);
        break;
      case 'Overdue':
        overdueList.push(inv);
        break;
      case 'Partially Paid':
        partiallyPaidList.push(inv);
        break;
      case 'Unpaid':
        unpaidList.push(inv);
        break;
    }
  }

  const totalValidCount = validInvoices.length;
  const totalValidAmount = validInvoices.reduce((sum, inv) => {
    const res = invoiceResults.get(inv.id);
    return sum + (res?.totalAmount ?? 0);
  }, 0);

  const buildItem = (
    status: InvoiceCalculatedStatus,
    list: Invoice[]
  ): InvoiceStatusBreakdownItem => {
    const count = list.length;
    const percentage = totalValidCount > 0 ? Math.round((count / totalValidCount) * 100) : 0;
    const totalAmount = list.reduce((sum, inv) => {
      const res = invoiceResults.get(inv.id);
      return sum + (res?.totalAmount ?? 0);
    }, 0);
    const paidAmount = list.reduce((sum, inv) => {
      const res = invoiceResults.get(inv.id);
      return sum + (res?.paidAmount ?? 0);
    }, 0);
    const remainingAmount = list.reduce((sum, inv) => {
      const res = invoiceResults.get(inv.id);
      return sum + (res?.outstanding ?? 0);
    }, 0);

    return {
      status,
      count,
      percentage,
      totalAmount,
      paidAmount,
      remainingAmount,
      invoices: list,
    };
  };

  const paid = buildItem('Paid', paidList);
  const overdue = buildItem('Overdue', overdueList);
  const partiallyPaid = buildItem('Partially Paid', partiallyPaidList);
  const unpaid = buildItem('Unpaid', unpaidList);

  const totalValidRemaining =
    paid.remainingAmount +
    overdue.remainingAmount +
    partiallyPaid.remainingAmount +
    unpaid.remainingAmount;

  return {
    paid,
    overdue,
    partiallyPaid,
    unpaid,
    totalValidCount,
    totalValidAmount,
    totalValidRemaining,
  };
}

/**
 * Calculates authoritative Total Outstanding for the Organization Overview KPI:
 * For every valid invoice (where isVoid !== true and status !== 'Void'):
 *   Invoice Paid Amount = SUM(valid payments belonging to invoice)
 *   Invoice Outstanding = Math.max(0, Invoice Total - Invoice Paid Amount)
 * Total Outstanding = SUM(all valid invoice outstanding balances)
 */
export function calculateAuthoritativeTotalOutstanding(
  invoices: Invoice[] = [],
  payments: Payment[] = []
): number {
  if (!Array.isArray(invoices)) return 0;
  const validInvoices = invoices.filter(isValidInvoice);
  if (validInvoices.length === 0) return 0;

  const { paymentsByInvoiceId, paymentsByBillNumber } = getValidPaymentsPerInvoice(
    invoices,
    payments
  );

  const hasPaymentsArray = Array.isArray(payments);
  let totalOutstanding = 0;

  for (const inv of validInvoices) {
    const rawTotal =
      typeof inv.totalAmount === 'number'
        ? inv.totalAmount
        : parseFloat(String(inv.totalAmount ?? 0));
    const invoiceTotal = Number.isFinite(rawTotal) && rawTotal > 0 ? rawTotal : 0;

    let paidAmount = 0;
    const paymentFromId = inv.id ? paymentsByInvoiceId.get(inv.id) : undefined;
    const paymentFromBill = inv.billNumber ? paymentsByBillNumber.get(inv.billNumber) : undefined;

    if (paymentFromId !== undefined) {
      paidAmount = paymentFromId;
    } else if (paymentFromBill !== undefined) {
      paidAmount = paymentFromBill;
    } else if (!hasPaymentsArray && Number(inv.totalPaid) > 0) {
      paidAmount = Number(inv.totalPaid) || 0;
    } else {
      paidAmount = 0;
    }

    const outstanding = Math.max(0, invoiceTotal - paidAmount);
    totalOutstanding += outstanding;
  }

  return totalOutstanding;
}

/**
 * Authoritative check whether an invoice is locked.
 * Matches the application's existing lock state logic:
 * - Explicitly locked via isLocked === true
 * - Status is 'Paid'
 * - Fully paid: totalAmount > 0 and totalPaid >= totalAmount
 * - Fully paid: totalAmount > 0 and remaining <= 0
 */
export function isInvoiceLocked(inv: Partial<Invoice> | null | undefined): boolean {
  if (!inv) return false;
  const total = Number(inv.totalAmount) || 0;
  const paid = Number(inv.totalPaid) || 0;
  const remaining = inv.remaining !== undefined ? Number(inv.remaining) : (total - paid);
  return Boolean(
    inv.isLocked === true ||
    inv.status === 'Paid' ||
    (total > 0 && paid >= total) ||
    (total > 0 && remaining <= 0)
  );
}
