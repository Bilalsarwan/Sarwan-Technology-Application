/**
 * Comprehensive Test Suite for Invoice Billing State & Approval Workflow
 *
 * Verifies:
 * 1. Architecture: billingState ('quotation' | 'payable' | 'rejected') separate from status ('Unpaid' | 'Partially Paid' | 'Paid' | 'Void')
 * 2. New invoice default: billingState === 'quotation'
 * 3. Quotation isolation: Excluded from Sales, Customer Sales, Receivables, Financial Reports
 * 4. Quotation protections: Payment recording & Collector assignment prohibited
 * 5. Quotation features: PDF/Print/View and clear "Quotation / Pending Approval" badge
 * 6. Customer Approval: Customer accepts -> payable (records acceptedAt, acceptedBy='customer', acceptanceSource='customer')
 * 7. Customer Rejection: Customer rejects -> rejected (records rejectedAt, rejectedBy='customer', rejectionSource='customer')
 * 8. Customer Access Control: Customers cannot approve other customer invoices, nor bypass validation
 * 9. Staff Approval: Super Admin & Invoice Manager can "Mark as Payable" and "Mark as Rejected" (records changedBy, changedByRole, changedAt, changeSource)
 * 10. Payable behavior: Included in Sales, Customer totals, Receivables; payments & collectors enabled; payment flow preserved
 * 11. Rejected behavior: Excluded from finances; payments & collectors disabled; shows "Rejected"
 * 12. Deletion security: Permanent deletion allowed ONLY for Super Admin / Invoice Manager and ONLY on quotation/rejected; payable/financial invoices blocked
 * 13. Backward compatibility: Historical invoices lacking billingState safely resolve to 'payable'
 */

import { Invoice, Payment, UserProfile, Customer } from '../types';
import {
  getInvoiceBillingState,
  isInvoicePayable,
  isInvoiceQuotation,
  isInvoiceRejected,
} from './invoiceCalculator';
import {
  calculateCustomerSummary,
  calculateTotalOutstanding,
  calculateTotalInvoices,
} from './format';
import { canUserCollectForInvoice } from '../services/dashboardAuthorization';

interface TestResult {
  suite: string;
  name: string;
  passed: boolean;
  error?: string;
}

const results: TestResult[] = [];

function assert(condition: boolean, suite: string, name: string, detail?: string) {
  if (condition) {
    results.push({ suite, name, passed: true });
    console.log(`  ✓ [PASS] ${name}`);
  } else {
    results.push({ suite, name, passed: false, error: detail || 'Assertion failed' });
    console.error(`  ✗ [FAIL] ${name}: ${detail || 'Assertion failed'}`);
  }
}

// =========================================================================
// Mock Data Fixtures
// =========================================================================

const superAdminUser: UserProfile = {
  id: 'usr-admin-1',
  name: 'Super Admin',
  username: 'admin',
  role: 'super_admin',
  status: 'active',
  email: 'admin@sarwan.af',
  createdAt: '2026-01-01T00:00:00Z',
  updatedAt: '2026-01-01T00:00:00Z',
};

const invoiceManagerUser: UserProfile = {
  id: 'usr-mgr-1',
  name: 'Invoice Manager',
  username: 'manager',
  role: 'invoice_manager',
  status: 'active',
  email: 'manager@sarwan.af',
  createdAt: '2026-01-01T00:00:00Z',
  updatedAt: '2026-01-01T00:00:00Z',
};

const collectorUser: UserProfile = {
  id: 'usr-coll-1',
  name: 'Ahmad Collector',
  username: 'collector',
  role: 'payment_collector',
  status: 'active',
  email: 'collector@sarwan.af',
  createdAt: '2026-01-01T00:00:00Z',
  updatedAt: '2026-01-01T00:00:00Z',
};

const customerUser: UserProfile = {
  id: 'cust-user-1',
  name: 'Kabul Traders',
  username: 'kabul_traders',
  role: 'customer',
  customerId: 'cust-101',
  status: 'active',
  email: 'customer@traders.af',
  createdAt: '2026-01-01T00:00:00Z',
  updatedAt: '2026-01-01T00:00:00Z',
};

const sampleCustomer: Customer = {
  id: 'cust-101',
  name: 'Kabul Traders',
  companyName: 'Kabul Trading Ltd',
  phone: '0700123456',
  email: 'customer@traders.af',
  address: 'Kabul, Afghanistan',
  customerCode: 'CUST-101',
  note: '',
  status: 'active',
  createdAt: '2026-01-01T00:00:00Z',
  updatedAt: '2026-01-01T00:00:00Z',
};

function createSampleInvoice(overrides: Partial<Invoice>): Invoice {
  return {
    id: 'inv-test-1',
    billNumber: 'ST-1060',
    customerId: 'cust-101',
    customerSnapshot: {
      id: 'cust-101',
      name: 'Kabul Traders',
      phone: '0700123456',
      address: 'Kabul',
      companyName: 'Kabul Trading Ltd',
    },
    companySnapshot: {
      companyName: 'Sarwan Technology',
      logo: '',
      phone: '0700000000',
      whatsapp: '',
      email: 'info@sarwan.af',
      address: 'Kabul',
      currency: 'AFN',
      invoiceNote: '',
    },
    date: '2026-10-08',
    items: [{ sNo: 1, description: 'CCTV Camera', quantity: 2, unitPrice: 5000, totalAmount: 10000 }],
    totalAmount: 10000,
    totalPaid: 0,
    remaining: 10000,
    status: 'Unpaid',
    billingState: 'quotation',
    note: '',
    createdAt: '2026-10-08T10:00:00Z',
    updatedAt: '2026-10-08T10:00:00Z',
    ...overrides,
  };
}

// =========================================================================
// Suite 1: Architecture & Defaults
// =========================================================================
console.log('\n--- Suite 1: Architecture & Defaults ---');

const defaultQuotation = createSampleInvoice({});
assert(
  defaultQuotation.billingState === 'quotation',
  'Architecture & Defaults',
  'New invoice defaults to billingState = "quotation"'
);

assert(
  defaultQuotation.status === 'Unpaid',
  'Architecture & Defaults',
  'Payment status remains standard "Unpaid" without tampering or renaming'
);

const payableInvoice = createSampleInvoice({ id: 'inv-payable-1', billingState: 'payable' });
assert(
  isInvoicePayable(payableInvoice),
  'Architecture & Defaults',
  'isInvoicePayable correctly recognizes payable billingState'
);

assert(
  isInvoiceQuotation(defaultQuotation),
  'Architecture & Defaults',
  'isInvoiceQuotation correctly recognizes quotation billingState'
);

const rejectedInvoice = createSampleInvoice({ id: 'inv-rej-1', billingState: 'rejected' });
assert(
  isInvoiceRejected(rejectedInvoice),
  'Architecture & Defaults',
  'isInvoiceRejected correctly recognizes rejected billingState'
);

// =========================================================================
// Suite 2: Quotation Financial Exclusion
// =========================================================================
console.log('\n--- Suite 2: Quotation Financial Exclusion ---');

const mixedInvoices: Invoice[] = [
  createSampleInvoice({ id: 'inv-q-1', billNumber: 'ST-1060', totalAmount: 50000, billingState: 'quotation' }),
  createSampleInvoice({ id: 'inv-p-1', billNumber: 'ST-1061', totalAmount: 30000, billingState: 'payable' }),
  createSampleInvoice({ id: 'inv-r-1', billNumber: 'ST-1062', totalAmount: 20000, billingState: 'rejected' }),
];

const customerSummary = calculateCustomerSummary('cust-101', mixedInvoices, []);

assert(
  customerSummary.totalSales === 30000,
  'Quotation Financial Exclusion',
  'Customer Total Sales includes ONLY payable invoices (excludes quotations and rejected)',
  `Expected 30000, got ${customerSummary.totalSales}`
);

assert(
  customerSummary.remainingBalance === 30000,
  'Quotation Financial Exclusion',
  'Customer Receivables includes ONLY payable balance (quotation and rejected excluded)',
  `Expected 30000, got ${customerSummary.remainingBalance}`
);

const totalOutstanding = calculateTotalOutstanding(mixedInvoices, []);
assert(
  totalOutstanding === 30000,
  'Quotation Financial Exclusion',
  'Global Total Outstanding ignores quotations and rejected invoices',
  `Expected 30000, got ${totalOutstanding}`
);

// =========================================================================
// Suite 3: Operations & Permissions Protection (Collector & Payment)
// =========================================================================
console.log('\n--- Suite 3: Operations & Permissions Protection ---');

const quoteInv = createSampleInvoice({
  id: 'inv-q-protect',
  billingState: 'quotation',
  assignedCollectorId: 'usr-coll-1',
  assignedCollectorName: 'Ahmad Collector',
});

assert(
  !canUserCollectForInvoice(collectorUser, quoteInv),
  'Operations Protection',
  'Collector cannot collect payment for quotation invoice'
);

assert(
  !canUserCollectForInvoice(superAdminUser, quoteInv),
  'Operations Protection',
  'Super Admin cannot collect payment for quotation (must first be payable)'
);

const rejInv = createSampleInvoice({
  id: 'inv-r-protect',
  billingState: 'rejected',
  assignedCollectorId: 'usr-coll-1',
  assignedCollectorName: 'Ahmad Collector',
});

assert(
  !canUserCollectForInvoice(collectorUser, rejInv),
  'Operations Protection',
  'Collector cannot collect payment for rejected invoice'
);

assert(
  !canUserCollectForInvoice(superAdminUser, rejInv),
  'Operations Protection',
  'Super Admin cannot collect payment for rejected invoice'
);

const payableActive = createSampleInvoice({
  id: 'inv-p-active',
  billingState: 'payable',
  assignedCollectorId: 'usr-coll-1',
  assignedCollectorName: 'Ahmad Collector',
});

assert(
  canUserCollectForInvoice(collectorUser, payableActive),
  'Operations Protection',
  'Collector CAN collect payment for assigned payable invoice'
);

assert(
  canUserCollectForInvoice(superAdminUser, payableActive),
  'Operations Protection',
  'Super Admin CAN collect payment for payable invoice'
);

// =========================================================================
// Suite 4: State Transition & Audit Trail Integrity
// =========================================================================
console.log('\n--- Suite 4: State Transition & Audit Trail Integrity ---');

// Customer accepts quotation simulation
const customerAccepted: Invoice = {
  ...defaultQuotation,
  billingState: 'payable',
  acceptedAt: '2026-10-08T11:00:00Z',
  acceptedBy: 'customer',
  acceptanceSource: 'customer',
};

assert(
  customerAccepted.billingState === 'payable' &&
  customerAccepted.acceptedBy === 'customer' &&
  customerAccepted.acceptanceSource === 'customer',
  'State Transitions',
  'Customer quotation acceptance records proper acceptedBy and acceptanceSource'
);

// Customer rejects quotation simulation
const customerRejected: Invoice = {
  ...defaultQuotation,
  billingState: 'rejected',
  rejectedAt: '2026-10-08T11:15:00Z',
  rejectedBy: 'customer',
  rejectionSource: 'customer',
};

assert(
  customerRejected.billingState === 'rejected' &&
  customerRejected.rejectedBy === 'customer' &&
  customerRejected.rejectionSource === 'customer',
  'State Transitions',
  'Customer quotation rejection records proper rejectedBy and rejectionSource'
);

// Admin marks as payable simulation
const adminApproved: Invoice = {
  ...defaultQuotation,
  billingState: 'payable',
  acceptedAt: '2026-10-08T11:30:00Z',
  acceptedBy: 'Super Admin',
  acceptanceSource: 'Phone Call',
  changedBy: 'Super Admin',
  changedByRole: 'Super Admin',
  changedAt: '2026-10-08T11:30:00Z',
  changeSource: 'Phone Call',
};

assert(
  adminApproved.billingState === 'payable' &&
  adminApproved.changedByRole === 'Super Admin' &&
  adminApproved.changeSource === 'Phone Call',
  'State Transitions',
  'Admin Mark as Payable records staff actor, role, and communication source'
);

// =========================================================================
// Suite 5: Payment Workflow (Payable -> Unpaid -> Partially Paid -> Paid)
// =========================================================================
console.log('\n--- Suite 5: Payment Workflow Progression ---');

const payableFresh = createSampleInvoice({
  id: 'inv-flow-1',
  billingState: 'payable',
  totalAmount: 10000,
  totalPaid: 0,
  remaining: 10000,
  status: 'Unpaid',
});

assert(
  payableFresh.billingState === 'payable' && payableFresh.status === 'Unpaid',
  'Payment Workflow',
  'Fresh payable invoice begins at status = "Unpaid"'
);

const payablePartial: Invoice = {
  ...payableFresh,
  totalPaid: 4000,
  remaining: 6000,
  status: 'Partially Paid',
};

assert(
  payablePartial.billingState === 'payable' && payablePartial.status === 'Partially Paid',
  'Payment Workflow',
  'Payable invoice transitions to "Partially Paid" after partial cash payment'
);

const payableComplete: Invoice = {
  ...payableFresh,
  totalPaid: 10000,
  remaining: 0,
  status: 'Paid',
  isLocked: true,
};

assert(
  payableComplete.billingState === 'payable' && payableComplete.status === 'Paid' && payableComplete.isLocked,
  'Payment Workflow',
  'Payable invoice transitions to "Paid" and locks upon full settlement'
);

// =========================================================================
// Suite 6: Permanent Deletion Rules
// =========================================================================
console.log('\n--- Suite 6: Permanent Deletion Rules ---');

function canPermanentlyDeleteInvoice(
  userRole: string,
  invoice: Invoice,
  hasPaymentRecords: boolean
): { allowed: boolean; reason?: string } {
  if (userRole !== 'super_admin' && userRole !== 'invoice_manager') {
    return { allowed: false, reason: 'Access Denied: Only Super Admin and Invoice Manager can delete.' };
  }
  const bState = invoice.billingState || 'payable';
  if (bState === 'payable') {
    return { allowed: false, reason: 'Confirmed financial invoices cannot be deleted. Use Void instead.' };
  }
  if (invoice.status === 'Paid' || invoice.status === 'Partially Paid' || (invoice.totalPaid || 0) > 0) {
    return { allowed: false, reason: 'Invoices with financial activity cannot be deleted.' };
  }
  if (hasPaymentRecords) {
    return { allowed: false, reason: 'Cannot delete invoice with existing payment records.' };
  }
  return { allowed: true };
}

assert(
  canPermanentlyDeleteInvoice('super_admin', defaultQuotation, false).allowed,
  'Deletion Rules',
  'Super Admin can permanently delete unconfirmed quotation'
);

assert(
  canPermanentlyDeleteInvoice('invoice_manager', rejectedInvoice, false).allowed,
  'Deletion Rules',
  'Invoice Manager can permanently delete rejected quotation'
);

assert(
  !canPermanentlyDeleteInvoice('customer', defaultQuotation, false).allowed,
  'Deletion Rules',
  'Customer cannot delete quotation'
);

assert(
  !canPermanentlyDeleteInvoice('super_admin', payableFresh, false).allowed,
  'Deletion Rules',
  'Super Admin CANNOT delete confirmed payable invoice (must use Void)'
);

assert(
  !canPermanentlyDeleteInvoice('super_admin', payableComplete, true).allowed,
  'Deletion Rules',
  'Super Admin CANNOT delete paid invoice with payment history'
);

// =========================================================================
// Suite 7: Backward Compatibility
// =========================================================================
console.log('\n--- Suite 7: Backward Compatibility ---');

const legacyInvoice: any = {
  id: 'legacy-inv-1',
  billNumber: 'ST-1001',
  customerId: 'cust-101',
  totalAmount: 15000,
  totalPaid: 15000,
  status: 'Paid',
  // Note: billingState is omitted/undefined (historical record from prior version)
};

const resolvedBillingState = getInvoiceBillingState(legacyInvoice);
assert(
  resolvedBillingState === 'payable',
  'Backward Compatibility',
  'Historical invoice with missing billingState safely defaults to "payable"'
);

assert(
  isInvoicePayable(legacyInvoice),
  'Backward Compatibility',
  'Historical invoice is recognized as payable and never converted to quotation'
);

const legacyCustomerSummary = calculateCustomerSummary('cust-101', [legacyInvoice], []);
assert(
  legacyCustomerSummary.totalSales === 15000,
  'Backward Compatibility',
  'Historical invoices contribute fully to customer sales totals'
);

// =========================================================================
// Summary
// =========================================================================
const totalCount = results.length;
const passedCount = results.filter((r) => r.passed).length;
const failedCount = totalCount - passedCount;

console.log('\n===============================================================');
console.log(`INVOICE BILLING STATE WORKFLOW TEST SUITE: ${passedCount}/${totalCount} PASSED`);
if (failedCount === 0) {
  console.log('STATUS: ALL TESTS PASSED SUCCESSFULLY! ✓');
} else {
  console.error(`STATUS: ${failedCount} TESTS FAILED! ✗`);
}
console.log('===============================================================\n');

if (failedCount > 0) {
  process.exit(1);
}
