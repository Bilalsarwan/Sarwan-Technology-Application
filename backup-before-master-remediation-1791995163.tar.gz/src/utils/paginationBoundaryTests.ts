/**
 * Rigorous test suite for Invoice Pagination Boundary and Item Continuity.
 * Verifies that no items are ever skipped, lost, duplicated, or clipped
 * across all page boundaries, with exact tests for:
 * 20, 21, 23, 24, 25, 26, 27, 28, 30, 50, and 100 items.
 */
import { CanonicalInvoiceItem } from '../types/canonicalInvoiceDocument';
import { paginateInvoiceItems, calculateInvoicePageChunks } from './canonicalInvoicePagination';
import { DEFAULT_INVOICE_DESIGN } from '../types/invoiceDesign';

interface TestResult {
  name: string;
  passed: boolean;
  error?: string;
}

const results: TestResult[] = [];

function test(name: string, fn: () => void) {
  try {
    fn();
    results.push({ name, passed: true });
  } catch (err: any) {
    results.push({ name, passed: false, error: err?.message || String(err) });
  }
}

function expect(condition: boolean, msg: string) {
  if (!condition) throw new Error(msg);
}

function createTestItems(count: number): CanonicalInvoiceItem[] {
  return Array.from({ length: count }, (_, idx) => ({
    sNo: idx + 1,
    description: `Test Invoice Item Description #${idx + 1}`,
    quantity: 1,
    unit: 'pcs',
    unitPrice: 100 + idx * 10,
    totalAmount: 100 + idx * 10,
  }));
}

export function runPaginationBoundaryTests(): { total: number; passed: number; failed: number } {
  const paperA4Portrait = { paperSize: 'A4' as const, orientation: 'portrait' as const };

  // =========================================================================
  // Core Invariant Test for Required Item Counts
  // =========================================================================
  const testCounts = [20, 21, 23, 24, 25, 26, 27, 28, 30, 50, 100];

  for (const n of testCounts) {
    test(`Pagination Continuity & Invariant: ${n} items`, () => {
      const sourceItems = createTestItems(n);
      const pages = paginateInvoiceItems(sourceItems, paperA4Portrait, DEFAULT_INVOICE_DESIGN);
      const allPageItems = pages.flatMap((p) => p.items);

      // Invariant 1: Total source item count === total rendered item count
      expect(
        allPageItems.length === sourceItems.length,
        `Expected ${sourceItems.length} items rendered across pages, but got ${allPageItems.length}`
      );

      // Invariant 2: Every source item appears exactly once in identical order
      for (let i = 0; i < n; i++) {
        expect(
          allPageItems[i].sNo === sourceItems[i].sNo,
          `Item index ${i}: expected sNo ${sourceItems[i].sNo}, got ${allPageItems[i].sNo}`
        );
        expect(
          allPageItems[i].description === sourceItems[i].description,
          `Item index ${i}: description mismatch`
        );
      }

      // Invariant 3: Boundary continuity between adjacent pages
      for (let p = 0; p < pages.length - 1; p++) {
        const lastItemOfCurrentPage = pages[p].items[pages[p].items.length - 1];
        const firstItemOfNextPage = pages[p + 1].items[0];

        expect(
          Boolean(lastItemOfCurrentPage),
          `Page ${p + 1} has no items`
        );
        expect(
          Boolean(firstItemOfNextPage),
          `Page ${p + 2} has no items`
        );
        expect(
          lastItemOfCurrentPage.sNo + 1 === firstItemOfNextPage.sNo,
          `Page boundary gap detected between page ${p + 1} (ends at #${lastItemOfCurrentPage.sNo}) and page ${p + 2} (starts at #${firstItemOfNextPage.sNo})`
        );
      }

      // Invariant 4: Final page closing section flags
      pages.forEach((p, idx) => {
        const isFinal = idx === pages.length - 1;
        expect(
          p.isLastPage === isFinal,
          `Page ${idx + 1} isLastPage flag mismatch`
        );
        expect(
          p.showNotes === isFinal,
          `Page ${idx + 1} showNotes expected ${isFinal}, got ${p.showNotes}`
        );
        expect(
          p.showSignatures === isFinal,
          `Page ${idx + 1} showSignatures expected ${isFinal}, got ${p.showSignatures}`
        );
        expect(
          p.showPayment === isFinal,
          `Page ${idx + 1} showPayment expected ${isFinal}, got ${p.showPayment}`
        );
      });
    });
  }

  // =========================================================================
  // Specific Test for 30-Item Invoice Boundary (Item #24 Continuity)
  // =========================================================================
  test('Specific Test: 30-item invoice splits at row #23 and page 2 starts at row #24', () => {
    const sourceItems = createTestItems(30);
    const pages = paginateInvoiceItems(sourceItems, paperA4Portrait, DEFAULT_INVOICE_DESIGN);

    expect(pages.length === 2, `Expected 2 pages for 30 items, got ${pages.length}`);

    const page1 = pages[0];
    const page2 = pages[1];

    expect(page1.items.length === 23, `Page 1 should have 23 items to avoid overflow, got ${page1.items.length}`);
    expect(page2.items.length === 7, `Page 2 should have 7 items, got ${page2.items.length}`);

    expect(page1.items[0].sNo === 1, 'Page 1 starts at item #1');
    expect(page1.items[22].sNo === 23, 'Page 1 ends at item #23');

    // CRITICAL BUG FIX VERIFICATION:
    expect(page2.items[0].sNo === 24, `Page 2 MUST start at item #24 (got ${page2.items[0].sNo})`);
    expect(page2.items[6].sNo === 30, 'Page 2 ends at item #30');
  });

  // =========================================================================
  // Summary
  // =========================================================================
  console.log('===============================================================');
  console.log('       INVOICE PAGINATION BOUNDARY VERIFICATION RESULTS       ');
  console.log('===============================================================');

  let passed = 0;
  let failed = 0;

  results.forEach((r) => {
    if (r.passed) {
      passed++;
      console.log(`[✓ PASS] ${r.name}`);
    } else {
      failed++;
      console.error(`[✗ FAIL] ${r.name}: ${r.error}`);
    }
  });

  console.log('---------------------------------------------------------------');
  console.log(`TOTAL: ${results.length} Tests | PASSED: ${passed} | FAILED: ${failed}`);
  console.log('===============================================================');

  return { total: results.length, passed, failed };
}

// Auto-run if executed directly
if (process.argv[1] && process.argv[1].endsWith('paginationBoundaryTests.ts')) {
  const summary = runPaginationBoundaryTests();
  if (summary.failed > 0) {
    process.exit(1);
  }
}
