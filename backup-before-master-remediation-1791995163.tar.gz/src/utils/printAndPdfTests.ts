/**
 * Comprehensive verification test suite for PDF export, canonical document resolution, and saved invoice design.
 */
import { Invoice, Payment, BusinessSettings } from '../types';
import { DEFAULT_INVOICE_DESIGN } from '../types/invoiceDesign';
import { buildCanonicalInvoiceDocument } from './canonicalInvoiceDocument';
import {
  isInvoiceActionInProgress,
  generateInvoiceFilename,
  resolveCanonicalDocument,
  verifyCanonicalInvoiceDocumentStructure,
} from './print';

interface TestResult {
  suite: string;
  name: string;
  passed: boolean;
  error?: string;
}

const results: TestResult[] = [];

function test(suite: string, name: string, fn: () => void) {
  try {
    fn();
    results.push({ suite, name, passed: true });
  } catch (err: any) {
    results.push({ suite, name, passed: false, error: err?.message || String(err) });
  }
}

function expect(condition: boolean, msg: string) {
  if (!condition) throw new Error(msg);
}

export function runPrintAndPdfTests(): { total: number; passed: number; failed: number } {
  const sampleSettings: BusinessSettings = {
    companyName: 'Sarwan Technology',
    logo: '/sarwan-logo.png',
    logo2: '/dahua-logo.svg',
    phone: '0731339014',
    whatsapp: '0778771020',
    email: 'Sarwantechnology.af@gmail.com',
    address: 'Kabul, Afghanistan',
    currency: 'AFN',
    invoicePrefix: 'ST-',
    nextInvoiceNumber: 1060,
    invoiceNote: 'Thank you for choosing Sarwan Technology.',
    authorizedEmails: ['admin@sarwantechnology.com'],
    invoiceDesign: {
      ...DEFAULT_INVOICE_DESIGN,
      title: {
        ...DEFAULT_INVOICE_DESIGN.title,
        text: 'CUSTOM SYSTEM TITLE',
      },
      colors: {
        ...DEFAULT_INVOICE_DESIGN.colors,
        primary: '#F58220',
      },
    },
  };

  const sampleInvoice: Invoice = {
    id: 'inv-test-real-1',
    billNumber: 'ST-1060',
    customerId: 'cust-1',
    customerSnapshot: {
      id: 'cust-1',
      name: 'Kabul Tech Trading Co.',
      phone: '0788112233',
      address: 'Karte 4, Kabul',
      companyName: 'Kabul Tech Ltd.',
    },
    date: '2026-09-28',
    totalAmount: 45000,
    totalPaid: 25000,
    remaining: 20000,
    status: 'Partially Paid',
    items: [
      { sNo: 1, description: '4K CCTV IP Camera', quantity: 4, unitPrice: 5000, totalAmount: 20000 },
      { sNo: 2, description: '8-Port PoE Gigabit Switch', quantity: 2, unitPrice: 7500, totalAmount: 15000 },
      { sNo: 3, description: 'Installation & Network Termination', quantity: 1, unitPrice: 10000, totalAmount: 10000 },
    ],
    createdAt: '2026-09-28T08:00:00Z',
    updatedAt: '2026-09-28T08:00:00Z',
    companySnapshot: sampleSettings,
    note: '',
  };

  const samplePayments: Payment[] = [
    {
      id: 'pay-1',
      invoiceId: 'inv-test-real-1',
      billNumber: 'ST-1060',
      customerId: 'cust-1',
      customerName: 'Kabul Tech Trading Co.',
      amount: 25000,
      date: '2026-09-28',
      time: '10:00:00',
      method: 'CASH',
      note: '',
      recordedBy: 'admin',
      recordedByName: 'Super Admin',
      createdAt: '2026-09-28T10:00:00Z',
    },
  ];

  // ==========================================
  // Suite 1: Canonical Document Resolution & Filename
  // ==========================================
  test('Canonical Document & Filename', 'Resolves canonical document from Invoice object with intact calculations', () => {
    const doc = resolveCanonicalDocument({
      invoice: sampleInvoice,
      payments: samplePayments,
      settings: sampleSettings,
    });

    expect(doc.billNumber === 'ST-1060', 'Preserves bill number');
    expect(doc.customer.name === 'Kabul Tech Trading Co.', 'Preserves customer name');
    expect(doc.totalPrice === 45000, 'Preserves total price');
    expect(doc.totalPaid === 25000, 'Preserves total paid');
    expect(doc.remainingBalance === 20000, 'Preserves remaining balance');
    expect(doc.status === 'Partially Paid', 'Preserves status calculation');
    expect(doc.items.length === 3, 'Preserves items');
  });

  test('Canonical Document & Filename', 'Generates clean descriptive PDF filename', () => {
    const filename = generateInvoiceFilename(sampleInvoice);
    expect(filename === 'Sarwan-Technology-Invoice-ST-1060.pdf', `Generated filename: ${filename}`);
  });

  test('Canonical Document & Filename', 'PDF export concurrency lock is idle by default', () => {
    expect(isInvoiceActionInProgress() === false, 'Action in progress must be false initially');
  });

  // ==========================================
  // Suite 2: Saved Invoice Design Export
  // ==========================================
  test('Saved Invoice Design Export', 'Automatically applies current saved system design to export document', () => {
    const doc = buildCanonicalInvoiceDocument({
      invoice: sampleInvoice,
      payments: samplePayments,
      settings: sampleSettings,
    });

    expect(doc.design.title.text === 'CUSTOM SYSTEM TITLE', 'Preserves saved custom title');
    expect(doc.design.colors.primary === '#F58220', 'Preserves saved primary color');
    expect(doc.company.logo === '/sarwan-logo.png', 'Preserves saved logo');
  });

  test('Saved Invoice Design Export', 'Uses default invoice design structure when settings.invoiceDesign is empty', () => {
    const settingsWithoutCustomDesign: BusinessSettings = {
      ...sampleSettings,
      invoiceDesign: undefined,
    };

    const doc = buildCanonicalInvoiceDocument({
      invoice: sampleInvoice,
      payments: samplePayments,
      settings: settingsWithoutCustomDesign,
    });

    expect(doc.design.title.text === DEFAULT_INVOICE_DESIGN.title.text, 'Falls back to default title text');
    expect(doc.paperConfig.paperSize === 'A4', 'Defaults to A4 paper');
  });

  // ==========================================
  // Suite 3: Data Consistency & Non-Mutation
  // ==========================================
  test('Data Consistency & Non-Mutation', 'Export document creation does not mutate business settings', () => {
    const originalTitle = sampleSettings.invoiceDesign?.title?.text;

    const doc = buildCanonicalInvoiceDocument({
      invoice: sampleInvoice,
      payments: samplePayments,
      settings: sampleSettings,
    });

    expect(Boolean(doc), 'Generated doc is valid');
    expect(sampleSettings.invoiceDesign?.title?.text === originalTitle, 'System settings were not mutated');
  });

  test('Data Consistency & Non-Mutation', 'Preview and export documents are identical for saved invoice design', () => {
    const docForPreview = buildCanonicalInvoiceDocument({
      invoice: sampleInvoice,
      payments: samplePayments,
      settings: sampleSettings,
    });

    const docForExport = buildCanonicalInvoiceDocument({
      invoice: sampleInvoice,
      payments: samplePayments,
      settings: sampleSettings,
    });

    expect(docForPreview.billNumber === docForExport.billNumber, 'Bill numbers match');
    expect(docForPreview.totalPrice === docForExport.totalPrice, 'Totals match');
    expect(docForPreview.totalPaid === docForExport.totalPaid, 'Total paid matches');
    expect(docForPreview.remainingBalance === docForExport.remainingBalance, 'Remaining matches');
    expect(docForPreview.design.title.text === docForExport.design.title.text, 'Design titles match');
    expect(docForPreview.items.length === docForExport.items.length, 'Item lengths match');
  });

  // ==========================================
  // Suite 4: Dual Entry Points (Invoice List & Invoice Details Modal)
  // ==========================================
  test('Dual Entry Points', 'Invoice List Entry Point builds complete canonical document for real invoice', () => {
    const docFromList = resolveCanonicalDocument({
      invoice: sampleInvoice,
      payments: samplePayments,
      settings: sampleSettings,
    });

    expect(docFromList.billNumber === 'ST-1060', 'List entry point billNumber matches');
    expect(docFromList.customer.name === 'Kabul Tech Trading Co.', 'List entry point customer matches');
    expect(docFromList.totalPrice === 45000, 'List entry point total matches');
    expect(docFromList.totalPaid === 25000, 'List entry point paid matches');
    expect(docFromList.remainingBalance === 20000, 'List entry point remaining matches');
    expect(docFromList.status === 'Partially Paid', 'List entry point status matches');
    expect(docFromList.paperConfig.paperSize === 'A4', 'List entry point paper config defaults to A4');
  });

  test('Dual Entry Points', 'Invoice Detail Modal Entry Point builds complete canonical document with override', () => {
    const docFromDetailModal = buildCanonicalInvoiceDocument({
      invoice: sampleInvoice,
      totalPaidOverride: 25000,
      settings: sampleSettings,
    });

    expect(docFromDetailModal.billNumber === 'ST-1060', 'Detail modal billNumber matches');
    expect(docFromDetailModal.totalPrice === 45000, 'Detail modal total matches');
    expect(docFromDetailModal.totalPaid === 25000, 'Detail modal totalPaid matches');
    expect(docFromDetailModal.remainingBalance === 20000, 'Detail modal remaining matches');
    expect(docFromDetailModal.items.length === 3, 'Detail modal items count matches');
  });

  // ==========================================
  // Suite 5: Unique Invoice DOM IDs & Exact Target Capture
  // ==========================================
  test('Unique Invoice Document DOM IDs', 'Validates unique DOM IDs for preview, download modal, draft preview, and staging', () => {
    const detailPreviewId = 'invoice-detail-preview-document';
    const pdfDownloadId = 'invoice-pdf-download-document';
    const draftPreviewId = 'invoice-draft-preview-document';
    const stagingId = 'invoice-pdf-staging-document';

    const ids = [detailPreviewId, pdfDownloadId, draftPreviewId, stagingId];
    const uniqueIds = new Set(ids);
    expect(uniqueIds.size === ids.length, 'All 4 invoice document IDs must be mutually unique');
    expect(ids.includes('invoice-detail-preview-document'), 'invoice-detail-preview-document defined');
    expect(ids.includes('invoice-pdf-download-document'), 'invoice-pdf-download-document defined');
    expect(ids.includes('invoice-draft-preview-document'), 'invoice-draft-preview-document defined');
    expect(ids.includes('invoice-pdf-staging-document'), 'invoice-pdf-staging-document defined');
  });

  // ==========================================
  // Suite 6: Canonical Document Verification & Parity Checks
  // ==========================================
  test('Canonical Document Verification', 'verifyCanonicalInvoiceDocumentStructure flags missing required sections', () => {
    const mockContainer = {
      querySelector: (sel: string) => {
        if (sel === '#invoice-header-section') return {};
        if (sel === '#invoice-header-company-name') return {};
        return null;
      },
      querySelectorAll: () => [{}, {}],
    } as any;

    const report = verifyCanonicalInvoiceDocumentStructure(mockContainer, 100);
    expect(!report.isValid, 'Should detect invalid/incomplete document');
    expect(report.missingSections.length > 0, 'Should list missing sections');
    expect(report.deviations.length > 0, 'Should record deviation messages');
  });

  test('Canonical Document Verification', 'verifyCanonicalInvoiceDocumentStructure passes when all sections and header components are present', () => {
    const validSections = [
      '#invoice-header-section',
      '#invoice-title-meta-section',
      '#invoice-customer-section',
      '#invoice-items-table-section',
      '#invoice-payment-totals-section',
      '#invoice-notes-section',
      '#invoice-signatures-section',
      '#invoice-footer-section',
      '#invoice-header-logo-1',
      '#invoice-header-company-name',
      '#invoice-header-pashto-name',
      '#invoice-header-slogan',
      '#invoice-header-logo-2',
    ];

    const mockCompleteContainer = {
      querySelector: (sel: string) => (validSections.includes(sel) ? {} : null),
      querySelectorAll: () => new Array(50).fill({}),
    } as any;

    const report = verifyCanonicalInvoiceDocumentStructure(mockCompleteContainer, 25000);
    expect(report.isValid === true, 'Complete document must pass verification');
    expect(report.foundSections.length === 8, 'Found all 8 canonical sections');
    expect(report.foundHeaderComponents.length === 5, 'Found all 5 header components');
    expect(report.deviations.length === 0, 'No deviations reported for complete document');
  });

  test('Canonical Document Verification', 'Detects and reports PDF byte size deviations', () => {
    const validSections = [
      '#invoice-header-section',
      '#invoice-title-meta-section',
      '#invoice-customer-section',
      '#invoice-items-table-section',
      '#invoice-payment-totals-section',
      '#invoice-notes-section',
      '#invoice-signatures-section',
      '#invoice-footer-section',
      '#invoice-header-logo-1',
      '#invoice-header-company-name',
      '#invoice-header-pashto-name',
      '#invoice-header-slogan',
      '#invoice-header-logo-2',
    ];

    const mockContainer = {
      querySelector: (sel: string) => (validSections.includes(sel) ? {} : null),
      querySelectorAll: () => new Array(50).fill({}),
    } as any;

    // PDF size is only 500 bytes (far below expected minimum of 3000 bytes)
    const report = verifyCanonicalInvoiceDocumentStructure(mockContainer, 500);
    expect(report.isValid === false, 'Undersized PDF must trigger deviation');
    expect(report.deviations.some(d => d.includes('PDF size')), 'Report includes PDF size deviation');
  });

  // ==========================================
  // Suite 7: 100% Invoice Preview / PDF Parity Cases (A - M)
  // ==========================================
  test('Preview/PDF Parity Cases (A-M)', 'Case A: Default Design #7 produces identical canonical structure', () => {
    const doc = buildCanonicalInvoiceDocument({
      invoice: sampleInvoice,
      payments: samplePayments,
      settings: sampleSettings,
    });
    expect(doc.design.colors.primary !== '', 'Primary color present');
    expect(doc.paperConfig.paperSize === 'A4', 'Paper size is A4');
    expect(doc.items.length === 3, 'Items length matches');
  });

  test('Preview/PDF Parity Cases (A-M)', 'Case B: Custom typography propagates without alteration', () => {
    const customSettings: BusinessSettings = {
      ...sampleSettings,
      invoiceDesign: {
        ...DEFAULT_INVOICE_DESIGN,
        typography: {
          ...DEFAULT_INVOICE_DESIGN.typography,
          fontFamily: 'Montserrat',
          headingFontFamily: 'Amiri',
          baseFontSize: 11,
        },
      },
    };
    const doc = buildCanonicalInvoiceDocument({
      invoice: sampleInvoice,
      payments: samplePayments,
      settings: customSettings,
    });
    expect(doc.design.typography.fontFamily === 'Montserrat', 'Font family is Montserrat');
    expect(doc.design.typography.headingFontFamily === 'Amiri', 'Heading font family is Amiri');
    expect(doc.design.typography.baseFontSize === 11, 'Base font size is 11');
  });

  test('Preview/PDF Parity Cases (A-M)', 'Case C: Custom colors preserve exact HEX values for Preview and PDF', () => {
    const customSettings: BusinessSettings = {
      ...sampleSettings,
      invoiceDesign: {
        ...DEFAULT_INVOICE_DESIGN,
        colors: {
          ...DEFAULT_INVOICE_DESIGN.colors,
          primary: '#1A365D',
          secondary: '#E2E8F0',
          tableHeaderBackground: '#2B6CB0',
          tableHeaderText: '#FFFFFF',
        },
      },
    };
    const doc = buildCanonicalInvoiceDocument({
      invoice: sampleInvoice,
      settings: customSettings,
    });
    expect(doc.design.colors.primary === '#1A365D', 'Primary color preserved');
    expect(doc.design.colors.secondary === '#E2E8F0', 'Secondary color preserved');
    expect(doc.design.colors.tableHeaderBackground === '#2B6CB0', 'Table header background preserved');
    expect(doc.design.colors.tableHeaderText === '#FFFFFF', 'Table header text preserved');
  });

  test('Preview/PDF Parity Cases (A-M)', 'Case D: Hidden/shown elements are strictly synchronized', () => {
    const customSettings: BusinessSettings = {
      ...sampleSettings,
      invoiceDesign: {
        ...DEFAULT_INVOICE_DESIGN,
        header: {
          ...DEFAULT_INVOICE_DESIGN.header,
          show: false,
        },
        collector: {
          ...DEFAULT_INVOICE_DESIGN.collector,
          show: false,
        },
        notes: {
          ...DEFAULT_INVOICE_DESIGN.notes,
          showInvoiceNote: false,
        },
      },
    };
    const doc = buildCanonicalInvoiceDocument({
      invoice: sampleInvoice,
      settings: customSettings,
    });
    expect(doc.design.header.show === false, 'Header is hidden');
    expect(doc.design.collector.show === false, 'Collector is hidden');
    expect(doc.design.notes.showInvoiceNote === false, 'Notes are hidden');
  });

  test('Preview/PDF Parity Cases (A-M)', 'Case E: Custom table columns retain canonical order and properties', () => {
    const customSettings: BusinessSettings = {
      ...sampleSettings,
      invoiceDesign: {
        ...DEFAULT_INVOICE_DESIGN,
        itemsTable: {
          ...DEFAULT_INVOICE_DESIGN.itemsTable,
          columnOrder: ['sNo', 'description', 'quantity', 'unitPrice', 'totalAmount'],
          columns: {
            ...DEFAULT_INVOICE_DESIGN.itemsTable.columns,
            description: {
              ...DEFAULT_INVOICE_DESIGN.itemsTable.columns.description,
              label: 'Item Particulars',
              width: '45%',
            },
          },
        },
      },
    };
    const doc = buildCanonicalInvoiceDocument({
      invoice: sampleInvoice,
      settings: customSettings,
    });
    expect(doc.design.itemsTable.columnOrder[0] === 'sNo', 'First column is sNo');
    expect(doc.design.itemsTable.columnOrder[1] === 'description', 'Second column is description');
    expect(doc.design.itemsTable.columns.description.label === 'Item Particulars', 'Custom label preserved');
    expect(doc.design.itemsTable.columns.description.width === '45%', 'Custom width preserved');
  });

  test('Preview/PDF Parity Cases (A-M)', 'Case F: Custom spacing gaps are preserved exactly', () => {
    const customSettings: BusinessSettings = {
      ...sampleSettings,
      invoiceDesign: {
        ...DEFAULT_INVOICE_DESIGN,
        spacing: {
          ...DEFAULT_INVOICE_DESIGN.spacing,
          headerToMeta: 18,
          metaToCustomer: 14,
          customerToTable: 16,
          tableToPayment: 20,
          totalsToNotes: 15,
          notesToSignatures: 22,
          footerSpacing: 25,
        },
      },
    };
    const doc = buildCanonicalInvoiceDocument({
      invoice: sampleInvoice,
      settings: customSettings,
    });
    expect(doc.design.spacing.headerToMeta === 18, 'Header to meta gap preserved');
    expect(doc.design.spacing.tableToPayment === 20, 'Table to payment gap preserved');
    expect(doc.design.spacing.footerSpacing === 25, 'Footer spacing preserved');
  });

  test('Preview/PDF Parity Cases (A-M)', 'Case G: Custom margins propagate into document geometry', () => {
    const customSettings: BusinessSettings = {
      ...sampleSettings,
      invoiceDesign: {
        ...DEFAULT_INVOICE_DESIGN,
        page: {
          ...DEFAULT_INVOICE_DESIGN.page,
          margins: {
            top: 15,
            bottom: 15,
            left: 14,
            right: 14,
          },
        },
      },
    };
    const doc = buildCanonicalInvoiceDocument({
      invoice: sampleInvoice,
      settings: customSettings,
    });
    expect(doc.design.page.margins.top === 15, 'Top margin preserved');
    expect(doc.design.page.margins.left === 14, 'Left margin preserved');
    expect(doc.design.page.margins.right === 14, 'Right margin preserved');
    expect(doc.design.page.margins.bottom === 15, 'Bottom margin preserved');
  });

  test('Preview/PDF Parity Cases (A-M)', 'Case H: Custom dual logos propagate directly to document', () => {
    const customSettings: BusinessSettings = {
      ...sampleSettings,
      invoiceDesign: {
        ...DEFAULT_INVOICE_DESIGN,
        logos: {
          logo1: {
            ...DEFAULT_INVOICE_DESIGN.logos.logo1,
            url: '/custom-primary.png',
            show: true,
          },
          logo2: {
            ...DEFAULT_INVOICE_DESIGN.logos.logo2,
            url: '/custom-partner.svg',
            show: true,
          },
        },
      },
    };
    const doc = buildCanonicalInvoiceDocument({
      invoice: sampleInvoice,
      settings: customSettings,
    });
    expect(doc.design.logos.logo1.url === '/custom-primary.png', 'Left logo URL preserved');
    expect(doc.design.logos.logo2.url === '/custom-partner.svg', 'Right logo URL preserved');
  });

  test('Preview/PDF Parity Cases (A-M)', 'Case I: Custom signatures retain labels and dimensions', () => {
    const customSettings: BusinessSettings = {
      ...sampleSettings,
      invoiceDesign: {
        ...DEFAULT_INVOICE_DESIGN,
        signatures: {
          ...DEFAULT_INVOICE_DESIGN.signatures,
          customerSignatureLabel: 'Verified & Received By',
          managerSignatureLabel: 'Authorized Officer',
          showCustomerSignature: true,
          showManagerSignature: true,
          customerWidth: '200px',
        },
      },
    };
    const doc = buildCanonicalInvoiceDocument({
      invoice: sampleInvoice,
      settings: customSettings,
    });
    expect(doc.design.signatures.customerSignatureLabel === 'Verified & Received By', 'Customer label preserved');
    expect(doc.design.signatures.managerSignatureLabel === 'Authorized Officer', 'Manager label preserved');
    expect(doc.design.signatures.customerWidth === '200px', 'Customer signature width preserved');
  });

  test('Preview/PDF Parity Cases (A-M)', 'Case J: Multi-page invoice preserves A4 dimensions and item integrity', () => {
    const multiItemInvoice: Invoice = {
      ...sampleInvoice,
      items: Array.from({ length: 30 }, (_, i) => ({
        sNo: i + 1,
        description: `High-Density Network Terminal #${i + 1}`,
        quantity: 2,
        unitPrice: 1200,
        totalAmount: 2400,
      })),
      totalAmount: 72000,
    };
    const doc = buildCanonicalInvoiceDocument({
      invoice: multiItemInvoice,
      settings: sampleSettings,
    });
    expect(doc.items.length === 30, 'All 30 items present in canonical document');
    expect(doc.totalPrice === 72000, 'Total price unchanged for multi-page');
    expect(doc.paperConfig.widthMm === 210, 'A4 width 210mm');
    expect(doc.paperConfig.heightMm === 297, 'A4 height 297mm');
  });

  test('Preview/PDF Parity Cases (A-M)', 'Case K: RTL/Pashto text does not alter column order or numbers', () => {
    const rtlInvoice: Invoice = {
      ...sampleInvoice,
      customerSnapshot: {
        ...sampleInvoice.customerSnapshot,
        name: 'د کابل تخنیکي شرکت',
        address: 'څلورمه کارته، کابل',
      },
    };
    const doc = buildCanonicalInvoiceDocument({
      invoice: rtlInvoice,
      settings: sampleSettings,
    });
    expect(doc.customer.name === 'د کابل تخنیکي شرکت', 'Pashto customer name preserved');
    expect(doc.design.itemsTable.columnOrder[0] === 'sNo', 'Items table column order is NOT reversed by RTL');
    expect(doc.totalPrice === 45000, 'Calculations remain intact');
  });

  test('Preview/PDF Parity Cases (A-M)', 'Case L: Long customer names preserve intact string without truncation', () => {
    const longName = 'International Consortium for Telecommunication Infrastructure, Networking, and Surveillance Systems Afghanistan Branch Ltd.';
    const longNameInvoice: Invoice = {
      ...sampleInvoice,
      customerSnapshot: {
        ...sampleInvoice.customerSnapshot,
        name: longName,
      },
    };
    const doc = buildCanonicalInvoiceDocument({
      invoice: longNameInvoice,
      settings: sampleSettings,
    });
    expect(doc.customer.name === longName, 'Long customer name is fully preserved');
  });

  test('Preview/PDF Parity Cases (A-M)', 'Case M: Long item descriptions preserve full text without calculation shifts', () => {
    const longDesc = 'High-Performance 32-Channel Network Video Recorder with AI Deep Learning Face Recognition, H.265+ Smart Codec Compression, Redundant Power Supply, and 4x8TB Enterprise Surveillance Hard Drives Installed';
    const longDescInvoice: Invoice = {
      ...sampleInvoice,
      items: [
        { sNo: 1, description: longDesc, quantity: 2, unitPrice: 35000, totalAmount: 70000 },
      ],
      totalAmount: 70000,
    };
    const doc = buildCanonicalInvoiceDocument({
      invoice: longDescInvoice,
      settings: sampleSettings,
    });
    expect(doc.items[0].description === longDesc, 'Long item description preserved intact');
    expect(doc.totalPrice === 70000, 'Calculations are unchanged');
  });

  // ==========================================
  // Suite 8: Master Parity Acceptance Test (Requirement 15)
  // ==========================================
  test('Master Parity Acceptance (Req 15)', 'Full customized invoice produces identical models across Designer, Preview, PDF Preview, and Download', () => {
    const fullyCustomizedSettings: BusinessSettings = {
      companyName: 'Sarwan Tech Enterprise Solutions',
      logo: '/sarwan-primary-logo.png',
      logo2: '/partner-security-badge.svg',
      phone: '+93 73 133 9014',
      whatsapp: '+93 77 877 1020',
      email: 'enterprise@sarwantechnology.com',
      address: 'Shah-re-Naw, Street 3, Kabul, Afghanistan',
      currency: 'AFN',
      invoicePrefix: 'STE-',
      nextInvoiceNumber: 2050,
      invoiceNote: 'All equipment covers a 12-month manufacturer replacement warranty.',
      authorizedEmails: ['admin@sarwantechnology.com'],
      invoiceDesign: {
        ...DEFAULT_INVOICE_DESIGN,
        // Page & Margins
        page: {
          paperSize: 'A4',
          orientation: 'portrait',
          margins: { top: 14, right: 14, bottom: 14, left: 14 },
          showCornerDecorations: true,
          showPageBorder: true,
        },
        // Decorative Shapes
        shapes: {
          topLeft: { show: true, fillColor: '#002B49', accentColor: '#F58220', borderWidth: 3, width: 130, height: 65, opacity: 1 },
          topRight: { show: true, fillColor: '#002B49', accentColor: '#F58220', borderWidth: 3, width: 130, height: 65, opacity: 1 },
          goldAccent: { show: true, fillColor: '#F58220', accentColor: '#002B49', borderWidth: 2, width: 70, height: 4, opacity: 1 },
        },
        // Logos
        logos: {
          logo1: { show: true, url: '/sarwan-primary-logo.png', width: 140, height: 60, position: 'left', alignment: 'center', margin: 4, opacity: 1 },
          logo2: { show: true, url: '/partner-security-badge.svg', width: 130, height: 55, position: 'right', alignment: 'center', margin: 4, opacity: 1 },
        },
        // Company Name & Pashto & Slogan
        company: {
          ...DEFAULT_INVOICE_DESIGN.company,
          showName: true,
          name: 'Sarwan Tech Enterprise Solutions',
          showPashtoName: true,
          pashtoName: 'د سرور ټیکنالوژي پرمختللي حلونه',
          pashtoFontSize: 16,
          pashtoFontFamily: 'Amiri',
          pashtoColor: '#002B49',
          slogan: 'Leading the Future of Secure Networking & CCTV',
          sloganFontSize: 12,
          sloganFontFamily: 'Montserrat',
          sloganColor: '#F58220',
          fontFamily: 'Montserrat',
          fontSize: 12,
        },
        // Invoice Number, Dates, Due Date
        invoiceNumber: {
          ...DEFAULT_INVOICE_DESIGN.invoiceNumber,
          show: true,
          label: 'INVOICE REF',
          fontSize: 14,
          fontFamily: 'Montserrat',
          color: '#002B49',
          valueColor: '#1A202C',
        },
        date: {
          ...DEFAULT_INVOICE_DESIGN.date,
          show: true,
          showDueDate: true,
          label: 'ISSUE DATE',
          dueDateLabel: 'PAYMENT DUE',
          fontSize: 11,
          fontFamily: 'Inter',
        },
        // Customer Information
        customer: {
          ...DEFAULT_INVOICE_DESIGN.customer,
          show: true,
          showName: true,
          showPhone: true,
          showEmail: true,
          showAddress: true,
          showCompany: true,
          showCustomerId: true,
          label: 'BILLING RECIPIENT',
          fontSize: 11,
          fontFamily: 'Inter',
          nameFontFamily: 'Montserrat',
        },
        // Table Columns & Custom Widths
        itemsTable: {
          ...DEFAULT_INVOICE_DESIGN.itemsTable,
          show: true,
          columnOrder: ['sNo', 'description', 'quantity', 'unit', 'unitPrice', 'discount', 'tax', 'totalAmount'],
          columns: {
            sNo: { show: true, label: '#', width: '6%', align: 'center' },
            description: { show: true, label: 'Service & Product Specification', width: '36%', align: 'left' },
            quantity: { show: true, label: 'Qty', width: '9%', align: 'center' },
            unit: { show: true, label: 'Unit', width: '8%', align: 'center' },
            unitPrice: { show: true, label: 'Rate (AFN)', width: '13%', align: 'right' },
            discount: { show: true, label: 'Discount', width: '8%', align: 'right' },
            tax: { show: true, label: 'Tax', width: '7%', align: 'right' },
            totalAmount: { show: true, label: 'Total (AFN)', width: '13%', align: 'right' },
          },
          headerBgColor: '#002B49',
          headerTextColor: '#FFFFFF',
          headerFontSize: 11,
          bodyFontSize: 10.5,
          rowHeight: 32,
        },
        // Payment & Totals
        totals: {
          ...DEFAULT_INVOICE_DESIGN.totals,
          show: true,
          showSubtotal: true,
          showDiscount: true,
          showTax: true,
          showGrandTotal: true,
          showTotalPaid: true,
          showRemaining: true,
          grandTotalBg: '#002B49',
          grandTotalColor: '#FFFFFF',
        },
        // Notes
        notes: {
          ...DEFAULT_INVOICE_DESIGN.notes,
          showInvoiceNote: true,
          invoiceNoteText: 'All payments must be remitted strictly in AFN currency.',
          invoiceNoteFontSize: 10,
          invoiceNoteColor: '#4A5568',
        },
        // Signatures
        signatures: {
          ...DEFAULT_INVOICE_DESIGN.signatures,
          show: true,
          showManagerSignature: true,
          managerSignatureLabel: 'Authorized Managing Director',
          showCustomerSignature: true,
          customerSignatureLabel: 'Client Acceptance & Seal',
          width: '220px',
        },
        // Footer
        footer: {
          ...DEFAULT_INVOICE_DESIGN.footer,
          show: true,
          showThankYou: true,
          showContacts: true,
          footerText: 'Thank you for partnering with Sarwan Technology Enterprise.',
          fontSize: 9.5,
          fontFamily: 'Inter',
        },
        // Spacing & Typography
        spacing: {
          ...DEFAULT_INVOICE_DESIGN.spacing,
          headerToMeta: 16,
          metaToCustomer: 14,
          customerToTable: 16,
          tableToPayment: 18,
          totalsToNotes: 14,
          notesToSignatures: 20,
          footerSpacing: 22,
        },
        typography: {
          fontFamily: 'Inter',
          headingFontFamily: 'Montserrat',
          baseFontSize: 11,
          headerFontSize: 14,
          titleFontSize: 24,
          tableFontSize: 10.5,
          tableHeaderFontSize: 11,
          footerFontSize: 9.5,
          lineHeight: 1.35,
        },
        colors: {
          primary: '#002B49',
          secondary: '#F58220',
          text: '#1A202C',
          background: '#FFFFFF',
          headerBackground: '#FFFFFF',
          tableHeaderBackground: '#002B49',
          tableHeaderText: '#FFFFFF',
          border: '#E2E8F0',
          footerBackground: '#002B49',
          grandTotalBackground: '#002B49',
          grandTotalText: '#FFFFFF',
        },
      },
    };

    const customizedInvoice: Invoice = {
      id: 'inv-custom-parity-1',
      billNumber: 'STE-2050',
      customerId: 'cust-parity-9',
      customerSnapshot: {
        id: 'cust-parity-9',
        name: 'Afghan Wireless Telecommunications Ltd.',
        phone: '+93 70 022 1100',
        address: 'Airport Road, Sector 8, Kabul',
        companyName: 'AWCC Corporate HQ',
      },
      date: '2026-10-04',
      totalAmount: 185000,
      totalPaid: 100000,
      remaining: 85000,
      status: 'Partially Paid',
      items: [
        { sNo: 1, description: 'Core Optical Switch 48-Port 10GbE SFP+', quantity: 2, unitPrice: 65000, totalAmount: 130000 },
        { sNo: 2, description: 'Cat6A Shielded Backbone Cabling (305m)', quantity: 4, unitPrice: 8500, totalAmount: 34000 },
        { sNo: 3, description: 'Precision Air Flow Rack Termination & Labelling', quantity: 1, unitPrice: 21000, totalAmount: 21000 },
      ],
      createdAt: '2026-10-04T10:00:00Z',
      updatedAt: '2026-10-04T10:00:00Z',
      companySnapshot: fullyCustomizedSettings,
      note: 'All equipment covers a 12-month manufacturer replacement warranty.',
    };

    // 1. Build document for Designer Preview
    const docDesignerPreview = buildCanonicalInvoiceDocument({
      invoice: customizedInvoice,
      settings: fullyCustomizedSettings,
    });

    // 2. Build document for Invoice Preview
    const docInvoicePreview = resolveCanonicalDocument({
      invoice: customizedInvoice,
      settings: fullyCustomizedSettings,
    });

    // 3. Build document for PDF Preview
    const docPdfPreview = buildCanonicalInvoiceDocument({
      invoice: customizedInvoice,
      settings: fullyCustomizedSettings,
    });

    // 4. Build document for Downloaded PDF
    const docDownloadedPdf = resolveCanonicalDocument(customizedInvoice, {
      settings: fullyCustomizedSettings,
    });

    // Verify 100% Geometry Parity across all 4 entry pipelines
    const docs = [docDesignerPreview, docInvoicePreview, docPdfPreview, docDownloadedPdf];
    for (const d of docs) {
      expect(d.paperConfig.widthMm === 210, 'Width must be exactly 210mm');
      expect(d.paperConfig.heightMm === 297, 'Height must be exactly 297mm');
      expect(d.paperConfig.paperSize === 'A4', 'Paper size must be A4');
      expect(d.paperConfig.marginTopMm === 14, 'Top margin must be 14mm');
      expect(d.paperConfig.marginRightMm === 14, 'Right margin must be 14mm');
      expect(d.paperConfig.marginBottomMm === 14, 'Bottom margin must be 14mm');
      expect(d.paperConfig.marginLeftMm === 14, 'Left margin must be 14mm');

      // Verify Table Columns and Widths
      expect(d.design.itemsTable.columnOrder.length === 8, '8 columns in items table');
      expect(d.design.itemsTable.columnOrder[0] === 'sNo', 'sNo is 1st column');
      expect(d.design.itemsTable.columnOrder[1] === 'description', 'description is 2nd column');
      expect(d.design.itemsTable.columnOrder[7] === 'totalAmount', 'totalAmount is last column');
      expect(d.design.itemsTable.columns.description.width === '36%', 'Description width is 36%');
      expect(d.design.itemsTable.columns.sNo.width === '6%', 'sNo width is 6%');

      // Verify Typography & Spacing
      expect(d.design.typography.headingFontFamily === 'Montserrat', 'Heading font is Montserrat');
      expect(d.design.typography.fontFamily === 'Inter', 'Body font is Inter');
      expect(d.design.spacing.headerToMeta === 16, 'Header to meta spacing is 16');
      expect(d.design.spacing.customerToTable === 16, 'Customer to table spacing is 16');

      // Verify Content Exactness
      expect(d.company.companyName === 'Sarwan Tech Enterprise Solutions', 'Company name matches');
      expect(d.customer.name === 'Afghan Wireless Telecommunications Ltd.', 'Customer name matches');
      expect(d.totalPrice === 185000, 'Total price matches');
      expect(d.totalPaid === 100000, 'Total paid matches');
      expect(d.remainingBalance === 85000, 'Remaining balance matches');
      expect(d.items.length === 3, 'Items count matches');
    }
  });

  const suites = Array.from(new Set(results.map((r) => r.suite)));
  console.log('===============================================================');
  console.log('            PDF & CANONICAL INVOICE TEST RESULTS               ');
  console.log('===============================================================');

  let totalPassed = 0;
  let totalFailed = 0;

  for (const s of suites) {
    const suiteResults = results.filter((r) => r.suite === s);
    const suitePassed = suiteResults.filter((r) => r.passed).length;
    const suiteTotal = suiteResults.length;
    const allPassed = suitePassed === suiteTotal;

    console.log(`[${allPassed ? '✓ PASS' : '✗ FAIL'}] ${s} (${suitePassed}/${suiteTotal} passed)`);
    for (const r of suiteResults) {
      if (r.passed) {
        console.log(`  ✓ ${r.name}`);
        totalPassed++;
      } else {
        console.log(`  ✗ ${r.name}: ${r.error}`);
        totalFailed++;
      }
    }
  }

  console.log('---------------------------------------------------------------');
  console.log(`TOTAL: ${totalPassed}/${results.length} Tests Passed`);
  console.log(`OVERALL STATUS: ${totalFailed === 0 ? 'ALL TESTS PASSED' : 'SOME TESTS FAILED'}`);
  console.log('===============================================================');

  return { total: results.length, passed: totalPassed, failed: totalFailed };
}

if (import.meta.url === `file://${process.argv[1]}`) {
  const summary = runPrintAndPdfTests();
  process.exit(summary.failed === 0 ? 0 : 1);
}
