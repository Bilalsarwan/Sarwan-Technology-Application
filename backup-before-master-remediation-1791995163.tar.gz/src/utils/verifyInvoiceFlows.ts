/**
 * verifyInvoiceFlows.ts
 * Rigorous end-to-end flow verification for:
 * 1. Existing Invoice A4 Preview & PDF Download parity
 * 2. Sequential Invoice Switching (Invoice 1 -> Invoice 2) to guarantee no stale data/caching leakage
 * 3. New/Draft Invoice Creation -> Preview -> Download flow parity
 */
import { Invoice, Payment, BusinessSettings, UserProfile } from '../types';
import { DEFAULT_INVOICE_DESIGN } from '../types/invoiceDesign';
import { buildCanonicalInvoiceDocument } from './canonicalInvoiceDocument';
import {
  generateInvoiceFilename,
  resolveCanonicalDocument,
  verifyCanonicalInvoiceDocumentStructure,
} from './print';

interface FlowTestResult {
  step: string;
  flow: string;
  passed: boolean;
  details: string;
}

const flowResults: FlowTestResult[] = [];

function assertStep(flow: string, step: string, condition: boolean, details: string) {
  if (!condition) {
    flowResults.push({ flow, step, passed: false, details: `FAILED: ${details}` });
    throw new Error(`[${flow}] Step "${step}" Failed: ${details}`);
  }
  flowResults.push({ flow, step, passed: true, details });
}

export async function runAllFlowVerifications() {
  console.log('===============================================================');
  console.log('        RUNNING INVOICE PREVIEW & PDF FLOW VERIFICATION        ');
  console.log('===============================================================\n');

  const settings: BusinessSettings = {
    companyName: 'Sarwan Technology',
    logo: '/sarwan-logo.png',
    logo2: '/dahua-logo.svg',
    phone: '0731339014',
    whatsapp: '0778771020',
    email: 'Sarwantechnology.af@gmail.com',
    address: 'Kabul, Afghanistan',
    currency: 'AFN',
    invoicePrefix: 'ST-',
    nextInvoiceNumber: 1060,
    invoiceNote: 'Thank you for choosing Sarwan Technology.',
    authorizedEmails: ['admin@sarwantechnology.com'],
    invoiceDesign: DEFAULT_INVOICE_DESIGN,
  };

  const userProfile: UserProfile = {
    id: 'user-admin',
    name: 'Admin User',
    username: 'admin',
    email: 'admin@sarwantechnology.com',
    role: 'super_admin',
    status: 'active',
    createdAt: '2026-09-01T00:00:00Z',
  };

  // -------------------------------------------------------------
  // FLOW 1: Existing Invoice -> A4 Preview -> PDF Download Parity
  // -------------------------------------------------------------
  console.log('--> Executing Flow 1: Existing Invoice -> A4 Preview -> PDF Download...');
  const invoice1: Invoice = {
    id: 'inv-flow-1',
    billNumber: 'ST-1060',
    customerId: 'cust-1',
    customerSnapshot: {
      id: 'cust-1',
      name: 'Kabul Tech Trading Co.',
      phone: '0788112233',
      address: 'Karte 4, Kabul',
      companyName: 'Kabul Tech Ltd.',
    },
    date: '2026-09-28',
    totalAmount: 45000,
    totalPaid: 25000,
    remaining: 20000,
    status: 'Partially Paid',
    note: '',
    items: [
      { sNo: 1, description: '4K CCTV IP Camera', quantity: 4, unitPrice: 5000, totalAmount: 20000 },
      { sNo: 2, description: '8-Port PoE Gigabit Switch', quantity: 2, unitPrice: 7500, totalAmount: 15000 },
      { sNo: 3, description: 'Installation & Network Termination', quantity: 1, unitPrice: 10000, totalAmount: 10000 },
    ],
    createdAt: '2026-09-28T08:00:00Z',
    updatedAt: '2026-09-28T08:00:00Z',
    companySnapshot: settings,
  };

  const payments1: Payment[] = [
    {
      id: 'pay-flow-1',
      invoiceId: 'inv-flow-1',
      billNumber: 'ST-1060',
      customerId: 'cust-1',
      customerName: 'Kabul Tech Trading Co.',
      amount: 25000,
      date: '2026-09-28',
      time: '10:00:00',
      method: 'CASH',
      note: 'Payment received',
      recordedBy: 'user-admin',
      recordedByName: 'Admin User',
      createdAt: '2026-09-28T10:00:00Z',
    },
  ];

  // 1. Simulate opening InvoiceDetailModal and mounting canonical preview
  const previewDoc1 = buildCanonicalInvoiceDocument({
    invoice: invoice1,
    payments: payments1,
    settings,
    userProfile,
    totalPaidOverride: 25000,
  });

  // Verify unique DOM ID target contract
  const previewDomId1 = 'invoice-detail-preview-document';
  assertStep('Flow 1', 'Preview DOM ID', previewDomId1 === 'invoice-detail-preview-document', 'Preview uses unique DOM ID invoice-detail-preview-document');
  assertStep('Flow 1', 'Preview Bill Number', previewDoc1.billNumber === 'ST-1060', 'Preview displays ST-1060');
  assertStep('Flow 1', 'Preview Customer', previewDoc1.customer.name === 'Kabul Tech Trading Co.', 'Preview customer is Kabul Tech Trading Co.');
  assertStep('Flow 1', 'Preview Total', previewDoc1.totalPrice === 45000, 'Preview total is 45,000 AFN');
  assertStep('Flow 1', 'Preview Remaining', previewDoc1.remainingBalance === 20000, 'Preview remaining is 20,000 AFN');
  assertStep('Flow 1', 'Preview Items Count', previewDoc1.items.length === 3, 'Preview includes all 3 items');

  // 2. Simulate clicking Download PDF in InvoiceDetailModal (opens InvoicePdfDownloadModal)
  const downloadModalDoc1 = buildCanonicalInvoiceDocument({
    invoice: invoice1,
    payments: payments1,
    settings,
    userProfile,
    totalPaidOverride: 25000,
  });
  const downloadDomId1 = 'invoice-pdf-download-document';
  assertStep('Flow 1', 'Download Modal DOM ID', downloadDomId1 === 'invoice-pdf-download-document', 'Download modal uses unique DOM ID invoice-pdf-download-document');

  // 3. Simulate downloadInvoicePdf invocation targeting invoice-pdf-download-document
  const resolvedPdfDoc1 = resolveCanonicalDocument(downloadModalDoc1);
  const pdfFilename1 = generateInvoiceFilename(resolvedPdfDoc1);

  assertStep('Flow 1', 'PDF Filename', pdfFilename1 === 'Sarwan-Technology-Invoice-ST-1060.pdf', 'PDF filename matches clean format: Sarwan-Technology-Invoice-ST-1060.pdf');
  assertStep('Flow 1', 'Preview & PDF Parity - Bill No', previewDoc1.billNumber === resolvedPdfDoc1.billNumber, 'Bill numbers strictly identical');
  assertStep('Flow 1', 'Preview & PDF Parity - Customer', previewDoc1.customer.name === resolvedPdfDoc1.customer.name, 'Customer names strictly identical');
  assertStep('Flow 1', 'Preview & PDF Parity - Total', previewDoc1.totalPrice === resolvedPdfDoc1.totalPrice, 'Totals strictly identical (45,000 AFN)');
  assertStep('Flow 1', 'Preview & PDF Parity - Paid', previewDoc1.totalPaid === resolvedPdfDoc1.totalPaid, 'Total paid strictly identical (25,000 AFN)');
  assertStep('Flow 1', 'Preview & PDF Parity - Remaining', previewDoc1.remainingBalance === resolvedPdfDoc1.remainingBalance, 'Remaining balance strictly identical (20,000 AFN)');
  assertStep('Flow 1', 'Preview & PDF Parity - Items', JSON.stringify(previewDoc1.items) === JSON.stringify(resolvedPdfDoc1.items), 'Items array strictly identical');

  console.log('✓ Flow 1 Passed: Existing Invoice Preview and PDF Download verified with 100% parity.\n');

  // -------------------------------------------------------------
  // FLOW 2: Open Invoice A -> Download -> Open Invoice B -> Download
  // -------------------------------------------------------------
  console.log('--> Executing Flow 2: Sequential Invoice Switching (Invoice A -> Invoice B)...');
  const invoice2: Invoice = {
    id: 'inv-flow-2',
    billNumber: 'ST-1061',
    customerId: 'cust-2',
    customerSnapshot: {
      id: 'cust-2',
      name: 'Herat Fiber Optics Network',
      phone: '0700554433',
      address: 'Jad-e-Welayat, Herat',
      companyName: 'Herat Fiber LLC',
    },
    date: '2026-09-29',
    totalAmount: 85000,
    totalPaid: 85000,
    remaining: 0,
    status: 'Paid',
    note: '',
    items: [
      { sNo: 1, description: 'Core Fiber Optical Splicer', quantity: 1, unitPrice: 65000, totalAmount: 65000 },
      { sNo: 2, description: 'Optical Time Domain Reflectometer (OTDR)', quantity: 1, unitPrice: 20000, totalAmount: 20000 },
    ],
    createdAt: '2026-09-29T11:00:00Z',
    updatedAt: '2026-09-29T11:00:00Z',
    companySnapshot: settings,
  };

  const payments2: Payment[] = [
    {
      id: 'pay-flow-2',
      invoiceId: 'inv-flow-2',
      billNumber: 'ST-1061',
      customerId: 'cust-2',
      customerName: 'Herat Fiber Optics Network',
      amount: 85000,
      date: '2026-09-29',
      time: '11:30:00',
      method: 'CASH',
      note: 'Full payment received',
      recordedBy: 'user-admin',
      recordedByName: 'Admin User',
      createdAt: '2026-09-29T11:30:00Z',
    },
  ];

  // 1. Open Invoice B in InvoiceDetailModal & Preview it
  const previewDoc2 = buildCanonicalInvoiceDocument({
    invoice: invoice2,
    payments: payments2,
    settings,
    userProfile,
    totalPaidOverride: 85000,
  });

  assertStep('Flow 2', 'Invoice B Preview Bill No', previewDoc2.billNumber === 'ST-1061', 'Invoice B preview is ST-1061');
  assertStep('Flow 2', 'Invoice B Customer', previewDoc2.customer.name === 'Herat Fiber Optics Network', 'Invoice B customer is Herat Fiber Optics Network');
  assertStep('Flow 2', 'Invoice B Total', previewDoc2.totalPrice === 85000, 'Invoice B total is 85,000 AFN');
  assertStep('Flow 2', 'Invoice B Paid Status', previewDoc2.status === 'Paid', 'Invoice B status is Paid');
  assertStep('Flow 2', 'No Data Leakage from Invoice A to Preview B', previewDoc2.billNumber !== previewDoc1.billNumber && previewDoc2.customer.name !== previewDoc1.customer.name, 'No Invoice A data leaked into Invoice B preview');

  // 2. Download Invoice B PDF
  const downloadModalDoc2 = buildCanonicalInvoiceDocument({
    invoice: invoice2,
    payments: payments2,
    settings,
    userProfile,
    totalPaidOverride: 85000,
  });
  const resolvedPdfDoc2 = resolveCanonicalDocument(downloadModalDoc2);
  const pdfFilename2 = generateInvoiceFilename(resolvedPdfDoc2);

  assertStep('Flow 2', 'Invoice B PDF Filename', pdfFilename2 === 'Sarwan-Technology-Invoice-ST-1061.pdf', 'Invoice B PDF filename is Sarwan-Technology-Invoice-ST-1061.pdf');
  assertStep('Flow 2', 'Invoice B PDF Bill No', resolvedPdfDoc2.billNumber === 'ST-1061', 'Invoice B PDF contains ST-1061');
  assertStep('Flow 2', 'Invoice B PDF Customer', resolvedPdfDoc2.customer.name === 'Herat Fiber Optics Network', 'Invoice B PDF contains Herat Fiber Optics Network');
  assertStep('Flow 2', 'Invoice B PDF Total', resolvedPdfDoc2.totalPrice === 85000, 'Invoice B PDF total is 85,000 AFN');
  assertStep('Flow 2', 'No Invoice A Leakage in PDF B', !pdfFilename2.includes('1060') && resolvedPdfDoc2.billNumber !== 'ST-1060' && resolvedPdfDoc2.customer.name !== 'Kabul Tech Trading Co.', 'Confirmed: PDF B contains strictly Invoice B, zero elements of Invoice A');

  console.log('✓ Flow 2 Passed: Open Invoice A -> Download -> Open Invoice B -> Download verified with strict data isolation.\n');

  // -------------------------------------------------------------
  // FLOW 3: New / Draft Invoice -> Add Customer/Items -> Preview -> Download PDF
  // -------------------------------------------------------------
  console.log('--> Executing Flow 3: New/Draft Invoice Creation -> Preview -> Download PDF...');

  const draftProjectedBillNo = 'ST-1062';
  const draftCustomerName = 'Balkh Solar Energy Systems';
  const draftCustomerPhone = '0799887766';
  const draftCustomerAddress = 'Mazar-i-Sharif, Balkh';
  const draftCustomerCompany = 'Balkh Solar Ltd.';
  const draftItems = [
    { sNo: 1, description: 'Tier-1 Mono Solar Panel 550W', quantity: 10, unitPrice: 12000, totalAmount: 120000 },
    { sNo: 2, description: 'Hybrid Solar Inverter 5kW', quantity: 2, unitPrice: 25000, totalAmount: 50000 },
  ];
  const draftTotal = 170000;
  const draftPaidCash = 70000;

  // 1. Build draft preview canonical document (matches InvoiceModal.tsx previewCanonicalDoc)
  const draftPreviewDoc = buildCanonicalInvoiceDocument({
    invoice: {
      id: 'draft-preview',
      billNumber: draftProjectedBillNo,
      date: '2026-09-30',
      items: draftItems,
      totalAmount: draftTotal,
      customerSnapshot: {
        id: 'new-cust',
        name: draftCustomerName,
        phone: draftCustomerPhone,
        address: draftCustomerAddress,
        companyName: draftCustomerCompany,
      },
      companySnapshot: settings,
      note: 'Advance payment received on solar equipment delivery',
      status: 'Partially Paid',
      isVoid: false,
      isLocked: false,
    },
    totalPaidOverride: draftPaidCash,
    settings,
    userProfile,
  });

  const draftDomId = 'invoice-draft-preview-document';
  assertStep('Flow 3', 'Draft Preview DOM ID', draftDomId === 'invoice-draft-preview-document', 'Draft preview uses unique DOM ID invoice-draft-preview-document');
  assertStep('Flow 3', 'Draft Bill Number', draftPreviewDoc.billNumber === 'ST-1062', 'Draft bill number is ST-1062');
  assertStep('Flow 3', 'Draft Customer Name', draftPreviewDoc.customer.name === 'Balkh Solar Energy Systems', 'Draft customer name matches input');
  assertStep('Flow 3', 'Draft Customer Phone', draftPreviewDoc.customer.phone === '0799887766', 'Draft phone matches input');
  assertStep('Flow 3', 'Draft Items Count', draftPreviewDoc.items.length === 2, 'Draft items count is 2');
  assertStep('Flow 3', 'Draft Total', draftPreviewDoc.totalPrice === 170000, 'Draft total is 170,000 AFN');
  assertStep('Flow 3', 'Draft Paid', draftPreviewDoc.totalPaid === 70000, 'Draft paid is 70,000 AFN');
  assertStep('Flow 3', 'Draft Remaining', draftPreviewDoc.remainingBalance === 100000, 'Draft remaining is 100,000 AFN');

  // 2. Simulate downloading PDF from draft preview (opens InvoicePdfDownloadModal with previewInvoice)
  const draftInvoiceObject: Invoice = {
    id: 'draft-preview',
    billNumber: draftProjectedBillNo,
    customerId: 'new-cust',
    date: '2026-09-30',
    items: draftItems,
    totalAmount: draftTotal,
    totalPaid: draftPaidCash,
    remaining: 100000,
    status: 'Partially Paid',
    customerSnapshot: {
      id: 'new-cust',
      name: draftCustomerName,
      phone: draftCustomerPhone,
      address: draftCustomerAddress,
      companyName: draftCustomerCompany,
    },
    companySnapshot: settings,
    note: 'Advance payment received on solar equipment delivery',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  };

  const draftDownloadModalDoc = buildCanonicalInvoiceDocument({
    invoice: draftInvoiceObject,
    payments: [],
    settings,
    userProfile,
    totalPaidOverride: draftPaidCash,
  });

  const resolvedDraftPdfDoc = resolveCanonicalDocument(draftDownloadModalDoc);
  const draftPdfFilename = generateInvoiceFilename(resolvedDraftPdfDoc);

  assertStep('Flow 3', 'Draft PDF Filename', draftPdfFilename === 'Sarwan-Technology-Invoice-ST-1062.pdf', 'Draft PDF filename matches: Sarwan-Technology-Invoice-ST-1062.pdf');
  assertStep('Flow 3', 'Draft Preview & PDF Parity - Bill No', draftPreviewDoc.billNumber === resolvedDraftPdfDoc.billNumber, 'Draft bill numbers match');
  assertStep('Flow 3', 'Draft Preview & PDF Parity - Customer', draftPreviewDoc.customer.name === resolvedDraftPdfDoc.customer.name, 'Draft customer matches');
  assertStep('Flow 3', 'Draft Preview & PDF Parity - Total', draftPreviewDoc.totalPrice === resolvedDraftPdfDoc.totalPrice, 'Draft totals match (170,000 AFN)');
  assertStep('Flow 3', 'Draft Preview & PDF Parity - Paid', draftPreviewDoc.totalPaid === resolvedDraftPdfDoc.totalPaid, 'Draft paid amounts match (70,000 AFN)');
  assertStep('Flow 3', 'Draft Preview & PDF Parity - Remaining', draftPreviewDoc.remainingBalance === resolvedDraftPdfDoc.remainingBalance, 'Draft remaining balances match (100,000 AFN)');
  assertStep('Flow 3', 'Draft Preview & PDF Parity - Items', JSON.stringify(draftPreviewDoc.items) === JSON.stringify(resolvedDraftPdfDoc.items), 'Draft items arrays match exactly');

  console.log('✓ Flow 3 Passed: New/Draft Invoice Creation -> Preview -> Download PDF verified with 100% parity.\n');

  // -------------------------------------------------------------
  // Verification Summary
  // -------------------------------------------------------------
  console.log('===============================================================');
  console.log('                 FLOW VERIFICATION SUMMARY                     ');
  console.log('===============================================================');
  const total = flowResults.length;
  const passed = flowResults.filter((r) => r.passed).length;
  console.log(`TOTAL STEPS VERIFIED: ${passed}/${total}`);
  for (const r of flowResults) {
    console.log(`  [✓] [${r.flow}] ${r.step}: ${r.details}`);
  }
  console.log('---------------------------------------------------------------');
  console.log('STATUS: ALL 3 USER FLOWS VERIFIED SUCCESSFULLY');
  console.log('===============================================================\n');

  return { total, passed, failed: total - passed };
}

// Execute if run directly via tsx
if (import.meta.url === `file://${process.argv[1]}`) {
  runAllFlowVerifications().catch((err) => {
    console.error('Fatal Flow Verification Error:', err);
    process.exit(1);
  });
}
