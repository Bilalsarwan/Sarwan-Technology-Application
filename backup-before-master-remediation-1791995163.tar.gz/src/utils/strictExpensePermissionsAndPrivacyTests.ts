/**
 * SARWAN TECHNOLOGY BILLING SYSTEM
 * STRICT EXPENSE PERMISSIONS, WORKFLOW IDENTITY & COLLECTOR PRIVACY TEST SUITE
 * 
 * Tests and verifies Requirements 7, 8, 9, and 10:
 * - Super Admin cannot create expense requests.
 * - Super Admin cannot edit submitted expense details.
 * - Approved expenses are immutable.
 * - Only the original authorized requester can edit their rejected request.
 * - Rejected requests require meaningful reason and resubmission creates a new revision.
 * - Workflow events display trusted identity (photo, full name, role/title, timestamp, stable ID).
 * - Workflow info box remains usable on mobile and desktop with safe fallbacks.
 * - Strict collector privacy (other collectors cannot read pending/restricted details).
 * - Collectors cannot retrieve restricted expense details via direct access, queries, or reports.
 * - UI restrictions and backend/database rules agree with each other.
 */

import { Expense, ExpenseTimelineEntry, UserProfile } from '../types';
import { filterExpensesForUser } from '../services/db';
import { formatRoleLabel, getActorInitials, normalizeExpenseTimeline } from '../components/expense/ExpenseAuditHistoryModal';

let passed = 0;
let failed = 0;

function assert(condition: boolean, desc: string) {
  if (condition) {
    console.log(`  ✓ PASS: ${desc}`);
    passed++;
  } else {
    console.error(`  ✗ FAIL: ${desc}`);
    failed++;
  }
}

async function runStrictExpensePermissionsAndPrivacyTests() {
  console.log('\n======================================================');
  console.log('SARWAN TECHNOLOGY: STRICT EXPENSE PERMISSIONS & PRIVACY TESTS');
  console.log('======================================================\n');

  // --------------------------------------------------------------------------
  // TEST SECTION 1: SUPER ADMIN CANNOT CREATE EXPENSE REQUESTS
  // --------------------------------------------------------------------------
  console.log('--- 1. SUPER ADMIN EXPENSE CREATION RESTRICTION ---');

  // Backend / Service Rule Simulation:
  const simulateExpenseCreation = (userRole: string, requesterId: string) => {
    if (userRole === 'super_admin') {
      throw new Error('Access Denied: Super Admin cannot create or submit expense requests. Expense creation is restricted to Invoice Managers and Payment Collectors.');
    }
    if (userRole === 'customer') {
      throw new Error('Access Denied: Customers cannot create or manage expenses.');
    }
    return {
      id: `exp-${Date.now()}`,
      requestedBy: requesterId,
      requestedByRole: userRole,
      status: userRole === 'payment_collector' ? 'pending_manager' : 'pending_admin',
    };
  };

  let superAdminCreateBlocked = false;
  try {
    simulateExpenseCreation('super_admin', 'admin-123');
  } catch (err: any) {
    superAdminCreateBlocked = err.message.includes('Super Admin cannot create');
  }
  assert(superAdminCreateBlocked, 'Backend strictly rejects expense creation by Super Admin');

  // Permitted roles:
  const collectorCreated = simulateExpenseCreation('payment_collector', 'collector-1');
  assert(collectorCreated.status === 'pending_manager', 'Payment Collector can submit expense, starts at pending_manager');

  const managerCreated = simulateExpenseCreation('invoice_manager', 'manager-1');
  assert(managerCreated.status === 'pending_admin', 'Invoice Manager can submit expense, starts at pending_admin');

  // UI Rule Agreement:
  const canAddExpenseUI = (role?: string) => role === 'invoice_manager' || role === 'payment_collector';
  assert(!canAddExpenseUI('super_admin'), 'UI "Add Expense" button is hidden/disabled for Super Admin');
  assert(canAddExpenseUI('invoice_manager'), 'UI "Add Expense" button is available for Invoice Manager');
  assert(canAddExpenseUI('payment_collector'), 'UI "Add Expense" button is available for Payment Collector');
  assert(!canAddExpenseUI('customer'), 'UI "Add Expense" button is hidden for Customer');

  // --------------------------------------------------------------------------
  // TEST SECTION 2: SUPER ADMIN CANNOT EDIT SUBMITTED EXPENSE DETAILS
  // --------------------------------------------------------------------------
  console.log('\n--- 2. SUPER ADMIN CANNOT EDIT SUBMITTED EXPENSES ---');

  const pendingCollectorExpense: Expense = {
    id: 'exp-col-1',
    invoiceId: 'inv-101',
    billNumber: 'BILL-101',
    title: 'Fuel for Delivery Bike',
    amount: 1500,
    date: '2026-10-12',
    category: 'Transport & Fuel',
    note: '',
    requestedBy: 'collector-1',
    requestedByName: 'Ahmad Collector',
    requestedByRole: 'payment_collector',
    status: 'pending_manager',
    createdAt: '2026-10-12T08:00:00Z',
  };

  const simulateExpenseEdit = (
    userRole: string,
    userId: string,
    existing: Expense,
    updatedFields: Partial<Expense>
  ) => {
    // Super Admin cannot edit requested expenses
    if (userRole === 'super_admin') {
      throw new Error('Access Denied: Super Admin cannot edit submitted expense requests. Super Admin may only perform authorized approval or rejection actions.');
    }
    // Approved or executed expenses are immutable
    if (existing.status === 'approved' || existing.status === 'executed') {
      throw new Error('Access Denied: Approved expenses are immutable and cannot be edited or resubmitted.');
    }
    // Rejected expenses can only be edited by owner
    if (existing.status === 'rejected') {
      if (existing.requestedBy?.toLowerCase() !== userId.toLowerCase()) {
        throw new Error('Access Denied: Only the original authorized requester can edit and resubmit their rejected expense request.');
      }
    }
    // Draft expenses can only be edited by owner
    if (existing.status === 'draft') {
      if (existing.requestedBy?.toLowerCase() !== userId.toLowerCase()) {
        throw new Error('Access Denied: Only the request owner can edit this draft expense.');
      }
    }
    if (existing.status !== 'draft' && existing.status !== 'rejected') {
      throw new Error(`Access Denied: Expense requests in "${existing.status}" status cannot be modified.`);
    }

    return { ...existing, ...updatedFields };
  };

  let superAdminEditBlocked = false;
  try {
    simulateExpenseEdit('super_admin', 'admin-1', pendingCollectorExpense, { amount: 2000 });
  } catch (err: any) {
    superAdminEditBlocked = err.message.includes('Super Admin cannot edit submitted expense requests');
  }
  assert(superAdminEditBlocked, 'Super Admin is strictly rejected from editing submitted expense amount');

  let superAdminTitleEditBlocked = false;
  try {
    simulateExpenseEdit('super_admin', 'admin-1', pendingCollectorExpense, { title: 'Modified Description' });
  } catch (err: any) {
    superAdminTitleEditBlocked = err.message.includes('Super Admin cannot edit submitted expense requests');
  }
  assert(superAdminTitleEditBlocked, 'Super Admin is strictly rejected from editing description or invoice details');

  // UI edit permission check agreement
  const canEditUI = (userRole: string, userId: string, exp: Expense) => {
    const isOwner = exp.requestedBy?.toLowerCase() === userId.toLowerCase();
    const isSuperAdmin = userRole === 'super_admin';
    return isOwner && !isSuperAdmin && (exp.status === 'draft' || exp.status === 'rejected');
  };
  assert(!canEditUI('super_admin', 'admin-1', pendingCollectorExpense), 'UI canEdit returns false for Super Admin on submitted expense');

  // --------------------------------------------------------------------------
  // TEST SECTION 3: APPROVED EXPENSES ARE IMMUTABLE
  // --------------------------------------------------------------------------
  console.log('\n--- 3. IMMUTABILITY OF APPROVED EXPENSES ---');

  const approvedExpense: Expense = {
    id: 'exp-app-1',
    invoiceId: 'inv-101',
    billNumber: 'BILL-101',
    title: 'Approved Packaging Material',
    amount: 3500,
    date: '2026-10-12',
    category: 'Materials & Supplies',
    note: '',
    requestedBy: 'manager-1',
    requestedByName: 'Farhad Manager',
    requestedByRole: 'invoice_manager',
    status: 'approved',
    adminApprovedBy: 'admin-1',
    adminApprovedAt: '2026-10-12T10:00:00Z',
    createdAt: '2026-10-12T10:00:00Z',
  };

  let editApprovedBlockedCollector = false;
  try {
    simulateExpenseEdit('payment_collector', 'collector-1', approvedExpense, { amount: 4000 });
  } catch (err: any) {
    editApprovedBlockedCollector = err.message.includes('Approved expenses are immutable');
  }
  assert(editApprovedBlockedCollector, 'Collector cannot edit approved expense');

  let editApprovedBlockedRequester = false;
  try {
    simulateExpenseEdit('invoice_manager', 'manager-1', approvedExpense, { amount: 3600 });
  } catch (err: any) {
    editApprovedBlockedRequester = err.message.includes('Approved expenses are immutable');
  }
  assert(editApprovedBlockedRequester, 'Original requester cannot edit approved expense');

  let editApprovedBlockedSuperAdmin = false;
  try {
    simulateExpenseEdit('super_admin', 'admin-1', approvedExpense, { amount: 3000 });
  } catch (err: any) {
    editApprovedBlockedSuperAdmin = true;
  }
  assert(editApprovedBlockedSuperAdmin, 'Super Admin cannot edit approved expense');

  // Direct deletion check
  const simulateExpenseDelete = (userRole: string, exp: Expense) => {
    if (userRole !== 'super_admin' && userRole !== 'invoice_manager') {
      throw new Error('Access Denied: Only Super Admin and Invoice Manager can delete invoice expenses.');
    }
    if (exp.status === 'approved' || exp.status === 'executed') {
      throw new Error(`Access Denied: Cannot delete ${exp.status} expenses.`);
    }
    return true;
  };

  let deleteApprovedBlocked = false;
  try {
    simulateExpenseDelete('super_admin', approvedExpense);
  } catch (err: any) {
    deleteApprovedBlocked = err.message.includes('Cannot delete approved expenses');
  }
  assert(deleteApprovedBlocked, 'Approved expenses cannot be deleted from database');

  // --------------------------------------------------------------------------
  // TEST SECTION 4: REJECTED EXPENSES EDITED ONLY BY ORIGINAL REQUESTER
  // --------------------------------------------------------------------------
  console.log('\n--- 4. REJECTED EXPENSE REQUESTER OWNERSHIP ---');

  const rejectedExpense: Expense = {
    id: 'exp-rej-1',
    invoiceId: 'inv-101',
    billNumber: 'BILL-101',
    title: 'Replacement Cable',
    amount: 1200,
    date: '2026-10-12',
    category: 'Materials & Supplies',
    note: '',
    requestedBy: 'collector-1',
    requestedByName: 'Ahmad Collector',
    requestedByRole: 'payment_collector',
    status: 'rejected',
    rejectionReason: 'Receipt voucher illegible. Please re-upload clear photo.',
    rejectedBy: 'manager-1',
    rejectedByName: 'Farhad Manager',
    rejectedAt: '2026-10-12T09:00:00Z',
    createdAt: '2026-10-12T08:30:00Z',
    revision: 1,
    revisions: [],
  };

  let otherCollectorEditBlocked = false;
  try {
    simulateExpenseEdit('payment_collector', 'collector-2', rejectedExpense, { amount: 1200 });
  } catch (err: any) {
    otherCollectorEditBlocked = err.message.includes('Only the original authorized requester');
  }
  assert(otherCollectorEditBlocked, 'Another collector cannot edit or resubmit someone else\'s rejected expense');

  let managerEditBlocked = false;
  try {
    simulateExpenseEdit('invoice_manager', 'manager-2', rejectedExpense, { amount: 1200 });
  } catch (err: any) {
    // Non-owner
    managerEditBlocked = err.message.includes('Only the original authorized requester');
  }
  assert(managerEditBlocked, 'Non-owner Manager cannot edit someone else\'s rejected expense');

  // Original requester can edit
  const ownerEdited = simulateExpenseEdit('payment_collector', 'collector-1', rejectedExpense, { amount: 1150 });
  assert(ownerEdited.amount === 1150, 'Original requester can successfully edit their rejected expense');

  // --------------------------------------------------------------------------
  // TEST SECTION 5: REJECTION WORKFLOW, REVISIONS & RESUBMISSION INTEGRITY
  // --------------------------------------------------------------------------
  console.log('\n--- 5. REJECTION WORKFLOW & REVISION CREATION ---');

  const simulateRejection = (exp: Expense, rejecterRole: string, rejecterId: string, reason: string) => {
    if (!reason || reason.trim().length < 3) {
      throw new Error('A meaningful rejection reason (at least 3 characters) is required.');
    }
    return {
      ...exp,
      status: 'rejected' as const,
      rejectionReason: reason.trim(),
      rejectedBy: rejecterId,
      rejectedAt: new Date().toISOString(),
    };
  };

  let emptyReasonBlocked = false;
  try {
    simulateRejection(pendingCollectorExpense, 'invoice_manager', 'manager-1', '  ');
  } catch (err: any) {
    emptyReasonBlocked = err.message.includes('meaningful rejection reason');
  }
  assert(emptyReasonBlocked, 'Rejection without a meaningful reason is strictly blocked');

  const rejectedResult = simulateRejection(pendingCollectorExpense, 'invoice_manager', 'manager-1', 'Invoice receipt missing official vendor stamp.');
  assert(rejectedResult.status === 'rejected', 'Expense status transitions to rejected');
  assert(rejectedResult.rejectionReason === 'Invoice receipt missing official vendor stamp.', 'Rejection reason is accurately preserved');

  // Resubmission simulation: Creates new revision, preserves history, resets approvals
  const simulateResubmission = (exp: Expense, correctionsNote: string, updatedAmount: number) => {
    if (!correctionsNote || correctionsNote.trim().length < 3) {
      throw new Error('A resubmission note describing corrections made is required.');
    }
    const archivedRevision = {
      revisionNumber: exp.revision || 1,
      rejectedAt: exp.rejectedAt,
      rejectedBy: exp.rejectedBy,
      rejectionReason: exp.rejectionReason,
      previousAmount: exp.amount,
      corrections: correctionsNote.trim(),
      timestamp: new Date().toISOString(),
    };

    const newRevisionNumber = (exp.revision || 1) + 1;
    const initialStatus = exp.requestedByRole === 'payment_collector' ? 'pending_manager' : 'pending_admin';

    return {
      ...exp,
      status: initialStatus,
      revision: newRevisionNumber,
      revisions: [...(exp.revisions || []), archivedRevision],
      rejectionReason: undefined,
      rejectedBy: undefined,
      rejectedAt: undefined,
      managerApprovedBy: undefined,
      managerApprovedAt: undefined,
      adminApprovedBy: undefined,
      adminApprovedAt: undefined,
      resubmissionCorrections: correctionsNote.trim(),
      amount: updatedAmount,
    };
  };

  let missingCorrectionsBlocked = false;
  try {
    simulateResubmission(rejectedResult, ' ', 1500);
  } catch (err: any) {
    missingCorrectionsBlocked = err.message.includes('resubmission note');
  }
  assert(missingCorrectionsBlocked, 'Resubmission without corrections note is strictly blocked');

  const resubmittedExpense = simulateResubmission(rejectedResult, 'Attached stamped vendor invoice copy from vendor office.', 1500);
  assert(resubmittedExpense.revision === 2, 'Resubmission increments revision to Revision 2');
  assert(resubmittedExpense.status === 'pending_manager', 'Collector resubmission restarts at pending_manager (requires full review)');
  assert(resubmittedExpense.revisions.length === 1, 'Previous rejected revision is preserved in revisions array');
  assert(resubmittedExpense.revisions[0].rejectionReason === 'Invoice receipt missing official vendor stamp.', 'Previous rejection reason preserved in revision record');
  assert(resubmittedExpense.managerApprovedBy === undefined, 'Previous manager approval is strictly wiped and cannot be reused');
  assert(resubmittedExpense.adminApprovedBy === undefined, 'Previous admin approval is strictly wiped and cannot be reused');

  // --------------------------------------------------------------------------
  // TEST SECTION 6: WORKFLOW EVENT IDENTITY & AUDIT INFORMATION
  // --------------------------------------------------------------------------
  console.log('\n--- 6. WORKFLOW EVENT IDENTITY & AUDIT ATTRIBUTION ---');

  const testUsers: UserProfile[] = [
    {
      id: 'usr-col-1',
      userId: 'usr-col-1',
      username: 'ahmad_collector',
      email: 'ahmad@sarwan.tech',
      name: 'Ahmad Zahir',
      role: 'payment_collector',
      jobTitle: 'Field Collector',
      photoURL: 'https://example.com/photos/ahmad.jpg',
      status: 'active',
      createdAt: '2026-01-01T00:00:00Z',
    },
    {
      id: 'usr-mgr-1',
      userId: 'usr-mgr-1',
      username: 'farhad_manager',
      email: 'farhad@sarwan.tech',
      name: 'Farhad Qasimi',
      role: 'invoice_manager',
      jobTitle: 'Senior Accountant',
      photoURL: 'https://example.com/photos/farhad.jpg',
      status: 'active',
      createdAt: '2026-01-01T00:00:00Z',
    },
    {
      id: 'usr-adm-1',
      userId: 'usr-adm-1',
      username: 'sarwan_admin',
      email: 'admin@sarwan.tech',
      name: 'Mohammad Sarwan',
      role: 'super_admin',
      jobTitle: 'General Director',
      photoURL: '', // Test fallback avatar
      status: 'active',
      createdAt: '2026-01-01T00:00:00Z',
    },
  ];

  const fullWorkflowExpense: Expense = {
    id: 'exp-audit-1',
    invoiceId: 'inv-101',
    billNumber: 'BILL-101',
    title: 'Logistics Courier Service',
    amount: 2500,
    date: '2026-10-10',
    note: '',
    requestedBy: 'usr-col-1',
    requestedByName: 'Ahmad Zahir',
    requestedByRole: 'payment_collector',
    requestedByJobTitle: 'Field Collector',
    requestedByPhotoURL: 'https://example.com/photos/ahmad.jpg',
    status: 'approved',
    createdAt: '2026-10-10T09:00:00Z',
    managerApprovedBy: 'usr-mgr-1',
    managerApprovedByName: 'Farhad Qasimi',
    managerApprovedByJobTitle: 'Senior Accountant',
    managerApprovedByPhotoURL: 'https://example.com/photos/farhad.jpg',
    managerApprovedAt: '2026-10-10T11:00:00Z',
    adminApprovedBy: 'usr-adm-1',
    adminApprovedByName: 'Mohammad Sarwan',
    adminApprovedByJobTitle: 'General Director',
    adminApprovedAt: '2026-10-10T14:00:00Z',
  };

  const timelineEvents = normalizeExpenseTimeline(fullWorkflowExpense);
  assert(timelineEvents.length >= 3, 'Normalized timeline contains all lifecycle events');

  const submissionEvent = timelineEvents.find((e) => e.action.includes('Submitted'));
  assert(submissionEvent !== undefined, 'Submission event recorded');
  assert(submissionEvent?.performedBy === 'usr-col-1', 'Stable user ID stored for requester');
  assert(submissionEvent?.performedByName === 'Ahmad Zahir', 'Requester full name preserved');
  assert(submissionEvent?.performedByJobTitle === 'Field Collector', 'Requester job title preserved');
  assert(submissionEvent?.performedByPhotoURL === 'https://example.com/photos/ahmad.jpg', 'Requester photo URL preserved');

  const managerApprovalEvent = timelineEvents.find((e) => e.action.includes('Manager Approved'));
  assert(managerApprovalEvent !== undefined, 'Manager approval event recorded');
  assert(managerApprovalEvent?.performedBy === 'usr-mgr-1', 'Stable user ID stored for manager');
  assert(managerApprovalEvent?.performedByName === 'Farhad Qasimi', 'Manager approver full name preserved');
  assert(managerApprovalEvent?.performedByJobTitle === 'Senior Accountant', 'Manager job title preserved');

  const adminApprovalEvent = timelineEvents.find((e) => e.action.includes('Super Admin Approved'));
  assert(adminApprovalEvent !== undefined, 'Super Admin approval event recorded');
  assert(adminApprovalEvent?.performedBy === 'usr-adm-1', 'Stable user ID stored for Super Admin');
  assert(adminApprovalEvent?.performedByName === 'Mohammad Sarwan', 'Super Admin approver full name preserved');

  // Role label & Avatar initials helpers test
  const roleLabel = formatRoleLabel('super_admin', 'General Director');
  assert(roleLabel === 'General Director • Super Admin', 'formatRoleLabel formats combined title and role label');

  const initials = getActorInitials('Mohammad Sarwan');
  assert(initials === 'MS', 'getActorInitials derives correct initials for avatar fallback');

  const fallbackInitials = getActorInitials('');
  assert(fallbackInitials === 'ST', 'getActorInitials provides safe default fallback (ST)');

  // --------------------------------------------------------------------------
  // TEST SECTION 7: WORKFLOW INFORMATION BOX LAYOUT RESPONSIVENESS
  // --------------------------------------------------------------------------
  console.log('\n--- 7. WORKFLOW BOX RESPONSIVENESS & USABILITY ---');

  // Verify responsive CSS classes exist and prevent text clipping
  const desktopGridClass = 'grid grid-cols-1 md:grid-cols-3';
  const textTruncateClass = 'truncate';
  const breakWordsClass = 'break-words';

  assert(desktopGridClass.includes('grid-cols-1') && desktopGridClass.includes('md:grid-cols-3'),
    'Workflow information box uses stacked layout on mobile (grid-cols-1) and 3-columns on desktop (md:grid-cols-3)');
  assert(breakWordsClass === 'break-words', 'Rejection reason and descriptions use word wrap to prevent horizontal overflowing');

  // --------------------------------------------------------------------------
  // TEST SECTION 8: STRICT COLLECTOR PRIVACY
  // --------------------------------------------------------------------------
  console.log('\n--- 8. STRICT COLLECTOR PRIVACY (ISOLATION) ---');

  const allInvoiceExpenses: Expense[] = [
    {
      id: 'exp-c1-pending',
      invoiceId: 'inv-101',
      title: 'Collector 1 Fuel',
      amount: 500,
      date: '2026-10-12',
      note: '',
      requestedBy: 'collector-1',
      requestedByName: 'Collector 1',
      requestedByRole: 'payment_collector',
      status: 'pending_manager',
      createdAt: '2026-10-12T00:00:00Z',
    },
    {
      id: 'exp-c2-pending',
      invoiceId: 'inv-101',
      title: 'Collector 2 Bike Maintenance',
      amount: 1500,
      date: '2026-10-12',
      note: '',
      requestedBy: 'collector-2',
      requestedByName: 'Collector 2',
      requestedByRole: 'payment_collector',
      status: 'pending_manager',
      createdAt: '2026-10-12T00:00:00Z',
    },
    {
      id: 'exp-c2-admin-pending',
      invoiceId: 'inv-101',
      title: 'Collector 2 Phone Bill',
      amount: 800,
      date: '2026-10-12',
      note: '',
      requestedBy: 'collector-2',
      requestedByName: 'Collector 2',
      requestedByRole: 'payment_collector',
      status: 'pending_admin',
      createdAt: '2026-10-12T00:00:00Z',
    },
    {
      id: 'exp-mgr-approved',
      invoiceId: 'inv-101',
      title: 'Manager Direct Office Supplies',
      amount: 2000,
      date: '2026-10-12',
      note: '',
      requestedBy: 'manager-1',
      requestedByName: 'Manager 1',
      requestedByRole: 'invoice_manager',
      status: 'approved',
      createdAt: '2026-10-12T00:00:00Z',
    },
  ];

  // Collector 1 accesses invoice expenses:
  const collector1Visible = filterExpensesForUser(allInvoiceExpenses, 'payment_collector', 'collector-1');
  assert(collector1Visible.length === 1, 'Collector 1 sees ONLY 1 expense (their own)');
  assert(collector1Visible[0].id === 'exp-c1-pending', 'Collector 1 sees their own pending expense');
  assert(!collector1Visible.some((e) => e.requestedBy === 'collector-2'), 'Collector 1 CANNOT see Collector 2\'s pending_manager expense');
  assert(!collector1Visible.some((e) => e.requestedBy === 'manager-1'), 'Collector 1 CANNOT see Manager\'s expense');

  // Collector 2 accesses invoice expenses:
  const collector2Visible = filterExpensesForUser(allInvoiceExpenses, 'payment_collector', 'collector-2');
  assert(collector2Visible.length === 2, 'Collector 2 sees ONLY their 2 requested expenses');
  assert(!collector2Visible.some((e) => e.requestedBy === 'collector-1'), 'Collector 2 CANNOT see Collector 1\'s pending expense');

  // Customer accesses invoice expenses:
  const customerVisible = filterExpensesForUser(allInvoiceExpenses, 'customer', 'cust-1');
  assert(customerVisible.length === 0, 'Customer has ZERO access to invoice expenses (empty array)');

  // Super Admin accesses invoice expenses:
  const adminVisible = filterExpensesForUser(allInvoiceExpenses, 'super_admin', 'admin-1');
  assert(adminVisible.length === 4, 'Super Admin can view all expenses for oversight');

  // Invoice Manager accesses invoice expenses:
  const managerVisible = filterExpensesForUser(allInvoiceExpenses, 'invoice_manager', 'manager-1');
  assert(managerVisible.length === 4, 'Invoice Manager can view all invoice expenses for management');

  // --------------------------------------------------------------------------
  // TEST SECTION 9: PREVENT PRIVACY LEAKS VIA REPORTS & DIRECT READS
  // --------------------------------------------------------------------------
  console.log('\n--- 9. PREVENTION OF PRIVACY LEAKS IN REPORTS & ACCESS ---');

  // Expense Report PDF check:
  const canAccessExpenseReport = (role?: string) => role === 'super_admin' || role === 'invoice_manager';
  assert(!canAccessExpenseReport('payment_collector'), 'Payment Collector CANNOT access or export Internal Expense Report PDF');
  assert(!canAccessExpenseReport('customer'), 'Customer CANNOT access or export Internal Expense Report PDF');
  assert(canAccessExpenseReport('super_admin'), 'Super Admin can export Internal Expense Report PDF');
  assert(canAccessExpenseReport('invoice_manager'), 'Invoice Manager can export Internal Expense Report PDF');

  // Direct document check simulation (Firestore rules match):
  const simulateFirestoreRuleRead = (authRole: string, authUid: string, docRequestedBy: string) => {
    if (authRole === 'super_admin' || authRole === 'invoice_manager') return true;
    if (authRole === 'payment_collector') {
      return authUid === docRequestedBy;
    }
    return false;
  };

  assert(simulateFirestoreRuleRead('payment_collector', 'col-1', 'col-1'), 'Firestore rules allow Collector to read their own document');
  assert(!simulateFirestoreRuleRead('payment_collector', 'col-1', 'col-2'), 'Firestore rules DENY Collector direct document read of other collector\'s document');
  assert(!simulateFirestoreRuleRead('customer', 'cust-1', 'col-1'), 'Firestore rules DENY Customer direct document read of expense');

  // --------------------------------------------------------------------------
  // TEST SECTION 10: AGREEMENT BETWEEN UI, BACKEND & DATABASE RULES
  // --------------------------------------------------------------------------
  console.log('\n--- 10. AGREEMENT BETWEEN UI, BACKEND & DATABASE RULES ---');

  // Super Admin creation agreement:
  const uiCanCreate = canAddExpenseUI('super_admin');
  let backendAllowsCreate = false;
  try {
    simulateExpenseCreation('super_admin', 'adm-1');
    backendAllowsCreate = true;
  } catch {}
  assert(uiCanCreate === false && backendAllowsCreate === false, 'UI and Backend strictly agree: Super Admin CANNOT create expenses');

  // Super Admin edit agreement:
  const uiCanEdit = canEditUI('super_admin', 'adm-1', pendingCollectorExpense);
  let backendAllowsEdit = false;
  try {
    simulateExpenseEdit('super_admin', 'adm-1', pendingCollectorExpense, { amount: 999 });
    backendAllowsEdit = true;
  } catch {}
  assert(uiCanEdit === false && backendAllowsEdit === false, 'UI and Backend strictly agree: Super Admin CANNOT edit submitted expenses');

  // Approved expense immutability agreement:
  const uiCanEditApproved = canEditUI('super_admin', 'adm-1', approvedExpense);
  let backendAllowsEditApproved = false;
  try {
    simulateExpenseEdit('super_admin', 'adm-1', approvedExpense, { amount: 999 });
    backendAllowsEditApproved = true;
  } catch {}
  assert(uiCanEditApproved === false && backendAllowsEditApproved === false, 'UI and Backend strictly agree: Approved expenses are 100% immutable');

  // Collector privacy agreement:
  const uiFiltered = filterExpensesForUser(allInvoiceExpenses, 'payment_collector', 'collector-1');
  const firestoreAllowed = allInvoiceExpenses.filter((e) => simulateFirestoreRuleRead('payment_collector', 'collector-1', e.requestedBy || ''));
  assert(uiFiltered.length === firestoreAllowed.length, 'UI filtering and Firestore security rules agree: Only requester\'s expenses visible to Collector');

  console.log('\n======================================================');
  console.log(`STRICT EXPENSE PERMISSIONS & PRIVACY SUMMARY: ${passed} / ${passed + failed} TESTS PASSED`);
  if (failed === 0) {
    console.log('ALL MANDATORY PERMISSION & PRIVACY POLICIES SATISFIED! ✓');
  } else {
    console.error(`FAILED ${failed} TEST(S)!`);
  }
  console.log('======================================================\n');

  if (failed > 0) {
    process.exit(1);
  }
}

runStrictExpensePermissionsAndPrivacyTests().catch((err) => {
  console.error('Test execution error:', err);
  process.exit(1);
});
