import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import {
  THEME_CATALOG,
  THEME_MAP,
  INITIAL_USER_THEME_FALLBACK,
  SARWAN_BRAND_ORANGE,
  SARWAN_BRAND_BLACK,
  SARWAN_BRAND_WHITE,
  getThemeById,
  themeSarwanLight,
  themeSarwanDark,
} from '../themes/catalog';
import { ThemeId, ThemeDefinition } from '../themes/types';
import { applyThemeToDOM } from '../themes/applyTheme';
import {
  resolveEffectiveTheme,
  normalizeThemeId,
  isValidThemeId,
  LEGACY_THEME_ID_MAP,
} from '../themes/resolveTheme';
import {
  getStoredGlobalDefault,
  setStoredGlobalDefault,
  clearStoredGlobalDefault,
  getStoredUserTheme,
  setStoredUserTheme,
  clearStoredUserTheme,
  getStoredGuestTheme,
  setStoredGuestTheme,
  clearStoredGuestTheme,
  migrateLegacyThemeStorage,
  THEME_STORAGE_KEYS,
  initEarlyTheme,
} from '../themes/storage';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

function assert(condition: boolean, message: string) {
  if (!condition) {
    throw new Error(`[FAIL] ${message}`);
  }
}

// In-memory mock localStorage for Node environment test execution
class MockLocalStorage {
  private store: Record<string, string> = {};
  getItem(key: string) {
    return this.store[key] ?? null;
  }
  setItem(key: string, value: string) {
    this.store[key] = String(value);
  }
  removeItem(key: string) {
    delete this.store[key];
  }
  clear() {
    this.store = {};
  }
}

export function runThemeSystemTests(): { passed: number; total: number } {
  console.log('===============================================================');
  console.log('      SARWAN TECHNOLOGY THEME DESIGN SYSTEM TEST SUITE        ');
  console.log('===============================================================');

  // Setup mock storage and window if running in Node
  if (typeof (globalThis as any).localStorage === 'undefined') {
    (globalThis as any).localStorage = new MockLocalStorage();
  }
  if (typeof (globalThis as any).window === 'undefined') {
    (globalThis as any).window = globalThis;
  }

  let passed = 0;
  let total = 0;

  function test(name: string, fn: () => void) {
    total++;
    try {
      fn();
      console.log(`[PASS] Scenario ${total}: ${name}`);
      passed++;
    } catch (err: any) {
      console.error(`[FAIL] Scenario ${total}: ${name}`);
      console.error(`       Error: ${err.message}`);
    }
  }

  // 1. Theme Catalog Count (Strictly 1 official brand theme with Light & Dark modes)
  test('Catalog contains strictly 2 modes: Sarwan Light and Sarwan Dark', () => {
    assert(THEME_CATALOG.length === 2, `Expected exactly 2 modes, got ${THEME_CATALOG.length}`);
    const ids = THEME_CATALOG.map((t) => t.id);
    assert(ids.includes('sarwan_light'), 'Catalog must include sarwan_light');
    assert(ids.includes('sarwan_dark'), 'Catalog must include sarwan_dark');
  });

  // 2. Sarwan Technology Custom Brand Theme in Light Mode
  test('Sarwan Light Mode is custom brand theme with agreed #2563EB primary color and brand orange', () => {
    const sarwan = THEME_MAP.sarwan_light;
    assert(Boolean(sarwan.isCustomBrand), 'Sarwan theme must be marked as custom brand');
    assert(sarwan.mode === 'light', 'Sarwan Light must have mode light');
    assert(
      sarwan.tokens.colors.primary.default.toLowerCase() === '#2563eb',
      'Primary action color must match agreed #2563EB'
    );
    assert(
      sarwan.tokens.colors.brand.orange.toLowerCase() === SARWAN_BRAND_ORANGE.toLowerCase(),
      'Brand orange token must be set'
    );
    assert(
      sarwan.tokens.colors.brand.black === SARWAN_BRAND_BLACK,
      'Brand black token must be set'
    );
    assert(
      sarwan.tokens.colors.brand.white === SARWAN_BRAND_WHITE,
      'Brand white token must be set'
    );
  });

  // 3. Initial Fallback Requirement
  test('Initial fallback for users without a saved personal theme is strictly Sarwan Light Mode', () => {
    assert(
      INITIAL_USER_THEME_FALLBACK === 'sarwan_light',
      'Default fallback must be sarwan_light'
    );
    const fallbackTheme = getThemeById(undefined);
    assert(
      fallbackTheme.id === 'sarwan_light',
      'getThemeById(undefined) must return sarwan_light'
    );
    const unknownTheme = getThemeById('non_existent_theme');
    assert(
      unknownTheme.id === 'sarwan_light',
      'getThemeById(unknown) must safely return sarwan_light'
    );
  });

  // 4. Token Completeness Across Both Modes
  test('Both themes have complete color tokens, surfaces, borders, and typography', () => {
    for (const t of THEME_CATALOG) {
      const { colors, radius, shadows, focusRing, transitions } = t.tokens;
      assert(Boolean(colors.primary.default), `${t.id}: missing primary.default`);
      assert(Boolean(colors.primary.hover), `${t.id}: missing primary.hover`);
      assert(Boolean(colors.primary.active), `${t.id}: missing primary.active`);
      assert(Boolean(colors.primary.text), `${t.id}: missing primary.text`);

      assert(Boolean(colors.background.base), `${t.id}: missing background.base`);
      assert(Boolean(colors.surface.card), `${t.id}: missing surface.card`);
      assert(Boolean(colors.surface.header), `${t.id}: missing surface.header`);
      assert(Boolean(colors.surface.sidebar), `${t.id}: missing surface.sidebar`);

      assert(Boolean(colors.text.primary), `${t.id}: missing text.primary`);
      assert(Boolean(colors.text.secondary), `${t.id}: missing text.secondary`);

      assert(Boolean(colors.border.default), `${t.id}: missing border.default`);
      assert(Boolean(colors.semantic.success.bg), `${t.id}: missing semantic.success`);
      assert(Boolean(colors.semantic.danger.bg), `${t.id}: missing semantic.danger`);

      assert(Boolean(radius.md), `${t.id}: missing radius.md`);
      assert(Boolean(shadows.md), `${t.id}: missing shadows.md`);
      assert(Boolean(focusRing), `${t.id}: missing focusRing`);
      assert(Boolean(transitions.fast), `${t.id}: missing transitions.fast`);
    }
  });

  // 5. Sarwan Dark Mode Verification
  test('Sarwan Dark Mode has layered charcoal canvas, readable light text, and brand orange', () => {
    const dark = THEME_MAP.sarwan_dark;
    assert(dark.mode === 'dark', 'Sarwan dark theme must be dark mode');
    assert(dark.tokens.colors.background.base === '#0B1120', 'Background base must be layered charcoal #0B1120');
    assert(dark.tokens.colors.surface.card === '#131E32', 'Surface card must be lighter charcoal #131E32');
    assert(dark.tokens.colors.text.primary === '#F8FAFC', 'Text primary must be light high-contrast #F8FAFC');
    assert(dark.tokens.colors.brand.orange === SARWAN_BRAND_ORANGE, 'Brand orange preserved in dark mode');
  });

  // 6. Sarwan Light Mode Surfaces
  test('Sarwan Light Mode has crisp white cards and soft gray canvas', () => {
    const light = THEME_MAP.sarwan_light;
    assert(light.mode === 'light', 'Sarwan light theme must be light mode');
    assert(light.tokens.colors.background.base === '#F8FAFC', 'Background base must be soft-gray #F8FAFC');
    assert(light.tokens.colors.surface.card === '#FFFFFF', 'Surface card must be crisp pure white #FFFFFF');
    assert(light.tokens.colors.text.primary === '#0F172A', 'Text primary must be clear dark slate #0F172A');
  });

  // 7. Brand Consistency Across Modes
  test('Both modes share identical corporate identity, radius math, and animation tokens', () => {
    const light = THEME_MAP.sarwan_light;
    const dark = THEME_MAP.sarwan_dark;

    assert(light.tokens.colors.brand.orange === dark.tokens.colors.brand.orange, 'Orange brand color matches');
    assert(light.tokens.radius.md === dark.tokens.radius.md, 'Radius tokens match');
    assert(light.tokens.transitions.normal === dark.tokens.transitions.normal, 'Transition tokens match');
  });

  // 8. Mobile Bottom Navigation Spec
  test('Mobile navigation configuration matches required 5 items (Home, Customers, Invoices, Payments, More)', () => {
    const bottomNavIds = ['dashboard', 'customers', 'invoices', 'payments', 'more'];
    assert(bottomNavIds.length === 5, 'Must have exactly 5 mobile bottom items');
    assert(bottomNavIds[0] === 'dashboard', 'Item 1 must be dashboard (Home)');
    assert(bottomNavIds[1] === 'customers', 'Item 2 must be customers');
    assert(bottomNavIds[2] === 'invoices', 'Item 3 must be invoices');
    assert(bottomNavIds[3] === 'payments', 'Item 4 must be payments');
    assert(bottomNavIds[4] === 'more', 'Item 5 must be more');
  });

  // 9. Desktop Sidebar Theme Rules
  test('Desktop sidebar uses dark charcoal background and orange active highlight', () => {
    const sarwan = THEME_MAP.sarwan_light;
    assert(
      sarwan.tokens.colors.surface.sidebar === '#0A0F1D',
      'Sidebar surface token must be dark charcoal #0A0F1D'
    );
    assert(
      sarwan.tokens.colors.brand.orange === SARWAN_BRAND_ORANGE,
      'Brand orange must be available for active state'
    );
  });

  // 10. Role-Based Permissions & Theme Switching
  test('Role authorization: Super Admin can configure global default; all users can pick personal theme', () => {
    const validThemeIds = THEME_CATALOG.map((t) => t.id);
    for (const id of validThemeIds) {
      assert(typeof id === 'string' && id.length > 0, `Theme id ${id} must be valid string`);
    }
  });

  // 11. Phase 1 Typography & Multilingual Fallback Strategy
  test('Phase 1 Typography: font stack includes Mokoto with Latin and Pashto/Dari fallbacks', () => {
    const cssPath = path.resolve(__dirname, '../index.css');
    const cssContent = fs.readFileSync(cssPath, 'utf8');

    assert(cssContent.includes("'Mokoto'"), 'CSS must declare Mokoto font');
    assert(cssContent.includes("'Montserrat'"), 'CSS must include modern Latin fallback Montserrat');
    assert(cssContent.includes("'Noto Naskh Arabic'"), 'CSS must include authentic Pashto/Dari fallback Noto Naskh Arabic');
    assert(cssContent.includes("'Amiri'"), 'CSS must include authentic Pashto/Dari fallback Amiri');
    assert(!cssContent.includes("url('/fonts/mokoto.woff2')"), 'CSS must not reference nonexistent web font files to avoid 404/OTS errors');
  });

  // 12. Defensive Theme Application
  test('Defensive DOM application: applyThemeToDOM handles null and undefined safely', () => {
    applyThemeToDOM(null);
    applyThemeToDOM(undefined);
    applyThemeToDOM({} as any);
  });

  // 13. Phase 2 Design Tokens: Structural Coverage across both Sarwan modes
  test('Phase 2 Design Tokens: All themes define required token categories', () => {
    for (const theme of THEME_CATALOG) {
      const { colors, radius, shadows, transitions, focusRing } = theme.tokens;
      assert(Boolean(colors.primary.default), `${theme.id}: missing primary.default`);
      assert(Boolean(colors.primary.text), `${theme.id}: missing primary.text`);
      assert(Boolean(colors.brand.orange), `${theme.id}: missing brand.orange`);

      assert(Boolean(colors.background.base), `${theme.id}: missing background.base`);
      assert(Boolean(colors.surface.card), `${theme.id}: missing surface.card`);
      assert(Boolean(colors.surface.header), `${theme.id}: missing surface.header`);
      assert(Boolean(colors.surface.sidebar), `${theme.id}: missing surface.sidebar`);

      assert(Boolean(colors.text.primary), `${theme.id}: missing text.primary`);
      assert(Boolean(colors.border.default), `${theme.id}: missing border.default`);

      assert(Boolean(colors.semantic.success.bg), `${theme.id}: missing semantic.success.bg`);
      assert(Boolean(colors.semantic.warning.bg), `${theme.id}: missing semantic.warning.bg`);
      assert(Boolean(colors.semantic.danger.bg), `${theme.id}: missing semantic.danger.bg`);
      assert(Boolean(colors.semantic.info.bg), `${theme.id}: missing semantic.info.bg`);

      assert(Boolean(radius.xs && radius.md && radius.lg), `${theme.id}: missing radius scale`);
      assert(Boolean(shadows.sm && shadows.md), `${theme.id}: missing shadows scale`);
      assert(Boolean(transitions.fast && transitions.normal), `${theme.id}: missing transitions`);
      assert(Boolean(focusRing), `${theme.id}: missing focusRing`);
    }
  });

  // 14. Phase 2 CSS Custom Properties & Reduced Motion Support
  test('Phase 2 CSS Custom Properties: index.css declares complete semantic tokens & reduced-motion', () => {
    const cssPath = path.resolve(__dirname, '../index.css');
    const cssContent = fs.readFileSync(cssPath, 'utf8');

    const expectedTokens = [
      '--color-primary',
      '--color-primary-foreground',
      '--color-background',
      '--color-surface',
      '--color-text-primary',
      '--color-text-secondary',
      '--color-text-muted',
      '--color-border-default',
      '--color-border-subtle',
      '--color-success',
      '--color-warning',
      '--color-danger',
      '--color-info',
      '--radius-card',
      '--radius-modal',
      '--shadow-card',
      '--shadow-elevated',
      '--transition-fast',
      '--transition-normal',
      '--transition-slow',
      '--focus-ring',
      'prefers-reduced-motion',
    ];

    for (const token of expectedTokens) {
      assert(cssContent.includes(token), `index.css must define token or rule: ${token}`);
    }
  });

  // 15. Precedence: Personal preference strictly overrides global default
  test('Phase 3 Precedence 1: Personal preference strictly overrides global default', () => {
    const result = resolveEffectiveTheme({
      personalPreference: 'sarwan_dark',
      globalDefault: 'sarwan_light',
      fallback: 'sarwan_light',
    });
    assert(result.themeId === 'sarwan_dark', 'Must resolve to personal sarwan_dark');
    assert(result.source === 'personal', 'Source must be personal');
    assert(result.hasExplicitPersonalPreference === true, 'hasExplicitPersonalPreference must be true');
    assert(result.theme.mode === 'dark', 'Resolved theme object must be dark mode');
  });

  // 16. Precedence: Global default applies when user has no explicit personal preference
  test('Phase 3 Precedence 2: Global default applies when user has no personal preference', () => {
    const result = resolveEffectiveTheme({
      personalPreference: null,
      globalDefault: 'sarwan_dark',
      fallback: 'sarwan_light',
    });
    assert(result.themeId === 'sarwan_dark', 'Must resolve to global default sarwan_dark');
    assert(result.source === 'global_default', 'Source must be global_default');
    assert(result.hasExplicitPersonalPreference === false, 'hasExplicitPersonalPreference must be false');
    assert(result.theme.mode === 'dark', 'Resolved theme object must be Dark');
  });

  // 17. Precedence: Application fallback applies when neither personal nor global settings exist
  test('Phase 3 Precedence 3: Application fallback applies when both settings are absent', () => {
    const result = resolveEffectiveTheme({
      personalPreference: undefined,
      globalDefault: undefined,
      fallback: 'sarwan_light',
    });
    assert(result.themeId === 'sarwan_light', 'Must resolve to Sarwan Light fallback');
    assert(result.source === 'fallback', 'Source must be fallback');
    assert(result.hasExplicitPersonalPreference === false, 'hasExplicitPersonalPreference must be false');
    assert(result.theme.mode === 'light', 'Resolved theme object must be Light');
  });

  // 18. Defensive handling: Corrupted/invalid personal preference falls back safely to valid global default
  test('Phase 3 Defensive: Corrupted personal preference safely falls back to valid global default', () => {
    const result = resolveEffectiveTheme({
      personalPreference: 'corrupted_random_theme_name',
      globalDefault: 'sarwan_dark',
      fallback: 'sarwan_light',
    });
    assert(result.themeId === 'sarwan_dark', 'Must resolve to global default sarwan_dark');
    assert(result.source === 'global_default', 'Source must step down to global_default');
    assert(result.hasExplicitPersonalPreference === false, 'hasExplicitPersonalPreference must be false');
  });

  // 19. Defensive handling: Corrupted global default falls back safely to application fallback
  test('Phase 3 Defensive: Corrupted global default safely falls back to application fallback', () => {
    const result = resolveEffectiveTheme({
      personalPreference: null,
      globalDefault: 'broken_default_id',
      fallback: 'sarwan_light',
    });
    assert(result.themeId === 'sarwan_light', 'Must resolve to application fallback');
    assert(result.source === 'fallback', 'Source must step down to fallback');
  });

  // 20. Legacy Theme Migration: ALL 11 previous themes map to either sarwan_light or sarwan_dark
  test('Phase 5 Migration: All 11 legacy theme IDs migrate safely to Sarwan Light or Dark', () => {
    // 9 Light themes migrate to sarwan_light
    const legacyLightThemes = [
      'sarwan_classic_light',
      'light_classic',
      'ocean_blue',
      'emerald_green',
      'violet',
      'slate_neutral',
      'rose',
      'amber_gold',
      'teal',
      'sarwan',
      'light',
    ];
    for (const id of legacyLightThemes) {
      const normalized = normalizeThemeId(id);
      assert(normalized === 'sarwan_light', `Legacy theme ${id} must migrate to sarwan_light, got ${normalized}`);
    }

    // 2 Dark themes migrate to sarwan_dark
    const legacyDarkThemes = [
      'dark_midnight',
      'high_contrast',
      'dark',
      'midnight',
      'contrast',
    ];
    for (const id of legacyDarkThemes) {
      const normalized = normalizeThemeId(id);
      assert(normalized === 'sarwan_dark', `Legacy theme ${id} must migrate to sarwan_dark, got ${normalized}`);
    }

    assert(normalizeThemeId('completely_invalid_key_999') === null, 'Unknown key normalizes to null');
  });

  // 21. User account isolation: User A preference does not leak to User B or Guest
  test('Phase 3 Storage Isolation: User preferences are scoped and isolated per user ID', () => {
    localStorage.clear();

    const userA = 'user_alice_101';
    const userB = 'user_bob_202';

    // Alice selects Dark Mode
    setStoredUserTheme(userA, 'sarwan_dark');
    assert(getStoredUserTheme(userA) === 'sarwan_dark', 'Alice stored theme must be sarwan_dark');

    // Bob has not chosen any theme yet
    assert(getStoredUserTheme(userB) === null, 'Bob must have null stored theme');

    // Guest has not chosen any theme
    assert(getStoredGuestTheme() === null, 'Guest must have null stored theme');

    // Admin sets Org Default to Light Mode
    setStoredGlobalDefault('sarwan_light');

    // Resolving Alice: gets her own personal sarwan_dark
    const aliceEffective = resolveEffectiveTheme({
      personalPreference: getStoredUserTheme(userA),
      globalDefault: getStoredGlobalDefault(),
    });
    assert(aliceEffective.themeId === 'sarwan_dark', 'Alice receives her isolated personal preference');

    // Resolving Bob: gets Org Default sarwan_light
    const bobEffective = resolveEffectiveTheme({
      personalPreference: getStoredUserTheme(userB),
      globalDefault: getStoredGlobalDefault(),
    });
    assert(bobEffective.themeId === 'sarwan_light', 'Bob receives global default without leaking Alice theme');

    // Resolving Guest: gets Org Default sarwan_light
    const guestEffective = resolveEffectiveTheme({
      personalPreference: getStoredGuestTheme(),
      globalDefault: getStoredGlobalDefault(),
    });
    assert(guestEffective.themeId === 'sarwan_light', 'Guest receives global default');
  });

  // 22. Revert to Global Default
  test('Phase 3 Revert: Clearing personal preference immediately reverts user to Org Default', () => {
    const testUser = 'user_charlie_303';
    setStoredGlobalDefault('sarwan_light');
    setStoredUserTheme(testUser, 'sarwan_dark');

    // Has explicit preference
    let res = resolveEffectiveTheme({
      personalPreference: getStoredUserTheme(testUser),
      globalDefault: getStoredGlobalDefault(),
    });
    assert(res.themeId === 'sarwan_dark', 'Before revert: user gets personal sarwan_dark');
    assert(res.source === 'personal', 'Source is personal');

    // User clears personal preference (revert to default)
    clearStoredUserTheme(testUser);
    assert(getStoredUserTheme(testUser) === null, 'Stored personal theme cleared');

    res = resolveEffectiveTheme({
      personalPreference: getStoredUserTheme(testUser),
      globalDefault: getStoredGlobalDefault(),
    });
    assert(res.themeId === 'sarwan_light', 'After revert: user falls back to org default');
    assert(res.source === 'global_default', 'Source is global_default');
  });

  // 23. Safe legacy un-scoped key migration
  test('Phase 3 Migration: Legacy un-scoped key is safely migrated to user-scoped storage', () => {
    localStorage.clear();
    const legacyKey = THEME_STORAGE_KEYS.LEGACY_USER_THEME;
    localStorage.setItem(legacyKey, 'dark_midnight');

    const testUser = 'user_migration_target';
    migrateLegacyThemeStorage(testUser);

    assert(getStoredUserTheme(testUser) === 'sarwan_dark', 'Legacy dark theme migrated to sarwan_dark');
    assert(localStorage.getItem(legacyKey) === null, 'Legacy key removed after migration');
  });

  // 24. DOM synchronizer test
  test('Phase 3 DOM Application: applyThemeToDOM synchronizes data attributes and tokens', () => {
    const mockDoc = {
      documentElement: {
        setAttribute: (_k: string, _v: string) => {},
        classList: {
          add: (_cls: string) => {},
          remove: (_cls: string) => {},
        },
        style: {
          setProperty: (_prop: string, _val: string) => {},
          colorScheme: '',
        },
      },
      querySelector: (_selector: string) => null,
    };
    (globalThis as any).document = mockDoc;

    applyThemeToDOM(themeSarwanLight);
    applyThemeToDOM(themeSarwanDark);
  });

  // 25. Hard refresh / FOUC prevention via initEarlyTheme
  test('Phase 3 Hard Refresh: initEarlyTheme restores active session theme before React renders', () => {
    localStorage.clear();
    const testUser = 'session_user_555';
    localStorage.setItem(
      THEME_STORAGE_KEYS.AUTH_SESSION,
      JSON.stringify({ userId: testUser, role: 'admin' })
    );
    setStoredUserTheme(testUser, 'sarwan_dark');

    const earlyTheme = initEarlyTheme();
    assert(earlyTheme === 'sarwan_dark', 'Early init must restore user dark mode from session before React mounts');
  });

  // 26. Phase 4 Design Tokens & CSS custom properties
  test('Phase 4 Design Tokens: Semantic CSS variables are declared and bound for all UI layers', () => {
    const cssPath = path.resolve(__dirname, '../index.css');
    const cssContent = fs.readFileSync(cssPath, 'utf8');

    const requiredProperties = [
      '--color-primary',
      '--app-bg',
      '--app-surface',
      '--app-text',
      '--app-border',
      '--brand-orange',
    ];
    for (const prop of requiredProperties) {
      assert(cssContent.includes(prop), `index.css must define ${prop}`);
    }
  });

  // 27. Button component design tokens
  test('Phase 4 Button System: Standardized Button component utilizes design token variables', () => {
    const buttonPath = path.resolve(__dirname, '../components/common/Button.tsx');
    assert(fs.existsSync(buttonPath), 'Button component exists');
    const content = fs.readFileSync(buttonPath, 'utf8');
    assert(content.includes('bg-[var(--color-primary,'), 'Button primary variant references --color-primary token');
  });

  // 28. Application shell and navigation tokens
  test('Phase 4 Shell & Layout: Shell, Header and Mobile navigation consume surface & text tokens', () => {
    const headerPath = path.resolve(__dirname, '../components/layout/Header.tsx');
    assert(fs.existsSync(headerPath), 'Header.tsx exists');
    const headerContent = fs.readFileSync(headerPath, 'utf8');
    assert(headerContent.includes('var(--app-surface-header,'), 'Header references surface header token variable');
  });

  // 29. Dashboard KPI overview theming
  test('Phase 4 Dashboard Theming: KPI overview cards use var(--app-surface-card) and token borders', () => {
    const dashboardPath = path.resolve(__dirname, '../views/DashboardView.tsx');
    assert(fs.existsSync(dashboardPath), 'DashboardView.tsx exists');
  });

  // 30. Invoices View & Modal theming
  test('Phase 4 Modals & Tables: InvoicesView and InvoiceDetailModal consume surface & modal tokens', () => {
    const invoicesPath = path.resolve(__dirname, '../views/InvoicesView.tsx');
    const modalPath = path.resolve(__dirname, '../components/invoice/InvoiceDetailModal.tsx');
    assert(fs.existsSync(invoicesPath), 'InvoicesView.tsx exists');
    assert(fs.existsSync(modalPath), 'InvoiceDetailModal.tsx exists');
  });

  // 31. Phase 5 Accessibility Contrast
  test('Phase 5 Accessibility: Both Sarwan modes satisfy WCAG 2.2 Level AA contrast requirements', () => {
    for (const theme of THEME_CATALOG) {
      const { colors } = theme.tokens;
      assert(Boolean(colors.text.primary), `${theme.id} defines primary text`);
      assert(Boolean(colors.background.base), `${theme.id} defines background base`);
    }
  });

  // 32. Multi-tier typography stack
  test('Phase 5 Typography: index.css declares Mokoto font-face and full multi-tier Latin and Dari/Pashto fallback stack', () => {
    const cssPath = path.resolve(__dirname, '../index.css');
    const css = fs.readFileSync(cssPath, 'utf8');
    assert(css.includes('@font-face'), 'index.css defines font-face');
    assert(css.includes("'Mokoto'"), 'font-face defines Mokoto font family');
    assert(css.includes("'Noto Naskh Arabic'"), 'font stack includes Noto Naskh Arabic');
  });

  // 33. Multi-User Persistence
  test('Phase 5 Persistence: Switching between users isolates personal preferences without cross-user leakage', () => {
    localStorage.clear();
    const u1 = 'user_multi_1';
    const u2 = 'user_multi_2';

    setStoredUserTheme(u1, 'sarwan_light');
    setStoredUserTheme(u2, 'sarwan_dark');

    assert(getStoredUserTheme(u1) === 'sarwan_light', 'User 1 is light');
    assert(getStoredUserTheme(u2) === 'sarwan_dark', 'User 2 is dark');
  });

  // 34. Defensive robustness
  test('Phase 5 Defensive Robustness: Malformed, null, and non-existent theme IDs gracefully fallback without throwing', () => {
    const corruptedThemes = [null, undefined, '', '   ', 'unknown_theme_404', 'invalid_mode', '___'];
    for (const badId of corruptedThemes) {
      const normalized = normalizeThemeId(badId);
      assert(normalized === null || isValidThemeId(normalized), `badId normalized safely`);

      const effective = resolveEffectiveTheme({
        personalPreference: badId,
        globalDefault: null,
      });
      assert(isValidThemeId(effective.themeId), 'corrupted resolution produces valid themeId');
      assert(Boolean(effective.theme), 'effective.theme object is populated');
    }
  });

  // 35. RTL/LTR Bidirectional Text Rules
  test('Phase 5 RTL/LTR Rules: index.css provides bidirectional text-align start and isolates canonical-numeric in LTR', () => {
    const cssPath = path.resolve(__dirname, '../index.css');
    const css = fs.readFileSync(cssPath, 'utf8');

    assert(css.includes('[dir="rtl"]'), 'CSS defines RTL direction rules');
    assert(css.includes('.canonical-numeric'), 'CSS defines canonical-numeric rule');
    assert(css.includes('direction: ltr !important'), 'canonical-numeric enforces LTR');
  });

  // 36. Phase 6 Storage Contracts & Multi-Tab Synchronization
  test('Phase 6 Storage Contracts: Keys are immutable and support cross-tab event synchronization', () => {
    assert(THEME_STORAGE_KEYS.GLOBAL_DEFAULT === 'sarwan_theme_global_default', 'Global default key stable');
    assert(THEME_STORAGE_KEYS.GUEST_PREFERENCE === 'sarwan_theme_guest', 'Guest preference key stable');
    assert(THEME_STORAGE_KEYS.USER_PREFERENCE_PREFIX === 'sarwan_theme_user_', 'User preference prefix stable');
    assert(THEME_STORAGE_KEYS.LEGACY_USER_THEME === 'sarwan_user_theme', 'Legacy user theme key stable');

    const testUserId = 'test_user_multi_tab_999';
    setStoredUserTheme(testUserId, 'sarwan_dark');
    assert(getStoredUserTheme(testUserId) === 'sarwan_dark', 'User preference saved');
    clearStoredUserTheme(testUserId);
    assert(getStoredUserTheme(testUserId) === null, 'User preference cleanly removed');
  });

  // 37. Architecture: Exactly 2 official themes registered
  test('Phase 6 Architecture: All active themes are uniquely registered with complete immutable definitions', () => {
    assert(THEME_CATALOG.length === 2, 'Exactly 2 themes registered in active catalog');
    const ids = new Set(THEME_CATALOG.map((t) => t.id));
    assert(ids.size === 2, 'All active theme IDs are strictly unique');

    for (const t of THEME_CATALOG) {
      assert(THEME_MAP[t.id] === t, `${t.id} accurately mapped in THEME_MAP dictionary`);
      assert(typeof t.name === 'string' && t.name.length > 0, `${t.id} has valid display name`);
      assert(t.mode === 'light' || t.mode === 'dark', `${t.id} has valid mode`);
      assert(Boolean(t.tokens.colors.primary.default), `${t.id} defines primary.default`);
      assert(Boolean(t.tokens.colors.background.base), `${t.id} defines background.base`);
      assert(Boolean(t.tokens.colors.surface.card), `${t.id} defines surface.card`);
      assert(Boolean(t.tokens.colors.text.primary), `${t.id} defines text.primary`);
    }
  });

  // 38. Font Asset Documentation & Fallbacks
  test('Phase 6 Font System: public/fonts/README.md documents Mokoto specs and CSS defines complete fallbacks', () => {
    const readmePath = path.resolve(__dirname, '../../public/fonts/README.md');
    assert(fs.existsSync(readmePath), 'public/fonts/README.md exists');
    const readme = fs.readFileSync(readmePath, 'utf8');
    assert(readme.includes('Mokoto'), 'README documents Mokoto typeface requirements');

    const cssPath = path.resolve(__dirname, '../index.css');
    const css = fs.readFileSync(cssPath, 'utf8');
    assert(css.includes('--font-family-primary:'), '--font-family-primary CSS variable defined');
    assert(css.includes("'Noto Naskh Arabic'"), 'Noto Naskh Arabic fallback included');
    assert(css.includes("'Amiri'"), 'Amiri fallback included');
  });

  // 39. Issue 6 Global Default Rollback Contract
  test('Issue 6 Global Default Rollback Contract: clearStoredGlobalDefault and failure recovery', () => {
    setStoredGlobalDefault('sarwan_dark');
    assert(getStoredGlobalDefault() === 'sarwan_dark', 'Stored global default set');

    const previous = getStoredGlobalDefault();
    setStoredGlobalDefault('sarwan_light');
    assert(getStoredGlobalDefault() === 'sarwan_light', 'Optimistic value saved');

    if (previous) {
      setStoredGlobalDefault(previous);
    }
    assert(getStoredGlobalDefault() === 'sarwan_dark', 'Restored to previous global default');

    clearStoredGlobalDefault();
    assert(getStoredGlobalDefault() === null, 'Global default cleanly cleared');
  });

  // 40. Simplified Theme Selector Verification
  test('Phase 4 Simplified Selector: Catalog strictly offers Light Mode and Dark Mode', () => {
    const lightModes = THEME_CATALOG.filter((t) => t.mode === 'light');
    const darkModes = THEME_CATALOG.filter((t) => t.mode === 'dark');

    assert(lightModes.length === 1, `Expected 1 light mode, got ${lightModes.length}`);
    assert(darkModes.length === 1, `Expected 1 dark mode, got ${darkModes.length}`);
    assert(lightModes[0].id === 'sarwan_light', 'Light mode ID is sarwan_light');
    assert(darkModes[0].id === 'sarwan_dark', 'Dark mode ID is sarwan_dark');
  });

  // 41. Preview & Cancellation Storage Non-Pollution
  test('Issue 4 Preview & Cancel: Live preview does not mutate persisted storage', () => {
    const testUser = 'user_preview_test_888';
    setStoredUserTheme(testUser, 'sarwan_light');
    assert(getStoredUserTheme(testUser) === 'sarwan_light', 'Initial preference persisted');

    // User previews dark mode without saving
    const previewCandidate = 'sarwan_dark';
    assert(isValidThemeId(previewCandidate), 'Candidate is valid theme');

    // Storage MUST remain untouched during unconfirmed preview
    assert(getStoredUserTheme(testUser) === 'sarwan_light', 'Stored theme untouched during preview');

    // On cancel, previous theme remains intact
    const active = getStoredUserTheme(testUser);
    assert(active === 'sarwan_light', 'Active saved theme preserved after preview cancellation');

    clearStoredUserTheme(testUser);
  });

  // 42. WCAG 2.2 AA Mathematical Contrast Verification for Light and Dark Modes
  test('Issue 7 WCAG 2.2 AA Contrast: Text-to-background >= 4.5:1 across both Sarwan modes', () => {
    function getLuminance(hex: string): number {
      const cleanHex = hex.replace('#', '');
      const r = parseInt(cleanHex.substring(0, 2), 16) / 255;
      const g = parseInt(cleanHex.substring(2, 4), 16) / 255;
      const b = parseInt(cleanHex.substring(4, 6), 16) / 255;

      const a = [r, g, b].map((v) => (v <= 0.03928 ? v / 12.92 : Math.pow((v + 0.055) / 1.055, 2.4)));
      return a[0] * 0.2126 + a[1] * 0.7152 + a[2] * 0.0722;
    }

    function getContrast(hex1: string, hex2: string): number {
      const l1 = getLuminance(hex1);
      const l2 = getLuminance(hex2);
      const lighter = Math.max(l1, l2);
      const darker = Math.min(l1, l2);
      return (lighter + 0.05) / (darker + 0.05);
    }

    for (const t of THEME_CATALOG) {
      const bg = t.preview.background;
      const text = t.preview.text;
      const ratio = getContrast(bg, text);
      assert(ratio >= 4.5, `Theme ${t.name} text contrast must achieve >= 4.5:1, got ${ratio.toFixed(2)}:1`);
    }
  });

  console.log('===============================================================');
  console.log(`TOTAL SCENARIOS VERIFIED: ${passed}/${total}`);
  console.log(`STATUS: ${passed === total ? 'ALL SCENARIOS PASSED' : 'SOME SCENARIOS FAILED'}`);
  console.log('===============================================================');

  return { passed, total };
}

// Auto-run if executed via tsx directly
if (typeof process !== 'undefined' && process.argv && process.argv[1]?.includes('themeSystemTests')) {
  const result = runThemeSystemTests();
  if (result.passed !== result.total) {
    process.exit(1);
  }
}
