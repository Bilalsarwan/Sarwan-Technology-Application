/**
 * Sarwan Technology Billing System
 * Security Remediation & Authentication Migration Test Suite
 * 
 * Verifies:
 * 1. Server-side timing-safe legacy password verification.
 * 2. Canonical immutable identity generation.
 * 3. Profile sanitization (zero passwordHash or passwordSalt in client responses).
 * 4. Inactive and deactivated account rejection.
 * 5. Customer phone ambiguity detection.
 * 6. Server-side Super Admin verification for Payment Reversal.
 * 7. 48-Hour payment reversal business rule enforcement.
 * 8. Financial ledger invariance (totalAmount, totalPaid, remaining, void records).
 */

import {
  timingSafeCompare,
  computeServerPasswordHash,
  verifyLegacyPasswordServer,
  getImmutableAuthEmail,
  sanitizeUserProfile,
} from '../services/authBackendService';
import { UserProfile, Payment, Invoice } from '../types';
import { checkPaymentReversalEligibility } from './paymentValidation';

function assert(condition: boolean, message: string) {
  if (!condition) {
    console.error(`[FAIL] ${message}`);
    throw new Error(`Assertion failed: ${message}`);
  }
  console.log(`[PASS] ${message}`);
}

async function runSecurityAuthMigrationTests() {
  console.log('================================================================');
  console.log(' SARWAN TECHNOLOGY BILLING SYSTEM — SECURITY & MIGRATION TESTS ');
  console.log('================================================================\n');

  let passed = 0;

  // --- 1. TIMING-SAFE PASSWORD HASH COMPARISON ---
  console.log('--- 1. Timing-Safe Cryptographic Hash Verification ---');
  const salt = 'a1b2c3d4e5f60718';
  const password = 'Sarwan@User2026!';
  const expectedHash = computeServerPasswordHash(password, salt);

  assert(
    verifyLegacyPasswordServer(password, salt, expectedHash),
    'Valid legacy password and salt verifies successfully on server'
  );
  passed++;

  assert(
    !verifyLegacyPasswordServer('WrongPassword!', salt, expectedHash),
    'Incorrect password fails server verification'
  );
  passed++;

  assert(
    !verifyLegacyPasswordServer(password, 'tampered_salt', expectedHash),
    'Tampered salt fails server verification'
  );
  passed++;

  assert(
    !verifyLegacyPasswordServer('', salt, expectedHash),
    'Empty password string is rejected'
  );
  passed++;

  assert(
    !timingSafeCompare('deadbeef', 'cafebabe'),
    'Timing-safe compare rejects mismatched hashes'
  );
  passed++;

  assert(
    timingSafeCompare(expectedHash, expectedHash),
    'Timing-safe compare accepts identical hashes'
  );
  passed++;

  // --- 2. CANONICAL IMMUTABLE IDENTITY GENERATION ---
  console.log('\n--- 2. Canonical Immutable Identity Mapping ---');
  const staffProfile: UserProfile = {
    id: 'ST-U-5000',
    userId: 'ST-U-5000',
    name: 'Bilal Sarwan',
    username: 'bilalsarwan7',
    email: 'bilalsarwan7@gmail.com',
    role: 'super_admin',
    status: 'active',
    createdAt: '2026-10-01T00:00:00Z',
  };

  const staffEmail = getImmutableAuthEmail(staffProfile);
  assert(
    staffEmail === 'u.st-u-5000@auth.sarwan.tech',
    `Staff canonical email derived from immutable userId: ${staffEmail}`
  );
  passed++;

  const customerProfile: UserProfile = {
    id: 'ST-U-5005',
    userId: 'ST-U-5005',
    customerId: 'CUST-1042',
    name: 'Ahmad Khan',
    username: 'ahmad_khan',
    email: 'ahmad@example.com',
    role: 'customer',
    status: 'active',
    createdAt: '2026-10-01T00:00:00Z',
  };

  const customerEmail = getImmutableAuthEmail(customerProfile);
  assert(
    customerEmail === 'c.cust-1042@customer.sarwan.tech',
    `Customer canonical email derived from customerId: ${customerEmail}`
  );
  passed++;

  // --- 3. PROFILE SANITIZATION & ZERO HASH LEAKAGE ---
  console.log('\n--- 3. Client Profile Sanitization (Zero Credential Leakage) ---');
  const sensitiveProfile: UserProfile = {
    ...staffProfile,
    passwordHash: expectedHash,
    passwordSalt: salt,
  };

  const sanitized = sanitizeUserProfile(sensitiveProfile);
  assert(
    (sanitized as any).passwordHash === undefined,
    'Sanitized profile strictly removes passwordHash'
  );
  passed++;

  assert(
    (sanitized as any).passwordSalt === undefined,
    'Sanitized profile strictly removes passwordSalt'
  );
  passed++;

  assert(
    sanitized.id === staffProfile.id && sanitized.username === staffProfile.username,
    'Sanitized profile preserves non-sensitive business attributes'
  );
  passed++;

  // --- 4. 48-HOUR PAYMENT REVERSAL BUSINESS RULE & AUTHORIZATION ---
  console.log('\n--- 4. 48-Hour Payment Reversal Rule & Ledger Protection ---');
  const nowMs = Date.now();

  const recentPayment: Payment = {
    id: 'pay-001',
    invoiceId: 'inv-001',
    billNumber: 'ST-INV-100',
    customerId: 'cust-1',
    customerName: 'Kabul Traders',
    amount: 15000,
    date: '2026-10-10',
    method: 'CASH',
    createdAt: new Date(nowMs - 2 * 60 * 60 * 1000).toISOString(), // 2 hours old
  };

  const recentEligibility = checkPaymentReversalEligibility(recentPayment);
  assert(
    recentEligibility.isEligible === true,
    'Payment created 2 hours ago is eligible for reversal'
  );
  passed++;

  const expiredPayment: Payment = {
    ...recentPayment,
    id: 'pay-002',
    createdAt: new Date(nowMs - 49 * 60 * 60 * 1000).toISOString(), // 49 hours old
  };

  const expiredEligibility = checkPaymentReversalEligibility(expiredPayment);
  assert(
    expiredEligibility.isEligible === false,
    'Payment created 49 hours ago is strictly ineligible for reversal'
  );
  passed++;

  const alreadyVoidPayment: Payment = {
    ...recentPayment,
    id: 'pay-003',
    isVoid: true,
  };

  const voidEligibility = checkPaymentReversalEligibility(alreadyVoidPayment);
  assert(
    voidEligibility.isEligible === false,
    'Already reversed payment cannot be reversed again'
  );
  passed++;

  // --- 5. FINANCIAL LEDGER INVARIANCE ACROSS REVERSAL ---
  console.log('\n--- 5. Financial Ledger Invariance Across Payment Correction ---');
  const originalInvoice: Invoice = {
    id: 'inv-001',
    billNumber: 'ST-INV-100',
    customerId: 'cust-1',
    customerSnapshot: {
      id: 'cust-1',
      name: 'Kabul Traders',
      phone: '0731339014',
      address: 'Kabul',
      companyName: 'Kabul Traders Ltd',
    },
    companySnapshot: {
      companyName: 'Sarwan Technology',
      logo: '',
      phone: '',
      whatsapp: '',
      email: '',
      address: '',
      currency: 'AFN',
      invoiceNote: '',
    },
    date: '2026-10-10',
    items: [],
    note: '',
    totalAmount: 50000,
    totalPaid: 25000,
    remaining: 25000,
    status: 'Partially Paid',
    createdAt: '2026-10-10T00:00:00Z',
    updatedAt: '2026-10-10T00:00:00Z',
  };

  // Reversing payment of 15000 with a corrected replacement payment of 10000
  const reversedAmount = 15000;
  const replacementAmount = 10000;

  const currentTotalPaid = originalInvoice.totalPaid;
  const invTotal = originalInvoice.totalAmount;
  const newTotalPaid = Math.max(0, currentTotalPaid - reversedAmount + replacementAmount);
  const newRemaining = Math.max(0, invTotal - newTotalPaid);

  assert(
    newTotalPaid === 20000,
    `Calculated new totalPaid is exact (25000 - 15000 + 10000 = 20000): got ${newTotalPaid}`
  );
  passed++;

  assert(
    newRemaining === 30000,
    `Calculated new remaining balance is exact (50000 - 20000 = 30000): got ${newRemaining}`
  );
  passed++;

  assert(
    originalInvoice.totalAmount === 50000,
    'Invoice totalAmount remains 100% immutable across reversal'
  );
  passed++;

  console.log('\n================================================================');
  console.log(` ALL ${passed} / ${passed} SECURITY & MIGRATION TESTS PASSED! `);
  console.log('================================================================\n');
}

runSecurityAuthMigrationTests().catch((err) => {
  console.error('Test execution failed:', err);
  process.exit(1);
});
