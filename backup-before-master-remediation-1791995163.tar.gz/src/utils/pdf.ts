import jsPDF from 'jspdf';
import html2canvas from 'html2canvas';
import {
  verifyCanonicalInvoiceDocumentStructure,
  ensureAllFontsLoaded,
  forceLayoutAndStabilize,
  hasTransformedAncestor,
} from './print';

/**
 * Robustly converts any modern CSS color string (oklch, oklab, lab, lch, color(...))
 * into standard html2canvas-compatible rgb(...) or rgba(...) using an offscreen 2D canvas.
 */
function cssColorToRgb(colorStr: string): string {
  if (!colorStr || typeof colorStr !== 'string') return colorStr;
  const trimmed = colorStr.trim();
  if (
    !trimmed.includes('oklch') &&
    !trimmed.includes('oklab') &&
    !trimmed.includes('lab(') &&
    !trimmed.includes('lch(') &&
    !trimmed.includes('color(')
  ) {
    return trimmed;
  }

  try {
    const canvas = document.createElement('canvas');
    canvas.width = 1;
    canvas.height = 1;
    const ctx = canvas.getContext('2d', { willReadFrequently: true });
    if (!ctx) return '#000000';
    ctx.clearRect(0, 0, 1, 1);
    ctx.fillStyle = trimmed;
    ctx.fillRect(0, 0, 1, 1);
    const [r, g, b, a] = ctx.getImageData(0, 0, 1, 1).data;
    const alpha = a / 255;
    if (alpha >= 0.99) {
      return `rgb(${r}, ${g}, ${b})`;
    } else {
      return `rgba(${r}, ${g}, ${b}, ${Number(alpha.toFixed(2))})`;
    }
  } catch {
    return '#000000';
  }
}

/**
 * Replaces modern color functions inside compound CSS properties (like box-shadow or borders)
 */
function sanitizeColorProperty(val: string): string {
  if (!val || typeof val !== 'string') return val;
  if (
    !val.includes('oklch') &&
    !val.includes('oklab') &&
    !val.includes('lab(') &&
    !val.includes('lch(') &&
    !val.includes('color(')
  ) {
    return val;
  }
  return val.replace(/(oklch|oklab|lab|lch|color)\([^)]+\)/gi, (match) => cssColorToRgb(match));
}

/**
 * Safely executes html2canvas for general elements (e.g. staff cards, receipts) with color sanitization.
 */
export async function safeHtml2Canvas(
  target: HTMLElement,
  options: any = {}
): Promise<HTMLCanvasElement> {
  if (typeof window === 'undefined') {
    return html2canvas(target, options);
  }

  const originalGetComputedStyle = window.getComputedStyle;

  function createComputedStyleColorProxy(style: CSSStyleDeclaration): CSSStyleDeclaration {
    return new Proxy(style, {
      get(t, prop) {
        const val = (t as any)[prop];
        if (prop === 'getPropertyValue') {
          return (p: string) => {
            const raw = t.getPropertyValue(p);
            return typeof raw === 'string' &&
              (raw.includes('oklch') ||
                raw.includes('oklab') ||
                raw.includes('lab(') ||
                raw.includes('lch(') ||
                raw.includes('color('))
              ? sanitizeColorProperty(raw)
              : raw;
          };
        }
        if (typeof val === 'function') {
          return val.bind(t);
        }
        if (typeof val === 'string') {
          if (
            val.includes('oklch') ||
            val.includes('oklab') ||
            val.includes('lab(') ||
            val.includes('lch(') ||
            val.includes('color(')
          ) {
            return sanitizeColorProperty(val);
          }
        }
        return val;
      },
    });
  }

  window.getComputedStyle = function (this: any, elt: Element, pseudoElt?: string | null) {
    const targetWin = (elt && elt.ownerDocument && elt.ownerDocument.defaultView) || window;
    const style = originalGetComputedStyle.call(targetWin, elt, pseudoElt);
    return style ? createComputedStyleColorProxy(style) : style;
  };

  const userOnClone = options.onclone;
  const wrappedOptions = {
    ...options,
    onclone: (clonedDoc: Document, clonedElement: HTMLElement) => {
      if (clonedDoc.defaultView) {
        const origIframeGetComputedStyle = clonedDoc.defaultView.getComputedStyle;
        const iframeWin = clonedDoc.defaultView;
        iframeWin.getComputedStyle = function (this: any, elt: Element, pseudoElt?: string | null) {
          const style = origIframeGetComputedStyle.call(iframeWin, elt, pseudoElt);
          return style ? createComputedStyleColorProxy(style) : style;
        };
      }
      try {
        const styleTags = clonedDoc.querySelectorAll('style');
        styleTags.forEach((s) => {
          if (s.textContent && (s.textContent.includes('oklch') || s.textContent.includes('oklab'))) {
            s.textContent = sanitizeColorProperty(s.textContent);
          }
        });
      } catch {
        // safe ignore
      }
      if (typeof userOnClone === 'function') {
        userOnClone(clonedDoc, clonedElement);
      }
    },
  };

  try {
    return await html2canvas(target, wrappedOptions);
  } finally {
    window.getComputedStyle = originalGetComputedStyle;
  }
}

export interface PdfExportOptions {
  paperSize?: 'A4' | 'A5' | 'Letter' | 'Thermal80' | 'Thermal58' | 'Custom';
  orientation?: 'portrait' | 'landscape';
}

/**
 * Downloads a DOM element (like an A4 invoice, report, or POS thermal receipt) as a high-resolution PDF.
 * Guaranteed to fit perfectly on standard pages or thermal rolls with crystal-clear fonts, borders, and logos,
 * completely immune to Tailwind v4 oklch color parsing errors in html2canvas.
 * Supports multi-page invoices with automatic page breaks.
 */
export async function downloadElementAsPdf(
  elementOrId: string | HTMLElement,
  filename: string = 'Sarwan-Technology-Invoice.pdf',
  options?: PdfExportOptions
): Promise<void> {
  let element: HTMLElement | null = null;
  if (typeof elementOrId === 'string') {
    element = document.getElementById(elementOrId);
  } else if (elementOrId instanceof HTMLElement) {
    element = elementOrId;
  }

  if (!element) {
    throw new Error(`Element "${elementOrId}" not found for PDF export.`);
  }

  // Ensure all web fonts are loaded and applied
  await ensureAllFontsLoaded();

  // Wait for all images inside the printable element to load completely
  const images = Array.from(element.querySelectorAll('img'));
  await Promise.all(
    images.map(
      (img) =>
        new Promise<void>((resolve) => {
          if (img.complete && img.naturalHeight !== 0) {
            resolve();
          } else {
            img.onload = () => resolve();
            img.onerror = () => resolve();
          }
        })
    )
  );

  // Force reflow and wait for stable frames
  await forceLayoutAndStabilize(element);

  // Check if there are multiple page sheets inside the container
  const pageSheets = Array.from(
    element.querySelectorAll<HTMLElement>('.canonical-invoice-sheet, .invoice-page-sheet')
  );
  const targets = pageSheets.length > 0 ? pageSheets : [element];

  // Programmatically verify the content before PDF capture
  try {
    verifyCanonicalInvoiceDocumentStructure(element);
  } catch {
    // Non-critical
  }

  // Paper dimensions in mm
  const isLandscape = options?.orientation === 'landscape';
  let format: string | [number, number] = 'a4';
  let pageWidth = 210;
  let pageHeight = 297;

  if (options?.paperSize === 'A5') {
    format = 'a5';
    pageWidth = 148;
    pageHeight = 210;
  } else if (options?.paperSize === 'Letter') {
    format = 'letter';
    pageWidth = 215.9;
    pageHeight = 279.4;
  } else if (options?.paperSize === 'Thermal80') {
    pageWidth = 80;
    const computedHeightMm = Math.max(100, Math.ceil((element.scrollHeight / (element.scrollWidth || 300)) * 80) + 15);
    pageHeight = computedHeightMm;
    format = [pageWidth, pageHeight];
  } else if (options?.paperSize === 'Thermal58') {
    pageWidth = 58;
    const computedHeightMm = Math.max(90, Math.ceil((element.scrollHeight / (element.scrollWidth || 220)) * 58) + 15);
    pageHeight = computedHeightMm;
    format = [pageWidth, pageHeight];
  }

  if (isLandscape) {
    const temp = pageWidth;
    pageWidth = pageHeight;
    pageHeight = temp;
  }

  const pdf = new jsPDF({
    orientation: isLandscape ? 'landscape' : 'portrait',
    unit: 'mm',
    format: format,
    compress: true,
  });

  for (let i = 0; i < targets.length; i++) {
    const target = targets[i];

    const targetRect = await forceLayoutAndStabilize(target);
    const targetWidth = Math.round(targetRect.width || target.offsetWidth || 794);
    const targetHeight = Math.round(targetRect.height || target.offsetHeight || 1123);

    // Render canvas capture with 2.5x scale for crisp print quality
    const canvas = await safeHtml2Canvas(target, {
      scale: 2.5,
      useCORS: true,
      allowTaint: true,
      logging: false,
      backgroundColor: '#ffffff',
      width: targetWidth,
      height: targetHeight,
      windowWidth: targetWidth,
      windowHeight: targetHeight,
      scrollX: 0,
      scrollY: 0,
      imageTimeout: 15000,
      onclone: (clonedDoc, clonedElement) => {
        // Reset scale and transforms
        clonedElement.style.opacity = '1';
        clonedElement.style.position = 'relative';
        clonedElement.style.left = '0';
        clonedElement.style.top = '0';
        clonedElement.style.transform = 'none';
        clonedElement.style.margin = '0';

        // Reset any ancestor preview zoom transforms
        let ancestor: HTMLElement | null = clonedElement.parentElement;
        while (ancestor && ancestor !== clonedDoc.body && ancestor !== clonedDoc.documentElement) {
          ancestor.style.transform = 'none';
          (ancestor.style as any).zoom = '1';
          ancestor = ancestor.parentElement;
        }

        // Technical container reset to prevent iframe scrollbars
        clonedDoc.documentElement.style.margin = '0';
        clonedDoc.documentElement.style.padding = '0';
        clonedDoc.documentElement.style.overflow = 'hidden';
        clonedDoc.body.style.margin = '0';
        clonedDoc.body.style.padding = '0';
        clonedDoc.body.style.overflow = 'hidden';
      },
    });

    const imgData = canvas.toDataURL('image/png', 1.0);

    if (i > 0) {
      pdf.addPage(format as any, isLandscape ? 'landscape' : 'portrait');
    }

    const canvasRatio = canvas.height / canvas.width;
    const expectedRatio = pageHeight / pageWidth;
    const finalPageHeight = Math.abs(canvasRatio - expectedRatio) < 0.005
      ? pageHeight
      : pageWidth * canvasRatio;

    pdf.addImage(imgData, 'PNG', 0, 0, pageWidth, finalPageHeight, undefined, 'SLOW');
  }

  // Programmatically report on generated PDF size and element count
  try {
    const pdfByteSize = pdf.output('arraybuffer').byteLength;
    verifyCanonicalInvoiceDocumentStructure(element, pdfByteSize);
  } catch {
    // Non-critical verification reporting
  }

  pdf.save(filename);
}

