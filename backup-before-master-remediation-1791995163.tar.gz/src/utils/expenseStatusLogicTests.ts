/**
 * SARWAN TECHNOLOGY BILLING SYSTEM
 * EXPENSE REQUEST STATUS LOGIC & WORKFLOW DISPLAY VERIFICATION SUITE
 * 
 * Verifies all 8 user-facing status labels, semantic colors, workflow transitions,
 * rejection visibility, resubmission approval resets, and privacy invariants.
 */

import assert from 'assert';
import {
  UserFacingExpenseStatus,
  EXPENSE_STATUS_HEX_COLORS,
  getExpenseStatusInfo,
  getRequesterExpenseStatus,
  isExpenseFullyApproved,
} from './expenseStatus';
import { Expense, ExpenseStatus } from '../types';
import { filterExpensesForUser } from '../services/db';

console.log('===============================================================');
console.log('   SARWAN TECHNOLOGY: EXPENSE STATUS LOGIC & DISPLAY TESTS     ');
console.log('===============================================================');

let totalTests = 0;
let passedTests = 0;

function runTest(name: string, fn: () => void) {
  totalTests++;
  try {
    fn();
    console.log(`  ✓ PASS: ${name}`);
    passedTests++;
  } catch (err: any) {
    console.error(`  ✗ FAIL: ${name}`);
    console.error(err);
    process.exit(1);
  }
}

// =========================================================================
// SECTION 1: USER-FACING LABELS & EXACT SEMANTIC COLORS
// =========================================================================
console.log('\n--- 1. USER-FACING LABELS & SEMANTIC COLORS ---');

const REQUIRED_LABELS: UserFacingExpenseStatus[] = [
  'Requested',
  'Pending Manager Approval',
  'Approved by Manager',
  'Pending Super Admin Approval',
  'Rejected',
  'Approved',
  'Resubmitted',
  'Executed / Disbursed',
];

runTest('All 8 required user-facing status labels are supported', () => {
  REQUIRED_LABELS.forEach((label) => {
    assert.strictEqual(typeof EXPENSE_STATUS_HEX_COLORS[label], 'string');
  });
});

runTest('Requested maps to exact semantic color blue #2563EB', () => {
  assert.strictEqual(EXPENSE_STATUS_HEX_COLORS['Requested'], '#2563EB');
  const info = getExpenseStatusInfo('draft');
  assert.strictEqual(info.label, 'Requested');
  assert.strictEqual(info.color, '#2563EB');
  assert.strictEqual(info.semanticType, 'blue');
});

runTest('Pending Manager Approval maps to exact semantic color blue #2563EB', () => {
  assert.strictEqual(EXPENSE_STATUS_HEX_COLORS['Pending Manager Approval'], '#2563EB');
  const info = getExpenseStatusInfo('pending_manager');
  assert.strictEqual(info.label, 'Pending Manager Approval');
  assert.strictEqual(info.color, '#2563EB');
  assert.strictEqual(info.semanticType, 'blue');
});

runTest('Approved by Manager maps to green #16A34A with Super Admin notice', () => {
  assert.strictEqual(EXPENSE_STATUS_HEX_COLORS['Approved by Manager'], '#16A34A');
  const collectorExp: Partial<Expense> = {
    id: 'exp-101',
    requestedByRole: 'payment_collector',
    status: 'pending_admin',
    managerApprovedBy: 'mgr-user-01',
    managerApprovedAt: '2026-10-12T08:00:00Z',
  };
  const info = getExpenseStatusInfo(collectorExp);
  assert.strictEqual(info.label, 'Approved by Manager');
  assert.strictEqual(info.color, '#16A34A');
  assert.strictEqual(info.semanticType, 'green');
  assert.strictEqual(info.requiresSuperAdminNotice, true);
  assert.strictEqual(info.isIntermediateApproval, true);
  assert.strictEqual(info.isFinalApproved, false);
});

runTest('Pending Super Admin Approval maps to exact semantic color blue #2563EB', () => {
  assert.strictEqual(EXPENSE_STATUS_HEX_COLORS['Pending Super Admin Approval'], '#2563EB');
  const managerExp: Partial<Expense> = {
    id: 'exp-102',
    requestedByRole: 'invoice_manager',
    status: 'pending_admin',
  };
  const info = getExpenseStatusInfo(managerExp);
  assert.strictEqual(info.label, 'Pending Super Admin Approval');
  assert.strictEqual(info.color, '#2563EB');
  assert.strictEqual(info.semanticType, 'blue');
  assert.strictEqual(info.requiresSuperAdminNotice, false);
});

runTest('Rejected maps to exact semantic color red #DC2626', () => {
  assert.strictEqual(EXPENSE_STATUS_HEX_COLORS['Rejected'], '#DC2626');
  const info = getExpenseStatusInfo('rejected');
  assert.strictEqual(info.label, 'Rejected');
  assert.strictEqual(info.color, '#DC2626');
  assert.strictEqual(info.semanticType, 'red');
});

runTest('Approved maps to exact semantic color green #16A34A', () => {
  assert.strictEqual(EXPENSE_STATUS_HEX_COLORS['Approved'], '#16A34A');
  const info = getExpenseStatusInfo('approved');
  assert.strictEqual(info.label, 'Approved');
  assert.strictEqual(info.color, '#16A34A');
  assert.strictEqual(info.semanticType, 'green');
  assert.strictEqual(info.isFinalApproved, true);
});

runTest('Resubmitted maps to exact semantic color blue #2563EB', () => {
  assert.strictEqual(EXPENSE_STATUS_HEX_COLORS['Resubmitted'], '#2563EB');
  const info = getExpenseStatusInfo('resubmitted');
  assert.strictEqual(info.label, 'Resubmitted');
  assert.strictEqual(info.color, '#2563EB');
  assert.strictEqual(info.semanticType, 'blue');
});

runTest('Executed / Disbursed maps to exact semantic color green #16A34A', () => {
  assert.strictEqual(EXPENSE_STATUS_HEX_COLORS['Executed / Disbursed'], '#16A34A');
  const info = getExpenseStatusInfo('executed');
  assert.strictEqual(info.label, 'Executed / Disbursed');
  assert.strictEqual(info.color, '#16A34A');
  assert.strictEqual(info.semanticType, 'green');
  assert.strictEqual(info.isExecuted, true);
});

// =========================================================================
// SECTION 2: PAYMENT COLLECTOR WORKFLOW STATES
// =========================================================================
console.log('\n--- 2. PAYMENT COLLECTOR WORKFLOW STATES ---');

runTest('State 1: Newly requested Collector expense resolves to Requested or Pending Manager Approval', () => {
  const expDraft: Partial<Expense> = {
    id: 'col-1',
    requestedByRole: 'payment_collector',
    status: 'draft',
  };
  assert.strictEqual(getRequesterExpenseStatus(expDraft).label, 'Requested');

  const expSubmitted: Partial<Expense> = {
    id: 'col-2',
    requestedByRole: 'payment_collector',
    status: 'pending_manager',
  };
  assert.strictEqual(getRequesterExpenseStatus(expSubmitted).label, 'Pending Manager Approval');
});

runTest('State 2: Collector request waiting for Invoice Manager resolves to Pending Manager Approval', () => {
  const exp: Partial<Expense> = {
    id: 'col-3',
    requestedByRole: 'payment_collector',
    status: 'pending_manager',
    requestedBy: 'collector-101',
  };
  const statusInfo = getRequesterExpenseStatus(exp);
  assert.strictEqual(statusInfo.label, 'Pending Manager Approval');
  assert.strictEqual(statusInfo.color, '#2563EB');
  assert.strictEqual(isExpenseFullyApproved(exp), false);
});

runTest('State 3: Invoice Manager approves Collector request -> Approved by Manager (awaiting Super Admin)', () => {
  const exp: Partial<Expense> = {
    id: 'col-4',
    requestedByRole: 'payment_collector',
    status: 'pending_admin',
    managerApprovedBy: 'manager-202',
    managerApprovedAt: '2026-10-12T09:30:00Z',
  };
  const statusInfo = getRequesterExpenseStatus(exp);
  assert.strictEqual(statusInfo.label, 'Approved by Manager');
  assert.strictEqual(statusInfo.color, '#16A34A');
  assert.strictEqual(statusInfo.requiresSuperAdminNotice, true);
  assert.strictEqual(statusInfo.isIntermediateApproval, true);
  // Manager approval ALONE does not equal final Approved
  assert.strictEqual(isExpenseFullyApproved(exp), false);
});

runTest('State 4: Super Admin approves Collector request -> Approved', () => {
  const exp: Partial<Expense> = {
    id: 'col-5',
    requestedByRole: 'payment_collector',
    status: 'approved',
    managerApprovedBy: 'manager-202',
    adminApprovedBy: 'admin-001',
    adminApprovedAt: '2026-10-12T10:00:00Z',
  };
  const statusInfo = getRequesterExpenseStatus(exp);
  assert.strictEqual(statusInfo.label, 'Approved');
  assert.strictEqual(statusInfo.color, '#16A34A');
  assert.strictEqual(statusInfo.isFinalApproved, true);
  assert.strictEqual(isExpenseFullyApproved(exp), true);
});

runTest('State 5: Executed or Disbursed Collector expense -> Executed / Disbursed', () => {
  const exp: Partial<Expense> = {
    id: 'col-6',
    requestedByRole: 'payment_collector',
    status: 'executed',
    executionStatus: 'executed',
    executedBy: 'admin-001',
  };
  const statusInfo = getRequesterExpenseStatus(exp);
  assert.strictEqual(statusInfo.label, 'Executed / Disbursed');
  assert.strictEqual(statusInfo.color, '#16A34A');
  assert.strictEqual(statusInfo.isExecuted, true);
  assert.strictEqual(isExpenseFullyApproved(exp), true);
});

// =========================================================================
// SECTION 3: INVOICE MANAGER WORKFLOW (NO FICTITIOUS MANAGER APPROVAL)
// =========================================================================
console.log('\n--- 3. INVOICE MANAGER WORKFLOW ---');

runTest('Invoice Manager submitted request initializes strictly as Pending Super Admin Approval', () => {
  const managerExp: Partial<Expense> = {
    id: 'mgr-1',
    requestedByRole: 'invoice_manager',
    status: 'pending_admin',
    requestedBy: 'manager-202',
  };
  const statusInfo = getRequesterExpenseStatus(managerExp);
  assert.strictEqual(statusInfo.label, 'Pending Super Admin Approval');
  assert.strictEqual(statusInfo.color, '#2563EB');
  // Must NOT have fictitious manager approval notice
  assert.strictEqual(statusInfo.requiresSuperAdminNotice, false);
  assert.strictEqual(statusInfo.isIntermediateApproval, false);
  assert.strictEqual(isExpenseFullyApproved(managerExp), false);
});

runTest('Super Admin approves Invoice Manager request -> Approved', () => {
  const managerExp: Partial<Expense> = {
    id: 'mgr-2',
    requestedByRole: 'invoice_manager',
    status: 'approved',
    adminApprovedBy: 'admin-001',
  };
  const statusInfo = getRequesterExpenseStatus(managerExp);
  assert.strictEqual(statusInfo.label, 'Approved');
  assert.strictEqual(statusInfo.color, '#16A34A');
  assert.strictEqual(isExpenseFullyApproved(managerExp), true);
});

// =========================================================================
// SECTION 4: REJECTION & RESUBMISSION RULES
// =========================================================================
console.log('\n--- 4. REJECTION & RESUBMISSION RULES ---');

runTest('Rejected Collector request displays Rejected and preserves rejection reason', () => {
  const exp: Partial<Expense> = {
    id: 'rej-1',
    requestedByRole: 'payment_collector',
    status: 'rejected',
    rejectionReason: 'Receipt missing valid vendor tax identifier',
    rejectedBy: 'manager-202',
  };
  const statusInfo = getRequesterExpenseStatus(exp);
  assert.strictEqual(statusInfo.label, 'Rejected');
  assert.strictEqual(statusInfo.color, '#DC2626');
  assert.strictEqual(statusInfo.rejectionReason, 'Receipt missing valid vendor tax identifier');
  assert.strictEqual(isExpenseFullyApproved(exp), false);
});

runTest('Rejected Invoice Manager request by Super Admin displays Rejected and reason', () => {
  const exp: Partial<Expense> = {
    id: 'rej-2',
    requestedByRole: 'invoice_manager',
    status: 'rejected',
    rejectionReason: 'Exceeds budget cap without purchase order',
    rejectedBy: 'admin-001',
  };
  const statusInfo = getRequesterExpenseStatus(exp);
  assert.strictEqual(statusInfo.label, 'Rejected');
  assert.strictEqual(statusInfo.color, '#DC2626');
  assert.strictEqual(statusInfo.rejectionReason, 'Exceeds budget cap without purchase order');
});

runTest('Resubmitted Collector request routes back to Pending Manager Approval and invalidates old approvals', () => {
  // Simulating revised expense: old managerApprovedBy was deleted on resubmission
  const resubmittedCollectorExp: Partial<Expense> = {
    id: 'resub-1',
    requestedByRole: 'payment_collector',
    status: 'pending_manager',
    revision: 2,
    resubmittedAt: '2026-10-12T11:00:00Z',
    resubmissionCorrections: 'Attached updated tax invoice with vendor ID',
    // managerApprovedBy is absent because it was invalidated
  };
  const statusInfo = getRequesterExpenseStatus(resubmittedCollectorExp);
  assert.strictEqual(statusInfo.label, 'Pending Manager Approval');
  assert.strictEqual(statusInfo.color, '#2563EB');
  assert.strictEqual(statusInfo.isResubmitted, true);
  // Must NOT appear approved due to old approvals
  assert.strictEqual(isExpenseFullyApproved(resubmittedCollectorExp), false);
  assert.strictEqual(statusInfo.isFinalApproved, false);
});

runTest('Resubmitted Invoice Manager request routes back to Pending Super Admin Approval', () => {
  const resubmittedManagerExp: Partial<Expense> = {
    id: 'resub-2',
    requestedByRole: 'invoice_manager',
    status: 'pending_admin',
    revision: 2,
    resubmittedAt: '2026-10-12T11:15:00Z',
    resubmissionCorrections: 'Attached signed purchase order',
  };
  const statusInfo = getRequesterExpenseStatus(resubmittedManagerExp);
  assert.strictEqual(statusInfo.label, 'Pending Super Admin Approval');
  assert.strictEqual(statusInfo.color, '#2563EB');
  assert.strictEqual(statusInfo.isResubmitted, true);
  assert.strictEqual(isExpenseFullyApproved(resubmittedManagerExp), false);
});

runTest('preferResubmitted flag allows explicit Resubmitted label on revised requests', () => {
  const exp: Partial<Expense> = {
    id: 'resub-3',
    requestedByRole: 'payment_collector',
    status: 'pending_manager',
    revision: 2,
    resubmittedAt: '2026-10-12T11:00:00Z',
  };
  const statusInfo = getExpenseStatusInfo(exp, { preferResubmitted: true });
  assert.strictEqual(statusInfo.label, 'Resubmitted');
  assert.strictEqual(statusInfo.color, '#2563EB');
  assert.strictEqual(statusInfo.semanticType, 'blue');
});

// =========================================================================
// SECTION 5: ROLE-BASED PRIVACY & DATA FILTERING
// =========================================================================
console.log('\n--- 5. ROLE-BASED PRIVACY & DATA FILTERING ---');

runTest('Payment Collector can ONLY view their own expense requests', () => {
  const allExpenses: Expense[] = [
    {
      id: 'e1',
      title: 'Fuel Collector Alpha',
      amount: 1200,
      date: '2026-10-12',
      note: '',
      requestedBy: 'collector-alpha',
      requestedByName: 'Collector Alpha',
      requestedByRole: 'payment_collector',
      status: 'pending_manager',
      createdAt: '2026-10-12T08:00:00Z',
    },
    {
      id: 'e2',
      title: 'Cable Collector Beta',
      amount: 2500,
      date: '2026-10-12',
      note: '',
      requestedBy: 'collector-beta',
      requestedByName: 'Collector Beta',
      requestedByRole: 'payment_collector',
      status: 'pending_manager',
      createdAt: '2026-10-12T08:30:00Z',
    },
  ];

  const alphaView = filterExpensesForUser(allExpenses, 'payment_collector', 'collector-alpha');
  assert.strictEqual(alphaView.length, 1);
  assert.strictEqual(alphaView[0].id, 'e1');
  assert.strictEqual(alphaView[0].requestedBy, 'collector-alpha');

  const betaView = filterExpensesForUser(allExpenses, 'payment_collector', 'collector-beta');
  assert.strictEqual(betaView.length, 1);
  assert.strictEqual(betaView[0].id, 'e2');
  assert.strictEqual(betaView[0].requestedBy, 'collector-beta');
});

runTest('Invoice Manager and Super Admin can view all submitted expenses for review', () => {
  const allExpenses: Expense[] = [
    {
      id: 'e1',
      title: 'Fuel',
      amount: 1200,
      date: '2026-10-12',
      note: '',
      requestedBy: 'collector-alpha',
      requestedByName: 'Collector Alpha',
      requestedByRole: 'payment_collector',
      status: 'pending_manager',
      createdAt: '2026-10-12T08:00:00Z',
    },
    {
      id: 'e2',
      title: 'Cable',
      amount: 2500,
      date: '2026-10-12',
      note: '',
      requestedBy: 'collector-beta',
      requestedByName: 'Collector Beta',
      requestedByRole: 'payment_collector',
      status: 'pending_manager',
      createdAt: '2026-10-12T08:30:00Z',
    },
  ];

  const managerView = filterExpensesForUser(allExpenses, 'invoice_manager', 'manager-1');
  assert.strictEqual(managerView.length, 2);

  const adminView = filterExpensesForUser(allExpenses, 'super_admin', 'admin-1');
  assert.strictEqual(adminView.length, 2);
});

runTest('Customer account receives strictly 0 operating expense records', () => {
  const allExpenses: Expense[] = [
    {
      id: 'e1',
      title: 'Internal Purchase',
      amount: 5000,
      date: '2026-10-12',
      note: '',
      requestedBy: 'collector-alpha',
      requestedByName: 'Staff',
      requestedByRole: 'payment_collector',
      status: 'approved',
      createdAt: '2026-10-12T08:00:00Z',
    },
  ];
  const customerView = filterExpensesForUser(allExpenses, 'customer', 'cust-99');
  assert.strictEqual(customerView.length, 0);
});

// =========================================================================
// SECTION 6: COMPLETE WORKFLOW STATE MATRIX SUMMARY
// =========================================================================
console.log('\n--- 6. COMPLETE WORKFLOW STATE MATRIX VERIFICATION ---');

const WORKFLOW_STATE_MATRIX = [
  { state: 'Newly requested', status: 'draft', expectedLabel: 'Requested', expectedColor: '#2563EB' },
  { state: 'Pending Manager Approval', status: 'pending_manager', expectedLabel: 'Pending Manager Approval', expectedColor: '#2563EB' },
  {
    state: 'Approved by Manager',
    status: 'pending_admin',
    collectorWithMgr: true,
    expectedLabel: 'Approved by Manager',
    expectedColor: '#16A34A',
  },
  {
    state: 'Pending Super Admin Approval',
    status: 'pending_admin',
    collectorWithMgr: false,
    expectedLabel: 'Pending Super Admin Approval',
    expectedColor: '#2563EB',
  },
  { state: 'Rejected by Manager', status: 'rejected', expectedLabel: 'Rejected', expectedColor: '#DC2626' },
  { state: 'Rejected by Super Admin', status: 'rejected', expectedLabel: 'Rejected', expectedColor: '#DC2626' },
  {
    state: 'Resubmitted Collector request',
    status: 'resubmitted',
    expectedLabel: 'Resubmitted',
    expectedColor: '#2563EB',
  },
  {
    state: 'Resubmitted Invoice Manager request',
    status: 'resubmitted',
    expectedLabel: 'Resubmitted',
    expectedColor: '#2563EB',
  },
  { state: 'Fully Approved request', status: 'approved', expectedLabel: 'Approved', expectedColor: '#16A34A' },
  { state: 'Executed / Disbursed request', status: 'executed', expectedLabel: 'Executed / Disbursed', expectedColor: '#16A34A' },
];

WORKFLOW_STATE_MATRIX.forEach((item) => {
  runTest(`Matrix: ${item.state} -> "${item.expectedLabel}" (${item.expectedColor})`, () => {
    let exp: Partial<Expense>;
    if (item.collectorWithMgr) {
      exp = {
        requestedByRole: 'payment_collector',
        status: 'pending_admin',
        managerApprovedBy: 'mgr-01',
      };
    } else if (item.collectorWithMgr === false) {
      exp = {
        requestedByRole: 'invoice_manager',
        status: 'pending_admin',
      };
    } else {
      exp = {
        status: item.status as ExpenseStatus,
      };
    }
    const info = getExpenseStatusInfo(exp);
    assert.strictEqual(info.label, item.expectedLabel);
    assert.strictEqual(info.color, item.expectedColor);
  });
});

console.log('===============================================================');
console.log(`TOTAL TESTS: ${totalTests} | PASSED: ${passedTests} | FAILED: 0`);
console.log('ALL EXPENSE STATUS LOGIC & WORKFLOW DISPLAY TESTS PASSED! ✓');
console.log('===============================================================');
