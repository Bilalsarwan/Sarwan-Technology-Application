import { InvoiceDesignSettings, DesignerElement, DEFAULT_INVOICE_DESIGN } from '../types/invoiceDesign';

/**
 * CANONICAL VISIBILITY STATE MANAGEMENT
 * Single authoritative visibility read/write engine for all Designer Elements.
 * Synchronizes duplicate properties (e.g. visibility.invoiceNumber & invoiceNumber.show)
 * so that Insert Drawer, Contextual Toolbar, and Invoice Preview stay in 100% lockstep.
 */

export function getElementVisibility(
  element: DesignerElement | string,
  design: InvoiceDesignSettings
): boolean {
  switch (element) {
    case 'logoLeft':
      return Boolean(design.visibility?.logo1 && design.logos?.logo1?.show);

    case 'logoRight':
      return Boolean(design.visibility?.logo2 && design.logos?.logo2?.show);

    case 'companyEnglishName':
      return design.company?.showName !== false;

    case 'companyPashtoName':
      return design.company?.showPashtoName !== false;

    case 'companySlogan':
      return design.company?.showSubtitle !== false;

    case 'shapeTopLeft':
      return design.page?.showCornerDecorations !== false && design.shapes?.topLeft?.show !== false;

    case 'shapeTopRight':
      return design.page?.showCornerDecorations !== false && design.shapes?.topRight?.show !== false;

    case 'shapeGoldAccent':
      return design.shapes?.goldAccent?.show !== false;

    case 'shapeBottomLeft':
      return design.shapes?.bottomLeft?.show !== false;

    case 'shapeBottomRight':
      return design.shapes?.bottomRight?.show !== false;

    case 'invoiceTitle':
      return Boolean(design.visibility?.invoiceTitle && design.title?.show !== false);

    case 'invoiceMeta':
      return Boolean(
        design.visibility?.invoiceNumber || design.visibility?.date || design.visibility?.collector
      );

    case 'billNumber':
      return Boolean(design.visibility?.invoiceNumber && design.invoiceNumber?.show !== false);

    case 'invoiceDate':
      return Boolean(design.visibility?.date && design.date?.show !== false);

    case 'dueDate':
      return Boolean(design.date?.showDueDate);

    case 'collector':
      return Boolean(design.visibility?.collector && design.collector?.show !== false);

    case 'customerInfo':
      return Boolean(design.visibility?.customerInfo);

    case 'customerName':
      return design.customer?.showName !== false;

    case 'customerPhone':
      return design.customer?.showPhone !== false;

    case 'customerAddress':
      return design.customer?.showAddress !== false;

    case 'customerEmail':
      return design.customer?.showEmail !== false;

    case 'customerCompany':
      return design.customer?.showCompany !== false;

    case 'customerId':
      return design.customer?.showCustomerId !== false;

    case 'itemsTable':
      return Boolean(design.visibility?.itemsTable);

    case 'tableHeader':
      return design.itemsTable?.show !== false;

    case 'tableBody':
      return true;

    case 'tableColumnSerial':
      return design.itemsTable?.columns?.sNo?.show !== false;

    case 'tableColumnDescription':
      return design.itemsTable?.columns?.description?.show !== false;

    case 'tableColumnQuantity':
      return design.itemsTable?.columns?.quantity?.show !== false;

    case 'tableColumnUnit':
      return design.itemsTable?.columns?.unit?.show !== false;

    case 'tableColumnUnitPrice':
      return design.itemsTable?.columns?.unitPrice?.show !== false;

    case 'tableColumnDiscount':
      return Boolean(design.itemsTable?.columns?.discount?.show);

    case 'tableColumnTax':
      return Boolean(design.itemsTable?.columns?.tax?.show);

    case 'tableColumnTotal':
      return design.itemsTable?.columns?.totalAmount?.show !== false;

    case 'paymentInfo':
      return design.payment?.show !== false;

    case 'paymentMethod':
      return design.payment?.showMethod !== false;

    case 'paymentStatus':
      return design.payment?.showPaymentStatusBadge !== false;

    case 'paidAmount':
      return design.payment?.showPaid !== false;

    case 'remainingAmount':
      return design.payment?.showRemaining !== false;

    case 'totals':
      return Boolean(design.visibility?.total);

    case 'subtotal':
      return design.totals?.showSubtotal !== false;

    case 'discountTotal':
      return design.totals?.showDiscount !== false;

    case 'taxTotal':
      return design.totals?.showTax !== false;

    case 'grandTotal':
      return design.totals?.showGrandTotal !== false;

    case 'totalPaid':
      return Boolean(design.totals?.showTotalPaid);

    case 'remainingTotal':
      return Boolean(design.totals?.showRemaining);

    case 'paymentStatusTotal':
      return Boolean(design.visibility?.paymentStatus);

    case 'notes':
      return Boolean(design.visibility?.notes && design.notes?.showInvoiceNote);

    case 'signatures':
      return Boolean(design.visibility?.signatures);

    case 'signatureCustomer':
      return Boolean(design.signatures?.showCustomerSignature);

    case 'signatureAuthorized':
      return Boolean(design.signatures?.showManagerSignature);

    case 'footer':
      return Boolean(design.visibility?.footer && design.footer?.show);

    case 'footerThankYou':
      return design.footer?.showThankYou !== false;

    case 'footerContacts':
      return Boolean(design.visibility?.companyInfo && design.footer?.showContacts !== false);

    case 'pageNumber':
      return Boolean(design.visibility?.pageNumber && design.pageNumber?.show);

    default:
      return true;
  }
}

export function setElementVisibility(
  element: DesignerElement | string,
  visible: boolean,
  prev: InvoiceDesignSettings
): InvoiceDesignSettings {
  switch (element) {
    case 'logoLeft':
      return {
        ...prev,
        visibility: { ...prev.visibility, logo1: visible },
        logos: { ...prev.logos, logo1: { ...prev.logos.logo1, show: visible } },
      };

    case 'logoRight':
      return {
        ...prev,
        visibility: { ...prev.visibility, logo2: visible },
        logos: { ...prev.logos, logo2: { ...prev.logos.logo2, show: visible } },
      };

    case 'companyEnglishName':
      return {
        ...prev,
        company: { ...prev.company, showName: visible },
      };

    case 'companyPashtoName':
      return {
        ...prev,
        company: { ...prev.company, showPashtoName: visible },
      };

    case 'companySlogan':
      return {
        ...prev,
        company: { ...prev.company, showSubtitle: visible },
      };

    case 'shapeTopLeft':
      return {
        ...prev,
        shapes: { ...prev.shapes, topLeft: { ...prev.shapes.topLeft, show: visible } },
      };

    case 'shapeTopRight':
      return {
        ...prev,
        shapes: { ...prev.shapes, topRight: { ...prev.shapes.topRight, show: visible } },
      };

    case 'shapeGoldAccent':
      return {
        ...prev,
        shapes: { ...prev.shapes, goldAccent: { ...prev.shapes.goldAccent, show: visible } },
      };

    case 'shapeBottomLeft':
      return {
        ...prev,
        shapes: { ...prev.shapes, bottomLeft: { ...prev.shapes.bottomLeft, show: visible } },
      };

    case 'shapeBottomRight':
      return {
        ...prev,
        shapes: { ...prev.shapes, bottomRight: { ...prev.shapes.bottomRight, show: visible } },
      };

    case 'invoiceTitle':
      return {
        ...prev,
        visibility: { ...prev.visibility, invoiceTitle: visible },
        title: { ...prev.title, show: visible },
      };

    case 'invoiceMeta':
      return {
        ...prev,
        visibility: {
          ...prev.visibility,
          invoiceNumber: visible,
          date: visible,
          collector: visible,
        },
      };

    case 'billNumber':
      return {
        ...prev,
        visibility: { ...prev.visibility, invoiceNumber: visible },
        invoiceNumber: { ...prev.invoiceNumber, show: visible },
      };

    case 'invoiceDate':
      return {
        ...prev,
        visibility: { ...prev.visibility, date: visible },
        date: { ...prev.date, show: visible },
      };

    case 'dueDate':
      return {
        ...prev,
        date: { ...prev.date, showDueDate: visible },
      };

    case 'collector':
      return {
        ...prev,
        visibility: { ...prev.visibility, collector: visible },
        collector: { ...prev.collector, show: visible },
      };

    case 'customerInfo':
      return {
        ...prev,
        visibility: { ...prev.visibility, customerInfo: visible },
      };

    case 'customerName':
      return {
        ...prev,
        customer: { ...prev.customer, showName: visible },
      };

    case 'customerPhone':
      return {
        ...prev,
        customer: { ...prev.customer, showPhone: visible },
      };

    case 'customerAddress':
      return {
        ...prev,
        customer: { ...prev.customer, showAddress: visible },
      };

    case 'customerEmail':
      return {
        ...prev,
        customer: { ...prev.customer, showEmail: visible },
      };

    case 'customerCompany':
      return {
        ...prev,
        customer: { ...prev.customer, showCompany: visible },
      };

    case 'customerId':
      return {
        ...prev,
        customer: { ...prev.customer, showCustomerId: visible },
      };

    case 'itemsTable':
      return {
        ...prev,
        visibility: { ...prev.visibility, itemsTable: visible },
      };

    case 'tableHeader':
      return {
        ...prev,
        itemsTable: { ...prev.itemsTable, show: visible },
      };

    case 'tableColumnSerial':
      return {
        ...prev,
        itemsTable: {
          ...prev.itemsTable,
          columns: {
            ...prev.itemsTable.columns,
            sNo: { ...prev.itemsTable.columns.sNo, show: visible },
          },
        },
      };

    case 'tableColumnDescription':
      return {
        ...prev,
        itemsTable: {
          ...prev.itemsTable,
          columns: {
            ...prev.itemsTable.columns,
            description: { ...prev.itemsTable.columns.description, show: visible },
          },
        },
      };

    case 'tableColumnQuantity':
      return {
        ...prev,
        itemsTable: {
          ...prev.itemsTable,
          columns: {
            ...prev.itemsTable.columns,
            quantity: { ...prev.itemsTable.columns.quantity, show: visible },
          },
        },
      };

    case 'tableColumnUnit':
      return {
        ...prev,
        itemsTable: {
          ...prev.itemsTable,
          columns: {
            ...prev.itemsTable.columns,
            unit: { ...prev.itemsTable.columns.unit, show: visible },
          },
        },
      };

    case 'tableColumnUnitPrice':
      return {
        ...prev,
        itemsTable: {
          ...prev.itemsTable,
          columns: {
            ...prev.itemsTable.columns,
            unitPrice: { ...prev.itemsTable.columns.unitPrice, show: visible },
          },
        },
      };

    case 'tableColumnDiscount':
      return {
        ...prev,
        itemsTable: {
          ...prev.itemsTable,
          columns: {
            ...prev.itemsTable.columns,
            discount: { ...prev.itemsTable.columns.discount, show: visible },
          },
        },
      };

    case 'tableColumnTax':
      return {
        ...prev,
        itemsTable: {
          ...prev.itemsTable,
          columns: {
            ...prev.itemsTable.columns,
            tax: { ...prev.itemsTable.columns.tax, show: visible },
          },
        },
      };

    case 'tableColumnTotal':
      return {
        ...prev,
        itemsTable: {
          ...prev.itemsTable,
          columns: {
            ...prev.itemsTable.columns,
            totalAmount: { ...prev.itemsTable.columns.totalAmount, show: visible },
          },
        },
      };

    case 'paymentInfo':
      return {
        ...prev,
        payment: { ...prev.payment, show: visible },
      };

    case 'paymentMethod':
      return {
        ...prev,
        payment: { ...prev.payment, showMethod: visible },
      };

    case 'paymentStatus':
      return {
        ...prev,
        payment: { ...prev.payment, showPaymentStatusBadge: visible },
      };

    case 'paidAmount':
      return {
        ...prev,
        payment: { ...prev.payment, showPaid: visible },
      };

    case 'remainingAmount':
      return {
        ...prev,
        payment: { ...prev.payment, showRemaining: visible },
      };

    case 'totals':
      return {
        ...prev,
        visibility: { ...prev.visibility, total: visible },
      };

    case 'subtotal':
      return {
        ...prev,
        visibility: { ...prev.visibility, subtotal: visible },
        totals: { ...prev.totals, showSubtotal: visible },
      };

    case 'discountTotal':
      return {
        ...prev,
        visibility: { ...prev.visibility, discount: visible },
        totals: { ...prev.totals, showDiscount: visible },
      };

    case 'taxTotal':
      return {
        ...prev,
        visibility: { ...prev.visibility, tax: visible },
        totals: { ...prev.totals, showTax: visible },
      };

    case 'grandTotal':
      return {
        ...prev,
        totals: { ...prev.totals, showGrandTotal: visible },
      };

    case 'totalPaid':
      return {
        ...prev,
        visibility: { ...prev.visibility, paid: visible },
        totals: { ...prev.totals, showTotalPaid: visible },
      };

    case 'remainingTotal':
      return {
        ...prev,
        visibility: { ...prev.visibility, remaining: visible },
        totals: { ...prev.totals, showRemaining: visible },
      };

    case 'paymentStatusTotal':
      return {
        ...prev,
        visibility: { ...prev.visibility, paymentStatus: visible },
      };

    case 'notes':
      return {
        ...prev,
        visibility: { ...prev.visibility, notes: visible },
        notes: { ...prev.notes, showInvoiceNote: visible },
      };

    case 'signatures':
      return {
        ...prev,
        visibility: { ...prev.visibility, signatures: visible },
      };

    case 'signatureCustomer':
      return {
        ...prev,
        signatures: { ...prev.signatures, showCustomerSignature: visible },
      };

    case 'signatureAuthorized':
      return {
        ...prev,
        signatures: { ...prev.signatures, showManagerSignature: visible },
      };

    case 'footer':
      return {
        ...prev,
        visibility: { ...prev.visibility, footer: visible },
        footer: { ...prev.footer, show: visible },
      };

    case 'footerThankYou':
      return {
        ...prev,
        footer: { ...prev.footer, showThankYou: visible },
      };

    case 'footerContacts':
      return {
        ...prev,
        visibility: { ...prev.visibility, companyInfo: visible },
        footer: { ...prev.footer, showContacts: visible },
      };

    case 'pageNumber':
      return {
        ...prev,
        visibility: { ...prev.visibility, pageNumber: visible },
        pageNumber: { ...prev.pageNumber, show: visible },
      };

    default:
      return prev;
  }
}

/**
 * Migration helper during load:
 * Reconciles any legacy saved designs where duplicate properties might have diverged,
 * ensuring seamless backward compatibility without losing existing user settings.
 */
export function migrateLegacyVisibility(saved: Partial<InvoiceDesignSettings>): Partial<InvoiceDesignSettings> {
  const result = { ...saved };
  const vis = { ...(result.visibility || {}) };

  const resolveVisibility = (valA?: boolean, valB?: boolean): boolean => {
    if (valA === false || valB === false) return false;
    if (valA === true || valB === true) return true;
    return true;
  };

  // Reconcile logo1
  if (saved.logos?.logo1?.show !== undefined || vis.logo1 !== undefined) {
    const isShown = resolveVisibility(saved.logos?.logo1?.show, vis.logo1);
    vis.logo1 = isShown;
    if (result.logos?.logo1) {
      result.logos.logo1.show = isShown;
    }
  }

  // Reconcile logo2
  if (saved.logos?.logo2?.show !== undefined || vis.logo2 !== undefined) {
    const isShown = resolveVisibility(saved.logos?.logo2?.show, vis.logo2);
    vis.logo2 = isShown;
    if (result.logos?.logo2) {
      result.logos.logo2.show = isShown;
    }
  }

  // Reconcile billNumber / invoiceNumber
  if (saved.invoiceNumber?.show !== undefined || vis.invoiceNumber !== undefined) {
    const isShown = resolveVisibility(saved.invoiceNumber?.show, vis.invoiceNumber);
    vis.invoiceNumber = isShown;
    if (result.invoiceNumber) {
      result.invoiceNumber.show = isShown;
    }
  }

  // Reconcile invoiceDate
  if (saved.date?.show !== undefined || vis.date !== undefined) {
    const isShown = resolveVisibility(saved.date?.show, vis.date);
    vis.date = isShown;
    if (result.date) {
      result.date.show = isShown;
    }
  }

  // Reconcile collector
  if (saved.collector?.show !== undefined || vis.collector !== undefined) {
    const isShown = resolveVisibility(saved.collector?.show, vis.collector);
    vis.collector = isShown;
    if (result.collector) {
      result.collector.show = isShown;
    }
  }

  // Reconcile notes
  if (saved.notes?.showInvoiceNote !== undefined || vis.notes !== undefined) {
    const isShown = resolveVisibility(saved.notes?.showInvoiceNote, vis.notes);
    vis.notes = isShown;
    if (result.notes) {
      result.notes.showInvoiceNote = isShown;
    }
  }

  // Reconcile pageNumber
  if (saved.pageNumber?.show !== undefined || vis.pageNumber !== undefined) {
    const isShown = resolveVisibility(saved.pageNumber?.show, vis.pageNumber);
    vis.pageNumber = isShown;
    if (result.pageNumber) {
      result.pageNumber.show = isShown;
    }
  }

  // Reconcile footer
  if (saved.footer?.show !== undefined || vis.footer !== undefined) {
    const isShown = resolveVisibility(saved.footer?.show, vis.footer);
    vis.footer = isShown;
    if (result.footer) {
      result.footer.show = isShown;
    }
  }

  // Reconcile companyInfo / footerContacts
  if (saved.footer?.showContacts !== undefined || vis.companyInfo !== undefined) {
    const isShown = resolveVisibility(saved.footer?.showContacts, vis.companyInfo);
    vis.companyInfo = isShown;
    if (result.footer) {
      result.footer.showContacts = isShown;
    }
  }

  result.visibility = vis as any;
  return result;
}

/**
 * Migration helper for section spacing:
 * Normalizes legacy duplicate/alias spacing properties into the 8 canonical gap keys,
 * while preserving the default visual spacing.
 */
export function migrateLegacySpacing(savedSpacing: any): InvoiceDesignSettings['spacing'] {
  const s = savedSpacing || {};
  const defaults = DEFAULT_INVOICE_DESIGN.spacing;

  const headerToMeta = s.headerToMeta ?? s.metaSpacing ?? s.headerSpacing ?? defaults.headerToMeta ?? 8;
  const metaToCustomer = s.metaToCustomer ?? s.metaToCustomerSpacing ?? s.customerSpacing ?? defaults.metaToCustomer ?? 8;
  const customerToTable = s.customerToTable ?? s.customerToTableSpacing ?? s.tableSpacing ?? defaults.customerToTable ?? 8;
  const tableToPayment = s.tableToPayment ?? s.tableToPaymentSpacing ?? s.paymentSpacing ?? defaults.tableToPayment ?? 10;
  const paymentToTotals = s.paymentToTotals ?? s.paymentToTotalsSpacing ?? defaults.paymentToTotals ?? 16;
  const totalsToNotes = s.totalsToNotes ?? s.totalsToNotesSpacing ?? s.totalsSpacing ?? defaults.totalsToNotes ?? 10;
  const notesToSignatures = s.notesToSignatures ?? s.notesToSignaturesSpacing ?? s.sectionSpacing ?? defaults.notesToSignatures ?? 10;
  const footerSpacing = s.footerSpacing ?? defaults.footerSpacing ?? 8;

  return {
    ...defaults,
    ...s,
    headerToMeta,
    metaToCustomer,
    customerToTable,
    tableToPayment,
    paymentToTotals,
    totalsToNotes,
    notesToSignatures,
    footerSpacing,
    // Keep backward-compatible properties synchronized
    headerSpacing: headerToMeta,
    customerSpacing: metaToCustomer,
    tableSpacing: customerToTable,
    paymentSpacing: tableToPayment,
    totalsSpacing: totalsToNotes,
  };
}
