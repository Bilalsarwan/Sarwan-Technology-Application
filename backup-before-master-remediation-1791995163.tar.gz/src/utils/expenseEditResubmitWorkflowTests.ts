import assert from 'node:assert';
import { Expense, ExpenseTimelineEntry, ExpenseRevision, UserProfile } from '../types';
import { calculateInvoiceProfitSummary } from './purchaseCostCalculator';

/**
 * ===========================================================================
 * SARWAN TECHNOLOGY BILLING SYSTEM
 * COMPREHENSIVE TEST SUITE: EXPENSE EDIT & RESUBMIT WORKFLOW (MODE A)
 * ===========================================================================
 * 
 * Verifies all specifications for the Edit & Resubmit workflow for rejected expenses:
 * 1. Resubmission Mode A (Edit & Resubmit) with revised amount, date, title, category, notes
 * 2. Mandatory resubmission note (corrections explanation required, min 3 chars)
 * 3. Immutable audit history: rejection record and revisions preserved; revision incremented
 * 4. Ownership authorization: only original requester can edit & resubmit; Super Admin blocked
 * 5. Approval routing: Collector -> pending_manager; Manager -> pending_admin
 * 6. Clean approval reset: previous manager and admin approvals wiped for revised request
 * 7. Invoice binding immutability: cannot reassign expense to different invoice
 * 8. Financial profit isolation: pending resubmitted expenses contribute 0 AFN until approved
 */

console.log('===========================================================================');
console.log('SARWAN TECHNOLOGY: EXPENSE EDIT & RESUBMIT WORKFLOW TESTS');
console.log('===========================================================================\n');

let totalTests = 0;
let passedTests = 0;

function it(desc: string, fn: () => void) {
  totalTests++;
  try {
    fn();
    passedTests++;
    console.log(`  ✓ PASS: ${desc}`);
  } catch (err: any) {
    console.error(`  ✗ FAIL: ${desc}`);
    console.error(`    Error: ${err?.message || err}`);
    throw err;
  }
}

// Workflow simulation engine following db.ts advanceExpenseWorkflow & resubmitRejectedExpense logic
function simulateEditAndResubmit(params: {
  existingExpense: Expense;
  actor: { userId: string; userName: string; userRole: string; userJobTitle?: string };
  title: string;
  amount: number;
  date: string;
  category?: string;
  note?: string;
  corrections: string;
  invoiceId: string;
  billNumber?: string;
}): Expense {
  const { existingExpense, actor, title, amount, date, category, note, corrections, invoiceId } = params;

  // 1. Role validation
  if (actor.userRole === 'customer') {
    throw new Error('Access Denied: Customers cannot create or edit expenses.');
  }
  if (actor.userRole === 'super_admin') {
    throw new Error('Access Denied: Super Admin cannot resubmit expense requests.');
  }

  // 2. State & Ownership validation
  if (existingExpense.status !== 'rejected') {
    throw new Error('Only rejected expenses can be resubmitted.');
  }

  const isOwner =
    existingExpense.requestedBy &&
    actor.userId &&
    existingExpense.requestedBy.toLowerCase() === actor.userId.toLowerCase();
  if (!isOwner) {
    throw new Error('Access Denied: Only the original authorized requester can edit and resubmit their rejected expense request.');
  }

  // 3. Resubmission note requirement (MANDATORY)
  const cleanCorrections = (corrections || '').trim();
  if (!cleanCorrections || cleanCorrections.length < 3) {
    throw new Error('A resubmission note explaining corrections (at least 3 characters) is required to resubmit a rejected expense.');
  }

  // 4. Data validation
  if (!title || !title.trim()) {
    throw new Error('Expense description is required.');
  }
  const numAmount = Number(amount);
  if (!Number.isFinite(numAmount) || numAmount <= 0) {
    throw new Error('Expense amount must be a positive number.');
  }
  if (!date) {
    throw new Error('Expense date is required.');
  }

  // 5. Immutable invoice association check
  if (existingExpense.invoiceId && existingExpense.invoiceId !== invoiceId) {
    throw new Error(`Access Denied: Expense belongs to invoice "${existingExpense.invoiceId}" and cannot be reassigned to invoice "${invoiceId}".`);
  }

  const now = new Date().toISOString();

  // 6. Routing calculation
  let nextStatus: 'pending_manager' | 'pending_admin' = 'pending_manager';
  if (existingExpense.requestedByRole === 'payment_collector') {
    nextStatus = 'pending_manager';
  } else if (existingExpense.requestedByRole === 'invoice_manager') {
    nextStatus = 'pending_admin';
  } else {
    nextStatus = 'pending_admin';
  }

  // 7. Preserve previous rejected revision in revisions array
  const previousRev: ExpenseRevision = {
    revisionNumber: existingExpense.revision || 1,
    title: existingExpense.title,
    amount: existingExpense.amount,
    date: existingExpense.date,
    category: existingExpense.category || 'General Operations',
    note: existingExpense.note || '',
    status: 'rejected',
    rejectionReason: existingExpense.rejectionReason || '',
    rejectedBy: existingExpense.rejectedBy,
    rejectedByName: existingExpense.rejectedByName,
    rejectedByJobTitle: existingExpense.rejectedByJobTitle,
    rejectedAt: existingExpense.rejectedAt,
    timestamp: now,
    corrections: cleanCorrections,
    correctionDescription: cleanCorrections,
  };

  const newRevisionNumber = (existingExpense.revision || 1) + 1;

  // 8. New timeline entry
  const newTimelineEntry: ExpenseTimelineEntry = {
    action: 'Expense Request Resubmitted',
    performedBy: actor.userId,
    performedByName: actor.userName,
    performedByRole: actor.userRole,
    performedByJobTitle: actor.userJobTitle,
    timestamp: now,
    note: cleanCorrections,
    corrections: cleanCorrections,
    correctionDescription: cleanCorrections,
    revision: newRevisionNumber,
    status: 'resubmitted',
  };

  // 9. Construct revised expense with reset approvals
  const updatedExpense: Expense = {
    ...existingExpense,
    title: title.trim(),
    description: title.trim(),
    amount: numAmount,
    date,
    expenseDate: date,
    category: category || 'General Operations',
    note: note?.trim() || '',
    status: nextStatus,
    revision: newRevisionNumber,
    revisions: [...(existingExpense.revisions || []), previousRev],
    resubmissionReason: cleanCorrections,
    resubmissionCorrections: cleanCorrections,
    resubmittedBy: actor.userId,
    resubmittedByName: actor.userName,
    resubmittedByJobTitle: actor.userJobTitle,
    resubmittedAt: now,
    updatedAt: now,
    timeline: [...(existingExpense.timeline || []), newTimelineEntry],
    approvalHistory: [...(existingExpense.timeline || []), newTimelineEntry],
  };

  // Clear previous approvals
  delete updatedExpense.managerApprovedBy;
  delete updatedExpense.managerApprovedByName;
  delete updatedExpense.managerApprovedAt;
  delete updatedExpense.adminApprovedBy;
  delete updatedExpense.adminApprovedByName;
  delete updatedExpense.adminApprovedAt;
  // Clear active rejection fields (they are preserved in previousRev and timeline)
  delete updatedExpense.rejectionReason;
  delete updatedExpense.rejectedBy;
  delete updatedExpense.rejectedByName;
  delete updatedExpense.rejectedAt;

  return updatedExpense;
}

// --- SETUP BASE ENTITIES ---
const invoiceId = 'inv-test-resubmit-001';
const billNumber = 'BILL-2026-9901';

const collectorUser = {
  userId: 'user-collector-01',
  userName: 'Jamal Collector',
  userRole: 'payment_collector',
  userJobTitle: 'Field Payment Collector',
};

const managerUser = {
  userId: 'user-manager-01',
  userName: 'Nadia Manager',
  userRole: 'invoice_manager',
  userJobTitle: 'Senior Billing Manager',
};

const adminUser = {
  userId: 'user-admin-01',
  userName: 'Sarwan Admin',
  userRole: 'super_admin',
  userJobTitle: 'Chief Executive Administrator',
};

const intruderUser = {
  userId: 'user-intruder-02',
  userName: 'Hamid Intruder',
  userRole: 'payment_collector',
  userJobTitle: 'Collector',
};

// Create an initial Collector rejected expense
const initialCollectorRejectedExpense: Expense = {
  id: 'exp-col-101',
  invoiceId,
  billNumber,
  title: 'Network Cabling for Tower 4',
  amount: 2500,
  date: '2026-10-10',
  category: 'Materials & Supplies',
  note: 'Installed 50m Cat6 cable',
  requestedBy: collectorUser.userId,
  requestedByName: collectorUser.userName,
  requestedByRole: collectorUser.userRole,
  status: 'rejected',
  revision: 1,
  rejectionReason: 'Missing official supplier receipt stamped by vendor',
  rejectedBy: managerUser.userId,
  rejectedByName: managerUser.userName,
  rejectedByJobTitle: managerUser.userJobTitle,
  rejectedAt: '2026-10-11T10:00:00Z',
  createdAt: '2026-10-10T08:00:00Z',
  timeline: [
    {
      action: 'Expense Request Submitted',
      performedBy: collectorUser.userId,
      performedByName: collectorUser.userName,
      performedByRole: collectorUser.userRole,
      timestamp: '2026-10-10T08:00:00Z',
      status: 'submitted',
      revision: 1,
    },
    {
      action: 'Expense Request Rejected',
      performedBy: managerUser.userId,
      performedByName: managerUser.userName,
      performedByRole: managerUser.userRole,
      timestamp: '2026-10-11T10:00:00Z',
      rejectionReason: 'Missing official supplier receipt stamped by vendor',
      status: 'rejected',
      revision: 1,
    },
  ],
};

// Create an initial Manager rejected expense (rejected by Super Admin)
const initialManagerRejectedExpense: Expense = {
  id: 'exp-mgr-201',
  invoiceId,
  billNumber,
  title: 'Main Server Rack Power Supply',
  amount: 14000,
  date: '2026-10-11',
  category: 'Hardware',
  note: 'Emergency redundant PSU unit',
  requestedBy: managerUser.userId,
  requestedByName: managerUser.userName,
  requestedByRole: managerUser.userRole,
  status: 'rejected',
  revision: 1,
  rejectionReason: 'Price exceeds threshold; requires 2 competitor quotations attached',
  rejectedBy: adminUser.userId,
  rejectedByName: adminUser.userName,
  rejectedByJobTitle: adminUser.userJobTitle,
  rejectedAt: '2026-10-12T11:00:00Z',
  createdAt: '2026-10-11T09:00:00Z',
  timeline: [
    {
      action: 'Expense Request Submitted',
      performedBy: managerUser.userId,
      performedByName: managerUser.userName,
      performedByRole: managerUser.userRole,
      timestamp: '2026-10-11T09:00:00Z',
      status: 'submitted',
      revision: 1,
    },
    {
      action: 'Expense Request Rejected',
      performedBy: adminUser.userId,
      performedByName: adminUser.userName,
      performedByRole: adminUser.userRole,
      timestamp: '2026-10-12T11:00:00Z',
      rejectionReason: 'Price exceeds threshold; requires 2 competitor quotations attached',
      status: 'rejected',
      revision: 1,
    },
  ],
};

// ===========================================================================
// SECTION 1: MANDATORY RESUBMISSION NOTE VALIDATION
// ===========================================================================
console.log('--- 1. MANDATORY RESUBMISSION NOTE VALIDATION ---');

it('Rejects resubmission when corrections note is an empty string', () => {
  assert.throws(
    () => {
      simulateEditAndResubmit({
        existingExpense: initialCollectorRejectedExpense,
        actor: collectorUser,
        title: 'Network Cabling for Tower 4',
        amount: 2500,
        date: '2026-10-10',
        corrections: '',
        invoiceId,
      });
    },
    (err: any) => err.message.includes('A resubmission note explaining corrections')
  );
});

it('Rejects resubmission when corrections note consists only of whitespace', () => {
  assert.throws(
    () => {
      simulateEditAndResubmit({
        existingExpense: initialCollectorRejectedExpense,
        actor: collectorUser,
        title: 'Network Cabling for Tower 4',
        amount: 2500,
        date: '2026-10-10',
        corrections: '     ',
        invoiceId,
      });
    },
    (err: any) => err.message.includes('A resubmission note explaining corrections')
  );
});

it('Rejects resubmission when corrections note is less than 3 characters', () => {
  assert.throws(
    () => {
      simulateEditAndResubmit({
        existingExpense: initialCollectorRejectedExpense,
        actor: collectorUser,
        title: 'Network Cabling for Tower 4',
        amount: 2500,
        date: '2026-10-10',
        corrections: 'ok',
        invoiceId,
      });
    },
    (err: any) => err.message.includes('at least 3 characters')
  );
});

it('Accepts resubmission when a meaningful corrections note (>= 3 chars) is provided', () => {
  const result = simulateEditAndResubmit({
    existingExpense: initialCollectorRejectedExpense,
    actor: collectorUser,
    title: 'Network Cabling for Tower 4 - Corrected',
    amount: 2400,
    date: '2026-10-10',
    corrections: 'Attached officially stamped vendor receipt #AF-9921',
    invoiceId,
  });
  assert.strictEqual(result.resubmissionCorrections, 'Attached officially stamped vendor receipt #AF-9921');
  assert.strictEqual(result.amount, 2400);
});

// ===========================================================================
// SECTION 2: OWNERSHIP & AUTHORIZATION GUARDRAILS
// ===========================================================================
console.log('\n--- 2. OWNERSHIP & AUTHORIZATION GUARDRAILS ---');

it('Blocks non-requester Payment Collector from editing & resubmitting another user request', () => {
  assert.throws(
    () => {
      simulateEditAndResubmit({
        existingExpense: initialCollectorRejectedExpense,
        actor: intruderUser, // different collector
        title: 'Network Cabling for Tower 4',
        amount: 2500,
        date: '2026-10-10',
        corrections: 'Trying to resubmit someone else request',
        invoiceId,
      });
    },
    (err: any) => err.message.includes('Only the original authorized requester can edit and resubmit')
  );
});

it('Blocks non-requester Invoice Manager from resubmitting a collector request', () => {
  assert.throws(
    () => {
      simulateEditAndResubmit({
        existingExpense: initialCollectorRejectedExpense,
        actor: managerUser, // manager did not create this collector request
        title: 'Network Cabling for Tower 4',
        amount: 2500,
        date: '2026-10-10',
        corrections: 'Manager trying to resubmit collector request',
        invoiceId,
      });
    },
    (err: any) => err.message.includes('Only the original authorized requester can edit and resubmit')
  );
});

it('Super Admin cannot resubmit expense requests', () => {
  assert.throws(
    () => {
      simulateEditAndResubmit({
        existingExpense: initialCollectorRejectedExpense,
        actor: adminUser,
        title: 'Network Cabling for Tower 4',
        amount: 2500,
        date: '2026-10-10',
        corrections: 'Admin trying to resubmit',
        invoiceId,
      });
    },
    (err: any) => err.message.includes('Super Admin cannot resubmit expense requests')
  );
});

it('Customer account is strictly blocked from editing or resubmitting', () => {
  assert.throws(
    () => {
      simulateEditAndResubmit({
        existingExpense: initialCollectorRejectedExpense,
        actor: { userId: 'cust-99', userName: 'Client', userRole: 'customer' },
        title: 'Network Cabling for Tower 4',
        amount: 2500,
        date: '2026-10-10',
        corrections: 'Customer attempt',
        invoiceId,
      });
    },
    (err: any) => err.message.includes('Customers cannot create or edit expenses')
  );
});

it('Non-rejected expense (e.g. pending_manager or approved) cannot be resubmitted', () => {
  const pendingExpense: Expense = {
    ...initialCollectorRejectedExpense,
    status: 'pending_manager',
  };
  assert.throws(
    () => {
      simulateEditAndResubmit({
        existingExpense: pendingExpense,
        actor: collectorUser,
        title: 'Network Cabling for Tower 4',
        amount: 2500,
        date: '2026-10-10',
        corrections: 'Resubmitting while pending',
        invoiceId,
      });
    },
    (err: any) => err.message.includes('Only rejected expenses can be resubmitted')
  );
});

// ===========================================================================
// SECTION 3: APPROVAL ROUTING LOGIC BY ROLE
// ===========================================================================
console.log('\n--- 3. APPROVAL ROUTING LOGIC BY ROLE ---');

it('Resubmitted Payment Collector expense routes strictly to pending_manager', () => {
  const resubmitted = simulateEditAndResubmit({
    existingExpense: initialCollectorRejectedExpense,
    actor: collectorUser,
    title: 'Network Cabling for Tower 4 (Revision)',
    amount: 2300,
    date: '2026-10-10',
    corrections: 'Added official stamped store bill and serial numbers',
    invoiceId,
  });
  assert.strictEqual(resubmitted.status, 'pending_manager', 'Collector resubmission MUST return to pending_manager');
  assert.strictEqual(resubmitted.managerApprovedBy, undefined, 'Previous manager approval must be cleared');
  assert.strictEqual(resubmitted.adminApprovedBy, undefined, 'Previous admin approval must be cleared');
});

it('Resubmitted Invoice Manager expense routes strictly to pending_admin', () => {
  const resubmitted = simulateEditAndResubmit({
    existingExpense: initialManagerRejectedExpense,
    actor: managerUser,
    title: 'Main Server Rack Power Supply (Adjusted)',
    amount: 12500, // lowered amount
    date: '2026-10-11',
    corrections: 'Negotiated discount and attached 2 competitor supplier quotations',
    invoiceId,
  });
  assert.strictEqual(resubmitted.status, 'pending_admin', 'Manager resubmission MUST return to pending_admin');
  assert.strictEqual(resubmitted.adminApprovedBy, undefined, 'Previous admin approval must be cleared');
});

// ===========================================================================
// SECTION 4: IMMUTABLE AUDIT TRAIL & REVISION PRESERVATION
// ===========================================================================
console.log('\n--- 4. IMMUTABLE AUDIT TRAIL & REVISION PRESERVATION ---');

it('Increments revision counter from 1 to 2 upon resubmission', () => {
  const resubmitted = simulateEditAndResubmit({
    existingExpense: initialCollectorRejectedExpense,
    actor: collectorUser,
    title: 'Network Cabling for Tower 4',
    amount: 2400,
    date: '2026-10-10',
    corrections: 'Corrected supplier documentation',
    invoiceId,
  });
  assert.strictEqual(resubmitted.revision, 2, 'Revision counter must be incremented to 2');
});

it('Preserves previous rejected revision details in revisions array', () => {
  const resubmitted = simulateEditAndResubmit({
    existingExpense: initialCollectorRejectedExpense,
    actor: collectorUser,
    title: 'Network Cabling for Tower 4',
    amount: 2400,
    date: '2026-10-10',
    corrections: 'Corrected supplier documentation',
    invoiceId,
  });
  assert.strictEqual(resubmitted.revisions?.length, 1, 'Revisions array must contain 1 archived revision');
  const rev1 = resubmitted.revisions![0];
  assert.strictEqual(rev1.revisionNumber, 1);
  assert.strictEqual(rev1.amount, 2500);
  assert.strictEqual(rev1.status, 'rejected');
  assert.strictEqual(rev1.rejectionReason, 'Missing official supplier receipt stamped by vendor');
  assert.strictEqual(rev1.rejectedBy, managerUser.userId);
  assert.strictEqual(rev1.rejectedByName, managerUser.userName);
});

it('Appends a new timeline entry with status "resubmitted" and exact correction details', () => {
  const resubmitted = simulateEditAndResubmit({
    existingExpense: initialCollectorRejectedExpense,
    actor: collectorUser,
    title: 'Network Cabling for Tower 4',
    amount: 2400,
    date: '2026-10-10',
    corrections: 'Attached officially stamped vendor receipt #AF-9921',
    invoiceId,
  });
  assert.strictEqual(resubmitted.timeline?.length, 3, 'Timeline must contain submission, rejection, and resubmission');
  const resubmitEntry = resubmitted.timeline![2];
  assert.strictEqual(resubmitEntry.action, 'Expense Request Resubmitted');
  assert.strictEqual(resubmitEntry.status, 'resubmitted');
  assert.strictEqual(resubmitEntry.performedBy, collectorUser.userId);
  assert.strictEqual(resubmitEntry.performedByName, collectorUser.userName);
  assert.strictEqual(resubmitEntry.corrections, 'Attached officially stamped vendor receipt #AF-9921');
  assert.strictEqual(resubmitEntry.revision, 2);
});

it('Supports multiple rejection and resubmission cycles (Revision 1 -> 2 -> 3)', () => {
  // Cycle 1: Revision 1 rejected -> resubmit to Revision 2
  const rev2 = simulateEditAndResubmit({
    existingExpense: initialCollectorRejectedExpense,
    actor: collectorUser,
    title: 'Network Cabling for Tower 4',
    amount: 2400,
    date: '2026-10-10',
    corrections: 'Cycle 1 corrections',
    invoiceId,
  });

  // Manager rejects Revision 2
  const rev2Rejected: Expense = {
    ...rev2,
    status: 'rejected',
    rejectionReason: 'Vendor stamp is blurry; please upload clear PDF scan',
    rejectedBy: managerUser.userId,
    rejectedByName: managerUser.userName,
    rejectedAt: '2026-10-12T14:00:00Z',
    timeline: [
      ...rev2.timeline!,
      {
        action: 'Expense Request Rejected',
        performedBy: managerUser.userId,
        performedByName: managerUser.userName,
        performedByRole: managerUser.userRole,
        timestamp: '2026-10-12T14:00:00Z',
        rejectionReason: 'Vendor stamp is blurry; please upload clear PDF scan',
        status: 'rejected',
        revision: 2,
      },
    ],
  };

  // Cycle 2: Revision 2 rejected -> resubmit to Revision 3
  const rev3 = simulateEditAndResubmit({
    existingExpense: rev2Rejected,
    actor: collectorUser,
    title: 'Network Cabling for Tower 4',
    amount: 2350,
    date: '2026-10-10',
    corrections: 'Re-uploaded crystal clear high-res PDF scan of stamped bill',
    invoiceId,
  });

  assert.strictEqual(rev3.revision, 3, 'Revision counter must be 3');
  assert.strictEqual(rev3.revisions?.length, 2, 'Should preserve both Revision 1 and Revision 2 in history');
  assert.strictEqual(rev3.revisions![0].revisionNumber, 1);
  assert.strictEqual(rev3.revisions![1].revisionNumber, 2);
  assert.strictEqual(rev3.revisions![1].rejectionReason, 'Vendor stamp is blurry; please upload clear PDF scan');
  assert.strictEqual(rev3.timeline?.length, 5, 'Timeline preserves all 5 lifecycle events');
});

// ===========================================================================
// SECTION 5: IMMUTABLE INVOICE ASSOCIATION & DATA INTEGRITY
// ===========================================================================
console.log('\n--- 5. IMMUTABLE INVOICE ASSOCIATION & DATA INTEGRITY ---');

it('Strictly rejects attempting to move a rejected expense to a different invoice', () => {
  assert.throws(
    () => {
      simulateEditAndResubmit({
        existingExpense: initialCollectorRejectedExpense,
        actor: collectorUser,
        title: 'Network Cabling for Tower 4',
        amount: 2400,
        date: '2026-10-10',
        corrections: 'Trying to reassign',
        invoiceId: 'inv-different-invoice-999', // Mismatched invoice ID
      });
    },
    (err: any) => err.message.includes('cannot be reassigned to invoice')
  );
});

it('Rejects non-positive amounts during edit and resubmit', () => {
  assert.throws(
    () => {
      simulateEditAndResubmit({
        existingExpense: initialCollectorRejectedExpense,
        actor: collectorUser,
        title: 'Network Cabling for Tower 4',
        amount: 0,
        date: '2026-10-10',
        corrections: 'Amount set to 0',
        invoiceId,
      });
    },
    (err: any) => err.message.includes('Expense amount must be a positive number')
  );

  assert.throws(
    () => {
      simulateEditAndResubmit({
        existingExpense: initialCollectorRejectedExpense,
        actor: collectorUser,
        title: 'Network Cabling for Tower 4',
        amount: -500,
        date: '2026-10-10',
        corrections: 'Negative amount',
        invoiceId,
      });
    },
    (err: any) => err.message.includes('Expense amount must be a positive number')
  );
});

it('Rejects empty description / title during edit and resubmit', () => {
  assert.throws(
    () => {
      simulateEditAndResubmit({
        existingExpense: initialCollectorRejectedExpense,
        actor: collectorUser,
        title: '   ',
        amount: 2500,
        date: '2026-10-10',
        corrections: 'No description provided',
        invoiceId,
      });
    },
    (err: any) => err.message.includes('Expense description is required')
  );
});

// ===========================================================================
// SECTION 6: FINANCIAL ISOLATION & PROFIT CALCULATION INVARIANCE
// ===========================================================================
console.log('\n--- 6. FINANCIAL ISOLATION & PROFIT CALCULATION INVARIANCE ---');

it('Rejected expense has 0 AFN impact on net profit', () => {
  const dummyItems: any[] = [
    { id: 'item-1', description: 'Service', quantity: 1, unitPrice: 50000, purchaseCost: 30000 },
  ];
  const summaryBefore = calculateInvoiceProfitSummary(dummyItems, [initialCollectorRejectedExpense], invoiceId);
  assert.strictEqual(summaryBefore.totalExpenses, 0, 'Rejected expense must contribute 0 to totalExpenses');
  assert.strictEqual(summaryBefore.netProfit, 20000, 'Net profit equals gross profit (50k - 30k = 20k)');
});

it('Resubmitted expense in pending_manager status still has 0 AFN impact on net profit', () => {
  const resubmitted = simulateEditAndResubmit({
    existingExpense: initialCollectorRejectedExpense,
    actor: collectorUser,
    title: 'Network Cabling for Tower 4',
    amount: 2400,
    date: '2026-10-10',
    corrections: 'Attached officially stamped vendor receipt #AF-9921',
    invoiceId,
  });

  const dummyItems: any[] = [
    { id: 'item-1', description: 'Service', quantity: 1, unitPrice: 50000, purchaseCost: 30000 },
  ];
  const summaryPending = calculateInvoiceProfitSummary(dummyItems, [resubmitted], invoiceId);
  assert.strictEqual(summaryPending.totalExpenses, 0, 'Pending resubmitted expense must contribute 0 until approved');
  assert.strictEqual(summaryPending.netProfit, 20000, 'Net profit remains 20,000 AFN while pending review');
});

it('Once approved, only the revised amount (2,400 AFN) is deducted without duplicating', () => {
  const resubmitted = simulateEditAndResubmit({
    existingExpense: initialCollectorRejectedExpense,
    actor: collectorUser,
    title: 'Network Cabling for Tower 4',
    amount: 2400,
    date: '2026-10-10',
    corrections: 'Attached officially stamped vendor receipt #AF-9921',
    invoiceId,
  });

  // Transition to approved
  const approvedResubmitted: Expense = {
    ...resubmitted,
    status: 'approved',
    managerApprovedBy: managerUser.userId,
    adminApprovedBy: adminUser.userId,
  };

  const dummyItems: any[] = [
    { id: 'item-1', description: 'Service', quantity: 1, unitPrice: 50000, purchaseCost: 30000 },
  ];
  const summaryApproved = calculateInvoiceProfitSummary(dummyItems, [approvedResubmitted], invoiceId);
  assert.strictEqual(summaryApproved.totalExpenses, 2400, 'Only the revised amount is counted');
  assert.strictEqual(summaryApproved.netProfit, 17600, 'Net profit = 20,000 - 2,400 = 17,600 AFN');
});

console.log('\n===========================================================================');
console.log(`TOTAL TESTS: ${totalTests} | PASSED: ${passedTests} | FAILED: ${totalTests - passedTests}`);
console.log('ALL EXPENSE EDIT & RESUBMIT WORKFLOW TESTS PASSED! ✓');
console.log('===========================================================================');
