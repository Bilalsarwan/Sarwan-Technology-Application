import {
  CanonicalInvoiceItem,
  CanonicalInvoicePage,
  CanonicalInvoiceDocumentModel,
} from '../types/canonicalInvoiceDocument';
import { InvoiceDesignSettings, DEFAULT_INVOICE_DESIGN } from '../types/invoiceDesign';
import { InvoicePaperConfig } from './invoicePaperConfig';

/**
 * Determines whether an invoice row is a completely blank empty placeholder row.
 * True when the row has no description, no quantity, no price, and no positive total.
 */
export function isBlankPlaceholderRow(item: CanonicalInvoiceItem): boolean {
  const hasDesc = Boolean(item.description && item.description.trim() !== '');
  const hasQty = item.quantity !== '' && item.quantity !== undefined && item.quantity !== null;
  const hasPrice = item.unitPrice !== '' && item.unitPrice !== undefined && item.unitPrice !== null;
  const hasAmount = Boolean(item.totalAmount && item.totalAmount > 0);
  return !hasDesc && !hasQty && !hasPrice && !hasAmount;
}

/**
 * Normalizes an items list for pagination:
 * Trims trailing blank placeholder rows (e.g. from editor drafts),
 * while strictly preserving 100% of all items prior to the trailing blanks.
 * If all rows are blank, returns a single placeholder row.
 */
export function normalizeItemsForPagination(items: CanonicalInvoiceItem[]): CanonicalInvoiceItem[] {
  if (!items || items.length === 0) return [];
  let lastNonBlank = items.length - 1;
  while (lastNonBlank >= 0 && isBlankPlaceholderRow(items[lastNonBlank])) {
    lastNonBlank--;
  }
  if (lastNonBlank < 0) {
    return [items[0]];
  }
  return items.slice(0, lastNonBlank + 1);
}

/**
 * Legacy classification helper preserved for backward compatibility with existing tests.
 */
export const isPopulatedInvoiceItem = (item: CanonicalInvoiceItem): boolean =>
  !isBlankPlaceholderRow(item);

/**
 * Estimates the rendered vertical height of an item row.
 * Handles single-line descriptions and multi-line wrapped descriptions.
 */
export function getItemRowHeight(item: CanonicalInvoiceItem, baseRowHeight: number): number {
  const desc = item.description || '';
  const newlines = (desc.match(/\n/g) || []).length;
  // Estimate extra lines if description is long (>40 chars) or contains explicit linebreaks
  const extraLines = Math.max(newlines, Math.floor(Math.max(0, desc.length - 40) / 45));
  if (extraLines > 0) {
    return baseRowHeight + extraLines * 13;
  }
  return baseRowHeight;
}

/**
 * Authoritative Canonical Invoice Pagination Engine.
 * 
 * Rules:
 * 1. renderedItems.length === sourceItems.length (zero skipped, zero missing, zero duplicated).
 * 2. Next page always continues exactly where previous page ended.
 * 3. Page boundaries are calculated from real physical sheet space (A4 297mm = 1122.5px @ 96 DPI).
 * 4. Page 1 reserves space for Header, Title, Combined Customer/Invoice Row, and Table Header.
 * 5. Intermediate pages use compact continuation header and standard table header.
 * 6. Final page reserves space for Payment Information, Notes, and Signatures before Footer.
 * 7. Notes and Signatures appear ONLY on the final page.
 * 8. Fixed page-bottom footer appears on every page.
 */
export function paginateInvoiceItems(
  rawItems: CanonicalInvoiceItem[],
  paperConfig?: Partial<InvoicePaperConfig>,
  design?: InvoiceDesignSettings,
  docContext?: Partial<CanonicalInvoiceDocumentModel>
): CanonicalInvoicePage[] {
  const itemsToPaginate = normalizeItemsForPagination(rawItems);
  const totalItems = itemsToPaginate.length;

  if (totalItems === 0) {
    return [
      {
        pageNumber: 1,
        totalPages: 1,
        isFirstPage: true,
        isLastPage: true,
        items: [],
        showPayment: true,
        showNotes: true,
        showSignatures: true,
      },
    ];
  }

  // 1. Physical Sheet Geometry in CSS Pixels (96 DPI: 1mm = 96 / 25.4 = 3.779527559 px)
  const pxPerMm = 96 / 25.4;
  const isA5 = paperConfig?.paperSize === 'A5';
  const isLandscape = paperConfig?.orientation === 'landscape';
  const heightMm = paperConfig?.heightMm || (isA5 ? 210 : isLandscape ? 210 : 297);
  const totalPageHeightPx = heightMm * pxPerMm;

  const marginTopMm = paperConfig?.marginTopMm ?? 12;
  const marginBottomMm = paperConfig?.marginBottomMm ?? 12;
  const topMarginPx = marginTopMm * pxPerMm;
  const bottomMarginPx = marginBottomMm * pxPerMm;
  const usablePageHeight = totalPageHeightPx - topMarginPx - bottomMarginPx;

  // 2. Footer Height (Reserved on EVERY page)
  const effectiveDesign = design || DEFAULT_INVOICE_DESIGN;
  const footerPaddingTop = effectiveDesign.footer?.topSpacing ?? 8;
  const footerPaddingBottom = effectiveDesign.footer?.bottomSpacing ?? 8;
  const footerBorder = effectiveDesign.footer?.borderWidth ?? 2.5;
  const thankYouHeight = effectiveDesign.footer?.showThankYou !== false ? 22 : 0;
  const contactsHeight = 24;
  const calculatedFooterHeight = footerPaddingTop + footerPaddingBottom + footerBorder + thankYouHeight + contactsHeight + 10;
  const footerHeightPx = (effectiveDesign.footer as any)?.height
    ? Math.max((effectiveDesign.footer as any).height, calculatedFooterHeight)
    : calculatedFooterHeight;

  const usableHeightAboveFooter = usablePageHeight - footerHeightPx;

  // 3. Top Space on Page 1 (Header + Title + Combined Info Row + Table Header)
  let page1TopSpacePx = 0;
  if (effectiveDesign.visibility?.header !== false && effectiveDesign.header?.show !== false) {
    const headerPadding = (effectiveDesign.header?.padding ?? 2) + 8;
    const logoHeight = effectiveDesign.logos?.logo1?.height || 56;
    const textHeight =
      (effectiveDesign.company?.fontSize || 24) * 1.2 +
      (effectiveDesign.company?.showPashtoName !== false ? 29 : 0) +
      (effectiveDesign.company?.showSubtitle !== false ? 19 : 0);
    const headerContent = Math.max(logoHeight, textHeight);
    const headerMarginBottom = effectiveDesign.spacing?.headerToMeta ?? 8;
    page1TopSpacePx += headerPadding + headerContent + 3 + headerMarginBottom;
  }

  if (effectiveDesign.visibility?.invoiceTitle !== false && effectiveDesign.title?.show !== false) {
    const titleFontSize = effectiveDesign.title?.fontSize || 24;
    const titleMarginBottom = effectiveDesign.title?.marginBottom ?? 6;
    page1TopSpacePx += titleFontSize * 1.1 + titleMarginBottom;
  }

  const hasCompany = Boolean(docContext?.customer?.companyName && effectiveDesign.customer?.showCompany);
  const hasAddress = Boolean(docContext?.customer?.address && effectiveDesign.customer?.showAddress);
  const customerRows = 2 + (hasCompany ? 1 : 0) + (hasAddress ? 1 : 0);
  const customerCardHeight = 26 + customerRows * 22 + 16;
  const billInfoCardHeight = 26 + 3 * 22 + 16;
  const infoRowHeight = Math.max(customerCardHeight, billInfoCardHeight);
  const infoRowMarginBottom = effectiveDesign.spacing?.customerToTable ?? 8;
  page1TopSpacePx += infoRowHeight + infoRowMarginBottom;

  const tableHeaderHeightPx = 32;
  page1TopSpacePx += tableHeaderHeightPx;
  const page1SafetyCushion = 16;
  page1TopSpacePx += page1SafetyCushion;

  // 4. Top Space on Continuation Pages (Page 2+)
  const continuationTopSpacePx = 38 + tableHeaderHeightPx + 15; // ~85px

  // 5. Closing Content Space on Final Page (Payment Information + Notes + Signatures)
  let closingContentHeightPx = 0;
  if (effectiveDesign.payment?.show !== false || effectiveDesign.visibility?.total !== false) {
    closingContentHeightPx += 26 + 4 * 22 + 16 + (effectiveDesign.spacing?.totalsToNotes ?? 10);
  }
  if (effectiveDesign.visibility?.notes !== false && effectiveDesign.notes?.showInvoiceNote !== false) {
    closingContentHeightPx += 22 + 32 + 16 + (effectiveDesign.spacing?.notesToSignatures ?? 10);
  }
  if (effectiveDesign.visibility?.signatures !== false && effectiveDesign.signatures?.show !== false) {
    closingContentHeightPx += 36 + 20 + 16;
  }
  closingContentHeightPx += 20;

  if (isA5 || isLandscape) {
    closingContentHeightPx = Math.round(closingContentHeightPx * 0.85);
    page1TopSpacePx = Math.round(page1TopSpacePx * 0.85);
  }

  // 6. Base Item Row Height
  const baseRowHeight = Math.max(22.5, effectiveDesign.spacing?.rowHeight || 22.5);

  // 7. Usable vertical space for rows across page types
  const spaceForRowsSinglePage = Math.max(0, usableHeightAboveFooter - page1TopSpacePx - closingContentHeightPx);
  const spaceForRowsFirstPageMulti = Math.max(0, usableHeightAboveFooter - page1TopSpacePx);
  const spaceForRowsMiddlePage = Math.max(0, usableHeightAboveFooter - continuationTopSpacePx);
  const spaceForRowsLastPageWithClosing = Math.max(
    0,
    usableHeightAboveFooter - continuationTopSpacePx - closingContentHeightPx
  );

  const getItemHeight = (item: CanonicalInvoiceItem): number => getItemRowHeight(item, baseRowHeight);
  const getItemsHeight = (list: CanonicalInvoiceItem[]): number => {
    let sum = 0;
    for (const it of list) {
      sum += getItemHeight(it);
    }
    return sum;
  };

  const countFittingItems = (
    startIndex: number,
    maxAvailableHeight: number,
    total: number,
    list: CanonicalInvoiceItem[]
  ): number => {
    let accumulated = 0;
    let count = 0;
    for (let i = startIndex; i < total; i++) {
      const h = getItemHeight(list[i]);
      if (accumulated + h <= maxAvailableHeight) {
        accumulated += h;
        count++;
      } else {
        break;
      }
    }
    return count;
  };

  // Check if ALL items fit on a single page with closing content:
  // Hard limit: A4 portrait single page with full closing sections fits up to 14 rows comfortably
  const maxItemsSinglePage = isA5 ? 9 : isLandscape ? 8 : 14;
  if (totalItems <= maxItemsSinglePage && getItemsHeight(itemsToPaginate) <= spaceForRowsSinglePage) {
    return [
      {
        pageNumber: 1,
        totalPages: 1,
        isFirstPage: true,
        isLastPage: true,
        items: itemsToPaginate,
        showPayment: true,
        showNotes: true,
        showSignatures: true,
      },
    ];
  }

  // Multi-page partition
  const pageItemChunks: CanonicalInvoiceItem[][] = [];
  let currentIndex = 0;
  let pageNum = 1;

  while (currentIndex < totalItems) {
    const remaining = totalItems - currentIndex;

    if (pageNum === 1) {
      // Page 1 of multi-page invoice
      let count = countFittingItems(currentIndex, spaceForRowsFirstPageMulti, totalItems, itemsToPaginate);
      const maxPage1Items = isA5 ? 16 : isLandscape ? 14 : 23;
      count = Math.min(count, maxPage1Items);

      // Must leave room for subsequent page(s)
      const minNext = remaining <= 17 ? 1 : 2;
      if (count >= remaining) {
        count = Math.max(1, remaining - minNext);
      }
      count = Math.max(1, count);

      pageItemChunks.push(itemsToPaginate.slice(currentIndex, currentIndex + count));
      currentIndex += count;
    } else {
      // Check if all remaining items fit on this page WITH closing content
      const remainingHeight = getItemsHeight(itemsToPaginate.slice(currentIndex));
      const maxFinalPageItems = isA5 ? 14 : isLandscape ? 12 : 21;

      if (remaining <= maxFinalPageItems && remainingHeight <= spaceForRowsLastPageWithClosing) {
        // Final page!
        pageItemChunks.push(itemsToPaginate.slice(currentIndex));
        currentIndex = totalItems;
      } else {
        // Intermediate Middle page
        let count = countFittingItems(currentIndex, spaceForRowsMiddlePage, totalItems, itemsToPaginate);
        const maxMiddleItems = isA5 ? 20 : isLandscape ? 18 : 33;
        count = Math.min(count, maxMiddleItems);

        // Must leave at least 1 item for final page
        if (count >= remaining) {
          count = Math.max(1, remaining - 1);
        }
        count = Math.max(1, count);

        pageItemChunks.push(itemsToPaginate.slice(currentIndex, currentIndex + count));
        currentIndex += count;
      }
    }

    pageNum++;
  }

  // Authoritative Pagination Invariant Assertions:
  // 1. Total rendered items count === total source items count
  // 2. Original sequence & indexes preserved identically
  // 3. Boundary continuity: page N+1 starts exactly at index where page N ended
  if (process.env.NODE_ENV !== 'production') {
    const flattened = pageItemChunks.flat();
    if (flattened.length !== totalItems) {
      console.error(
        `[Pagination Invariant Violation] Total items mismatch: expected ${totalItems}, got ${flattened.length}`
      );
    }
    for (let i = 0; i < totalItems; i++) {
      if (flattened[i] !== itemsToPaginate[i]) {
        console.error(
          `[Pagination Invariant Violation] Item order/identity mismatch at index ${i}`
        );
      }
    }
  }

  const totalPages = pageItemChunks.length;
  return pageItemChunks.map((chunk, idx) => ({
    pageNumber: idx + 1,
    totalPages,
    isFirstPage: idx === 0,
    isLastPage: idx === totalPages - 1,
    items: chunk,
    showPayment: idx === totalPages - 1,
    showNotes: idx === totalPages - 1,
    showSignatures: idx === totalPages - 1,
  }));
}

/**
 * Calculates page chunks as an array of CanonicalInvoiceItem arrays.
 * Backward-compatible helper used across existing tests and components.
 */
export function calculateInvoicePageChunks(
  items: CanonicalInvoiceItem[],
  paperConfig?: Partial<InvoicePaperConfig>,
  design?: InvoiceDesignSettings,
  docContext?: Partial<CanonicalInvoiceDocumentModel>
): CanonicalInvoiceItem[][] {
  const pages = paginateInvoiceItems(items, paperConfig, design, docContext);
  return pages.map((p) => p.items);
}
