import assert from 'node:assert';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

console.log('======================================================');
console.log('SARWAN TECHNOLOGY: EXPENSE MODAL DIALOG VERIFICATION');
console.log('======================================================');

let passedTests = 0;
let totalTests = 0;

function it(description: string, fn: () => void) {
  totalTests++;
  try {
    fn();
    console.log(`  ✓ PASS: ${description}`);
    passedTests++;
  } catch (err: any) {
    console.error(`  ✗ FAIL: ${description}`);
    console.error(`    Error: ${err.message}`);
    throw err;
  }
}

// -------------------------------------------------------------
// 1. FILE & COMPONENT EXISTENCE
// -------------------------------------------------------------
console.log('\n--- 1. COMPONENT STRUCTURE & DEDICATED MODAL EXISTENCE ---');

it('ExpenseModal.tsx exists and is dedicated component in src/components/expense', () => {
  const modalPath = path.resolve(__dirname, '../components/expense/ExpenseModal.tsx');
  assert(fs.existsSync(modalPath), 'ExpenseModal.tsx must exist');
  const code = fs.readFileSync(modalPath, 'utf8');
  assert(code.includes('export const ExpenseModal'), 'Must export ExpenseModal component');
  assert(code.includes('role="dialog"'), 'Must define role="dialog"');
  assert(code.includes('aria-modal="true"'), 'Must define aria-modal="true"');
  assert(code.includes('aria-labelledby="expense-modal-title"'), 'Must define accessible title labeling');
});

it('InvoiceDetailModal imports and renders ExpenseModal instead of inline form', () => {
  const invoiceModalPath = path.resolve(__dirname, '../components/invoice/InvoiceDetailModal.tsx');
  const code = fs.readFileSync(invoiceModalPath, 'utf8');
  assert(code.includes("import { ExpenseModal } from '../expense/ExpenseModal';"), 'Must import ExpenseModal');
  assert(code.includes('<ExpenseModal'), 'Must render <ExpenseModal');
  assert(!code.includes('id="btn-collapse-invoice-expense"'), 'Must NOT contain old inline collapse button');
  assert(!code.includes('Collapse Expense Form'), 'Must NOT contain collapse form text in invoice detail');
});

// -------------------------------------------------------------
// 2. MODAL MODES: ADD, EDIT, RESUBMIT
// -------------------------------------------------------------
console.log('\n--- 2. DEDICATED MODAL TITLES, ICONS & BUTTON LABELS ACROSS MODES ---');

it('ExpenseModal supports Add Expense mode with correct title and submit label', () => {
  const modalPath = path.resolve(__dirname, '../components/expense/ExpenseModal.tsx');
  const code = fs.readFileSync(modalPath, 'utf8');
  assert(code.includes("'Add Expense'"), 'Must define "Add Expense" title');
  assert(code.includes("'Save Expense'"), 'Must define "Save Expense" submit button label');
  assert(code.includes('PlusCircle'), 'Must use PlusCircle icon for add mode');
});

it('ExpenseModal supports Edit Expense mode with correct title and submit label', () => {
  const modalPath = path.resolve(__dirname, '../components/expense/ExpenseModal.tsx');
  const code = fs.readFileSync(modalPath, 'utf8');
  assert(code.includes("'Edit Expense'"), 'Must define "Edit Expense" title');
  assert(code.includes("'Update Expense'"), 'Must define "Update Expense" submit button label');
  assert(code.includes('Pencil'), 'Must use Pencil icon for edit mode');
});

it('ExpenseModal supports Resubmit mode for rejected expenses with required corrections note', () => {
  const modalPath = path.resolve(__dirname, '../components/expense/ExpenseModal.tsx');
  const code = fs.readFileSync(modalPath, 'utf8');
  assert(code.includes("'Edit & Resubmit Rejected Expense'"), 'Must define resubmit title');
  assert(code.includes("'Resubmit Expense'"), 'Must define "Resubmit Expense" submit button label');
  assert(code.includes('RotateCcw'), 'Must use RotateCcw icon for resubmit mode');
  assert(code.includes('Correction Summary / Notes for Resubmission'), 'Must display correction notes field');
  assert(code.includes('activeExpense?.rejectionReason'), 'Must display previous rejection reason');
});

// -------------------------------------------------------------
// 3. DIALOG ACCESSIBILITY, FOCUS & SCROLL LOCK
// -------------------------------------------------------------
console.log('\n--- 3. ACCESSIBILITY, FOCUS RESTORATION & BODY SCROLL LOCK ---');

it('ExpenseModal locks body scroll while open and restores it when unmounted/closed', () => {
  const modalPath = path.resolve(__dirname, '../components/expense/ExpenseModal.tsx');
  const code = fs.readFileSync(modalPath, 'utf8');
  assert(code.includes("document.body.style.overflow = 'hidden'"), 'Must lock document body overflow');
  assert(code.includes("document.body.style.overflow = originalOverflow"), 'Must restore document body overflow');
});

it('ExpenseModal supports Escape key to dismiss when not actively saving', () => {
  const modalPath = path.resolve(__dirname, '../components/expense/ExpenseModal.tsx');
  const code = fs.readFileSync(modalPath, 'utf8');
  assert(code.includes("e.key === 'Escape'"), 'Must listen for Escape key');
  assert(code.includes('!savingExpense'), 'Escape key must be guarded while saving');
  assert(code.includes('onClose()'), 'Must invoke onClose upon Escape key');
});

it('ExpenseModal closes when clicking modal backdrop overlay and guards while saving', () => {
  const modalPath = path.resolve(__dirname, '../components/expense/ExpenseModal.tsx');
  const code = fs.readFileSync(modalPath, 'utf8');
  assert(code.includes('e.target === e.currentTarget && !savingExpense'), 'Backdrop click must close only when outside container and not saving');
});

it('ExpenseModal restores keyboard focus to triggering button on modal close', () => {
  const modalPath = path.resolve(__dirname, '../components/expense/ExpenseModal.tsx');
  const code = fs.readFileSync(modalPath, 'utf8');
  assert(code.includes('lastFocusedTrigger'), 'Must accept lastFocusedTrigger for focus return');
  assert(code.includes('lastFocusedTrigger.focus()'), 'Must call focus() on trigger button when closing');

  const invoiceModalPath = path.resolve(__dirname, '../components/invoice/InvoiceDetailModal.tsx');
  const invoiceCode = fs.readFileSync(invoiceModalPath, 'utf8');
  assert(invoiceCode.includes('lastFocusedExpenseTriggerRef'), 'InvoiceDetailModal must maintain trigger element ref');
});

// -------------------------------------------------------------
// 4. DESIGN SYSTEM, LAYERING & THEME CONFORMANCE
// -------------------------------------------------------------
console.log('\n--- 4. SARWAN DESIGN SYSTEM & THEME TOKENS ---');

it('ExpenseModal uses primary Sarwan Blue #2563EB and proper modal surface tokens', () => {
  const modalPath = path.resolve(__dirname, '../components/expense/ExpenseModal.tsx');
  const code = fs.readFileSync(modalPath, 'utf8');
  assert(code.includes('#2563EB'), 'Submit button must use #2563EB primary color');
  assert(code.includes('--app-surface-modal'), 'Modal container must consume --app-surface-modal token');
  assert(code.includes('--app-text-primary'), 'Modal text must consume --app-text-primary token');
  assert(code.includes('--app-border'), 'Modal border must consume --app-border token');
  assert(code.includes('z-60'), 'Modal backdrop must use z-60 for layering above z-50 invoice detail');
});

it('ExpenseModal provides internal scrolling with sticky header and footer', () => {
  const modalPath = path.resolve(__dirname, '../components/expense/ExpenseModal.tsx');
  const code = fs.readFileSync(modalPath, 'utf8');
  assert(code.includes('overflow-y-auto'), 'Body must scroll with overflow-y-auto');
  assert(code.includes('shrink-0'), 'Header and footer must have shrink-0 to prevent collapsing');
  assert(code.includes('max-h-[90vh]'), 'Modal must not exceed viewport height');
});

// -------------------------------------------------------------
// 5. VALIDATION & ERROR HANDLING INTEGRATION
// -------------------------------------------------------------
console.log('\n--- 5. VALIDATION, SUBMISSION GUARDS & ERROR NOTIFICATION ---');

it('InvoiceDetailModal guards against submission while in-flight and keeps modal open on failure', () => {
  const invoiceModalPath = path.resolve(__dirname, '../components/invoice/InvoiceDetailModal.tsx');
  const code = fs.readFileSync(invoiceModalPath, 'utf8');
  assert(code.includes('if (!invoice || savingExpense) return;'), 'Must guard against duplicate/concurrent submissions');
  assert(code.includes("setExpenseFormError('Expense description is required.');"), 'Must validate description');
  assert(code.includes("setExpenseFormError('Expense amount must be greater than zero.');"), 'Must validate amount');
  assert(code.includes("setExpenseFormError('Expense date is required.');"), 'Must validate date');
  assert(code.includes("setExpenseFormError('A resubmission note (at least 3 characters) describing corrections made is required.');"), 'Must validate resubmission corrections');
});

it('Cancelling or closing modal does NOT mutate invoice or create false expense records', () => {
  const invoiceModalPath = path.resolve(__dirname, '../components/invoice/InvoiceDetailModal.tsx');
  const code = fs.readFileSync(invoiceModalPath, 'utf8');
  // Inspect handleCloseExpenseForm
  assert(code.includes('const handleCloseExpenseForm = () => {'), 'Must define handleCloseExpenseForm');
  assert(!code.includes('saveInvoiceExpense(') || code.indexOf('handleCloseExpenseForm') < code.indexOf('saveInvoiceExpense('), 'Closing form does not save');
});

console.log('\n======================================================');
console.log(`TEST SUMMARY: ${passedTests} / ${totalTests} TESTS PASSED`);
console.log('ALL EXPENSE MODAL DIALOG TESTS PASSED SUCCESSFULLY! ✓');
console.log('======================================================');
