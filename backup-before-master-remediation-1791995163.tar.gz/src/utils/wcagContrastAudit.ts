import { THEME_CATALOG } from '../themes/catalog';

// WCAG relative luminance calculation
function hexToRgb(hex: string): { r: number; g: number; b: number } {
  let cleanHex = hex.replace('#', '').trim();
  if (cleanHex.length === 3) {
    cleanHex = cleanHex.split('').map(c => c + c).join('');
  }
  const num = parseInt(cleanHex, 16);
  return {
    r: (num >> 16) & 255,
    g: (num >> 8) & 255,
    b: num & 255,
  };
}

function getLuminance(r: number, g: number, b: number): number {
  const a = [r, g, b].map(v => {
    v /= 255;
    return v <= 0.03928 ? v / 12.92 : Math.pow((v + 0.055) / 1.055, 2.4);
  });
  return a[0] * 0.2126 + a[1] * 0.7152 + a[2] * 0.0722;
}

function getContrastRatio(hex1: string, hex2: string): number {
  const rgb1 = hexToRgb(hex1);
  const rgb2 = hexToRgb(hex2);
  const l1 = getLuminance(rgb1.r, rgb1.g, rgb1.b);
  const l2 = getLuminance(rgb2.r, rgb2.g, rgb2.b);
  const lighter = Math.max(l1, l2);
  const darker = Math.min(l1, l2);
  return (lighter + 0.05) / (darker + 0.05);
}

console.log('=== WCAG CONTRAST AUDIT ACROSS SARWAN BRAND THEME (LIGHT & DARK) ===');
let failures = 0;

for (const theme of THEME_CATALOG) {
  const { colors } = theme.tokens;
  const minNormalText = 4.5;
  const minLargeText = 3.0;

  // 1. Primary text on page background
  const ratioTextBg = getContrastRatio(colors.text.primary, colors.background.base);
  // 2. Primary text on card surface
  const ratioTextCard = getContrastRatio(colors.text.primary, colors.surface.card);
  // 3. Primary button text on primary button default
  const ratioBtn = getContrastRatio(colors.primary.text, colors.primary.default);
  // 4. Secondary text on card surface
  const ratioSecText = getContrastRatio(colors.text.secondary, colors.surface.card);
  // 5. Muted text on card surface (large or UI text 3:1)
  const ratioMutedText = getContrastRatio(colors.text.muted, colors.surface.card);

  console.log(`\nTheme [${theme.id}] (${theme.mode}) - ${theme.name}:`);
  console.log(`  1. Primary Text (${colors.text.primary}) on Base Bg (${colors.background.base}): ${ratioTextBg.toFixed(2)}:1 ${ratioTextBg >= minNormalText ? '✓ PASS' : '✗ FAIL'}`);
  console.log(`  2. Primary Text (${colors.text.primary}) on Card (${colors.surface.card}): ${ratioTextCard.toFixed(2)}:1 ${ratioTextCard >= minNormalText ? '✓ PASS' : '✗ FAIL'}`);
  console.log(`  3. Primary Button Text (${colors.primary.text}) on Button (${colors.primary.default}): ${ratioBtn.toFixed(2)}:1 ${ratioBtn >= minNormalText ? '✓ PASS' : '✗ FAIL'}`);
  console.log(`  4. Secondary Text (${colors.text.secondary}) on Card (${colors.surface.card}): ${ratioSecText.toFixed(2)}:1 ${ratioSecText >= minNormalText ? '✓ PASS' : '✗ FAIL'}`);
  console.log(`  5. Muted Text (${colors.text.muted}) on Card (${colors.surface.card}): ${ratioMutedText.toFixed(2)}:1 ${ratioMutedText >= minLargeText ? '✓ PASS (3:1)' : '✗ FAIL'}`);

  if (ratioTextBg < minNormalText) { console.error(`    FAIL: Text on Bg ratio ${ratioTextBg.toFixed(2)} < ${minNormalText}`); failures++; }
  if (ratioTextCard < minNormalText) { console.error(`    FAIL: Text on Card ratio ${ratioTextCard.toFixed(2)} < ${minNormalText}`); failures++; }
  if (ratioBtn < minNormalText) { console.error(`    FAIL: Button text ratio ${ratioBtn.toFixed(2)} < ${minNormalText}`); failures++; }
}

console.log(`\nAudit completed. Total failures: ${failures}`);
