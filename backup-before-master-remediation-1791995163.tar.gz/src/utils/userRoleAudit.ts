import { UserProfile, Customer, UserRole } from '../types';
import { PRIMARY_ADMIN_EMAILS, INITIAL_SUPER_ADMIN_UID } from '../services/security';

export interface RoleAuditIssue {
  userId: string;
  userName: string;
  username?: string;
  email?: string;
  currentRole: string;
  customerId?: string;
  issueType:
    | 'CUSTOMER_WITH_STAFF_ROLE'
    | 'CUSTOMER_ROLE_WITHOUT_CUSTOMER_LINK'
    | 'STAFF_WITH_CUSTOMER_LINK'
    | 'UNAUTHORIZED_SUPER_ADMIN'
    | 'ORPHANED_CUSTOMER_LINK'
    | 'ROLE_MISMATCH_WITH_CUSTOMER'
    | 'INVALID_ROLE_VALUE';
  severity: 'CRITICAL' | 'WARNING' | 'INFO';
  description: string;
  recommendedAction: string;
}

export interface RoleAuditReport {
  totalUsersScanned: number;
  totalStaffUsers: number;
  totalCustomerUsers: number;
  totalIssuesFound: number;
  criticalCount: number;
  warningCount: number;
  infoCount: number;
  issues: RoleAuditIssue[];
  timestamp: string;
}

/**
 * Validates whether an account is a legitimate staff user:
 * - Excludes accounts with role 'customer'
 * - Excludes accounts linked to a customer entity (customerId)
 * - Includes legitimate staff roles (super_admin, invoice_manager, payment_collector)
 * - Tolerates missing optional fields (jobTitle, department, employeeCode, etc.)
 */
export function isStaffUser(u: UserProfile | null | undefined): boolean {
  if (!u || typeof u !== 'object') return false;
  if (u.role === 'customer') return false;
  if (u.customerId && typeof u.customerId === 'string' && u.customerId.trim().length > 0) {
    return false;
  }
  return (
    u.role === 'super_admin' ||
    u.role === 'invoice_manager' ||
    u.role === 'payment_collector'
  );
}

/**
 * Validates whether an account is a customer portal user:
 * - Role is 'customer' OR actively linked to a customer record
 */
export function isCustomerUser(u: UserProfile | null | undefined): boolean {
  if (!u || typeof u !== 'object') return false;
  if (u.role === 'customer') return true;
  if (u.customerId && typeof u.customerId === 'string' && u.customerId.trim().length > 0) {
    return true;
  }
  return false;
}

/**
 * Scans all user records and customer records in memory to identify role inconsistencies.
 * SAFE AND NON-DESTRUCTIVE: Generates an auditable diagnostic report without modifying or deleting any data.
 */
export function auditUserRoles(
  users: UserProfile[] = [],
  customers: Customer[] = []
): RoleAuditReport {
  const issues: RoleAuditIssue[] = [];
  const customerIdSet = new Set(customers.map((c) => c.id));
  const customerCodeSet = new Set(
    customers.map((c) => c.customerCode || c.customerId || '').filter(Boolean)
  );

  let totalStaff = 0;
  let totalCustomers = 0;

  const validRoles: UserRole[] = [
    'super_admin',
    'invoice_manager',
    'payment_collector',
    'customer',
  ];

  for (const user of users) {
    if (!user || !user.id) continue;

    const role = user.role as UserRole;
    const cid = user.customerId?.trim();

    if (isStaffUser(user)) {
      totalStaff++;
    } else if (isCustomerUser(user)) {
      totalCustomers++;
    }

    // 1. Check for Invalid Role string
    if (!validRoles.includes(role)) {
      issues.push({
        userId: user.id,
        userName: user.name || 'Unknown',
        username: user.username,
        email: user.email,
        currentRole: String(role),
        customerId: cid,
        issueType: 'INVALID_ROLE_VALUE',
        severity: 'CRITICAL',
        description: `User account has unrecognized role "${role}".`,
        recommendedAction: 'Reassign to a valid system role (invoice_manager, payment_collector, or customer).',
      });
      continue;
    }

    // 2. Check for Customer with Staff Role (Security Risk)
    // Account has an active customerId link BUT is assigned a staff role
    if (cid && (role === 'invoice_manager' || role === 'payment_collector' || role === 'super_admin')) {
      issues.push({
        userId: user.id,
        userName: user.name || 'Unknown',
        username: user.username,
        email: user.email,
        currentRole: role,
        customerId: cid,
        issueType: 'CUSTOMER_WITH_STAFF_ROLE',
        severity: 'CRITICAL',
        description: `Customer account is linked to customer "${cid}" but holds staff authority (${role}).`,
        recommendedAction: 'Separate customer portal account from staff user, or reassign role to "customer".',
      });
    }

    // 3. Check for Customer Role without Customer Link (Detached/Orphan Customer)
    if (role === 'customer' && !cid) {
      // Check if any customer record has this user's ID
      const matchingCust = customers.find(
        (c) => c.userId === user.id || (c.email && user.email && c.email.toLowerCase() === user.email.toLowerCase())
      );

      if (matchingCust) {
        issues.push({
          userId: user.id,
          userName: user.name || 'Unknown',
          username: user.username,
          email: user.email,
          currentRole: role,
          customerId: cid,
          issueType: 'CUSTOMER_ROLE_WITHOUT_CUSTOMER_LINK',
          severity: 'WARNING',
          description: `Customer user account is not directly linked via customerId, but matches customer "${matchingCust.name}" (${matchingCust.id}).`,
          recommendedAction: `Link account to customer record "${matchingCust.id}".`,
        });
      } else {
        issues.push({
          userId: user.id,
          userName: user.name || 'Unknown',
          username: user.username,
          email: user.email,
          currentRole: role,
          customerId: cid,
          issueType: 'CUSTOMER_ROLE_WITHOUT_CUSTOMER_LINK',
          severity: 'WARNING',
          description: 'Customer portal user has no linked customerId and no corresponding customer record.',
          recommendedAction: 'Link to an existing customer record or complete customer registration.',
        });
      }
    }

    // 4. Check for Orphaned Customer Link (customerId points to nonexistent customer)
    if (cid && !customerIdSet.has(cid) && !customerCodeSet.has(cid)) {
      issues.push({
        userId: user.id,
        userName: user.name || 'Unknown',
        username: user.username,
        email: user.email,
        currentRole: role,
        customerId: cid,
        issueType: 'ORPHANED_CUSTOMER_LINK',
        severity: 'WARNING',
        description: `Account references customerId "${cid}", but no matching customer record exists in the database.`,
        recommendedAction: 'Verify if customer was deleted or restore/update the customer link.',
      });
    }

    // 5. Check for Unauthorized Super Admin
    if (role === 'super_admin') {
      const emailLower = (user.email || '').toLowerCase().trim();
      const isRecognizedAdmin =
        user.id === INITIAL_SUPER_ADMIN_UID ||
        PRIMARY_ADMIN_EMAILS.some((adm) => adm.toLowerCase() === emailLower);

      if (!isRecognizedAdmin) {
        issues.push({
          userId: user.id,
          userName: user.name || 'Unknown',
          username: user.username,
          email: user.email,
          currentRole: role,
          customerId: cid,
          issueType: 'UNAUTHORIZED_SUPER_ADMIN',
          severity: 'CRITICAL',
          description: `Account has super_admin role but is not listed in designated primary administrator registry (${user.email || user.username}).`,
          recommendedAction: 'Verify legitimacy with root administrator and reassign to appropriate operational role if needed.',
        });
      }
    }
  }

  // Check for customers pointing to staff users
  for (const cust of customers) {
    if (cust.userId) {
      const linkedUser = users.find((u) => u.id === cust.userId);
      if (linkedUser && linkedUser.role !== 'customer') {
        issues.push({
          userId: linkedUser.id,
          userName: linkedUser.name,
          username: linkedUser.username,
          email: linkedUser.email,
          currentRole: linkedUser.role,
          customerId: cust.id,
          issueType: 'ROLE_MISMATCH_WITH_CUSTOMER',
          severity: 'CRITICAL',
          description: `Customer "${cust.name}" (${cust.id}) is linked to user "${linkedUser.name}", who holds role "${linkedUser.role}" instead of "customer".`,
          recommendedAction: 'Reassign user to "customer" role or unlink user from customer record.',
        });
      }
    }
  }

  const criticalCount = issues.filter((i) => i.severity === 'CRITICAL').length;
  const warningCount = issues.filter((i) => i.severity === 'WARNING').length;
  const infoCount = issues.filter((i) => i.severity === 'INFO').length;

  return {
    totalUsersScanned: users.length,
    totalStaffUsers: totalStaff,
    totalCustomerUsers: totalCustomers,
    totalIssuesFound: issues.length,
    criticalCount,
    warningCount,
    infoCount,
    issues,
    timestamp: new Date().toISOString(),
  };
}
