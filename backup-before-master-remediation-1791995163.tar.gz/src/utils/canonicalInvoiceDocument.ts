import {
  Invoice,
  Payment,
  BusinessSettings,
  UserProfile,
  CustomerSnapshot,
  CompanySnapshot,
} from '../types';
import { DEFAULT_INVOICE_DESIGN, InvoiceDesignSettings, normalizeTableColumnOrder, normalizeFooterElementsOrder } from '../types/invoiceDesign';
import {
  CanonicalInvoiceDocumentModel,
  CanonicalInvoiceItem,
} from '../types/canonicalInvoiceDocument';
import {
  calculateSingleInvoiceStatus,
  getValidPaymentsPerInvoice,
} from './invoiceCalculator';
import { formatDate } from './format';
import { getInvoicePaperConfigFromDesign } from './invoicePaperConfig';
import { paginateInvoiceItems } from './canonicalInvoicePagination';

export interface BuildInvoiceDocumentOptions {
  invoice: Partial<Invoice>;
  payments?: Payment[];
  settings?: Partial<BusinessSettings>;
  userProfile?: UserProfile | null;
  totalPaidOverride?: number;
}

/**
 * Builds the canonical authoritative document model for any invoice.
 * Used identically for In-App Preview, Browser Print, and PDF export.
 */
export function buildCanonicalInvoiceDocument(
  options: BuildInvoiceDocumentOptions
): CanonicalInvoiceDocumentModel {
  const { invoice, payments = [], settings, totalPaidOverride } = options;

  const id = invoice.id || 'draft-invoice';
  const billNumber = invoice.billNumber?.trim() || '—';

  // 1. Calculate authoritative payments
  let totalPaid = 0;
  if (typeof totalPaidOverride === 'number' && Number.isFinite(totalPaidOverride)) {
    totalPaid = Math.max(0, totalPaidOverride);
  } else if (payments && payments.length > 0) {
    const { paymentsByInvoiceId, paymentsByBillNumber } = getValidPaymentsPerInvoice(
      invoice.id ? [invoice as Invoice] : [],
      payments
    );
    const paidById = invoice.id ? paymentsByInvoiceId.get(invoice.id) || 0 : 0;
    const paidByBill = invoice.billNumber ? paymentsByBillNumber.get(invoice.billNumber) || 0 : 0;
    totalPaid = Math.max(paidById, paidByBill);
  } else if (typeof invoice.totalPaid === 'number' && Number.isFinite(invoice.totalPaid)) {
    totalPaid = Math.max(0, invoice.totalPaid);
  }

  // 2. Authoritative items normalization
  const rawItems = Array.isArray(invoice.items) ? invoice.items : [];
  let calculatedItemsTotal = 0;

  const normalizedItems: CanonicalInvoiceItem[] = rawItems.map((item: any, idx: number) => {
    const sNo = typeof item.sNo === 'number' ? item.sNo : idx + 1;
    const description = typeof item.description === 'string' ? item.description.trim() : '';
    const quantity = item.quantity === '' || item.quantity === undefined || item.quantity === null
      ? ''
      : Number(item.quantity);
    const unitPrice = item.unitPrice === '' || item.unitPrice === undefined || item.unitPrice === null
      ? ''
      : Number(item.unitPrice);
    
    let totalAmount = 0;
    if (typeof item.totalAmount === 'number' && Number.isFinite(item.totalAmount)) {
      totalAmount = item.totalAmount;
    } else if (typeof quantity === 'number' && typeof unitPrice === 'number') {
      totalAmount = quantity * unitPrice;
    }

    if (totalAmount > 0) {
      calculatedItemsTotal += totalAmount;
    }

    return {
      sNo,
      description,
      quantity,
      unit: item.unit || 'pcs',
      unitPrice,
      totalAmount,
      discount: item.discount ? Number(item.discount) : undefined,
      tax: item.tax ? Number(item.tax) : undefined,
    };
  });

  // 3. Authoritative Total Price
  const rawTotalAmount = typeof invoice.totalAmount === 'number' ? invoice.totalAmount : Number(invoice.totalAmount || 0);
  const totalPrice = Number.isFinite(rawTotalAmount) && rawTotalAmount > 0
    ? rawTotalAmount
    : calculatedItemsTotal;

  // 4. Status calculation & Void check
  const isExplicitlyVoid = invoice.isVoid === true || invoice.status === 'Void';
  const statusResult = calculateSingleInvoiceStatus(
    {
      ...invoice,
      id,
      billNumber: invoice.billNumber || '',
      totalAmount: totalPrice,
      status: invoice.status || 'Unpaid',
      isVoid: isExplicitlyVoid,
    } as Invoice,
    totalPaid
  );

  const status = isExplicitlyVoid ? 'Void' : statusResult.status;
  const isVoid = status === 'Void';
  const isLocked = Boolean(
    isVoid ||
    invoice.isLocked ||
    status === 'Paid' ||
    (totalPrice > 0 && totalPaid >= totalPrice)
  );

  // Void invoices have 0 remaining receivable balance
  const remainingBalance = isVoid ? 0 : Math.max(0, totalPrice - totalPaid);

  // 5. Customer Info
  const customerSnapshot: Partial<CustomerSnapshot> = invoice.customerSnapshot || {};
  const customer = {
    id: invoice.customerId || customerSnapshot.id || '',
    name: customerSnapshot.name || (invoice as any).customerName || 'Walk-in Customer',
    phone: customerSnapshot.phone || (invoice as any).customerPhone || '',
    companyName: customerSnapshot.companyName || (invoice as any).customerCompanyName || '',
    address: customerSnapshot.address || (invoice as any).customerAddress || '',
    email: customerSnapshot.email || '',
  };

  // 6. Design & Paper Config - Style #7 Canonical Baseline with custom template resolution
  let savedDesign = settings?.invoiceDesign;
  if ((invoice as any)?.templateId && settings?.customTemplates?.length) {
    const matched = settings.customTemplates.find((t) => t.id === (invoice as any).templateId);
    if (matched?.design) {
      savedDesign = matched.design;
    }
  } else if ((invoice as any)?.customDesign) {
    savedDesign = (invoice as any).customDesign;
  }

  // 7. Company Info
  const companySnapshot: Partial<CompanySnapshot> = invoice.companySnapshot || {};
  const company = {
    companyName:
      savedDesign?.company?.name ||
      savedDesign?.title?.text ||
      savedDesign?.header?.headerText ||
      companySnapshot.companyName ||
      settings?.companyName ||
      'Sarwan Technology',
    logo: savedDesign?.logos?.logo1?.url || companySnapshot.logo || settings?.logo || '/sarwan-logo.png',
    logo2: savedDesign?.logos?.logo2?.url || companySnapshot.logo2 || settings?.logo2 || '/dahua-logo.svg',
    phone: companySnapshot.phone || settings?.phone || '0731339014',
    whatsapp: companySnapshot.whatsapp || settings?.whatsapp || '0778771020',
    email: companySnapshot.email || settings?.email || 'Sarwantechnology.af@gmail.com',
    address: companySnapshot.address || settings?.address || '',
    website: companySnapshot.website || settings?.website || '',
    currency: companySnapshot.currency || settings?.currency || 'AFN',
    invoiceNote: companySnapshot.invoiceNote || settings?.invoiceNote || '',
    subtitle: '',
    footerText: companySnapshot.footerText || settings?.footerText || '',
  };

  // 8. Dates
  const date = invoice.date || new Date().toISOString().split('T')[0];
  let displayDate = date;
  try {
    displayDate = formatDate(date);
  } catch {
    displayDate = date;
  }

  const dueDate = invoice.dueDate;
  let displayDueDate: string | undefined = undefined;
  if (dueDate) {
    try {
      displayDueDate = formatDate(dueDate);
    } catch {
      displayDueDate = dueDate;
    }
  }

  // 9. Design Assembly with deep-merging to prevent partial sub-object property loss
  const design: InvoiceDesignSettings = {
    ...DEFAULT_INVOICE_DESIGN,
    ...(savedDesign || {}),
    page: {
      ...DEFAULT_INVOICE_DESIGN.page,
      ...(savedDesign?.page || {}),
      margins: {
        ...DEFAULT_INVOICE_DESIGN.page.margins,
        ...(savedDesign?.page?.margins || {}),
      },
    },
    shapes: {
      topLeft: {
        ...DEFAULT_INVOICE_DESIGN.shapes?.topLeft,
        ...(savedDesign?.shapes?.topLeft || {}),
      },
      topRight: {
        ...DEFAULT_INVOICE_DESIGN.shapes?.topRight,
        ...(savedDesign?.shapes?.topRight || {}),
      },
      goldAccent: {
        ...DEFAULT_INVOICE_DESIGN.shapes?.goldAccent,
        ...(savedDesign?.shapes?.goldAccent || {}),
      },
    } as any,
    logos: {
      ...DEFAULT_INVOICE_DESIGN.logos,
      ...(savedDesign?.logos || {}),
      logo1: {
        ...DEFAULT_INVOICE_DESIGN.logos.logo1,
        ...(savedDesign?.logos?.logo1 || {}),
      },
      logo2: {
        ...DEFAULT_INVOICE_DESIGN.logos.logo2,
        ...(savedDesign?.logos?.logo2 || {}),
      },
    },
    company: {
      ...DEFAULT_INVOICE_DESIGN.company,
      ...(savedDesign?.company || {}),
      pashtoName: savedDesign?.company?.pashtoName ?? DEFAULT_INVOICE_DESIGN.company.pashtoName,
      slogan: savedDesign?.company?.slogan ?? DEFAULT_INVOICE_DESIGN.company.slogan,
      subtitle: savedDesign?.company?.subtitle ?? savedDesign?.company?.slogan ?? DEFAULT_INVOICE_DESIGN.company.subtitle,
      showName: savedDesign?.company?.showName ?? true,
      showSubtitle: savedDesign?.company?.showSubtitle ?? true,
    },
    header: {
      ...DEFAULT_INVOICE_DESIGN.header,
      ...(savedDesign?.header || {}),
    },
    title: {
      ...DEFAULT_INVOICE_DESIGN.title,
      ...(savedDesign?.title || {}),
      text: savedDesign?.title?.text ?? DEFAULT_INVOICE_DESIGN.title.text,
      secondaryText: savedDesign?.title?.secondaryText ?? DEFAULT_INVOICE_DESIGN.title.secondaryText,
      invoiceTitle: savedDesign?.title?.invoiceTitle ?? DEFAULT_INVOICE_DESIGN.title.invoiceTitle,
    },
    invoiceNumber: {
      ...DEFAULT_INVOICE_DESIGN.invoiceNumber,
      ...(savedDesign?.invoiceNumber || {}),
      label: savedDesign?.invoiceNumber?.label || 'Bill No:',
    },
    date: {
      ...DEFAULT_INVOICE_DESIGN.date,
      ...(savedDesign?.date || {}),
      label: savedDesign?.date?.label || 'Date:',
      dueDateLabel: savedDesign?.date?.dueDateLabel || 'Due Date:',
    },
    customer: {
      ...DEFAULT_INVOICE_DESIGN.customer,
      ...(savedDesign?.customer || {}),
      sectionTitle: savedDesign?.customer?.sectionTitle || 'Customer Information',
    },
    collector: {
      ...DEFAULT_INVOICE_DESIGN.collector,
      ...(savedDesign?.collector || {}),
      label: savedDesign?.collector?.label || 'Collector:',
    },
    itemsTable: {
      ...DEFAULT_INVOICE_DESIGN.itemsTable,
      ...(savedDesign?.itemsTable || {}),
      columnOrder: normalizeTableColumnOrder(savedDesign?.itemsTable?.columnOrder),
      columns: {
        ...DEFAULT_INVOICE_DESIGN.itemsTable.columns,
        ...(savedDesign?.itemsTable?.columns || {}),
        sNo: { ...DEFAULT_INVOICE_DESIGN.itemsTable.columns.sNo, ...(savedDesign?.itemsTable?.columns?.sNo || {}) },
        description: { ...DEFAULT_INVOICE_DESIGN.itemsTable.columns.description, ...(savedDesign?.itemsTable?.columns?.description || {}) },
        quantity: { ...DEFAULT_INVOICE_DESIGN.itemsTable.columns.quantity, ...(savedDesign?.itemsTable?.columns?.quantity || {}) },
        unit: { ...DEFAULT_INVOICE_DESIGN.itemsTable.columns.unit, ...(savedDesign?.itemsTable?.columns?.unit || {}) },
        unitPrice: { ...DEFAULT_INVOICE_DESIGN.itemsTable.columns.unitPrice, ...(savedDesign?.itemsTable?.columns?.unitPrice || {}) },
        discount: { ...DEFAULT_INVOICE_DESIGN.itemsTable.columns.discount, ...(savedDesign?.itemsTable?.columns?.discount || {}) },
        tax: { ...DEFAULT_INVOICE_DESIGN.itemsTable.columns.tax, ...(savedDesign?.itemsTable?.columns?.tax || {}) },
        totalAmount: { ...DEFAULT_INVOICE_DESIGN.itemsTable.columns.totalAmount, ...(savedDesign?.itemsTable?.columns?.totalAmount || {}) },
      },
    },
    totals: {
      ...DEFAULT_INVOICE_DESIGN.totals,
      ...(savedDesign?.totals || {}),
      subtotalLabel: savedDesign?.totals?.subtotalLabel === 'Total Price' ? 'Subtotal' : (savedDesign?.totals?.subtotalLabel || 'Subtotal'),
      grandTotalLabel: savedDesign?.totals?.grandTotalLabel || 'Grand Total',
      totalPaidLabel: savedDesign?.totals?.totalPaidLabel || 'Paid / Received',
      remainingLabel: savedDesign?.totals?.remainingLabel || 'Remaining',
    },
    payment: {
      ...DEFAULT_INVOICE_DESIGN.payment,
      ...(savedDesign?.payment || {}),
    },
    notes: {
      ...DEFAULT_INVOICE_DESIGN.notes,
      ...(savedDesign?.notes || {}),
      notesLabel: savedDesign?.notes?.notesLabel || 'Notes:',
    },
    signatures: {
      ...DEFAULT_INVOICE_DESIGN.signatures,
      ...(savedDesign?.signatures || {}),
    },
    footer: {
      ...DEFAULT_INVOICE_DESIGN.footer,
      ...(savedDesign?.footer || {}),
      footerElementsOrder: normalizeFooterElementsOrder(
        savedDesign?.footer?.footerElementsOrder || DEFAULT_INVOICE_DESIGN.footer?.footerElementsOrder
      ),
    },
    pageNumber: {
      ...DEFAULT_INVOICE_DESIGN.pageNumber,
      ...(savedDesign?.pageNumber || {}),
    },
    typography: {
      ...DEFAULT_INVOICE_DESIGN.typography,
      ...(savedDesign?.typography || {}),
    },
    colors: {
      ...DEFAULT_INVOICE_DESIGN.colors,
      ...(savedDesign?.colors || {}),
    },
    spacing: {
      ...DEFAULT_INVOICE_DESIGN.spacing,
      ...(savedDesign?.spacing || {}),
    },
    visibility: {
      ...DEFAULT_INVOICE_DESIGN.visibility,
      ...(savedDesign?.visibility || {}),
    },
  };

  const paperConfig = getInvoicePaperConfigFromDesign(design);

  // 9. Staff/Collector
  let assignedCollector: { id?: string; name?: string } | undefined = undefined;
  if (invoice.assignedCollectorId || (invoice as any).assignedCollectorName) {
    assignedCollector = {
      id: invoice.assignedCollectorId,
      name: (invoice as any).assignedCollectorName || (invoice as any).assignedCollector?.name,
    };
  }

  // 10. Payment Method resolution from authoritative data
  let paymentMethod: string | undefined = undefined;
  if ((invoice as any).paymentMethod && typeof (invoice as any).paymentMethod === 'string') {
    paymentMethod = (invoice as any).paymentMethod;
  } else if ((invoice as any).payment?.method && typeof (invoice as any).payment?.method === 'string') {
    paymentMethod = (invoice as any).payment.method;
  } else if (payments && payments.length > 0) {
    const matchingPayments = payments.filter((p) => {
      if (p.isVoid) return false;
      if (invoice.id && p.invoiceId === invoice.id) return true;
      if (invoice.billNumber && p.billNumber === invoice.billNumber) return true;
      return false;
    });
    if (matchingPayments.length > 0) {
      const rawMethod = matchingPayments[0].method;
      paymentMethod = rawMethod === 'CASH' ? 'Cash' : rawMethod;
    }
  }

  // 11. Authoritative Tax & Discount totals
  let totalTax = 0;
  for (const item of normalizedItems) {
    if (typeof item.tax === 'number' && Number.isFinite(item.tax)) {
      totalTax += item.tax;
    }
  }
  if (typeof (invoice as any).taxAmount === 'number' && Number.isFinite((invoice as any).taxAmount)) {
    totalTax = Math.max(totalTax, (invoice as any).taxAmount);
  }

  let totalDiscount = 0;
  for (const item of normalizedItems) {
    if (typeof item.discount === 'number' && Number.isFinite(item.discount)) {
      totalDiscount += item.discount;
    }
  }
  if (typeof (invoice as any).discountAmount === 'number' && Number.isFinite((invoice as any).discountAmount)) {
    totalDiscount = Math.max(totalDiscount, (invoice as any).discountAmount);
  }

  const docContext: Partial<CanonicalInvoiceDocumentModel> = {
    customer,
    company,
    design,
    paperConfig,
    items: normalizedItems,
    note: invoice.note,
    totalPrice,
    totalPaid,
    remainingBalance,
    status,
  };

  const pages = paginateInvoiceItems(normalizedItems, paperConfig, design, docContext);

  return {
    id,
    billNumber,
    date,
    displayDate,
    dueDate,
    displayDueDate,
    status,
    billingState: invoice.billingState,
    isVoid,
    isLocked,
    customer,
    assignedCollector,
    createdBy: (invoice as any).createdBy,
    company,
    items: normalizedItems,
    pages,
    subtotal: calculatedItemsTotal > 0 ? calculatedItemsTotal : totalPrice,
    totalPrice,
    totalPaid,
    remainingBalance,
    totalTax: typeof totalTax === 'number' ? totalTax : 0,
    totalDiscount: typeof totalDiscount === 'number' ? totalDiscount : 0,
    paymentMethod,
    note: invoice.note,
    design,
    paperConfig,
  };
}

/**
 * Creates a clean, filesystem-safe filename for PDF download.
 * E.g. "Sarwan-Technology-Invoice-ST-1001.pdf"
 */
export function getCanonicalInvoicePdfFileName(doc: CanonicalInvoiceDocumentModel): string {
  const rawCompany = (doc.company.companyName || 'Sarwan-Technology')
    .replace(/[^a-zA-Z0-9_-]/g, '-')
    .replace(/-+/g, '-');
  
  const rawBillNo = (doc.billNumber && doc.billNumber !== '—' ? doc.billNumber : 'Invoice')
    .replace(/[^a-zA-Z0-9_-]/g, '-')
    .replace(/-+/g, '-');

  const cleanCompany = rawCompany.replace(/^-|-$/g, '') || 'Sarwan-Technology';
  const cleanBill = rawBillNo.replace(/^-|-$/g, '') || 'Invoice';

  return `${cleanCompany}-Invoice-${cleanBill}.pdf`;
}
