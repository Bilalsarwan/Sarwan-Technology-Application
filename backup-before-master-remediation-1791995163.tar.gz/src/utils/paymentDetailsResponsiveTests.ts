/**
 * Verification Test Suite for Responsive Behavior of Payment Details UI
 * 
 * Verifies all criteria from USER_REQUEST:
 * 1. Desktop: Professional layout, max width max-w-2xl, clean alignment, action buttons clearly visible
 * 2. Tablet: Responsive grids (sm:grid-cols-2, sm:grid-cols-3), cards stack smoothly, no overflow
 * 3. Mobile / Small Screens: Single-column defaults (grid-cols-1), no horizontal scroll, text doesn't overlap,
 *    amounts remain fully visible (no truncate on amounts, uses break-words), long IDs/phones wrap/break safely
 * 4. Header: Multi-row stacking on mobile (flex-col xs:flex-row), ID and Invoice don't overlap, status visible, close accessible
 * 5. Action Buttons: Print/Download/Close accessible, responsive labels (hidden sm:inline / sm:hidden),
 *    aria-labels and tooltips preserved, stacking on narrow viewports
 * 6. Information Sections: Summary, Customer, Invoice, Record sections all responsive
 * 7. Modal Container: Flex container (flex flex-col max-h-[96vh]), scrollable body (overflow-y-auto flex-1 min-h-0),
 *    background body scroll lock to prevent horizontal page scrolling
 * 8. Functional integrity: No changes to data, invoice calculations, or payment records
 */

import fs from 'fs';
import path from 'path';

function assert(condition: boolean, message: string) {
  if (!condition) {
    throw new Error(`[FAIL] ${message}`);
  }
}

export function runPaymentDetailsResponsiveTests() {
  console.log('===============================================================');
  console.log('   PAYMENT DETAILS UI RESPONSIVE BEHAVIOR VERIFICATION TESTS   ');
  console.log('===============================================================');

  let passed = 0;
  const modalFilePath = path.resolve(process.cwd(), 'src/components/payment/PaymentDetailModal.tsx');
  const content = fs.readFileSync(modalFilePath, 'utf-8');

  // Test 1: Desktop Layout & Modal Container
  try {
    assert(content.includes('max-w-2xl'), 'Modal has max-w-2xl on desktop to prevent oversized empty space');
    assert(content.includes('max-h-[96vh] sm:max-h-[90vh]'), 'Modal height bounded within viewport');
    assert(content.includes('flex flex-col'), 'Modal is a flex column container for pinned header/footer');
    assert(content.includes('flex-1 min-h-0 overflow-y-auto'), 'Modal body is vertically scrollable and contained');
    assert(content.includes('overscroll-contain'), 'Modal body contains overscroll');
    assert(content.includes("document.body.style.overflow = 'hidden'"), 'Background scroll locked when modal is open');

    console.log('[✓ PASS] 1. Desktop Container & Viewport Bounds (max-w-2xl, flex-col, overflow-y-auto, scroll lock)');
    passed++;
  } catch (err: any) {
    console.error('[✗ FAIL] 1. Desktop Container:', err.message);
  }

  // Test 2: Header Mobile Stacking & Overflow Protection
  try {
    assert(content.includes('id="payment-detail-header"'), 'Header exists');
    assert(content.includes('flex flex-col xs:flex-row xs:items-center'), 'Header metadata stacks into multiple rows on mobile');
    assert(content.includes('id="payment-detail-header-id"'), 'Payment ID exists');
    assert(content.includes('id="payment-detail-header-invoice"'), 'Invoice Number exists');
    assert(content.includes('truncate max-w-[140px] xs:max-w-[200px] sm:max-w-none'), 'Header ID and Invoice Number have safety clamp to prevent overlap');
    assert(content.includes('id="payment-detail-status-badge"'), 'Status badge exists and visible');
    assert(content.includes('id="btn-close-payment-detail"'), 'Close button exists and accessible');

    console.log('[✓ PASS] 2. Header Mobile Stacking (Multi-row on mobile, no overlap between ID & Invoice, status visible, close accessible)');
    passed++;
  } catch (err: any) {
    console.error('[✗ FAIL] 2. Header Mobile Stacking:', err.message);
  }

  // Test 3: Amounts Must Remain Fully Visible (Anti-Truncation Rule)
  try {
    // Check Amount Paid in Payment Summary
    const summaryAmountMatch = content.match(/id="payment-summary-amount"[^>]*className="([^"]*)"/);
    assert(!!summaryAmountMatch, 'Summary amount element found');
    assert(!summaryAmountMatch![1].includes('truncate'), 'Summary amount does NOT have truncate class (amounts must remain fully visible)');
    assert(summaryAmountMatch![1].includes('break-words'), 'Summary amount has break-words');

    // Check Invoice Total
    const invoiceTotalMatch = content.match(/id="payment-invoice-total"[^>]*className="([^"]*)"/);
    assert(!!invoiceTotalMatch, 'Invoice total element found');
    assert(!invoiceTotalMatch![1].includes('truncate'), 'Invoice total does NOT have truncate class');

    // Check Total Paid
    const invoicePaidMatch = content.match(/id="payment-invoice-paid"[^>]*className="([^"]*)"/);
    assert(!!invoicePaidMatch, 'Invoice paid element found');
    assert(!invoicePaidMatch![1].includes('truncate'), 'Invoice paid does NOT have truncate class');

    // Check Remaining Balance
    const invoiceRemainingMatch = content.match(/id="payment-invoice-remaining"[^>]*className="([^"]*)"/);
    assert(!!invoiceRemainingMatch, 'Invoice remaining element found');
    assert(!invoiceRemainingMatch![1].includes('truncate'), 'Invoice remaining does NOT have truncate class');

    console.log('[✓ PASS] 3. Amounts Display Rule (Amounts never truncated, fully visible, break-words enabled)');
    passed++;
  } catch (err: any) {
    console.error('[✗ FAIL] 3. Amounts Display Rule:', err.message);
  }

  // Test 4: Action Buttons Responsive Behavior
  try {
    assert(content.includes('id="payment-detail-actions"'), 'Actions footer exists');
    assert(content.includes('flex flex-col xs:flex-row items-stretch xs:items-center'), 'Actions footer stacks on small screens');
    assert(content.includes('id="btn-print-payment-receipt"'), 'Print receipt button exists');
    assert(content.includes('id="btn-download-payment-receipt"'), 'Download receipt button exists');
    assert(content.includes('id="btn-close-payment-detail-footer"'), 'Close button exists in footer');
    assert(content.includes('hidden sm:inline'), 'Print & Download have responsive full labels on tablet/desktop');
    assert(content.includes('sm:hidden'), 'Print & Download have responsive compact labels on mobile');
    assert(content.includes('aria-label="Print Receipt"'), 'Print button has accessible aria-label');
    assert(content.includes('aria-label="Download Receipt / PDF"'), 'Download button has accessible aria-label');

    console.log('[✓ PASS] 4. Action Buttons Responsive Adaptation (Compact labels on mobile, full on desktop/tablet, accessible aria-labels, no button overflow)');
    passed++;
  } catch (err: any) {
    console.error('[✗ FAIL] 4. Action Buttons Responsive:', err.message);
  }

  // Test 5: Tablet & Mobile Grids for Information Sections
  try {
    // Payment Summary: grid-cols-1 sm:grid-cols-2 lg:grid-cols-4
    assert(content.includes('grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4'), 'Payment Summary adapts 1-col on mobile, 2 on tablet, 4 on desktop');

    // Customer Information: grid-cols-1 sm:grid-cols-2
    assert(content.includes('grid grid-cols-1 sm:grid-cols-2 gap-3 sm:gap-3.5'), 'Customer section adapts 1-col on mobile, 2 on tablet/desktop');

    // Invoice Info Grid: grid-cols-1 sm:grid-cols-3
    assert(content.includes('grid grid-cols-1 sm:grid-cols-3 gap-2.5 sm:gap-3'), 'Invoice metadata adapts 1-col on mobile, 3 on tablet/desktop');

    // Invoice Financial Ledger: grid-cols-1 sm:grid-cols-3
    assert(content.includes('grid grid-cols-1 sm:grid-cols-3 gap-2 sm:gap-2.5'), 'Invoice ledger adapts 1-col on mobile, 3 on tablet/desktop');

    console.log('[✓ PASS] 5. Information Sections Responsive Grids (Summary, Customer, Invoice, Record sections adapt to viewport)');
    passed++;
  } catch (err: any) {
    console.error('[✗ FAIL] 5. Responsive Grids:', err.message);
  }

  // Test 6: Long Values Wrapping & Break Protection
  try {
    assert(content.includes('break-all') && content.includes('break-words'), 'Long text values have break-words and break-all classes');
    assert(content.includes('id="payment-customer-phone"') && content.includes('break-all'), 'Customer phone has break-all to prevent horizontal overflow');
    assert(content.includes('id="payment-invoice-number"') && content.includes('break-all'), 'Invoice number has break-all to prevent horizontal overflow');
    assert(content.includes('id="payment-record-notes"') && content.includes('break-words'), 'Notes have break-words to prevent card overflow');

    console.log('[✓ PASS] 6. Long Values Wrapping & Horizontal Overflow Protection (Phone, Invoice No, Notes, IDs)');
    passed++;
  } catch (err: any) {
    console.error('[✗ FAIL] 6. Long Values Wrapping:', err.message);
  }

  // Test 7: Keyboard Accessibility & Overlay Interaction
  try {
    assert(content.includes("handleKeyDown") && content.includes("'Escape'"), 'Escape key handler dismisses modal cleanly');
    assert(content.includes('role="dialog"'), 'Dialog accessibility role preserved');
    assert(content.includes('aria-modal="true"'), 'aria-modal attribute preserved');
    assert(content.includes('aria-labelledby="payment-detail-title"'), 'aria-labelledby attribute preserved');

    console.log('[✓ PASS] 7. Keyboard Accessibility & WAI-ARIA Dialog Semantics');
    passed++;
  } catch (err: any) {
    console.error('[✗ FAIL] 7. Accessibility:', err.message);
  }

  // Test 8: Zero Functional / Business Logic Mutation
  try {
    assert(content.includes('formatAFN(payment.amount)'), 'Original formatAFN calculation intact');
    assert(content.includes('formatAFN(invoiceTotal)'), 'Original invoiceTotal calculation intact');
    assert(content.includes('formatAFN(invoiceTotalPaid)'), 'Original invoiceTotalPaid calculation intact');
    assert(content.includes('formatAFN(invoiceRemaining)'), 'Original invoiceRemaining calculation intact');
    assert(content.includes('downloadElementAsPdf'), 'Original PDF download function intact');
    assert(content.includes('handlePrintReceipt'), 'Original print handler intact');

    console.log('[✓ PASS] 8. Zero Functional Changes (Calculations, PDF generation, print handling 100% preserved)');
    passed++;
  } catch (err: any) {
    console.error('[✗ FAIL] 8. Functional Integrity:', err.message);
  }

  console.log('---------------------------------------------------------------');
  console.log(`TOTAL: 8 Tests | PASSED: ${passed} | FAILED: ${8 - passed}`);
  console.log('===============================================================');

  if (passed !== 8) {
    process.exit(1);
  }
}

runPaymentDetailsResponsiveTests();
