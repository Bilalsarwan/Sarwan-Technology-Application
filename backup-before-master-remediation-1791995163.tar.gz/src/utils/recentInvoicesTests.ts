import { Invoice, Payment, CustomerSnapshot, CompanySnapshot } from '../types';
import {
  getRecentInvoices,
  calculateInvoiceRecentStatus,
  getInvoiceCreationTimestamp,
} from './recentInvoices';
import { formatAFN } from './format';

export interface TestCaseResult {
  name: string;
  passed: boolean;
  expected: any;
  actual: any;
  message?: string;
}

export interface TestSuiteResult {
  suiteName: string;
  passed: boolean;
  totalTests: number;
  passedTests: number;
  failedTests: number;
  results: TestCaseResult[];
}

const defaultCustomerSnapshot: CustomerSnapshot = {
  id: 'cust-1',
  name: 'Test Customer',
  companyName: 'Test Company',
  phone: '0700000000',
  email: 'test@example.com',
  address: 'Kabul, Afghanistan',
};

const defaultCompanySnapshot: CompanySnapshot = {
  companyName: 'Sarwan Technology',
  logo: '',
  phone: '0799999999',
  whatsapp: '0799999999',
  email: 'info@sarwan.af',
  address: 'Kabul, Afghanistan',
  currency: 'AFN',
  invoiceNote: 'Thank you for your business.',
};

function createTestInvoice(overrides: Partial<Invoice> = {}): Invoice {
  return {
    id: overrides.id || 'inv-' + Math.random().toString(36).substring(2, 9),
    billNumber: overrides.billNumber || 'BILL-001',
    customerId: overrides.customerId || 'cust-1',
    customerSnapshot: overrides.customerSnapshot || defaultCustomerSnapshot,
    companySnapshot: overrides.companySnapshot || defaultCompanySnapshot,
    date: overrides.date || '2026-09-01',
    dueDate: overrides.dueDate || '2026-10-01',
    items: overrides.items || [],
    totalAmount: overrides.totalAmount !== undefined ? overrides.totalAmount : 1000,
    note: overrides.note || '',
    status: overrides.status || 'Unpaid',
    createdAt: overrides.createdAt || '2026-09-01T10:00:00.000Z',
    updatedAt: overrides.updatedAt || '2026-09-01T10:00:00.000Z',
    isVoid: overrides.isVoid !== undefined ? overrides.isVoid : false,
    ...overrides,
  };
}

function createTestPayment(overrides: Partial<Payment> = {}): Payment {
  return {
    id: overrides.id || 'pay-' + Math.random().toString(36).substring(2, 9),
    invoiceId: overrides.invoiceId || 'inv-1',
    billNumber: overrides.billNumber || 'BILL-001',
    customerId: overrides.customerId || 'cust-1',
    customerName: overrides.customerName || 'Test Customer',
    amount: overrides.amount !== undefined ? overrides.amount : 500,
    date: overrides.date || '2026-09-05',
    note: overrides.note || 'Cash payment',
    method: 'CASH',
    createdAt: overrides.createdAt || '2026-09-05T10:00:00.000Z',
    isVoid: overrides.isVoid !== undefined ? overrides.isVoid : false,
    ...overrides,
  };
}

export function runAllRecentInvoicesTests(): {
  passed: boolean;
  suites: TestSuiteResult[];
  totalTests: number;
  passedTests: number;
  failedTests: number;
} {
  const suites: TestSuiteResult[] = [];

  // Suite 1: Ordering & Limit (Newest First, Exactly 8)
  {
    const suite: TestSuiteResult = {
      suiteName: 'Recent Invoices Ordering & Limit',
      passed: true,
      totalTests: 0,
      passedTests: 0,
      failedTests: 0,
      results: [],
    };

    // Create 12 valid invoices with different creation times
    const invoices: Invoice[] = [
      createTestInvoice({ id: 'inv-1', billNumber: 'BILL-001', createdAt: '2026-09-01T10:00:00.000Z' }),
      createTestInvoice({ id: 'inv-2', billNumber: 'BILL-002', createdAt: '2026-09-02T10:00:00.000Z' }),
      createTestInvoice({ id: 'inv-3', billNumber: 'BILL-003', createdAt: '2026-09-03T10:00:00.000Z' }),
      createTestInvoice({ id: 'inv-4', billNumber: 'BILL-004', createdAt: '2026-09-04T10:00:00.000Z' }),
      createTestInvoice({ id: 'inv-5', billNumber: 'BILL-005', createdAt: '2026-09-05T10:00:00.000Z' }),
      createTestInvoice({ id: 'inv-6', billNumber: 'BILL-006', createdAt: '2026-09-06T10:00:00.000Z' }),
      createTestInvoice({ id: 'inv-7', billNumber: 'BILL-007', createdAt: '2026-09-07T10:00:00.000Z' }),
      createTestInvoice({ id: 'inv-8', billNumber: 'BILL-008', createdAt: '2026-09-08T10:00:00.000Z' }),
      createTestInvoice({ id: 'inv-9', billNumber: 'BILL-009', createdAt: '2026-09-09T10:00:00.000Z' }),
      createTestInvoice({ id: 'inv-10', billNumber: 'BILL-010', createdAt: '2026-09-10T10:00:00.000Z' }),
      createTestInvoice({ id: 'inv-11', billNumber: 'BILL-011', createdAt: '2026-09-11T10:00:00.000Z' }),
      createTestInvoice({ id: 'inv-12', billNumber: 'BILL-012', createdAt: '2026-09-12T10:00:00.000Z' }),
    ];

    const result = getRecentInvoices(invoices, [], 8, '2026-09-18');

    // Test 1: Exactly 8 records returned
    const t1Passed = result.length === 8;
    suite.results.push({
      name: 'Limits result to exactly 8 records',
      passed: t1Passed,
      expected: 8,
      actual: result.length,
    });

    // Test 2: Newest invoice (BILL-012) appears first
    const t2Passed = result[0]?.invoice.billNumber === 'BILL-012';
    suite.results.push({
      name: 'Newest invoice appears first in list',
      passed: t2Passed,
      expected: 'BILL-012',
      actual: result[0]?.invoice.billNumber,
    });

    // Test 3: Oldest included is BILL-005 (invoices 1-4 are excluded by limit)
    const t3Passed = result[7]?.invoice.billNumber === 'BILL-005';
    suite.results.push({
      name: 'Oldest included invoice is 8th newest',
      passed: t3Passed,
      expected: 'BILL-005',
      actual: result[7]?.invoice.billNumber,
    });

    // Test 4: Chronological descending order across all 8 items
    let isStrictlyDescending = true;
    for (let i = 0; i < result.length - 1; i++) {
      const curTime = getInvoiceCreationTimestamp(result[i].invoice);
      const nextTime = getInvoiceCreationTimestamp(result[i + 1].invoice);
      if (curTime < nextTime) {
        isStrictlyDescending = false;
        break;
      }
    }
    suite.results.push({
      name: 'All 8 invoices are strictly in descending chronological order',
      passed: isStrictlyDescending,
      expected: true,
      actual: isStrictlyDescending,
    });

    suite.totalTests = suite.results.length;
    suite.passedTests = suite.results.filter((r) => r.passed).length;
    suite.failedTests = suite.totalTests - suite.passedTests;
    suite.passed = suite.failedTests === 0;
    suites.push(suite);
  }

  // Suite 2: Void Invoices Exclusion
  {
    const suite: TestSuiteResult = {
      suiteName: 'Void Invoices Exclusion',
      passed: true,
      totalTests: 0,
      passedTests: 0,
      failedTests: 0,
      results: [],
    };

    const invoices: Invoice[] = [
      createTestInvoice({ id: 'inv-v1', billNumber: 'BILL-VOID-1', createdAt: '2026-09-15T12:00:00.000Z', isVoid: true }),
      createTestInvoice({ id: 'inv-v2', billNumber: 'BILL-VOID-2', createdAt: '2026-09-16T12:00:00.000Z', isVoid: false, status: 'Void' }),
      createTestInvoice({ id: 'inv-ok1', billNumber: 'BILL-OK-1', createdAt: '2026-09-14T12:00:00.000Z', isVoid: false }),
    ];

    const result = getRecentInvoices(invoices, [], 8, '2026-09-18');

    // Test 1: Void invoice with isVoid: true is excluded
    const hasVoid1 = result.some((r) => r.invoice.id === 'inv-v1');
    suite.results.push({
      name: 'Invoice with isVoid: true is completely excluded',
      passed: !hasVoid1,
      expected: false,
      actual: hasVoid1,
    });

    // Test 2: Invoice with status: Void is excluded
    const hasVoid2 = result.some((r) => r.invoice.id === 'inv-v2');
    suite.results.push({
      name: 'Invoice with status: "Void" is completely excluded',
      passed: !hasVoid2,
      expected: false,
      actual: hasVoid2,
    });

    // Test 3: Valid invoice remains
    const hasOk1 = result.some((r) => r.invoice.id === 'inv-ok1');
    suite.results.push({
      name: 'Valid non-void invoice is present',
      passed: hasOk1,
      expected: true,
      actual: hasOk1,
    });

    suite.totalTests = suite.results.length;
    suite.passedTests = suite.results.filter((r) => r.passed).length;
    suite.failedTests = suite.totalTests - suite.passedTests;
    suite.passed = suite.failedTests === 0;
    suites.push(suite);
  }

  // Suite 3: Dynamic Status Calculation (Paid, Overdue, Partially Paid, Unpaid)
  {
    const suite: TestSuiteResult = {
      suiteName: 'Dynamic Status Calculation Business Rules',
      passed: true,
      totalTests: 0,
      passedTests: 0,
      failedTests: 0,
      results: [],
    };

    const today = '2026-09-18';

    // Test 1: Fully paid invoice before due date → Paid
    const invFullyPaidBeforeDue = createTestInvoice({
      id: 'inv-fp-1',
      billNumber: 'BILL-FP-1',
      totalAmount: 100000,
      date: '2026-09-10',
      dueDate: '2026-10-01',
      createdAt: '2026-09-10T08:00:00.000Z',
    });
    const paymentFull = createTestPayment({
      id: 'pay-fp-1',
      invoiceId: 'inv-fp-1',
      billNumber: 'BILL-FP-1',
      amount: 100000,
      date: '2026-09-12',
      createdAt: '2026-09-12T09:00:00.000Z',
    });
    const res1 = calculateInvoiceRecentStatus(invFullyPaidBeforeDue, [paymentFull], today);
    suite.results.push({
      name: 'Fully paid invoice before due date → Paid',
      passed: res1.status === 'Paid',
      expected: 'Paid',
      actual: res1.status,
    });

    // Test 2: Fully paid invoice AFTER due date → Paid (Priority: Paid over Overdue)
    const invFullyPaidAfterDue = createTestInvoice({
      id: 'inv-fp-2',
      billNumber: 'BILL-FP-2',
      totalAmount: 100000,
      date: '2026-08-01',
      dueDate: '2026-08-15', // past due date
      createdAt: '2026-08-01T08:00:00.000Z',
    });
    const paymentLate = createTestPayment({
      id: 'pay-fp-2',
      invoiceId: 'inv-fp-2',
      billNumber: 'BILL-FP-2',
      amount: 100000,
      date: '2026-09-10',
      createdAt: '2026-09-10T09:00:00.000Z',
    });
    const res2 = calculateInvoiceRecentStatus(invFullyPaidAfterDue, [paymentLate], today);
    suite.results.push({
      name: 'Fully paid invoice after due date → Paid (Paid has priority over Overdue)',
      passed: res2.status === 'Paid',
      expected: 'Paid',
      actual: res2.status,
    });

    // Test 3: Multiple valid payments → correctly summed to Partially Paid
    const invMultiPay = createTestInvoice({
      id: 'inv-mp-1',
      billNumber: 'BILL-MP-1',
      totalAmount: 100000,
      date: '2026-09-01',
      dueDate: '2026-10-01', // future due date
      createdAt: '2026-09-01T08:00:00.000Z',
    });
    const pay1 = createTestPayment({
      id: 'pay-mp-1',
      invoiceId: 'inv-mp-1',
      billNumber: 'BILL-MP-1',
      amount: 30000,
      date: '2026-09-05',
      createdAt: '2026-09-05T09:00:00.000Z',
    });
    const pay2 = createTestPayment({
      id: 'pay-mp-2',
      invoiceId: 'inv-mp-1',
      billNumber: 'BILL-MP-1',
      amount: 20000,
      date: '2026-09-08',
      createdAt: '2026-09-08T09:00:00.000Z',
    });
    const res3 = calculateInvoiceRecentStatus(invMultiPay, [pay1, pay2], today);
    suite.results.push({
      name: 'Multiple valid payments (30k + 20k of 100k) before due date → Partially Paid',
      passed: res3.status === 'Partially Paid' && res3.paidAmount === 50000 && res3.remainingAmount === 50000,
      expected: { status: 'Partially Paid', paid: 50000, remaining: 50000 },
      actual: { status: res3.status, paid: res3.paidAmount, remaining: res3.remainingAmount },
    });

    // Test 4: Unpaid before due date → Unpaid
    const invUnpaidFuture = createTestInvoice({
      id: 'inv-unp-1',
      billNumber: 'BILL-UNP-1',
      totalAmount: 100000,
      date: '2026-09-10',
      dueDate: '2026-10-15', // future
      createdAt: '2026-09-10T08:00:00.000Z',
    });
    const res4 = calculateInvoiceRecentStatus(invUnpaidFuture, [], today);
    suite.results.push({
      name: 'Unpaid invoice before due date → Unpaid',
      passed: res4.status === 'Unpaid' && res4.paidAmount === 0,
      expected: 'Unpaid',
      actual: res4.status,
    });

    // Test 5: Unpaid after due date → Overdue
    const invUnpaidPast = createTestInvoice({
      id: 'inv-ovd-1',
      billNumber: 'BILL-OVD-1',
      totalAmount: 100000,
      date: '2026-08-01',
      dueDate: '2026-08-15', // past
      createdAt: '2026-08-01T08:00:00.000Z',
    });
    const res5 = calculateInvoiceRecentStatus(invUnpaidPast, [], today);
    suite.results.push({
      name: 'Unpaid invoice after due date → Overdue',
      passed: res5.status === 'Overdue' && res5.remainingAmount === 100000,
      expected: 'Overdue',
      actual: res5.status,
    });

    // Test 6: Partially paid after due date → Overdue
    const invPartiallyPaidPast = createTestInvoice({
      id: 'inv-ovd-2',
      billNumber: 'BILL-OVD-2',
      totalAmount: 100000,
      date: '2026-08-01',
      dueDate: '2026-08-15', // past
      createdAt: '2026-08-01T08:00:00.000Z',
    });
    const payPartial = createTestPayment({
      id: 'pay-ovd-2',
      invoiceId: 'inv-ovd-2',
      billNumber: 'BILL-OVD-2',
      amount: 30000,
      date: '2026-08-05',
      createdAt: '2026-08-05T09:00:00.000Z',
    });
    const res6 = calculateInvoiceRecentStatus(invPartiallyPaidPast, [payPartial], today);
    suite.results.push({
      name: 'Partially paid invoice after due date → Overdue (balance > 0 and past due)',
      passed: res6.status === 'Overdue' && res6.paidAmount === 30000 && res6.remainingAmount === 70000,
      expected: { status: 'Overdue', paid: 30000, remaining: 70000 },
      actual: { status: res6.status, paid: res6.paidAmount, remaining: res6.remainingAmount },
    });

    // Test 7: Void payment is strictly excluded from paid calculation
    const invWithVoidPayment = createTestInvoice({
      id: 'inv-vp-1',
      billNumber: 'BILL-VP-1',
      totalAmount: 100000,
      date: '2026-09-01',
      dueDate: '2026-10-01', // future
      createdAt: '2026-09-01T08:00:00.000Z',
    });
    const payVoid = createTestPayment({
      id: 'pay-void-1',
      invoiceId: 'inv-vp-1',
      billNumber: 'BILL-VP-1',
      amount: 100000,
      date: '2026-09-05',
      createdAt: '2026-09-05T09:00:00.000Z',
      isVoid: true, // voided payment
    });
    const res7 = calculateInvoiceRecentStatus(invWithVoidPayment, [payVoid], today);
    suite.results.push({
      name: 'Void payment (isVoid: true) is excluded, invoice remains Unpaid',
      passed: res7.status === 'Unpaid' && res7.paidAmount === 0,
      expected: { status: 'Unpaid', paidAmount: 0 },
      actual: { status: res7.status, paidAmount: res7.paidAmount },
    });

    suite.totalTests = suite.results.length;
    suite.passedTests = suite.results.filter((r) => r.passed).length;
    suite.failedTests = suite.totalTests - suite.passedTests;
    suite.passed = suite.failedTests === 0;
    suites.push(suite);
  }

  // Suite 4: Timestamp Formats & Fault Tolerance
  {
    const suite: TestSuiteResult = {
      suiteName: 'Timestamp Parsing & Fault Tolerance',
      passed: true,
      totalTests: 0,
      passedTests: 0,
      failedTests: 0,
      results: [],
    };

    // Test 1: ISO string parsing
    const t1 = getInvoiceCreationTimestamp({ createdAt: '2026-09-18T10:00:00.000Z' });
    suite.results.push({
      name: 'Parses standard ISO 8601 string correctly',
      passed: t1 === 1789725600000 || t1 > 0,
      expected: '> 0',
      actual: t1,
    });

    // Test 2: Firestore Timestamp-like { seconds, nanoseconds }
    const t2 = getInvoiceCreationTimestamp({
      createdAt: { seconds: 1789725600, nanoseconds: 500000000 } as any,
    });
    suite.results.push({
      name: 'Parses Firestore { seconds, nanoseconds } correctly',
      passed: t2 === 1789725600500,
      expected: 1789725600500,
      actual: t2,
    });

    // Test 3: Firestore Timestamp with toMillis()
    const t3 = getInvoiceCreationTimestamp({
      createdAt: { toMillis: () => 1789725600000 } as any,
    });
    suite.results.push({
      name: 'Parses Firestore toMillis() correctly',
      passed: t3 === 1789725600000,
      expected: 1789725600000,
      actual: t3,
    });

    // Test 4: Missing createdAt falls back to date
    const t4 = getInvoiceCreationTimestamp({ date: '2026-09-18' });
    suite.results.push({
      name: 'Falls back to inv.date when createdAt is missing',
      passed: t4 > 0,
      expected: '> 0',
      actual: t4,
    });

    // Test 5: Corrupted / undefined createdAt does not crash
    const t5 = getInvoiceCreationTimestamp({ createdAt: 'corrupted-date' as any });
    suite.results.push({
      name: 'Corrupted createdAt returns 0 and does not throw',
      passed: t5 === 0,
      expected: 0,
      actual: t5,
    });

    // Test 6: Currency formatting uses AFN and never $ or USD
    const formatted = formatAFN(125000);
    suite.results.push({
      name: 'Currency formatting displays AFN 125,000 without $ or USD',
      passed: formatted.includes('AFN') && !formatted.includes('$') && !formatted.includes('USD'),
      expected: 'AFN 125,000 (or localized with AFN)',
      actual: formatted,
    });

    suite.totalTests = suite.results.length;
    suite.passedTests = suite.results.filter((r) => r.passed).length;
    suite.failedTests = suite.totalTests - suite.passedTests;
    suite.passed = suite.failedTests === 0;
    suites.push(suite);
  }

  const totalTests = suites.reduce((sum, s) => sum + s.totalTests, 0);
  const passedTests = suites.reduce((sum, s) => sum + s.passedTests, 0);
  const failedTests = suites.reduce((sum, s) => sum + s.failedTests, 0);
  const passed = failedTests === 0;

  console.log('===============================================================');
  console.log('       RECENT INVOICES VERIFICATION TEST SUITE RESULTS         ');
  console.log('===============================================================');
  for (const s of suites) {
    const sym = s.passed ? '✓ PASS' : '✗ FAIL';
    console.log(`\n[${sym}] ${s.suiteName} (${s.passedTests}/${s.totalTests} passed)`);
    for (const r of s.results) {
      const itemSym = r.passed ? '  ✓' : '  ✗';
      console.log(`${itemSym} ${r.name}`);
      if (!r.passed) {
        console.log(`     Expected: ${JSON.stringify(r.expected)}, Actual: ${JSON.stringify(r.actual)}`);
      }
    }
  }
  console.log('\n---------------------------------------------------------------');
  console.log(`TOTAL: ${passedTests}/${totalTests} Tests Passed`);
  console.log(`OVERALL STATUS: ${passed ? 'ALL TESTS PASSED' : 'SOME TESTS FAILED'}`);
  console.log('===============================================================\n');

  return { passed, suites, totalTests, passedTests, failedTests };
}

// Self-executing if run directly
if (import.meta.url === `file://${process.argv[1]}`) {
  const summary = runAllRecentInvoicesTests();
  if (!summary.passed) {
    process.exit(1);
  }
}
