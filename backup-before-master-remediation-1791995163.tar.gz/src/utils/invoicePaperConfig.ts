import { PaperSize, PageOrientation, InvoiceDesignSettings } from '../types/invoiceDesign';

export interface InvoicePaperConfig {
  paperSize: PaperSize;
  orientation: PageOrientation;
  widthMm: number;
  heightMm: number;
  widthPx: number; // calculated at 96 DPI: 1mm = 3.779527559px
  heightPx: number;
  marginTopMm: number;
  marginRightMm: number;
  marginBottomMm: number;
  marginLeftMm: number;
  pdfFormat: string | [number, number];
}

const MM_TO_PX = 3.779527559;

export function getInvoicePaperConfig(
  paperSize: PaperSize = 'A4',
  orientation: PageOrientation = 'portrait',
  margins?: { top: number; right: number; bottom: number; left: number }
): InvoicePaperConfig {
  let widthMm = 210;
  let heightMm = 297;
  let pdfFormat: string | [number, number] = 'a4';

  if (paperSize === 'A5') {
    widthMm = 148;
    heightMm = 210;
    pdfFormat = 'a5';
  } else if (paperSize === 'Letter') {
    widthMm = 215.9;
    heightMm = 279.4;
    pdfFormat = 'letter';
  }

  const isLandscape = orientation === 'landscape';
  if (isLandscape) {
    const tempMm = widthMm;
    widthMm = heightMm;
    heightMm = tempMm;
  }

  const top = margins?.top ?? 12;
  const right = margins?.right ?? 12;
  const bottom = margins?.bottom ?? 12;
  const left = margins?.left ?? 12;

  return {
    paperSize,
    orientation,
    widthMm,
    heightMm,
    widthPx: Math.round(widthMm * MM_TO_PX),
    heightPx: Math.round(heightMm * MM_TO_PX),
    marginTopMm: top,
    marginRightMm: right,
    marginBottomMm: bottom,
    marginLeftMm: left,
    pdfFormat: isLandscape ? [widthMm, heightMm] : pdfFormat,
  };
}

export function getInvoicePaperConfigFromDesign(
  design?: Partial<InvoiceDesignSettings>
): InvoicePaperConfig {
  const paperSize = design?.page?.paperSize || 'A4';
  const orientation = design?.page?.orientation || 'portrait';
  const margins = design?.page?.margins;
  return getInvoicePaperConfig(paperSize, orientation, margins);
}
