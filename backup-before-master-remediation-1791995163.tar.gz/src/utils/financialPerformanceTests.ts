import { Invoice, Payment, Expense } from '../types';
import {
  calculateFinancialPerformance,
  parseSafeAmount,
  isValidInvoiceForPerformance,
  isValidPaymentForPerformance,
  isValidExpenseForPerformance,
  extractCalendarDateString,
  getCalendarDateRanges,
} from './financialPerformance';
import { formatAFN } from './format';

interface TestResult {
  name: string;
  passed: boolean;
  expected: any;
  actual: any;
  message?: string;
}

export function runFinancialPerformanceTests(): { passed: boolean; total: number; passedCount: number; failedCount: number } {
  const results: TestResult[] = [];

  function assert(name: string, actual: any, expected: any, message?: string) {
    const passed = JSON.stringify(actual) === JSON.stringify(expected);
    results.push({ name, passed, expected, actual, message });
  }

  // Use a fixed reference date: 2026-09-18
  const refDate = new Date(2026, 8, 18, 14, 0, 0); // Sept 18, 2026

  // 1. Safe parsing tests
  assert('parseSafeAmount with valid number', parseSafeAmount(1500), 1500);
  assert('parseSafeAmount with string number', parseSafeAmount(' 2500.50 '), 2500.5);
  assert('parseSafeAmount with null', parseSafeAmount(null), 0);
  assert('parseSafeAmount with undefined', parseSafeAmount(undefined), 0);
  assert('parseSafeAmount with empty string', parseSafeAmount(''), 0);
  assert('parseSafeAmount with NaN', parseSafeAmount(NaN), 0);

  // 2. Invoice validation tests
  assert(
    'isValidInvoice excludes isVoid: true',
    isValidInvoiceForPerformance({ id: 'inv-1', isVoid: true, totalAmount: 1000 } as any),
    false
  );
  assert(
    'isValidInvoice excludes status: "Void"',
    isValidInvoiceForPerformance({ id: 'inv-2', status: 'Void', totalAmount: 1000 } as any),
    false
  );
  assert(
    'isValidInvoice includes valid active invoice',
    isValidInvoiceForPerformance({ id: 'inv-3', isVoid: false, status: 'Unpaid', totalAmount: 1000 } as any),
    true
  );

  // 3. Expense validation tests (strictly approved AND executed)
  assert(
    'isValidExpense excludes pending_manager',
    isValidExpenseForPerformance({ id: 'exp-1', status: 'pending_manager', amount: 500 } as any),
    false
  );
  assert(
    'isValidExpense excludes pending_admin',
    isValidExpenseForPerformance({ id: 'exp-2', status: 'pending_admin', amount: 500 } as any),
    false
  );
  assert(
    'isValidExpense excludes rejected',
    isValidExpenseForPerformance({ id: 'exp-3', status: 'rejected', amount: 500 } as any),
    false
  );
  assert(
    'isValidExpense excludes approved without execution',
    isValidExpenseForPerformance({ id: 'exp-4', status: 'approved', executionStatus: 'pending', amount: 500 } as any),
    false
  );
  assert(
    'isValidExpense includes approved AND executed',
    isValidExpenseForPerformance({ id: 'exp-5', status: 'approved', executionStatus: 'executed', amount: 500 } as any),
    true
  );
  assert(
    'isValidExpense includes status executed',
    isValidExpenseForPerformance({ id: 'exp-6', status: 'executed', amount: 500 } as any),
    true
  );

  // 4. Payment validation tests
  const validInvIds = new Set(['inv-valid-1', 'inv-valid-2']);
  const validBills = new Set(['BILL-101']);
  const voidInvIds = new Set(['inv-void-1']);
  const voidBills = new Set(['BILL-VOID']);

  assert(
    'isValidPayment excludes isVoid: true',
    isValidPaymentForPerformance(
      { id: 'p-1', isVoid: true, invoiceId: 'inv-valid-1', amount: 200 } as any,
      validInvIds,
      validBills,
      voidInvIds,
      voidBills
    ),
    false
  );
  assert(
    'isValidPayment excludes payment belonging to void invoice',
    isValidPaymentForPerformance(
      { id: 'p-2', isVoid: false, invoiceId: 'inv-void-1', amount: 200 } as any,
      validInvIds,
      validBills,
      voidInvIds,
      voidBills
    ),
    false
  );
  assert(
    'isValidPayment includes payment belonging to valid invoice',
    isValidPaymentForPerformance(
      { id: 'p-3', isVoid: false, invoiceId: 'inv-valid-1', amount: 200 } as any,
      validInvIds,
      validBills,
      voidInvIds,
      voidBills
    ),
    true
  );

  // 5. Calendar date range tests
  const dateRanges = getCalendarDateRanges(refDate);
  assert('getCalendarDateRanges todayStr is 2026-09-18', dateRanges.todayStr, '2026-09-18');
  assert('getCalendarDateRanges last 7 days contains today', dateRanges.last7DaysSet.has('2026-09-18'), true);
  assert('getCalendarDateRanges last 7 days contains 6 days ago (2026-09-12)', dateRanges.last7DaysSet.has('2026-09-12'), true);
  assert('getCalendarDateRanges last 7 days does NOT contain 7 days ago (2026-09-11)', dateRanges.last7DaysSet.has('2026-09-11'), false);
  assert('getCalendarDateRanges thisMonthPrefix is 2026-09', dateRanges.thisMonthPrefix, '2026-09');

  // 6. Comprehensive Financial Performance Calculation Scenario
  const testInvoices: Invoice[] = [
    // Today (2026-09-18)
    { id: 'inv-today-1', billNumber: 'B1', date: '2026-09-18', totalAmount: 10000, status: 'Unpaid', isVoid: false } as any,
    { id: 'inv-today-2', billNumber: 'B2', date: '2026-09-18', totalAmount: 5000, status: 'Partially Paid', isVoid: false } as any,
    // Void today (MUST BE EXCLUDED)
    { id: 'inv-today-void', billNumber: 'B-VOID', date: '2026-09-18', totalAmount: 20000, status: 'Void', isVoid: true } as any,
    // 3 days ago (2026-09-15) - within last 7 days & this month
    { id: 'inv-week-1', billNumber: 'B3', date: '2026-09-15', totalAmount: 8000, status: 'Paid', isVoid: false } as any,
    // 10 days ago (2026-09-08) - outside last 7 days, but within this month
    { id: 'inv-month-1', billNumber: 'B4', date: '2026-09-08', totalAmount: 12000, status: 'Unpaid', isVoid: false } as any,
    // Last month (2026-08-25) - outside this month
    { id: 'inv-old', billNumber: 'B5', date: '2026-08-25', totalAmount: 50000, status: 'Paid', isVoid: false } as any,
  ];

  const testPayments: Payment[] = [
    // Today payment for inv-today-2
    { id: 'pay-today-1', invoiceId: 'inv-today-2', date: '2026-09-18', amount: 3000, isVoid: false } as any,
    // Today payment for inv-week-1
    { id: 'pay-today-2', invoiceId: 'inv-week-1', date: '2026-09-18', amount: 4000, isVoid: false } as any,
    // Void payment today (MUST BE EXCLUDED)
    { id: 'pay-today-void', invoiceId: 'inv-today-1', date: '2026-09-18', amount: 5000, isVoid: true } as any,
    // Payment for void invoice (MUST BE EXCLUDED)
    { id: 'pay-void-inv', invoiceId: 'inv-today-void', date: '2026-09-18', amount: 10000, isVoid: false } as any,
    // 4 days ago payment (2026-09-14)
    { id: 'pay-week-1', invoiceId: 'inv-week-1', date: '2026-09-14', amount: 4000, isVoid: false } as any,
    // 12 days ago payment (2026-09-06)
    { id: 'pay-month-1', invoiceId: 'inv-month-1', date: '2026-09-06', amount: 6000, isVoid: false } as any,
  ];

  const testExpenses: Expense[] = [
    // Today approved & executed expense
    { id: 'exp-today-1', date: '2026-09-18', amount: 2000, status: 'approved', executionStatus: 'executed' } as any,
    // Today executed status expense
    { id: 'exp-today-2', date: '2026-09-18', amount: 1500, status: 'executed' } as any,
    // Today pending expense (MUST BE EXCLUDED)
    { id: 'exp-today-pending', date: '2026-09-18', amount: 8000, status: 'pending_manager' } as any,
    // Today approved but unexecuted (MUST BE EXCLUDED)
    { id: 'exp-today-unexec', date: '2026-09-18', amount: 4000, status: 'approved', executionStatus: 'pending' } as any,
    // Today rejected (MUST BE EXCLUDED)
    { id: 'exp-today-rej', date: '2026-09-18', amount: 9000, status: 'rejected' } as any,
    // 2 days ago approved & executed
    { id: 'exp-week-1', date: '2026-09-16', amount: 3000, status: 'approved', executionStatus: 'executed' } as any,
    // 15 days ago approved & executed
    { id: 'exp-month-1', date: '2026-09-03', amount: 5000, status: 'executed' } as any,
  ];

  const result = calculateFinancialPerformance({
    invoices: testInvoices,
    payments: testPayments,
    expenses: testExpenses,
    referenceDate: refDate,
  });

  // Daily Checks:
  // Sales: inv-today-1 (10,000) + inv-today-2 (5,000) = 15,000 (inv-today-void excluded)
  assert('Daily Sales calculates only valid non-void invoices', result.daily.sales, 15000);
  assert('Daily Invoices count', result.daily.invoicesCount, 2);

  // Payments: pay-today-1 (3,000) + pay-today-2 (4,000) = 7,000 (void payment & void inv payment excluded)
  assert('Daily Payments calculates only valid payments for valid invoices', result.daily.payments, 7000);
  assert('Daily Payments count', result.daily.paymentsCount, 2);

  // Expenses: exp-today-1 (2,000) + exp-today-2 (1,500) = 3,500 (pending, unexecuted, rejected excluded)
  assert('Daily Expenses includes ONLY approved AND executed', result.daily.expenses, 3500);

  // Net: Sales (15,000) - Expenses (3,500) = 11,500
  assert('Daily Net Result = Sales - Expenses', result.daily.net, 11500);

  // Last 7 Days Checks:
  // Sales: today (15,000) + inv-week-1 (8,000) = 23,000
  assert('Last 7 Days Sales', result.weekly.sales, 23000);

  // Payments: today (7,000) + pay-week-1 (4,000) = 11,000
  assert('Last 7 Days Payments', result.weekly.payments, 11000);

  // Expenses: today (3,500) + exp-week-1 (3,000) = 6,500
  assert('Last 7 Days Expenses', result.weekly.expenses, 6500);

  // Net: 23,000 - 6,500 = 16,500
  assert('Last 7 Days Net Result', result.weekly.net, 16500);

  // This Month Checks:
  // Sales: today (15,000) + week (8,000) + inv-month-1 (12,000) = 35,000
  assert('This Month Sales', result.monthly.sales, 35000);

  // Payments: today (7,000) + week (4,000) + pay-month-1 (6,000) = 17,000
  assert('This Month Payments', result.monthly.payments, 17000);

  // Expenses: today (3,500) + week (3,000) + exp-month-1 (5,000) = 11,500
  assert('This Month Expenses', result.monthly.expenses, 11500);

  // Net: 35,000 - 11,500 = 23,500
  assert('This Month Net Result', result.monthly.net, 23500);

  // 7. Format AFN test
  assert('formatAFN formats with currency prefix', formatAFN(125000, true), 'AFN 125,000');

  const passedCount = results.filter((r) => r.passed).length;
  const failedCount = results.filter((r) => !r.passed).length;
  const passed = failedCount === 0;

  console.log('===============================================================');
  console.log('       FINANCIAL PERFORMANCE TEST RESULTS');
  console.log('===============================================================');
  for (const r of results) {
    console.log(`${r.passed ? '[✓ PASS]' : '[✗ FAIL]'} ${r.name}`);
    if (!r.passed) {
      console.log(`   Expected: ${JSON.stringify(r.expected)}, Actual: ${JSON.stringify(r.actual)}`);
    }
  }
  console.log('---------------------------------------------------------------');
  console.log(`TOTAL: ${passedCount}/${results.length} Tests Passed`);
  console.log(`OVERALL STATUS: ${passed ? 'ALL TESTS PASSED' : 'SOME TESTS FAILED'}`);
  console.log('===============================================================\n');

  return { passed, total: results.length, passedCount, failedCount };
}

if (import.meta.url === `file://${process.argv[1]}`) {
  const result = runFinancialPerformanceTests();
  if (!result.passed) {
    process.exit(1);
  }
}
