import { Invoice, Payment } from '../types';
import { getTodayDateString } from './format';
import {
  calculateSingleInvoiceStatus,
  getValidPaymentsPerInvoice,
  isValidInvoice,
  InvoiceCalculatedStatus,
} from './invoiceCalculator';

export type RecentInvoiceStatus = InvoiceCalculatedStatus;

export interface RecentInvoiceItem {
  invoice: Invoice;
  calculatedStatus: RecentInvoiceStatus;
  totalAmount: number;
  paidAmount: number;
  remainingAmount: number;
}

/**
 * Safely extracts a numeric epoch millisecond timestamp for an invoice's creation date.
 * Supports:
 * - ISO 8601 string (e.g. '2026-09-18T12:00:00.000Z')
 * - YYYY-MM-DD string
 * - Firestore Timestamp objects with toMillis() or toDate()
 * - Firestore Timestamp-like objects with { seconds, nanoseconds }
 * - JS Date instances
 * - Numeric epoch values
 * - Fallback to invoice.date
 * - Safe return of 0 for invalid/missing values to prevent crashes
 */
export function getInvoiceCreationTimestamp(inv: Partial<Invoice> | null | undefined): number {
  if (!inv) return 0;
  const raw: any = inv.createdAt;

  if (raw !== null && raw !== undefined && raw !== '') {
    // 1. Direct number
    if (typeof raw === 'number' && Number.isFinite(raw)) {
      return raw;
    }

    // 2. Object formats (Firestore Timestamp, JS Date)
    if (typeof raw === 'object') {
      if (typeof raw.toMillis === 'function') {
        try {
          const ms = raw.toMillis();
          if (typeof ms === 'number' && Number.isFinite(ms)) return ms;
        } catch {
          // Fall through
        }
      }
      if (typeof raw.toDate === 'function') {
        try {
          const d = raw.toDate();
          if (d instanceof Date && !isNaN(d.getTime())) return d.getTime();
        } catch {
          // Fall through
        }
      }
      if ('seconds' in raw && typeof raw.seconds === 'number') {
        const s = raw.seconds;
        const ns = typeof raw.nanoseconds === 'number' ? raw.nanoseconds : 0;
        return s * 1000 + Math.floor(ns / 1000000);
      }
      if (raw instanceof Date) {
        const t = raw.getTime();
        if (!isNaN(t)) return t;
      }
    }

    // 3. String formats
    if (typeof raw === 'string') {
      const trimmed = raw.trim();
      if (trimmed) {
        const parsed = Date.parse(trimmed);
        if (!isNaN(parsed)) return parsed;

        const num = Number(trimmed);
        if (Number.isFinite(num) && num > 0) return num;
      }
    }
  }

  // Fallback to inv.date
  if (inv.date && typeof inv.date === 'string') {
    const parsedDate = Date.parse(inv.date.trim());
    if (!isNaN(parsedDate)) return parsedDate;
  }

  return 0;
}

/**
 * Validates whether an invoice record is active and valid for Recent Invoices.
 * Excludes:
 * - isVoid === true
 * - status === 'Void'
 * - deleted / non-existent records
 * - demo / fake records
 */
export function isValidRecentInvoice(inv: unknown): inv is Invoice {
  return isValidInvoice(inv);
}

/**
 * Calculates the exact dynamic status of an invoice according to business rules:
 * Valid Paid Amount = SUM(all payment.amount belonging to this invoice where payment.isVoid !== true)
 * Priority: Paid → Overdue → Partially Paid → Unpaid
 *
 * - Paid: Valid Paid Amount >= Invoice Total (Paid has priority over Overdue, even if due date passed)
 * - Overdue: Valid Paid Amount < Invoice Total AND outstanding balance exists AND due date has passed
 * - Partially Paid: Valid Paid Amount > 0 AND Valid Paid Amount < Invoice Total AND not overdue
 * - Unpaid: Valid Paid Amount === 0 AND not overdue
 */
export function calculateInvoiceRecentStatus(
  inv: Invoice,
  payments: Payment[] = [],
  todayDateStr?: string
): {
  status: RecentInvoiceStatus;
  totalAmount: number;
  paidAmount: number;
  remainingAmount: number;
} {
  const { paymentsByInvoiceId, paymentsByBillNumber } = getValidPaymentsPerInvoice(
    [inv],
    payments
  );
  const paymentFromId = inv.id ? paymentsByInvoiceId.get(inv.id) : undefined;
  const paymentFromBill = inv.billNumber ? paymentsByBillNumber.get(inv.billNumber) : undefined;

  let paidAmount = 0;
  if (paymentFromId !== undefined) {
    paidAmount = paymentFromId;
  } else if (paymentFromBill !== undefined) {
    paidAmount = paymentFromBill;
  } else if (!Array.isArray(payments) && Number(inv.totalPaid) > 0) {
    paidAmount = Number(inv.totalPaid) || 0;
  } else {
    paidAmount = 0;
  }

  const res = calculateSingleInvoiceStatus(inv, paidAmount, todayDateStr);
  return {
    status: res.status,
    totalAmount: res.totalAmount,
    paidAmount: res.paidAmount,
    remainingAmount: res.outstanding,
  };
}

/**
 * Returns the 8 most recently created valid invoices, sorted Newest → Oldest by creation timestamp,
 * with real-time calculated status and monetary values.
 *
 * Sequence:
 * 1. Filter out void/deleted/demo invoices
 * 2. Sort the complete valid invoice collection by createdAt descending
 * 3. Take the first 8 records ONLY after sorting
 * 4. Calculate real-time Paid / Overdue / Partially Paid / Unpaid status for each invoice
 */
export function getRecentInvoices(
  invoices: Invoice[] = [],
  payments: Payment[] = [],
  limit: number = 8,
  todayDateStr?: string
): RecentInvoiceItem[] {
  if (!Array.isArray(invoices)) return [];

  // 1. Exclude void/deleted invoices
  const validInvoices = invoices.filter(isValidRecentInvoice);

  // 2. Sort by actual creation timestamp descending (Newest → Oldest)
  const sorted = [...validInvoices].sort((a, b) => {
    const timeB = getInvoiceCreationTimestamp(b);
    const timeA = getInvoiceCreationTimestamp(a);
    if (timeB !== timeA) {
      return timeB - timeA;
    }
    // Deterministic tie-breaker
    return String(b.billNumber || b.id).localeCompare(String(a.billNumber || a.id));
  });

  // 3. Take top N only AFTER sorting
  const topInvoices = sorted.slice(0, limit);

  // Index payments once for fast, efficient lookup
  const { paymentsByInvoiceId, paymentsByBillNumber } = getValidPaymentsPerInvoice(
    invoices,
    payments
  );
  const hasPaymentsArray = Array.isArray(payments);

  // 4. Calculate status for each invoice using the shared calculator
  return topInvoices.map((inv) => {
    let paidAmount = 0;
    const paymentFromId = inv.id ? paymentsByInvoiceId.get(inv.id) : undefined;
    const paymentFromBill = inv.billNumber ? paymentsByBillNumber.get(inv.billNumber) : undefined;

    if (paymentFromId !== undefined) {
      paidAmount = paymentFromId;
    } else if (paymentFromBill !== undefined) {
      paidAmount = paymentFromBill;
    } else if (!hasPaymentsArray && Number(inv.totalPaid) > 0) {
      paidAmount = Number(inv.totalPaid) || 0;
    } else {
      paidAmount = 0;
    }

    const res = calculateSingleInvoiceStatus(inv, paidAmount, todayDateStr);
    return {
      invoice: inv,
      calculatedStatus: res.status,
      totalAmount: res.totalAmount,
      paidAmount: res.paidAmount,
      remainingAmount: res.outstanding,
    };
  });
}
