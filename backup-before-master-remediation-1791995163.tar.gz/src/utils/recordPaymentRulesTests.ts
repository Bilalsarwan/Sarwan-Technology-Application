/**
 * Comprehensive Test Suite for Record Payment Rules
 *
 * Requirements Tested:
 * 1. Payment Date Rule:
 *    - Default Payment Date = today
 *    - Allow today and any previous date (Payment Date <= Today)
 *    - Reject tomorrow and any future date
 *    - Service layer validation rejects API/manual bypass requests
 *
 * 2. Payment Method Architecture:
 *    - Keep Cash as the only currently active Payment Method
 *    - Architecture extensible for future methods (Bank Transfer, Mobile Money, Card)
 *    - Preserves existing CASH behavior and compatibility with existing records
 *
 * 3. Payment Note:
 *    - Genuinely optional
 *    - Note entered -> exact note saved
 *    - Note empty -> empty string saved (no artificial defaults like 'Cash received in shop')
 *
 * 4. Atomic Payment + Invoice Update:
 *    - All 13 steps verified
 *    - Excludes voided payments from authoritative calculation
 *    - Overpayment protection
 *    - Fully paid invoice protection
 *    - Zero/negative amount rejection
 *    - Rollback scenarios: payment failure, invoice update failure, audit failure
 *    - No partial financial state remains
 */

import { Invoice, Payment, AuditLog, PaymentMethod } from '../types';
import { getTodayDateString } from './format';
import {
  validatePaymentDate,
  validatePaymentMethod,
  sanitizePaymentNote,
  calculateAuthoritativeBalance,
  calculateNewInvoiceFinancials,
  validatePaymentPermissions,
} from './paymentValidation';
import {
  executeAtomicRecordPayment,
  RecordPaymentParams,
  TransactionContext,
} from './paymentTransaction';

let passedTests = 0;
let totalTests = 0;

function assert(condition: boolean, testName: string, detail?: string) {
  totalTests++;
  if (condition) {
    passedTests++;
    console.log(`  ✓ [PASS] ${testName}`);
  } else {
    console.error(`  ✗ [FAIL] ${testName}${detail ? ` - ${detail}` : ''}`);
    throw new Error(`Assertion failed: ${testName}`);
  }
}

// Helper to create mock invoice
function createMockInvoice(overrides?: Partial<Invoice>): Invoice {
  return {
    id: 'inv-test-101',
    billNumber: 'ST-101',
    customerId: 'cust-1',
    customerSnapshot: {
      id: 'cust-1',
      name: 'Ahmad Reshad',
      phone: '0799123456',
      email: 'ahmad@example.com',
      companyName: 'Kabul Trading',
      address: 'Kabul, Afghanistan',
    },
    companySnapshot: {
      companyName: 'Sarwan Technology',
      logo: '',
      phone: '0700000000',
      whatsapp: '0700000000',
      email: 'info@sarwan.af',
      address: 'Kabul',
      currency: 'AFN',
      invoiceNote: '',
    },
    date: '2026-10-01',
    items: [
      { sNo: 1, description: 'Web Development', quantity: 1, unitPrice: 10000, totalAmount: 10000 },
    ],
    note: '',
    totalAmount: 10000,
    totalPaid: 0,
    remaining: 10000,
    status: 'Unpaid',
    createdAt: '2026-10-01T10:00:00.000Z',
    updatedAt: '2026-10-01T10:00:00.000Z',
    ...overrides,
  };
}

async function runAllTests() {
  console.log('\n======================================================');
  console.log('RECORD PAYMENT RULES & ATOMIC TRANSACTION TEST SUITE');
  console.log('======================================================\n');

  const todayStr = getTodayDateString();
  const yesterdayDate = new Date();
  yesterdayDate.setDate(yesterdayDate.getDate() - 1);
  const yesterdayStr = yesterdayDate.toISOString().split('T')[0];

  const tomorrowDate = new Date();
  tomorrowDate.setDate(tomorrowDate.getDate() + 1);
  const tomorrowStr = tomorrowDate.toISOString().split('T')[0];

  const futureDate = '2099-12-31';
  const pastDate = '2020-01-15';

  // =========================================================================
  // 1. PAYMENT DATE VALIDATION TESTS
  // =========================================================================
  console.log('--- 1. Payment Date Rule (Payment Date <= Today) ---');

  // Test 1.1: Today's date is allowed
  const todayResult = validatePaymentDate(todayStr, todayStr);
  assert(todayResult.isValid === true && todayResult.normalizedDate === todayStr, 'Payment Date: Today is allowed');

  // Test 1.2: Yesterday's date is allowed
  const yesterdayResult = validatePaymentDate(yesterdayStr, todayStr);
  assert(yesterdayResult.isValid === true && yesterdayResult.normalizedDate === yesterdayStr, 'Payment Date: Yesterday is allowed');

  // Test 1.3: Distant past date is allowed
  const pastResult = validatePaymentDate(pastDate, todayStr);
  assert(pastResult.isValid === true && pastResult.normalizedDate === pastDate, 'Payment Date: Older date (2020-01-15) is allowed');

  // Test 1.4: Tomorrow is strictly rejected
  const tomorrowResult = validatePaymentDate(tomorrowStr, todayStr);
  assert(tomorrowResult.isValid === false, 'Payment Date: Tomorrow is rejected');
  assert(Boolean(tomorrowResult.error?.includes('future')), 'Payment Date: Tomorrow error message indicates future date');

  // Test 1.5: Far future date (2099-12-31) is strictly rejected
  const futureResult = validatePaymentDate(futureDate, todayStr);
  assert(futureResult.isValid === false, 'Payment Date: Far future date (2099-12-31) is rejected');

  // Test 1.6: Empty/missing date defaults/flags required
  const emptyDateResult = validatePaymentDate('', todayStr);
  assert(emptyDateResult.isValid === false, 'Payment Date: Empty string is rejected');

  // Test 1.7: ISO date string with timestamp normalization
  const isoPast = `${pastDate}T14:30:00.000Z`;
  const isoResult = validatePaymentDate(isoPast, todayStr);
  assert(isoResult.isValid === true && isoResult.normalizedDate === pastDate, 'Payment Date: ISO timestamp string normalized correctly');

  // =========================================================================
  // 2. PAYMENT METHOD ARCHITECTURE TESTS
  // =========================================================================
  console.log('\n--- 2. Payment Method Architecture ---');

  // Test 2.1: Default method is Cash
  const defaultMethod = validatePaymentMethod();
  assert(defaultMethod.isValid === true && defaultMethod.method === 'CASH', 'Payment Method: Default is CASH');

  // Test 2.2: Explicit Cash is allowed
  const cashMethod = validatePaymentMethod('CASH');
  assert(cashMethod.isValid === true && cashMethod.method === 'CASH', 'Payment Method: CASH is valid and active');

  // Test 2.3: Lowercase 'cash' is normalized to CASH
  const lowerCashMethod = validatePaymentMethod('cash');
  assert(lowerCashMethod.isValid === true && lowerCashMethod.method === 'CASH', 'Payment Method: Lowercase "cash" normalizes to CASH');

  // Test 2.4: Future methods (Bank Transfer, Mobile Money, Card) are supported in architecture but rejected in current phase
  const bankTransferMethod = validatePaymentMethod('BANK_TRANSFER');
  assert(
    bankTransferMethod.isValid === false && Boolean(bankTransferMethod.error?.includes('not currently active')),
    'Payment Method: BANK_TRANSFER recognized as supported but inactive in current phase'
  );

  const mobileMoneyMethod = validatePaymentMethod('MOBILE_MONEY');
  assert(
    mobileMoneyMethod.isValid === false && Boolean(mobileMoneyMethod.error?.includes('not currently active')),
    'Payment Method: MOBILE_MONEY recognized as supported but inactive in current phase'
  );

  const cardMethod = validatePaymentMethod('CARD');
  assert(
    cardMethod.isValid === false && Boolean(cardMethod.error?.includes('not currently active')),
    'Payment Method: CARD recognized as supported but inactive in current phase'
  );

  // Test 2.5: Unknown/unsupported payment method is rejected
  const invalidMethod = validatePaymentMethod('CRYPTO_COIN');
  assert(
    invalidMethod.isValid === false && Boolean(invalidMethod.error?.includes('Unsupported payment method')),
    'Payment Method: Unsupported method CRYPTO_COIN is rejected'
  );

  // =========================================================================
  // 3. PAYMENT NOTE TESTS
  // =========================================================================
  console.log('\n--- 3. Payment Note (Genuinely Optional & No Artificial Defaults) ---');

  // Test 3.1: Note entered -> exact note saved
  const userNote = 'Paid in cash by Ahmad at reception counter';
  const savedNote = sanitizePaymentNote(userNote);
  assert(savedNote === userNote, 'Payment Note: User note saved verbatim');

  // Test 3.2: Note empty -> returns empty string (no artificial defaults)
  const emptyNote1 = sanitizePaymentNote('');
  assert(emptyNote1 === '', 'Payment Note: Empty string saves empty string');

  const emptyNote2 = sanitizePaymentNote(undefined);
  assert(emptyNote2 === '', 'Payment Note: Undefined note saves empty string');

  const emptyNote3 = sanitizePaymentNote(null);
  assert(emptyNote3 === '', 'Payment Note: Null note saves empty string');

  const emptyNote4 = sanitizePaymentNote('    ');
  assert(emptyNote4 === '', 'Payment Note: Whitespace-only note saves empty string');

  // Test 3.3: Verify artificial default text is NEVER returned
  assert(emptyNote1 !== 'Cash received in shop', 'Payment Note: Artificial "Cash received in shop" is NOT saved');
  assert(emptyNote1 !== 'Cash Payment Received', 'Payment Note: Artificial "Cash Payment Received" is NOT saved');

  // =========================================================================
  // 4. ATOMIC PAYMENT + INVOICE UPDATE: CALCULATION & INVARIANTS
  // =========================================================================
  console.log('\n--- 4. Authoritative Calculation & Financial Logic ---');

  const testInvoice = createMockInvoice({ totalAmount: 10000 });
  const existingPayments: Payment[] = [
    {
      id: 'p-1',
      invoiceId: testInvoice.id,
      billNumber: testInvoice.billNumber,
      customerId: testInvoice.customerId,
      customerName: 'Customer',
      amount: 3000,
      date: '2026-10-02',
      method: 'CASH',
      createdAt: '2026-10-02T10:00:00.000Z',
    },
    {
      id: 'p-2-void',
      invoiceId: testInvoice.id,
      billNumber: testInvoice.billNumber,
      customerId: testInvoice.customerId,
      customerName: 'Customer',
      amount: 5000,
      date: '2026-10-03',
      method: 'CASH',
      isVoid: true, // VOIDED - MUST BE EXCLUDED
      createdAt: '2026-10-03T10:00:00.000Z',
    },
  ];

  // Test 4.1: Authoritative balance calculation strictly excludes voided payments
  const authBalance = calculateAuthoritativeBalance(testInvoice.totalAmount, existingPayments);
  assert(authBalance.authoritativeTotalPaid === 3000, 'Authoritative Paid: Excludes voided payments (3,000 AFN, not 8,000)');
  assert(authBalance.remainingBalance === 7000, 'Authoritative Remaining: 7,000 AFN remaining (10,000 - 3,000)');

  // Test 4.2: Partial payment state calculation
  const partialFinancials = calculateNewInvoiceFinancials(10000, 3000, 2000);
  assert(partialFinancials.newTotalPaid === 5000, 'Financials: New Total Paid is 5,000 AFN');
  assert(partialFinancials.newRemaining === 5000, 'Financials: New Remaining is 5,000 AFN');
  assert(partialFinancials.newStatus === 'Partially Paid', 'Financials: Status is Partially Paid');
  assert(partialFinancials.isLocked === false, 'Financials: Invoice remains unlocked');

  // Test 4.3: Final full payment state calculation
  const fullFinancials = calculateNewInvoiceFinancials(10000, 5000, 5000);
  assert(fullFinancials.newTotalPaid === 10000, 'Financials: Full payment Total Paid is 10,000 AFN');
  assert(fullFinancials.newRemaining === 0, 'Financials: Full payment Remaining is 0 AFN');
  assert(fullFinancials.newStatus === 'Paid', 'Financials: Full payment Status is Paid');
  assert(fullFinancials.isLocked === true, 'Financials: Full payment locks invoice');

  // =========================================================================
  // 5. ATOMIC EXECUTION & TRANSACTION SIMULATION
  // =========================================================================
  console.log('\n--- 5. Atomic Execution & Rollback Simulation ---');

  // Simulated transactional database engine
  class MockDatabaseEngine {
    invoices = new Map<string, Invoice>();
    payments = new Map<string, Payment>();
    auditLogs = new Map<string, AuditLog>();

    constructor(initialInvoice: Invoice, initialPayments: Payment[] = []) {
      this.invoices.set(initialInvoice.id, JSON.parse(JSON.stringify(initialInvoice)));
      for (const p of initialPayments) {
        this.payments.set(p.id, JSON.parse(JSON.stringify(p)));
      }
    }

    // Executes a transaction. If any operation throws, mutations staged in the transaction are rolled back.
    async runTransaction<T>(
      operation: (ctx: TransactionContext) => Promise<T>,
      options?: {
        failAtStep?: 'setPayment' | 'updateInvoice' | 'addAuditLog';
      }
    ): Promise<T> {
      // Working staging snapshot
      const stagedInvoices = new Map(this.invoices);
      const stagedPayments = new Map(this.payments);
      const stagedAuditLogs = new Map(this.auditLogs);

      const ctx: TransactionContext = {
        getInvoice: async (id: string) => {
          const inv = stagedInvoices.get(id);
          return inv ? JSON.parse(JSON.stringify(inv)) : null;
        },
        setPayment: async (payment: Payment) => {
          if (options?.failAtStep === 'setPayment') {
            throw new Error('Simulated atomic failure during setPayment write');
          }
          stagedPayments.set(payment.id, JSON.parse(JSON.stringify(payment)));
        },
        updateInvoice: async (id: string, updates: Partial<Invoice>) => {
          if (options?.failAtStep === 'updateInvoice') {
            throw new Error('Simulated atomic failure during updateInvoice write');
          }
          const existing = stagedInvoices.get(id);
          if (!existing) throw new Error('Invoice not found in transaction');
          stagedInvoices.set(id, { ...existing, ...updates });
        },
        addAuditLog: async (log: AuditLog) => {
          if (options?.failAtStep === 'addAuditLog') {
            throw new Error('Simulated atomic failure during addAuditLog write');
          }
          stagedAuditLogs.set(log.id, JSON.parse(JSON.stringify(log)));
        },
      };

      try {
        const result = await operation(ctx);
        // ATOMIC COMMIT: Staged changes replace live state only if all steps succeed
        this.invoices = stagedInvoices;
        this.payments = stagedPayments;
        this.auditLogs = stagedAuditLogs;
        return result;
      } catch (err) {
        // ATOMIC ROLLBACK: Discard all staged changes, leaving original state untouched
        throw err;
      }
    }
  }

  // Test 5.1: Successful atomic partial payment
  const initialInvoice1 = createMockInvoice({ totalAmount: 10000, totalPaid: 0, remaining: 10000, status: 'Unpaid' });
  const mockDb1 = new MockDatabaseEngine(initialInvoice1);

  const partialParam: RecordPaymentParams = {
    invoiceId: initialInvoice1.id,
    amount: 4000,
    date: todayStr,
    note: 'Initial deposit',
    userId: 'admin-1',
    userName: 'Admin User',
    userRole: 'super_admin',
  };

  const result1 = await mockDb1.runTransaction((ctx) =>
    executeAtomicRecordPayment(ctx, partialParam, [], { referenceTodayStr: todayStr })
  );

  assert(result1.payment.amount === 4000, 'Atomic Run 1: Payment created with AFN 4,000');
  assert(result1.payment.note === 'Initial deposit', 'Atomic Run 1: Note saved as "Initial deposit"');
  assert(result1.updatedInvoice.totalPaid === 4000, 'Atomic Run 1: Invoice totalPaid updated to 4,000');
  assert(result1.updatedInvoice.remaining === 6000, 'Atomic Run 1: Invoice remaining updated to 6,000');
  assert(result1.updatedInvoice.status === 'Partially Paid', 'Atomic Run 1: Invoice status updated to Partially Paid');
  assert(mockDb1.payments.size === 1, 'Atomic Run 1: Exactly 1 payment in DB');
  assert(mockDb1.auditLogs.size === 1, 'Atomic Run 1: Exactly 1 audit log in DB');

  // Test 5.2: Successful atomic final payment (settling balance to 0)
  const remainingPayments = Array.from(mockDb1.payments.values());
  const finalParam: RecordPaymentParams = {
    invoiceId: initialInvoice1.id,
    amount: 6000,
    date: todayStr,
    note: '', // Empty note -> must save empty
    userId: 'admin-1',
    userName: 'Admin User',
    userRole: 'super_admin',
  };

  const result2 = await mockDb1.runTransaction((ctx) =>
    executeAtomicRecordPayment(ctx, finalParam, remainingPayments, { referenceTodayStr: todayStr })
  );

  assert(result2.payment.amount === 6000, 'Atomic Run 2: Final payment AFN 6,000 created');
  assert(result2.payment.note === '', 'Atomic Run 2: Empty note saved as empty string');
  assert(result2.updatedInvoice.totalPaid === 10000, 'Atomic Run 2: Invoice totalPaid is 10,000');
  assert(result2.updatedInvoice.remaining === 0, 'Atomic Run 2: Invoice remaining is 0');
  assert(result2.updatedInvoice.status === 'Paid', 'Atomic Run 2: Invoice status is Paid');
  assert(result2.updatedInvoice.isLocked === true, 'Atomic Run 2: Invoice is locked');
  assert(result2.auditLogs.length === 2, 'Atomic Run 2: 2 audit logs produced (payment + fully paid)');

  // Test 5.3: Overpayment prevention in atomic operation
  let overpayErrorCaught = false;
  try {
    const allPaymentsSettled = Array.from(mockDb1.payments.values());
    await mockDb1.runTransaction((ctx) =>
      executeAtomicRecordPayment(
        ctx,
        {
          invoiceId: initialInvoice1.id,
          amount: 500,
          date: todayStr,
          userId: 'admin-1',
          userRole: 'super_admin',
        },
        allPaymentsSettled,
        { referenceTodayStr: todayStr }
      )
    );
  } catch (err: any) {
    overpayErrorCaught = true;
    assert(err.message.includes('already fully paid'), 'Overpayment Check: Correctly rejected fully paid invoice');
  }
  assert(overpayErrorCaught, 'Overpayment Check: Error thrown for fully paid invoice');

  // Test 5.4: Future date rejected in atomic operation
  let futureDateErrorCaught = false;
  try {
    const invoiceForDateTest = createMockInvoice();
    const mockDbDate = new MockDatabaseEngine(invoiceForDateTest);
    await mockDbDate.runTransaction((ctx) =>
      executeAtomicRecordPayment(
        ctx,
        {
          invoiceId: invoiceForDateTest.id,
          amount: 1000,
          date: tomorrowStr, // FUTURE DATE
          userId: 'admin-1',
          userRole: 'super_admin',
        },
        [],
        { referenceTodayStr: todayStr }
      )
    );
  } catch (err: any) {
    futureDateErrorCaught = true;
    assert(err.message.includes('future'), 'Atomic Date Check: Error message specifies future date');
  }
  assert(futureDateErrorCaught, 'Atomic Date Check: Future date rejected inside transaction execution');

  // Test 5.5: Zero or negative payment rejected
  let negativeAmtError = false;
  try {
    const invTest = createMockInvoice();
    const mockDbAmt = new MockDatabaseEngine(invTest);
    await mockDbAmt.runTransaction((ctx) =>
      executeAtomicRecordPayment(
        ctx,
        {
          invoiceId: invTest.id,
          amount: -500,
          date: todayStr,
          userId: 'admin-1',
          userRole: 'super_admin',
        },
        [],
        { referenceTodayStr: todayStr }
      )
    );
  } catch (err: any) {
    negativeAmtError = true;
    assert(err.message.includes('greater than zero'), 'Amount Check: Negative amount rejected');
  }
  assert(negativeAmtError, 'Amount Check: Non-positive amount rejected');

  // Test 5.6: Customer role rejected (Access Denied)
  let customerDenied = false;
  try {
    const invTest = createMockInvoice();
    const mockDbCust = new MockDatabaseEngine(invTest);
    await mockDbCust.runTransaction((ctx) =>
      executeAtomicRecordPayment(
        ctx,
        {
          invoiceId: invTest.id,
          amount: 500,
          date: todayStr,
          userId: 'cust-1',
          userRole: 'customer',
        },
        [],
        { referenceTodayStr: todayStr }
      )
    );
  } catch (err: any) {
    customerDenied = true;
    assert(err.message.includes('Customers are not permitted'), 'Role Check: Customers cannot record payments');
  }
  assert(customerDenied, 'Role Check: Customer role correctly denied');

  // Test 5.7: Payment Collector scope restriction
  let collectorDenied = false;
  try {
    const invTest = createMockInvoice({ assignedCollectorId: 'collector-A', assignedCollectorName: 'Collector A' });
    const mockDbColl = new MockDatabaseEngine(invTest);
    await mockDbColl.runTransaction((ctx) =>
      executeAtomicRecordPayment(
        ctx,
        {
          invoiceId: invTest.id,
          amount: 500,
          date: todayStr,
          userId: 'collector-B', // DIFFERENT COLLECTOR
          userName: 'Collector B',
          userRole: 'payment_collector',
        },
        [],
        { referenceTodayStr: todayStr }
      )
    );
  } catch (err: any) {
    collectorDenied = true;
    assert(err.message.includes('only authorized to record payments for invoices assigned to you'), 'Collector Scope: Unassigned collector denied');
  }
  assert(collectorDenied, 'Collector Scope: Correctly blocked unauthorized collector');

  // =========================================================================
  // 6. ATOMICITY ROLLBACK FAILURE SCENARIOS (CRITICAL)
  // =========================================================================
  console.log('\n--- 6. Atomicity Rollback Tests (Failure Scenarios) ---');

  // Scenario 6.1: Invoice update fails during transaction -> NO payment or audit log must remain
  const testInvRollback1 = createMockInvoice({ totalAmount: 10000, totalPaid: 0, remaining: 10000 });
  const mockDbRollback1 = new MockDatabaseEngine(testInvRollback1);

  let rollback1Caught = false;
  try {
    await mockDbRollback1.runTransaction(
      (ctx) =>
        executeAtomicRecordPayment(
          ctx,
          {
            invoiceId: testInvRollback1.id,
            amount: 2500,
            date: todayStr,
            userId: 'admin-1',
            userRole: 'super_admin',
          },
          [],
          { referenceTodayStr: todayStr }
        ),
      { failAtStep: 'updateInvoice' } // INVOICE UPDATE FAILS
    );
  } catch (err: any) {
    rollback1Caught = true;
  }
  assert(rollback1Caught, 'Rollback Scenario 1: Failure was caught');
  assert(mockDbRollback1.payments.size === 0, 'Rollback Scenario 1: NO payment record was committed (clean rollback)');
  assert(mockDbRollback1.invoices.get(testInvRollback1.id)?.totalPaid === 0, 'Rollback Scenario 1: Invoice totalPaid untouched (0)');
  assert(mockDbRollback1.invoices.get(testInvRollback1.id)?.remaining === 10000, 'Rollback Scenario 1: Invoice remaining untouched (10,000)');
  assert(mockDbRollback1.auditLogs.size === 0, 'Rollback Scenario 1: NO audit logs committed');

  // Scenario 6.2: Payment creation fails -> NO invoice update or audit log must remain
  const testInvRollback2 = createMockInvoice({ totalAmount: 8000, totalPaid: 0, remaining: 8000 });
  const mockDbRollback2 = new MockDatabaseEngine(testInvRollback2);

  let rollback2Caught = false;
  try {
    await mockDbRollback2.runTransaction(
      (ctx) =>
        executeAtomicRecordPayment(
          ctx,
          {
            invoiceId: testInvRollback2.id,
            amount: 3000,
            date: todayStr,
            userId: 'admin-1',
            userRole: 'super_admin',
          },
          [],
          { referenceTodayStr: todayStr }
        ),
      { failAtStep: 'setPayment' } // PAYMENT WRITE FAILS
    );
  } catch (err: any) {
    rollback2Caught = true;
  }
  assert(rollback2Caught, 'Rollback Scenario 2: Failure was caught');
  assert(mockDbRollback2.payments.size === 0, 'Rollback Scenario 2: NO payment committed');
  assert(mockDbRollback2.invoices.get(testInvRollback2.id)?.totalPaid === 0, 'Rollback Scenario 2: Invoice untouched (totalPaid: 0)');
  assert(mockDbRollback2.auditLogs.size === 0, 'Rollback Scenario 2: NO audit log committed');

  // Scenario 6.3: Audit log write fails -> entire operation rolled back
  const testInvRollback3 = createMockInvoice({ totalAmount: 5000, totalPaid: 0, remaining: 5000 });
  const mockDbRollback3 = new MockDatabaseEngine(testInvRollback3);

  let rollback3Caught = false;
  try {
    await mockDbRollback3.runTransaction(
      (ctx) =>
        executeAtomicRecordPayment(
          ctx,
          {
            invoiceId: testInvRollback3.id,
            amount: 1500,
            date: todayStr,
            userId: 'admin-1',
            userRole: 'super_admin',
          },
          [],
          { referenceTodayStr: todayStr }
        ),
      { failAtStep: 'addAuditLog' } // AUDIT WRITE FAILS
    );
  } catch (err: any) {
    rollback3Caught = true;
  }
  assert(rollback3Caught, 'Rollback Scenario 3: Failure was caught');
  assert(mockDbRollback3.payments.size === 0, 'Rollback Scenario 3: Payment rolled back when audit fails');
  assert(mockDbRollback3.invoices.get(testInvRollback3.id)?.totalPaid === 0, 'Rollback Scenario 3: Invoice rolled back when audit fails');
  assert(mockDbRollback3.auditLogs.size === 0, 'Rollback Scenario 3: Audit logs rolled back');

  console.log('\n======================================================');
  console.log(`ALL TESTS PASSED: ${passedTests}/${totalTests}`);
  console.log('======================================================\n');
}

runAllTests().catch((err) => {
  console.error('Test suite failed:', err);
  process.exit(1);
});
