import { Payment, Invoice, CustomerSnapshot, CompanySnapshot } from '../types';
import {
  getRecentPayments,
  getPaymentCreationTimestamp,
  getSafePaymentAmount,
  getPaymentCustomerName,
} from './recentPayments';
import { formatAFN, formatDate } from './format';

export interface TestCaseResult {
  name: string;
  passed: boolean;
  expected: any;
  actual: any;
  message?: string;
}

export interface TestSuiteResult {
  suiteName: string;
  passed: boolean;
  totalTests: number;
  passedTests: number;
  failedTests: number;
  results: TestCaseResult[];
}

const defaultCustomerSnapshot: CustomerSnapshot = {
  id: 'cust-1',
  name: 'Test Customer',
  companyName: 'Test Company',
  phone: '0700000000',
  email: 'test@example.com',
  address: 'Kabul, Afghanistan',
};

const defaultCompanySnapshot: CompanySnapshot = {
  companyName: 'Sarwan Technology',
  logo: '',
  phone: '0799999999',
  whatsapp: '0799999999',
  email: 'info@sarwan.af',
  address: 'Kabul, Afghanistan',
  currency: 'AFN',
  invoiceNote: 'Thank you for your business.',
};

function createTestInvoice(overrides: Partial<Invoice> = {}): Invoice {
  return {
    id: overrides.id || 'inv-' + Math.random().toString(36).substring(2, 9),
    billNumber: overrides.billNumber || 'BILL-001',
    customerId: overrides.customerId || 'cust-1',
    customerSnapshot: overrides.customerSnapshot || defaultCustomerSnapshot,
    companySnapshot: overrides.companySnapshot || defaultCompanySnapshot,
    date: overrides.date || '2026-09-01',
    dueDate: overrides.dueDate || '2026-10-01',
    items: overrides.items || [],
    totalAmount: overrides.totalAmount !== undefined ? overrides.totalAmount : 1000,
    note: overrides.note || '',
    status: overrides.status || 'Unpaid',
    createdAt: overrides.createdAt || '2026-09-01T10:00:00.000Z',
    updatedAt: overrides.updatedAt || '2026-09-01T10:00:00.000Z',
    isVoid: overrides.isVoid !== undefined ? overrides.isVoid : false,
    ...overrides,
  };
}

function createTestPayment(overrides: Partial<Payment> & Record<string, any> = {}): Payment {
  return {
    id: overrides.id || 'pay-' + Math.random().toString(36).substring(2, 9),
    invoiceId: overrides.invoiceId || 'inv-1',
    billNumber: overrides.billNumber || 'BILL-001',
    customerId: overrides.customerId || 'cust-1',
    customerName: overrides.customerName || 'Test Customer',
    amount: overrides.amount !== undefined ? overrides.amount : 500,
    date: overrides.date || '2026-09-05',
    note: overrides.note || 'Cash payment',
    method: 'CASH',
    createdAt: overrides.createdAt || '2026-09-05T10:00:00.000Z',
    isVoid: overrides.isVoid !== undefined ? overrides.isVoid : false,
    ...overrides,
  };
}

export function runAllRecentPaymentsTests(): {
  passed: boolean;
  suites: TestSuiteResult[];
  totalTests: number;
  passedTests: number;
  failedTests: number;
} {
  const suites: TestSuiteResult[] = [];

  // Suite 1: Ordering & Limit (Newest First, Exactly 8)
  {
    const suite: TestSuiteResult = {
      suiteName: 'Recent Cash Receipts Ordering & Limit',
      passed: true,
      totalTests: 0,
      passedTests: 0,
      failedTests: 0,
      results: [],
    };

    const activeInvoice = createTestInvoice({ id: 'inv-active', billNumber: 'BILL-ACT-1', isVoid: false });

    // Create 12 valid payments with differing creation times
    const payments: Payment[] = [
      createTestPayment({ id: 'pay-01', billNumber: 'BILL-001', createdAt: '2026-09-01T10:00:00.000Z', invoiceId: activeInvoice.id }),
      createTestPayment({ id: 'pay-02', billNumber: 'BILL-002', createdAt: '2026-09-02T10:00:00.000Z', invoiceId: activeInvoice.id }),
      createTestPayment({ id: 'pay-03', billNumber: 'BILL-003', createdAt: '2026-09-03T10:00:00.000Z', invoiceId: activeInvoice.id }),
      createTestPayment({ id: 'pay-04', billNumber: 'BILL-004', createdAt: '2026-09-04T10:00:00.000Z', invoiceId: activeInvoice.id }),
      createTestPayment({ id: 'pay-05', billNumber: 'BILL-005', createdAt: '2026-09-05T10:00:00.000Z', invoiceId: activeInvoice.id }),
      createTestPayment({ id: 'pay-06', billNumber: 'BILL-006', createdAt: '2026-09-06T10:00:00.000Z', invoiceId: activeInvoice.id }),
      createTestPayment({ id: 'pay-07', billNumber: 'BILL-007', createdAt: '2026-09-07T10:00:00.000Z', invoiceId: activeInvoice.id }),
      createTestPayment({ id: 'pay-08', billNumber: 'BILL-008', createdAt: '2026-09-08T10:00:00.000Z', invoiceId: activeInvoice.id }),
      createTestPayment({ id: 'pay-09', billNumber: 'BILL-009', createdAt: '2026-09-09T10:00:00.000Z', invoiceId: activeInvoice.id }),
      createTestPayment({ id: 'pay-10', billNumber: 'BILL-010', createdAt: '2026-09-10T10:00:00.000Z', invoiceId: activeInvoice.id }),
      createTestPayment({ id: 'pay-11', billNumber: 'BILL-011', createdAt: '2026-09-11T10:00:00.000Z', invoiceId: activeInvoice.id }),
      createTestPayment({ id: 'pay-12', billNumber: 'BILL-012', createdAt: '2026-09-12T10:00:00.000Z', invoiceId: activeInvoice.id }),
    ];

    const result = getRecentPayments(payments, [activeInvoice], 8);

    // Test 1: Exactly 8 records returned
    suite.results.push({
      name: 'Limits result to exactly 8 records',
      passed: result.length === 8,
      expected: 8,
      actual: result.length,
    });

    // Test 2: Newest payment (pay-12) appears first
    suite.results.push({
      name: 'Newest payment (pay-12) appears first in list',
      passed: result[0]?.id === 'pay-12',
      expected: 'pay-12',
      actual: result[0]?.id,
    });

    // Test 3: Oldest included is pay-05 (payments 1-4 are excluded by limit)
    suite.results.push({
      name: 'Oldest included payment is 8th newest (pay-05)',
      passed: result[7]?.id === 'pay-05',
      expected: 'pay-05',
      actual: result[7]?.id,
    });

    // Test 4: Chronological descending order across all 8 items
    let isStrictlyDescending = true;
    for (let i = 0; i < result.length - 1; i++) {
      const curTime = getPaymentCreationTimestamp(result[i]);
      const nextTime = getPaymentCreationTimestamp(result[i + 1]);
      if (curTime < nextTime) {
        isStrictlyDescending = false;
        break;
      }
    }
    suite.results.push({
      name: 'All 8 payments are strictly in descending chronological order',
      passed: isStrictlyDescending,
      expected: true,
      actual: isStrictlyDescending,
    });

    suite.totalTests = suite.results.length;
    suite.passedTests = suite.results.filter((r) => r.passed).length;
    suite.failedTests = suite.totalTests - suite.passedTests;
    suite.passed = suite.failedTests === 0;
    suites.push(suite);
  }

  // Suite 2: Void Payments Exclusion
  {
    const suite: TestSuiteResult = {
      suiteName: 'Void Payments Exclusion',
      passed: true,
      totalTests: 0,
      passedTests: 0,
      failedTests: 0,
      results: [],
    };

    const activeInvoice = createTestInvoice({ id: 'inv-act', billNumber: 'BILL-ACT', isVoid: false });

    const payments: Payment[] = [
      createTestPayment({
        id: 'pay-v1',
        billNumber: 'BILL-V1',
        createdAt: '2026-09-15T12:00:00.000Z',
        isVoid: true,
        invoiceId: activeInvoice.id,
      }),
      createTestPayment({
        id: 'pay-v2',
        billNumber: 'BILL-V2',
        createdAt: '2026-09-16T12:00:00.000Z',
        isVoid: false,
        status: 'Void' as any,
        invoiceId: activeInvoice.id,
      }),
      createTestPayment({
        id: 'pay-ok',
        billNumber: 'BILL-OK',
        createdAt: '2026-09-14T12:00:00.000Z',
        isVoid: false,
        invoiceId: activeInvoice.id,
      }),
    ];

    const result = getRecentPayments(payments, [activeInvoice], 8);

    // Test 1: isVoid: true is excluded
    const hasVoid1 = result.some((p) => p.id === 'pay-v1');
    suite.results.push({
      name: 'Payment with isVoid: true is completely excluded',
      passed: !hasVoid1,
      expected: false,
      actual: hasVoid1,
    });

    // Test 2: status: Void is excluded
    const hasVoid2 = result.some((p) => p.id === 'pay-v2');
    suite.results.push({
      name: 'Payment with status: "Void" is completely excluded',
      passed: !hasVoid2,
      expected: false,
      actual: hasVoid2,
    });

    // Test 3: Active payment is present
    const hasOk = result.some((p) => p.id === 'pay-ok');
    suite.results.push({
      name: 'Valid non-void payment is present',
      passed: hasOk,
      expected: true,
      actual: hasOk,
    });

    suite.totalTests = suite.results.length;
    suite.passedTests = suite.results.filter((r) => r.passed).length;
    suite.failedTests = suite.totalTests - suite.passedTests;
    suite.passed = suite.failedTests === 0;
    suites.push(suite);
  }

  // Suite 3: Payments Belonging to Void Invoices Exclusion
  {
    const suite: TestSuiteResult = {
      suiteName: 'Payments on Void Invoices Exclusion',
      passed: true,
      totalTests: 0,
      passedTests: 0,
      failedTests: 0,
      results: [],
    };

    const voidInvoice1 = createTestInvoice({
      id: 'inv-void-1',
      billNumber: 'BILL-VOID-1',
      isVoid: true,
    });
    const voidInvoice2 = createTestInvoice({
      id: 'inv-void-2',
      billNumber: 'BILL-VOID-2',
      isVoid: false,
      status: 'Void',
    });
    const activeInvoice = createTestInvoice({
      id: 'inv-active-1',
      billNumber: 'BILL-ACT-1',
      isVoid: false,
      status: 'Unpaid',
    });

    const paymentOnVoid1 = createTestPayment({
      id: 'pay-on-void-1',
      invoiceId: voidInvoice1.id,
      billNumber: voidInvoice1.billNumber,
      createdAt: '2026-09-16T10:00:00.000Z',
      isVoid: false,
    });
    const paymentOnVoid2 = createTestPayment({
      id: 'pay-on-void-2',
      invoiceId: voidInvoice2.id,
      billNumber: voidInvoice2.billNumber,
      createdAt: '2026-09-17T10:00:00.000Z',
      isVoid: false,
    });
    const paymentOnActive = createTestPayment({
      id: 'pay-on-active',
      invoiceId: activeInvoice.id,
      billNumber: activeInvoice.billNumber,
      createdAt: '2026-09-15T10:00:00.000Z',
      isVoid: false,
    });

    const result = getRecentPayments(
      [paymentOnVoid1, paymentOnVoid2, paymentOnActive],
      [voidInvoice1, voidInvoice2, activeInvoice],
      8
    );

    // Test 1: Payment on invoice with isVoid: true is excluded
    const hasP1 = result.some((p) => p.id === 'pay-on-void-1');
    suite.results.push({
      name: 'Payment on invoice with isVoid: true is excluded',
      passed: !hasP1,
      expected: false,
      actual: hasP1,
    });

    // Test 2: Payment on invoice with status: Void is excluded
    const hasP2 = result.some((p) => p.id === 'pay-on-void-2');
    suite.results.push({
      name: 'Payment on invoice with status: "Void" is excluded',
      passed: !hasP2,
      expected: false,
      actual: hasP2,
    });

    // Test 3: Payment on active invoice is retained
    const hasActive = result.some((p) => p.id === 'pay-on-active');
    suite.results.push({
      name: 'Payment on active non-void invoice is retained',
      passed: hasActive,
      expected: true,
      actual: hasActive,
    });

    suite.totalTests = suite.results.length;
    suite.passedTests = suite.results.filter((r) => r.passed).length;
    suite.failedTests = suite.totalTests - suite.passedTests;
    suite.passed = suite.failedTests === 0;
    suites.push(suite);
  }

  // Suite 4: Multiple Payments for Same Invoice
  {
    const suite: TestSuiteResult = {
      suiteName: 'Multiple Payments for Same Invoice',
      passed: true,
      totalTests: 0,
      passedTests: 0,
      failedTests: 0,
      results: [],
    };

    const singleInvoice = createTestInvoice({
      id: 'inv-shared',
      billNumber: 'BILL-SHARED',
      totalAmount: 100000,
      isVoid: false,
    });

    const payment1 = createTestPayment({
      id: 'pay-part-1',
      invoiceId: singleInvoice.id,
      billNumber: singleInvoice.billNumber,
      amount: 40000,
      createdAt: '2026-09-10T10:00:00.000Z',
      isVoid: false,
    });

    const payment2 = createTestPayment({
      id: 'pay-part-2',
      invoiceId: singleInvoice.id,
      billNumber: singleInvoice.billNumber,
      amount: 60000,
      createdAt: '2026-09-12T10:00:00.000Z',
      isVoid: false,
    });

    const result = getRecentPayments([payment1, payment2], [singleInvoice], 8);

    // Test 1: Both payments exist as distinct items
    suite.results.push({
      name: 'Both payments for same invoice appear as separate records (not merged)',
      passed: result.length === 2 && result.some((p) => p.id === 'pay-part-1') && result.some((p) => p.id === 'pay-part-2'),
      expected: 2,
      actual: result.length,
    });

    // Test 2: Newer payment (pay-part-2) appears first
    suite.results.push({
      name: 'Newer payment appears first among payments for same invoice',
      passed: result[0]?.id === 'pay-part-2',
      expected: 'pay-part-2',
      actual: result[0]?.id,
    });

    // Test 3: Distinct amounts are preserved
    suite.results.push({
      name: 'Individual payment amounts preserved (60,000 and 40,000)',
      passed: result[0]?.amount === 60000 && result[1]?.amount === 40000,
      expected: { first: 60000, second: 40000 },
      actual: { first: result[0]?.amount, second: result[1]?.amount },
    });

    suite.totalTests = suite.results.length;
    suite.passedTests = suite.results.filter((r) => r.passed).length;
    suite.failedTests = suite.totalTests - suite.passedTests;
    suite.passed = suite.failedTests === 0;
    suites.push(suite);
  }

  // Suite 5: Data Display & Safety
  {
    const suite: TestSuiteResult = {
      suiteName: 'Data Display & Amount Safety',
      passed: true,
      totalTests: 0,
      passedTests: 0,
      failedTests: 0,
      results: [],
    };

    const invoice = createTestInvoice({ id: 'inv-disp', billNumber: 'BILL-DISP', isVoid: false });

    // Test 1: Customer name fallback
    const paymentNoCustomer = createTestPayment({
      id: 'pay-no-cust',
      customerName: '',
      invoiceId: invoice.id,
      amount: 25000,
    });
    const resNoCust = getRecentPayments([paymentNoCustomer], [invoice], 8);
    suite.results.push({
      name: 'Fallback to "Customer" when customerName is empty string',
      passed: resNoCust[0]?.customerName === 'Customer',
      expected: 'Customer',
      actual: resNoCust[0]?.customerName,
    });

    // Test 2: NaN or invalid amount safely mapped to 0
    const paymentInvalidAmount = createTestPayment({
      id: 'pay-invalid-amt',
      invoiceId: invoice.id,
      amount: NaN as any,
    });
    const resInvalidAmt = getRecentPayments([paymentInvalidAmount], [invoice], 8);
    suite.results.push({
      name: 'NaN payment amount safely mapped to 0 (no NaN / Infinity)',
      passed: resInvalidAmt[0]?.amount === 0 && Number.isFinite(resInvalidAmt[0]?.amount),
      expected: 0,
      actual: resInvalidAmt[0]?.amount,
    });

    // Test 3: Currency formatting uses AFN, never $ or USD
    const formatted = formatAFN(25000);
    suite.results.push({
      name: 'Receipt currency formatting displays "AFN 25,000" without $ or USD',
      passed: formatted.includes('AFN') && !formatted.includes('$') && !formatted.includes('USD'),
      expected: 'AFN 25,000',
      actual: formatted,
    });

    // Test 4: Payment date formatting preserved with formatDate
    const formattedDate = formatDate('2026-09-18');
    suite.results.push({
      name: 'Payment date displays via standard formatDate()',
      passed: typeof formattedDate === 'string' && formattedDate.length > 0,
      expected: 'string',
      actual: typeof formattedDate,
    });

    suite.totalTests = suite.results.length;
    suite.passedTests = suite.results.filter((r) => r.passed).length;
    suite.failedTests = suite.totalTests - suite.passedTests;
    suite.passed = suite.failedTests === 0;
    suites.push(suite);
  }

  // Suite 6: Timestamp Parsing & Fault Tolerance
  {
    const suite: TestSuiteResult = {
      suiteName: 'Timestamp Parsing & Fault Tolerance',
      passed: true,
      totalTests: 0,
      passedTests: 0,
      failedTests: 0,
      results: [],
    };

    // Test 1: ISO string parsing
    const t1 = getPaymentCreationTimestamp({ createdAt: '2026-09-18T10:00:00.000Z' });
    suite.results.push({
      name: 'Parses standard ISO 8601 string correctly',
      passed: t1 > 0,
      expected: '> 0',
      actual: t1,
    });

    // Test 2: Firestore Timestamp-like { seconds, nanoseconds }
    const t2 = getPaymentCreationTimestamp({
      createdAt: { seconds: 1789725600, nanoseconds: 500000000 } as any,
    });
    suite.results.push({
      name: 'Parses Firestore { seconds, nanoseconds } correctly',
      passed: t2 === 1789725600500,
      expected: 1789725600500,
      actual: t2,
    });

    // Test 3: Firestore Timestamp with toMillis()
    const t3 = getPaymentCreationTimestamp({
      createdAt: { toMillis: () => 1789725600000 } as any,
    });
    suite.results.push({
      name: 'Parses Firestore toMillis() correctly',
      passed: t3 === 1789725600000,
      expected: 1789725600000,
      actual: t3,
    });

    // Test 4: Missing createdAt falls back to date
    const t4 = getPaymentCreationTimestamp({ date: '2026-09-18' });
    suite.results.push({
      name: 'Falls back to p.date when createdAt is missing',
      passed: t4 > 0,
      expected: '> 0',
      actual: t4,
    });

    // Test 5: Corrupted / undefined createdAt does not crash
    const t5 = getPaymentCreationTimestamp({ createdAt: 'corrupted-date' as any });
    suite.results.push({
      name: 'Corrupted createdAt returns 0 and does not throw',
      passed: t5 === 0,
      expected: 0,
      actual: t5,
    });

    suite.totalTests = suite.results.length;
    suite.passedTests = suite.results.filter((r) => r.passed).length;
    suite.failedTests = suite.totalTests - suite.passedTests;
    suite.passed = suite.failedTests === 0;
    suites.push(suite);
  }

  // Suite 7: Real-time Behavior Simulation
  {
    const suite: TestSuiteResult = {
      suiteName: 'Real-time Behavior Simulation',
      passed: true,
      totalTests: 0,
      passedTests: 0,
      failedTests: 0,
      results: [],
    };

    const invoice = createTestInvoice({ id: 'inv-rt', billNumber: 'BILL-RT', isVoid: false });

    // Initial 8 payments
    const initialPayments: Payment[] = [
      createTestPayment({ id: 'p-1', createdAt: '2026-09-01T10:00:00.000Z', invoiceId: invoice.id }),
      createTestPayment({ id: 'p-2', createdAt: '2026-09-02T10:00:00.000Z', invoiceId: invoice.id }),
      createTestPayment({ id: 'p-3', createdAt: '2026-09-03T10:00:00.000Z', invoiceId: invoice.id }),
      createTestPayment({ id: 'p-4', createdAt: '2026-09-04T10:00:00.000Z', invoiceId: invoice.id }),
      createTestPayment({ id: 'p-5', createdAt: '2026-09-05T10:00:00.000Z', invoiceId: invoice.id }),
      createTestPayment({ id: 'p-6', createdAt: '2026-09-06T10:00:00.000Z', invoiceId: invoice.id }),
      createTestPayment({ id: 'p-7', createdAt: '2026-09-07T10:00:00.000Z', invoiceId: invoice.id }),
      createTestPayment({ id: 'p-8', createdAt: '2026-09-08T10:00:00.000Z', invoiceId: invoice.id }),
    ];

    const initialResult = getRecentPayments(initialPayments, [invoice], 8);
    const initialOldest = initialResult[initialResult.length - 1]; // should be p-1

    // New payment recorded with later createdAt
    const newPayment = createTestPayment({
      id: 'p-new-9',
      createdAt: '2026-09-09T10:00:00.000Z',
      invoiceId: invoice.id,
    });

    const updatedResult = getRecentPayments([...initialPayments, newPayment], [invoice], 8);

    // Test 1: New payment appears at index 0 and list length remains 8
    suite.results.push({
      name: 'When new payment is recorded, it appears at index 0 and list length remains 8',
      passed: updatedResult.length === 8 && updatedResult[0]?.id === 'p-new-9',
      expected: { length: 8, firstId: 'p-new-9' },
      actual: { length: updatedResult.length, firstId: updatedResult[0]?.id },
    });

    // Test 2: Oldest item (p-1) dropped off
    const hasOldest = updatedResult.some((p) => p.id === initialOldest.id);
    suite.results.push({
      name: 'Oldest item drops off when a 9th payment is added',
      passed: !hasOldest,
      expected: false,
      actual: hasOldest,
    });

    // Test 3: When an invoice becomes void, its payment disappears in real time
    const voidedInvoice = { ...invoice, isVoid: true };
    const voidedInvResult = getRecentPayments([...initialPayments, newPayment], [voidedInvoice], 8);
    suite.results.push({
      name: 'When an invoice becomes void, its related payments immediately disappear',
      passed: voidedInvResult.length === 0,
      expected: 0,
      actual: voidedInvResult.length,
    });

    suite.totalTests = suite.results.length;
    suite.passedTests = suite.results.filter((r) => r.passed).length;
    suite.failedTests = suite.totalTests - suite.passedTests;
    suite.passed = suite.failedTests === 0;
    suites.push(suite);
  }

  const totalTests = suites.reduce((sum, s) => sum + s.totalTests, 0);
  const passedTests = suites.reduce((sum, s) => sum + s.passedTests, 0);
  const failedTests = suites.reduce((sum, s) => sum + s.failedTests, 0);
  const passed = failedTests === 0;

  console.log('===============================================================');
  console.log('       RECENT CASH RECEIPTS VERIFICATION TEST SUITE RESULTS    ');
  console.log('===============================================================');
  for (const s of suites) {
    const sym = s.passed ? '✓ PASS' : '✗ FAIL';
    console.log(`\n[${sym}] ${s.suiteName} (${s.passedTests}/${s.totalTests} passed)`);
    for (const r of s.results) {
      const itemSym = r.passed ? '  ✓' : '  ✗';
      console.log(`${itemSym} ${r.name}`);
      if (!r.passed) {
        console.log(`     Expected: ${JSON.stringify(r.expected)}, Actual: ${JSON.stringify(r.actual)}`);
      }
    }
  }
  console.log('\n---------------------------------------------------------------');
  console.log(`TOTAL: ${passedTests}/${totalTests} Tests Passed`);
  console.log(`OVERALL STATUS: ${passed ? 'ALL TESTS PASSED' : 'SOME TESTS FAILED'}`);
  console.log('===============================================================\n');

  return { passed, suites, totalTests, passedTests, failedTests };
}

// Self-executing if run directly
if (import.meta.url === `file://${process.argv[1]}`) {
  const summary = runAllRecentPaymentsTests();
  if (!summary.passed) {
    process.exit(1);
  }
}
