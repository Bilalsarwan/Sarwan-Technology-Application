import { Payment, Invoice } from '../types';

/**
 * Safely extracts a numeric epoch millisecond timestamp for a payment's creation date.
 * Supports:
 * - ISO 8601 string (e.g. '2026-09-18T12:00:00.000Z')
 * - YYYY-MM-DD string
 * - Firestore Timestamp objects with toMillis() or toDate()
 * - Firestore Timestamp-like objects with { seconds, nanoseconds }
 * - JS Date instances
 * - Numeric epoch values
 * - Fallback to payment.date
 * - Safe return of 0 for invalid/missing values to prevent crashes
 */
export function getPaymentCreationTimestamp(payment: Partial<Payment> | null | undefined): number {
  if (!payment) return 0;
  const raw: any = payment.createdAt;

  if (raw !== null && raw !== undefined && raw !== '') {
    // 1. Direct number
    if (typeof raw === 'number' && Number.isFinite(raw)) {
      return raw;
    }

    // 2. Object formats (Firestore Timestamp, JS Date)
    if (typeof raw === 'object') {
      if (typeof raw.toMillis === 'function') {
        try {
          const ms = raw.toMillis();
          if (typeof ms === 'number' && Number.isFinite(ms)) return ms;
        } catch {
          // Fall through
        }
      }
      if (typeof raw.toDate === 'function') {
        try {
          const d = raw.toDate();
          if (d instanceof Date && !isNaN(d.getTime())) return d.getTime();
        } catch {
          // Fall through
        }
      }
      if ('seconds' in raw && typeof raw.seconds === 'number') {
        const s = raw.seconds;
        const ns = typeof raw.nanoseconds === 'number' ? raw.nanoseconds : 0;
        return s * 1000 + Math.floor(ns / 1000000);
      }
      if (raw instanceof Date) {
        const t = raw.getTime();
        if (!isNaN(t)) return t;
      }
    }

    // 3. String formats
    if (typeof raw === 'string') {
      const trimmed = raw.trim();
      if (trimmed) {
        const parsed = Date.parse(trimmed);
        if (!isNaN(parsed)) return parsed;

        const num = Number(trimmed);
        if (Number.isFinite(num) && num > 0) return num;
      }
    }
  }

  // 4. Fallback to payment.date
  if (payment.date && typeof payment.date === 'string') {
    const parsedDate = Date.parse(payment.date.trim());
    if (!isNaN(parsedDate)) return parsedDate;
  }

  return 0;
}

/**
 * Safely parses and validates a payment monetary amount.
 * Prevents NaN, Infinity, and undefined.
 */
export function getSafePaymentAmount(amount: unknown): number {
  if (typeof amount === 'number' && Number.isFinite(amount)) {
    return Math.max(0, amount);
  }
  if (typeof amount === 'string') {
    const cleaned = amount.replace(/[^0-9.-]+/g, '');
    const parsed = parseFloat(cleaned);
    if (Number.isFinite(parsed)) {
      return Math.max(0, parsed);
    }
  }
  return 0;
}

/**
 * Safely extracts the customer display name for a payment.
 */
export function getPaymentCustomerName(payment: Partial<Payment> | null | undefined): string {
  if (!payment) return 'Customer';
  const name = payment.customerName;
  if (typeof name === 'string' && name.trim()) {
    return name.trim();
  }
  return 'Customer';
}

/**
 * Filters and returns the latest N valid cash receipts for the Dashboard.
 *
 * Rules:
 * 1. Exclude invalid payments (corrupted or missing id).
 * 2. Exclude void/corrected payments (isVoid === true or status === 'Void').
 * 3. Exclude deleted/demo/fake payments.
 * 4. Exclude payments belonging to void invoices (where related invoice has isVoid === true or status === 'Void').
 * 5. Sort remaining valid payments strictly by createdAt descending (Newest -> Oldest).
 * 6. Slice to limit (exactly 8 records).
 * 7. Ensure amounts and customer names are clean and safe.
 */
export function getRecentPayments(
  payments: Payment[] = [],
  invoices: Invoice[] = [],
  limit: number = 8
): Payment[] {
  if (!Array.isArray(payments) || payments.length === 0) {
    return [];
  }

  // Build lookup sets for void invoices
  const voidInvoiceIds = new Set<string>();
  const voidBillNumbers = new Set<string>();

  if (Array.isArray(invoices) && invoices.length > 0) {
    for (const inv of invoices) {
      if (inv && (inv.isVoid === true || inv.status === 'Void')) {
        if (inv.id) voidInvoiceIds.add(String(inv.id));
        if (inv.billNumber) voidBillNumbers.add(String(inv.billNumber));
      }
    }
  }

  // 1-4. Filter valid active payments
  const validPayments: Payment[] = [];

  for (const p of payments) {
    if (!p || typeof p !== 'object' || !p.id) {
      continue;
    }

    // Exclude void payments
    if (p.isVoid === true || (p as any).status === 'Void') {
      continue;
    }

    // Exclude deleted or demo/fake payments
    if ((p as any).isDeleted === true || (p as any).isDemo === true || (p as any).isFake === true) {
      continue;
    }

    // Exclude payments belonging to void invoices
    if (p.invoiceId && voidInvoiceIds.has(String(p.invoiceId))) {
      continue;
    }
    if (p.billNumber && voidBillNumbers.has(String(p.billNumber))) {
      continue;
    }

    // Safe sanitized payment record
    validPayments.push({
      ...p,
      amount: getSafePaymentAmount(p.amount),
      customerName: getPaymentCustomerName(p),
    });
  }

  // 5. Sort valid payments by createdAt descending (Newest -> Oldest)
  validPayments.sort((a, b) => {
    const timeB = getPaymentCreationTimestamp(b);
    const timeA = getPaymentCreationTimestamp(a);
    if (timeB !== timeA) {
      return timeB - timeA;
    }
    // Deterministic tie-breaker
    return String(b.id || '').localeCompare(String(a.id || ''));
  });

  // 6. Slice top records AFTER filtering and sorting
  return validPayments.slice(0, Math.max(0, limit));
}
