import { UserProfile } from '../types';

export interface ProfileCompletionDetails {
  isComplete: boolean;
  percentage: number;
  completedFieldsCount: number;
  totalRequiredFields: number;
  missingFields: { key: string; label: string }[];
}

/**
 * The essential required fields that define whether a user/employee profile is complete.
 * Only these fields affect the Blue checkmark (✓) vs Red cross (✕) indicator.
 * Optional fields (like employeeCode, notes, gender, dob, emergency contacts) do NOT block completion.
 */
export const REQUIRED_PROFILE_FIELDS = [
  { key: 'name', label: 'Full Name' },
  { key: 'email', label: 'Email Address' },
  { key: 'phone', label: 'Phone Number' },
  { key: 'jobTitle', label: 'Job Title / Position' },
  { key: 'department', label: 'Department' },
  { key: 'nationalId', label: 'National ID / Tazkira' },
  { key: 'address', label: 'Residential / Office Address' },
] as const;

/**
 * Determines whether a user's profile is complete based on required fields.
 * Returns true only when all required fields contain valid, non-empty data.
 */
export function isProfileComplete(user?: Partial<UserProfile> | null): boolean {
  return getProfileCompletionDetails(user).isComplete;
}

/**
 * Calculates complete percentage and returns missing required fields for the user.
 */
export function getProfileCompletionDetails(user?: Partial<UserProfile> | null): ProfileCompletionDetails {
  if (!user) {
    return {
      isComplete: false,
      percentage: 0,
      completedFieldsCount: 0,
      totalRequiredFields: REQUIRED_PROFILE_FIELDS.length,
      missingFields: [...REQUIRED_PROFILE_FIELDS],
    };
  }

  const missing: { key: string; label: string }[] = [];

  for (const field of REQUIRED_PROFILE_FIELDS) {
    const val = user[field.key as keyof UserProfile];
    if (typeof val !== 'string' || !val.trim()) {
      missing.push(field);
    }
  }

  const completed = REQUIRED_PROFILE_FIELDS.length - missing.length;
  const percentage = Math.round((completed / REQUIRED_PROFILE_FIELDS.length) * 100);

  return {
    isComplete: missing.length === 0,
    percentage,
    completedFieldsCount: completed,
    totalRequiredFields: REQUIRED_PROFILE_FIELDS.length,
    missingFields: missing,
  };
}

/**
 * Returns the immutable official User ID (e.g. ST-U-5000).
 * Falls back gracefully to user.id or a default pattern.
 */
export function getOfficialUserId(user?: { id?: string; userId?: string } | null): string {
  if (!user) return 'ST-U-5000';
  if (user.userId && user.userId.trim()) return user.userId.trim();
  if (user.id && user.id.startsWith('ST-U-')) return user.id;
  return user.id || 'ST-U-5000';
}
