import { Customer, CustomerType, CustomerCanonicalStatus, CustomerStatus } from '../types';

export const AFGHAN_PROVINCES = [
  'Kabul',
  'Herat',
  'Balkh',
  'Kandahar',
  'Nangarhar',
  'Kunduz',
  'Takhar',
  'Badakhshan',
  'Baghlan',
  'Samangan',
  'Sar-e Pol',
  'Jowzjan',
  'Faryab',
  'Badghis',
  'Ghor',
  'Bamyan',
  'Daikundi',
  'Ghazni',
  'Wardak',
  'Logar',
  'Paktia',
  'Paktika',
  'Khost',
  'Laghman',
  'Kunar',
  'Nuristan',
  'Panjshir',
  'Parwan',
  'Kapisa',
  'Nimruz',
  'Helmand',
  'Farah',
  'Zabul',
  'Urozgan',
] as const;

/**
 * Normalizes a phone number string for duplicate detection and consistent search:
 * - Strips all non-digit characters (+, -, spaces, parentheses)
 * - Strips leading international exit codes (0093 or +93 -> 93)
 * - Normalizes Afghan country code (+93 / 0093 / 93) to standard 9-digit local phone
 * - Strips leading '0' so 0731339014 and 731339014 equate to the same number
 */
export function normalizePhone(rawPhone?: string | null): string {
  if (!rawPhone) return '';
  let digits = rawPhone.replace(/\D/g, '');
  if (!digits) return '';

  // Handle international prefix 0093
  if (digits.startsWith('0093')) {
    digits = digits.slice(4);
  } else if (digits.startsWith('93') && digits.length >= 11) {
    digits = digits.slice(2);
  }

  // Remove leading 0 if present (e.g., 0731339014 -> 731339014)
  if (digits.startsWith('0') && digits.length > 5) {
    digits = digits.slice(1);
  }

  return digits;
}

/**
 * Compares two phone strings using normalized digits.
 */
export function isPhoneMatch(phoneA?: string | null, phoneB?: string | null): boolean {
  const normA = normalizePhone(phoneA);
  const normB = normalizePhone(phoneB);
  if (!normA || !normB) return false;
  // Match if exact or if one is the suffix of the other (min 7 digits)
  if (normA === normB) return true;
  if (normA.length >= 7 && normB.length >= 7) {
    return normA.endsWith(normB) || normB.endsWith(normA);
  }
  return false;
}

/**
 * Scans an array of existing customers to find any duplicate phone (phone or alternatePhone),
 * excluding the customer being edited.
 */
export function findDuplicatePhoneCustomer(
  inputPhone: string,
  customers: Customer[],
  excludeCustomerId?: string
): Customer | null {
  const normInput = normalizePhone(inputPhone);
  if (!normInput || normInput.length < 6) return null;

  for (const c of customers) {
    if (excludeCustomerId && (c.id === excludeCustomerId || c.customerCode === excludeCustomerId)) {
      continue;
    }

    if (isPhoneMatch(c.phone, inputPhone)) {
      return c;
    }
    if (c.alternatePhone && isPhoneMatch(c.alternatePhone, inputPhone)) {
      return c;
    }
  }

  return null;
}

/**
 * Normalizes customer status to canonical: 'Active' | 'Inactive' | 'Blocked'
 * Preserves full backward compatibility with legacy values ('active', 'deactivated', 'archived').
 */
export function normalizeCustomerStatus(
  status?: string | null,
  isArchived?: boolean | null
): CustomerCanonicalStatus {
  if (!status) {
    return isArchived ? 'Inactive' : 'Active';
  }

  const s = String(status).trim().toLowerCase();
  if (s === 'blocked') {
    return 'Blocked';
  }
  if (s === 'inactive' || s === 'deactivated' || s === 'archived' || isArchived === true) {
    return 'Inactive';
  }
  return 'Active';
}

/**
 * Normalizes Customer ID format: ST-CUST-1001
 * Migrates legacy CUST-1001 or raw numeric suffixes to ST-CUST-XXXX.
 */
export function migrateCustomerId(legacyCodeOrId?: string | null, fallbackIndex = 1001): string {
  if (!legacyCodeOrId || typeof legacyCodeOrId !== 'string') {
    return `ST-CUST-${fallbackIndex}`;
  }

  const trimmed = legacyCodeOrId.trim();
  if (trimmed.startsWith('ST-CUST-')) {
    return trimmed;
  }

  if (trimmed.startsWith('CUST-')) {
    const numPart = trimmed.replace('CUST-', '');
    return `ST-CUST-${numPart}`;
  }

  const numMatch = trimmed.match(/\d+$/);
  if (numMatch) {
    return `ST-CUST-${numMatch[0]}`;
  }

  return `ST-CUST-${fallbackIndex}`;
}

export interface CustomerValidationResult {
  isValid: boolean;
  errors: Record<string, string>;
}

/**
 * Centralized customer data validation according to system specifications:
 * Required:
 * - Customer Type: Individual | Business
 * - Customer Name
 * - Phone (min 7 digits)
 * - Email (valid format)
 * - Address
 * - City
 * - Province
 * - Company Name when Customer Type = Business
 */
export function validateCustomerData(data: {
  customerType?: CustomerType;
  name?: string;
  companyName?: string;
  phone?: string;
  email?: string;
  address?: string;
  city?: string;
  province?: string;
}): CustomerValidationResult {
  const errors: Record<string, string> = {};

  const type = data.customerType || 'Individual';
  const name = data.name?.trim() || '';
  const phone = data.phone?.trim() || '';
  const email = data.email?.trim().toLowerCase() || '';
  const address = data.address?.trim() || '';
  const city = data.city?.trim() || '';
  const province = data.province?.trim() || '';
  const companyName = data.companyName?.trim() || '';

  if (!type || (type !== 'Individual' && type !== 'Business')) {
    errors.customerType = 'Please select a valid customer type (Individual or Business).';
  }

  if (!name) {
    errors.name = 'Customer full name is required.';
  } else if (name.length < 2) {
    errors.name = 'Customer name must be at least 2 characters long.';
  }

  if (type === 'Business' && !companyName) {
    errors.companyName = 'Company name is required for Business customers.';
  }

  if (!phone) {
    errors.phone = 'Phone number is required.';
  } else {
    const digits = normalizePhone(phone);
    if (digits.length < 7) {
      errors.phone = 'Please enter a valid phone number (minimum 7 digits).';
    }
  }

  if (!email) {
    errors.email = 'Email address is required.';
  } else {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
      errors.email = 'Please enter a valid email address.';
    }
  }

  if (!address) {
    errors.address = 'Street/Physical address is required.';
  }

  if (!city) {
    errors.city = 'City is required.';
  }

  if (!province) {
    errors.province = 'Province is required.';
  }

  return {
    isValid: Object.keys(errors).length === 0,
    errors,
  };
}
