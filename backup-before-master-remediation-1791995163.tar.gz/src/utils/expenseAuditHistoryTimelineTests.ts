import assert from 'assert';
import {
  resolveEventStatus,
  getStatusConfig,
  normalizeExpenseTimeline,
  formatRoleLabel,
  getActorInitials,
  resolveActorPhoto,
  resolveActorName,
  WORKFLOW_SEMANTIC_COLORS,
  getApprovalProgressStages,
  getPendingStagesForTimeline,
  getEventStageTitle,
  getActionDescription,
} from '../components/expense/ExpenseAuditHistoryModal';
import { formatDateTime } from './format';
import { Expense, ExpenseTimelineEntry, UserProfile } from '../types';
import {
  filterExpensesForUser,
  resolveUserPhoto,
  seedUserProfileCache,
  getUserProfileById,
} from '../services/db';

console.log('================================================================');
console.log(' SARWAN TECHNOLOGY: EXPENSE APPROVAL AUDIT TIMELINE TEST SUITE  ');
console.log('================================================================');

let passedTests = 0;
let totalTests = 0;

function runTest(name: string, fn: () => void) {
  totalTests++;
  try {
    fn();
    passedTests++;
    console.log(`  ✓ PASS: ${name}`);
  } catch (err: any) {
    console.error(`  ✗ FAIL: ${name}`);
    console.error(`    ${err.message}`);
    process.exitCode = 1;
  }
}

// -------------------------------------------------------------
// 1. EXACT SEMANTIC COLORS
// -------------------------------------------------------------
console.log('\n--- 1. EXACT SEMANTIC COLORS & STATUS CONFIGURATION ---');

runTest('Approved status maps to exact semantic color #16A34A', () => {
  assert.strictEqual(WORKFLOW_SEMANTIC_COLORS.approved, '#16A34A');
  const config = getStatusConfig('approved');
  assert.strictEqual(config.color, '#16A34A');
  assert.strictEqual(config.badgeLabel, 'Approved');
});

runTest('Rejected status maps to exact semantic color #DC2626', () => {
  assert.strictEqual(WORKFLOW_SEMANTIC_COLORS.rejected, '#DC2626');
  const config = getStatusConfig('rejected');
  assert.strictEqual(config.color, '#DC2626');
  assert.strictEqual(config.badgeLabel, 'Expense Request Rejected');
});

runTest('Pending status maps to exact semantic color #2563EB', () => {
  assert.strictEqual(WORKFLOW_SEMANTIC_COLORS.pending, '#2563EB');
  const config = getStatusConfig('pending');
  assert.strictEqual(config.color, '#2563EB');
});

runTest('Submitted status maps to exact semantic color #2563EB', () => {
  assert.strictEqual(WORKFLOW_SEMANTIC_COLORS.submitted, '#2563EB');
  const config = getStatusConfig('submitted');
  assert.strictEqual(config.color, '#2563EB');
});

runTest('Resubmitted status maps to exact semantic color #2563EB', () => {
  assert.strictEqual(WORKFLOW_SEMANTIC_COLORS.resubmitted, '#2563EB');
  const config = getStatusConfig('resubmitted');
  assert.strictEqual(config.color, '#2563EB');
});

runTest('Executed status maps to exact semantic color #16A34A with distinct Executed label', () => {
  assert.strictEqual(WORKFLOW_SEMANTIC_COLORS.executed, '#16A34A');
  const config = getStatusConfig('executed');
  assert.strictEqual(config.color, '#16A34A');
  assert.strictEqual(config.badgeLabel, 'Executed & Disbursed');
});

// -------------------------------------------------------------
// 2. INDEPENDENT EVENT STATUS RESOLUTION
// -------------------------------------------------------------
console.log('\n--- 2. INDEPENDENT EVENT STATUS RESOLUTION ---');

runTest('Rejection event is resolved as rejected regardless of current expense status', () => {
  const rejectedEntry: ExpenseTimelineEntry = {
    action: 'Expense Request Rejected',
    performedBy: 'mgr-001',
    performedByName: 'Sarah Manager',
    performedByRole: 'invoice_manager',
    timestamp: '2026-10-10T10:00:00Z',
    rejectionReason: 'Receipt missing store stamp',
  };
  assert.strictEqual(resolveEventStatus(rejectedEntry), 'rejected');
});

runTest('Historical unapproved/rejected event is not marked as approved', () => {
  const historicalRejection: ExpenseTimelineEntry = {
    action: 'Rejected: Missing official invoice slip',
    performedBy: 'adm-001',
    performedByName: 'Admin',
    performedByRole: 'super_admin',
    timestamp: '2026-10-09T08:00:00Z',
    rejectionReason: 'Missing official invoice slip',
  };
  const resolved = resolveEventStatus(historicalRejection);
  assert.notStrictEqual(resolved, 'approved');
  assert.strictEqual(resolved, 'rejected');
});

runTest('Resubmission event with corrections description is resolved as resubmitted', () => {
  const resubmitEntry: ExpenseTimelineEntry = {
    action: 'Expense Request Resubmitted',
    performedBy: 'coll-001',
    performedByName: 'Farhad Collector',
    performedByRole: 'payment_collector',
    timestamp: '2026-10-10T12:00:00Z',
    corrections: 'Attached clear vendor stamp image and serial number',
    correctionDescription: 'Attached clear vendor stamp image and serial number',
    revision: 2,
  };
  assert.strictEqual(resolveEventStatus(resubmitEntry), 'resubmitted');
});

runTest('Executed event is resolved as executed', () => {
  const executedEntry: ExpenseTimelineEntry = {
    action: 'Executed & Disbursed',
    performedBy: 'adm-001',
    performedByName: 'Super Admin',
    performedByRole: 'super_admin',
    timestamp: '2026-10-11T14:00:00Z',
  };
  assert.strictEqual(resolveEventStatus(executedEntry), 'executed');
});

runTest('Approval event is resolved as approved', () => {
  const approveEntry: ExpenseTimelineEntry = {
    action: 'Invoice Manager Approved',
    performedBy: 'mgr-001',
    performedByName: 'Invoice Manager',
    performedByRole: 'invoice_manager',
    timestamp: '2026-10-11T11:00:00Z',
  };
  assert.strictEqual(resolveEventStatus(approveEntry), 'approved');
});

runTest('Pending Manager Approval is resolved as pending (blue #2563EB)', () => {
  const pendingManagerEntry: ExpenseTimelineEntry = {
    action: 'Pending Manager Approval',
    performedBy: 'pending-mgr',
    performedByName: 'Awaiting Invoice Manager Review',
    performedByRole: 'invoice_manager',
    timestamp: '2026-10-11T11:30:00Z',
  };
  assert.strictEqual(resolveEventStatus(pendingManagerEntry), 'pending');
  assert.strictEqual(getStatusConfig('pending').color, '#2563EB');
});

runTest('Pending Super Admin Approval is resolved as pending (blue #2563EB)', () => {
  const pendingAdminEntry: ExpenseTimelineEntry = {
    action: 'Pending Super Admin Approval',
    performedBy: 'pending-adm',
    performedByName: 'Awaiting Super Admin Approval',
    performedByRole: 'super_admin',
    timestamp: '2026-10-11T12:00:00Z',
  };
  assert.strictEqual(resolveEventStatus(pendingAdminEntry), 'pending');
  assert.strictEqual(getStatusConfig('pending').color, '#2563EB');
});

runTest('Submission event on an approved expense remains strictly blue (#2563EB) and NOT green', () => {
  // Even if an entry inherited status: 'approved' from an approved expense document
  const submissionWithApprovedStatus: ExpenseTimelineEntry = {
    action: 'Expense Request Submitted',
    performedBy: 'user-007',
    performedByName: 'Requester',
    performedByRole: 'payment_collector',
    timestamp: '2026-10-11T09:00:00Z',
    status: 'approved' as any, // Stale or inherited overall status
  };
  const resolved = resolveEventStatus(submissionWithApprovedStatus);
  assert.strictEqual(resolved, 'submitted');
  assert.strictEqual(getStatusConfig(resolved).color, '#2563EB');
  assert.notStrictEqual(getStatusConfig(resolved).color, '#16A34A');
});

runTest('Resubmitted event on an approved expense remains strictly blue (#2563EB) and NOT green', () => {
  const resubmitWithApprovedStatus: ExpenseTimelineEntry = {
    action: 'Expense Request Resubmitted',
    performedBy: 'user-007',
    performedByName: 'Requester',
    performedByRole: 'payment_collector',
    timestamp: '2026-10-11T10:00:00Z',
    status: 'approved' as any,
    corrections: 'Fixed tax code',
  };
  const resolved = resolveEventStatus(resubmitWithApprovedStatus);
  assert.strictEqual(resolved, 'resubmitted');
  assert.strictEqual(getStatusConfig(resolved).color, '#2563EB');
});

// -------------------------------------------------------------
// 3. ACTOR IDENTITY, PROFILE PHOTOS, FALLBACKS & ATTRIBUTION
// -------------------------------------------------------------
console.log('\n--- 3. ACTOR IDENTITY, PROFILE PHOTOS & ATTRIBUTION ---');

runTest('Actor full initials derived accurately for two names', () => {
  assert.strictEqual(getActorInitials('Ahmad Zahir'), 'AZ');
  assert.strictEqual(getActorInitials('Sarah Jenkins'), 'SJ');
});

runTest('Actor initials derived accurately for single word name', () => {
  assert.strictEqual(getActorInitials('Administrator'), 'AD');
  assert.strictEqual(getActorInitials('Sarwan'), 'SA');
});

runTest('Actor initials fallback safely when name is missing', () => {
  assert.strictEqual(getActorInitials(''), 'ST');
  assert.strictEqual(getActorInitials(undefined), 'ST');
});

runTest('Role label formatting preserves both job title and role when distinct', () => {
  const formatted = formatRoleLabel('invoice_manager', 'Chief Financial Officer');
  assert.strictEqual(formatted, 'Chief Financial Officer • Invoice Manager');
});

runTest('Role label formatting falls back to role name when job title is missing', () => {
  assert.strictEqual(formatRoleLabel('payment_collector'), 'Payment Collector');
  assert.strictEqual(formatRoleLabel('super_admin'), 'Super Admin');
  assert.strictEqual(formatRoleLabel('invoice_manager'), 'Invoice Manager');
});

runTest('Role label falls back to Authorized Staff when role is undefined', () => {
  assert.strictEqual(formatRoleLabel(undefined), 'Authorized Staff');
});

runTest('resolveUserPhoto resolves Base64 JPEG data URL correctly', () => {
  const dataUrl = 'data:image/jpeg;base64,/9j/4AAQSkZJRgABAQEASABIAAD...';
  const resolved = resolveUserPhoto({ photoURL: dataUrl } as UserProfile);
  assert.strictEqual(resolved, dataUrl);
});

runTest('resolveUserPhoto resolves external HTTPS download URL correctly', () => {
  const httpsUrl = 'https://lh3.googleusercontent.com/a/ACg8ocISarwan=s96-c';
  const resolved = resolveUserPhoto({ photoURL: httpsUrl } as UserProfile);
  assert.strictEqual(resolved, httpsUrl);
});

runTest('resolveUserPhoto handles naming variants photoUrl and avatar safely', () => {
  const variant1 = resolveUserPhoto({ photoUrl: 'https://cdn.example.com/photo1.jpg' } as any);
  assert.strictEqual(variant1, 'https://cdn.example.com/photo1.jpg');

  const variant2 = resolveUserPhoto({ avatar: 'data:image/png;base64,iVBORw0KGgo...' } as any);
  assert.strictEqual(variant2, 'data:image/png;base64,iVBORw0KGgo...');
});

runTest('resolveUserPhoto returns null for empty or undefined photos', () => {
  assert.strictEqual(resolveUserPhoto(undefined), null);
  assert.strictEqual(resolveUserPhoto({} as UserProfile), null);
  assert.strictEqual(resolveUserPhoto({ photoURL: '   ' } as UserProfile), null);
});

runTest('resolveActorPhoto prioritizes live user profile photo over historical snapshot if profile is updated', () => {
  const liveUser: Partial<UserProfile> = {
    id: 'user-001',
    name: 'Farhad Collector',
    photoURL: 'https://storage.googleapis.com/updated-profile-photo.jpg',
  };
  const historicalEntry: ExpenseTimelineEntry = {
    action: 'Submitted Request',
    performedBy: 'user-001',
    performedByName: 'Farhad Collector',
    performedByRole: 'payment_collector',
    performedByPhotoURL: 'https://storage.googleapis.com/old-snapshot.jpg',
    timestamp: '2026-10-01T10:00:00Z',
  };

  const resolved = resolveActorPhoto(historicalEntry, liveUser);
  assert.strictEqual(resolved, 'https://storage.googleapis.com/updated-profile-photo.jpg');
});

runTest('resolveActorPhoto falls back to historical snapshot when live profile has no photo', () => {
  const liveUserWithoutPhoto: Partial<UserProfile> = {
    id: 'user-002',
    name: 'Ali Collector',
    photoURL: '',
  };
  const historicalEntry: ExpenseTimelineEntry = {
    action: 'Submitted Request',
    performedBy: 'user-002',
    performedByName: 'Ali Collector',
    performedByRole: 'payment_collector',
    performedByPhotoURL: 'https://storage.googleapis.com/historical-snapshot.jpg',
    timestamp: '2026-10-01T10:00:00Z',
  };

  const resolved = resolveActorPhoto(historicalEntry, liveUserWithoutPhoto);
  assert.strictEqual(resolved, 'https://storage.googleapis.com/historical-snapshot.jpg');
});

runTest('resolveActorPhoto returns null when neither profile nor snapshot has photo', () => {
  const emptyEntry: ExpenseTimelineEntry = {
    action: 'Submitted Request',
    performedBy: 'user-003',
    performedByName: 'No Photo User',
    performedByRole: 'payment_collector',
    timestamp: '2026-10-01T10:00:00Z',
  };
  const resolved = resolveActorPhoto(emptyEntry, null);
  assert.strictEqual(resolved, null);
});

runTest('resolveActorName upgrades generic placeholders (Staff, Reviewer) to live name without leaking raw ID', () => {
  const userProfile: Partial<UserProfile> = {
    id: 'usr-999',
    userId: 'ST-U-9000',
    name: 'Zahra Finance Specialist',
  };
  const genericEntry: ExpenseTimelineEntry = {
    action: 'Invoice Manager Approved',
    performedBy: 'usr-999',
    performedByName: 'Reviewer',
    performedByRole: 'invoice_manager',
    timestamp: '2026-10-05T12:00:00Z',
  };

  const resolved = resolveActorName(genericEntry, userProfile);
  assert.strictEqual(resolved, 'Zahra Finance Specialist');
  assert.strictEqual(resolved.includes('usr-999'), false);
  assert.strictEqual(resolved.includes('ST-U-9000'), false);
});

runTest('seedUserProfileCache and getUserProfileById resolve cached user synchronously without network query', async () => {
  const mockUser: UserProfile = {
    id: 'test-user-cached-01',
    userId: 'ST-U-7777',
    name: 'Hamidullah Account Lead',
    username: 'hamidullah',
    email: 'hamid@sarwan.af',
    role: 'invoice_manager',
    status: 'active',
    photoURL: 'data:image/jpeg;base64,mockphotodata12345',
    createdAt: '2026-01-01T00:00:00Z',
  };

  seedUserProfileCache([mockUser]);

  // Resolves by doc id
  const byId = await getUserProfileById('test-user-cached-01');
  assert.ok(byId);
  assert.strictEqual(byId?.name, 'Hamidullah Account Lead');
  assert.strictEqual(byId?.photoURL, 'data:image/jpeg;base64,mockphotodata12345');

  // Resolves by official userId
  const byUserId = await getUserProfileById('ST-U-7777');
  assert.ok(byUserId);
  assert.strictEqual(byUserId?.name, 'Hamidullah Account Lead');
});

runTest('Multiple distinct actors across workflow timeline have distinct photos and identities', () => {
  const requesterProfile: Partial<UserProfile> = {
    id: 'coll-101',
    name: 'Farhad Collector',
    photoURL: 'data:image/jpeg;base64,farhadPhotoData',
  };
  const reviewerProfile: Partial<UserProfile> = {
    id: 'mgr-202',
    name: 'Sarah Reviewer',
    photoURL: 'data:image/jpeg;base64,sarahPhotoData',
  };
  const adminProfile: Partial<UserProfile> = {
    id: 'adm-303',
    name: 'Ahmad Super Admin',
    photoURL: 'data:image/jpeg;base64,ahmadPhotoData',
  };

  const submitEntry: ExpenseTimelineEntry = {
    action: 'Submitted Request',
    performedBy: 'coll-101',
    performedByName: 'Farhad Collector',
    performedByRole: 'payment_collector',
    timestamp: '2026-10-01T08:00:00Z',
  };
  const reviewEntry: ExpenseTimelineEntry = {
    action: 'Invoice Manager Approved',
    performedBy: 'mgr-202',
    performedByName: 'Sarah Reviewer',
    performedByRole: 'invoice_manager',
    timestamp: '2026-10-01T10:00:00Z',
  };
  const approveEntry: ExpenseTimelineEntry = {
    action: 'Super Admin Approved',
    performedBy: 'adm-303',
    performedByName: 'Ahmad Super Admin',
    performedByRole: 'super_admin',
    timestamp: '2026-10-01T12:00:00Z',
  };

  const photoSubmit = resolveActorPhoto(submitEntry, requesterProfile);
  const photoReview = resolveActorPhoto(reviewEntry, reviewerProfile);
  const photoApprove = resolveActorPhoto(approveEntry, adminProfile);

  assert.strictEqual(photoSubmit, 'data:image/jpeg;base64,farhadPhotoData');
  assert.strictEqual(photoReview, 'data:image/jpeg;base64,sarahPhotoData');
  assert.strictEqual(photoApprove, 'data:image/jpeg;base64,ahmadPhotoData');

  // Verify none of them are mixed up or identical
  assert.notStrictEqual(photoSubmit, photoReview);
  assert.notStrictEqual(photoReview, photoApprove);
});

// -------------------------------------------------------------
// 4. REJECTION EVENTS & PRESERVATION ACROSS WORKFLOW
// -------------------------------------------------------------
console.log('\n--- 4. REJECTION EVENTS & AUDIT PRESERVATION ---');

runTest('Rejection event preserves full untruncated rejection reason', () => {
  const longReason =
    'The attached receipt #8812 is blurred and lacks the official tax identification stamp required by financial policy Section 4.2. Please obtain a clear scan from vendor ABC.';
  const entry: ExpenseTimelineEntry = {
    action: 'Expense Request Rejected',
    performedBy: 'mgr-100',
    performedByName: 'Finance Manager',
    performedByRole: 'invoice_manager',
    timestamp: '2026-10-09T09:15:00Z',
    rejectionReason: longReason,
  };

  assert.strictEqual(entry.rejectionReason, longReason);
  assert.strictEqual(entry.rejectionReason.length > 100, true);
});

runTest('Rejection event is preserved in timeline even after subsequent resubmission', () => {
  const mockExpense: Expense = {
    id: 'exp-101',
    title: 'Site Cabling Materials',
    amount: 15000,
    date: '2026-10-08',
    status: 'pending_manager',
    requestedBy: 'coll-01',
    requestedByName: 'Ali Collector',
    requestedByRole: 'payment_collector',
    revision: 2,
    createdAt: '2026-10-08T08:00:00Z',
    timeline: [
      {
        action: 'Submitted Expense Request',
        performedBy: 'coll-01',
        performedByName: 'Ali Collector',
        performedByRole: 'payment_collector',
        timestamp: '2026-10-08T08:00:00Z',
      },
      {
        action: 'Expense Request Rejected',
        performedBy: 'mgr-01',
        performedByName: 'Mohammad Manager',
        performedByRole: 'invoice_manager',
        timestamp: '2026-10-08T10:00:00Z',
        rejectionReason: 'Vendor receipt missing tax stamp',
      },
      {
        action: 'Expense Request Resubmitted',
        performedBy: 'coll-01',
        performedByName: 'Ali Collector',
        performedByRole: 'payment_collector',
        timestamp: '2026-10-08T11:00:00Z',
        corrections: 'Uploaded stamped invoice copy from vendor',
        correctionDescription: 'Uploaded stamped invoice copy from vendor',
        revision: 2,
      },
    ],
    note: '',
  };

  const timeline = normalizeExpenseTimeline(mockExpense);
  assert.strictEqual(timeline.length, 3);
  assert.strictEqual(timeline[1].action, 'Expense Request Rejected');
  assert.strictEqual(timeline[1].rejectionReason, 'Vendor receipt missing tax stamp');
  assert.strictEqual(timeline[2].action, 'Expense Request Resubmitted');
  assert.strictEqual(timeline[2].correctionDescription, 'Uploaded stamped invoice copy from vendor');
  assert.strictEqual(timeline[2].revision, 2);
});

// -------------------------------------------------------------
// 5. RESUBMISSION & EDIT HISTORY
// -------------------------------------------------------------
console.log('\n--- 5. RESUBMISSION & EDIT HISTORY ---');

runTest('Resubmission event contains revision number and exact correction description', () => {
  const entry: ExpenseTimelineEntry = {
    action: 'Expense Request Resubmitted',
    performedBy: 'user-77',
    performedByName: 'Jamil Requester',
    performedByRole: 'payment_collector',
    timestamp: '2026-10-10T16:00:00Z',
    corrections: 'Reduced amount from 25,000 to 22,000 AFN per discount agreement',
    correctionDescription: 'Reduced amount from 25,000 to 22,000 AFN per discount agreement',
    revision: 2,
  };

  assert.strictEqual(entry.revision, 2);
  assert.strictEqual(
    entry.correctionDescription,
    'Reduced amount from 25,000 to 22,000 AFN per discount agreement'
  );
  assert.strictEqual(resolveEventStatus(entry), 'resubmitted');
});

runTest('Reconstructed timeline includes previous revisions from expense.revisions array', () => {
  const legacyExpense: Expense = {
    id: 'exp-legacy-01',
    title: 'Fiber Splice Repair',
    amount: 8000,
    date: '2026-10-01',
    status: 'approved',
    requestedBy: 'user-01',
    requestedByName: 'Karim',
    requestedByRole: 'payment_collector',
    createdAt: '2026-10-01T09:00:00Z',
    revisions: [
      {
        revisionNumber: 1,
        title: 'Fiber Splice Repair',
        amount: 8000,
        date: '2026-10-01',
        status: 'rejected',
        rejectionReason: 'Need photos of completed splice',
        rejectedBy: 'mgr-01',
        rejectedByName: 'Manager Zahid',
        timestamp: '2026-10-01T11:00:00Z',
        corrections: 'Attached splice enclosure photos',
        correctionDescription: 'Attached splice enclosure photos',
      },
    ],
    adminApprovedAt: '2026-10-01T15:00:00Z',
    adminApprovedBy: 'admin-01',
    adminApprovedByName: 'Admin Sarwan',
    note: '',
  };

  const timeline = normalizeExpenseTimeline(legacyExpense);
  assert.strictEqual(timeline.length >= 4, true);

  const rejectionEvent = timeline.find((e) => e.rejectionReason === 'Need photos of completed splice');
  assert.ok(rejectionEvent, 'Rejection event found in reconstructed timeline');
  assert.strictEqual(rejectionEvent?.performedByName, 'Manager Zahid');

  const resubmissionEvent = timeline.find((e) => e.action === 'Expense Request Resubmitted');
  assert.ok(resubmissionEvent, 'Resubmission event found in reconstructed timeline');
  assert.strictEqual(resubmissionEvent?.correctionDescription, 'Attached splice enclosure photos');
});

// -------------------------------------------------------------
// 6. ACCURATE DATES AND TIMES
// -------------------------------------------------------------
console.log('\n--- 6. ACCURATE DATES AND TIMES (NO INVENTED DATES) ---');

runTest('formatDateTime displays both date and time accurately', () => {
  const isoStr = '2026-10-12T14:30:00Z';
  const formatted = formatDateTime(isoStr);
  assert.strictEqual(typeof formatted, 'string');
  assert.strictEqual(formatted.includes('2026'), true);
  assert.strictEqual(formatted.includes(':'), true);
});

runTest('formatDateTime provides clear fallback for missing timestamp without substituting current time', () => {
  const fallback = formatDateTime(undefined);
  assert.strictEqual(fallback, 'Date/Time not recorded');

  const emptyFallback = formatDateTime('');
  assert.strictEqual(emptyFallback, 'Date/Time not recorded');

  const nullFallback = formatDateTime(null);
  assert.strictEqual(nullFallback, 'Date/Time not recorded');
});

runTest('formatDateTime handles invalid date string safely', () => {
  const result = formatDateTime('not-a-valid-date');
  assert.strictEqual(result, 'not-a-valid-date');
});

// -------------------------------------------------------------
// 7. CHRONOLOGICAL ORDERING
// -------------------------------------------------------------
console.log('\n--- 7. STRICT CHRONOLOGICAL ORDERING ---');

runTest('normalizeExpenseTimeline sorts out-of-order events strictly chronologically', () => {
  const unorderedExpense: Expense = {
    id: 'exp-order-01',
    title: 'Server Rack Fan',
    amount: 3500,
    date: '2026-10-05',
    status: 'approved',
    requestedBy: 'user-01',
    requestedByName: 'Hamid',
    requestedByRole: 'invoice_manager',
    createdAt: '2026-10-05T08:00:00Z',
    timeline: [
      {
        action: 'Super Admin Approved',
        performedBy: 'admin-01',
        performedByName: 'Admin',
        performedByRole: 'super_admin',
        timestamp: '2026-10-05T16:00:00Z',
      },
      {
        action: 'Submitted Expense Request',
        performedBy: 'user-01',
        performedByName: 'Hamid',
        performedByRole: 'invoice_manager',
        timestamp: '2026-10-05T08:00:00Z',
      },
      {
        action: 'Invoice Manager Approved',
        performedBy: 'mgr-02',
        performedByName: 'Wahid Manager',
        performedByRole: 'invoice_manager',
        timestamp: '2026-10-05T11:00:00Z',
      },
    ],
    note: '',
  };

  const sortedTimeline = normalizeExpenseTimeline(unorderedExpense);
  assert.strictEqual(sortedTimeline.length, 3);
  assert.strictEqual(sortedTimeline[0].action, 'Submitted Expense Request');
  assert.strictEqual(sortedTimeline[1].action, 'Invoice Manager Approved');
  assert.strictEqual(sortedTimeline[2].action, 'Super Admin Approved');
});

// -------------------------------------------------------------
// 8. COLLECTOR PRIVACY & ROLE-BASED ACCESS INVARIANTS
// -------------------------------------------------------------
console.log('\n--- 8. COLLECTOR PRIVACY & ROLE-BASED ACCESS INVARIANTS ---');

runTest('Payment Collector cannot view pending_manager expense requests of other collectors', () => {
  const expenses: Expense[] = [
    {
      id: 'exp-coll-1',
      title: 'Collector 1 Expense',
      amount: 4000,
      date: '2026-10-10',
      status: 'pending_manager',
      requestedBy: 'collector-alpha',
      requestedByName: 'Alpha',
      requestedByRole: 'payment_collector',
      createdAt: '2026-10-10T10:00:00Z',
      note: '',
    },
    {
      id: 'exp-coll-2',
      title: 'Collector 2 Expense',
      amount: 5000,
      date: '2026-10-10',
      status: 'pending_manager',
      requestedBy: 'collector-beta',
      requestedByName: 'Beta',
      requestedByRole: 'payment_collector',
      createdAt: '2026-10-10T11:00:00Z',
      note: '',
    },
    {
      id: 'exp-approved',
      title: 'Approved Hardware',
      amount: 6000,
      date: '2026-10-10',
      status: 'approved',
      requestedBy: 'collector-alpha',
      requestedByName: 'Alpha',
      requestedByRole: 'payment_collector',
      createdAt: '2026-10-10T09:00:00Z',
      note: '',
    },
  ];

  // Beta collector checks expenses
  const betaFiltered = filterExpensesForUser(expenses, 'payment_collector', 'collector-beta');
  const betaCanSeeAlphaPending = betaFiltered.some((e) => e.id === 'exp-coll-1');
  assert.strictEqual(
    betaCanSeeAlphaPending,
    false,
    'Collector Beta must NOT see Collector Alpha pending_manager expense'
  );

  const betaCanSeeBetaPending = betaFiltered.some((e) => e.id === 'exp-coll-2');
  assert.strictEqual(
    betaCanSeeBetaPending,
    true,
    'Collector Beta can see their own pending_manager expense'
  );
});

runTest('Invoice Manager can view all pending_manager expenses for review', () => {
  const expenses: Expense[] = [
    {
      id: 'exp-coll-1',
      title: 'Collector 1 Expense',
      amount: 4000,
      date: '2026-10-10',
      status: 'pending_manager',
      requestedBy: 'collector-alpha',
      requestedByName: 'Alpha',
      requestedByRole: 'payment_collector',
      createdAt: '2026-10-10T10:00:00Z',
      note: '',
    },
  ];

  const mgrFiltered = filterExpensesForUser(expenses, 'invoice_manager', 'mgr-01');
  assert.strictEqual(mgrFiltered.length, 1);
  assert.strictEqual(mgrFiltered[0].id, 'exp-coll-1');
});

runTest('Customer account receives zero expense records', () => {
  const expenses: Expense[] = [
    {
      id: 'exp-1',
      title: 'Hardware Cost',
      amount: 5000,
      date: '2026-10-10',
      status: 'approved',
      requestedBy: 'mgr-01',
      requestedByName: 'Manager',
      requestedByRole: 'invoice_manager',
      createdAt: '2026-10-10T10:00:00Z',
      note: '',
    },
  ];

  const custFiltered = filterExpensesForUser(expenses, 'customer', 'cust-01');
  assert.strictEqual(custFiltered.length, 0);
});

// -------------------------------------------------------------
// 9. VISUAL APPROVAL MILESTONES (PROGRESS STEPPER)
// -------------------------------------------------------------
console.log('\n--- 9. VISUAL APPROVAL MILESTONE PROGRESS INDICATORS ---');

runTest('Payment Collector workflow generates exactly 4 sequential milestones', () => {
  const collectorExp: Expense = {
    id: 'exp-c-01',
    title: 'Fuel Expenses',
    amount: 1500,
    date: '2026-10-12',
    status: 'pending_manager',
    requestedBy: 'col-01',
    requestedByName: 'Ali Collector',
    requestedByRole: 'payment_collector',
    createdAt: '2026-10-12T08:00:00Z',
    note: '',
  };
  const stages = getApprovalProgressStages(collectorExp);
  assert.strictEqual(stages.length, 4);
  assert.strictEqual(stages[0].id, 'submitted');
  assert.strictEqual(stages[1].id, 'manager_approval');
  assert.strictEqual(stages[2].id, 'admin_approval');
  assert.strictEqual(stages[3].id, 'execution');
});

runTest('Collector awaiting Manager review shows Submitted as completed and Manager as current', () => {
  const collectorExp: Expense = {
    id: 'exp-c-02',
    title: 'Hardware Tools',
    amount: 2200,
    date: '2026-10-12',
    status: 'pending_manager',
    requestedBy: 'col-01',
    requestedByName: 'Ali Collector',
    requestedByRole: 'payment_collector',
    createdAt: '2026-10-12T08:00:00Z',
    note: '',
  };
  const stages = getApprovalProgressStages(collectorExp);
  assert.strictEqual(stages[0].status, 'completed');
  assert.strictEqual(stages[1].status, 'current');
  assert.strictEqual(stages[2].status, 'upcoming');
  assert.strictEqual(stages[3].status, 'upcoming');
});

runTest('Collector approved by Manager shows Manager as completed and Super Admin as current', () => {
  const collectorExp: Expense = {
    id: 'exp-c-03',
    title: 'Hardware Tools',
    amount: 2200,
    date: '2026-10-12',
    status: 'pending_admin',
    requestedBy: 'col-01',
    requestedByName: 'Ali Collector',
    requestedByRole: 'payment_collector',
    managerApprovedAt: '2026-10-12T10:00:00Z',
    managerApprovedBy: 'mgr-01',
    createdAt: '2026-10-12T08:00:00Z',
    note: '',
  };
  const stages = getApprovalProgressStages(collectorExp);
  assert.strictEqual(stages[0].status, 'completed');
  assert.strictEqual(stages[1].status, 'completed');
  assert.strictEqual(stages[2].status, 'current');
  assert.strictEqual(stages[3].status, 'upcoming');
});

runTest('Collector fully approved shows Super Admin completed and Disbursement ready (current)', () => {
  const collectorExp: Expense = {
    id: 'exp-c-04',
    title: 'Hardware Tools',
    amount: 2200,
    date: '2026-10-12',
    status: 'approved',
    requestedBy: 'col-01',
    requestedByName: 'Ali Collector',
    requestedByRole: 'payment_collector',
    managerApprovedAt: '2026-10-12T10:00:00Z',
    managerApprovedBy: 'mgr-01',
    adminApprovedAt: '2026-10-12T12:00:00Z',
    adminApprovedBy: 'adm-01',
    createdAt: '2026-10-12T08:00:00Z',
    note: '',
  };
  const stages = getApprovalProgressStages(collectorExp);
  assert.strictEqual(stages[0].status, 'completed');
  assert.strictEqual(stages[1].status, 'completed');
  assert.strictEqual(stages[2].status, 'completed');
  assert.strictEqual(stages[3].status, 'current', 'Approved expense is ready for disbursement, not yet completed');
});

runTest('Executed Collector expense shows all 4 milestones as completed', () => {
  const collectorExp: Expense = {
    id: 'exp-c-05',
    title: 'Hardware Tools',
    amount: 2200,
    date: '2026-10-12',
    status: 'executed',
    requestedBy: 'col-01',
    requestedByName: 'Ali Collector',
    requestedByRole: 'payment_collector',
    managerApprovedAt: '2026-10-12T10:00:00Z',
    adminApprovedAt: '2026-10-12T12:00:00Z',
    executedAt: '2026-10-12T14:00:00Z',
    createdAt: '2026-10-12T08:00:00Z',
    note: '',
  };
  const stages = getApprovalProgressStages(collectorExp);
  assert.strictEqual(stages.every((s) => s.status === 'completed'), true);
});

runTest('Invoice Manager workflow generates exactly 3 milestones without fictitious manager stage', () => {
  const mgrExp: Expense = {
    id: 'exp-m-01',
    title: 'Server Hosting',
    amount: 15000,
    date: '2026-10-12',
    status: 'pending_admin',
    requestedBy: 'mgr-01',
    requestedByName: 'Sami Manager',
    requestedByRole: 'invoice_manager',
    createdAt: '2026-10-12T08:00:00Z',
    note: '',
  };
  const stages = getApprovalProgressStages(mgrExp);
  assert.strictEqual(stages.length, 3);
  assert.strictEqual(stages[0].id, 'submitted');
  assert.strictEqual(stages[1].id, 'admin_approval');
  assert.strictEqual(stages[2].id, 'execution');
  assert.strictEqual(stages[0].status, 'completed');
  assert.strictEqual(stages[1].status, 'current');
  assert.strictEqual(stages[2].status, 'upcoming');
});

runTest('Rejected expense marks only the rejected stage red and preserves completed earlier stages', () => {
  const rejectedCollectorExp: Expense = {
    id: 'exp-c-rej',
    title: 'Cable Purchase',
    amount: 8000,
    date: '2026-10-12',
    status: 'rejected',
    requestedBy: 'col-01',
    requestedByName: 'Ali Collector',
    requestedByRole: 'payment_collector',
    rejectionReason: 'Exceeds monthly limit without prior quote',
    createdAt: '2026-10-12T08:00:00Z',
    note: '',
  };
  const stages = getApprovalProgressStages(rejectedCollectorExp);
  assert.strictEqual(stages[0].status, 'completed', 'Submission remains completed');
  assert.strictEqual(stages[1].status, 'rejected', 'Manager stage is rejected');
  assert.strictEqual(stages[2].status, 'upcoming', 'Super Admin stage remains upcoming');
  assert.strictEqual(stages[3].status, 'upcoming', 'Disbursement remains upcoming');
});

// -------------------------------------------------------------
// 10. UNIFIED VERTICAL TIMELINE PENDING STAGES
// -------------------------------------------------------------
console.log('\n--- 10. UNIFIED VERTICAL TIMELINE PENDING STAGES ---');

runTest('Pending collector expense shows Manager, Super Admin, and Disbursement along vertical line', () => {
  const pendingExp: Expense = {
    id: 'exp-c-pend',
    title: 'Fuel',
    amount: 1200,
    date: '2026-10-12',
    status: 'pending_manager',
    requestedBy: 'col-01',
    requestedByName: 'Ali Collector',
    requestedByRole: 'payment_collector',
    createdAt: '2026-10-12T08:00:00Z',
    note: '',
  };
  const pendingStages = getPendingStagesForTimeline(pendingExp);
  assert.strictEqual(pendingStages.length, 3);
  assert.strictEqual(pendingStages[0].id, 'manager_approval');
  assert.strictEqual(pendingStages[0].status, 'current');
  assert.strictEqual(pendingStages[1].id, 'admin_approval');
  assert.strictEqual(pendingStages[1].status, 'upcoming');
  assert.strictEqual(pendingStages[2].id, 'execution');
  assert.strictEqual(pendingStages[2].status, 'upcoming');
});

runTest('Collector expense approved by Manager shows Super Admin review as current and Disbursement as upcoming', () => {
  const mgrApprovedExp: Expense = {
    id: 'exp-c-mgr-appr',
    title: 'Tools',
    amount: 3000,
    date: '2026-10-12',
    status: 'pending_admin',
    requestedBy: 'col-01',
    requestedByName: 'Ali Collector',
    requestedByRole: 'payment_collector',
    managerApprovedAt: '2026-10-12T10:00:00Z',
    createdAt: '2026-10-12T08:00:00Z',
    note: '',
  };
  const pendingStages = getPendingStagesForTimeline(mgrApprovedExp);
  assert.strictEqual(pendingStages.length, 2);
  assert.strictEqual(pendingStages[0].id, 'admin_approval');
  assert.strictEqual(pendingStages[0].status, 'current');
  assert.strictEqual(pendingStages[1].id, 'execution');
  assert.strictEqual(pendingStages[1].status, 'upcoming');
});

runTest('Fully approved expense shows only Disbursement as current', () => {
  const approvedExp: Expense = {
    id: 'exp-appr',
    title: 'Supplies',
    amount: 5000,
    date: '2026-10-12',
    status: 'approved',
    requestedBy: 'mgr-01',
    requestedByName: 'Sami Manager',
    requestedByRole: 'invoice_manager',
    adminApprovedAt: '2026-10-12T11:00:00Z',
    createdAt: '2026-10-12T08:00:00Z',
    note: '',
  };
  const pendingStages = getPendingStagesForTimeline(approvedExp);
  assert.strictEqual(pendingStages.length, 1);
  assert.strictEqual(pendingStages[0].id, 'execution');
  assert.strictEqual(pendingStages[0].status, 'current');
  assert.strictEqual(pendingStages[0].statusBadgeLabel, 'Ready for Disbursement');
});

runTest('Executed expense has zero pending stages', () => {
  const executedExp: Expense = {
    id: 'exp-exec',
    title: 'Hardware',
    amount: 8000,
    date: '2026-10-12',
    status: 'executed',
    requestedBy: 'mgr-01',
    requestedByName: 'Sami Manager',
    requestedByRole: 'invoice_manager',
    executedAt: '2026-10-12T14:00:00Z',
    createdAt: '2026-10-12T08:00:00Z',
    note: '',
  };
  const pendingStages = getPendingStagesForTimeline(executedExp);
  assert.strictEqual(pendingStages.length, 0);
});

runTest('Rejected expense shows Request Resubmission as current pending stage', () => {
  const rejectedExp: Expense = {
    id: 'exp-rej',
    title: 'Equipment',
    amount: 4000,
    date: '2026-10-12',
    status: 'rejected',
    requestedBy: 'col-01',
    requestedByName: 'Ali Collector',
    requestedByRole: 'payment_collector',
    rejectionReason: 'Missing invoice receipt',
    createdAt: '2026-10-12T08:00:00Z',
    note: '',
  };
  const pendingStages = getPendingStagesForTimeline(rejectedExp);
  assert.strictEqual(pendingStages.length, 1);
  assert.strictEqual(pendingStages[0].id, 'resubmission');
  assert.strictEqual(pendingStages[0].status, 'current');
  assert.strictEqual(pendingStages[0].statusBadgeLabel, 'Awaiting Resubmission');
});

// -------------------------------------------------------------
// 11. STAGE TITLES, ACTION DESCRIPTIONS & SEPARATED STATUS BADGES
// -------------------------------------------------------------
console.log('\n--- 11. STAGE TITLES, ACTION DESCRIPTIONS & SEPARATED STATUS BADGES ---');

runTest('getEventStageTitle resolves Request Submitted for initial submission', () => {
  const entry: ExpenseTimelineEntry = {
    action: 'Expense Request Submitted',
    performedBy: 'col-01',
    performedByName: 'Ali Collector',
    performedByRole: 'payment_collector',
    timestamp: '2026-10-12T08:00:00Z',
  };
  const title = getEventStageTitle(entry, 'submitted');
  assert.strictEqual(title, 'Request Submitted');
});

runTest('getEventStageTitle resolves Rejection Event for rejected event', () => {
  const entry: ExpenseTimelineEntry = {
    action: 'Expense Request Rejected',
    performedBy: 'mgr-01',
    performedByName: 'Mohammad Manager',
    performedByRole: 'invoice_manager',
    rejectionReason: 'Missing receipt',
    timestamp: '2026-10-12T09:00:00Z',
  };
  const title = getEventStageTitle(entry, 'rejected');
  assert.strictEqual(title, 'Rejection Event');
});

runTest('getEventStageTitle resolves Resubmission Event for resubmitted event', () => {
  const entry: ExpenseTimelineEntry = {
    action: 'Expense Request Resubmitted',
    performedBy: 'col-01',
    performedByName: 'Ali Collector',
    performedByRole: 'payment_collector',
    corrections: 'Attached receipt',
    timestamp: '2026-10-12T10:00:00Z',
  };
  const title = getEventStageTitle(entry, 'resubmitted');
  assert.strictEqual(title, 'Resubmission Event');
});

runTest('getEventStageTitle resolves Manager Approval and Super Admin Approval distinctly', () => {
  const mgrEntry: ExpenseTimelineEntry = {
    action: 'Invoice Manager Approved',
    performedBy: 'mgr-01',
    performedByName: 'Mohammad Manager',
    performedByRole: 'invoice_manager',
    timestamp: '2026-10-12T11:00:00Z',
  };
  assert.strictEqual(getEventStageTitle(mgrEntry, 'approved'), 'Manager Approval');

  const adminEntry: ExpenseTimelineEntry = {
    action: 'Super Admin Approved',
    performedBy: 'adm-01',
    performedByName: 'Ahmad Super Admin',
    performedByRole: 'super_admin',
    timestamp: '2026-10-12T12:00:00Z',
  };
  assert.strictEqual(getEventStageTitle(adminEntry, 'approved'), 'Super Admin Approval');
});

runTest('getActionDescription provides readable flow description with expense amount', () => {
  const submitEntry: ExpenseTimelineEntry = {
    action: 'Expense Request Submitted',
    performedBy: 'col-01',
    performedByName: 'Ali Collector',
    performedByRole: 'payment_collector',
    timestamp: '2026-10-12T08:00:00Z',
  };
  const desc = getActionDescription(submitEntry, 'submitted', 5000);
  assert.strictEqual(desc.includes('5,000'), true);
  assert.strictEqual(desc.includes('AFN'), true);
});

console.log('\n================================================================');
console.log(` TIMELINE TEST SUMMARY: ${passedTests} / ${totalTests} TESTS PASSED`);
if (passedTests === totalTests) {
  console.log(' ALL EXPENSE AUDIT TIMELINE TESTS PASSED SUCCESSFULLY! ✓');
} else {
  console.error(' SOME TESTS FAILED!');
  process.exitCode = 1;
}
console.log('================================================================\n');
