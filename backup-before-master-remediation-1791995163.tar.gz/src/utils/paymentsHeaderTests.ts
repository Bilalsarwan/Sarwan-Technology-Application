/**
 * Test suite verifying Payments Header and Record Payment Action requirements:
 * 1. Title: "Payments"
 * 2. Subtitle: "Manage and track all customer payments"
 * 3. Primary Record Payment button with icon and responsive behavior
 * 4. Preserved existing onAddPayment entry point
 */
import React from 'react';
import { renderToStaticMarkup } from 'react-dom/server';
import { PaymentsView } from '../views/PaymentsView';
import { AuthContext } from '../context/AuthContext';
import { UserProfile, UserPermissions, BusinessSettings } from '../types';

interface TestResult {
  name: string;
  passed: boolean;
  error?: string;
}

const results: TestResult[] = [];

function test(name: string, fn: () => void) {
  try {
    fn();
    results.push({ name, passed: true });
  } catch (err: any) {
    results.push({ name, passed: false, error: err?.message || String(err) });
  }
}

function expect(condition: boolean, msg: string) {
  if (!condition) throw new Error(msg);
}

const mockSettings: BusinessSettings = {
  companyName: 'Sarwan Technology',
  phone: '0731339014',
  whatsapp: '0778771020',
  email: 'info@sarwan.af',
  address: 'Kabul, Afghanistan',
  currency: 'AFN',
  invoiceNote: 'Thank you for your business.',
} as BusinessSettings;

const mockPermissions: UserPermissions = {
  canViewDashboard: true,
  canViewInvoices: true,
  canCreateInvoice: true,
  canEditInvoice: true,
  canVoidInvoice: true,
  canViewPayments: true,
  canCollectPayment: true,
  canReversePayment: true,
  canViewCustomers: true,
  canManageCustomers: true,
  canViewExpenses: true,
  canManageExpenses: true,
  canViewReports: true,
  canExportReports: true,
  canManageSettings: true,
  canManageStaff: true,
  canManageUsers: true,
  canManageRequests: true,
  canManageProjects: true,
  canViewAuditLogs: true,
  canExportBackup: true,
};

const mockUserProfile: UserProfile = {
  id: 'usr-admin-1',
  name: 'Ahmad Admin',
  username: 'ahmad_admin',
  role: 'super_admin',
  status: 'active',
  email: 'admin@sarwan.af',
  createdAt: new Date().toISOString(),
};

function renderPaymentsView(onAddPaymentMock = () => {}): string {
  const authContextValue: any = {
    currentUser: null,
    userProfile: mockUserProfile,
    userRole: 'super_admin',
    permissions: mockPermissions,
    isAuthorized: true,
    isSuperAdmin: true,
    isInvoiceManager: false,
    isPaymentCollector: false,
    isCustomer: false,
    loading: false,
    error: null,
    portalMode: 'staff',
    currentCustomer: null,
    activeCustomer: null,
    hasRole: () => true,
    hasPermission: () => true,
    signInWithGoogle: async () => {},
    signInWithUsernameAndPassword: async () => {},
    changeMandatoryPassword: async () => {},
    signOutUser: async () => {},
    clearError: () => {},
    updateCurrentUserProfile: async () => {},
  };

  return renderToStaticMarkup(
    React.createElement(
      AuthContext.Provider,
      { value: authContextValue },
      React.createElement(PaymentsView, {
        payments: [],
        invoices: [],
        settings: mockSettings,
        onAddPayment: onAddPaymentMock,
        onAddCorrection: () => {},
        onSelectInvoice: () => {},
      })
    )
  );
}

export function runPaymentsHeaderTests(): { total: number; passed: number; failed: number } {
  test('Payments Header Title & Subtitle', () => {
    const markup = renderPaymentsView();

    // Verify Title
    expect(markup.includes('>Payments<'), 'Header title is exactly "Payments"');
    expect(!markup.includes('>Cash Payment Ledger<'), 'Replaced old "Cash Payment Ledger" title');

    // Verify Subtitle
    expect(
      markup.includes('Manage and track all customer payments'),
      'Header subtitle is exactly "Manage and track all customer payments"'
    );
  });

  test('Record Payment Action Button', () => {
    const markup = renderPaymentsView();

    // Verify button exists with correct ID and title
    expect(markup.includes('id="btn-record-payment"'), 'Record payment button has ID btn-record-payment');
    expect(markup.includes('Record Payment'), 'Button contains "Record Payment" text');
    expect(markup.includes('aria-label="Record Payment"'), 'Button has accessibility aria-label="Record Payment"');

    // Verify prominent primary styling
    expect(markup.includes('bg-[#2563EB]') || markup.includes('bg-neutral-900'), 'Button uses prominent primary background');
    expect(markup.includes('text-white'), 'Button uses white text');
  });

  test('Adjustment Button Completely Removed', () => {
    const markup = renderPaymentsView();

    // Verify Adjustment button is completely removed
    expect(!markup.includes('>Adjustment<'), 'Adjustment text is completely absent');
    expect(!markup.includes('title="Super Admin Ledger Adjustment"'), 'Adjustment title is completely absent');
    expect(!markup.includes('aria-label="Adjustment"'), 'Adjustment aria-label is completely absent');
  });

  test('Responsive Behavior on Desktop and Mobile', () => {
    const markup = renderPaymentsView();

    // Desktop text visibility
    expect(
      markup.includes('<span class="hidden sm:inline">Record Payment</span>'),
      'Text is hidden on small screens and shown inline on sm: (desktop/tablet)'
    );

    // Compact mobile padding
    expect(
      markup.includes('p-2 sm:px-4 sm:py-2.5'),
      'Button uses compact p-2 on mobile and sm:px-4 sm:py-2.5 on desktop'
    );

    // Header layout flex containment
    expect(
      markup.includes('flex flex-row items-start sm:items-center justify-between gap-3 sm:gap-4'),
      'Header uses non-awkward flex layout that prevents overlapping on all screen sizes'
    );
  });

  console.log('===============================================================');
  console.log('       PAYMENTS HEADER VERIFICATION TEST RESULTS               ');
  console.log('===============================================================');

  let passed = 0;
  let failed = 0;

  results.forEach((r) => {
    if (r.passed) {
      passed++;
      console.log(`[✓ PASS] ${r.name}`);
    } else {
      failed++;
      console.error(`[✗ FAIL] ${r.name}: ${r.error}`);
    }
  });

  console.log('---------------------------------------------------------------');
  console.log(`TOTAL: ${results.length} Tests | PASSED: ${passed} | FAILED: ${failed}`);
  console.log('===============================================================');

  return { total: results.length, passed, failed };
}

// Auto-run when executed directly
if (process.argv[1] && process.argv[1].endsWith('paymentsHeaderTests.ts')) {
  const summary = runPaymentsHeaderTests();
  if (summary.failed > 0) {
    process.exit(1);
  }
}
