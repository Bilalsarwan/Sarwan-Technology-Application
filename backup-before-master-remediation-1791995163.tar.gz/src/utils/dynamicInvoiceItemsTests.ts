/**
 * Verification test suite for Dynamic Invoice Items in Invoice Create/Update flows.
 * Verifies removal of the 20-item cap and confirms dynamic item entry, updating,
 * calculations, numbering, and reopening without truncation.
 */
import { Invoice, InvoiceItem } from '../types';
import { createDefault20Items } from '../services/db';
import { calculateLineTotal, calculateInvoiceTotal } from '../utils/format';

interface TestResult {
  suite: string;
  name: string;
  passed: boolean;
  error?: string;
}

const results: TestResult[] = [];

function test(suiteOrName: string, nameOrFn: string | (() => void), maybeFn?: () => void) {
  const suite = typeof nameOrFn === 'function' ? 'Dynamic Items' : suiteOrName;
  const name = typeof nameOrFn === 'function' ? suiteOrName : (nameOrFn as string);
  const fn = typeof nameOrFn === 'function' ? nameOrFn : maybeFn!;
  try {
    fn();
    results.push({ suite, name, passed: true });
  } catch (err: any) {
    results.push({ suite, name, passed: false, error: err?.message || String(err) });
  }
}

function expect(condition: boolean, msg: string) {
  if (!condition) throw new Error(msg);
}

export function runDynamicInvoiceItemsTests(): { total: number; passed: number; failed: number } {
  const makeItem = (sNo: number, desc = `Product Item ${sNo}`, qty: number | '' = 1, price: number | '' = 1000): InvoiceItem => ({
    sNo,
    description: desc,
    quantity: qty,
    unitPrice: price,
    totalAmount: calculateLineTotal(qty, price),
  });

  // Test Suite 1: Initial Default Form State
  test('Create Invoice - Initial State', 'Initializes with 20 rows for clean backward-compatible UI', () => {
    const items = createDefault20Items();
    expect(items.length === 20, `Expected 20 initial rows, got ${items.length}`);
    expect(items[0].sNo === 1, 'First row sNo is 1');
    expect(items[19].sNo === 20, 'Twentieth row sNo is 20');
  });

  // Test Suite 2: Adding Items Beyond 20
  test('Create Invoice - Add Item 21', 'Continuously adds item #21 without restriction', () => {
    let items = createDefault20Items();
    // Simulate user clicking Add Item
    items = [
      ...items,
      {
        sNo: items.length + 1,
        description: 'New Camera 21',
        quantity: 2,
        unitPrice: 5000,
        totalAmount: calculateLineTotal(2, 5000),
      },
    ];
    expect(items.length === 21, `Expected 21 items, got ${items.length}`);
    expect(items[20].sNo === 21, `Item #21 has sNo 21, got ${items[20].sNo}`);
    expect(items[20].totalAmount === 10000, `Item #21 totalAmount is 10000, got ${items[20].totalAmount}`);
  });

  test('Create Invoice - Add Items up to 30', 'Continuously adds items up to 30 items dynamically', () => {
    let items = createDefault20Items();
    for (let i = 21; i <= 30; i++) {
      items = [
        ...items,
        {
          sNo: items.length + 1,
          description: `Device #${i}`,
          quantity: 1,
          unitPrice: 1500,
          totalAmount: 1500,
        },
      ];
    }
    expect(items.length === 30, `Expected 30 items, got ${items.length}`);
    expect(items[29].sNo === 30, `Item #30 has sNo 30, got ${items[29].sNo}`);
    expect(items[29].description === 'Device #30', 'Item 30 has correct description');
  });

  test('Create Invoice - Continuous Growth', 'No artificial cap at 50 or 100 items', () => {
    let items: InvoiceItem[] = [];
    for (let i = 1; i <= 60; i++) {
      items.push(makeItem(i, `Fiber Component #${i}`, 1, 200));
    }
    expect(items.length === 60, `Expected 60 items, got ${items.length}`);
    const total = calculateInvoiceTotal(items);
    expect(total === 60 * 200, `Expected total 12000, got ${total}`);
  });

  // Test Suite 3: Updating Existing Invoice from 20 -> 21 and 20 -> 30 items
  test('Update Invoice - Reopen & Expand from 20 to 21 items', () => {
    const existingInvoice: Partial<Invoice> = {
      id: 'inv-test-20',
      billNumber: 'ST-1065',
      items: Array.from({ length: 20 }, (_, i) => makeItem(i + 1, `CCTV Camera #${i + 1}`, 1, 2000)),
      totalAmount: 40000,
    };

    // Simulate modal opening logic
    let loadedItems: InvoiceItem[] = [];
    if (existingInvoice.items && existingInvoice.items.length >= 20) {
      loadedItems = existingInvoice.items.map((it, idx) => ({ ...it, sNo: idx + 1 }));
    } else {
      loadedItems = createDefault20Items();
    }
    expect(loadedItems.length === 20, `Loaded items length must be 20, got ${loadedItems.length}`);

    // User adds item 21
    loadedItems = [
      ...loadedItems,
      {
        sNo: loadedItems.length + 1,
        description: 'CCTV Camera #21',
        quantity: 1,
        unitPrice: 2000,
        totalAmount: 2000,
      },
    ];
    expect(loadedItems.length === 21, `Updated items must have 21 items, got ${loadedItems.length}`);
    expect(loadedItems[20].sNo === 21, `Item #21 sNo is 21`);
    expect(calculateInvoiceTotal(loadedItems) === 42000, `New total is 42000, got ${calculateInvoiceTotal(loadedItems)}`);
  });

  test('Update Invoice - Reopen & Expand from 20 to 30 items', () => {
    const existingInvoice: Partial<Invoice> = {
      id: 'inv-test-20-to-30',
      billNumber: 'ST-1066',
      items: Array.from({ length: 20 }, (_, i) => makeItem(i + 1, `Switch Port #${i + 1}`, 2, 500)),
      totalAmount: 20000,
    };

    let loadedItems = existingInvoice.items!.map((it, idx) => ({ ...it, sNo: idx + 1 }));
    // Add 10 more items
    for (let i = 21; i <= 30; i++) {
      loadedItems = [
        ...loadedItems,
        makeItem(i, `Switch Port #${i}`, 2, 500),
      ];
    }
    expect(loadedItems.length === 30, `Expected 30 items, got ${loadedItems.length}`);
    expect(loadedItems[29].sNo === 30, `Item #30 has sNo 30`);
    expect(calculateInvoiceTotal(loadedItems) === 30000, `Expected total 30000, got ${calculateInvoiceTotal(loadedItems)}`);
  });

  // Test Suite 4: Reopening Invoice with > 20 items (No Truncation)
  test('Reopening Invoice - Preserves all 25 items without truncation', () => {
    const savedInvoiceWith25Items: Invoice = {
      id: 'inv-saved-25',
      billNumber: 'ST-1067',
      customerId: 'cust-1',
      customerSnapshot: { id: 'cust-1', name: 'Kabul IT Solutions', phone: '0700123456', address: 'Kabul', companyName: 'Kabul IT Solutions' },
      companySnapshot: { companyName: 'Sarwan Technology' } as any,
      date: '2026-10-05',
      items: Array.from({ length: 25 }, (_, i) => makeItem(i + 1, `Optical Cable Roll #${i + 1}`, 1, 1500)),
      totalAmount: 37500,
      note: 'Bulk cabling',
      status: 'Unpaid',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    // Simulate modal reopening logic (exact logic from InvoiceModal.tsx)
    let loadedItems: InvoiceItem[] = [];
    if (savedInvoiceWith25Items.items && savedInvoiceWith25Items.items.length > 0) {
      if (savedInvoiceWith25Items.items.length < 20) {
        const padded = createDefault20Items();
        savedInvoiceWith25Items.items.forEach((it, idx) => {
          padded[idx] = { ...it, sNo: idx + 1 };
        });
        loadedItems = padded;
      } else {
        loadedItems = savedInvoiceWith25Items.items.map((it, idx) => ({
          ...it,
          sNo: idx + 1,
        }));
      }
    } else {
      loadedItems = createDefault20Items();
    }

    expect(loadedItems.length === 25, `Expected all 25 items preserved upon reopening, got ${loadedItems.length}`);
    expect(loadedItems[20].description === 'Optical Cable Roll #21', 'Item 21 is preserved intact');
    expect(loadedItems[24].description === 'Optical Cable Roll #25', 'Item 25 is preserved intact');
    expect(loadedItems[24].sNo === 25, 'Item 25 has sNo 25');
  });

  // Test Suite 5: Dynamic Item Removal & S.No. Re-indexing
  test('Item Removal - Removing item #10 from 25 items dynamically re-indexes to 24 items', () => {
    let items = Array.from({ length: 25 }, (_, i) => makeItem(i + 1, `Inventory Unit ${i + 1}`, 1, 100));
    expect(items.length === 25, 'Starts with 25 items');
    expect(items[9].description === 'Inventory Unit 10', 'Index 9 is Item 10');

    // Remove item #10 (index 9)
    const removeIndex = 9;
    const filtered = items.filter((_, idx) => idx !== removeIndex);
    items = filtered.map((item, idx) => ({
      ...item,
      sNo: idx + 1,
    }));

    expect(items.length === 24, `Expected 24 items after removal, got ${items.length}`);
    // What was item #11 is now at index 9, and its sNo should be 10
    expect(items[9].description === 'Inventory Unit 11', 'Next item took the slot of removed item');
    expect(items[9].sNo === 10, `Item description #11 now has sNo 10, got ${items[9].sNo}`);
    expect(items[23].sNo === 24, `Last item has sNo 24, got ${items[23].sNo}`);
  });

  // Test Suite 6: Calculations with Any Number of Items
  test('Calculations - Full arithmetic integrity across 21 and 30 items', () => {
    const items21: InvoiceItem[] = Array.from({ length: 21 }, (_, i) => ({
      sNo: i + 1,
      description: `Item ${i + 1}`,
      quantity: 3,
      unitPrice: 100,
      totalAmount: calculateLineTotal(3, 100),
    }));
    // 21 * 300 = 6300
    expect(calculateInvoiceTotal(items21) === 6300, `Expected total 6300 for 21 items, got ${calculateInvoiceTotal(items21)}`);

    const items30: InvoiceItem[] = Array.from({ length: 30 }, (_, i) => ({
      sNo: i + 1,
      description: `Item ${i + 1}`,
      quantity: 5,
      unitPrice: 200,
      totalAmount: calculateLineTotal(5, 200),
    }));
    // 30 * 1000 = 30000
    expect(calculateInvoiceTotal(items30) === 30000, `Expected total 30000 for 30 items, got ${calculateInvoiceTotal(items30)}`);
  });

  // Test Suite 7: Backward Compatibility
  test('Backward Compatibility - Invoice with 3 items is padded cleanly to 20 rows for editing', () => {
    const smallInvoice: Partial<Invoice> = {
      items: [
        makeItem(1, 'Item 1', 1, 1000),
        makeItem(2, 'Item 2', 2, 2000),
        makeItem(3, 'Item 3', 3, 3000),
      ],
    };

    let loadedItems: InvoiceItem[] = [];
    if (smallInvoice.items && smallInvoice.items.length < 20) {
      const padded = createDefault20Items();
      smallInvoice.items.forEach((it, idx) => {
        padded[idx] = { ...it, sNo: idx + 1 };
      });
      loadedItems = padded;
    }
    expect(loadedItems.length === 20, `Expected padded length of 20, got ${loadedItems.length}`);
    expect(loadedItems[0].description === 'Item 1', 'Item 1 intact');
    expect(loadedItems[1].description === 'Item 2', 'Item 2 intact');
    expect(loadedItems[2].description === 'Item 3', 'Item 3 intact');
    expect(loadedItems[3].description === '', 'Placeholder row 4 is blank');
    expect(loadedItems[19].description === '', 'Placeholder row 20 is blank');
  });

  // Report Summary
  const passed = results.filter((r) => r.passed).length;
  const failed = results.filter((r) => !r.passed).length;
  const total = results.length;

  console.log('===============================================================');
  console.log('       DYNAMIC INVOICE ITEMS VERIFICATION TEST RESULTS         ');
  console.log('===============================================================');

  const suites = Array.from(new Set(results.map((r) => r.suite)));
  suites.forEach((suite) => {
    const suiteResults = results.filter((r) => r.suite === suite);
    const suitePassed = suiteResults.filter((r) => r.passed).length;
    const allPassed = suitePassed === suiteResults.length;

    console.log(`\n[${allPassed ? '✓ PASS' : '✗ FAIL'}] ${suite} (${suitePassed}/${suiteResults.length} passed)`);
    suiteResults.forEach((r) => {
      if (r.passed) {
        console.log(`  ✓ ${r.name}`);
      } else {
        console.log(`  ✗ ${r.name}: ${r.error}`);
      }
    });
  });

  console.log('\n---------------------------------------------------------------');
  console.log(`TOTAL: ${passed}/${total} Tests Passed`);
  console.log(`OVERALL STATUS: ${failed === 0 ? 'ALL TESTS PASSED' : 'SOME TESTS FAILED'}`);
  console.log('===============================================================');

  return { total, passed, failed };
}

// Auto-run when executed directly via tsx
runDynamicInvoiceItemsTests();
