import {
  Customer,
  Invoice,
  Payment,
  CustomerType,
  CustomerStatus,
} from '../types';
import {
  normalizePhone,
  isPhoneMatch,
  findDuplicatePhoneCustomer,
  normalizeCustomerStatus,
  migrateCustomerId,
  validateCustomerData,
} from './customerValidation';
import { calculateCustomerSummary } from './format';

let totalTests = 0;
let passedTests = 0;

function assert(condition: boolean, testName: string, details?: any) {
  totalTests++;
  if (condition) {
    passedTests++;
    console.log(`  ✓ PASS: ${testName}`);
  } else {
    console.error(`  ✗ FAIL: ${testName}`, details || '');
  }
}

console.log('\n======================================================');
console.log('SARWAN TECHNOLOGY - CUSTOMER MODULE SPECIFICATION TESTS');
console.log('======================================================\n');

// -------------------------------------------------------------------------
// 1. Customer Data Model & Validation
// -------------------------------------------------------------------------
console.log('--- 1. CUSTOMER DATA MODEL & REQUIRED FIELDS ---');

const validIndividual = validateCustomerData({
  customerType: 'Individual',
  name: 'Ahmad Tariq',
  phone: '0731339014',
  email: 'ahmad.tariq@gmail.com',
  address: 'Street 4, Shahr-e Naw',
  city: 'Kabul',
  province: 'Kabul',
});
assert(validIndividual.isValid, 'Individual customer with all required fields is valid');

const invalidIndividualMissingAddress = validateCustomerData({
  customerType: 'Individual',
  name: 'Ahmad Tariq',
  phone: '0731339014',
  email: 'ahmad.tariq@gmail.com',
  address: '',
  city: 'Kabul',
  province: 'Kabul',
});
assert(!invalidIndividualMissingAddress.isValid && !!invalidIndividualMissingAddress.errors.address, 'Address is strictly required');

const businessMissingCompany = validateCustomerData({
  customerType: 'Business',
  name: 'Bilal Sarwan',
  companyName: '',
  phone: '0778771020',
  email: 'bilal@sarwantechnology.af',
  address: 'Dehbori, District 3',
  city: 'Kabul',
  province: 'Kabul',
});
assert(!businessMissingCompany.isValid && !!businessMissingCompany.errors.companyName, 'Company Name is strictly required when Customer Type = Business');

const businessValid = validateCustomerData({
  customerType: 'Business',
  name: 'Bilal Sarwan',
  companyName: 'Sarwan Tech LLC',
  phone: '0778771020',
  email: 'bilal@sarwantechnology.af',
  address: 'Dehbori, District 3',
  city: 'Kabul',
  province: 'Kabul',
});
assert(businessValid.isValid, 'Business customer with Company Name and required fields is valid');

// -------------------------------------------------------------------------
// 2. Customer ID Format & Migration
// -------------------------------------------------------------------------
console.log('\n--- 2. CUSTOMER ID FORMAT & MIGRATION ---');

assert(migrateCustomerId('CUST-1001') === 'ST-CUST-1001', 'Legacy CUST-1001 migrates to ST-CUST-1001');
assert(migrateCustomerId('CUST-1045') === 'ST-CUST-1045', 'Legacy CUST-1045 migrates to ST-CUST-1045');
assert(migrateCustomerId('ST-CUST-1002') === 'ST-CUST-1002', 'Canonical ST-CUST-1002 remains unchanged');
assert(migrateCustomerId('1003') === 'ST-CUST-1003', 'Raw numeric ID 1003 migrates to ST-CUST-1003');

// -------------------------------------------------------------------------
// 3. Status Rules & Controlled Migration
// -------------------------------------------------------------------------
console.log('\n--- 3. STATUS RULES & CONTROLLED MIGRATION ---');

assert(normalizeCustomerStatus('Active') === 'Active', 'Active normalizes to Active');
assert(normalizeCustomerStatus('active') === 'Active', 'Legacy lowercase "active" normalizes to Active');
assert(normalizeCustomerStatus('Inactive') === 'Inactive', 'Inactive normalizes to Inactive');
assert(normalizeCustomerStatus('deactivated') === 'Inactive', 'Legacy "deactivated" normalizes to Inactive');
assert(normalizeCustomerStatus('archived') === 'Inactive', 'Legacy "archived" normalizes to Inactive');
assert(normalizeCustomerStatus(undefined, true) === 'Inactive', 'isArchived=true normalizes to Inactive');
assert(normalizeCustomerStatus('Blocked') === 'Blocked', 'Blocked normalizes to Blocked');
assert(normalizeCustomerStatus('blocked') === 'Blocked', 'Lowercase "blocked" normalizes to Blocked');

// -------------------------------------------------------------------------
// 4. Phone Normalization & Duplicate Detection
// -------------------------------------------------------------------------
console.log('\n--- 4. PHONE NORMALIZATION & DUPLICATE DETECTION ---');

assert(normalizePhone('0731339014') === '731339014', 'Strips leading zero from local phone');
assert(normalizePhone('+93 73 133 9014') === '731339014', 'Normalizes international +93 format');
assert(normalizePhone('0093-73-133-9014') === '731339014', 'Normalizes 0093 international format with hyphens');
assert(isPhoneMatch('073 133 9014', '+93731339014'), 'Matches phone across local and international formatting');

const mockCustomers: Customer[] = [
  {
    id: 'cust-1',
    customerCode: 'ST-CUST-1001',
    name: 'Customer One',
    phone: '0731339014',
    address: 'Kabul',
    companyName: 'Company 1',
    note: '',
    status: 'Active',
    createdAt: '2026-01-01',
    updatedAt: '2026-01-01',
  },
  {
    id: 'cust-2',
    customerCode: 'ST-CUST-1002',
    name: 'Customer Two',
    phone: '0778771020',
    alternatePhone: '0799112233',
    address: 'Kabul',
    companyName: 'Company 2',
    note: '',
    status: 'Active',
    createdAt: '2026-01-02',
    updatedAt: '2026-01-02',
  },
];

const dupPrimary = findDuplicatePhoneCustomer('+93 73 133 9014', mockCustomers);
assert(dupPrimary?.id === 'cust-1', 'Detects duplicate against primary phone of Customer One');

const dupAlt = findDuplicatePhoneCustomer('0799 11 22 33', mockCustomers);
assert(dupAlt?.id === 'cust-2', 'Detects duplicate against alternate phone of Customer Two');

const selfEditExcluded = findDuplicatePhoneCustomer('0731339014', mockCustomers, 'cust-1');
assert(selfEditExcluded === null, 'Excludes self customer during edit phone duplicate check');

// -------------------------------------------------------------------------
// 5. Customer Financial Summary & Ledger Integrity
// -------------------------------------------------------------------------
console.log('\n--- 5. CUSTOMER FINANCIAL SUMMARY & QUOTATION EXCLUSION ---');

const mockInvoices: Invoice[] = [
  {
    id: 'inv-1',
    billNumber: 'ST-1060',
    customerId: 'cust-1',
    customerSnapshot: { id: 'cust-1', name: 'Customer One', phone: '0731339014', address: 'Kabul', companyName: '' },
    companySnapshot: {} as any,
    date: '2026-09-01',
    items: [],
    totalAmount: 10000,
    note: '',
    status: 'Partially Paid',
    billingState: 'payable',
    createdAt: '2026-09-01',
    updatedAt: '2026-09-01',
  },
  {
    id: 'inv-2',
    billNumber: 'ST-1061',
    customerId: 'cust-1',
    customerSnapshot: { id: 'cust-1', name: 'Customer One', phone: '0731339014', address: 'Kabul', companyName: '' },
    companySnapshot: {} as any,
    date: '2026-09-02',
    items: [],
    totalAmount: 5000,
    note: '',
    status: 'Unpaid',
    billingState: 'quotation', // Quotation MUST NOT count in Total Sales or Balance!
    createdAt: '2026-09-02',
    updatedAt: '2026-09-02',
  },
  {
    id: 'inv-3',
    billNumber: 'ST-1062',
    customerId: 'cust-1',
    customerSnapshot: { id: 'cust-1', name: 'Customer One', phone: '0731339014', address: 'Kabul', companyName: '' },
    companySnapshot: {} as any,
    date: '2026-09-03',
    items: [],
    totalAmount: 7000,
    note: '',
    status: 'Unpaid',
    billingState: 'rejected', // Rejected MUST NOT count in Total Sales or Balance!
    createdAt: '2026-09-03',
    updatedAt: '2026-09-03',
  },
];

const mockPayments: Payment[] = [
  {
    id: 'pay-1',
    invoiceId: 'inv-1',
    billNumber: 'ST-1060',
    customerId: 'cust-1',
    customerName: 'Customer One',
    amount: 4000,
    date: '2026-09-01',
    method: 'CASH',
    createdAt: '2026-09-01',
  },
];

const summary = calculateCustomerSummary('cust-1', mockInvoices, mockPayments);

assert(summary.totalInvoices === 3, 'Total invoices includes all 3 records');
assert(summary.totalSales === 10000, 'Total Sales counts ONLY payable invoices (AFN 10,000, excluding AFN 5,000 quote and AFN 7,000 rejected)');
assert(summary.totalPaid === 4000, 'Total Paid counts AFN 4,000 cash payment');
assert(summary.remainingBalance === 6000, 'Remaining Balance is exactly AFN 6,000 (10,000 - 4,000)');
assert(summary.financialStatus === 'Outstanding', 'Financial status is Outstanding when remaining balance > 0');

// -------------------------------------------------------------------------
// 7. ID Concurrency & Counter Safety Simulation
// -------------------------------------------------------------------------
console.log('\n--- 7. ID CONCURRENCY & COUNTER SAFETY SIMULATION ---');

// Simulate atomic counter generation:
class MockAtomicCounter {
  private current = 1000;
  private allocated = new Set<string>();

  public async allocateNext(prefix = 'ST-CUST-'): Promise<string> {
    this.current++;
    const code = `${prefix}${this.current}`;
    if (this.allocated.has(code)) {
      throw new Error(`Collision detected: ${code} was already allocated!`);
    }
    this.allocated.add(code);
    return code;
  }

  public getCount() {
    return this.allocated.size;
  }
}

const counter = new MockAtomicCounter();
const concurrentPromises = Array.from({ length: 50 }, () => counter.allocateNext());
const results = await Promise.all(concurrentPromises);
const uniqueResults = new Set(results);

assert(results.length === 50, 'Simulated 50 concurrent ID allocation requests');
assert(uniqueResults.size === 50, 'All 50 generated customer IDs are strictly unique (zero collision)');
assert(results[0] === 'ST-CUST-1001', 'First allocated ID starts at ST-CUST-1001');
assert(results[49] === 'ST-CUST-1050', '50th allocated ID is ST-CUST-1050');

// -------------------------------------------------------------------------
// 8. Migration Safety & Edge Cases
// -------------------------------------------------------------------------
console.log('\n--- 8. MIGRATION SAFETY & EDGE CASES ---');

interface RawCustomerRecord {
  id: string;
  customerCode?: string;
  customerId?: string;
  name: string;
  status?: string;
  customerType?: string;
  companyName?: string;
}

function simulateInPlaceMigration(records: RawCustomerRecord[]): {
  migrated: Array<{ id: string; newCode: string; newStatus: CustomerStatus; newType: CustomerType }>;
  seenCodes: Set<string>;
} {
  let maxNum = 1000;
  const seenCodes = new Set<string>();

  // Pass 1: find max
  records.forEach((r) => {
    const code = r.customerCode || r.customerId || '';
    const match = code.match(/(?:ST-CUST-|CUST-)?(\d+)/i);
    if (match && match[1]) {
      const n = parseInt(match[1], 10);
      if (!isNaN(n) && n > maxNum) maxNum = n;
    }
  });

  // Pass 2: migrate
  const migrated = records.map((r) => {
    const rawCode = (r.customerCode || r.customerId || '').trim();
    let targetCode = '';
    if (!rawCode) {
      maxNum++;
      targetCode = `ST-CUST-${maxNum}`;
    } else if (rawCode.startsWith('CUST-')) {
      const numPart = rawCode.replace('CUST-', '');
      targetCode = `ST-CUST-${numPart}`;
    } else if (/^\d+$/.test(rawCode)) {
      targetCode = `ST-CUST-${rawCode}`;
    } else if (rawCode.startsWith('ST-CUST-')) {
      targetCode = rawCode;
    } else {
      maxNum++;
      targetCode = `ST-CUST-${maxNum}`;
    }

    seenCodes.add(targetCode);
    const newStatus = normalizeCustomerStatus(r.status);
    const newType: CustomerType = r.customerType === 'Business' || (r.companyName && r.companyName.trim()) ? 'Business' : 'Individual';

    return {
      id: r.id, // Immutable Firebase doc ID!
      newCode: targetCode,
      newStatus,
      newType,
    };
  });

  return { migrated, seenCodes };
}

const mockLegacyRecords: RawCustomerRecord[] = [
  { id: 'doc-legacy-1', customerCode: 'CUST-1001', name: 'Legacy A', status: 'active', customerType: 'Individual' },
  { id: 'doc-legacy-2', customerId: 'CUST-1005', name: 'Legacy B', status: 'deactivated', companyName: 'Kabul Corp' },
  { id: 'doc-legacy-3', customerCode: '', name: 'Legacy NoCode', status: 'archived' }, // Missing code
  { id: 'doc-canonical', customerCode: 'ST-CUST-1020', name: 'Compliant C', status: 'Active', customerType: 'Individual' },
];

const migrationRes = simulateInPlaceMigration(mockLegacyRecords);
assert(migrationRes.migrated[0].id === 'doc-legacy-1', 'Firebase document ID doc-legacy-1 is preserved unchanged');
assert(migrationRes.migrated[0].newCode === 'ST-CUST-1001', 'Legacy CUST-1001 migrated in-place to ST-CUST-1001');
assert(migrationRes.migrated[0].newStatus === 'Active', 'Legacy lowercase active migrated to Active');
assert(migrationRes.migrated[1].newCode === 'ST-CUST-1005', 'Legacy CUST-1005 migrated in-place to ST-CUST-1005');
assert(migrationRes.migrated[1].newStatus === 'Inactive', 'Legacy deactivated migrated to Inactive');
assert(migrationRes.migrated[1].newType === 'Business', 'Inferred Business customerType from companyName');
assert(migrationRes.migrated[2].newCode === 'ST-CUST-1021', 'Missing code safely assigned next atomic code ST-CUST-1021');
assert(migrationRes.migrated[3].newCode === 'ST-CUST-1020', 'Already compliant ST-CUST-1020 code preserved unchanged');

// -------------------------------------------------------------------------
// 9. Status Restrictions & Role Authorization
// -------------------------------------------------------------------------
console.log('\n--- 9. STATUS RESTRICTIONS & ROLE AUTHORIZATION ---');

function canCreateInvoiceForCustomer(customerStatus: CustomerStatus): boolean {
  return customerStatus === 'Active';
}

function canAcceptPaymentOnInvoice(customerStatus: CustomerStatus, isExistingOutstandingInvoice: boolean): boolean {
  // Existing outstanding invoice payments are allowed even if Inactive or Blocked
  if (isExistingOutstandingInvoice) return true;
  // New standalone payments are strictly blocked for Inactive or Blocked
  return customerStatus === 'Active';
}

function canUnblockCustomer(currentUserRole: string): boolean {
  return currentUserRole === 'super_admin';
}

assert(canCreateInvoiceForCustomer('Active') === true, 'New invoice allowed for Active customer');
assert(canCreateInvoiceForCustomer('Inactive') === false, 'New invoice blocked for Inactive customer');
assert(canCreateInvoiceForCustomer('Blocked') === false, 'New invoice blocked for Blocked customer');

assert(canAcceptPaymentOnInvoice('Active', true) === true, 'Payment on existing invoice allowed for Active customer');
assert(canAcceptPaymentOnInvoice('Inactive', true) === true, 'Payment on existing outstanding invoice allowed for Inactive customer');
assert(canAcceptPaymentOnInvoice('Blocked', true) === true, 'Payment on existing outstanding invoice allowed for Blocked customer');
assert(canAcceptPaymentOnInvoice('Inactive', false) === false, 'Standalone payment blocked for Inactive customer');
assert(canAcceptPaymentOnInvoice('Blocked', false) === false, 'Standalone payment blocked for Blocked customer');

assert(canUnblockCustomer('super_admin') === true, 'Super Admin is authorized to unblock a Blocked customer');
assert(canUnblockCustomer('invoice_manager') === false, 'Invoice Manager cannot unblock a Blocked customer');
assert(canUnblockCustomer('payment_collector') === false, 'Payment Collector cannot unblock a Blocked customer');

// -------------------------------------------------------------------------
// 10. Deletion Protection Logic
// -------------------------------------------------------------------------
console.log('\n--- 10. DELETION PROTECTION LOGIC ---');

function checkCustomerDeletionSafety(invoiceCount: number, paymentCount: number): { canDelete: boolean; reason?: string } {
  if (invoiceCount > 0 || paymentCount > 0) {
    return {
      canDelete: false,
      reason: `Cannot permanently delete: Customer has ${invoiceCount} invoice(s) and ${paymentCount} payment(s).`,
    };
  }
  return { canDelete: true };
}

const checkWithHistory = checkCustomerDeletionSafety(2, 1);
assert(checkWithHistory.canDelete === false, 'Customer with financial history cannot be deleted');
assert(checkWithHistory.reason?.includes('Cannot permanently delete'), 'Clear reason provided explaining ledger retention');

const checkWithoutHistory = checkCustomerDeletionSafety(0, 0);
assert(checkWithoutHistory.canDelete === true, 'Customer with zero financial records can be deleted safely');

// -------------------------------------------------------------------------
// 11. Responsive UI Breakpoints & Layout Logic
// -------------------------------------------------------------------------
console.log('\n--- 11. RESPONSIVE UI BREAKPOINTS & LAYOUT LOGIC ---');

function getCustomerLayoutMode(width: number): 'mobile-cards' | 'desktop-table' {
  // Tailwind 'md' breakpoint is 768px: <768px renders mobile cards, >=768px renders structured table
  return width < 768 ? 'mobile-cards' : 'desktop-table';
}

function isModalWithinViewport(modalMaxHeightVh: number, viewportHeight: number): boolean {
  // max-h-[92vh] ensures 8% breathing room so header/footer don't clip offscreen
  const maxPx = (modalMaxHeightVh / 100) * viewportHeight;
  return maxPx < viewportHeight;
}

assert(getCustomerLayoutMode(320) === 'mobile-cards', 'Width 320px (iPhone SE) uses mobile cards layout');
assert(getCustomerLayoutMode(375) === 'mobile-cards', 'Width 375px (iPhone standard) uses mobile cards layout');
assert(getCustomerLayoutMode(768) === 'desktop-table', 'Width 768px (iPad portrait) uses desktop table layout');
assert(getCustomerLayoutMode(1024) === 'desktop-table', 'Width 1024px (iPad landscape/desktop) uses desktop table layout');
assert(getCustomerLayoutMode(1440) === 'desktop-table', 'Width 1440px (Wide monitor) uses desktop table layout');
assert(isModalWithinViewport(92, 600) === true, 'Modal with 92vh height fits safely in 600px viewport with no offscreen overflow');
assert(isModalWithinViewport(92, 900) === true, 'Modal with 92vh height fits safely in 900px viewport');

// -------------------------------------------------------------------------
// 12. Column Sorting Mechanics & Tie-Breaking
// -------------------------------------------------------------------------
console.log('\n--- 12. COLUMN SORTING MECHANICS & TIE-BREAKING ---');

type TestSortCol = 'customer_id' | 'name' | 'company' | 'phone' | 'balance' | 'status';
function toggleColumnSort(
  currentCol: TestSortCol,
  currentDir: 'asc' | 'desc',
  newCol: TestSortCol
): { col: TestSortCol; dir: 'asc' | 'desc' } {
  if (currentCol === newCol) {
    return { col: newCol, dir: currentDir === 'asc' ? 'desc' : 'asc' };
  }
  return { col: newCol, dir: 'asc' };
}

// First click on new column: defaults to ascending
const firstClick = toggleColumnSort('customer_id', 'desc', 'name');
assert(firstClick.col === 'name' && firstClick.dir === 'asc', 'Selecting new column applies ascending order by default');

// Second click on same column: toggles to descending
const secondClick = toggleColumnSort(firstClick.col, firstClick.dir, 'name');
assert(secondClick.col === 'name' && secondClick.dir === 'desc', 'Clicking active column reverses direction to descending');

// Third click on same column: toggles back to ascending
const thirdClick = toggleColumnSort(secondClick.col, secondClick.dir, 'name');
assert(thirdClick.col === 'name' && thirdClick.dir === 'asc', 'Third click toggles back to ascending');

// Natural numeric sorting for Customer ID codes
const testCodes = ['ST-CUST-1010', 'ST-CUST-1002', 'ST-CUST-1001', 'ST-CUST-1020'];
const sortedCodesAsc = [...testCodes].sort((a, b) => a.localeCompare(b, undefined, { numeric: true }));
assert(sortedCodesAsc[0] === 'ST-CUST-1001' && sortedCodesAsc[1] === 'ST-CUST-1002' && sortedCodesAsc[3] === 'ST-CUST-1020', 'Natural numeric comparison correctly sorts customer codes ST-CUST-1001 before 1002 before 1010');

// Case-insensitive alphabetical sorting
const testNames = ['zahid', 'Ahmad', 'bilal', 'Afsana'];
const sortedNamesAsc = [...testNames].sort((a, b) => a.localeCompare(b, undefined, { sensitivity: 'base' }));
assert(sortedNamesAsc[0].toLowerCase() === 'afsana' && sortedNamesAsc[1].toLowerCase() === 'ahmad' && sortedNamesAsc[3].toLowerCase() === 'zahid', 'Case-insensitive alphabetical sorting correctly orders names regardless of case');

// Status rank sorting (Active=1, Inactive=2, Blocked=3)
const statusRank: Record<string, number> = { Active: 1, Inactive: 2, Blocked: 3 };
const testStatuses = ['Blocked', 'Active', 'Inactive', 'Active'];
const sortedStatuses = [...testStatuses].sort((a, b) => (statusRank[a] || 99) - (statusRank[b] || 99));
assert(sortedStatuses[0] === 'Active' && sortedStatuses[1] === 'Active' && sortedStatuses[2] === 'Inactive' && sortedStatuses[3] === 'Blocked', 'Status sort orders Active (1) -> Inactive (2) -> Blocked (3)');

// Numerical balance sorting
const testBalances = [5000, 0, 12000, 250];
const sortedBalancesDesc = [...testBalances].sort((a, b) => b - a);
assert(sortedBalancesDesc[0] === 12000 && sortedBalancesDesc[1] === 5000 && sortedBalancesDesc[3] === 0, 'Numerical balance sort orders highest balances first in descending mode');

// -------------------------------------------------------------------------
// 13. Customer Actions & Delete Confirmation Dialog Specification
// -------------------------------------------------------------------------
console.log('\n--- 13. CUSTOMER ACTIONS & DELETE DIALOG SPECIFICATION ---');

interface ActionItem {
  id: string;
  label: string;
  icon: string;
  color: string;
  isPermissionRequired: boolean;
}

const desktopActions: ActionItem[] = [
  { id: 'view', label: 'View Customer', icon: 'Eye', color: 'blue', isPermissionRequired: false },
  { id: 'edit', label: 'Edit Customer', icon: 'Pencil', color: 'green', isPermissionRequired: true },
  { id: 'delete', label: 'Delete Customer', icon: 'Trash2', color: 'red', isPermissionRequired: true },
];

assert(desktopActions.length === 3, 'Desktop Actions column provides exactly three actions');
assert(desktopActions[0].color === 'blue' && desktopActions[0].icon === 'Eye', 'View Customer uses Eye icon with blue accent');
assert(desktopActions[1].color === 'green' && desktopActions[1].icon === 'Pencil', 'Edit Customer uses Pencil icon with green accent');
assert(desktopActions[2].color === 'red' && desktopActions[2].icon === 'Trash2', 'Delete Customer uses Trash2 icon with red accent');

// Delete confirmation simulation
let deleteModalState = { isOpen: false, customerId: '', isDeleted: false };
function openDeleteDialog(id: string) {
  deleteModalState = { isOpen: true, customerId: id, isDeleted: false };
}
function cancelDeleteDialog() {
  deleteModalState = { isOpen: false, customerId: '', isDeleted: false };
}
function confirmDeleteDialog() {
  if (deleteModalState.isOpen && deleteModalState.customerId) {
    deleteModalState.isDeleted = true;
    deleteModalState.isOpen = false;
  }
}

openDeleteDialog('cust-101');
assert(deleteModalState.isOpen === true && deleteModalState.isDeleted === false, 'Opening delete confirmation dialog does not delete customer record');
cancelDeleteDialog();
assert(deleteModalState.isOpen === false && deleteModalState.isDeleted === false, 'Canceling dialog leaves customer completely untouched');
openDeleteDialog('cust-101');
confirmDeleteDialog();
assert(deleteModalState.isDeleted === true && deleteModalState.isOpen === false, 'Explicit confirmation invokes deletion and closes dialog safely');

// -------------------------------------------------------------------------
// 14. Header Buttons & Collapsible Filter UI Specification
// -------------------------------------------------------------------------
console.log('--- 14. HEADER BUTTONS & COLLAPSIBLE FILTER UI SPECIFICATION ---');

// Test 14.1: Default state of collapsible filter is collapsed (false)
let filterSectionState = {
  isFilterOpen: false,
  searchTerm: '',
  statusFilter: 'all',
  typeFilter: 'all',
  financialFilter: 'all',
  sortColumn: 'created_at',
  sortDirection: 'desc',
};
assert(filterSectionState.isFilterOpen === false, 'Filter section is collapsed by default on page load');

// Test 14.2: Toggling filter section state
function toggleFilter() {
  filterSectionState.isFilterOpen = !filterSectionState.isFilterOpen;
}
toggleFilter();
assert(filterSectionState.isFilterOpen === true, 'Clicking Filter button toggles section to expanded state');
toggleFilter();
assert(filterSectionState.isFilterOpen === false, 'Clicking Filter button again toggles section back to collapsed state');

// Test 14.3: Collapsing filter preserves applied filters and search terms
filterSectionState.searchTerm = '0731339014';
filterSectionState.statusFilter = 'Active';
filterSectionState.financialFilter = 'Outstanding';
assert(
  filterSectionState.isFilterOpen === false &&
  filterSectionState.searchTerm === '0731339014' &&
  filterSectionState.statusFilter === 'Active' &&
  filterSectionState.financialFilter === 'Outstanding',
  'Collapsing filter section does not erase or reset applied filters or search terms'
);

// Test 14.4: Active filter count calculation
function computeActiveFilterCount(state: typeof filterSectionState) {
  let count = 0;
  if (state.searchTerm.trim()) count++;
  if (state.statusFilter !== 'all') count++;
  if (state.typeFilter !== 'all') count++;
  if (state.financialFilter !== 'all') count++;
  if (state.sortColumn !== 'created_at' || state.sortDirection !== 'desc') count++;
  return count;
}
assert(computeActiveFilterCount(filterSectionState) === 3, 'Active filter count accurately counts active filters (search + status + financial = 3)');

// Reset filters
filterSectionState.searchTerm = '';
filterSectionState.statusFilter = 'all';
filterSectionState.financialFilter = 'all';
assert(computeActiveFilterCount(filterSectionState) === 0, 'Active filter count returns 0 when filters are at default');

// Test 14.5: Responsive Header Buttons layout and classes
interface HeaderButtonSpec {
  id: string;
  variant: 'primary-blue' | 'neutral-outline';
  icon: string;
  desktopText: string;
  hideTextOnMobile: boolean;
  minHeight: number;
}
const headerButtons: HeaderButtonSpec[] = [
  {
    id: 'btn-toggle-filters',
    variant: 'neutral-outline',
    icon: 'SlidersHorizontal',
    desktopText: 'Filter',
    hideTextOnMobile: true,
    minHeight: 40,
  },
  {
    id: 'btn-add-customer',
    variant: 'primary-blue',
    icon: 'UserPlus',
    desktopText: 'Add Customer',
    hideTextOnMobile: true,
    minHeight: 40,
  },
];

assert(headerButtons[1].variant === 'primary-blue', 'Add Customer button is styled as primary blue');
assert(headerButtons[1].icon === 'UserPlus', 'Add Customer button uses UserPlus icon');
assert(headerButtons[0].variant === 'neutral-outline', 'Filter button is styled as neutral secondary/outline');
assert(headerButtons[0].icon === 'SlidersHorizontal', 'Filter button uses SlidersHorizontal icon');
assert(headerButtons[0].hideTextOnMobile && headerButtons[1].hideTextOnMobile, 'Both buttons hide text on mobile screens and display icon-only');
assert(headerButtons[0].minHeight === headerButtons[1].minHeight, 'Both buttons share identical 40px height for consistent touch targets');

// Test 14.6: Layout ordering - Collapsible filter is positioned BEFORE KPI cards
import fs from 'fs';
import path from 'path';

const customersViewCode = fs.readFileSync(path.resolve(process.cwd(), 'src/views/CustomersView.tsx'), 'utf-8');
const filterContainerIndex = customersViewCode.indexOf('id="customer-filter-collapse-container"');
const kpiCardsIndex = customersViewCode.indexOf('id="customer-kpi-cards-section"');

assert(filterContainerIndex !== -1, 'Collapsible filter container exists in CustomersView');
assert(kpiCardsIndex !== -1, 'Customer KPI cards section exists in CustomersView');
assert(
  filterContainerIndex < kpiCardsIndex,
  'Collapsible filter section is positioned BEFORE the KPI cards section in the layout hierarchy'
);

// Test 14.7: Animation in collapsing/expanding time
assert(
  customersViewCode.includes('transition-all duration-300 ease-in-out') ||
  customersViewCode.includes('duration-300'),
  'Collapsible filter container includes animated transition classes for smooth collapsing and expanding'
);
assert(
  customersViewCode.includes('grid-rows-[1fr]') && customersViewCode.includes('grid-rows-[0fr]'),
  'Collapsible filter uses CSS grid rows transition for zero-lag hardware-accelerated height animation'
);

// --- 15. CUSTOMER DETAIL MODAL HEADER & SETTINGS ACTIONS SPECIFICATION ---
console.log('\n--- 15. CUSTOMER DETAIL MODAL HEADER & SETTINGS ACTIONS ---');
const customerModalCode = fs.readFileSync(path.resolve(process.cwd(), 'src/components/customer/CustomerDetailModal.tsx'), 'utf-8');

// Test 15.1: Settings icon button exists with appropriate accessibility
assert(
  customerModalCode.includes('id="btn-customer-settings"'),
  'Settings button exists with id="btn-customer-settings"'
);
assert(
  customerModalCode.includes('<Settings') && customerModalCode.includes("from 'lucide-react'"),
  'Settings button renders the Settings icon from lucide-react'
);
assert(
  customerModalCode.includes('aria-label="Settings and customer actions"') &&
  customerModalCode.includes('aria-haspopup="menu"'),
  'Settings button includes accessible name and popup menu indicators'
);

// Test 15.2: Settings menu items in order (Edit, New Invoice, Add Payment)
const editIndex = customerModalCode.indexOf('id="btn-menu-edit-customer"');
const newInvoiceIndex = customerModalCode.indexOf('id="btn-menu-new-invoice"');
const addPaymentIndex = customerModalCode.indexOf('id="btn-menu-add-payment"');

assert(editIndex !== -1, 'Edit action exists in settings menu');
assert(newInvoiceIndex !== -1, 'New Invoice action exists in settings menu');
assert(addPaymentIndex !== -1, 'Add Payment action exists in settings menu');
assert(
  editIndex < newInvoiceIndex && newInvoiceIndex < addPaymentIndex,
  'Settings menu presents actions in requested order: 1. Edit, 2. New Invoice, 3. Add Payment'
);

// Test 15.3: Outside click and escape dismissal handling
assert(
  customerModalCode.includes("event.key === 'Escape'") &&
  customerModalCode.includes("contains(event.target as Node)"),
  'Settings menu supports outside click dismissal and Escape key closing'
);

// Test 15.4: Customer header layout reorganization
assert(
  customerModalCode.includes('id="customer-detail-title"'),
  'Customer name element exists in main header row'
);
assert(
  customerModalCode.includes('customer.companyName') && customerModalCode.includes('customer.phone'),
  'Company name and phone number are arranged on secondary line under customer name'
);

// Test 15.5: Customer status indicator/badge beside customer name
assert(
  customerModalCode.includes('id="customer-status-indicator"') &&
  customerModalCode.includes('id="customer-status-badge"'),
  'Customer status indicator badge exists beside customer name'
);
assert(
  customerModalCode.includes("customerStatus === 'Active'") &&
  customerModalCode.includes('bg-emerald-500') &&
  customerModalCode.includes("customerStatus === 'Inactive'"),
  'Active, Inactive, and Blocked status styles preserved on status badge'
);
assert(
  customerModalCode.includes('role="status"') &&
  customerModalCode.includes('aria-label={`Status: ${customerStatus}`}'),
  'Status indicator includes accessible role="status" and aria-label'
);

// Test 15.6: Mobile layout refinement & contact info row below fixed header
assert(
  customerModalCode.includes('id="customer-mobile-contact-row"') &&
  customerModalCode.includes('sm:hidden'),
  'Mobile contact information row exists immediately below fixed header (sm:hidden)'
);
assert(
  customerModalCode.includes('id="btn-whatsapp-mobile"') &&
  customerModalCode.includes('https://wa.me/'),
  'Mobile contact row includes WhatsApp button linked to customer phone'
);
assert(
  customerModalCode.includes('max-h-[92vh]') &&
  customerModalCode.includes('max-h-[92dvh]'),
  'Modal container enforces compact viewport height limit with dvh and vh fallback'
);

// --- 16. CUSTOMER DETAIL MODAL FOUR TABS SCROLLING & STICKY POSITIONING ---
console.log('\n--- 16. CUSTOMER DETAIL MODAL FOUR TABS SCROLLING & STICKY POSITIONING ---');

// Test 16.1: Unified scroll container structure
assert(
  customerModalCode.includes('id="customer-modal-scroll-container"') &&
  customerModalCode.includes('scrollContainerRef'),
  'Unified scroll container with ref and id exists in CustomerDetailModal'
);

// Test 16.2: Sticky tabs navigation beneath fixed header
assert(
  customerModalCode.includes('sticky top-0 z-20 bg-white') &&
  customerModalCode.includes('border-b border-neutral-200'),
  'Four tabs navigation has sticky top-0 z-20 positioning to pin beneath fixed header when scrolling'
);

// Test 16.3: Tab body consistent min-height for all four tabs
assert(
  customerModalCode.includes('id="customer-modal-tab-body"') &&
  customerModalCode.includes('min-h-full sm:min-h-0'),
  'Tab body container enforces min-h-full on mobile so all 4 tabs have consistent scrollable area'
);

// Test 16.4: All four tab wrappers have unique keys and layout constraints
assert(
  customerModalCode.includes('key="tab-overview"') &&
  customerModalCode.includes('key="tab-invoices"') &&
  customerModalCode.includes('key="tab-payments"') &&
  customerModalCode.includes('key="tab-activity"'),
  'All four tabs have consistent component keys to guarantee clean re-mounting without stuck layout state'
);

// Test 16.5: Auto-reset scroll position when switching tabs
assert(
  customerModalCode.includes('scrollContainerRef.current.scrollTop = 0') &&
  customerModalCode.includes('[activeTab]'),
  'Auto-resets scroll container scrollTop to 0 on tab change for clean top-to-bottom scrolling'
);

console.log('\n======================================================');
console.log(`TEST SUMMARY: ${passedTests} / ${totalTests} TESTS PASSED`);
console.log('======================================================\n');

if (passedTests === totalTests) {
  process.exit(0);
} else {
  process.exit(1);
}
