import { strict as assert } from 'assert';
import fs from 'fs';
import path from 'path';
import { Invoice, Payment } from '../types';
import {
  calculateMonthlyRevenueTrends,
  extractYearMonth,
  generateContiguousMonthKeys,
  formatMonthLabels,
  MonthlyRevenueTrendChart,
} from '../views/DashboardView';

export interface TestResult {
  name: string;
  passed: boolean;
  expected?: any;
  actual?: any;
  error?: string;
}

export function runMonthlyRevenueTrendsChartTests(): {
  total: number;
  passed: number;
  failed: number;
  results: TestResult[];
} {
  const results: TestResult[] = [];

  function test(name: string, fn: () => void) {
    try {
      fn();
      results.push({ name, passed: true });
    } catch (err: any) {
      results.push({
        name,
        passed: false,
        error: err?.message || String(err),
      });
    }
  }

  // Reference date: March 15, 2026
  const refDate = new Date(2026, 2, 15); // March 2026

  // --- Suite 1: Date Normalization & Key Extraction ---
  test('extractYearMonth extracts YYYY-MM from YYYY-MM-DD date strings', () => {
    assert.equal(extractYearMonth('2026-03-15'), '2026-03');
    assert.equal(extractYearMonth('2025-11-01'), '2025-11');
  });

  test('extractYearMonth extracts YYYY-MM from ISO date strings', () => {
    assert.equal(extractYearMonth('2026-02-10T14:30:00.000Z'), '2026-02');
  });

  test('extractYearMonth returns null for invalid or empty date inputs', () => {
    assert.equal(extractYearMonth(''), null);
    assert.equal(extractYearMonth(undefined), null);
    assert.equal(extractYearMonth(null), null);
    assert.equal(extractYearMonth('invalid-date'), null);
  });

  test('generateContiguousMonthKeys creates strictly sequential monthly keys ending at current month', () => {
    const keys6 = generateContiguousMonthKeys(6, refDate);
    assert.equal(keys6.length, 6);
    assert.deepEqual(keys6, [
      '2025-10',
      '2025-11',
      '2025-12',
      '2026-01',
      '2026-02',
      '2026-03',
    ]);

    const keys12 = generateContiguousMonthKeys(12, refDate);
    assert.equal(keys12.length, 12);
    assert.equal(keys12[keys12.length - 1], '2026-03');
    assert.equal(keys12[0], '2025-04');
  });

  test('formatMonthLabels returns correct short and full month labels', () => {
    const labels = formatMonthLabels('2026-03');
    assert.equal(labels.label, 'Mar 2026');
    assert.equal(labels.shortLabel, 'Mar');
    assert.equal(labels.fullLabel, 'March 2026');
  });

  // --- Suite 2: Data Aggregation & Business Logic ---
  test('calculateMonthlyRevenueTrends with empty arrays returns contiguous zeroed points', () => {
    const summary = calculateMonthlyRevenueTrends([], [], '6M', refDate);
    assert.equal(summary.dataPoints.length, 6);
    assert.equal(summary.totalInvoiced, 0);
    assert.equal(summary.totalCollected, 0);
    assert.equal(summary.overallCollectionRate, 0);
    assert.equal(summary.netVariance, 0);
    assert.equal(summary.activeMonthsCount, 0);
  });

  const createInvoice = (data: Partial<Invoice>): Invoice =>
    ({
      id: 'inv-def',
      billNumber: 'ST-000',
      customerId: 'cust-def',
      date: '2026-03-01',
      totalAmount: 0,
      status: 'Unpaid',
      items: [],
      customerSnapshot: { name: 'Test' } as any,
      companySnapshot: {} as any,
      createdAt: '2026-03-01T00:00:00Z',
      updatedAt: '2026-03-01T00:00:00Z',
      ...data,
    } as Invoice);

  const createPayment = (data: Partial<Payment>): Payment =>
    ({
      id: 'pay-def',
      invoiceId: 'inv-def',
      billNumber: 'ST-000',
      customerId: 'cust-def',
      customerName: 'Test',
      amount: 0,
      date: '2026-03-01',
      method: 'Cash',
      createdAt: '2026-03-01T00:00:00Z',
      isVoid: false,
      ...data,
    } as Payment);

  test('calculateMonthlyRevenueTrends correctly aggregates valid invoices by month', () => {
    const mockInvoices: Invoice[] = [
      createInvoice({
        id: 'inv-1',
        billNumber: 'ST-1001',
        customerId: 'cust-1',
        date: '2026-03-05',
        totalAmount: 12000,
        status: 'Unpaid',
      }),
      createInvoice({
        id: 'inv-2',
        billNumber: 'ST-1002',
        customerId: 'cust-1',
        date: '2026-03-20',
        totalAmount: 8000,
        status: 'Unpaid',
      }),
      createInvoice({
        id: 'inv-3',
        billNumber: 'ST-1003',
        customerId: 'cust-2',
        date: '2026-02-14',
        totalAmount: 15000,
        status: 'Paid',
      }),
    ];

    const summary = calculateMonthlyRevenueTrends(mockInvoices, [], '6M', refDate);
    const marPoint = summary.dataPoints.find((p) => p.month === '2026-03');
    const febPoint = summary.dataPoints.find((p) => p.month === '2026-02');

    assert(marPoint, 'March 2026 point must exist');
    assert.equal(marPoint.invoiced, 20000);
    assert.equal(marPoint.invoicesCount, 2);

    assert(febPoint, 'February 2026 point must exist');
    assert.equal(febPoint.invoiced, 15000);
    assert.equal(febPoint.invoicesCount, 1);

    assert.equal(summary.totalInvoiced, 35000);
  });

  test('calculateMonthlyRevenueTrends strictly excludes void invoices and draft quotations', () => {
    const mockInvoices: Invoice[] = [
      createInvoice({
        id: 'inv-valid',
        billNumber: 'ST-1001',
        date: '2026-03-10',
        totalAmount: 10000,
        status: 'Unpaid',
      }),
      createInvoice({
        id: 'inv-void-1',
        billNumber: 'ST-1002',
        date: '2026-03-12',
        totalAmount: 50000,
        status: 'Void', // Excluded
        isVoid: true,
      }),
      createInvoice({
        id: 'inv-void-2',
        billNumber: 'ST-1003',
        date: '2026-03-14',
        totalAmount: 30000,
        status: 'Unpaid',
        isVoid: true, // Excluded
      }),
      createInvoice({
        id: 'inv-quote',
        billNumber: 'ST-1004',
        date: '2026-03-15',
        totalAmount: 40000,
        status: 'Unpaid',
        billingState: 'quotation', // Excluded
      }),
    ];

    const summary = calculateMonthlyRevenueTrends(mockInvoices, [], '6M', refDate);
    const marPoint = summary.dataPoints.find((p) => p.month === '2026-03');
    assert.equal(marPoint?.invoiced, 10000);
    assert.equal(marPoint?.invoicesCount, 1);
    assert.equal(summary.totalInvoiced, 10000);
  });

  test('calculateMonthlyRevenueTrends aggregates valid payments and excludes void payments', () => {
    const mockPayments: Payment[] = [
      createPayment({
        id: 'pay-1',
        invoiceId: 'inv-1',
        amount: 8000,
        date: '2026-03-08',
        isVoid: false,
      }),
      createPayment({
        id: 'pay-2',
        invoiceId: 'inv-1',
        amount: 4000,
        date: '2026-03-18',
        isVoid: false,
      }),
      createPayment({
        id: 'pay-void',
        invoiceId: 'inv-2',
        amount: 100000,
        date: '2026-03-19',
        isVoid: true, // Excluded
      }),
      createPayment({
        id: 'pay-feb',
        invoiceId: 'inv-3',
        amount: 15000,
        date: '2026-02-20',
        isVoid: false,
      }),
    ];

    const summary = calculateMonthlyRevenueTrends([], mockPayments, '6M', refDate);
    const marPoint = summary.dataPoints.find((p) => p.month === '2026-03');
    const febPoint = summary.dataPoints.find((p) => p.month === '2026-02');

    assert.equal(marPoint?.collected, 12000);
    assert.equal(marPoint?.paymentsCount, 2);

    assert.equal(febPoint?.collected, 15000);
    assert.equal(febPoint?.paymentsCount, 1);

    assert.equal(summary.totalCollected, 27000);
  });

  test('calculateMonthlyRevenueTrends computes collection rate and net variance accurately', () => {
    const mockInvoices: Invoice[] = [
      createInvoice({
        id: 'i1',
        billNumber: 'ST-101',
        date: '2026-03-01',
        totalAmount: 20000,
        status: 'Unpaid',
      }),
    ];
    const mockPayments: Payment[] = [
      createPayment({
        id: 'p1',
        amount: 15000,
        date: '2026-03-10',
      }),
    ];

    const summary = calculateMonthlyRevenueTrends(mockInvoices, mockPayments, '6M', refDate);
    const marPoint = summary.dataPoints.find((p) => p.month === '2026-03')!;

    assert.equal(marPoint.invoiced, 20000);
    assert.equal(marPoint.collected, 15000);
    assert.equal(marPoint.collectionRate, 75); // 15000 / 20000 * 100
    assert.equal(marPoint.netVariance, -5000); // 15000 - 20000

    assert.equal(summary.overallCollectionRate, 75);
    assert.equal(summary.netVariance, -5000);
  });

  // --- Suite 3: DashboardView & Dashboard Integration Verification ---
  test('DashboardView.tsx exports MonthlyRevenueTrendChart and calculation helpers', () => {
    assert(typeof MonthlyRevenueTrendChart === 'function');
    assert(typeof calculateMonthlyRevenueTrends === 'function');
    assert(typeof extractYearMonth === 'function');
  });

  test('SuperAdminDashboard and InvoiceManagerDashboard integrate MonthlyRevenueTrendChart', () => {
    const superAdminSrc = fs.readFileSync(
      path.join(process.cwd(), 'src/components/dashboard/SuperAdminDashboard.tsx'),
      'utf8'
    );
    assert(
      superAdminSrc.includes('MonthlyRevenueTrendChart'),
      'SuperAdminDashboard must reference MonthlyRevenueTrendChart'
    );

    const invoiceManagerSrc = fs.readFileSync(
      path.join(process.cwd(), 'src/components/dashboard/InvoiceManagerDashboard.tsx'),
      'utf8'
    );
    assert(
      invoiceManagerSrc.includes('MonthlyRevenueTrendChart'),
      'InvoiceManagerDashboard must reference MonthlyRevenueTrendChart'
    );

    const dashboardViewSrc = fs.readFileSync(
      path.join(process.cwd(), 'src/views/DashboardView.tsx'),
      'utf8'
    );
    assert(
      dashboardViewSrc.includes('MonthlyRevenueTrendChart'),
      'DashboardView must reference MonthlyRevenueTrendChart'
    );
  });

  test('MonthlyRevenueTrendChart component source implements Recharts line chart elements', () => {
    const chartSrc = fs.readFileSync(
      path.join(process.cwd(), 'src/components/dashboard/MonthlyRevenueTrendChart.tsx'),
      'utf8'
    );
    assert(chartSrc.includes('ResponsiveContainer'), 'Must use ResponsiveContainer');
    assert(chartSrc.includes('LineChart'), 'Must use LineChart');
    assert(chartSrc.includes('Line'), 'Must use Line');
    assert(chartSrc.includes('XAxis'), 'Must use XAxis');
    assert(chartSrc.includes('YAxis'), 'Must use YAxis');
    assert(chartSrc.includes('Tooltip'), 'Must use Tooltip');
    assert(chartSrc.includes('Legend'), 'Must use Legend');
    assert(chartSrc.includes('CartesianGrid'), 'Must use CartesianGrid');
  });

  const passed = results.filter((r) => r.passed).length;
  const failed = results.filter((r) => !r.passed).length;

  return {
    total: results.length,
    passed,
    failed,
    results,
  };
}

// Standalone execution
if (import.meta.url === `file://${process.argv[1]}`) {
  console.log('===============================================================');
  console.log('     MONTHLY REVENUE TRENDS (RECHARTS) TEST SUITE RESULTS      ');
  console.log('===============================================================');

  const { total, passed, failed, results } = runMonthlyRevenueTrendsChartTests();

  for (const r of results) {
    if (r.passed) {
      console.log(`[PASS] ${r.name}`);
    } else {
      console.error(`[FAIL] ${r.name}: ${r.error}`);
    }
  }

  console.log('===============================================================');
  console.log(`TOTAL TESTS: ${total} | PASSED: ${passed} | FAILED: ${failed}`);
  if (failed === 0) {
    console.log('STATUS: ALL REVENUE TREND CHART TESTS PASSED! ✓');
  } else {
    console.error('STATUS: SOME TESTS FAILED');
    process.exit(1);
  }
  console.log('===============================================================');
}
