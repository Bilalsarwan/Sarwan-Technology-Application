/**
 * Cryptographic Password Utilities for Sarwan Technology Billing System
 * Implements secure salt generation and SHA-256 password hashing via Web Crypto API.
 * Plaintext passwords are NEVER stored in Firestore or exposed in the client.
 */

export const DEFAULT_NEW_USER_PASSWORD = 'Sarwan@User2026!';

/**
 * Generates a cryptographically random hexadecimal salt.
 */
export function generateSalt(byteLength: number = 16): string {
  const buffer = new Uint8Array(byteLength);
  crypto.getRandomValues(buffer);
  return Array.from(buffer)
    .map((b) => b.toString(16).padStart(2, '0'))
    .join('');
}

/**
 * Computes SHA-256 hash of (password + ':' + salt) using native Web Crypto API.
 */
export async function hashPassword(password: string, salt: string): Promise<string> {
  const encoder = new TextEncoder();
  const data = encoder.encode(`${password.trim()}:${salt}`);
  const hashBuffer = await crypto.subtle.digest('SHA-256', data);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  return hashArray.map((b) => b.toString(16).padStart(2, '0')).join('');
}

/**
 * Verifies if an entered password matches the stored password hash with salt.
 */
export async function verifyPassword(
  enteredPassword: string,
  storedSalt: string,
  storedHash: string
): Promise<boolean> {
  if (!enteredPassword || !storedSalt || !storedHash) return false;
  const computedHash = await hashPassword(enteredPassword, storedSalt);
  return computedHash === storedHash;
}
