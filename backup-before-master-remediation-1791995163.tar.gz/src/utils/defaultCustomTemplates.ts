import { DEFAULT_INVOICE_DESIGN, InvoiceDesignSettings } from '../types/invoiceDesign';
import { CustomInvoiceTemplate } from '../types';

export const DEFAULT_CUSTOM_TEMPLATES: CustomInvoiceTemplate[] = [
  {
    id: 'tpl_security_service',
    name: 'Security & CCTV Installation Service',
    category: 'Service',
    targetServiceOrClient: 'Security Camera & NVR Installations',
    description: 'Itemized breakdown for camera installations, cabling labor, network setup, and warranty sign-off.',
    isDefault: true,
    createdAt: '2026-01-01T00:00:00.000Z',
    updatedAt: '2026-01-01T00:00:00.000Z',
    design: {
      ...DEFAULT_INVOICE_DESIGN,
      presetName: 'sarwan_official',
      title: {
        ...DEFAULT_INVOICE_DESIGN.title,
        text: 'SERVICE INVOICE',
        secondaryText: 'د خدمتونو انویس / بیل',
      },
      colors: {
        ...DEFAULT_INVOICE_DESIGN.colors,
        primary: '#0B1E36',
        secondary: '#1E3A8A',
        accent: '#C5A059',
        headerBackground: '#0B1E36',
        tableHeaderBackground: '#1E3A8A',
        footerBackground: '#0B1E36',
        footerAccent: '#C5A059',
      },
    },
  },
  {
    id: 'tpl_corporate_vip',
    name: 'Corporate & Enterprise Contract',
    category: 'Corporate',
    targetServiceOrClient: 'Offices, Banks & Enterprise Clients',
    description: 'Formal corporate layout with Pashto company branding, tax breakdown, terms of service, and dual managerial signatures.',
    isDefault: false,
    createdAt: '2026-01-01T00:00:00.000Z',
    updatedAt: '2026-01-01T00:00:00.000Z',
    design: {
      ...DEFAULT_INVOICE_DESIGN,
      presetName: 'modern_corporate',
      title: {
        ...DEFAULT_INVOICE_DESIGN.title,
        text: 'TAX & SERVICE INVOICE',
        secondaryText: 'د مالیاتي او خدمتونو انویس',
      },
      colors: {
        ...DEFAULT_INVOICE_DESIGN.colors,
        primary: '#0F172A',
        secondary: '#1E3A8A',
        accent: '#D97706',
        headerBackground: '#0F172A',
        tableHeaderBackground: '#0F172A',
        footerBackground: '#0F172A',
        footerAccent: '#D97706',
      },
      typography: {
        ...DEFAULT_INVOICE_DESIGN.typography,
        headingFontFamily: 'serif',
      },
      totals: {
        ...DEFAULT_INVOICE_DESIGN.totals,
        showTax: true,
        showGrandTotal: true,
      },
      signatures: {
        ...DEFAULT_INVOICE_DESIGN.signatures,
        showCustomerSignature: true,
        showManagerSignature: true,
      },
    },
  },
  {
    id: 'tpl_hardware_sales',
    name: 'Hardware & Equipment Sales',
    category: 'Retail / Wholesale',
    targetServiceOrClient: 'Walk-in Customers & Wholesale Equipment Buyers',
    description: 'Optimized for point-of-sale hardware supply (cameras, cables, power supplies, hard drives). Emphasizes quantities, unit rates, cash receipt, and quick balance.',
    isDefault: false,
    createdAt: '2026-01-01T00:00:00.000Z',
    updatedAt: '2026-01-01T00:00:00.000Z',
    design: {
      ...DEFAULT_INVOICE_DESIGN,
      presetName: 'compact_tech',
      title: {
        ...DEFAULT_INVOICE_DESIGN.title,
        text: 'CASH SALES INVOICE',
        secondaryText: 'د نغدي پلورلو انویس',
      },
      colors: {
        ...DEFAULT_INVOICE_DESIGN.colors,
        primary: '#064E3B',
        secondary: '#047857',
        accent: '#10B981',
        headerBackground: '#064E3B',
        tableHeaderBackground: '#047857',
        footerBackground: '#064E3B',
        footerAccent: '#10B981',
      },
      spacing: {
        ...DEFAULT_INVOICE_DESIGN.spacing,
        rowHeight: 20,
        tablePadding: 5,
      },
    },
  },
  {
    id: 'tpl_maintenance_amc',
    name: 'Maintenance & AMC Support',
    category: 'Maintenance',
    targetServiceOrClient: 'Annual Maintenance Contracts & Periodic Support',
    description: 'Tailored for ongoing maintenance agreements, scheduled technical inspections, periodic service dues, and dedicated collector assignment.',
    isDefault: false,
    createdAt: '2026-01-01T00:00:00.000Z',
    updatedAt: '2026-01-01T00:00:00.000Z',
    design: {
      ...DEFAULT_INVOICE_DESIGN,
      presetName: 'classic_formal',
      title: {
        ...DEFAULT_INVOICE_DESIGN.title,
        text: 'MAINTENANCE & SUPPORT BILL',
        secondaryText: 'د تخنیکي ملاتړ او ساتنې بیل',
      },
      colors: {
        ...DEFAULT_INVOICE_DESIGN.colors,
        primary: '#1E293B',
        secondary: '#334155',
        accent: '#0EA5E9',
        headerBackground: '#1E293B',
        tableHeaderBackground: '#334155',
        footerBackground: '#1E293B',
        footerAccent: '#0EA5E9',
      },
      date: {
        ...DEFAULT_INVOICE_DESIGN.date,
        showDueDate: true,
      },
    },
  },
  {
    id: 'tpl_minimal_clean',
    name: 'Minimalist Modern Invoice',
    category: 'General',
    targetServiceOrClient: 'Consulting & General Technology Solutions',
    description: 'Clean, modern layout without corner flap decorations, featuring sleek borders and streamlined customer cards.',
    isDefault: false,
    createdAt: '2026-01-01T00:00:00.000Z',
    updatedAt: '2026-01-01T00:00:00.000Z',
    design: {
      ...DEFAULT_INVOICE_DESIGN,
      presetName: 'minimal_clean',
      title: {
        ...DEFAULT_INVOICE_DESIGN.title,
        text: 'INVOICE',
        secondaryText: 'د پلورنې بیل',
      },
      page: {
        ...DEFAULT_INVOICE_DESIGN.page,
        showCornerDecorations: false,
        showPageBorder: true,
      },
      colors: {
        ...DEFAULT_INVOICE_DESIGN.colors,
        primary: '#27272A',
        secondary: '#3F3F46',
        accent: '#71717A',
        headerBackground: '#27272A',
        tableHeaderBackground: '#3F3F46',
        footerBackground: '#27272A',
        footerAccent: '#71717A',
      },
    },
  },
];

export function resolveTemplates(customTemplates?: CustomInvoiceTemplate[]): CustomInvoiceTemplate[] {
  if (customTemplates && Array.isArray(customTemplates) && customTemplates.length > 0) {
    return customTemplates;
  }
  return DEFAULT_CUSTOM_TEMPLATES;
}
