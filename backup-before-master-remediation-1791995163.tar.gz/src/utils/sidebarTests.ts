/**
 * Focused verification tests for Sidebar navigation and layout behavior.
 */
import { readFileSync } from 'fs';
import { resolve } from 'path';

interface TestResult {
  suite: string;
  name: string;
  passed: boolean;
  error?: string;
}

const results: TestResult[] = [];

function test(suite: string, name: string, fn: () => void) {
  try {
    fn();
    results.push({ suite, name, passed: true });
  } catch (err: any) {
    results.push({ suite, name, passed: false, error: err?.message || String(err) });
  }
}

function expect(condition: boolean, msg: string) {
  if (!condition) throw new Error(msg);
}

export function runAllSidebarTests(): { total: number; passed: number; failed: number } {
  const sidebarPath = resolve(process.cwd(), 'src/components/layout/Sidebar.tsx');
  const sidebarContent = readFileSync(sidebarPath, 'utf8');

  const cssPath = resolve(process.cwd(), 'src/index.css');
  const cssContent = readFileSync(cssPath, 'utf8');

  const appPath = resolve(process.cwd(), 'src/App.tsx');
  const appContent = readFileSync(appPath, 'utf8');

  // Suite 1: Duplicate Invoice Button Removal
  test('Duplicate Invoice Button Removal', 'Standalone "New Invoice" quick action button is removed from Sidebar', () => {
    expect(
      !sidebarContent.includes('New Invoice') || !sidebarContent.includes('Quick Action Button: New Invoice'),
      'Sidebar still contains the duplicate standalone "New Invoice" button!'
    );
    expect(
      !sidebarContent.includes('PlusCircle'),
      'PlusCircle icon for duplicate button should be removed'
    );
  });

  test('Duplicate Invoice Button Removal', 'Authoritative Invoices navigation menu remains present and functional', () => {
    expect(
      sidebarContent.includes("id: 'invoices', label: 'Invoices', href: '/invoices'"),
      'Invoices navigation menu item was altered or removed!'
    );
  });

  // Suite 2: Desktop Sidebar Collapse / Expand
  test('Desktop Sidebar Collapse/Expand', 'Collapse / Expand button exists and is accessible in both states', () => {
    expect(
      sidebarContent.includes('sidebar-collapse-toggle-btn'),
      'Missing sidebar-collapse-toggle-btn button'
    );
    expect(
      sidebarContent.includes('ChevronLeft') && sidebarContent.includes('ChevronRight'),
      'Missing ChevronLeft or ChevronRight icon for collapse/expand toggle'
    );
    expect(
      sidebarContent.includes("title={isCollapsed ? 'Expand Sidebar' : 'Collapse Sidebar'}"),
      'Missing accessible tooltip/title for both collapsed and expanded states'
    );
  });

  test('Desktop Sidebar Collapse/Expand', 'Sidebar reduces to compact width (lg:w-20) when collapsed', () => {
    expect(
      sidebarContent.includes("isCollapsed ? 'lg:w-20' : 'lg:w-64'"),
      'Sidebar width does not toggle between lg:w-20 and lg:w-64'
    );
    expect(
      sidebarContent.includes('transition-all duration-300'),
      'Missing smooth transition classes on sidebar'
    );
  });

  test('Desktop Sidebar Collapse/Expand', 'Hides menu labels when collapsed but keeps icons visible', () => {
    expect(
      sidebarContent.includes('{!isCollapsed && <span className="truncate">{item.label}</span>}'),
      'Menu labels are not hidden when sidebar is collapsed'
    );
    expect(
      sidebarContent.includes('{item.icon}'),
      'Menu icons must remain visible'
    );
  });

  test('Desktop Sidebar Collapse/Expand', 'Main content area adjusts padding to match collapsed sidebar', () => {
    expect(
      appContent.includes("isSidebarCollapsed ? 'lg:pl-20' : 'lg:pl-64'"),
      'App.tsx does not dynamically adjust main content left padding'
    );
  });

  // Suite 3: Sidebar Scrolling & Hidden Scrollbar
  test('Sidebar Scrolling & Hidden Scrollbar', 'Sidebar container retains independent overflow-y-auto scrolling', () => {
    expect(
      sidebarContent.includes('overflow-y-auto flex-1'),
      'Sidebar container does not have overflow-y-auto'
    );
  });

  test('Sidebar Scrolling & Hidden Scrollbar', 'Scrollbar is visually hidden cross-browser while preserving scroll functionality', () => {
    expect(
      sidebarContent.includes('no-scrollbar'),
      'Sidebar container does not use no-scrollbar class'
    );
    expect(
      cssContent.includes('.no-scrollbar') &&
      cssContent.includes('scrollbar-width: none') &&
      cssContent.includes('::-webkit-scrollbar'),
      'index.css is missing complete cross-browser .no-scrollbar rules'
    );
  });

  // Suite 4: Responsive Behavior
  test('Responsive Behavior', 'Mobile sidebar backdrop and overlay classes are intact', () => {
    expect(
      sidebarContent.includes('isOpenOnMobile && (') &&
      sidebarContent.includes('fixed inset-0 z-40 bg-black/50 lg:hidden'),
      'Mobile backdrop is missing or modified'
    );
    expect(
      sidebarContent.includes("isOpenOnMobile ? 'translate-x-0 w-64' : '-translate-x-full'"),
      'Mobile translation and width classes are missing or modified'
    );
  });

  const suites = Array.from(new Set(results.map((r) => r.suite)));
  console.log('===============================================================');
  console.log('            SIDEBAR BEHAVIOR VERIFICATION RESULTS              ');
  console.log('===============================================================');

  let totalPassed = 0;
  let totalFailed = 0;

  for (const s of suites) {
    const suiteResults = results.filter((r) => r.suite === s);
    const suitePassed = suiteResults.filter((r) => r.passed).length;
    const suiteTotal = suiteResults.length;
    const allPassed = suitePassed === suiteTotal;

    console.log(`[${allPassed ? '✓ PASS' : '✗ FAIL'}] ${s} (${suitePassed}/${suiteTotal} passed)`);
    for (const r of suiteResults) {
      if (r.passed) {
        console.log(`  ✓ ${r.name}`);
        totalPassed++;
      } else {
        console.log(`  ✗ ${r.name}: ${r.error}`);
        totalFailed++;
      }
    }
  }

  console.log('---------------------------------------------------------------');
  console.log(`TOTAL: ${totalPassed}/${results.length} Tests Passed`);
  console.log(`OVERALL STATUS: ${totalFailed === 0 ? 'ALL TESTS PASSED' : 'SOME TESTS FAILED'}`);
  console.log('===============================================================');

  return { total: results.length, passed: totalPassed, failed: totalFailed };
}

if (import.meta.url === `file://${process.argv[1]}`) {
  const summary = runAllSidebarTests();
  process.exit(summary.failed === 0 ? 0 : 1);
}
