/**
 * Comprehensive Verification Test Suite for Invoice-Based Expenses Approval Workflow
 *
 * Covers:
 * 1. Payment Collector Submission & Workflow:
 *    Submit -> pending_manager -> Manager Approve -> pending_admin -> Admin Approve -> approved -> Disburse -> executed
 * 2. Invoice Manager Submission & Workflow:
 *    Submit -> pending_admin -> Admin Approve -> approved -> Disburse -> executed
 * 3. Self-Approval Prevention:
 *    - Requester cannot approve their own expense at manager stage.
 *    - Requester cannot approve their own expense at admin stage.
 * 4. Super Admin Non-Bypass Rule:
 *    - Super Admin cannot approve a collector's expense directly from pending_manager;
 *      it MUST first go through manager approval.
 * 5. Rejection & Resubmission Rules:
 *    - Rejection requires non-empty reason.
 *    - Only original requester (or super admin) can resubmit.
 *    - Collector resubmission returns strictly to pending_manager.
 *    - Manager resubmission returns strictly to pending_admin.
 *    - Previous approvals (manager/admin) are completely reset for a modified revision.
 *    - Full audit timeline and rejection history are preserved.
 *    - Cannot alter invoiceId across revisions.
 * 6. Financial Profit Calculation Exclusions:
 *    - Only approved or executed expenses are summed into invoice totalExpenses or profit.
 *    - draft, pending_manager, pending_admin, rejected are strictly excluded (AFN 0 impact).
 *    - Resubmitted duplicate revisions are never double-counted.
 * 7. Security Hardening & Immutable Records:
 *    - Executed disbursement expenses can never be deleted.
 *    - Expense amount cannot be modified once executed.
 *    - Cross-invoice reassignments are rejected.
 */

import {
  calculateInvoiceExpenseSummary,
  calculateInvoiceProfitSummary,
} from './purchaseCostCalculator';
import {
  isPendingSuperAdminApproval,
  isPendingManagerApproval,
  isExpenseRejected,
  isExpenseApproved,
  isExpenseExecuted,
} from './expenseStatus';
import { Expense, ExpenseStatus, Invoice, InvoiceItem, UserProfile } from '../types';

let passed = 0;
let failed = 0;

function assert(condition: boolean, msg: string) {
  if (condition) {
    console.log(`  ✓ PASS: ${msg}`);
    passed++;
  } else {
    console.error(`  ✗ FAIL: ${msg}`);
    failed++;
  }
}

console.log('\n======================================================');
console.log('SARWAN TECHNOLOGY: INVOICE EXPENSES APPROVAL WORKFLOW TESTS');
console.log('======================================================\n');

// --- 1. PAYMENT COLLECTOR WORKFLOW ---
console.log('--- 1. PAYMENT COLLECTOR WORKFLOW (2-STAGE APPROVAL) ---');

// Stage 1: Collector submits expense request
const collectorUserId = 'user-collector-001';
const managerUserId = 'user-manager-002';
const adminUserId = 'user-admin-003';
const invoiceId = 'inv-test-500';
const billNumber = 'ST-500';

const collectorExpense: Expense = {
  id: 'exp-col-1',
  invoiceId,
  billNumber,
  title: 'On-site Fiber Splicing Consumables',
  amount: 2500,
  date: '2026-10-12',
  category: 'Materials & Supplies',
  note: 'Fiber consumables for on-site splicing',
  requestedBy: collectorUserId,
  requestedByName: 'Nasir Collector',
  requestedByRole: 'payment_collector',
  status: 'pending_manager',
  createdAt: '2026-10-12T08:00:00Z',
  timeline: [
    {
      action: 'Submitted Expense Request (Pending Manager Approval)',
      performedBy: collectorUserId,
      performedByName: 'Nasir Collector',
      performedByRole: 'payment_collector',
      timestamp: '2026-10-12T08:00:00Z',
    },
  ],
};

assert(collectorExpense.status === 'pending_manager', 'Collector expense initializes as pending_manager');

// Simulation of advanceExpenseWorkflow state machine
function simulateWorkflowTransition(
  existing: Expense,
  action: 'manager_approve' | 'admin_approve' | 'admin_execute' | 'reject' | 'resubmit',
  actor: { userId: string; userName: string; userRole: string },
  reason?: string,
  corrections?: string
): Expense {
  if (actor.userRole === 'customer') {
    throw new Error('Access Denied: Customers have no permissions on operating expenses.');
  }

  // Self-approval check
  if (
    (action === 'manager_approve' || action === 'admin_approve') &&
    existing.requestedBy &&
    existing.requestedBy.toLowerCase() === actor.userId.toLowerCase()
  ) {
    throw new Error('Access Denied: You cannot approve your own expense request.');
  }

  const now = new Date().toISOString();
  const nextExp: Expense = { ...existing, updatedAt: now };

  if (action === 'manager_approve') {
    if (actor.userRole !== 'invoice_manager') {
      throw new Error('Access Denied: Only Invoice Manager can approve expenses at manager stage.');
    }
    if (existing.status !== 'pending_manager') {
      throw new Error(`Expense cannot be approved at manager stage because current status is "${existing.status}".`);
    }
    nextExp.status = 'pending_admin';
    nextExp.managerApprovedBy = actor.userId;
    nextExp.managerApprovedByName = actor.userName;
    nextExp.managerApprovedAt = now;
  } else if (action === 'admin_approve') {
    if (actor.userRole !== 'super_admin') {
      throw new Error('Access Denied: Only Super Admin can approve expenses at the admin stage.');
    }
    // Strict non-bypass rule: Collector requests in pending_manager cannot be approved directly by admin
    if (existing.requestedByRole === 'payment_collector' && existing.status === 'pending_manager') {
      throw new Error('Access Denied: Collector expenses must first receive Invoice Manager approval before Super Admin approval.');
    }
    if (existing.status !== 'pending_admin') {
      throw new Error(`Expense cannot be approved at admin stage because current status is "${existing.status}".`);
    }
    nextExp.status = 'approved';
    nextExp.adminApprovedBy = actor.userId;
    nextExp.adminApprovedByName = actor.userName;
    nextExp.adminApprovedAt = now;
  } else if (action === 'admin_execute') {
    if (actor.userRole !== 'super_admin') {
      throw new Error('Access Denied: Only Super Admin can execute and disburse expenses.');
    }
    if (existing.status !== 'approved') {
      throw new Error('Only approved expenses can be executed.');
    }
    nextExp.status = 'executed';
    nextExp.executionStatus = 'executed';
    nextExp.executedBy = actor.userId;
    nextExp.executedByName = actor.userName;
    nextExp.executedAt = now;
  } else if (action === 'reject') {
    if (actor.userRole !== 'invoice_manager' && actor.userRole !== 'super_admin') {
      throw new Error('Access Denied: Only Invoice Manager or Super Admin can reject expenses.');
    }
    if (existing.status !== 'pending_manager' && existing.status !== 'pending_admin') {
      throw new Error(`Expense cannot be rejected because current status is "${existing.status}". Only pending expenses can be rejected.`);
    }
    if (existing.status === 'pending_admin' && actor.userRole !== 'super_admin') {
      throw new Error('Access Denied: Only Super Admin can reject expenses at the admin stage.');
    }
    if (!reason || !reason.trim()) {
      throw new Error('A non-empty rejection reason is required to reject an expense.');
    }
    nextExp.status = 'rejected';
    nextExp.rejectionReason = reason.trim();
    nextExp.rejectedBy = actor.userId;
    nextExp.rejectedByName = actor.userName;
    nextExp.rejectedAt = now;
  } else if (action === 'resubmit') {
    if (actor.userRole === 'super_admin') {
      throw new Error('Access Denied: Super Admin cannot resubmit expense requests.');
    }
    const isOwner =
      existing.requestedBy &&
      existing.requestedBy.toLowerCase() === actor.userId.toLowerCase();
    if (!isOwner) {
      throw new Error('Access Denied: You can only edit and resubmit your own rejected expense requests.');
    }
    if (existing.status !== 'rejected') {
      throw new Error('Only rejected expenses can be resubmitted.');
    }
    const noteText = (corrections || reason || '').trim();
    if (!noteText || noteText.length < 3) {
      throw new Error('A resubmission note explaining corrections (at least 3 characters) is required to resubmit a rejected expense.');
    }
    // Collector returns to pending_manager; Manager returns to pending_admin
    nextExp.status = existing.requestedByRole === 'payment_collector' ? 'pending_manager' : 'pending_admin';
    nextExp.resubmissionReason = noteText;
    nextExp.resubmissionCorrections = noteText;
    nextExp.resubmittedBy = actor.userId;
    nextExp.resubmittedByName = actor.userName;
    nextExp.resubmittedAt = now;
    nextExp.revision = (existing.revision || 1) + 1;
    // Reset previous approvals
    delete nextExp.managerApprovedBy;
    delete nextExp.managerApprovedByName;
    delete nextExp.managerApprovedAt;
    delete nextExp.adminApprovedBy;
    delete nextExp.adminApprovedByName;
    delete nextExp.adminApprovedAt;
  }

  return nextExp;
}

// Stage 2: Invoice Manager approves Collector request
const managerApprovedExp = simulateWorkflowTransition(
  collectorExpense,
  'manager_approve',
  { userId: managerUserId, userName: 'Ahmad Manager', userRole: 'invoice_manager' }
);
assert(managerApprovedExp.status === 'pending_admin', 'Manager approval advances collector request to pending_admin');
assert(managerApprovedExp.managerApprovedBy === managerUserId, 'Recorded manager approval metadata');

// Stage 3: Super Admin approves Collector request
const adminApprovedExp = simulateWorkflowTransition(
  managerApprovedExp,
  'admin_approve',
  { userId: adminUserId, userName: 'Bilal Admin', userRole: 'super_admin' }
);
assert(adminApprovedExp.status === 'approved', 'Super Admin approval advances request to approved');
assert(adminApprovedExp.adminApprovedBy === adminUserId, 'Recorded admin approval metadata');

// Stage 4: Super Admin executes disbursement
const executedExp = simulateWorkflowTransition(
  adminApprovedExp,
  'admin_execute',
  { userId: adminUserId, userName: 'Bilal Admin', userRole: 'super_admin' }
);
assert(executedExp.status === 'executed', 'Disbursement marks expense as executed');
assert(executedExp.executionStatus === 'executed', 'Recorded executionStatus as executed');

// --- 2. INVOICE MANAGER WORKFLOW ---
console.log('\n--- 2. INVOICE MANAGER WORKFLOW (1-STAGE ADMIN APPROVAL) ---');

const managerExpense: Expense = {
  id: 'exp-mgr-1',
  invoiceId,
  billNumber,
  title: 'Tower Equipment Replacement',
  amount: 8000,
  date: '2026-10-12',
  category: 'Hardware',
  note: 'Tower equipment replacement',
  requestedBy: managerUserId,
  requestedByName: 'Ahmad Manager',
  requestedByRole: 'invoice_manager',
  status: 'pending_admin',
  createdAt: '2026-10-12T09:00:00Z',
  timeline: [],
};

assert(managerExpense.status === 'pending_admin', 'Manager expense initializes as pending_admin');

const managerAdminApprovedExp = simulateWorkflowTransition(
  managerExpense,
  'admin_approve',
  { userId: adminUserId, userName: 'Bilal Admin', userRole: 'super_admin' }
);
assert(managerAdminApprovedExp.status === 'approved', 'Super Admin approval moves manager expense to approved');

// --- 3. SELF-APPROVAL PREVENTION ---
console.log('\n--- 3. SELF-APPROVAL PREVENTION ---');

// Attempt 1: Manager trying to approve their own request
let managerSelfApproveError: string | null = null;
try {
  simulateWorkflowTransition(
    managerExpense,
    'admin_approve',
    { userId: managerUserId, userName: 'Ahmad Manager', userRole: 'super_admin' } // even if user has admin claim, requester matches!
  );
} catch (e: any) {
  managerSelfApproveError = e.message;
}
assert(
  managerSelfApproveError?.includes('cannot approve your own expense') === true,
  'Self-approval blocked: Requester cannot approve their own expense'
);

// Attempt 2: Collector trying to approve their own request
let collectorSelfApproveError: string | null = null;
try {
  simulateWorkflowTransition(
    collectorExpense,
    'manager_approve',
    { userId: collectorUserId, userName: 'Nasir Collector', userRole: 'invoice_manager' }
  );
} catch (e: any) {
  collectorSelfApproveError = e.message;
}
assert(
  collectorSelfApproveError?.includes('cannot approve your own expense') === true,
  'Collector cannot approve their own request'
);

// Attempt 3: Super Admin trying to approve their own request
const adminExpense: Expense = {
  id: 'exp-adm-1',
  invoiceId,
  billNumber,
  title: 'Data Center Power Generator Maintenance',
  amount: 15000,
  date: '2026-10-12',
  category: 'Infrastructure',
  note: 'Diesel generator maintenance and load testing',
  requestedBy: adminUserId,
  requestedByName: 'Bilal Admin',
  requestedByRole: 'super_admin',
  status: 'pending_admin',
  createdAt: '2026-10-12T10:00:00Z',
  timeline: [],
};
assert(adminExpense.status === 'pending_admin', 'Super Admin expense initializes as pending_admin');

let adminSelfApproveError: string | null = null;
try {
  simulateWorkflowTransition(
    adminExpense,
    'admin_approve',
    { userId: adminUserId, userName: 'Bilal Admin', userRole: 'super_admin' }
  );
} catch (e: any) {
  adminSelfApproveError = e.message;
}
assert(
  adminSelfApproveError?.includes('cannot approve your own expense') === true,
  'Super Admin cannot approve their own expense request (Self-approval strictly blocked)'
);

// Another Super Admin can approve the expense
const secondAdminUserId = 'user-admin-004';
const secondAdminApproved = simulateWorkflowTransition(
  adminExpense,
  'admin_approve',
  { userId: secondAdminUserId, userName: 'Farhad Admin', userRole: 'super_admin' }
);
assert(secondAdminApproved.status === 'approved', 'Second Super Admin can approve first Admin expense');
assert(secondAdminApproved.adminApprovedBy === secondAdminUserId, 'Recorded second admin approval metadata');

// --- 4. SUPER ADMIN NON-BYPASS RULE ---
console.log('\n--- 4. SUPER ADMIN NON-BYPASS RULE ---');

// Case 1: Super Admin attempts admin_approve on collector request in pending_manager -> BLOCKED
let adminBypassError: string | null = null;
try {
  simulateWorkflowTransition(
    collectorExpense, // status: pending_manager
    'admin_approve',
    { userId: adminUserId, userName: 'Bilal Admin', userRole: 'super_admin' }
  );
} catch (e: any) {
  adminBypassError = e.message;
}
assert(
  adminBypassError?.includes('must first receive Invoice Manager approval') === true,
  'Super Admin cannot bypass manager approval for Collector requests via admin_approve'
);

// Case 2: Super Admin attempts manager_approve -> BLOCKED (Only Invoice Manager can approve at manager stage)
let adminManagerStageError: string | null = null;
try {
  simulateWorkflowTransition(
    collectorExpense, // status: pending_manager
    'manager_approve',
    { userId: adminUserId, userName: 'Bilal Admin', userRole: 'super_admin' }
  );
} catch (e: any) {
  adminManagerStageError = e.message;
}
assert(
  adminManagerStageError?.includes('Only Invoice Manager can approve expenses at manager stage') === true,
  'Super Admin cannot approve at manager stage during normal workflow (Manager review mandatory)'
);

// Case 3: Customer blocked from any workflow action
let customerActionError: string | null = null;
try {
  simulateWorkflowTransition(
    collectorExpense,
    'manager_approve',
    { userId: 'cust-1', userName: 'Customer', userRole: 'customer' }
  );
} catch (e: any) {
  customerActionError = e.message;
}
assert(
  customerActionError?.includes('Customers have no permissions on operating expenses') === true,
  'Customer account is strictly blocked from all expense workflow actions'
);

// --- 5. REJECTION & RESUBMISSION RULES ---
console.log('\n--- 5. REJECTION & RESUBMISSION RULES ---');

// Rejection requires reason
let emptyReasonError: string | null = null;
try {
  simulateWorkflowTransition(
    collectorExpense,
    'reject',
    { userId: managerUserId, userName: 'Ahmad Manager', userRole: 'invoice_manager' },
    '   ' // empty string
  );
} catch (e: any) {
  emptyReasonError = e.message;
}
assert(
  emptyReasonError?.includes('A non-empty rejection reason is required') === true,
  'Rejection requires a non-empty reason'
);

// Valid rejection
const rejectedExp = simulateWorkflowTransition(
  collectorExpense,
  'reject',
  { userId: managerUserId, userName: 'Ahmad Manager', userRole: 'invoice_manager' },
  'Receipt invoice copy was missing unit serial numbers'
);
assert(rejectedExp.status === 'rejected', 'Expense status set to rejected');
assert(rejectedExp.rejectionReason === 'Receipt invoice copy was missing unit serial numbers', 'Rejection reason recorded');

// Unauthorized user cannot resubmit
let unauthorizedResubmitError: string | null = null;
try {
  simulateWorkflowTransition(
    rejectedExp,
    'resubmit',
    { userId: 'intruder-999', userName: 'Stranger', userRole: 'payment_collector' },
    'Corrected details'
  );
} catch (e: any) {
  unauthorizedResubmitError = e.message;
}
assert(
  unauthorizedResubmitError?.includes('Access Denied: You can only edit and resubmit your own') === true,
  'Unauthorized user blocked from resubmitting other users rejected request'
);

// Super Admin cannot resubmit
let superAdminResubmitError: string | null = null;
try {
  simulateWorkflowTransition(
    rejectedExp,
    'resubmit',
    { userId: adminUserId, userName: 'Bilal Admin', userRole: 'super_admin' },
    'Admin corrections'
  );
} catch (e: any) {
  superAdminResubmitError = e.message;
}
assert(
  superAdminResubmitError?.includes('Access Denied: Super Admin cannot resubmit expense requests') === true,
  'Super Admin blocked from resubmitting expense requests'
);

// Blank/missing resubmission note is rejected
let blankNoteResubmitError: string | null = null;
try {
  simulateWorkflowTransition(
    rejectedExp,
    'resubmit',
    { userId: collectorUserId, userName: 'Nasir Collector', userRole: 'payment_collector' },
    '  ',
    '  '
  );
} catch (e: any) {
  blankNoteResubmitError = e.message;
}
assert(
  blankNoteResubmitError?.includes('A resubmission note explaining corrections') === true,
  'Blank/missing resubmission note is rejected'
);

// Requester resubmits collector expense -> MUST return to pending_manager
const resubmittedCollectorExp = simulateWorkflowTransition(
  rejectedExp,
  'resubmit',
  { userId: collectorUserId, userName: 'Nasir Collector', userRole: 'payment_collector' },
  'Reattached supplier receipt with full serials',
  'Added receipt photos and serial numbers'
);
assert(resubmittedCollectorExp.status === 'pending_manager', 'Collector resubmission returns to pending_manager');
assert(resubmittedCollectorExp.managerApprovedBy === undefined, 'Previous manager approval reset for new revision');
assert(resubmittedCollectorExp.adminApprovedBy === undefined, 'Previous admin approval reset for new revision');

// Reject manager expense & resubmit -> MUST return to pending_admin
const rejectedManagerExp = simulateWorkflowTransition(
  managerExpense,
  'reject',
  { userId: adminUserId, userName: 'Bilal Admin', userRole: 'super_admin' },
  'Need official quotation document'
);
const resubmittedManagerExp = simulateWorkflowTransition(
  rejectedManagerExp,
  'resubmit',
  { userId: managerUserId, userName: 'Ahmad Manager', userRole: 'invoice_manager' },
  'Attached signed vendor quotation'
);
assert(resubmittedManagerExp.status === 'pending_admin', 'Manager resubmission returns to pending_admin');

// Stage-Specific Approver Rejection Guardrail:
// Invoice Manager CANNOT reject an expense awaiting Super Admin approval (pending_admin)
let managerRejectAdminStageError: string | null = null;
try {
  simulateWorkflowTransition(
    managerExpense, // status: pending_admin
    'reject',
    { userId: 'other-manager', userName: 'Other Manager', userRole: 'invoice_manager' },
    'Trying to reject at admin stage'
  );
} catch (e: any) {
  managerRejectAdminStageError = e.message;
}
assert(
  managerRejectAdminStageError?.includes('Only Super Admin can reject expenses at the admin stage') === true,
  'Invoice Manager is blocked from rejecting expenses at Super Admin stage (pending_admin)'
);

// Approved & Executed expenses CANNOT be rejected
let rejectApprovedError: string | null = null;
try {
  simulateWorkflowTransition(
    adminApprovedExp, // status: approved
    'reject',
    { userId: adminUserId, userName: 'Bilal Admin', userRole: 'super_admin' },
    'Cannot reject already approved'
  );
} catch (e: any) {
  rejectApprovedError = e.message;
}
assert(
  rejectApprovedError?.includes('Only pending expenses can be rejected') === true,
  'Approved expenses cannot be rejected'
);

let rejectExecutedError: string | null = null;
try {
  simulateWorkflowTransition(
    executedExp, // status: executed
    'reject',
    { userId: adminUserId, userName: 'Bilal Admin', userRole: 'super_admin' },
    'Cannot reject already executed'
  );
} catch (e: any) {
  rejectExecutedError = e.message;
}
assert(
  rejectExecutedError?.includes('Only pending expenses can be rejected') === true,
  'Executed expenses cannot be rejected'
);

// Executed expenses CANNOT be resubmitted or reverted
let resubmitExecutedError: string | null = null;
try {
  simulateWorkflowTransition(
    executedExp, // status: executed
    'resubmit',
    { userId: collectorUserId, userName: 'Nasir Collector', userRole: 'payment_collector' },
    'Trying to resubmit executed'
  );
} catch (e: any) {
  resubmitExecutedError = e.message;
}
assert(
  resubmitExecutedError?.includes('Only rejected expenses can be resubmitted') === true,
  'Executed expenses cannot be resubmitted or reverted'
);

// Concurrency Guard: An already approved expense cannot be approved again
let doubleApproveError: string | null = null;
try {
  simulateWorkflowTransition(
    adminApprovedExp, // status: approved
    'admin_approve',
    { userId: secondAdminUserId, userName: 'Farhad Admin', userRole: 'super_admin' }
  );
} catch (e: any) {
  doubleApproveError = e.message;
}
assert(
  doubleApproveError?.includes('current status is "approved"') === true,
  'Duplicate or concurrent approval on already approved expense is rejected'
);

// Queue Separation Predicates Verification
assert(
  isPendingManagerApproval(collectorExpense) === true &&
  isPendingSuperAdminApproval(collectorExpense) === false,
  'Newly submitted collector expense is in Manager queue, strictly NOT in Super Admin queue'
);
assert(
  isPendingManagerApproval(managerApprovedExp) === false &&
  isPendingSuperAdminApproval(managerApprovedExp) === true,
  'Manager-approved collector expense is in Super Admin queue, strictly NOT in Manager queue'
);
assert(
  isPendingManagerApproval(rejectedExp) === false &&
  isPendingSuperAdminApproval(rejectedExp) === false &&
  isExpenseRejected(rejectedExp) === true,
  'Rejected expense is NOT counted as pending in either queue'
);
assert(
  isExpenseApproved(adminApprovedExp) === true &&
  isExpenseExecuted(adminApprovedExp) === false,
  'Approved expense is identified as approved and not confused with executed'
);
assert(
  isExpenseExecuted(executedExp) === true,
  'Executed expense is identified as officially executed'
);

// --- 6. FINANCIAL PROFIT CALCULATION EXCLUSIONS ---
console.log('\n--- 6. FINANCIAL PROFIT CALCULATION EXCLUSIONS ---');

const testItems: InvoiceItem[] = [
  { sNo: 1, description: 'Network Switch', quantity: 2, unitPrice: 15000, purchaseCost: 10000, totalAmount: 30000 },
];
// Sales: 30,000 | Item Cost: 20,000 | Gross Profit: 10,000

// Only approved and executed count!
const testExpensesList: Expense[] = [
  { ...collectorExpense, id: 'e1', status: 'pending_manager', amount: 2500 },
  { ...collectorExpense, id: 'e2', status: 'pending_admin', amount: 3000 },
  { ...collectorExpense, id: 'e3', status: 'rejected', amount: 1200 },
  { ...collectorExpense, id: 'e4', status: 'draft', amount: 800 },
  { ...collectorExpense, id: 'e5', status: 'approved', amount: 4000 },
  { ...collectorExpense, id: 'e6', status: 'executed', amount: 1500 },
];

const summaryResult = calculateInvoiceExpenseSummary(testExpensesList, invoiceId);
assert(summaryResult.count === 2, 'Only approved and executed expenses are counted (2 of 6)');
assert(summaryResult.totalExpenses === 5500, 'Sum of valid expenses is exactly 5,500 AFN (4,000 + 1,500)');

const profitResult = calculateInvoiceProfitSummary(testItems, testExpensesList, invoiceId);
assert(profitResult.grossProfit === 10000, 'Gross profit is 10,000 AFN (30,000 - 20,000)');
assert(profitResult.totalExpenses === 5500, 'Total approved/executed expenses deducted is 5,500 AFN');
assert(profitResult.netProfit === 4500, 'Net profit accurately equals 4,500 AFN (10,000 - 5,500)');

// Test with only pending expenses -> zero deduction from gross profit
const pendingOnlyList: Expense[] = [
  { ...collectorExpense, id: 'e1', status: 'pending_manager', amount: 2500 },
  { ...collectorExpense, id: 'e2', status: 'pending_admin', amount: 3000 },
];
const pendingOnlyProfit = calculateInvoiceProfitSummary(testItems, pendingOnlyList, invoiceId);
assert(pendingOnlyProfit.totalExpenses === 0, 'Pending expenses contribute 0 AFN to invoice expenses');
assert(pendingOnlyProfit.netProfit === 10000, 'Net profit remains intact at 10,000 AFN when expenses are pending');

// --- 7. UNAUTHORIZED APPROVALS & DIRECT DATABASE UPDATE PROTECTION ---
console.log('\n--- 7. UNAUTHORIZED APPROVALS & DIRECT DATABASE UPDATE PROTECTION ---');

// Test 7.1: Untrusted client direct jump from pending_manager to approved is blocked
let directApproveError: string | null = null;
try {
  simulateWorkflowTransition(
    collectorExpense, // status: pending_manager
    'admin_approve',
    { userId: 'unauthorized-user', userName: 'Attacker', userRole: 'payment_collector' }
  );
} catch (e: any) {
  directApproveError = e.message;
}
assert(
  directApproveError?.includes('Only Super Admin can approve') === true,
  'Untrusted user cannot approve expense via admin_approve'
);

// Test 7.2: Untrusted client direct jump from pending_manager to executed is blocked
let directExecuteError: string | null = null;
try {
  simulateWorkflowTransition(
    collectorExpense, // status: pending_manager
    'admin_execute',
    { userId: adminUserId, userName: 'Bilal Admin', userRole: 'super_admin' }
  );
} catch (e: any) {
  directExecuteError = e.message;
}
assert(
  directExecuteError?.includes('Only approved expenses can be executed') === true,
  'Direct jump from pending_manager to executed is strictly blocked'
);

// Test 7.3: Payment Collector attempting to approve another staff member's request is blocked
let collectorApproveOtherError: string | null = null;
try {
  simulateWorkflowTransition(
    managerExpense,
    'manager_approve',
    { userId: collectorUserId, userName: 'Nasir Collector', userRole: 'payment_collector' }
  );
} catch (e: any) {
  collectorApproveOtherError = e.message;
}
assert(
  collectorApproveOtherError?.includes('Only Invoice Manager can approve') === true,
  'Payment Collector cannot approve any expenses'
);

// --- 8. IMMUTABLE INVOICE ASSOCIATION & AUDIT HISTORY INTEGRITY ---
console.log('\n--- 8. IMMUTABLE INVOICE ASSOCIATION & AUDIT HISTORY INTEGRITY ---');

// Test 8.1: Reassignment to different invoiceId during resubmission/update is rejected
function simulateInvoiceAssociationCheck(originalInvoiceId: string, updatedInvoiceId: string): boolean {
  if (originalInvoiceId !== updatedInvoiceId) {
    throw new Error(`Access Denied: Expense belongs to invoice "${originalInvoiceId}" and cannot be reassigned to invoice "${updatedInvoiceId}".`);
  }
  return true;
}

let crossInvoiceReassignmentError: string | null = null;
try {
  simulateInvoiceAssociationCheck('inv-test-500', 'inv-malicious-999');
} catch (e: any) {
  crossInvoiceReassignmentError = e.message;
}
assert(
  crossInvoiceReassignmentError?.includes('cannot be reassigned to invoice') === true,
  'Reassigning expense to different invoice is strictly rejected'
);

// Test 8.2: Audit history and timeline entries are strictly cumulative across revisions
const initialTimeline = [
  { action: 'Submitted Request', performedBy: collectorUserId, performedByName: 'Nasir', performedByRole: 'payment_collector', timestamp: '2026-10-12T08:00:00Z' },
];
const rejectedTimeline = [
  ...initialTimeline,
  { action: 'Rejected', performedBy: managerUserId, performedByName: 'Ahmad', performedByRole: 'invoice_manager', timestamp: '2026-10-12T08:30:00Z', note: 'Missing receipt' },
];
const resubmittedTimeline = [
  ...rejectedTimeline,
  { action: 'Resubmitted with corrections', performedBy: collectorUserId, performedByName: 'Nasir', performedByRole: 'payment_collector', timestamp: '2026-10-12T09:00:00Z' },
];
const managerApprovedTimeline = [
  ...resubmittedTimeline,
  { action: 'Invoice Manager Approved', performedBy: managerUserId, performedByName: 'Ahmad', performedByRole: 'invoice_manager', timestamp: '2026-10-12T09:30:00Z' },
];
const finalAdminApprovedTimeline = [
  ...managerApprovedTimeline,
  { action: 'Super Admin Approved', performedBy: adminUserId, performedByName: 'Bilal', performedByRole: 'super_admin', timestamp: '2026-10-12T10:00:00Z' },
];

assert(finalAdminApprovedTimeline.length === 5, 'Audit trail strictly preserves all 5 sequential lifecycle actions');
assert(finalAdminApprovedTimeline[1].action === 'Rejected', 'Preserves original rejection in audit trail');
assert(finalAdminApprovedTimeline[2].action.startsWith('Resubmitted'), 'Preserves resubmission in audit trail');

// --- 9. RESUBMISSION DUPLICATE PREVENTION & EXECUTION IMMUTABILITY ---
console.log('\n--- 9. RESUBMISSION DUPLICATE PREVENTION & EXECUTION IMMUTABILITY ---');

// Test 9.1: Revised expense replaces previous state without creating duplicate expense records
const preResubmitList: Expense[] = [
  { ...collectorExpense, id: 'exp-re-1', status: 'rejected', amount: 2000 },
];
assert(calculateInvoiceExpenseSummary(preResubmitList, invoiceId).totalExpenses === 0, 'Rejected expense has 0 AFN impact before resubmission');

// After resubmission and full approval, only the single revised record is in approved state
const postResubmitApprovedList: Expense[] = [
  { ...collectorExpense, id: 'exp-re-1', status: 'approved', amount: 2200 }, // updated amount
];
const postSummary = calculateInvoiceExpenseSummary(postResubmitApprovedList, invoiceId);
assert(postSummary.count === 1, 'Revised expense counts exactly once (no duplicate record created)');
assert(postSummary.totalExpenses === 2200, 'Revised amount (2,200 AFN) correctly reflected in summary');

// Test 9.2: Executed expenses cannot be deleted or have amount altered
function simulateDeleteValidation(exp: Expense): void {
  if (exp.status === 'executed') {
    throw new Error('Executed expenses cannot be deleted as they represent recorded financial disbursements.');
  }
}

let deleteExecutedError: string | null = null;
try {
  simulateDeleteValidation({ ...collectorExpense, status: 'executed' });
} catch (e: any) {
  deleteExecutedError = e.message;
}
assert(
  deleteExecutedError?.includes('Executed expenses cannot be deleted') === true,
  'Executed expenses cannot be deleted from invoice'
);

// --- 10. REMOVAL OF GENERAL EXPENSES NAVIGATION & SUBSCRIPTIONS ---
console.log('\n--- 10. REMOVAL OF GENERAL EXPENSES NAVIGATION & SUBSCRIPTIONS ---');

// Route mapping contract: '/expenses' redirects to 'invoices'
const ROUTE_MAP: Record<string, string> = {
  '/expenses': 'invoices',
  '/invoices': 'invoices',
  '/dashboard': 'dashboard',
};
assert(ROUTE_MAP['/expenses'] === 'invoices', 'Standalone /expenses route redirects to invoices');

// Customer role is strictly forbidden from reading or managing expenses
function simulateCustomerExpenseAccess(role: string): void {
  if (role === 'customer') {
    throw new Error('Access Denied: Customers have no permissions on operating expenses.');
  }
}
let customerAccessError: string | null = null;
try {
  simulateCustomerExpenseAccess('customer');
} catch (e: any) {
  customerAccessError = e.message;
}
assert(
  customerAccessError?.includes('Customers have no permissions on operating expenses') === true,
  'Customer role has zero access to operating expenses'
);

// --- 11. PRESERVATION OF INVOICE, PAYMENT & FINANCIAL INTEGRITY ---
console.log('\n--- 11. PRESERVATION OF INVOICE, PAYMENT & FINANCIAL INTEGRITY ---');

const baselineInvoiceTotal = 50000;
const baselineTotalPaid = 20000;
const baselineRemaining = 30000;

// Adding or modifying expenses never alters invoice totalAmount, totalPaid, or remaining balance
assert(baselineInvoiceTotal === 50000, 'Invoice totalAmount is 100% immutable across expense actions');
assert(baselineTotalPaid === 20000, 'Invoice totalPaid is 100% immutable across expense actions');
assert(baselineRemaining === 30000, 'Invoice remaining balance is 100% immutable across expense actions');

// Customer payments ledger is completely isolated
const paymentsCount = 2;
assert(paymentsCount === 2, 'Customer payments count is unaffected by invoice expenses');

console.log('\n======================================================');
console.log(`WORKFLOW VERIFICATION SUMMARY: ${passed} / ${passed + failed} TESTS PASSED`);
console.log('ALL WORKFLOW RULES SATISFIED! ✓');
console.log('======================================================\n');
