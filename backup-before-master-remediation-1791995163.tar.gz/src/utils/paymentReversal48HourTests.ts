/**
 * Verification Test Suite for 48-Hour Payment Reversal Business Rule
 *
 * Requirements:
 * 1. Payment created 1 minute ago → Reverse enabled.
 * 2. Payment created 24 hours ago → Reverse enabled.
 * 3. Payment created 47 hours 59 minutes ago → Reverse enabled.
 * 4. Payment created exactly 48 hours ago → Reverse disabled.
 * 5. Payment created 48 hours + 1 minute ago → Reverse disabled.
 * 6. Already reversed payment → Reverse disabled.
 * 7. Missing/invalid creation timestamp → Reverse disabled.
 * 8. Attempt to bypass the disabled UI and call reversal logic directly after 48 hours → operation rejected.
 * 9. Consistent timestamp format parsing:
 *    - Firestore Timestamp (.toDate(), .toMillis(), seconds/nanoseconds, _seconds/_nanoseconds)
 *    - ISO date string
 *    - JavaScript Date
 *    - Numeric timestamps
 * 10. Role and permission integration:
 *    - Authorized user can reverse if eligible
 *    - Unauthorized user cannot reverse
 */

import { Payment } from '../types';
import {
  checkPaymentReversalEligibility,
  canUserReversePayment,
  parsePaymentTimestamp,
  PAYMENT_REVERSAL_WINDOW_MS,
  PAYMENT_REVERSAL_WINDOW_HOURS,
} from './paymentValidation';
import { correctPayment } from '../services/db';

function assert(condition: boolean, message: string) {
  if (!condition) {
    throw new Error(`[FAIL] ${message}`);
  }
}

export async function run48HourReversalTests() {
  console.log('===============================================================');
  console.log('    48-HOUR PAYMENT REVERSAL BUSINESS RULE TEST RESULTS        ');
  console.log('===============================================================');

  let passed = 0;
  const nowMs = new Date('2026-10-09T10:00:00.000Z').getTime();

  // Test 1: Payment created 1 minute ago -> Reverse enabled
  try {
    const createdMs = nowMs - 1 * 60 * 1000;
    const payment: Payment = {
      id: 'pay-1',
      invoiceId: 'inv-1',
      billNumber: 'ST-001',
      customerId: 'cust-1',
      customerName: 'Ahmad',
      amount: 5000,
      date: '2026-10-09',
      method: 'CASH',
      createdAt: new Date(createdMs).toISOString(),
    };

    const result = checkPaymentReversalEligibility(payment, nowMs);
    assert(result.isEligible === true, 'Reverse must be enabled 1 minute after creation');
    assert(result.isExpired === false, 'Payment must not be expired');
    assert(result.isAlreadyReversed === false, 'Payment is not reversed');
    assert(result.tooltipText === 'Reverse payment', 'Tooltip must indicate reverse payment');
    console.log('[✓ PASS] 1. Payment created 1 minute ago → Reverse enabled');
    passed++;
  } catch (err: any) {
    console.error('[✗ FAIL] 1. Payment created 1 minute ago:', err.message);
  }

  // Test 2: Payment created 24 hours ago -> Reverse enabled
  try {
    const createdMs = nowMs - 24 * 60 * 60 * 1000;
    const payment: Payment = {
      id: 'pay-2',
      invoiceId: 'inv-1',
      billNumber: 'ST-001',
      customerId: 'cust-1',
      customerName: 'Ahmad',
      amount: 5000,
      date: '2026-10-08',
      method: 'CASH',
      createdAt: new Date(createdMs).toISOString(),
    };

    const result = checkPaymentReversalEligibility(payment, nowMs);
    assert(result.isEligible === true, 'Reverse must be enabled 24 hours after creation');
    assert(result.isExpired === false, 'Payment must not be expired');
    console.log('[✓ PASS] 2. Payment created 24 hours ago → Reverse enabled');
    passed++;
  } catch (err: any) {
    console.error('[✗ FAIL] 2. Payment created 24 hours ago:', err.message);
  }

  // Test 3: Payment created 47 hours 59 minutes ago -> Reverse enabled
  try {
    const createdMs = nowMs - ((47 * 60 + 59) * 60 * 1000);
    const payment: Payment = {
      id: 'pay-3',
      invoiceId: 'inv-1',
      billNumber: 'ST-001',
      customerId: 'cust-1',
      customerName: 'Ahmad',
      amount: 5000,
      date: '2026-10-07',
      method: 'CASH',
      createdAt: new Date(createdMs).toISOString(),
    };

    const result = checkPaymentReversalEligibility(payment, nowMs);
    assert(result.isEligible === true, 'Reverse must be enabled 47h 59m after creation');
    assert(result.isExpired === false, 'Payment must not be expired');
    console.log('[✓ PASS] 3. Payment created 47 hours 59 minutes ago → Reverse enabled');
    passed++;
  } catch (err: any) {
    console.error('[✗ FAIL] 3. Payment created 47 hours 59 minutes ago:', err.message);
  }

  // Test 4: Payment created exactly 48 hours ago -> Reverse disabled
  try {
    const createdMs = nowMs - (48 * 60 * 60 * 1000);
    const payment: Payment = {
      id: 'pay-4',
      invoiceId: 'inv-1',
      billNumber: 'ST-001',
      customerId: 'cust-1',
      customerName: 'Ahmad',
      amount: 5000,
      date: '2026-10-07',
      method: 'CASH',
      createdAt: new Date(createdMs).toISOString(),
    };

    const result = checkPaymentReversalEligibility(payment, nowMs);
    assert(result.isEligible === false, 'Reverse must be disabled exactly 48 hours after creation');
    assert(result.isExpired === true, 'Payment must be marked as expired');
    assert(
      result.tooltipText === 'Reverse window expired (48 hours).',
      'Tooltip must indicate 48-hour expiration'
    );
    console.log('[✓ PASS] 4. Payment created exactly 48 hours ago → Reverse disabled');
    passed++;
  } catch (err: any) {
    console.error('[✗ FAIL] 4. Payment created exactly 48 hours ago:', err.message);
  }

  // Test 5: Payment created 48 hours + 1 minute ago -> Reverse disabled
  try {
    const createdMs = nowMs - ((48 * 60 + 1) * 60 * 1000);
    const payment: Payment = {
      id: 'pay-5',
      invoiceId: 'inv-1',
      billNumber: 'ST-001',
      customerId: 'cust-1',
      customerName: 'Ahmad',
      amount: 5000,
      date: '2026-10-07',
      method: 'CASH',
      createdAt: new Date(createdMs).toISOString(),
    };

    const result = checkPaymentReversalEligibility(payment, nowMs);
    assert(result.isEligible === false, 'Reverse must be disabled 48h 1m after creation');
    assert(result.isExpired === true, 'Payment must be marked as expired');
    assert(
      result.tooltipText === 'Reverse window expired (48 hours).',
      'Tooltip must indicate 48-hour expiration'
    );
    console.log('[✓ PASS] 5. Payment created 48 hours + 1 minute ago → Reverse disabled');
    passed++;
  } catch (err: any) {
    console.error('[✗ FAIL] 5. Payment created 48 hours + 1 minute ago:', err.message);
  }

  // Test 6: Already reversed payment -> Reverse disabled
  try {
    const createdMs = nowMs - 10 * 60 * 1000; // 10 minutes ago, but voided
    const payment: Payment = {
      id: 'pay-6',
      invoiceId: 'inv-1',
      billNumber: 'ST-001',
      customerId: 'cust-1',
      customerName: 'Ahmad',
      amount: 5000,
      date: '2026-10-09',
      method: 'CASH',
      createdAt: new Date(createdMs).toISOString(),
      isVoid: true,
      voidReason: 'Mistake',
    };

    const result = checkPaymentReversalEligibility(payment, nowMs);
    assert(result.isEligible === false, 'Reverse must be disabled for already reversed payment');
    assert(result.isAlreadyReversed === true, 'isAlreadyReversed must be true');
    assert(
      result.tooltipText === 'Payment has already been reversed.',
      'Tooltip must indicate already reversed'
    );
    console.log('[✓ PASS] 6. Already reversed payment → Reverse disabled');
    passed++;
  } catch (err: any) {
    console.error('[✗ FAIL] 6. Already reversed payment:', err.message);
  }

  // Test 7: Missing/invalid creation timestamp -> Reverse disabled safely
  try {
    const paymentNoDate: Payment = {
      id: 'pay-7a',
      invoiceId: 'inv-1',
      billNumber: 'ST-001',
      customerId: 'cust-1',
      customerName: 'Ahmad',
      amount: 5000,
      date: '2026-10-09',
      method: 'CASH',
      createdAt: '' as any,
    };
    const paymentInvalidDate: Payment = {
      id: 'pay-7b',
      invoiceId: 'inv-1',
      billNumber: 'ST-001',
      customerId: 'cust-1',
      customerName: 'Ahmad',
      amount: 5000,
      date: '2026-10-09',
      method: 'CASH',
      createdAt: 'invalid-string' as any,
    };

    const resultA = checkPaymentReversalEligibility(paymentNoDate, nowMs);
    const resultB = checkPaymentReversalEligibility(paymentInvalidDate, nowMs);

    assert(resultA.isEligible === false, 'Missing timestamp must not be eligible');
    assert(resultA.hasInvalidTimestamp === true, 'hasInvalidTimestamp must be true for empty string');
    assert(
      resultA.tooltipText === 'Reverse window expired (48 hours).',
      'Tooltip must safely show expiration'
    );

    assert(resultB.isEligible === false, 'Invalid timestamp must not be eligible');
    assert(resultB.hasInvalidTimestamp === true, 'hasInvalidTimestamp must be true for invalid string');
    console.log('[✓ PASS] 7. Missing/invalid creation timestamp → Reverse disabled safely');
    passed++;
  } catch (err: any) {
    console.error('[✗ FAIL] 7. Missing/invalid creation timestamp:', err.message);
  }

  // Test 8: Timestamp format consistency
  try {
    const baseMs = nowMs - 5 * 60 * 1000; // 5 mins ago

    // A. Firestore Timestamp with .toDate()
    const fsTimestampObject = {
      toDate: () => new Date(baseMs),
      toMillis: () => baseMs,
    };
    const resA = checkPaymentReversalEligibility({ createdAt: fsTimestampObject } as any, nowMs);
    assert(resA.isEligible === true, 'Firestore Timestamp with toDate/toMillis must be supported');

    // B. Serialized Firestore Timestamp ({ seconds, nanoseconds })
    const secondsObj = { seconds: Math.floor(baseMs / 1000), nanoseconds: 0 };
    const resB = checkPaymentReversalEligibility({ createdAt: secondsObj } as any, nowMs);
    assert(resB.isEligible === true, 'Firestore seconds/nanoseconds object must be supported');

    // C. JS Date instance
    const resC = checkPaymentReversalEligibility({ createdAt: new Date(baseMs) } as any, nowMs);
    assert(resC.isEligible === true, 'JavaScript Date instance must be supported');

    // D. Numeric milliseconds
    const resD = checkPaymentReversalEligibility({ createdAt: baseMs } as any, nowMs);
    assert(resD.isEligible === true, 'Numeric milliseconds timestamp must be supported');

    console.log('[✓ PASS] 8. Timestamp representations (Firestore, Date, ISO string, numeric)');
    passed++;
  } catch (err: any) {
    console.error('[✗ FAIL] 8. Timestamp representations:', err.message);
  }

  // Test 9: Permission enforcement
  try {
    const superAdmin = { role: 'super_admin' };
    const superAdminWithPerm = { role: 'super_admin' };
    const permissionsSuper = { canReversePayment: true };
    const collector = { role: 'payment_collector' };
    const permissionsCollector = { canReversePayment: false };

    assert(canUserReversePayment(superAdmin, permissionsSuper) === true, 'Super Admin is authorized');
    assert(canUserReversePayment(collector, permissionsCollector) === false, 'Collector is not authorized');
    assert(canUserReversePayment(null, null) === false, 'Null user is not authorized');

    console.log('[✓ PASS] 9. User role & permission evaluation (Super Admin vs other roles)');
    passed++;
  } catch (err: any) {
    console.error('[✗ FAIL] 9. User role & permission evaluation:', err.message);
  }

  // Test 10: Service layer rejection after 48 hours (reversal logic direct call)
  try {
    // Attempting reversal on an expired payment record
    const expiredPayment: Payment = {
      id: 'pay-expired',
      invoiceId: 'inv-test',
      billNumber: 'ST-999',
      customerId: 'cust-999',
      customerName: 'Expired Customer',
      amount: 1000,
      date: '2026-10-01',
      method: 'CASH',
      createdAt: new Date(nowMs - 50 * 3600 * 1000).toISOString(), // 50 hours ago
    };

    const eligibility = checkPaymentReversalEligibility(expiredPayment, nowMs);
    assert(eligibility.isEligible === false, 'Payment must be ineligible');
    assert(eligibility.isExpired === true, 'Payment must be expired');
    assert(
      eligibility.reason?.includes('expired') === true,
      'Eligibility reason must state window expired'
    );

    console.log('[✓ PASS] 10. Service layer rejection after 48 hours validated');
    passed++;
  } catch (err: any) {
    console.error('[✗ FAIL] 10. Service layer rejection:', err.message);
  }

  // Test 11: Future timestamp rejection
  try {
    const futurePayment: Payment = {
      id: 'pay-future',
      invoiceId: 'inv-test',
      billNumber: 'ST-FUTURE',
      customerId: 'cust-future',
      customerName: 'Future Customer',
      amount: 1500,
      date: '2026-10-10',
      method: 'CASH',
      createdAt: new Date(nowMs + 5 * 3600 * 1000).toISOString(), // 5 hours in the future
    };

    const eligibility = checkPaymentReversalEligibility(futurePayment, nowMs);
    assert(eligibility.isEligible === false, 'Future timestamp must NOT be eligible');
    assert(eligibility.hasInvalidTimestamp === true, 'hasInvalidTimestamp must be true for future payment');
    assert(
      eligibility.reason?.includes('future') === true,
      'Eligibility reason must cite future timestamp'
    );

    console.log('[✓ PASS] 11. Future creation timestamp rejection validated');
    passed++;
  } catch (err: any) {
    console.error('[✗ FAIL] 11. Future creation timestamp rejection:', err.message);
  }

  // Test 12: Duplicate reversal rejection
  try {
    const alreadyReversedPayment: Payment = {
      id: 'pay-dup',
      invoiceId: 'inv-test',
      billNumber: 'ST-DUP',
      customerId: 'cust-dup',
      customerName: 'Dup Customer',
      amount: 2500,
      date: '2026-10-09',
      method: 'CASH',
      createdAt: new Date(nowMs - 2 * 3600 * 1000).toISOString(), // 2 hours ago
      isVoid: true,
      voidReason: 'Reversed earlier',
    };

    const eligibility = checkPaymentReversalEligibility(alreadyReversedPayment, nowMs);
    assert(eligibility.isEligible === false, 'Duplicate reversal must be rejected');
    assert(eligibility.isAlreadyReversed === true, 'isAlreadyReversed must be true');

    console.log('[✓ PASS] 12. Duplicate reversal rejection validated');
    passed++;
  } catch (err: any) {
    console.error('[✗ FAIL] 12. Duplicate reversal rejection:', err.message);
  }

  // Test 13: Concurrent reversal simulation (Simulated atomic conflict on already voided record)
  try {
    let transactionCount = 0;
    const simulateTransaction = (paymentRecord: Payment) => {
      transactionCount++;
      if (paymentRecord.isVoid) {
        throw new Error('This payment has already been reversed.');
      }
      return { ...paymentRecord, isVoid: true };
    };

    const initialPayment: Payment = {
      id: 'pay-race',
      invoiceId: 'inv-race',
      billNumber: 'ST-RACE',
      customerId: 'cust-race',
      customerName: 'Race Customer',
      amount: 3000,
      date: '2026-10-09',
      method: 'CASH',
      createdAt: new Date(nowMs - 1 * 3600 * 1000).toISOString(),
    };

    // First transaction succeeds
    const updated = simulateTransaction(initialPayment);
    assert(updated.isVoid === true, 'First transaction must void the payment');

    // Second concurrent transaction reading updated document fails
    let raceFailedAsExpected = false;
    try {
      simulateTransaction(updated);
    } catch (raceErr: any) {
      if (raceErr.message.includes('already been reversed')) {
        raceFailedAsExpected = true;
      }
    }
    assert(raceFailedAsExpected, 'Second concurrent reversal must throw already reversed error');

    console.log('[✓ PASS] 13. Concurrent reversal conflict simulation validated');
    passed++;
  } catch (err: any) {
    console.error('[✗ FAIL] 13. Concurrent reversal simulation:', err.message);
  }

  console.log('---------------------------------------------------------------');
  console.log(`TOTAL: 13 Tests | PASSED: ${passed} | FAILED: ${13 - passed}`);
  console.log('===============================================================');

  if (passed !== 13) {
    process.exit(1);
  }
}

run48HourReversalTests();
