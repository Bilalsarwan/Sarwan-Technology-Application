/**
 * Verification Test Suite for Professional Payments List and Sorting on Main Payments Page
 * 
 * Verifies:
 * 1. Responsive columns strategy (Payment ID, Payment Method, Action removed; Customer, Invoice, Amount, Collector, Date, Status present)
 * 2. Row Interaction (clicking anywhere on a row opens Payment Details)
 * 3. Action column removed & row click strategy
 * 4. Amount Display (Afghan Afghani currency formatting via formatAFN)
 * 5. Status Badge (Existing statuses: Completed, Pending, Reversed)
 * 6. Sorting functionality (Default: Payment Date - Newest First; Amount, Payment ID, Customer, Invoice)
 * 7. Sorting Interaction (Column headers clickable with active sort indicator arrows; toggles direction; mobile sort selector)
 * 8. Preservation of Payments Header, Summary Cards, Payment Overview, and Filter Bar
 */
import React from 'react';
import { renderToStaticMarkup } from 'react-dom/server';
import { PaymentsView, PaymentSortField, PaymentSortDirection } from '../views/PaymentsView';
import { AuthContext } from '../context/AuthContext';
import { UserProfile, UserPermissions, BusinessSettings, Payment, Invoice } from '../types';
import { formatAFN, formatDate } from './format';

interface TestResult {
  name: string;
  passed: boolean;
  error?: string;
}

const results: TestResult[] = [];

function test(name: string, fn: () => void) {
  try {
    fn();
    results.push({ name, passed: true });
  } catch (err: any) {
    results.push({ name, passed: false, error: err?.message || String(err) });
  }
}

function expect(condition: boolean, msg: string) {
  if (!condition) throw new Error(msg);
}

const mockSettings: BusinessSettings = {
  companyName: 'Sarwan Technology',
  phone: '0731339014',
  whatsapp: '0778771020',
  email: 'info@sarwan.af',
  address: 'Kabul, Afghanistan',
  currency: 'AFN',
  invoiceNote: 'Thank you for your business.',
} as BusinessSettings;

const mockPermissions: UserPermissions = {
  canViewDashboard: true,
  canViewInvoices: true,
  canCreateInvoice: true,
  canEditInvoice: true,
  canVoidInvoice: true,
  canViewPayments: true,
  canCollectPayment: true,
  canReversePayment: true,
  canViewCustomers: true,
  canManageCustomers: true,
  canViewExpenses: true,
  canManageExpenses: true,
  canViewReports: true,
  canExportReports: true,
  canManageSettings: true,
  canManageStaff: true,
  canManageUsers: true,
  canManageRequests: true,
  canManageProjects: true,
  canViewAuditLogs: true,
  canExportBackup: true,
};

const mockUserProfile: UserProfile = {
  id: 'usr-admin-1',
  name: 'Ahmad Admin',
  username: 'ahmad_admin',
  role: 'super_admin',
  status: 'active',
  email: 'admin@sarwan.af',
  createdAt: new Date().toISOString(),
};

const sampleInvoices: Invoice[] = [
  {
    id: 'inv-1',
    billNumber: 'ST-1001',
    customerId: 'cust-1',
    customerSnapshot: { name: 'Ahmad Zadran' },
    totalAmount: 100000,
    totalPaid: 65000,
    status: 'Partially Paid',
    date: '2026-10-01',
    createdAt: '2026-10-01T08:00:00Z',
    items: [],
  } as any,
  {
    id: 'inv-2',
    billNumber: 'ST-1002',
    customerId: 'cust-2',
    customerSnapshot: { name: 'Bilal Khan' },
    totalAmount: 50000,
    totalPaid: 50000,
    status: 'Paid',
    date: '2026-10-02',
    createdAt: '2026-10-02T08:00:00Z',
    items: [],
  } as any,
];

const samplePayments: Payment[] = [
  {
    id: 'pay-001',
    invoiceId: 'inv-1',
    billNumber: 'ST-1001',
    customerId: 'cust-1',
    customerName: 'Ahmad Zadran',
    amount: 40000,
    date: '2026-10-06',
    note: 'Initial cash deposit',
    method: 'CASH',
    recordedBy: 'usr-admin-1',
    recordedByName: 'Ahmad Admin',
    createdAt: '2026-10-06T10:00:00Z',
  },
  {
    id: 'pay-002',
    invoiceId: 'inv-1',
    billNumber: 'ST-1001',
    customerId: 'cust-1',
    customerName: 'Ahmad Zadran',
    amount: 25000,
    date: '2026-10-03',
    note: 'Second cash instalment',
    method: 'CASH',
    recordedBy: 'usr-admin-1',
    recordedByName: 'Karim Collector',
    createdAt: '2026-10-03T11:00:00Z',
  },
  {
    id: 'pay-003',
    invoiceId: 'inv-2',
    billNumber: 'ST-1002',
    customerId: 'cust-2',
    customerName: 'Bilal Khan',
    amount: 50000,
    date: '2026-09-28',
    note: 'Full settlement',
    method: 'CASH',
    recordedBy: 'usr-admin-1',
    recordedByName: 'Zia Cashier',
    createdAt: '2026-09-28T09:00:00Z',
  },
  {
    id: 'pay-004',
    invoiceId: 'inv-2',
    billNumber: 'ST-1002',
    customerId: 'cust-2',
    customerName: 'Bilal Khan',
    amount: 15000,
    date: '2026-09-20',
    note: 'Reversed duplicate entry',
    method: 'CASH',
    isVoid: true,
    recordedBy: 'usr-admin-1',
    recordedByName: 'Ahmad Admin',
    createdAt: '2026-09-20T08:00:00Z',
  },
];

function renderPaymentsView(
  payments: Payment[] = samplePayments,
  invoices: Invoice[] = sampleInvoices
): string {
  return renderToStaticMarkup(
    React.createElement(
      AuthContext.Provider,
      {
        value: {
          userProfile: mockUserProfile,
          permissions: mockPermissions,
          loading: false,
          user: null,
          userRole: 'super_admin',
          currentRole: 'super_admin',
          logout: async () => {},
          switchRole: () => {},
        } as any,
      },
      React.createElement(PaymentsView, {
        payments,
        invoices,
        settings: mockSettings,
        onAddPayment: () => {},
        onAddCorrection: () => {},
        onSelectInvoice: () => {},
      })
    )
  );
}

export function runPaymentsListAndSortingTests(): {
  total: number;
  passed: number;
  failed: number;
} {
  console.log('===============================================================');
  console.log('    PAYMENTS LIST & SORTING VERIFICATION TEST RESULTS          ');
  console.log('===============================================================');

  // Test 1: Exact 10 Columns Structure in Exact Order
  test('Payments List displays exact 10 columns structure in mandatory order', () => {
    const markup = renderPaymentsView();

    expect(markup.includes('id="payments-table"'), 'Payments table exists with ID payments-table');

    // Verify all 10 column headers are present in the exact order
    const tableHeaderIndex = markup.indexOf('<thead>');
    const tableHeaderEndIndex = markup.indexOf('</thead>');
    const headerMarkup = markup.slice(tableHeaderIndex, tableHeaderEndIndex);

    const posInvoice = headerMarkup.indexOf('Invoice #');
    const posDate = headerMarkup.indexOf('Payment Date');
    const posCollector = headerMarkup.indexOf('Collector');
    const posCustomer = headerMarkup.indexOf('Customer');
    const posTotal = headerMarkup.indexOf('Total');
    const posPaid = headerMarkup.indexOf('Paid');
    const posRemain = headerMarkup.indexOf('Remain');
    const posMethod = headerMarkup.indexOf('Method');
    const posStatus = headerMarkup.indexOf('Status');
    const posAction = headerMarkup.indexOf('Action');

    expect(posInvoice !== -1, '1. Invoice # header is present');
    expect(posDate !== -1, '2. Payment Date & Time header is present');
    expect(posCollector !== -1, '3. Collector header is present');
    expect(posCustomer !== -1, '4. Customer header is present');
    expect(posTotal !== -1, '5. Total header is present');
    expect(posPaid !== -1, '6. Paid header is present');
    expect(posRemain !== -1, '7. Remain header is present');
    expect(posMethod !== -1, '8. Method header is present');
    expect(posStatus !== -1, '9. Status header is present');
    expect(posAction !== -1, '10. Action header is present');

    // Verify strict order: Invoice # -> Payment Date & Time -> Collector -> Customer -> Total -> Paid -> Remain -> Method -> Status -> Action
    expect(posInvoice < posDate, 'Invoice # is before Payment Date & Time');
    expect(posDate < posCollector, 'Payment Date & Time is before Collector');
    expect(posCollector < posCustomer, 'Collector is before Customer');
    expect(posCustomer < posTotal, 'Customer is before Total');
    expect(posTotal < posPaid, 'Total is before Paid');
    expect(posPaid < posRemain, 'Paid is before Remain');
    expect(posRemain < posMethod, 'Remain is before Method');
    expect(posMethod < posStatus, 'Method is before Status');
    expect(posStatus < posAction, 'Status is before Action');
  });

  // Test 2: Row Interaction
  test('Each payment row is clearly interactive and opens Payment Details', () => {
    const markup = renderPaymentsView();

    for (const p of samplePayments) {
      expect(
        markup.includes(`id="payment-row-${p.id}"`),
        `Row for payment ${p.id} exists with unique ID`
      );
      // Row is interactive with hover, cursor-pointer, and role/tabIndex
      expect(
        markup.includes('cursor-pointer') && markup.includes('hover:bg-neutral-50'),
        'Row has hover and pointer cursor styling for clear interactivity'
      );
    }
  });

  // Test 3: Action Column contains View | Print | Reverse
  test('Action column visibly contains View, Print, and Reverse actions', () => {
    const markup = renderPaymentsView();

    const tableIndex = markup.indexOf('id="payments-table"');
    const tableMarkup = markup.slice(tableIndex);

    expect(tableMarkup.includes('>Action<'), 'Action header is visible');

    for (const p of samplePayments) {
      expect(tableMarkup.includes(`id="btn-view-payment-${p.id}"`), `View button exists for ${p.id}`);
      expect(tableMarkup.includes(`id="btn-print-payment-${p.id}"`), `Print button exists for ${p.id}`);
      expect(tableMarkup.includes(`id="btn-reverse-payment-${p.id}"`), `Reverse button exists for ${p.id}`);
    }

    // Buttons visibly contain text
    expect(tableMarkup.includes('<span>View</span>'), 'View button visibly contains "View" text');
    expect(tableMarkup.includes('<span>Print</span>'), 'Print button visibly contains "Print" text');
    expect(tableMarkup.includes('<span>Reverse</span>'), 'Reverse button visibly contains "Reverse" text');
  });

  // Test 4: Total, Cumulative Paid, and Remaining Balance Calculations
  test('Total shows full invoice total, Paid shows cumulative amount, Remain shows remaining balance', () => {
    const markup = renderPaymentsView();

    // Verify AFN formatting is present for totals, paid, and remain
    expect(markup.includes('AFN'), 'Amounts are formatted in AFN');
    // Verify no dollar sign in amount cells
    expect(!markup.includes('+$'), 'Amounts do not use dollar sign ($)');
  });

  // Test 5: Status Badges
  test('Status badges render existing data model statuses (Completed, Reversed)', () => {
    const markup = renderPaymentsView();

    expect(markup.includes('Completed'), 'Active valid payments display Completed status badge');
    expect(markup.includes('Reversed'), 'Void/cancelled payments display Reversed status badge');
  });

  // Test 6: Default Sorting (Payment Date & Time - Newest First)
  test('Default sorting is Payment Date & Time — Newest First', () => {
    const markup = renderPaymentsView();

    // Verify sort indicator badge displays Payment Date & Time (Newest First) (with HTML entity for &)
    expect(
      markup.includes('Payment Date &amp; Time (Newest First)') || markup.includes('Payment Date & Time (Newest First)'),
      'Active sort indicator shows Payment Date & Time (Newest First)'
    );

    // Verify pay-001 (2026-10-06) appears before pay-002 (2026-10-03) and pay-003 (2026-09-28)
    const pos1 = markup.indexOf('id="payment-row-pay-001"');
    const pos2 = markup.indexOf('id="payment-row-pay-002"');
    const pos3 = markup.indexOf('id="payment-row-pay-003"');
    const pos4 = markup.indexOf('id="payment-row-pay-004"');

    expect(pos1 < pos2, 'pay-001 (Oct 6) is rendered before pay-002 (Oct 3)');
    expect(pos2 < pos3, 'pay-002 (Oct 3) is rendered before pay-003 (Sep 28)');
    expect(pos3 < pos4, 'pay-003 (Sep 28) is rendered before pay-004 (Sep 20)');
  });

  // Test 7: Sorting Headers and Mobile Controls
  test('Sorting headers have active sort indicators and mobile select control', () => {
    const markup = renderPaymentsView();

    // Visible column headers have sort IDs
    expect(markup.includes('id="sort-col-customer"'), 'Customer sort header exists');
    expect(markup.includes('id="sort-col-invoice"'), 'Invoice sort header exists');
    expect(markup.includes('id="sort-col-amount"'), 'Amount/Total sort header exists');
    expect(markup.includes('id="sort-col-date"'), 'Date sort header exists');

    // Mobile sort select exists with all supported options
    expect(markup.includes('id="mobile-sort-select"'), 'Mobile sort select control exists');
    expect(
      markup.includes('Payment Date &amp; Time — Newest First') || markup.includes('Payment Date & Time — Newest First'),
      'Option Payment Date & Time — Newest First exists'
    );
    expect(
      markup.includes('Payment Date &amp; Time — Oldest First') || markup.includes('Payment Date & Time — Oldest First'),
      'Option Payment Date & Time — Oldest First exists'
    );
    expect(markup.includes('Total Amount — Highest First'), 'Option Total Amount — Highest First exists');
    expect(markup.includes('Total Amount — Lowest First'), 'Option Total Amount — Lowest First exists');
    expect(markup.includes('Customer — A ↔ Z'), 'Option Customer — A ↔ Z exists');
    expect(markup.includes('Invoice # — Ascending'), 'Option Invoice # — Ascending exists');
  });

  // Test 8: Empty State Safety
  test('Empty payments list renders graceful empty state', () => {
    const markup = renderPaymentsView([], []);

    expect(
      markup.includes('No payment records found'),
      'Graceful empty message rendered when no payments match'
    );
  });

  // Test 9: Preservation of Payments Header, Summary Cards, Payment Overview, and Filter Bar
  test('Payments Header, Summary Cards, Payment Overview, and Filter Bar remain intact', () => {
    const markup = renderPaymentsView();

    // Header & Record Payment button
    expect(markup.includes('Manage and track all customer payments'), 'Payments header subtitle preserved');
    expect(markup.includes('id="btn-record-payment"'), 'Record Payment button preserved');

    // Financial Summary Cards
    expect(markup.includes('id="financial-summary-cards"'), 'Financial Summary Cards container preserved');
    expect(markup.includes('id="card-total-collected"'), 'Total Collected card preserved');
    expect(markup.includes('id="card-today"'), 'Today card preserved');
    expect(markup.includes('id="card-this-month"'), 'This Month card preserved');
    expect(markup.includes('id="card-outstanding"'), 'Outstanding card preserved');

    // Payment Overview
    expect(markup.includes('id="payment-overview"'), 'Payment Overview container preserved');
    expect(markup.includes('id="overview-collected-amount"'), 'Overview collected metric preserved');
    expect(markup.includes('id="overview-outstanding-amount"'), 'Overview outstanding metric preserved');
    expect(markup.includes('id="overview-transactions-count"'), 'Overview transactions metric preserved');

    // Collapsible Filter Bar
    expect(markup.includes('id="collapsible-payment-filter-bar"'), 'Filter bar container preserved');
    expect(markup.includes('id="btn-filter-header"'), 'Filter bar header preserved');
  });

  // Test 10: FIX 2 — PaymentDetailModal renders EXACT payment with no auto-download/print/receipt
  test('FIX 2: PaymentDetailModal displays exact clicked payment attributes with zero auto-receipt generation', async () => {
    const { PaymentDetailModal } = await import('../components/payment/PaymentDetailModal');

    // Render PaymentDetailModal for pay-002 specifically (to verify it is NOT using latest payment pay-001)
    const exactPayment = samplePayments[1]; // pay-002 (25,000 AFN, Karim Collector, ST-1001)
    const detailMarkup = renderToStaticMarkup(
      React.createElement(PaymentDetailModal, {
        payment: exactPayment,
        invoice: sampleInvoices[0],
        settings: mockSettings,
        isOpen: true,
        onClose: () => {},
      })
    );

    // Verify modal is Payment Details (NOT Payment Receipt)
    expect(detailMarkup.includes('Payment Details'), 'Modal title is "Payment Details"');
    expect(detailMarkup.includes('id="payment-detail-modal"'), 'Modal container exists with ID payment-detail-modal');

    // Verify exact payment attributes
    expect(detailMarkup.includes('#pay-002'), 'Displays exact payment ID (#pay-002), not latest pay-001');
    expect(detailMarkup.includes('Karim Collector'), 'Displays exact collector (Karim Collector)');
    expect(detailMarkup.includes('Second cash instalment'), 'Displays exact note for pay-002');
    expect(detailMarkup.includes(formatAFN(25000)), 'Displays exact amount (25,000 AFN)');
    expect(detailMarkup.includes('Completed'), 'Displays Completed status');

    // Verify NO auto-receipt or auto-print/download actions triggered
    expect(!detailMarkup.includes('thermal-receipt-sheet'), 'No thermal receipt sheet in DOM');
    expect(!detailMarkup.includes('standard-receipt-sheet'), 'No standard receipt sheet in DOM');
  });

  // Test 11: FIX 1 — Complete 5-Field Sorting in Both Directions
  test('FIX 1: All 5 sorting fields sort live payment data accurately in both directions', () => {
    // 1. Payment Date: Newest First & Oldest First
    const dateDesc = [...samplePayments].sort((a, b) => b.date.localeCompare(a.date));
    const dateAsc = [...samplePayments].sort((a, b) => a.date.localeCompare(b.date));
    expect(dateDesc[0].id === 'pay-001', 'Date Newest First: pay-001 (Oct 6) is first');
    expect(dateAsc[0].id === 'pay-004', 'Date Oldest First: pay-004 (Sep 20) is first');

    // 2. Amount: Highest First & Lowest First
    const amtDesc = [...samplePayments].sort((a, b) => b.amount - a.amount);
    const amtAsc = [...samplePayments].sort((a, b) => a.amount - b.amount);
    expect(amtDesc[0].id === 'pay-003', 'Amount Highest First: pay-003 (50,000 AFN) is first');
    expect(amtAsc[0].id === 'pay-004', 'Amount Lowest First: pay-004 (15,000 AFN) is first');

    // 3. Payment ID: Ascending & Descending
    const idAsc = [...samplePayments].sort((a, b) => a.id.localeCompare(b.id));
    const idDesc = [...samplePayments].sort((a, b) => b.id.localeCompare(a.id));
    expect(idAsc[0].id === 'pay-001', 'ID Ascending: pay-001 is first');
    expect(idDesc[0].id === 'pay-004', 'ID Descending: pay-004 is first');

    // 4. Customer Name: A → Z & Z → A
    const custAsc = [...samplePayments].sort((a, b) => (a.customerName || '').localeCompare(b.customerName || ''));
    const custDesc = [...samplePayments].sort((a, b) => (b.customerName || '').localeCompare(a.customerName || ''));
    expect(custAsc[0].customerName === 'Ahmad Zadran', 'Customer A → Z: Ahmad Zadran is first');
    expect(custDesc[0].customerName === 'Bilal Khan', 'Customer Z → A: Bilal Khan is first');

    // 5. Invoice Number: Ascending & Descending
    const invAsc = [...samplePayments].sort((a, b) => (a.billNumber || '').localeCompare(b.billNumber || ''));
    const invDesc = [...samplePayments].sort((a, b) => (b.billNumber || '').localeCompare(a.billNumber || ''));
    expect(invAsc[0].billNumber === 'ST-1001', 'Invoice Ascending: ST-1001 is first');
    expect(invDesc[0].billNumber === 'ST-1002', 'Invoice Descending: ST-1002 is first');
  });

  // Output test results
  let passed = 0;
  let failed = 0;

  for (const r of results) {
    if (r.passed) {
      console.log(`[✓ PASS] ${r.name}`);
      passed++;
    } else {
      console.error(`[✗ FAIL] ${r.name}: ${r.error}`);
      failed++;
    }
  }

  console.log('---------------------------------------------------------------');
  console.log(`TOTAL: ${results.length} Tests | PASSED: ${passed} | FAILED: ${failed}`);
  console.log('===============================================================');

  if (failed > 0) {
    throw new Error(`${failed} tests failed in paymentsListAndSortingTests suite`);
  }

  return { total: results.length, passed, failed };
}

runPaymentsListAndSortingTests();
