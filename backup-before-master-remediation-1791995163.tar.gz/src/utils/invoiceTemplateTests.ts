/**
 * Verification test suite for InvoiceTemplate print/preview/PDF pagination.
 */
import { CanonicalInvoiceItem } from '../types/canonicalInvoiceDocument';
import { isPopulatedInvoiceItem, calculateInvoicePageChunks } from '../components/invoice/InvoiceTemplate';

interface TestResult {
  suite: string;
  name: string;
  passed: boolean;
  error?: string;
}

const results: TestResult[] = [];

function test(suite: string, name: string, fn: () => void) {
  try {
    fn();
    results.push({ suite, name, passed: true });
  } catch (err: any) {
    results.push({ suite, name, passed: false, error: err?.message || String(err) });
  }
}

function expect(condition: boolean, msg: string) {
  if (!condition) throw new Error(msg);
}

export function runInvoiceTemplatePaginationTests(): { total: number; passed: number; failed: number } {
  const blankItem = (sNo: number): CanonicalInvoiceItem => ({
    sNo,
    description: '',
    quantity: '',
    unit: 'pcs',
    unitPrice: '',
    totalAmount: 0,
  });

  const populatedItem = (sNo: number, desc = 'Networking Equipment', qty = 1, price = 2500): CanonicalInvoiceItem => ({
    sNo,
    description: desc,
    quantity: qty,
    unit: 'pcs',
    unitPrice: price,
    totalAmount: qty * price,
  });

  const a4Portrait = { paperSize: 'A4' as const, orientation: 'portrait' as const };
  const a5Portrait = { paperSize: 'A5' as const, orientation: 'portrait' as const };
  const a4Landscape = { paperSize: 'A4' as const, orientation: 'landscape' as const };

  // Test Suite 1: Definition of Populated Item
  test('Item Classification', 'Accurately classifies populated rows versus blank placeholders', () => {
    expect(isPopulatedInvoiceItem(populatedItem(1)), 'Row with description, qty, price is populated');
    expect(isPopulatedInvoiceItem({ sNo: 1, description: 'Only Description', quantity: '', unitPrice: '', totalAmount: 0 }), 'Row with description only is populated');
    expect(isPopulatedInvoiceItem({ sNo: 1, description: '', quantity: 2, unitPrice: 500, totalAmount: 1000 }), 'Row with quantity and unitPrice is populated');
    expect(!isPopulatedInvoiceItem(blankItem(1)), 'Blank placeholder row is not populated');
    expect(!isPopulatedInvoiceItem({ sNo: 1, description: '   ', quantity: '', unitPrice: '', totalAmount: 0 }), 'Whitespace-only description is not populated');
  });

  // Test Suite 2: Single-Page Invoices with Blank Placeholders
  test('Single-Page Invoice', 'Invoice with 1 populated item and 19 blank placeholders renders as exactly 1 page', () => {
    // Standard 20 items from editor: 1 populated, 19 blank
    const items: CanonicalInvoiceItem[] = [
      populatedItem(1, '24-Port Gigabit Switch', 1, 8500),
      ...Array.from({ length: 19 }, (_, i) => blankItem(i + 2)),
    ];

    expect(items.length === 20, 'Invoice contains 20 total items in stored data');

    const chunks = calculateInvoicePageChunks(items, a4Portrait);
    expect(chunks.length === 1, `Expected exactly 1 page chunk, but got ${chunks.length}`);
    expect(chunks[0].length === 1, `Page 1 should only contain the 1 populated item, got ${chunks[0].length}`);
    expect(chunks[0][0].sNo === 1, 'Preserves item sNo');
    expect(chunks[0][0].description === '24-Port Gigabit Switch', 'Preserves item description');
  });

  test('Single-Page Invoice', 'Invoice with 5 populated items and 15 blank placeholders renders as exactly 1 page', () => {
    const items: CanonicalInvoiceItem[] = [
      ...Array.from({ length: 5 }, (_, i) => populatedItem(i + 1, `Service ${i + 1}`, 1, 1000)),
      ...Array.from({ length: 15 }, (_, i) => blankItem(i + 6)),
    ];

    const chunks = calculateInvoicePageChunks(items, a4Portrait);
    expect(chunks.length === 1, `Expected exactly 1 page chunk for 5 items, got ${chunks.length}`);
    expect(chunks[0].length === 5, 'Page 1 has 5 populated items');
  });

  test('Single-Page Invoice', 'Invoice with exactly 14 populated items (A4 capacity limit) renders as 1 page', () => {
    const items: CanonicalInvoiceItem[] = [
      ...Array.from({ length: 14 }, (_, i) => populatedItem(i + 1, `Item ${i + 1}`, 1, 500)),
      ...Array.from({ length: 6 }, (_, i) => blankItem(i + 15)),
    ];

    const chunks = calculateInvoicePageChunks(items, a4Portrait);
    expect(chunks.length === 1, `Expected 1 page for 14 items on A4 portrait, got ${chunks.length}`);
    expect(chunks[0].length === 14, 'Page 1 contains all 14 items');
  });

  test('Single-Page Invoice', 'Invoice with 0 populated items (empty template) renders as 1 page safely', () => {
    const items: CanonicalInvoiceItem[] = Array.from({ length: 20 }, (_, i) => blankItem(i + 1));
    const chunks = calculateInvoicePageChunks(items, a4Portrait);
    expect(chunks.length === 1, `Expected 1 page for empty invoice, got ${chunks.length}`);
    expect(chunks[0].length === 1, 'Fallback retains single row placeholder on 1 page');
  });

  // Test Suite 3: Multi-Page Pagination Behavior
  test('Multi-Page Pagination', 'Invoice with 20 populated items correctly paginates across 2 pages', () => {
    const items: CanonicalInvoiceItem[] = Array.from({ length: 20 }, (_, i) =>
      populatedItem(i + 1, `Hardware Component ${i + 1}`, 2, 1200)
    );

    const chunks = calculateInvoicePageChunks(items, a4Portrait);
    expect(chunks.length === 2, `Expected 2 pages for 20 populated items, got ${chunks.length}`);
    expect(chunks[0].length === 18, `Page 1 should have 18 items, got ${chunks[0].length}`);
    expect(chunks[1].length === 2, `Page 2 should have 2 items (with room for totals), got ${chunks[1].length}`);
  });

  test('Multi-Page Pagination', 'Invoice with 17 populated items correctly splits to 2 pages leaving room for totals', () => {
    const items: CanonicalInvoiceItem[] = Array.from({ length: 17 }, (_, i) =>
      populatedItem(i + 1, `License ${i + 1}`, 1, 3000)
    );

    const chunks = calculateInvoicePageChunks(items, a4Portrait);
    expect(chunks.length === 2, `Expected 2 pages for 17 items (exceeds single-page 16), got ${chunks.length}`);
    expect(chunks[0].length === 16, `Page 1 has 16 items, got ${chunks[0].length}`);
    expect(chunks[1].length === 1, `Page 2 has 1 item, got ${chunks[1].length}`);
  });

  test('Multi-Page Pagination', 'Supports A5 portrait paper configuration with proper capacities', () => {
    // A5 single page capacity is 9
    const oneItem = [populatedItem(1), ...Array.from({ length: 19 }, (_, i) => blankItem(i + 2))];
    const chunkOne = calculateInvoicePageChunks(oneItem, a5Portrait);
    expect(chunkOne.length === 1, '1 item on A5 renders as 1 page');

    const twelveItems = Array.from({ length: 12 }, (_, i) => populatedItem(i + 1));
    const chunkTwelve = calculateInvoicePageChunks(twelveItems, a5Portrait);
    expect(chunkTwelve.length === 2, '12 items on A5 paginates to 2 pages');
  });

  test('Multi-Page Pagination', 'Supports A4 landscape paper configuration with proper capacities', () => {
    // A4 landscape single page capacity is 8
    const oneItem = [populatedItem(1), ...Array.from({ length: 19 }, (_, i) => blankItem(i + 2))];
    const chunkOne = calculateInvoicePageChunks(oneItem, a4Landscape);
    expect(chunkOne.length === 1, '1 item on landscape renders as 1 page');

    const tenItems = Array.from({ length: 10 }, (_, i) => populatedItem(i + 1));
    const chunkTen = calculateInvoicePageChunks(tenItems, a4Landscape);
    expect(chunkTen.length === 2, '10 items on landscape paginates to 2 pages');
  });

  const suites = Array.from(new Set(results.map((r) => r.suite)));
  console.log('===============================================================');
  console.log('       INVOICE TEMPLATE PAGINATION TEST RESULTS                ');
  console.log('===============================================================');

  let totalPassed = 0;
  let totalFailed = 0;

  for (const s of suites) {
    const suiteResults = results.filter((r) => r.suite === s);
    const suitePassed = suiteResults.filter((r) => r.passed).length;
    const suiteTotal = suiteResults.length;
    const allPassed = suitePassed === suiteTotal;

    console.log(`[${allPassed ? '✓ PASS' : '✗ FAIL'}] ${s} (${suitePassed}/${suiteTotal} passed)`);
    for (const r of suiteResults) {
      if (r.passed) {
        console.log(`  ✓ ${r.name}`);
        totalPassed++;
      } else {
        console.log(`  ✗ ${r.name}: ${r.error}`);
        totalFailed++;
      }
    }
  }

  console.log('---------------------------------------------------------------');
  console.log(`TOTAL: ${totalPassed}/${results.length} Tests Passed`);
  console.log(`OVERALL STATUS: ${totalFailed === 0 ? 'ALL TESTS PASSED' : 'SOME TESTS FAILED'}`);
  console.log('===============================================================');

  return { total: results.length, passed: totalPassed, failed: totalFailed };
}

if (import.meta.url === `file://${process.argv[1]}`) {
  const summary = runInvoiceTemplatePaginationTests();
  process.exit(summary.failed === 0 ? 0 : 1);
}
