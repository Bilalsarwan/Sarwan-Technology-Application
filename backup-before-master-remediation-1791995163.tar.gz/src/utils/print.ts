import React from 'react';
import { createRoot, Root } from 'react-dom/client';
import { Invoice, Payment, BusinessSettings, UserProfile } from '../types';
import { CanonicalInvoiceDocumentModel } from '../types/canonicalInvoiceDocument';
import { buildCanonicalInvoiceDocument } from './canonicalInvoiceDocument';
import { CanonicalInvoiceDocument, InvoiceRenderer } from '../components/invoice/CanonicalInvoiceDocument';

// Concurrency lock & active handle for PDF export
let isPdfExportActive = false;
let activePdfRoot: Root | null = null;

export interface InvoicePrintOptions {
  payments?: Payment[];
  settings?: Partial<BusinessSettings>;
  userProfile?: UserProfile | null;
  totalPaidOverride?: number;
  filename?: string;
  imageTimeoutMs?: number;
}

export type InvoicePrintInput =
  | CanonicalInvoiceDocumentModel
  | Invoice
  | {
      invoice: Invoice;
      payments?: Payment[];
      settings?: Partial<BusinessSettings>;
      userProfile?: UserProfile | null;
      totalPaidOverride?: number;
      filename?: string;
    };

/**
 * Resolves any invoice input format into the authoritative CanonicalInvoiceDocumentModel.
 */
export function resolveCanonicalDocument(
  input: InvoicePrintInput,
  options?: InvoicePrintOptions
): CanonicalInvoiceDocumentModel {
  // If already a canonical document model
  if ('paperConfig' in input && 'items' in input && 'company' in input) {
    return input as CanonicalInvoiceDocumentModel;
  }

  // If object with wrapped invoice
  if ('invoice' in input) {
    return buildCanonicalInvoiceDocument({
      invoice: input.invoice,
      payments: input.payments || options?.payments,
      settings: input.settings || options?.settings,
      userProfile: input.userProfile ?? options?.userProfile,
      totalPaidOverride: input.totalPaidOverride ?? options?.totalPaidOverride,
    });
  }

  // If raw Invoice object
  return buildCanonicalInvoiceDocument({
    invoice: input as Invoice,
    payments: options?.payments,
    settings: options?.settings,
    userProfile: options?.userProfile,
    totalPaidOverride: options?.totalPaidOverride,
  });
}

/**
 * Generates a clean, filesystem-safe, descriptive filename for invoice PDF downloads.
 * Example: "Sarwan-Technology-Invoice-ST-1001.pdf"
 */
export function generateInvoiceFilename(
  input: InvoicePrintInput,
  customFilename?: string
): string {
  if (customFilename && typeof customFilename === 'string' && customFilename.trim()) {
    let clean = customFilename.trim().replace(/[^a-zA-Z0-9_\-\.]/g, '-').replace(/-+/g, '-');
    clean = clean.replace(/^-|-$/g, '');
    if (!clean.toLowerCase().endsWith('.pdf')) {
      clean += '.pdf';
    }
    return clean || 'Sarwan-Technology-Invoice.pdf';
  }

  const doc = resolveCanonicalDocument(input);

  const rawCompany = (doc.company.companyName || 'Sarwan-Technology')
    .replace(/[^a-zA-Z0-9_-]/g, '-')
    .replace(/-+/g, '-');

  const rawBillNo = (doc.billNumber && doc.billNumber !== '—' ? doc.billNumber : 'Draft')
    .replace(/[^a-zA-Z0-9_-]/g, '-')
    .replace(/-+/g, '-');

  const cleanCompany = rawCompany.replace(/^-|-$/g, '') || 'Sarwan-Technology';
  const cleanBill = rawBillNo.replace(/^-|-$/g, '') || 'Invoice';

  return `${cleanCompany}-Invoice-${cleanBill}.pdf`;
}

/**
 * Ensures all required Google fonts and web fonts are fully loaded, parsed, and ready
 * before rasterization to prevent character overlap or font metric shifts.
 */
export async function ensureAllFontsLoaded(timeoutMs = 3500): Promise<void> {
  if (typeof document === 'undefined' || !document.fonts) return;

  try {
    // 1. Wait for document.fonts.ready
    await Promise.race([
      document.fonts.ready,
      new Promise((resolve) => setTimeout(resolve, timeoutMs)),
    ]);

    // 2. Explicitly load critical font weights used across the invoice document
    const criticalFontDescriptors = [
      '400 11.5px Inter, system-ui, sans-serif',
      '500 11.5px Inter, system-ui, sans-serif',
      '600 11.5px Inter, system-ui, sans-serif',
      '700 11.5px Inter, system-ui, sans-serif',
      '800 24px Inter, system-ui, sans-serif',
      '800 32px Inter, system-ui, sans-serif',
      '400 12px Roboto, sans-serif',
      '700 12px Roboto, sans-serif',
      '400 12px Poppins, sans-serif',
      '700 12px Poppins, sans-serif',
      '400 12px Montserrat, sans-serif',
      '700 12px Montserrat, sans-serif',
      '400 12px Outfit, sans-serif',
      '700 12px Outfit, sans-serif',
      '400 12px Lato, sans-serif',
      '700 12px Lato, sans-serif',
      '400 12px "Playfair Display", serif',
      '700 12px "Playfair Display", serif',
      '400 20px "Scheherazade New", Arial, sans-serif',
      '700 20px "Scheherazade New", Arial, sans-serif',
      '400 18px "Amiri", Arial, sans-serif',
      '700 18px "Amiri", Arial, sans-serif',
      '400 20px "Noto Naskh Arabic", Arial, sans-serif',
      '700 20px "Noto Naskh Arabic", Arial, sans-serif',
    ];

    await Promise.race([
      Promise.allSettled(criticalFontDescriptors.map((desc) => document.fonts.load(desc))),
      new Promise((resolve) => setTimeout(resolve, timeoutMs)),
    ]);

    // 3. Final document.fonts.ready check
    await Promise.race([
      document.fonts.ready,
      new Promise((resolve) => setTimeout(resolve, 1500)),
    ]);
  } catch (err) {
    console.warn('[PDF Font Loader] Font readiness warning:', err);
  }
}

/**
 * Checks if an element or any of its ancestors has a CSS transform, zoom, or scaling applied.
 * CSS transforms (such as preview zoom: scale(0.75)) are display-only and must not affect native print geometry.
 */
export function hasTransformedAncestor(element: HTMLElement): boolean {
  if (typeof window === 'undefined') return false;
  let curr: HTMLElement | null = element;
  while (curr && curr !== document.body && curr !== document.documentElement) {
    try {
      const style = window.getComputedStyle(curr);
      const transform = style.transform;
      const zoom = (style as any).zoom;
      if (transform && transform !== 'none') return true;
      if (zoom && zoom !== '1' && zoom !== 'normal') return true;
    } catch {
      // ignore
    }
    curr = curr.parentElement;
  }
  return false;
}

/**
 * Forces a complete layout/reflow and waits for stable animation frames so that
 * all font metrics, column widths, and line wraps are 100% computed by the browser
 * before native print preview opens.
 */
export async function forceLayoutAndStabilize(element: HTMLElement): Promise<DOMRect> {
  // 1. Trigger initial synchronous reflow
  void element.offsetHeight;
  void element.offsetWidth;

  // 2. Wait two animation frames so the browser layout engine and font shaper stabilize
  if (typeof window !== 'undefined' && typeof window.requestAnimationFrame === 'function') {
    await new Promise<void>((resolve) => {
      requestAnimationFrame(() => {
        requestAnimationFrame(() => {
          resolve();
        });
      });
    });
  } else {
    await new Promise((resolve) => setTimeout(resolve, 50));
  }

  // 3. Re-trigger reflow and return final stable bounding rect
  void element.offsetHeight;
  return element.getBoundingClientRect();
}

/**
 * Ensures all web fonts and images (company logos, secondary logos, QR codes, stamps)
 * within a container are fully loaded and decoded before triggering PDF capture.
 */
export async function waitForImagesReady(
  container: HTMLElement,
  timeoutMs = 4000
): Promise<void> {
  // 1. Comprehensive font readiness check
  await ensureAllFontsLoaded(timeoutMs);

  // 2. Images readiness check (logos, stamps, QR codes)
  const images = Array.from(container.querySelectorAll('img'));
  if (images.length === 0) return;

  const imagePromises = images.map((img) => {
    return new Promise<void>(async (resolve) => {
      // Force eager loading if browser set to lazy
      if (img.loading === 'lazy') {
        img.loading = 'eager';
      }

      // Check if already loaded
      if (img.complete && img.naturalHeight !== 0) {
        if (typeof img.decode === 'function') {
          try {
            await img.decode();
          } catch {
            // Safe fallback
          }
        }
        resolve();
        return;
      }

      const timer = setTimeout(() => resolve(), timeoutMs);

      img.onload = async () => {
        clearTimeout(timer);
        if (typeof img.decode === 'function') {
          try {
            await img.decode();
          } catch {
            // Safe fallback
          }
        }
        resolve();
      };

      img.onerror = () => {
        clearTimeout(timer);
        resolve();
      };
    });
  });

  await Promise.race([
    Promise.all(imagePromises),
    new Promise((resolve) => setTimeout(resolve, timeoutMs)),
  ]);
}

/**
 * Verification report detailing the structural integrity and parity of a rendered Canonical Invoice Document.
 */
export interface CanonicalInvoiceVerificationReport {
  isValid: boolean;
  totalElementCount: number;
  expectedMinElements: number;
  pdfByteSize?: number;
  expectedMinByteSize?: number;
  foundSections: string[];
  missingSections: string[];
  foundHeaderComponents: string[];
  missingHeaderComponents: string[];
  deviations: string[];
  summary: string;
}

/**
 * Programmatically verifies the PDF content / rendered invoice document by running a check
 * that ensures the rendered PDF document includes the expected header components and the correct
 * section IDs present in the 'CanonicalInvoiceDocument'. Reports if the generated PDF size or
 * element count deviates from the expected configuration.
 */
export function verifyCanonicalInvoiceDocumentStructure(
  rootElementOrDoc: HTMLElement | Document = document,
  pdfByteSize?: number
): CanonicalInvoiceVerificationReport {
  const expectedSections = [
    'invoice-header-section',
    'invoice-title-meta-section',
    'invoice-customer-section',
    'invoice-items-table-section',
    'invoice-payment-totals-section',
    'invoice-notes-section',
    'invoice-signatures-section',
    'invoice-footer-section',
  ];

  const expectedHeaderComponents = [
    'invoice-header-logo-1',
    'invoice-header-company-name',
    'invoice-header-pashto-name',
    'invoice-header-slogan',
    'invoice-header-logo-2',
  ];

  const foundSections: string[] = [];
  const missingSections: string[] = [];

  for (const secId of expectedSections) {
    if (rootElementOrDoc.querySelector(`#${secId}`)) {
      foundSections.push(secId);
    } else {
      missingSections.push(secId);
    }
  }

  const foundHeaderComponents: string[] = [];
  const missingHeaderComponents: string[] = [];

  for (const compId of expectedHeaderComponents) {
    if (rootElementOrDoc.querySelector(`#${compId}`)) {
      foundHeaderComponents.push(compId);
    } else {
      missingHeaderComponents.push(compId);
    }
  }

  const allElements = rootElementOrDoc.querySelectorAll('*');
  const totalElementCount = allElements.length;
  const expectedMinElements = 15;
  const expectedMinByteSize = 3000;

  const deviations: string[] = [];
  if (missingSections.length > 0) {
    deviations.push(`Missing section IDs: ${missingSections.join(', ')}`);
  }
  if (missingHeaderComponents.length > 0) {
    deviations.push(`Missing header components: ${missingHeaderComponents.join(', ')}`);
  }
  if (totalElementCount < expectedMinElements) {
    deviations.push(`Element count (${totalElementCount}) deviates from expected minimum (${expectedMinElements})`);
  }
  if (pdfByteSize !== undefined && pdfByteSize < expectedMinByteSize) {
    deviations.push(`PDF size (${pdfByteSize} B) deviates from expected minimum (${expectedMinByteSize} B)`);
  }

  const isValid = deviations.length === 0;
  const summary = isValid
    ? `Canonical Invoice Document verified successfully (${foundSections.length} sections, ${foundHeaderComponents.length} header components, ${totalElementCount} elements)`
    : `Canonical Invoice Document structure deviation detected: ${deviations.join('; ')}`;

  if (!isValid) {
    console.warn(`[PDF Verification Warning] Generated PDF document deviates from expected configuration:`, {
      isValid,
      totalElementCount,
      expectedMinElements,
      pdfByteSize,
      deviations,
      missingSections,
      missingHeaderComponents,
    });
  } else {
    console.log(`[PDF Verification Success] Generated PDF strictly matches CanonicalInvoiceDocument:`, {
      isValid,
      totalElementCount,
      pdfByteSize,
      foundSections,
      foundHeaderComponents,
    });
  }

  return {
    isValid,
    totalElementCount,
    expectedMinElements,
    pdfByteSize,
    expectedMinByteSize,
    foundSections,
    missingSections,
    foundHeaderComponents,
    missingHeaderComponents,
    deviations,
    summary,
  };
}

// State tracking currently prepared document
let preparedCanonicalDoc: CanonicalInvoiceDocumentModel | null = null;
let isPrintDocumentPrepared = false;

/**
 * Prepares the canonical invoice document inside #invoice-print-root BEFORE the user clicks print.
 *
 * Runs asynchronous operations while the modal or preview is open:
 * 1. Mounts CanonicalInvoiceDocument into #invoice-print-root.
 * 2. Waits for React render commit.
 * 3. Waits for all fonts (document.fonts.ready).
 * 4. Waits for all images/logos to decode.
 * 5. Stabilizes browser layout.
 * 6. Marks the print document as ready.
 */
export async function prepareInvoicePrintDocument(
  input: InvoicePrintInput,
  options?: InvoicePrintOptions
): Promise<CanonicalInvoiceDocumentModel> {
  const doc = resolveCanonicalDocument(input, options);

  let printRoot: HTMLDivElement | null = null;
  if (typeof document !== 'undefined') {
    printRoot = document.getElementById('invoice-print-root') as HTMLDivElement | null;
    if (!printRoot) {
      printRoot = document.createElement('div');
      printRoot.id = 'invoice-print-root';
      document.body.appendChild(printRoot);
    }
  }

  if (printRoot) {
    if (!activePdfRoot) {
      activePdfRoot = createRoot(printRoot);
    }

    await new Promise<void>((resolve) => {
      activePdfRoot!.render(
        React.createElement(CanonicalInvoiceDocument, {
          document: doc,
          id: 'invoice-print-document',
        })
      );
      const startTime = Date.now();
      const check = () => {
        if (printRoot?.querySelector('.canonical-invoice-sheet')) {
          resolve();
        } else if (Date.now() - startTime > 1200) {
          resolve();
        } else {
          requestAnimationFrame(check);
        }
      };
      requestAnimationFrame(check);
    });

    await ensureAllFontsLoaded();
    await waitForImagesReady(printRoot, options?.imageTimeoutMs || 3500);
    await forceLayoutAndStabilize(printRoot);

    try {
      verifyCanonicalInvoiceDocumentStructure(printRoot);
    } catch {
      // Non-critical verification
    }
  }

  preparedCanonicalDoc = doc;
  isPrintDocumentPrepared = true;
  return doc;
}

/**
 * Safely detects whether the application is running inside an embedded or sandboxed iframe
 * (e.g. Google AI Studio Preview) without throwing cross-origin security exceptions.
 */
export function isEmbeddedContext(): boolean {
  if (typeof window === 'undefined') return false;
  try {
    return window.self !== window.top;
  } catch {
    // Cross-origin access to window.top throws a SecurityError, which confirms an embedded iframe
    return true;
  }
}

/**
 * Renders and prints the canonical invoice inside a dedicated top-level print window/tab.
 *
 * Copies required stylesheets, Google fonts, and injects exact A4 print rules.
 * Clones the pre-rendered CanonicalInvoiceDocument DOM to preserve 100% design fidelity.
 * Waits for fonts, images, and layout stabilization before triggering printWindow.print().
 */
async function printInDedicatedWindow(
  printWindow: Window,
  customFilename?: string
): Promise<boolean> {
  const doc = preparedCanonicalDoc;
  const cleanFilename = doc ? generateInvoiceFilename(doc, customFilename) : 'Sarwan-Technology-Invoice.pdf';
  const printTitle = cleanFilename.replace(/\.pdf$/i, '');

  const escapedTitle = printTitle
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');

  const baseHref = typeof document !== 'undefined' ? document.baseURI : '';

  // 1. Write the initial document structure
  printWindow.document.open();
  printWindow.document.write(`<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <base href="${baseHref}">
  <title>${escapedTitle}</title>
</head>
<body style="margin: 0; padding: 0; background: #ffffff;">
</body>
</html>`);
  printWindow.document.close();

  // Set document title explicitly
  printWindow.document.title = printTitle;

  // 2. Copy all stylesheet links, preconnect links, and style elements from the current document
  if (typeof document !== 'undefined') {
    const styleElements = document.querySelectorAll('link[rel="stylesheet"], link[rel="preconnect"], style');
    styleElements.forEach((el) => {
      try {
        printWindow.document.head.appendChild(el.cloneNode(true));
      } catch (err) {
        console.warn('[Invoice Print] Failed to copy style element:', err);
      }
    });
  }

  // 3. Inject dedicated A4 print rules into the top-level print window
  const printStyle = printWindow.document.createElement('style');
  printStyle.id = 'dedicated-invoice-print-styles';
  printStyle.textContent = `
    @page {
      size: A4 portrait;
      margin: 0;
    }
    html, body {
      margin: 0 !important;
      padding: 0 !important;
      width: 210mm !important;
      min-height: 297mm !important;
      background: #ffffff !important;
      -webkit-print-color-adjust: exact !important;
      print-color-adjust: exact !important;
      color-adjust: exact !important;
    }
    #invoice-print-root {
      display: block !important;
      visibility: visible !important;
      position: static !important;
      width: 210mm !important;
      height: auto !important;
      min-height: 297mm !important;
      margin: 0 auto !important;
      padding: 0 !important;
      background: #ffffff !important;
      opacity: 1 !important;
      overflow: visible !important;
      pointer-events: auto !important;
      z-index: auto !important;
    }
    #invoice-print-root * {
      visibility: visible !important;
    }
    .canonical-invoice-container {
      width: 210mm !important;
      min-width: 210mm !important;
      max-width: 210mm !important;
      margin: 0 auto !important;
      padding: 0 !important;
      box-sizing: border-box !important;
      background: transparent !important;
      transform: none !important;
      zoom: normal !important;
    }
    .canonical-invoice-sheet {
      width: 210mm !important;
      min-width: 210mm !important;
      height: 297mm !important;
      margin: 0 auto !important;
      box-shadow: none !important;
      border: none !important;
      border-radius: 0 !important;
      box-sizing: border-box !important;
      overflow: visible !important;
      transform: none !important;
      zoom: normal !important;
      page-break-after: always;
      break-after: page;
      page-break-inside: avoid;
      break-inside: avoid;
    }
    .canonical-invoice-sheet:last-child {
      page-break-after: auto !important;
      break-after: auto !important;
    }
    @media print {
      .no-print {
        display: none !important;
      }
    }
  `;
  printWindow.document.head.appendChild(printStyle);

  // 4. Clone and insert canonical invoice DOM
  let sourceEl = typeof document !== 'undefined' ? document.getElementById('invoice-print-root') : null;
  if (!sourceEl || !sourceEl.querySelector('.canonical-invoice-sheet')) {
    sourceEl =
      document.getElementById('invoice-pdf-download-document') ||
      document.getElementById('invoice-detail-preview-document') ||
      sourceEl;
  }

  if (sourceEl) {
    const cloned = sourceEl.cloneNode(true) as HTMLElement;
    cloned.id = 'invoice-print-root';
    cloned.removeAttribute('aria-hidden');
    cloned.style.cssText =
      'display: block !important; visibility: visible !important; position: static !important; width: 210mm !important; margin: 0 auto !important; opacity: 1 !important; overflow: visible !important;';
    printWindow.document.body.appendChild(cloned);
  } else if (doc) {
    const container = printWindow.document.createElement('div');
    container.id = 'invoice-print-root';
    printWindow.document.body.appendChild(container);
    const winRoot = createRoot(container);
    winRoot.render(
      React.createElement(CanonicalInvoiceDocument, {
        document: doc,
        id: 'invoice-print-document',
      })
    );
    await new Promise<void>((resolve) => {
      const start = Date.now();
      const check = () => {
        if (container.querySelector('.canonical-invoice-sheet') || Date.now() - start > 1200) {
          resolve();
        } else {
          requestAnimationFrame(check);
        }
      };
      requestAnimationFrame(check);
    });
  }

  // 5. Add a clean, unobtrusive top action bar visible on screen but excluded from print
  const topBar = printWindow.document.createElement('div');
  topBar.className = 'no-print';
  topBar.style.cssText =
    'display: flex; align-items: center; justify-content: space-between; padding: 10px 20px; background: #171717; color: #ffffff; font-family: system-ui, -apple-system, sans-serif; font-size: 13px; border-bottom: 1px solid #333333; position: sticky; top: 0; z-index: 99999;';

  const titleSpan = printWindow.document.createElement('span');
  titleSpan.textContent = `Invoice Print Document: ${printTitle}`;
  titleSpan.style.fontWeight = '600';

  const btnGroup = printWindow.document.createElement('div');
  btnGroup.style.cssText = 'display: flex; gap: 8px;';

  const printAgainBtn = printWindow.document.createElement('button');
  printAgainBtn.textContent = 'Print / Save as PDF';
  printAgainBtn.style.cssText =
    'background: #f97316; color: #ffffff; border: none; padding: 6px 14px; border-radius: 6px; font-weight: 700; cursor: pointer; font-size: 12px;';
  printAgainBtn.onclick = () => printWindow.print();

  const closeBtn = printWindow.document.createElement('button');
  closeBtn.textContent = 'Close';
  closeBtn.style.cssText =
    'background: #333333; color: #ffffff; border: 1px solid #555555; padding: 6px 12px; border-radius: 6px; cursor: pointer; font-size: 12px;';
  closeBtn.onclick = () => printWindow.close();

  btnGroup.appendChild(printAgainBtn);
  btnGroup.appendChild(closeBtn);
  topBar.appendChild(titleSpan);
  topBar.appendChild(btnGroup);

  printWindow.document.body.insertBefore(topBar, printWindow.document.body.firstChild);

  // 6. Wait for fonts in print window
  if (printWindow.document.fonts && printWindow.document.fonts.ready) {
    try {
      await printWindow.document.fonts.ready;
    } catch (e) {
      console.warn('[Invoice Print] Font load warning in print window:', e);
    }
  }

  // 7. Wait for all images/logos to load/decode in print window
  const images = Array.from(printWindow.document.images);
  if (images.length > 0) {
    await Promise.all(
      images.map((img) => {
        if (img.complete && img.naturalWidth > 0) return Promise.resolve();
        return new Promise<void>((resolve) => {
          const timeout = setTimeout(resolve, 3000);
          img.onload = () => {
            clearTimeout(timeout);
            resolve();
          };
          img.onerror = () => {
            clearTimeout(timeout);
            resolve();
          };
        });
      })
    );
  }

  // 8. Stabilize layout before print
  await new Promise((resolve) => requestAnimationFrame(() => setTimeout(resolve, 100)));

  // 9. Focus and trigger native print in the top-level print window
  printWindow.focus();

  let hasFinished = false;
  const cleanup = () => {
    if (hasFinished) return;
    hasFinished = true;
    try {
      printWindow.close();
    } catch {}
  };

  printWindow.addEventListener('afterprint', cleanup);

  try {
    printWindow.print();
  } catch (err) {
    console.error('[Invoice Print] printWindow.print() error:', err);
    throw err;
  }

  return true;
}

/**
 * Renders and prints the canonical A4 Payment Receipt inside a dedicated top-level print window/tab.
 * Follows the exact same proven architecture as Invoice Print (synchronous user activation, iframe independence,
 * styles copying, font loading, image loading, A4 one-page print styling, cleanup).
 * Guaranteed to fit completely on ONE single A4 page.
 */
export async function printReceiptInDedicatedWindow(
  printWindow: Window,
  receiptElement: HTMLElement,
  customTitle?: string
): Promise<boolean> {
  const printTitle = customTitle || 'Sarwan-Technology-Payment-Receipt';
  const escapedTitle = printTitle
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');

  const baseHref = typeof document !== 'undefined' ? document.baseURI : '';

  // 1. Write initial document structure
  printWindow.document.open();
  printWindow.document.write(`<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <base href="${baseHref}">
  <title>${escapedTitle}</title>
</head>
<body style="margin: 0; padding: 0; background: #ffffff;">
</body>
</html>`);
  printWindow.document.close();

  printWindow.document.title = printTitle;

  // 2. Copy all stylesheet links, preconnect links, and style elements from the current document
  if (typeof document !== 'undefined') {
    const styleElements = document.querySelectorAll('link[rel="stylesheet"], link[rel="preconnect"], style');
    styleElements.forEach((el) => {
      try {
        printWindow.document.head.appendChild(el.cloneNode(true));
      } catch (err) {
        console.warn('[Receipt Print] Failed to copy style element:', err);
      }
    });
  }

  // 3. Inject dedicated A4 single-page print rules into the print window
  const printStyle = printWindow.document.createElement('style');
  printStyle.id = 'dedicated-receipt-print-styles';
  printStyle.textContent = `
    @page {
      size: A4 portrait;
      margin: 0;
    }
    html, body {
      margin: 0 !important;
      padding: 0 !important;
      width: 210mm !important;
      height: 297mm !important;
      max-height: 297mm !important;
      background: #ffffff !important;
      -webkit-print-color-adjust: exact !important;
      print-color-adjust: exact !important;
      color-adjust: exact !important;
      font-family: system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
      overflow: hidden !important;
    }
    #receipt-print-root, #payment-receipt-document {
      display: flex !important;
      flex-direction: column !important;
      justify-content: space-between !important;
      visibility: visible !important;
      position: static !important;
      width: 210mm !important;
      max-width: 210mm !important;
      height: 297mm !important;
      max-height: 297mm !important;
      min-height: 297mm !important;
      margin: 0 auto !important;
      padding: 14mm 16mm !important;
      background: #ffffff !important;
      box-shadow: none !important;
      border: none !important;
      border-radius: 0 !important;
      box-sizing: border-box !important;
      transform: none !important;
      page-break-inside: avoid !important;
      break-inside: avoid !important;
      page-break-after: avoid !important;
      break-after: avoid !important;
      overflow: hidden !important;
    }
    #receipt-print-root *, #payment-receipt-document * {
      visibility: visible !important;
    }
    @media print {
      .no-print {
        display: none !important;
      }
    }
  `;
  printWindow.document.head.appendChild(printStyle);

  // 4. Clone and insert canonical receipt DOM
  const cloned = receiptElement.cloneNode(true) as HTMLElement;
  cloned.id = 'payment-receipt-document';
  cloned.removeAttribute('aria-hidden');
  cloned.style.cssText =
    'display: flex !important; flex-direction: column !important; justify-content: space-between !important; visibility: visible !important; position: static !important; width: 210mm !important; max-width: 210mm !important; height: 297mm !important; max-height: 297mm !important; min-height: 297mm !important; margin: 0 auto !important; padding: 14mm 16mm !important; border: none !important; box-shadow: none !important; transform: none !important; background: #ffffff !important; box-sizing: border-box !important; page-break-inside: avoid !important; break-inside: avoid !important; page-break-after: avoid !important; break-after: avoid !important; overflow: hidden !important;';

  const container = printWindow.document.createElement('div');
  container.id = 'receipt-print-root';
  container.appendChild(cloned);
  printWindow.document.body.appendChild(container);

  // 5. Add clean top action bar visible on screen but excluded from print
  const topBar = printWindow.document.createElement('div');
  topBar.className = 'no-print';
  topBar.style.cssText =
    'display: flex; align-items: center; justify-content: space-between; padding: 10px 16px; background: #171717; color: #ffffff; font-family: system-ui, -apple-system, sans-serif; font-size: 13px; border-bottom: 1px solid #333333; position: sticky; top: 0; z-index: 99999;';

  const titleSpan = printWindow.document.createElement('span');
  titleSpan.textContent = `A4 Payment Receipt: ${printTitle}`;
  titleSpan.style.fontWeight = '600';

  const btnGroup = printWindow.document.createElement('div');
  btnGroup.style.cssText = 'display: flex; gap: 8px;';

  const printAgainBtn = printWindow.document.createElement('button');
  printAgainBtn.textContent = 'Print / Save as PDF';
  printAgainBtn.style.cssText =
    'background: #f97316; color: #ffffff; border: none; padding: 6px 14px; border-radius: 6px; font-weight: 700; cursor: pointer; font-size: 12px;';
  printAgainBtn.onclick = () => printWindow.print();

  const closeBtn = printWindow.document.createElement('button');
  closeBtn.textContent = 'Close';
  closeBtn.style.cssText =
    'background: #333333; color: #ffffff; border: 1px solid #555555; padding: 6px 12px; border-radius: 6px; cursor: pointer; font-size: 12px;';
  closeBtn.onclick = () => printWindow.close();

  btnGroup.appendChild(printAgainBtn);
  btnGroup.appendChild(closeBtn);
  topBar.appendChild(titleSpan);
  topBar.appendChild(btnGroup);

  printWindow.document.body.insertBefore(topBar, printWindow.document.body.firstChild);

  // 6. Wait for fonts in print window
  if (printWindow.document.fonts && printWindow.document.fonts.ready) {
    try {
      await printWindow.document.fonts.ready;
    } catch (e) {
      console.warn('[Receipt Print] Font load warning in print window:', e);
    }
  }

  // 7. Wait for all images/logos to load/decode in print window
  const images = Array.from(printWindow.document.images);
  if (images.length > 0) {
    await Promise.all(
      images.map((img) => {
        if (img.complete && img.naturalWidth > 0) return Promise.resolve();
        return new Promise<void>((resolve) => {
          const timeout = setTimeout(resolve, 3000);
          img.onload = () => {
            clearTimeout(timeout);
            resolve();
          };
          img.onerror = () => {
            clearTimeout(timeout);
            resolve();
          };
        });
      })
    );
  }

  // 8. Stabilize layout before print
  await new Promise((resolve) => requestAnimationFrame(() => setTimeout(resolve, 100)));

  // 9. Focus and trigger native print in the top-level print window
  printWindow.focus();

  let hasFinished = false;
  const cleanup = () => {
    if (hasFinished) return;
    hasFinished = true;
    try {
      printWindow.close();
    } catch {}
  };

  printWindow.addEventListener('afterprint', cleanup);

  try {
    printWindow.print();
  } catch (err) {
    console.error('[Receipt Print] printWindow.print() error:', err);
    throw err;
  }

  return true;
}

/**
 * Triggers native printing in the current window when running as a top-level document.
 */
function printInCurrentWindow(customFilename?: string): boolean {
  if (typeof window === 'undefined') return false;

  const doc = preparedCanonicalDoc;
  const cleanFilename = doc ? generateInvoiceFilename(doc, customFilename) : 'Sarwan-Technology-Invoice.pdf';
  const printTitle = cleanFilename.replace(/\.pdf$/i, '');
  const prevTitle = typeof document !== 'undefined' ? document.title : '';

  // Synchronously update document.title immediately before window.print()
  if (typeof document !== 'undefined') {
    document.title = printTitle;
  }

  let restored = false;
  const restoreTitle = () => {
    if (!restored && typeof document !== 'undefined') {
      restored = true;
      document.title = prevTitle;
    }
  };

  const handleAfterPrint = () => {
    restoreTitle();
    window.removeEventListener('afterprint', handleAfterPrint);
  };
  window.addEventListener('afterprint', handleAfterPrint);

  // Synchronous browser print invocation with active user gesture
  window.print();

  setTimeout(restoreTitle, 5000);
  return true;
}

/**
 * Triggers native browser printing for the already prepared invoice document.
 *
 * Automatically detects whether the application is running inside an embedded or sandboxed iframe
 * (e.g. Google AI Studio Preview).
 *
 * When embedded:
 * - Synchronously opens a dedicated top-level print window directly from the user click gesture
 *   turn to preserve browser activation and prevent popup blocking.
 * - Writes the canonical invoice and required styles into the top-level print window.
 * - Invokes native printWindow.print().
 *
 * When top-level:
 * - Directly invokes native window.print() in the current window.
 */
export async function printPreparedInvoice(customFilename?: string): Promise<boolean> {
  if (typeof window === 'undefined') return false;

  const isEmbedded = isEmbeddedContext();
  const printRoot = typeof document !== 'undefined' ? document.getElementById('invoice-print-root') : null;
  const printReady = isInvoicePrintReady();

  // Print diagnostics as required by system architecture
  console.log('[Invoice Print]', {
    isEmbedded,
    hasPrintRoot: Boolean(printRoot),
    printReady,
    userActivation:
      typeof navigator !== 'undefined'
        ? (navigator as any).userActivation?.isActive
        : undefined,
  });

  if (isEmbedded) {
    console.log('[Invoice Print] Using top-level print window');

    // SYNCHRONOUS window.open inside the click gesture turn (ZERO awaits before this call)
    let printWindow: Window | null = null;
    try {
      printWindow = window.open('', '_blank');
    } catch (err) {
      console.error('[Invoice Print] window.open exception:', err);
    }

    if (!printWindow) {
      throw new Error(
        'Your browser blocked the print window. Please allow pop-ups for this site and try again.'
      );
    }

    // Populate and print in the newly created top-level window
    return await printInDedicatedWindow(printWindow, customFilename);
  } else {
    console.log('[Invoice Print] Using native current-window print');
    return printInCurrentWindow(customFilename);
  }
}

/**
 * Checks if the canonical invoice document is currently prepared in #invoice-print-root.
 */
export function isInvoicePrintReady(): boolean {
  return isPrintDocumentPrepared;
}

/**
 * Convenience method that prepares and then prints the invoice.
 * Note: When called directly from a click event, prefer calling prepareInvoicePrintDocument()
 * when the modal/view opens and printPreparedInvoice() on click for guaranteed user activation.
 */
export async function downloadInvoicePdf(
  input: InvoicePrintInput,
  filenameOrOptions?: string | InvoicePrintOptions
): Promise<void> {
  if (isPdfExportActive) {
    console.warn('PDF print already in progress. Ignoring duplicate request.');
    return;
  }
  isPdfExportActive = true;

  const options: InvoicePrintOptions =
    typeof filenameOrOptions === 'string'
      ? { filename: filenameOrOptions }
      : filenameOrOptions || {};

  try {
    await prepareInvoicePrintDocument(input, options);
    await printPreparedInvoice(options.filename);
  } finally {
    isPdfExportActive = false;
  }
}

/**
 * Semantic alias for downloadInvoicePdf using the browser-native print engine.
 */
export const printInvoice = downloadInvoicePdf;

/**
 * Returns whether a PDF export operation is currently running.
 */
export function isInvoiceActionInProgress(): boolean {
  return isPdfExportActive;
}
