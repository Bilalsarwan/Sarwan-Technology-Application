/**
 * Verification Test Suite for Payment Receipt UI (Prompt Requirements 1-11)
 *
 * Verifies:
 * 1. Receipt belongs to the EXACT selected Payment (zero mock/stale/latest payment leakage)
 * 2. Header: Logo, Company Name, Contact Information, Title "PAYMENT RECEIPT", Receipt ID (Payment ID & Customer ID removed)
 * 3. Payment Information: Receipt ID, Date & Time, Status, Method, Collector (Payment ID & Customer ID removed)
 * 4. Customer Information: Name, Phone/Contact, Email, Address (no empty unnecessary fields, NO Customer ID)
 * 5. Invoice Information: Invoice Number, Total, Previously Paid, This Payment, Remaining Balance, Status
 * 6. Payment Summary: Prominent Amount Paid (AFN formatting, no $), Remaining Balance
 * 7. Notes: Displayed ONLY when payment.note is present; omitted when empty
 * 8. Footer: Company settings footer & thank you note
 * 9. Actions (UI Only): Print Receipt, Download Receipt, Close
 * 10. Responsive layout: Desktop, Tablet, Mobile widths & container scrolling
 * 11. Final verification with 10 varied payment & invoice configurations
 * 12. Security & Privacy: Receipt ID is displayed; Payment ID and Customer ID are NOT visible anywhere
 */

import React from 'react';
import { renderToStaticMarkup } from 'react-dom/server';
import { PaymentReceiptModal } from '../components/payment/PaymentReceiptModal';
import { Payment, Invoice, BusinessSettings } from '../types';
import { formatAFN, formatDate } from './format';

interface TestResult {
  name: string;
  passed: boolean;
  error?: string;
}

const results: TestResult[] = [];

function test(name: string, fn: () => void) {
  try {
    fn();
    results.push({ name, passed: true });
  } catch (err: any) {
    results.push({ name, passed: false, error: err?.message || String(err) });
  }
}

function expect(condition: boolean, msg: string) {
  if (!condition) throw new Error(msg);
}

const mockSettings: BusinessSettings = {
  companyName: 'Sarwan Technology',
  phone: '0731339014',
  whatsapp: '0778771020',
  email: 'info@sarwan.af',
  address: 'Kabul, Afghanistan',
  currency: 'AFN',
  invoiceNote: 'Thank you for your business.',
  footerText: 'Sarwan Technology • Security & Surveillance Systems',
} as BusinessSettings;

const samplePayment1: Payment = {
  id: 'ST-P-1025',
  invoiceId: 'INV-1025',
  billNumber: 'ST-1025',
  customerId: 'CUST-001',
  customerName: 'Ahmad Zadran',
  amount: 45000,
  method: 'CASH',
  date: '2026-10-06',
  time: '14:30',
  recordedBy: 'usr-admin-1',
  recordedByName: 'Ahmad Admin',
  note: 'First installment payment received in cash',
  createdAt: '2026-10-06T14:30:00Z',
};

const sampleInvoice1: Invoice = {
  id: 'INV-1025',
  billNumber: 'ST-1025',
  customerId: 'CUST-001',
  customerSnapshot: {
    id: 'CUST-001',
    name: 'Ahmad Zadran',
    companyName: 'Zadran Logistics',
    phone: '0700112233',
    email: 'ahmad@zadran.af',
    address: 'Kabul, District 4',
  },
  items: [],
  totalAmount: 100000,
  totalPaid: 75000,
  remaining: 25000,
  status: 'Partially Paid',
  date: '2026-10-01',
} as any;

export function runPaymentReceiptUITests() {
  console.log('===============================================================');
  console.log('          PAYMENT RECEIPT UI VERIFICATION TEST SUITE           ');
  console.log('===============================================================');

  // Test 1: Exact Selected Payment Rule
  test('1. Receipt belongs to the exact selected Payment record (ST-P-1025)', () => {
    const markup = renderToStaticMarkup(
      React.createElement(PaymentReceiptModal, {
        isOpen: true,
        onClose: () => {},
        payment: samplePayment1,
        invoice: sampleInvoice1,
        settings: mockSettings,
      })
    );

    expect(markup.includes('Ahmad Zadran'), 'Displays exact customer Ahmad Zadran');
    expect(markup.includes('ST-1025'), 'Displays exact bill number ST-1025');
    expect(!markup.includes('ST-P-9999'), 'Does NOT leak another payment');
    expect(!markup.includes('Receipt ID'), 'Does NOT display Receipt ID');
    expect(!markup.includes('Payment ID'), 'Does NOT display Payment ID');
    expect(!markup.includes('Customer ID'), 'Does NOT display Customer ID');
  });

  // Test 2: Header Structure
  test('2. Header displays Company Name, Contact info, and Title "PAYMENT RECEIPT"', () => {
    const markup = renderToStaticMarkup(
      React.createElement(PaymentReceiptModal, {
        isOpen: true,
        onClose: () => {},
        payment: samplePayment1,
        invoice: sampleInvoice1,
        settings: mockSettings,
      })
    );

    expect(markup.includes('PAYMENT RECEIPT'), 'Header contains title PAYMENT RECEIPT');
    expect(markup.includes('Sarwan Technology'), 'Header contains company name');
    expect(markup.includes('0731339014'), 'Header contains company phone');
    expect(markup.includes('0778771020'), 'Header contains company WhatsApp');
    expect(markup.includes('info@sarwan.af'), 'Header contains company email');
    expect(markup.includes('Kabul, Afghanistan'), 'Header contains company address');
  });

  // Test 3: Payment Information
  test('3. Payment Information displays Date & Time, Status, Method, and Collector', () => {
    const markup = renderToStaticMarkup(
      React.createElement(PaymentReceiptModal, {
        isOpen: true,
        onClose: () => {},
        payment: samplePayment1,
        invoice: sampleInvoice1,
        settings: mockSettings,
      })
    );

    expect(markup.includes('Payment Information'), 'Payment Information section exists');
    expect(markup.includes(formatDate('2026-10-06')), 'Displays formatted payment date');
    expect(markup.includes('Cash'), 'Displays Payment Method Cash');
    expect(markup.includes('Ahmad Admin'), 'Displays Collector Ahmad Admin');
    expect(markup.includes('Completed'), 'Displays Payment Status Completed');
  });

  // Test 4: Customer Information
  test('4. Customer Information displays Name, Contact, Email, Address without empty fields', () => {
    const markup = renderToStaticMarkup(
      React.createElement(PaymentReceiptModal, {
        isOpen: true,
        onClose: () => {},
        payment: samplePayment1,
        invoice: sampleInvoice1,
        settings: mockSettings,
      })
    );

    expect(markup.includes('Customer Information'), 'Customer Information section exists');
    expect(markup.includes('Ahmad Zadran'), 'Displays Customer Name');
    expect(markup.includes('0700112233'), 'Displays Customer Phone');
    expect(markup.includes('ahmad@zadran.af'), 'Displays Customer Email');
    expect(markup.includes('Kabul, District 4'), 'Displays Customer Address');
  });

  // Test 5: Invoice Information
  test('5. Invoice Information displays Number, Total, Previously Paid, This Payment, Remaining, and Status', () => {
    const markup = renderToStaticMarkup(
      React.createElement(PaymentReceiptModal, {
        isOpen: true,
        onClose: () => {},
        payment: samplePayment1,
        invoice: sampleInvoice1,
        settings: mockSettings,
      })
    );

    expect(markup.includes('Invoice Information'), 'Invoice Information section exists');
    expect(markup.includes('ST-1025'), 'Displays Invoice Number');
    expect(markup.includes(formatAFN(100000)), 'Displays Invoice Total (100,000 AFN)');
    // sampleInvoice1 totalPaid is 75,000, current payment is 45,000 -> previously paid = 30,000
    expect(markup.includes(formatAFN(30000)), 'Displays Previously Paid (30,000 AFN)');
    expect(markup.includes(formatAFN(45000)), 'Displays This Payment (45,000 AFN)');
    expect(markup.includes(formatAFN(25000)), 'Displays Remaining Balance (25,000 AFN)');
    expect(markup.includes('Partially Paid'), 'Displays Invoice Status Partially Paid');
  });

  // Test 6: Payment Summary Section with Afghani Formatting and No Dollar Sign
  test('6. Payment Summary displays Amount Paid & Remaining Balance in AFN without $', () => {
    const markup = renderToStaticMarkup(
      React.createElement(PaymentReceiptModal, {
        isOpen: true,
        onClose: () => {},
        payment: samplePayment1,
        invoice: sampleInvoice1,
        settings: mockSettings,
      })
    );

    expect(markup.includes('id="payment-receipt-summary"'), 'Payment Summary section exists');
    expect(markup.includes(formatAFN(45000)), 'Displays formatted Amount Paid');
    expect(markup.includes(formatAFN(25000)), 'Displays formatted Remaining Balance');
    expect(!markup.includes('$'), 'Does NOT contain dollar sign ($)');
  });

  // Test 7: Notes Displayed when present, Omitted when absent
  test('7. Notes section is displayed when note exists, omitted when absent', () => {
    // Payment WITH note
    const markupWithNote = renderToStaticMarkup(
      React.createElement(PaymentReceiptModal, {
        isOpen: true,
        onClose: () => {},
        payment: samplePayment1,
        invoice: sampleInvoice1,
        settings: mockSettings,
      })
    );
    expect(markupWithNote.includes('id="receipt-notes-section"'), 'Notes section rendered when note exists');
    expect(markupWithNote.includes('First installment payment received in cash'), 'Note text rendered');

    // Payment WITHOUT note
    const paymentWithoutNote: Payment = {
      ...samplePayment1,
      id: 'ST-P-1026',
      note: '',
    };
    const markupWithoutNote = renderToStaticMarkup(
      React.createElement(PaymentReceiptModal, {
        isOpen: true,
        onClose: () => {},
        payment: paymentWithoutNote,
        invoice: sampleInvoice1,
        settings: mockSettings,
      })
    );
    expect(!markupWithoutNote.includes('id="receipt-notes-section"'), 'Notes section omitted when note is empty');
  });

  // Test 8: Footer
  test('8. Footer displays company thank-you note and footer text', () => {
    const markup = renderToStaticMarkup(
      React.createElement(PaymentReceiptModal, {
        isOpen: true,
        onClose: () => {},
        payment: samplePayment1,
        invoice: sampleInvoice1,
        settings: mockSettings,
      })
    );

    expect(markup.includes('Thank you for your business.'), 'Displays thank you message');
    expect(markup.includes('Security &amp; Surveillance Systems') || markup.includes('Security'), 'Displays footer text');
  });

  // Test 9: Receipt Action Controls: Print Receipt, Download PDF, and Close
  test('9. Receipt Actions contain Print Receipt, Download PDF, and Close', () => {
    const markup = renderToStaticMarkup(
      React.createElement(PaymentReceiptModal, {
        isOpen: true,
        onClose: () => {},
        payment: samplePayment1,
        invoice: sampleInvoice1,
        settings: mockSettings,
      })
    );

    expect(markup.includes('id="btn-receipt-print"'), 'Print Receipt button exists');
    expect(markup.includes('Print Receipt'), 'Print Receipt text exists');
    expect(markup.includes('id="btn-receipt-download"'), 'Download PDF button exists');
    expect(markup.includes('Download PDF'), 'Download PDF text exists');
    expect(markup.includes('id="btn-receipt-close"'), 'Close button exists');
    expect(markup.includes('Close'), 'Close text exists');
  });

  // Test 10: Modal Container & Responsive Classes
  test('10. Modal Container fits viewport, prevents overflow, and uses responsive layout', () => {
    const markup = renderToStaticMarkup(
      React.createElement(PaymentReceiptModal, {
        isOpen: true,
        onClose: () => {},
        payment: samplePayment1,
        invoice: sampleInvoice1,
        settings: mockSettings,
      })
    );

    expect(markup.includes('max-h-'), 'Modal is viewport bounded');
    expect(markup.includes('overflow-y-auto'), 'Body supports vertical scrolling');
    expect(markup.includes('grid-cols-2'), 'Grid layout used for cards');
    expect(markup.includes('break-words') || markup.includes('break-all'), 'Long values wrap safely');
  });

  // Test 11: Final Verification with Varied Data Sets
  test('11. Final Verification with 10 varied scenarios', () => {
    // 1. Payment linked to invoice
    const m1 = renderToStaticMarkup(
      React.createElement(PaymentReceiptModal, {
        isOpen: true,
        onClose: () => {},
        payment: samplePayment1,
        invoice: sampleInvoice1,
        settings: mockSettings,
      })
    );
    expect(m1.includes('ST-1025'), 'Scenario 1: Invoice link verified');

    // 2. Payment with customer
    expect(m1.includes('Ahmad Zadran'), 'Scenario 2: Customer verified');

    // 3. Payment with collector
    expect(m1.includes('Ahmad Admin'), 'Scenario 3: Collector verified');

    // 4. Payment with notes
    expect(m1.includes('First installment payment'), 'Scenario 4: Notes verified');

    // 5. Payment without notes
    const pNoNotes = { ...samplePayment1, note: undefined };
    const m5 = renderToStaticMarkup(
      React.createElement(PaymentReceiptModal, {
        isOpen: true,
        onClose: () => {},
        payment: pNoNotes,
        invoice: sampleInvoice1,
        settings: mockSettings,
      })
    );
    expect(!m5.includes('id="receipt-notes-section"'), 'Scenario 5: No notes box verified');

    // 6. Different payment amounts (e.g. 150,000 AFN)
    const pLarge = { ...samplePayment1, amount: 150000 };
    const m6 = renderToStaticMarkup(
      React.createElement(PaymentReceiptModal, {
        isOpen: true,
        onClose: () => {},
        payment: pLarge,
        invoice: sampleInvoice1,
        settings: mockSettings,
      })
    );
    expect(m6.includes(formatAFN(150000)), 'Scenario 6: Large payment amount verified');

    // 7. Fully paid invoice (remaining balance = 0)
    const invPaid: Invoice = {
      ...sampleInvoice1,
      totalAmount: 45000,
      totalPaid: 45000,
      remaining: 0,
      status: 'Paid',
    } as any;
    const m7 = renderToStaticMarkup(
      React.createElement(PaymentReceiptModal, {
        isOpen: true,
        onClose: () => {},
        payment: samplePayment1,
        invoice: invPaid,
        settings: mockSettings,
      })
    );
    expect(m7.includes(formatAFN(0)), 'Scenario 7: Zero remaining balance verified');
    expect(m7.includes('Paid'), 'Scenario 7: Paid status verified');

    // 8, 9, 10. Responsive layout classes
    expect(m1.includes('max-w-4xl'), 'Scenario 8: Desktop width constraint verified');
    expect(m1.includes('sm:flex-row'), 'Scenario 9: Tablet flex stacking verified');
    expect(m1.includes('flex-col'), 'Scenario 10: Mobile column stacking verified');
  });

  // Test 12: Security & Privacy: No Receipt ID, Payment ID, or Customer ID visible
  test('12. Security and Privacy: Completely removes Receipt ID, Payment ID, and Customer ID', () => {
    const markup = renderToStaticMarkup(
      React.createElement(PaymentReceiptModal, {
        isOpen: true,
        onClose: () => {},
        payment: samplePayment1,
        invoice: sampleInvoice1,
        settings: mockSettings,
      })
    );

    // Verify completely removed: Receipt ID, Payment ID, and Customer ID labels and values
    expect(!markup.includes('Receipt ID'), 'Does NOT display "Receipt ID" anywhere in Receipt UI');
    expect(!markup.includes('Payment ID'), 'Does NOT display "Payment ID" anywhere in Receipt UI');
    expect(!markup.includes('Customer ID'), 'Does NOT display "Customer ID" anywhere in Receipt UI');
    expect(!markup.includes('ST-P-1025'), 'Does NOT display payment ID value "ST-P-1025" in visible Receipt');
    expect(!markup.includes('CUST-001'), 'Does NOT display customer ID value "CUST-001" anywhere in Receipt UI');
  });

  // Test 13: Sarwan Technology Logo Size (160% of original reference size)
  test('13. Branding: Sarwan Technology Logo is increased to 160% size (h-16, sm:h-[77px], max-w-[288px])', () => {
    const markupWithLogo = renderToStaticMarkup(
      React.createElement(PaymentReceiptModal, {
        isOpen: true,
        onClose: () => {},
        payment: samplePayment1,
        invoice: sampleInvoice1,
        settings: {
          ...mockSettings,
          logo: '/sarwan-logo.png',
        },
      })
    );

    // Original size was h-10 sm:h-12 max-w-[180px]
    // 160% size = h-16 sm:h-[77px] max-w-[288px]
    expect(markupWithLogo.includes('h-16'), 'Logo has 160% mobile height (h-16)');
    expect(markupWithLogo.includes('sm:h-[77px]'), 'Logo has 160% desktop height (sm:h-[77px])');
    expect(markupWithLogo.includes('max-w-[288px]'), 'Logo has 160% max-width (max-w-[288px])');
    expect(markupWithLogo.includes('object-contain'), 'Preserves original aspect ratio');
  });

  // Test 14: Single Canonical Receipt Component for Preview and Direct Print
  test('14. Single Receipt Architecture: PaymentReceiptDocument is the ONLY component used for Preview & Print', () => {
    const markup = renderToStaticMarkup(
      React.createElement(PaymentReceiptModal, {
        isOpen: true,
        onClose: () => {},
        payment: samplePayment1,
        invoice: sampleInvoice1,
        settings: mockSettings,
      })
    );

    expect(markup.includes('id="payment-receipt-document"'), 'Renders canonical PaymentReceiptDocument');
    expect(markup.includes('id="receipt-header-section"'), 'Contains canonical header section');
    expect(markup.includes('id="payment-receipt-summary"'), 'Contains canonical summary section');
    expect(markup.includes('id="receipt-payment-info"'), 'Contains canonical payment info section');
    expect(markup.includes('id="receipt-customer-info"'), 'Contains canonical customer info section');
    expect(markup.includes('id="receipt-invoice-info"'), 'Contains canonical invoice info section');
    expect(markup.includes('id="receipt-footer-section"'), 'Contains canonical footer section');
  });

  // Test 15: Auto-Scale & Responsive Preview Container
  test('15. Auto-Scale Viewport: Container provides smooth auto-fit and prevents horizontal overflow', () => {
    const markup = renderToStaticMarkup(
      React.createElement(PaymentReceiptModal, {
        isOpen: true,
        onClose: () => {},
        payment: samplePayment1,
        invoice: sampleInvoice1,
        settings: mockSettings,
      })
    );

    expect(markup.includes('overflow-x-hidden'), 'Container strictly prevents horizontal scrolling');
    expect(markup.includes('transform'), 'Scaling mechanism transforms document without altering layout');
    expect(markup.includes('top center'), 'Scales from top-center');
    expect(!markup.includes('btn-format-a4'), 'A4 format switcher is completely removed');
    expect(!markup.includes('btn-format-thermal'), 'Thermal format switcher removed as 80mm thermal is standard');
  });

  // Test 16: A4 One-Page Payment Receipt format uses exact data, calculations, and prominent totals
  test('16. A4 One-Page Payment Receipt renders exact calculations, prominent totals, zero internal IDs, and no thermal logic', () => {
    const markupA4 = renderToStaticMarkup(
      React.createElement(PaymentReceiptModal, {
        isOpen: true,
        onClose: () => {},
        payment: samplePayment1,
        invoice: sampleInvoice1,
        settings: mockSettings,
      })
    );

    // Renders exact financial numbers
    expect(markupA4.includes(formatAFN(45000)), 'A4 renders exact Amount Paid (45,000 AFN)');
    expect(markupA4.includes(formatAFN(25000)), 'A4 renders exact Remaining Balance (25,000 AFN)');
    expect(markupA4.includes(formatAFN(100000)), 'A4 renders exact Invoice Total (100,000 AFN)');
    expect(markupA4.includes(formatAFN(30000)), 'A4 renders exact Previously Paid (30,000 AFN)');

    // Renders exact customer and payment details
    expect(markupA4.includes('Ahmad Zadran'), 'A4 renders exact customer Ahmad Zadran');
    expect(markupA4.includes('Cash'), 'A4 renders exact payment method Cash');
    expect(markupA4.includes('ST-1025'), 'A4 renders exact bill number ST-1025');
    expect(markupA4.includes('Completed'), 'A4 renders exact payment status Completed');
    expect(markupA4.includes('Partially Paid'), 'A4 renders exact invoice status Partially Paid');

    // Contains ZERO internal IDs
    expect(!markupA4.includes('Receipt ID'), 'A4 has no Receipt ID');
    expect(!markupA4.includes('Payment ID'), 'A4 has no Payment ID');
    expect(!markupA4.includes('Customer ID'), 'A4 has no Customer ID');

    // Contains ZERO thermal logic
    expect(!markupA4.includes('format-thermal'), 'No thermal classes in receipt');
    expect(!markupA4.includes('Thermal80'), 'No thermal paper size in receipt');
  });

  // Summary
  let passed = 0;
  let failed = 0;
  for (const r of results) {
    if (r.passed) {
      console.log(`[✓ PASS] ${r.name}`);
      passed++;
    } else {
      console.error(`[✗ FAIL] ${r.name}: ${r.error}`);
      failed++;
    }
  }

  console.log('---------------------------------------------------------------');
  console.log(`TOTAL: ${results.length} Tests | PASSED: ${passed} | FAILED: ${failed}`);
  console.log('===============================================================');

  if (failed > 0) {
    throw new Error(`${failed} tests failed in paymentReceiptUITests suite`);
  }

  return { total: results.length, passed, failed };
}

runPaymentReceiptUITests();
