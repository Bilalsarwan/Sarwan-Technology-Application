import {
  Invoice,
  Payment,
  AuditLog,
  PaymentMethod,
  PAYMENT_METHOD_LABELS,
} from '../types';
import { getTodayDateString } from './format';
import {
  validatePaymentDate,
  validatePaymentMethod,
  sanitizePaymentNote,
  calculateAuthoritativeBalance,
  calculateNewInvoiceFinancials,
  validatePaymentPermissions,
} from './paymentValidation';

export interface RecordPaymentParams {
  invoiceId: string;
  billNumber?: string;
  customerId?: string;
  customerName?: string;
  amount: number;
  date?: string;
  note?: string;
  method?: PaymentMethod;
  isCorrection?: boolean;
  correctionRefId?: string;
  userId?: string;
  userName?: string;
  userRole?: string;
}

export interface RecordPaymentResult {
  paymentId: string;
  payment: Payment;
  updatedInvoice: Invoice;
  auditLogs: AuditLog[];
}

export interface TransactionalStore {
  getInvoice: (invoiceId: string) => Promise<Invoice | null>;
  getPaymentsForInvoice: (invoiceId: string) => Promise<Payment[]>;
  executeTransaction: (
    operations: (tx: TransactionContext) => Promise<RecordPaymentResult>
  ) => Promise<RecordPaymentResult>;
}

export interface TransactionContext {
  getInvoice: (invoiceId: string) => Promise<Invoice | null>;
  setPayment: (payment: Payment) => Promise<void>;
  updateInvoice: (invoiceId: string, updates: Partial<Invoice>) => Promise<void>;
  addAuditLog: (auditLog: AuditLog) => Promise<void>;
}

/**
 * Pure, authoritative implementation of the 13-step Atomic Payment + Invoice Update logic.
 *
 * Steps:
 * 1. Verify the Invoice.
 * 2. Verify the user has permission to record the Payment.
 * 3. Recalculate the valid Paid Amount from authoritative Payment data.
 * 4. Exclude voided Payments from the calculation.
 * 5. Calculate the current Remaining Balance.
 * 6. Validate the new Payment Amount.
 * 7. Reject zero/negative Payment amounts.
 * 8. Reject Overpayment.
 * 9. Validate Payment Date is not in the future (Payment Date <= Today).
 * 10. Create the Payment.
 * 11. Update the Invoice financial state/status.
 * 12. Create the related Audit Log if the existing architecture requires it.
 * 13. Commit the entire operation (Atomic — Rollback on any failure).
 */
export async function executeAtomicRecordPayment(
  tx: TransactionContext,
  params: RecordPaymentParams,
  existingPayments: Payment[],
  options?: {
    referenceTodayStr?: string;
    generatePaymentId?: () => string;
    generateAuditLogId?: () => string;
  }
): Promise<RecordPaymentResult> {
  // Step 2 (preliminary): Role check (Customers can never record payments)
  const userRole = (params.userRole || '').toLowerCase().trim();
  if (userRole === 'customer') {
    throw new Error('Access Denied: Customers are not permitted to record payments.');
  }

  // Step 6 & 7: Validate payment amount (reject zero/negative)
  const paymentAmount = Number(params.amount);
  if (isNaN(paymentAmount) || paymentAmount <= 0) {
    throw new Error('Payment amount must be greater than zero.');
  }

  // Step 9: Validate Payment Date is not in the future (Payment Date <= Today)
  const dateValidation = validatePaymentDate(params.date, options?.referenceTodayStr);
  if (!dateValidation.isValid) {
    throw new Error(dateValidation.error || 'Payment date cannot be in the future.');
  }
  const validPaymentDate = dateValidation.normalizedDate;

  // Step 2 (method): Validate Payment Method (Cash is only active method; extensible architecture)
  const methodValidation = validatePaymentMethod(params.method);
  if (!methodValidation.isValid) {
    throw new Error(methodValidation.error || 'Only Cash payments are currently accepted.');
  }
  const paymentMethod = methodValidation.method;

  // Step 3 (note): Genuinely optional, no artificial default notes
  const sanitizedNote = sanitizePaymentNote(params.note);

  // Step 1: Verify the Invoice
  const invoiceData = await tx.getInvoice(params.invoiceId);
  if (!invoiceData) {
    throw new Error('Associated invoice was not found.');
  }
  if (invoiceData.isVoid || invoiceData.status === 'Void') {
    throw new Error('Cannot accept payment on a voided invoice.');
  }

  // Step 2 (collector permissions): Collector Scope Enforcement
  const permCheck = validatePaymentPermissions({
    userRole: params.userRole,
    userId: params.userId,
    userName: params.userName,
    invoice: invoiceData,
  });
  if (!permCheck.allowed) {
    throw new Error(permCheck.error || 'Access Denied: Unauthorized to record payment for this invoice.');
  }

  // Step 3 & 4: Recalculate valid Paid Amount from authoritative Payment data, excluding voided payments
  const invoiceTotal = Number(invoiceData.totalAmount) || 0;
  const { authoritativeTotalPaid, remainingBalance } = calculateAuthoritativeBalance(
    invoiceTotal,
    existingPayments
  );

  // Step 5: Check current Remaining Balance
  if (remainingBalance <= 0) {
    throw new Error(
      `This invoice is already fully paid (Remaining Balance: AFN 0). No further payments can be accepted.`
    );
  }

  // Step 8: Reject Overpayment
  if (paymentAmount > remainingBalance) {
    throw new Error(
      `Payment amount of AFN ${paymentAmount.toLocaleString('en-US')} exceeds the remaining balance of AFN ${remainingBalance.toLocaleString('en-US')}. Overpayment is strictly prevented.`
    );
  }

  const now = new Date().toISOString();
  const paymentTime = new Date().toLocaleTimeString('en-US', { hour12: false });
  const finalBillNumber = params.billNumber || invoiceData.billNumber || '';
  const finalCustomerId = params.customerId || invoiceData.customerId || '';
  const finalCustomerName = params.customerName || invoiceData.customerSnapshot?.name || '';
  const paymentId = options?.generatePaymentId
    ? options.generatePaymentId()
    : `PAY-${Date.now()}-${Math.random().toString(36).substr(2, 6)}`;

  // Step 10: Create the Payment record
  const paymentRecord: Payment = {
    id: paymentId,
    invoiceId: params.invoiceId,
    billNumber: finalBillNumber,
    customerId: finalCustomerId,
    customerName: finalCustomerName,
    amount: paymentAmount,
    date: validPaymentDate,
    time: paymentTime,
    note: sanitizedNote,
    method: paymentMethod,
    recordedBy: params.userId || 'system',
    recordedByName: params.userName || 'Staff',
    createdAt: now,
    ...(params.isCorrection ? { isCorrection: true } : {}),
    ...(params.correctionRefId && params.correctionRefId.trim()
      ? { correctionRefId: params.correctionRefId.trim() }
      : {}),
  };

  await tx.setPayment(paymentRecord);

  // Step 11: Update Invoice financial state/status
  const { newTotalPaid, newRemaining, newStatus, isLocked } = calculateNewInvoiceFinancials(
    invoiceTotal,
    authoritativeTotalPaid,
    paymentAmount
  );

  const invoiceUpdates: Partial<Invoice> = {
    status: newStatus,
    totalPaid: newTotalPaid,
    remaining: newRemaining,
    isLocked,
    ...(isLocked ? { lockedAt: now } : {}),
    updatedAt: now,
  };

  await tx.updateInvoice(params.invoiceId, invoiceUpdates);

  const updatedInvoice: Invoice = {
    ...invoiceData,
    ...invoiceUpdates,
  };

  // Step 12: Create related Audit Log(s)
  const auditLogs: AuditLog[] = [];
  const methodLabel = PAYMENT_METHOD_LABELS[paymentMethod] || paymentMethod;
  const auditLogId = options?.generateAuditLogId
    ? options.generateAuditLogId()
    : `AUDIT-${Date.now()}-${Math.random().toString(36).substr(2, 6)}`;

  const paymentAudit: AuditLog = {
    id: auditLogId,
    dateTime: now,
    action: 'record_payment',
    userId: params.userId || 'system',
    userName: params.userName || 'Staff',
    userRole: params.userRole,
    entityType: 'payment',
    entityId: paymentId,
    referenceNumber: finalBillNumber,
    summary: `Recorded ${methodLabel.toLowerCase()} payment of AFN ${paymentAmount.toLocaleString('en-US')} on invoice ${finalBillNumber} (Customer: ${finalCustomerName}, Remaining: AFN ${newRemaining.toLocaleString('en-US')})`,
  };

  await tx.addAuditLog(paymentAudit);
  auditLogs.push(paymentAudit);

  if (newStatus === 'Paid') {
    const fullyPaidAuditId = options?.generateAuditLogId
      ? options.generateAuditLogId()
      : `AUDIT-PAID-${Date.now()}-${Math.random().toString(36).substr(2, 6)}`;

    const fullyPaidAudit: AuditLog = {
      id: fullyPaidAuditId,
      dateTime: now,
      action: 'edit_invoice',
      userId: params.userId || 'system',
      userName: params.userName || 'Staff',
      userRole: params.userRole,
      entityType: 'invoice',
      entityId: params.invoiceId,
      referenceNumber: finalBillNumber,
      summary: `Invoice ${finalBillNumber} became Fully Paid (Total: AFN ${invoiceTotal.toLocaleString('en-US')})`,
    };

    await tx.addAuditLog(fullyPaidAudit);
    auditLogs.push(fullyPaidAudit);
  }

  // Step 13: Entire operation committed atomically
  return {
    paymentId,
    payment: paymentRecord,
    updatedInvoice,
    auditLogs,
  };
}
