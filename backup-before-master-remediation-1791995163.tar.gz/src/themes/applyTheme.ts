import { ThemeDefinition } from './types';

export function applyThemeToDOM(theme: ThemeDefinition | null | undefined): void {
  if (typeof document === 'undefined' || !theme || !theme.tokens) return;

  const root = document.documentElement;
  const { colors, radius, shadows, transitions, focusRing } = theme.tokens;

  // Set data-theme and data-mode attributes
  root.setAttribute('data-theme', theme.id);
  root.setAttribute('data-mode', theme.mode);

  // Synchronize Tailwind 'dark' class
  if (theme.mode === 'dark') {
    root.classList.add('dark');
  } else {
    root.classList.remove('dark');
  }

  // 1. Primary & Brand Tokens
  root.style.setProperty('--color-primary', colors.primary.default);
  root.style.setProperty('--color-primary-hover', colors.primary.hover);
  root.style.setProperty('--color-primary-active', colors.primary.active);
  root.style.setProperty('--color-primary-light', colors.primary.light);
  root.style.setProperty('--color-primary-text', colors.primary.text);
  root.style.setProperty('--color-primary-foreground', colors.primary.text);
  root.style.setProperty('--color-primary-focus', colors.primary.ring);

  root.style.setProperty('--brand-orange', colors.brand.orange);
  root.style.setProperty('--brand-black', colors.brand.black);
  root.style.setProperty('--brand-white', colors.brand.white);

  // 2. Background and Surface Tokens (Existing and Semantic Aliases)
  root.style.setProperty('--app-bg', colors.background.base);
  root.style.setProperty('--app-bg-muted', colors.background.muted);
  root.style.setProperty('--app-bg-subtle', colors.background.subtle);
  root.style.setProperty('--app-bg-canvas', colors.background.canvas);
  root.style.setProperty('--color-background', colors.background.base);

  root.style.setProperty('--app-surface', colors.surface.card);
  root.style.setProperty('--app-surface-card', colors.surface.card);
  root.style.setProperty('--app-surface-modal', colors.surface.modal);
  root.style.setProperty('--app-surface-dropdown', colors.surface.dropdown);
  root.style.setProperty('--app-surface-header', colors.surface.header);
  root.style.setProperty('--app-surface-sidebar', colors.surface.sidebar);
  root.style.setProperty('--app-surface-input', colors.surface.input);
  root.style.setProperty('--app-surface-elevated', colors.surface.elevated || colors.surface.modal || colors.surface.card);

  root.style.setProperty('--color-surface', colors.surface.card);
  root.style.setProperty('--color-surface-elevated', colors.surface.elevated || colors.surface.modal || colors.surface.card);
  root.style.setProperty('--color-surface-sidebar', colors.surface.sidebar);
  root.style.setProperty('--color-surface-header', colors.surface.header);
  root.style.setProperty('--color-surface-input', colors.surface.input);

  // 3. Text & Typography Tokens
  root.style.setProperty('--app-text', colors.text.primary);
  root.style.setProperty('--app-text-primary', colors.text.primary);
  root.style.setProperty('--app-text-secondary', colors.text.secondary);
  root.style.setProperty('--app-text-muted', colors.text.muted);
  root.style.setProperty('--app-text-inverse', colors.text.inverse);
  root.style.setProperty('--app-text-accent', colors.text.accent);

  root.style.setProperty('--color-text-primary', colors.text.primary);
  root.style.setProperty('--color-text-secondary', colors.text.secondary);
  root.style.setProperty('--color-text-muted', colors.text.muted);
  root.style.setProperty('--color-text-inverse', colors.text.inverse);
  root.style.setProperty('--color-text-link', colors.text.link || colors.primary.default);
  root.style.setProperty('--color-text-disabled', colors.text.disabled || colors.text.muted);

  // 4. Border Tokens
  root.style.setProperty('--app-border', colors.border.default);
  root.style.setProperty('--app-border-subtle', colors.border.subtle);
  root.style.setProperty('--app-border-strong', colors.border.strong);
  root.style.setProperty('--app-border-active', colors.border.active);

  root.style.setProperty('--color-border-default', colors.border.default);
  root.style.setProperty('--color-border-subtle', colors.border.subtle);
  root.style.setProperty('--color-border-strong', colors.border.strong);
  root.style.setProperty('--color-border-divider', colors.border.divider || colors.border.subtle);

  // 5. Interactive States
  const interactiveHover = colors.interactive?.hover || colors.background.muted;
  const interactiveActive = colors.interactive?.active || colors.border.subtle;
  const interactiveSelected = colors.interactive?.selected || colors.primary.light;
  const interactiveDisabled = colors.interactive?.disabled || colors.background.muted;
  root.style.setProperty('--color-interactive-hover', interactiveHover);
  root.style.setProperty('--color-interactive-active', interactiveActive);
  root.style.setProperty('--color-interactive-selected', interactiveSelected);
  root.style.setProperty('--color-interactive-disabled', interactiveDisabled);

  // 6. Semantic Status Tokens
  if (colors.semantic) {
    if (colors.semantic.success) {
      root.style.setProperty('--color-success-bg', colors.semantic.success.bg);
      root.style.setProperty('--color-success-text', colors.semantic.success.text);
      root.style.setProperty('--color-success-border', colors.semantic.success.border);
      root.style.setProperty('--color-success', colors.semantic.success.text);
    }
    if (colors.semantic.warning) {
      root.style.setProperty('--color-warning-bg', colors.semantic.warning.bg);
      root.style.setProperty('--color-warning-text', colors.semantic.warning.text);
      root.style.setProperty('--color-warning-border', colors.semantic.warning.border);
      root.style.setProperty('--color-warning', colors.semantic.warning.text);
    }
    if (colors.semantic.danger) {
      root.style.setProperty('--color-danger-bg', colors.semantic.danger.bg);
      root.style.setProperty('--color-danger-text', colors.semantic.danger.text);
      root.style.setProperty('--color-danger-border', colors.semantic.danger.border);
      root.style.setProperty('--color-danger', colors.semantic.danger.text);
      root.style.setProperty('--color-error', colors.semantic.danger.text);
      root.style.setProperty('--color-destructive', colors.semantic.danger.text);
    }
    if (colors.semantic.info) {
      root.style.setProperty('--color-info-bg', colors.semantic.info.bg);
      root.style.setProperty('--color-info-text', colors.semantic.info.text);
      root.style.setProperty('--color-info-border', colors.semantic.info.border);
      root.style.setProperty('--color-info', colors.semantic.info.text);
    }
  }

  // 7. Radius Tokens
  if (radius) {
    root.style.setProperty('--radius-xs', radius.xs);
    root.style.setProperty('--radius-sm', radius.sm);
    root.style.setProperty('--radius-md', radius.md);
    root.style.setProperty('--radius-lg', radius.lg);
    root.style.setProperty('--radius-xl', radius.xl);
    root.style.setProperty('--radius-full', radius.full);
    root.style.setProperty('--radius-card', radius.card || radius.lg);
    root.style.setProperty('--radius-modal', radius.modal || radius.xl);
  }

  // 8. Shadow Tokens
  if (shadows) {
    root.style.setProperty('--shadow-sm', shadows.sm);
    root.style.setProperty('--shadow-md', shadows.md);
    root.style.setProperty('--shadow-lg', shadows.lg);
    root.style.setProperty('--shadow-card', shadows.card || shadows.md);
    root.style.setProperty('--shadow-elevated', shadows.elevated || shadows.lg);
  }

  // 9. Focus Ring & Accessibility Tokens
  root.style.setProperty('--focus-ring', focusRing || '0 0 0 2px #FFFFFF, 0 0 0 4px #2563EB');
  root.style.setProperty('--focus-ring-color', colors.primary.ring || colors.primary.default);

  // 10. Motion & Transitions Tokens
  if (transitions) {
    root.style.setProperty('--transition-fast', transitions.fast);
    root.style.setProperty('--transition-normal', transitions.normal);
    root.style.setProperty('--transition-slow', transitions.slow || '350ms cubic-bezier(0.4, 0, 0.2, 1)');
  }

  // Set meta theme-color for mobile address bar safely
  try {
    if (typeof document.querySelector === 'function' && typeof document.createElement === 'function' && document.head) {
      let metaTheme = document.querySelector('meta[name="theme-color"]');
      if (!metaTheme) {
        metaTheme = document.createElement('meta');
        metaTheme.setAttribute('name', 'theme-color');
        document.head.appendChild(metaTheme);
      }
      metaTheme.setAttribute('content', colors.surface.header);
    }
  } catch {
    // Ignore DOM exception in test/server environment
  }
}
