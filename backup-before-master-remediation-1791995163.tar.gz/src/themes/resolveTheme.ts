import { ThemeDefinition, ThemeId } from './types';
import { THEME_MAP, INITIAL_USER_THEME_FALLBACK, themeSarwanLight } from './catalog';

export type ThemeResolutionSource = 'personal' | 'global_default' | 'fallback';

export interface ThemeResolutionInput {
  personalPreference?: string | null;
  globalDefault?: string | null;
  fallback?: string | null;
}

export interface ResolvedTheme {
  theme: ThemeDefinition;
  themeId: ThemeId;
  source: ThemeResolutionSource;
  hasExplicitPersonalPreference: boolean;
}

/**
 * Migration dictionary: Maps all legacy, alternative, and alias identifiers
 * safely to the official Sarwan Light Mode or Sarwan Dark Mode.
 */
export const LEGACY_THEME_ID_MAP: Record<string, ThemeId> = {
  // Light Mode Mappings
  sarwan_classic_light: 'sarwan_light',
  sarwan_light: 'sarwan_light',
  sarwan: 'sarwan_light',
  sarwan_brand: 'sarwan_light',
  sarwan_corporate: 'sarwan_light',
  brand: 'sarwan_light',
  default: 'sarwan_light',
  light: 'sarwan_light',
  light_classic: 'sarwan_light',
  ocean_blue: 'sarwan_light',
  ocean: 'sarwan_light',
  blue: 'sarwan_light',
  emerald_green: 'sarwan_light',
  emerald: 'sarwan_light',
  green: 'sarwan_light',
  violet: 'sarwan_light',
  purple: 'sarwan_light',
  slate_neutral: 'sarwan_light',
  slate: 'sarwan_light',
  neutral: 'sarwan_light',
  rose: 'sarwan_light',
  amber_gold: 'sarwan_light',
  amber: 'sarwan_light',
  gold: 'sarwan_light',
  teal: 'sarwan_light',

  // Dark Mode Mappings
  sarwan_dark: 'sarwan_dark',
  dark: 'sarwan_dark',
  dark_midnight: 'sarwan_dark',
  midnight: 'sarwan_dark',
  high_contrast: 'sarwan_dark',
  contrast: 'sarwan_dark',
  hc: 'sarwan_dark',
};

/**
 * Validates whether an unknown identifier exists in the registered THEME_MAP.
 */
export function isValidThemeId(id: unknown): id is ThemeId {
  return typeof id === 'string' && id in THEME_MAP;
}

/**
 * Sanitizes and normalizes an incoming theme identifier, mapping legacy keys
 * to either 'sarwan_light' or 'sarwan_dark', discarding invalid strings safely.
 */
export function normalizeThemeId(rawId: unknown): ThemeId | null {
  if (typeof rawId !== 'string') return null;
  const trimmed = rawId.trim().toLowerCase();
  if (!trimmed) return null;

  // Check legacy mapping first to normalize aliases like sarwan_classic_light -> sarwan_light
  if (trimmed in LEGACY_THEME_ID_MAP) {
    return LEGACY_THEME_ID_MAP[trimmed];
  }

  if (trimmed in THEME_MAP) {
    return trimmed as ThemeId;
  }

  return null;
}

/**
 * Centralized Theme Precedence Engine:
 * 1. Explicit Personal Preference: If a valid personal theme has been saved, use it.
 * 2. Global Default Theme: If the user has no explicit personal preference, use the administrator default.
 * 3. Application Fallback: If neither is available or valid, use Sarwan Light Mode.
 */
export function resolveEffectiveTheme(input?: ThemeResolutionInput | null): ResolvedTheme {
  const personal = normalizeThemeId(input?.personalPreference);
  const globalDef = normalizeThemeId(input?.globalDefault);
  const fallbackCandidate = normalizeThemeId(input?.fallback);

  // 1. Explicit Personal Preference (User selection overrides global default)
  if (personal) {
    return {
      theme: THEME_MAP[personal] || themeSarwanLight,
      themeId: personal,
      source: 'personal',
      hasExplicitPersonalPreference: true,
    };
  }

  // 2. Administrator Global Default (For users without an explicit personal preference)
  if (globalDef) {
    return {
      theme: THEME_MAP[globalDef] || themeSarwanLight,
      themeId: globalDef,
      source: 'global_default',
      hasExplicitPersonalPreference: false,
    };
  }

  // 3. Application Fallback (Sarwan Light Mode)
  const fallbackId: ThemeId = fallbackCandidate || INITIAL_USER_THEME_FALLBACK;

  return {
    theme: THEME_MAP[fallbackId] || themeSarwanLight,
    themeId: fallbackId,
    source: 'fallback',
    hasExplicitPersonalPreference: false,
  };
}
