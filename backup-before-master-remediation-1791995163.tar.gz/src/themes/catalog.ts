import { ThemeDefinition, ThemeId, ThemeTokens } from './types';

// Sarwan Brand Constants
export const SARWAN_BRAND_ORANGE = '#F7941D'; // Official logo vector hex
export const SARWAN_BRAND_ORANGE_HOVER = '#E67E0A';
export const SARWAN_BRAND_ORANGE_ACTIVE = '#CC6D00';
export const SARWAN_BRAND_ORANGE_LIGHT = '#FFF7ED';
export const SARWAN_BRAND_BLACK = '#111827';
export const SARWAN_BRAND_WHITE = '#FFFFFF';

const baseRadius = {
  xs: '0.25rem',
  sm: '0.375rem',
  md: '0.5rem',
  lg: '0.75rem',
  xl: '1rem',
  full: '9999px',
  card: '0.75rem',
  modal: '1rem',
};

const baseTransitions = {
  fast: '150ms cubic-bezier(0.4, 0, 0.2, 1)',
  normal: '250ms cubic-bezier(0.4, 0, 0.2, 1)',
  slow: '350ms cubic-bezier(0.4, 0, 0.2, 1)',
};

/**
 * Sarwan Technology — Light Mode (Official Brand Theme)
 * Authentic Sarwan corporate identity: Crisp clean white surfaces, Sarwan Orange accents (#F7941D),
 * charcoal sidebar on desktop, professional corporate appearance.
 */
export const themeSarwanLight: ThemeDefinition = {
  id: 'sarwan_light',
  name: 'Sarwan Technology (Light)',
  tagline: 'Official Brand Light Mode',
  description: 'Signature corporate design featuring Sarwan vibrant orange, clean light surfaces, and crisp financial typography.',
  mode: 'light',
  isCustomBrand: true,
  accentColor: SARWAN_BRAND_ORANGE,
  surfaceColor: '#FFFFFF',
  preview: {
    primary: '#2563EB',
    background: '#F8FAFC',
    surface: '#FFFFFF',
    accent: SARWAN_BRAND_ORANGE,
    text: '#0F172A',
    border: '#E2E8F0',
  },
  tokens: {
    colors: {
      primary: {
        default: '#2563EB',
        hover: '#1D4ED8',
        active: '#1E40AF',
        light: '#EFF6FF',
        text: '#FFFFFF',
        ring: 'rgba(37, 99, 235, 0.35)',
      },
      secondary: {
        default: '#F1F5F9',
        hover: '#E2E8F0',
        active: '#CBD5E1',
        text: '#1E293B',
        border: '#CBD5E1',
      },
      background: {
        base: '#F8FAFC',
        muted: '#F1F5F9',
        subtle: '#FFFFFF',
        canvas: '#F8FAFC',
      },
      surface: {
        card: '#FFFFFF',
        modal: '#FFFFFF',
        dropdown: '#FFFFFF',
        header: '#FFFFFF',
        sidebar: '#0A0F1D',
        input: '#FFFFFF',
        elevated: '#FFFFFF',
      },
      text: {
        primary: '#0F172A',
        secondary: '#475569',
        muted: '#64748B',
        inverse: '#FFFFFF',
        accent: SARWAN_BRAND_ORANGE,
        link: '#2563EB',
        disabled: '#94A3B8',
      },
      border: {
        subtle: '#F1F5F9',
        default: '#E2E8F0',
        strong: '#CBD5E1',
        active: SARWAN_BRAND_ORANGE,
        divider: '#F1F5F9',
      },
      brand: {
        orange: SARWAN_BRAND_ORANGE,
        black: SARWAN_BRAND_BLACK,
        white: SARWAN_BRAND_WHITE,
      },
      semantic: {
        success: { bg: '#ECFDF5', text: '#065F46', border: '#A7F3D0', hover: '#059669' },
        warning: { bg: '#FFFBEB', text: '#92400E', border: '#FDE68A', hover: '#D97706' },
        danger: { bg: '#FEF2F2', text: '#991B1B', border: '#FECACA', hover: '#DC2626' },
        info: { bg: '#EFF6FF', text: '#1E40AF', border: '#BFDBFE', hover: '#2563EB' },
      },
      interactive: {
        hover: '#F1F5F9',
        active: '#E2E8F0',
        selected: '#EFF6FF',
        disabled: '#F8FAFC',
      },
    },
    radius: baseRadius,
    shadows: {
      sm: '0 1px 2px 0 rgba(0, 0, 0, 0.05)',
      md: '0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06)',
      lg: '0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05)',
      card: '0 1px 3px 0 rgba(0, 0, 0, 0.08), 0 1px 2px -1px rgba(0, 0, 0, 0.06)',
      elevated: '0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04)',
    },
    focusRing: '0 0 0 3px rgba(37, 99, 235, 0.35)',
    transitions: baseTransitions,
  },
};

/**
 * Sarwan Technology — Dark Mode (Official Brand Theme)
 * Authentic Sarwan corporate identity in a dark aesthetic: Layered charcoal surfaces,
 * vibrant brand orange accents (#F7941D), high-contrast readability, and deep canvas.
 */
export const themeSarwanDark: ThemeDefinition = {
  id: 'sarwan_dark',
  name: 'Sarwan Technology (Dark)',
  tagline: 'Official Brand Dark Mode',
  description: 'Signature corporate design featuring layered charcoal surfaces, vibrant brand accents, and high-readability typography.',
  mode: 'dark',
  isCustomBrand: true,
  accentColor: SARWAN_BRAND_ORANGE,
  surfaceColor: '#131E32',
  preview: {
    primary: '#3B82F6',
    background: '#0B1120',
    surface: '#131E32',
    accent: SARWAN_BRAND_ORANGE,
    text: '#F8FAFC',
    border: '#334155',
  },
  tokens: {
    colors: {
      primary: {
        default: '#3B82F6',
        hover: '#60A5FA',
        active: '#2563EB',
        light: '#1E3A8A',
        text: '#FFFFFF',
        ring: 'rgba(59, 130, 246, 0.4)',
      },
      secondary: {
        default: '#1E293B',
        hover: '#334155',
        active: '#475569',
        text: '#F1F5F9',
        border: '#334155',
      },
      background: {
        base: '#0B1120',
        muted: '#0F172A',
        subtle: '#131E32',
        canvas: '#0B1120',
      },
      surface: {
        card: '#131E32',
        modal: '#152238',
        dropdown: '#152238',
        header: '#0F172A',
        sidebar: '#070B14',
        input: '#10192A',
        elevated: '#1E293B',
      },
      text: {
        primary: '#F8FAFC',
        secondary: '#CBD5E1',
        muted: '#94A3B8',
        inverse: '#0F172A',
        accent: SARWAN_BRAND_ORANGE,
        link: '#60A5FA',
        disabled: '#64748B',
      },
      border: {
        subtle: '#1E293B',
        default: '#334155',
        strong: '#475569',
        active: SARWAN_BRAND_ORANGE,
        divider: '#1E293B',
      },
      brand: {
        orange: SARWAN_BRAND_ORANGE,
        black: SARWAN_BRAND_BLACK,
        white: SARWAN_BRAND_WHITE,
      },
      semantic: {
        success: { bg: '#064E3B', text: '#6EE7B7', border: '#059669', hover: '#10B981' },
        warning: { bg: '#78350F', text: '#FDE68A', border: '#D97706', hover: '#F59E0B' },
        danger: { bg: '#7F1D1D', text: '#FCA5A5', border: '#DC2626', hover: '#EF4444' },
        info: { bg: '#1E3A8A', text: '#93C5FD', border: '#2563EB', hover: '#3B82F6' },
      },
      interactive: {
        hover: '#1E293B',
        active: '#334155',
        selected: '#1E3A8A',
        disabled: '#0F172A',
      },
    },
    radius: baseRadius,
    shadows: {
      sm: '0 1px 2px 0 rgba(0, 0, 0, 0.4)',
      md: '0 4px 6px -1px rgba(0, 0, 0, 0.5), 0 2px 4px -1px rgba(0, 0, 0, 0.3)',
      lg: '0 10px 15px -3px rgba(0, 0, 0, 0.6), 0 4px 6px -2px rgba(0, 0, 0, 0.4)',
      card: '0 1px 3px 0 rgba(0, 0, 0, 0.5), 0 1px 2px -1px rgba(0, 0, 0, 0.4)',
      elevated: '0 20px 25px -5px rgba(0, 0, 0, 0.7), 0 10px 10px -5px rgba(0, 0, 0, 0.5)',
    },
    focusRing: '0 0 0 3px rgba(59, 130, 246, 0.4)',
    transitions: baseTransitions,
  },
};

// Backward-compatibility alias
export const themeSarwanClassicLight: ThemeDefinition = themeSarwanLight;

/**
 * The official active theme catalog strictly contains the two Sarwan brand modes.
 */
export const THEME_CATALOG: ThemeDefinition[] = [
  themeSarwanLight,
  themeSarwanDark,
];

/**
 * Fast lookup dictionary supporting canonical and backward-compatible alias IDs.
 */
export const THEME_MAP: Record<string, ThemeDefinition> = {
  sarwan_light: themeSarwanLight,
  sarwan_dark: themeSarwanDark,
  sarwan_classic_light: themeSarwanLight,
};

/**
 * Default fallback theme is Sarwan Light Mode.
 */
export const INITIAL_USER_THEME_FALLBACK: ThemeId = 'sarwan_light';

/**
 * Retrieves a theme definition by ThemeId, safely falling back to Sarwan Light.
 */
export function getThemeById(id: string | null | undefined): ThemeDefinition {
  if (!id) return themeSarwanLight;
  return THEME_MAP[id] || themeSarwanLight;
}

/**
 * Comprehensive runtime validation for token completeness.
 */
export function validateThemeTokens(theme: ThemeDefinition): string[] {
  const errors: string[] = [];
  if (!theme.tokens) {
    errors.push(`Theme ${theme.id} is missing tokens object.`);
    return errors;
  }
  const { colors, radius, shadows } = theme.tokens;
  if (!colors.primary?.default) errors.push(`Theme ${theme.id} missing primary.default color.`);
  if (!colors.background?.base) errors.push(`Theme ${theme.id} missing background.base color.`);
  if (!colors.surface?.card) errors.push(`Theme ${theme.id} missing surface.card color.`);
  if (!colors.text?.primary) errors.push(`Theme ${theme.id} missing text.primary color.`);
  if (!colors.border?.default) errors.push(`Theme ${theme.id} missing border.default color.`);
  if (!radius?.md) errors.push(`Theme ${theme.id} missing radius.md.`);
  if (!shadows?.md) errors.push(`Theme ${theme.id} missing shadows.md.`);
  return errors;
}

export function isThemeSystemReady(): boolean {
  for (const theme of THEME_CATALOG) {
    const errs = validateThemeTokens(theme);
    if (errs.length > 0) return false;
  }
  return true;
}
