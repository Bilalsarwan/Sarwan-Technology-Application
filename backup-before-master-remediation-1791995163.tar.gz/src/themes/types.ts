export type ThemeId =
  | 'sarwan_light'
  | 'sarwan_dark'
  | 'sarwan_classic_light'; // Legacy alias for backward compatibility

export type ThemeMode = 'light' | 'dark';

export interface ThemeColors {
  primary: {
    default: string;
    hover: string;
    active: string;
    light: string;
    text: string;
    ring: string;
  };
  secondary: {
    default: string;
    hover: string;
    active: string;
    text: string;
    border: string;
  };
  background: {
    base: string;
    muted: string;
    subtle: string;
    canvas: string;
  };
  surface: {
    card: string;
    modal: string;
    dropdown: string;
    header: string;
    sidebar: string;
    input: string;
    elevated?: string;
  };
  text: {
    primary: string;
    secondary: string;
    muted: string;
    inverse: string;
    accent: string;
    link?: string;
    disabled?: string;
  };
  border: {
    subtle: string;
    default: string;
    strong: string;
    active: string;
    divider?: string;
  };
  brand: {
    orange: string; // Sarwan Orange (#FF9200 / #F7941D)
    black: string;
    white: string;
  };
  semantic: {
    success: { bg: string; text: string; border: string; hover?: string };
    warning: { bg: string; text: string; border: string; hover?: string };
    danger: { bg: string; text: string; border: string; hover?: string };
    info: { bg: string; text: string; border: string; hover?: string };
  };
  interactive?: {
    hover?: string;
    active?: string;
    selected?: string;
    disabled?: string;
  };
}

export interface ThemeTokens {
  colors: ThemeColors;
  radius: {
    xs: string;
    sm: string;
    md: string;
    lg: string;
    xl: string;
    full: string;
    card?: string;
    modal?: string;
  };
  shadows: {
    sm: string;
    md: string;
    lg: string;
    card?: string;
    elevated?: string;
  };
  focusRing: string;
  transitions: {
    fast: string;
    normal: string;
    slow?: string;
  };
}

export interface ThemePreview {
  primary: string;
  background: string;
  surface: string;
  accent: string;
  text: string;
  border: string;
}

export interface ThemeDefinition {
  id: ThemeId;
  name: string;
  tagline: string;
  description: string;
  mode: ThemeMode;
  isCustomBrand?: boolean;
  accentColor: string;
  surfaceColor: string;
  preview: ThemePreview;
  tokens: ThemeTokens;
}
