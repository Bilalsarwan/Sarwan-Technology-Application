import { ThemeId } from './types';
import { THEME_MAP, INITIAL_USER_THEME_FALLBACK } from './catalog';
import { normalizeThemeId } from './resolveTheme';
import { applyThemeToDOM } from './applyTheme';

export const THEME_STORAGE_KEYS = {
  GLOBAL_DEFAULT: 'sarwan_theme_global_default',
  GUEST_PREFERENCE: 'sarwan_theme_guest',
  USER_PREFERENCE_PREFIX: 'sarwan_theme_user_',
  LEGACY_USER_THEME: 'sarwan_user_theme',
  AUTH_SESSION: 'sarwan_auth_session_v1',
} as const;

function safeGetItem(key: string): string | null {
  if (typeof window === 'undefined') return null;
  try {
    return localStorage.getItem(key);
  } catch (err) {
    console.warn(`[ThemeStorage] Failed to read localStorage key "${key}":`, err);
    return null;
  }
}

function safeSetItem(key: string, value: string): void {
  if (typeof window === 'undefined') return;
  try {
    localStorage.setItem(key, value);
  } catch (err) {
    console.warn(`[ThemeStorage] Failed to write localStorage key "${key}":`, err);
  }
}

function safeRemoveItem(key: string): void {
  if (typeof window === 'undefined') return;
  try {
    localStorage.removeItem(key);
  } catch (err) {
    console.warn(`[ThemeStorage] Failed to remove localStorage key "${key}":`, err);
  }
}

/**
 * Reads the cached administrator global default theme.
 */
export function getStoredGlobalDefault(): ThemeId | null {
  const val = safeGetItem(THEME_STORAGE_KEYS.GLOBAL_DEFAULT);
  return normalizeThemeId(val);
}

/**
 * Persists the administrator global default theme locally.
 */
export function setStoredGlobalDefault(themeId: ThemeId): void {
  safeSetItem(THEME_STORAGE_KEYS.GLOBAL_DEFAULT, themeId);
}

/**
 * Clears the administrator global default theme locally.
 */
export function clearStoredGlobalDefault(): void {
  safeRemoveItem(THEME_STORAGE_KEYS.GLOBAL_DEFAULT);
}


/**
 * Reads a specific user's scoped personal theme preference.
 */
export function getStoredUserTheme(userId: string): ThemeId | null {
  if (!userId) return null;
  const key = `${THEME_STORAGE_KEYS.USER_PREFERENCE_PREFIX}${userId}`;
  const val = safeGetItem(key);
  return normalizeThemeId(val);
}

/**
 * Saves a specific user's personal theme preference into isolated user storage.
 */
export function setStoredUserTheme(userId: string, themeId: ThemeId): void {
  if (!userId) return;
  const key = `${THEME_STORAGE_KEYS.USER_PREFERENCE_PREFIX}${userId}`;
  safeSetItem(key, themeId);
}

/**
 * Clears a specific user's personal theme preference (reverting them to global default).
 */
export function clearStoredUserTheme(userId: string): void {
  if (!userId) return;
  const key = `${THEME_STORAGE_KEYS.USER_PREFERENCE_PREFIX}${userId}`;
  safeRemoveItem(key);
}

/**
 * Reads a guest's temporary personal theme preference.
 */
export function getStoredGuestTheme(): ThemeId | null {
  const val = safeGetItem(THEME_STORAGE_KEYS.GUEST_PREFERENCE);
  return normalizeThemeId(val);
}

/**
 * Saves a guest's temporary personal theme preference.
 */
export function setStoredGuestTheme(themeId: ThemeId): void {
  safeSetItem(THEME_STORAGE_KEYS.GUEST_PREFERENCE, themeId);
}

/**
 * Clears guest preference.
 */
export function clearStoredGuestTheme(): void {
  safeRemoveItem(THEME_STORAGE_KEYS.GUEST_PREFERENCE);
}

/**
 * Migrates legacy un-scoped theme storage (`sarwan_user_theme`) into isolated user/guest storage.
 */
export function migrateLegacyThemeStorage(currentUserId?: string | null): void {
  const legacyVal = safeGetItem(THEME_STORAGE_KEYS.LEGACY_USER_THEME);
  if (!legacyVal) return;

  const normalized = normalizeThemeId(legacyVal);
  if (normalized) {
    if (currentUserId) {
      // If user storage doesn't already have a preference, adopt legacy
      if (!safeGetItem(`${THEME_STORAGE_KEYS.USER_PREFERENCE_PREFIX}${currentUserId}`)) {
        setStoredUserTheme(currentUserId, normalized);
      }
    } else {
      if (!safeGetItem(THEME_STORAGE_KEYS.GUEST_PREFERENCE)) {
        setStoredGuestTheme(normalized);
      }
    }
  }

  // Remove legacy key to prevent future cross-account pollution
  safeRemoveItem(THEME_STORAGE_KEYS.LEGACY_USER_THEME);
}

/**
 * Synchronous early initialization to prevent white/dark flashes before React renders.
 */
export function initEarlyTheme(): ThemeId {
  if (typeof window === 'undefined') return INITIAL_USER_THEME_FALLBACK;

  let resolvedThemeId: ThemeId | null = null;

  // 1. Try to read active session
  try {
    const rawSession = safeGetItem(THEME_STORAGE_KEYS.AUTH_SESSION);
    if (rawSession) {
      const parsed = JSON.parse(rawSession);
      if (parsed?.userId) {
        resolvedThemeId = getStoredUserTheme(parsed.userId);
      }
    }
  } catch {
    // Ignore JSON parse errors
  }

  // 2. Try global default
  if (!resolvedThemeId) {
    resolvedThemeId = getStoredGlobalDefault();
  }

  // 3. Try guest preference
  if (!resolvedThemeId) {
    resolvedThemeId = getStoredGuestTheme();
  }

  // 4. Fallback to Sarwan Classic Light
  if (!resolvedThemeId) {
    resolvedThemeId = INITIAL_USER_THEME_FALLBACK;
  }

  const themeDef = THEME_MAP[resolvedThemeId] || THEME_MAP[INITIAL_USER_THEME_FALLBACK];
  applyThemeToDOM(themeDef);

  return resolvedThemeId;
}
