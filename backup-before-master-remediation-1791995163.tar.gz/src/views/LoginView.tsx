import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import {
  AlertCircle,
  Eye,
  EyeOff,
  Lock,
  User as UserIcon,
  Loader2,
  LogIn,
} from 'lucide-react';
import { BusinessSettings } from '../types';

interface LoginViewProps {
  settings?: BusinessSettings;
}

export const LoginView: React.FC<LoginViewProps> = ({ settings }) => {
  const {
    signInWithGoogle,
    signInWithUsernameAndPassword,
    loading: authLoading,
    error: authError,
    clearError,
  } = useAuth();

  // Primary username/password state
  const [usernameOrEmail, setUsernameOrEmail] = useState<string>('');
  const [password, setPassword] = useState<string>('');
  const [showPassword, setShowPassword] = useState<boolean>(false);
  const [submitting, setSubmitting] = useState<boolean>(false);

  // Google sign-in state
  const [googleSubmitting, setGoogleSubmitting] = useState<boolean>(false);
  const [googleUserIdInput] = useState<string>('');

  const [localError, setLocalError] = useState<string | null>(null);

  const displayError = localError || authError;

  /**
   * Primary Username + Password login handler.
   */
  const handleUsernamePasswordLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLocalError(null);
    clearError();

    const cleanUser = usernameOrEmail.trim();
    if (!cleanUser) {
      setLocalError('Please enter your username or registered email.');
      return;
    }
    if (!password) {
      setLocalError('Please enter your password.');
      return;
    }

    setSubmitting(true);
    try {
      await signInWithUsernameAndPassword(cleanUser, password);
    } catch (err: any) {
      setLocalError(err.message || 'Invalid username or password.');
    } finally {
      setSubmitting(false);
    }
  };

  /**
   * Google sign-in handler.
   */
  const handleGoogleSignIn = async () => {
    setLocalError(null);
    clearError();
    setGoogleSubmitting(true);
    try {
      await signInWithGoogle(googleUserIdInput.trim() || undefined);
    } catch (err: any) {
      setLocalError(err.message || 'Google authentication failed.');
    } finally {
      setGoogleSubmitting(false);
    }
  };

  // Helper to detect if a string contains Arabic/Persian/Pashto script
  const isArabicScript = (str: string) =>
    /[\u0600-\u06FF\u0750-\u077F\u08A0-\u08FF\uFB50-\uFDFF\uFE70-\uFEFF]/.test(str);



  // Fixed path as required by specification: public/assets/branding/SignInDesignLogo/sarwan-technology-logo.png
  const logoUrl =
    settings?.loginLogo ||
    settings?.logo ||
    '/assets/branding/SignInDesignLogo/sarwan-technology-logo.png';

  // Read configured company name from existing Settings → Login Portal Settings:
  // English Company Name from Login Portal Settings (loginTitle or loginSubtitle), falling back to companyName and 'Sarwan Technology'
  const englishCompanyName =
    (settings?.loginTitle?.trim() && !isArabicScript(settings.loginTitle)
      ? settings.loginTitle.trim()
      : null) ||
    (settings?.loginSubtitle?.trim() && !isArabicScript(settings.loginSubtitle)
      ? settings.loginSubtitle.trim()
      : null) ||
    settings?.companyName?.trim() ||
    'Sarwan Technology';

  /**
   * Formats a company name with the logo's actual black and orange brand colors.
   * In the official Sarwan Technology logo, the primary brand entity ("Sarwan") is Black,
   * and the descriptor ("Technology") is Orange.
   * Adapts seamlessly to both Sarwan Light (#111827 / #EA580C) and Sarwan Dark (#F8FAFC / #FB923C) themes.
   */
  const renderLogoBrandedName = (name: string) => {
    const trimmed = name.trim();
    const lastSpace = trimmed.lastIndexOf(' ');
    if (lastSpace === -1) {
      return (
        <span className="text-[#111827] dark:text-[#F8FAFC]">
          {trimmed}
        </span>
      );
    }
    const lead = trimmed.slice(0, lastSpace);
    const trail = trimmed.slice(lastSpace + 1);
    return (
      <>
        <span className="text-[#000000] dark:text-[#F8FAFC]">
          {lead}
        </span>{' '}
        <span className="text-[#000000] dark:text-[#F8FAFC]">
          {trail}
        </span>
      </>
    );
  };

  return (
    <div className="min-h-screen w-full flex flex-col justify-center items-center px-4 py-8 sm:px-6 sm:py-12 bg-[var(--app-bg,#F8FAFC)] text-[var(--app-text,#0F172A)] font-sans overflow-x-hidden transition-colors duration-200">
      {/* Centered Login Card Container (compact, max-width 390px mobile to 420px desktop) */}
      <div className="w-full max-w-[390px] sm:max-w-[420px]">
        <div className="bg-[var(--app-surface-card,#FFFFFF)] rounded-2xl shadow-sm border border-[var(--app-border,#E2E8F0)] p-6 sm:p-7 transition-colors duration-200">
          {/* Corporate Branding Header */}
          <header className="text-center mb-5">
            {/* Logo Container (Transparent, No Border/Ring/Shadow, Enlarged) */}
            <div className="flex justify-center mb-3">
              <div
                className="flex items-center justify-center bg-transparent shrink-0"
                aria-hidden="true"
              >
                <img
                  src={logoUrl}
                  alt={englishCompanyName}
                  className="h-24 sm:h-28 w-auto max-w-[140px] sm:max-w-[160px] object-contain select-none transition-transform duration-200"
                  referrerPolicy="no-referrer"
                  onError={(e) => {
                    const target = e.currentTarget;
                    if (target.src.endsWith('.png')) target.src = '/sarwan-logo.svg';
                  }}
                />
              </div>
            </div>

            {/* Company-Name Line Beneath the Logo with Logo Brand Colors */}
            <div className="mt-1">
              <h1
                id="login-company-name-en"
                dir="ltr"
                className="text-xl sm:text-2xl font-bold tracking-tight leading-snug break-words px-2 text-center"
                style={{ fontFamily: 'var(--font-family-primary)' }}
              >
                {renderLogoBrandedName(englishCompanyName)}
              </h1>
            </div>
          </header>

          {/* Error Notice */}
          {displayError && (
            <div
              role="alert"
              className="mb-4 p-3 bg-red-50 dark:bg-red-950/40 border border-red-200 dark:border-red-900/60 text-red-700 dark:text-red-300 text-xs rounded-xl flex items-start gap-2.5 transition-colors"
            >
              <AlertCircle className="w-4 h-4 shrink-0 text-red-500 dark:text-red-400 mt-0.5" />
              <div className="flex-1 font-medium text-start leading-relaxed">
                {displayError}
              </div>
              <button
                type="button"
                onClick={() => {
                  setLocalError(null);
                  clearError();
                }}
                className="text-[11px] font-bold text-red-600 dark:text-red-400 hover:text-red-800 dark:hover:text-red-200 cursor-pointer ms-1 focus:outline-none"
              >
                Dismiss
              </button>
            </div>
          )}

          {/* Primary Authentication Form */}
          <form onSubmit={handleUsernamePasswordLogin} className="space-y-4">
            {/* Username or Email Input */}
            <div>
              <label
                htmlFor="usernameOrEmail"
                className="block text-xs font-semibold text-[var(--app-text-secondary,#475569)] mb-1.5 text-start"
              >
                Username or Email
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 start-0 ps-3.5 flex items-center pointer-events-none text-[var(--app-text-muted,#94A3B8)]">
                  <UserIcon className="w-4 h-4 shrink-0" />
                </div>
                <input
                  id="usernameOrEmail"
                  type="text"
                  required
                  autoComplete="username"
                  value={usernameOrEmail ?? ''}
                  onChange={(e) => {
                    setUsernameOrEmail(e.target.value);
                    if (localError) setLocalError(null);
                  }}
                  placeholder="Enter your username or email"
                  className="w-full h-11 ps-10 pe-3.5 text-xs sm:text-sm bg-[var(--app-surface-input,#FFFFFF)] border border-[var(--app-border,#CBD5E1)] rounded-xl focus:outline-none focus:border-[#2563EB] focus:ring-2 focus:ring-[#2563EB]/20 transition-all text-[var(--app-text-primary,#0F172A)] placeholder:text-[var(--app-text-muted,#94A3B8)] text-start"
                />
              </div>
            </div>

            {/* Password Input */}
            <div>
              <div className="flex items-center justify-between mb-1.5">
                <label
                  htmlFor="loginPassword"
                  className="block text-xs font-semibold text-[var(--app-text-secondary,#475569)] text-start"
                >
                  Password
                </label>
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  aria-label={showPassword ? 'Hide password' : 'Show password'}
                  className="text-[11px] text-[var(--app-text-muted,#64748B)] hover:text-[var(--app-text-primary,#0F172A)] font-medium flex items-center gap-1 cursor-pointer transition focus:outline-none"
                >
                  {showPassword ? (
                    <EyeOff className="w-3.5 h-3.5 shrink-0" />
                  ) : (
                    <Eye className="w-3.5 h-3.5 shrink-0" />
                  )}
                  <span>{showPassword ? 'Hide' : 'Show'}</span>
                </button>
              </div>
              <div className="relative">
                <div className="absolute inset-y-0 start-0 ps-3.5 flex items-center pointer-events-none text-[var(--app-text-muted,#94A3B8)]">
                  <Lock className="w-4 h-4 shrink-0" />
                </div>
                <input
                  id="loginPassword"
                  type={showPassword ? 'text' : 'password'}
                  required
                  autoComplete="current-password"
                  value={password ?? ''}
                  onChange={(e) => {
                    setPassword(e.target.value);
                    if (localError) setLocalError(null);
                  }}
                  placeholder="Enter your password"
                  className="w-full h-11 ps-10 pe-3.5 text-xs sm:text-sm bg-[var(--app-surface-input,#FFFFFF)] border border-[var(--app-border,#CBD5E1)] rounded-xl focus:outline-none focus:border-[#2563EB] focus:ring-2 focus:ring-[#2563EB]/20 transition-all text-[var(--app-text-primary,#0F172A)] placeholder:text-[var(--app-text-muted,#94A3B8)] text-start"
                />
              </div>
            </div>

            {/* Primary Sign In Button: Soft Modern #2563EB */}
            <button
              id="signin-submit-btn"
              type="submit"
              disabled={submitting || authLoading}
              className="w-full h-11 px-4 bg-[#2563EB] hover:bg-[#1D4ED8] active:bg-[#1E40AF] text-white text-xs sm:text-sm font-semibold rounded-xl shadow-xs hover:shadow transition-all duration-150 flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed active:scale-[0.99] mt-1 focus:outline-none focus-visible:ring-2 focus-visible:ring-[#2563EB] focus-visible:ring-offset-2 dark:focus-visible:ring-offset-[#131E32]"
            >
              {submitting ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin shrink-0" />
                  <span>Verifying Credentials...</span>
                </>
              ) : (
                <>
                  <LogIn className="w-4 h-4 shrink-0" />
                  <span>Sign In</span>
                </>
              )}
            </button>
          </form>

          {/* Subtle Divider */}
          <div className="relative flex items-center justify-center my-5" aria-hidden="true">
            <div className="border-t border-[var(--app-border,#E2E8F0)] w-full" />
            <span className="bg-[var(--app-surface-card,#FFFFFF)] px-3 text-[11px] text-[var(--app-text-muted,#64748B)] font-medium uppercase tracking-wider whitespace-nowrap select-none transition-colors">
              or
            </span>
            <div className="border-t border-[var(--app-border,#E2E8F0)] w-full" />
          </div>

          {/* Google Authentication Section */}
          <div>
            <button
              id="google-signin-btn"
              type="button"
              onClick={handleGoogleSignIn}
              disabled={googleSubmitting || submitting || authLoading}
              className="w-full h-11 px-4 bg-[var(--app-surface-card,#FFFFFF)] hover:bg-[var(--app-bg-muted,#F1F5F9)] text-[var(--app-text-primary,#0F172A)] text-xs sm:text-sm font-semibold rounded-xl border border-[var(--app-border,#CBD5E1)] hover:border-[var(--app-border-strong,#94A3B8)] shadow-2xs hover:shadow-xs transition-all duration-150 flex items-center justify-center gap-2.5 cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed active:scale-[0.99] focus:outline-none focus-visible:ring-2 focus-visible:ring-[var(--app-border-strong,#94A3B8)] focus-visible:ring-offset-2 dark:focus-visible:ring-offset-[#131E32]"
            >
              {googleSubmitting ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin shrink-0 text-[var(--app-text-muted,#64748B)]" />
                  <span>Verifying Google Account...</span>
                </>
              ) : (
                <>
                  <svg className="w-4 h-4 shrink-0" viewBox="0 0 24 24" aria-hidden="true">
                    <path
                      fill="#4285F4"
                      d="M23.745 12.27c0-.7-.06-1.4-.19-2.07H12v4.51h6.6c-.29 1.52-1.14 2.82-2.4 3.68v3.05h3.88c2.27-2.09 3.66-5.17 3.66-9.17z"
                    />
                    <path
                      fill="#34A853"
                      d="M12 24c3.24 0 5.95-1.08 7.93-2.91l-3.88-3.05c-1.08.72-2.45 1.16-4.05 1.16-3.12 0-5.77-2.1-6.72-4.93H1.25v3.15C3.26 21.36 7.33 24 12 24z"
                    />
                    <path
                      fill="#FBBC05"
                      d="M5.28 14.27c-.25-.72-.38-1.49-.38-2.27s.13-1.55.38-2.27V6.58H1.25C.45 8.18 0 9.99 0 12s.45 3.82 1.25 5.42l4.03-3.15z"
                    />
                    <path
                      fill="#EA4335"
                      d="M12 4.75c1.77 0 3.35.61 4.6 1.8l3.42-3.42C17.95 1.19 15.24 0 12 0 7.33 0 3.26 2.64 1.25 6.58l4.03 3.15c.95-2.83 3.6-4.98 6.72-4.98z"
                    />
                  </svg>
                  <span>Sign in with Google</span>
                </>
              )}
            </button>
          </div>
        </div>

        {/* Minimal Copyright Footer */}
        <footer className="mt-6 text-center text-[var(--app-text-muted,#64748B)] select-none">
          <p className="text-[10px]">
            &copy; {new Date().getFullYear()} Sarwan Technology. All rights reserved.
          </p>
        </footer>
      </div>
    </div>
  );
};
