import React from 'react';
import { InvoiceDesignerView, InvoiceDesignerViewProps, mergeDesignSettings } from './InvoiceDesignerView';

export interface InvoiceDesignerSettingsViewProps extends InvoiceDesignerViewProps {}

export const InvoiceDesignerSettingsView: React.FC<InvoiceDesignerSettingsViewProps> = (props) => {
  return <InvoiceDesignerView {...props} />;
};

export { mergeDesignSettings, InvoiceDesignerView };
export default InvoiceDesignerSettingsView;
