import React, { useState } from 'react';
import {
  Bell,
  CheckCheck,
  Filter,
  FileText,
  DollarSign,
  Receipt,
  MessageSquare,
  Shield,
  Clock,
  ChevronRight,
  ArrowLeft,
  Sparkles,
} from 'lucide-react';
import { AppNotification } from '../types';
import { ActiveTab } from '../components/layout/Sidebar';

interface NotificationsViewProps {
  notifications: AppNotification[];
  onMarkNotificationRead?: (id: string) => void;
  onTabChange?: (tab: ActiveTab) => void;
}

export const NotificationsView: React.FC<NotificationsViewProps> = ({
  notifications = [],
  onMarkNotificationRead,
  onTabChange,
}) => {
  const [filterType, setFilterType] = useState<'all' | 'unread' | 'invoice' | 'payment' | 'expense' | 'system'>('all');

  const unreadCount = notifications.filter((n) => !n.isRead).length;

  const filteredNotifications = notifications.filter((notif) => {
    if (filterType === 'unread') return !notif.isRead;
    if (filterType === 'invoice') return notif.type === 'invoice';
    if (filterType === 'payment') return notif.type === 'payment';
    if (filterType === 'expense') return notif.type === 'expense';
    if (filterType === 'system') return notif.type === 'system' || notif.type === 'request' || notif.type === 'project';
    return true;
  });

  const getNotificationIcon = (type: AppNotification['type']) => {
    switch (type) {
      case 'invoice':
        return <FileText className="w-4 h-4 text-orange-600" />;
      case 'payment':
        return <DollarSign className="w-4 h-4 text-emerald-600" />;
      case 'expense':
        return <Receipt className="w-4 h-4 text-rose-600" />;
      case 'request':
        return <MessageSquare className="w-4 h-4 text-amber-600" />;
      case 'project':
        return <Sparkles className="w-4 h-4 text-sky-600" />;
      default:
        return <Shield className="w-4 h-4 text-neutral-600" />;
    }
  };

  const handleNotificationClick = (notif: AppNotification) => {
    if (!notif.isRead && onMarkNotificationRead) {
      onMarkNotificationRead(notif.id);
    }
    if (!onTabChange) return;

    if (notif.type === 'invoice') onTabChange('invoices');
    else if (notif.type === 'payment') onTabChange('payments');
    else if (notif.type === 'expense') onTabChange('invoices');
    else if (notif.type === 'request') onTabChange('requests');
    else if (notif.type === 'project') onTabChange('projects');
    else if (notif.type === 'system') onTabChange('audit');
  };

  const handleMarkAllRead = () => {
    if (!onMarkNotificationRead) return;
    notifications.filter((n) => !n.isRead).forEach((n) => onMarkNotificationRead(n.id));
  };

  return (
    <div className="space-y-6 max-w-5xl mx-auto">
      {/* Header bar */}
      <div className="bg-white rounded-xl p-5 border border-neutral-200 shadow-xs flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          {onTabChange && (
            <button
              type="button"
              onClick={() => onTabChange('dashboard')}
              className="p-2 rounded-lg bg-neutral-100 hover:bg-neutral-200 text-neutral-600 hover:text-neutral-900 transition cursor-pointer"
              title="Return to Dashboard"
            >
              <ArrowLeft className="w-4 h-4" />
            </button>
          )}
          <div className="p-2.5 bg-orange-50 text-[#F58220] rounded-xl border border-orange-100">
            <Bell className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-lg font-bold text-neutral-900">Notifications &amp; Activity Alerts</h1>
              {unreadCount > 0 && (
                <span className="px-2 py-0.5 bg-orange-100 text-orange-700 font-bold text-xs rounded-full">
                  {unreadCount} unread
                </span>
              )}
            </div>
            <p className="text-xs text-neutral-500 mt-0.5">
              Real-time transaction alerts, invoice issuances, cash receipts, and system events.
            </p>
          </div>
        </div>

        {unreadCount > 0 && onMarkNotificationRead && (
          <button
            type="button"
            onClick={handleMarkAllRead}
            className="px-3 py-1.5 bg-neutral-100 hover:bg-neutral-200 active:bg-neutral-300 text-neutral-800 text-xs font-semibold rounded-lg transition inline-flex items-center gap-1.5 cursor-pointer shrink-0"
          >
            <CheckCheck className="w-4 h-4 text-blue-600" />
            <span>Mark all as read</span>
          </button>
        )}
      </div>

      {/* Filter Tabs */}
      <div className="flex items-center gap-2 overflow-x-auto pb-1 text-xs">
        <button
          type="button"
          onClick={() => setFilterType('all')}
          className={`px-3 py-1.5 rounded-lg font-medium transition cursor-pointer shrink-0 ${
            filterType === 'all'
              ? 'bg-[#2563EB] text-white font-bold shadow-xs'
              : 'bg-white border border-neutral-200 text-neutral-600 hover:bg-neutral-50'
          }`}
        >
          All ({notifications.length})
        </button>
        <button
          type="button"
          onClick={() => setFilterType('unread')}
          className={`px-3 py-1.5 rounded-lg font-medium transition cursor-pointer shrink-0 ${
            filterType === 'unread'
              ? 'bg-[#2563EB] text-white font-bold shadow-xs'
              : 'bg-white border border-neutral-200 text-neutral-600 hover:bg-neutral-50'
          }`}
        >
          Unread ({unreadCount})
        </button>
        <button
          type="button"
          onClick={() => setFilterType('invoice')}
          className={`px-3 py-1.5 rounded-lg font-medium transition cursor-pointer shrink-0 ${
            filterType === 'invoice'
              ? 'bg-[#2563EB] text-white font-bold shadow-xs'
              : 'bg-white border border-neutral-200 text-neutral-600 hover:bg-neutral-50'
          }`}
        >
          Invoices
        </button>
        <button
          type="button"
          onClick={() => setFilterType('payment')}
          className={`px-3 py-1.5 rounded-lg font-medium transition cursor-pointer shrink-0 ${
            filterType === 'payment'
              ? 'bg-[#2563EB] text-white font-bold shadow-xs'
              : 'bg-white border border-neutral-200 text-neutral-600 hover:bg-neutral-50'
          }`}
        >
          Payments
        </button>
        <button
          type="button"
          onClick={() => setFilterType('expense')}
          className={`px-3 py-1.5 rounded-lg font-medium transition cursor-pointer shrink-0 ${
            filterType === 'expense'
              ? 'bg-[#2563EB] text-white font-bold shadow-xs'
              : 'bg-white border border-neutral-200 text-neutral-600 hover:bg-neutral-50'
          }`}
        >
          Expenses
        </button>
        <button
          type="button"
          onClick={() => setFilterType('system')}
          className={`px-3 py-1.5 rounded-lg font-medium transition cursor-pointer shrink-0 ${
            filterType === 'system'
              ? 'bg-[#2563EB] text-white font-bold shadow-xs'
              : 'bg-white border border-neutral-200 text-neutral-600 hover:bg-neutral-50'
          }`}
        >
          System &amp; Tasks
        </button>
      </div>

      {/* Notifications list */}
      <div className="bg-white rounded-xl border border-neutral-200 shadow-xs divide-y divide-neutral-100 overflow-hidden">
        {filteredNotifications.length === 0 ? (
          <div className="p-12 text-center text-neutral-400">
            <Bell className="w-10 h-10 mx-auto mb-3 text-neutral-300" />
            <p className="font-semibold text-neutral-700 text-sm">No notifications found</p>
            <p className="text-xs text-neutral-400 mt-1">
              You are completely up to date. Transactions and status updates will be logged here.
            </p>
          </div>
        ) : (
          filteredNotifications.map((notif) => (
            <div
              key={notif.id}
              onClick={() => handleNotificationClick(notif)}
              className={`p-4 hover:bg-neutral-50 transition cursor-pointer flex items-start gap-3.5 ${
                !notif.isRead ? 'bg-orange-50/40' : ''
              }`}
            >
              <div
                className={`p-2 rounded-xl shrink-0 border ${
                  !notif.isRead
                    ? 'bg-orange-100/70 border-orange-200'
                    : 'bg-neutral-100 border-neutral-200'
                }`}
              >
                {getNotificationIcon(notif.type)}
              </div>

              <div className="flex-1 min-w-0">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-1 sm:gap-2">
                  <div className="flex items-center gap-2 min-w-0">
                    <h3 className={`text-sm break-words [overflow-wrap:anywhere] ${!notif.isRead ? 'font-bold text-neutral-900' : 'font-medium text-neutral-800'}`}>
                      {notif.title}
                    </h3>
                    {!notif.isRead && (
                      <span className="w-2 h-2 rounded-full bg-orange-500 shrink-0" />
                    )}
                  </div>
                  <div className="flex items-center gap-1 text-[11px] text-neutral-400 shrink-0">
                    <Clock className="w-3 h-3" />
                    <span>{new Date(notif.createdAt).toLocaleString()}</span>
                  </div>
                </div>

                <p className="text-xs text-neutral-600 mt-1 leading-relaxed break-words [overflow-wrap:anywhere]">
                  {notif.message}
                </p>
              </div>

              <ChevronRight className="w-4 h-4 text-neutral-300 shrink-0 self-center" />
            </div>
          ))
        )}
      </div>
    </div>
  );
};
