import React, { useState, useEffect } from 'react';
import { BusinessSettings } from '../types';
import { updateBusinessSettings } from '../services/db';
import { PRIMARY_ADMIN_EMAILS, useAuth } from '../context/AuthContext';
import { changeAdminCode } from '../services/security';
import { toast } from '../context/ToastContext';
import {
  Settings,
  Building,
  Phone,
  Mail,
  MapPin,
  FileText,
  Save,
  CheckCircle,
  AlertCircle,
  Users,
  Plus,
  Trash2,
  Shield,
  Sparkles,
  Palette,
  KeyRound,
  Eye,
  EyeOff,
  Lock,
  Loader2,
} from 'lucide-react';
import { ThemeSettingsSection } from '../components/theme/ThemeSettingsSection';

interface SettingsViewProps {
  settings: BusinessSettings;
}

export const SettingsView: React.FC<SettingsViewProps> = ({ settings }) => {
  const { userProfile, isSuperAdmin } = useAuth();
  const [activeSubTab, setActiveSubTab] = useState<'general' | 'security' | 'themes'>('general');
  const [companyName, setCompanyName] = useState<string>(settings.companyName || 'Sarwan Technology');
  const [phone, setPhone] = useState<string>(settings.phone || '0731339014');
  const [whatsapp, setWhatsapp] = useState<string>(settings.whatsapp || '0778771020');
  const [email, setEmail] = useState<string>(settings.email || 'Sarwantechnology.af@gmail.com');
  const [address, setAddress] = useState<string>(settings.address || 'Kabul, Afghanistan');
  const [website, setWebsite] = useState<string>(settings.website || 'https://sarwantechnology.af');
  const [invoiceNote, setInvoiceNote] = useState<string>(settings.invoiceNote || 'Thank you for choosing Sarwan Technology.');
  const [footerText, setFooterText] = useState<string>(
    settings.footerText || 'Sarwan Technology - Comprehensive Security & Surveillance Solutions'
  );
  const [invoicePrefix, setInvoicePrefix] = useState<string>(settings.invoicePrefix || 'ST-');
  const [nextInvoiceNumber, setNextInvoiceNumber] = useState<number>(settings.nextInvoiceNumber || 1060);
  const [logo, setLogo] = useState<string>(settings.logo || '/sarwan-logo.png');
  const [logo2, setLogo2] = useState<string>(settings.logo2 || '/dahua-logo.svg');

  const [loginTitle, setLoginTitle] = useState<string>(settings.loginTitle || 'SARWAN TECHNOLOGY');
  const [loginSubtitle, setLoginSubtitle] = useState<string>(
    settings.loginSubtitle || 'Billing & Business Management System'
  );
  const [loginWelcome, setLoginWelcome] = useState<string>(
    settings.loginWelcome || 'Security Surveillance & Technology Equipment Supplier'
  );

  const [authorizedEmails, setAuthorizedEmails] = useState<string[]>(
    settings.authorizedEmails || ['bilalsarwan7@gmail.com']
  );
  const [newEmailInput, setNewEmailInput] = useState<string>('');

  const [saving, setSaving] = useState<boolean>(false);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  // Super Admin Admin Code management
  const [currentAdminCode, setCurrentAdminCode] = useState<string>('');
  const [newAdminCode, setNewAdminCode] = useState<string>('');
  const [confirmAdminCode, setConfirmAdminCode] = useState<string>('');
  const [showCurrentCode, setShowCurrentCode] = useState<boolean>(false);
  const [showNewCode, setShowNewCode] = useState<boolean>(false);
  const [updatingAdminCode, setUpdatingAdminCode] = useState<boolean>(false);
  const [adminCodeMsg, setAdminCodeMsg] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  const handleChangeAdminCode = async (e: React.FormEvent) => {
    e.preventDefault();
    setAdminCodeMsg(null);

    if (!currentAdminCode.trim()) {
      setAdminCodeMsg({ type: 'error', text: 'Please enter the current Admin Code.' });
      return;
    }
    if (!newAdminCode.trim() || newAdminCode.length < 8) {
      setAdminCodeMsg({ type: 'error', text: 'The new Admin Code must be at least 8 characters long.' });
      return;
    }
    if (newAdminCode !== confirmAdminCode) {
      setAdminCodeMsg({ type: 'error', text: 'New Admin Code and confirmation do not match.' });
      return;
    }
    if (newAdminCode === currentAdminCode) {
      setAdminCodeMsg({
        type: 'error',
        text: 'The new Admin Code must be different from the current Admin Code.',
      });
      return;
    }

    setUpdatingAdminCode(true);
    try {
      await changeAdminCode({
        currentCode: currentAdminCode.trim(),
        newCode: newAdminCode.trim(),
        confirmCode: confirmAdminCode.trim(),
        superAdminUid: userProfile?.id || 'super_admin',
        superAdminName: userProfile?.name || 'Super Admin',
      });
      setAdminCodeMsg({
        type: 'success',
        text: 'Super Admin Admin Code updated successfully. The previous code has been invalidated immediately.',
      });
      setCurrentAdminCode('');
      setNewAdminCode('');
      setConfirmAdminCode('');
    } catch (err: any) {
      setAdminCodeMsg({ type: 'error', text: err.message || 'Failed to update Admin Code.' });
    } finally {
      setUpdatingAdminCode(false);
    }
  };

  useEffect(() => {
    setCompanyName(settings.companyName || 'Sarwan Technology');
    setPhone(settings.phone || '0731339014');
    setWhatsapp(settings.whatsapp || '0778771020');
    setEmail(settings.email || 'Sarwantechnology.af@gmail.com');
    setAddress(settings.address || 'Kabul, Afghanistan');
    setWebsite(settings.website || 'https://sarwantechnology.af');
    setInvoiceNote(settings.invoiceNote || 'Thank you for choosing Sarwan Technology.');
    setFooterText(
      settings.footerText || 'Sarwan Technology - Comprehensive Security & Surveillance Solutions'
    );
    setInvoicePrefix(settings.invoicePrefix || 'ST-');
    setNextInvoiceNumber(settings.nextInvoiceNumber || 1060);
    setAuthorizedEmails(settings.authorizedEmails || ['bilalsarwan7@gmail.com']);
    setLogo(settings.logo || '/sarwan-logo.png');
    setLogo2(settings.logo2 || '/dahua-logo.svg');
    setLoginTitle(settings.loginTitle || 'SARWAN TECHNOLOGY');
    setLoginSubtitle(settings.loginSubtitle || 'Billing & Business Management System');
    setLoginWelcome(
      settings.loginWelcome || 'Security Surveillance & Technology Equipment Supplier'
    );
  }, [settings]);

  const handleLogoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('image/')) {
      setErrorMessage('Please upload a valid image file (PNG, JPG, or SVG).');
      return;
    }

    const reader = new FileReader();
    reader.onload = async (event) => {
      const dataUrl = event.target?.result as string;
      if (dataUrl) {
        setLogo(dataUrl);
        try {
          await updateBusinessSettings(
            { logo: dataUrl },
            userProfile?.id,
            userProfile?.name || userProfile?.username,
            userProfile?.role || 'super_admin',
            userProfile?.email || userProfile?.authEmail || userProfile?.googleEmail
          );
          setSuccessMessage('Official logo uploaded and synchronized across the billing system!');
          toast.success('Official logo uploaded and synchronized across the billing system!');
          setTimeout(() => setSuccessMessage(null), 4000);
        } catch (err: any) {
          console.error('Error auto-updating logo:', err);
          toast.error('Failed to synchronize logo.');
        }
      }
    };
    reader.readAsDataURL(file);
  };

  const handleResetLogo = async () => {
    const defaultLogoPath = '/sarwan-logo.png';
    setLogo(defaultLogoPath);
    try {
      await updateBusinessSettings(
        { logo: defaultLogoPath },
        userProfile?.id,
        userProfile?.name || userProfile?.username,
        userProfile?.role || 'super_admin',
        userProfile?.email || userProfile?.authEmail || userProfile?.googleEmail
      );
      setSuccessMessage('Reset to original official Sarwan Technology logo asset.');
      toast.info('Reset to original official Sarwan Technology logo asset.');
      setTimeout(() => setSuccessMessage(null), 4000);
    } catch (err: any) {
      console.error('Error resetting logo:', err);
      toast.error('Failed to reset logo.');
    }
  };

  const handleAddEmail = (e: React.FormEvent) => {
    e.preventDefault();
    const emailToAdd = newEmailInput.trim().toLowerCase();
    if (!emailToAdd || !emailToAdd.includes('@')) {
      setErrorMessage('Please enter a valid Google email address.');
      return;
    }
    if (authorizedEmails.includes(emailToAdd)) {
      setErrorMessage('This email is already on the authorized list.');
      return;
    }

    setAuthorizedEmails([...authorizedEmails, emailToAdd]);
    setNewEmailInput('');
    setErrorMessage(null);
    toast.success(`Email ${emailToAdd} added to authorized list.`);
  };

  const handleRemoveEmail = (emailToRemove: string) => {
    if (PRIMARY_ADMIN_EMAILS.includes(emailToRemove.toLowerCase())) {
      toast.warning(`The primary administrator account (${emailToRemove}) cannot be removed.`);
      return;
    }
    setAuthorizedEmails(authorizedEmails.filter((e) => e !== emailToRemove));
    toast.info(`Email ${emailToRemove} removed from authorized list.`);
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    setSuccessMessage(null);
    setErrorMessage(null);

    try {
      await updateBusinessSettings(
        {
          companyName: companyName.trim(),
          logo: logo || '/sarwan-logo.png',
          logo2: logo2 || '/dahua-logo.svg',
          phone: phone.trim(),
          whatsapp: whatsapp.trim(),
          email: email.trim(),
          address: address.trim(),
          website: website.trim(),
          invoiceNote: invoiceNote.trim(),
          footerText: footerText.trim(),
          invoicePrefix: invoicePrefix.trim() || 'ST-',
          nextInvoiceNumber: Number(nextInvoiceNumber) || 1060,
          authorizedEmails,
          loginTitle: loginTitle.trim(),
          loginSubtitle: loginSubtitle.trim(),
          loginWelcome: loginWelcome.trim(),
          currency: 'AFN',
        },
        userProfile?.id,
        userProfile?.name || userProfile?.username,
        userProfile?.role || 'super_admin',
        userProfile?.email || userProfile?.authEmail || userProfile?.googleEmail
      );

      setSuccessMessage('Business settings saved successfully.');
      toast.success('Business settings saved successfully.');
      setTimeout(() => setSuccessMessage(null), 4000);
    } catch (err: any) {
      console.error('Error saving settings:', err);
      const errMsg = err.message || 'Failed to update settings.';
      setErrorMessage(errMsg);
      toast.error(errMsg);
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className={`${activeSubTab === 'invoice_design' ? 'w-full' : 'max-w-4xl'} space-y-6`}>
      {/* Header */}
      <div>
        <h1 className="text-xl font-bold text-[var(--app-text-primary,#0F172A)]">Settings &amp; Administration</h1>
        <p className="text-xs text-[var(--app-text-secondary,#475569)]">
          Configure business profile details, printable invoice layout, sequence numbers, and authorized user access.
        </p>
      </div>

      {/* Subtab Switcher */}
      <div className="flex items-center gap-2 border-b border-[var(--app-border,#E2E8F0)] pb-2 overflow-x-auto">
        <button
          type="button"
          onClick={() => setActiveSubTab('general')}
          className={`px-4 py-2 text-xs font-bold rounded-lg transition inline-flex items-center gap-2 whitespace-nowrap cursor-pointer ${
            activeSubTab === 'general'
              ? 'bg-[var(--color-primary,#2563EB)] text-white shadow-xs'
              : 'text-[var(--app-text-secondary,#475569)] hover:text-[var(--app-text-primary,#0F172A)] hover:bg-[var(--color-interactive-hover,#F1F5F9)]'
          }`}
        >
          <Settings className="w-3.5 h-3.5" />
          Company &amp; System Settings
        </button>

        <button
          type="button"
          onClick={() => setActiveSubTab('themes')}
          className={`px-4 py-2 text-xs font-bold rounded-lg transition inline-flex items-center gap-2 whitespace-nowrap cursor-pointer ${
            activeSubTab === 'themes'
              ? 'bg-[var(--color-primary,#2563EB)] text-white shadow-xs'
              : 'text-[var(--app-text-secondary,#475569)] hover:text-[var(--app-text-primary,#0F172A)] hover:bg-[var(--color-interactive-hover,#F1F5F9)]'
          }`}
        >
          <Palette className="w-3.5 h-3.5" />
          Theme &amp; Appearance
        </button>

        {isSuperAdmin && (
          <button
            type="button"
            onClick={() => setActiveSubTab('security')}
            className={`px-4 py-2 text-xs font-bold rounded-lg transition inline-flex items-center gap-2 whitespace-nowrap cursor-pointer ${
              activeSubTab === 'security'
                ? 'bg-[var(--color-primary,#2563EB)] text-white shadow-xs'
                : 'text-[var(--app-text-secondary,#475569)] hover:text-[var(--app-text-primary,#0F172A)] hover:bg-[var(--color-interactive-hover,#F1F5F9)]'
            }`}
          >
            <Shield className="w-3.5 h-3.5" />
            Security &amp; Super Admin
          </button>
        )}
      </div>

      {activeSubTab === 'security' && isSuperAdmin ? (
        <div className="space-y-6">
          {/* Breadcrumb indicator */}
          <div className="flex items-center gap-2 text-xs text-neutral-500 font-medium">
            <span>Settings</span>
            <span>&rarr;</span>
            <span>Security</span>
            <span>&rarr;</span>
            <span className="text-neutral-900 font-bold">Super Admin</span>
          </div>

          <div className="bg-[var(--app-surface-card,#FFFFFF)] p-6 rounded-xl border border-[var(--app-border,#E2E8F0)] shadow-xs space-y-5 transition-colors">
            <div className="flex items-center gap-3 border-b border-[var(--app-border-subtle,#F1F5F9)] pb-4">
              <div className="p-2.5 bg-[var(--brand-orange,#F7941D)]/10 text-[var(--brand-orange,#F7941D)] rounded-xl">
                <KeyRound className="w-5 h-5" />
              </div>
              <div>
                <h2 className="text-sm font-bold text-[var(--app-text-primary,#0F172A)]">
                  Super Admin Admin Code Management
                </h2>
                <p className="text-xs text-[var(--app-text-secondary,#475569)]">
                  Update and rotate the master Admin Code used for system bootstrap verification and security overrides.
                </p>
              </div>
            </div>

            {adminCodeMsg && (
              <div
                className={`p-3 rounded-xl text-xs font-semibold flex items-center gap-2 ${
                  adminCodeMsg.type === 'success'
                    ? 'bg-emerald-50 text-emerald-800 border border-emerald-200 dark:bg-emerald-950/60 dark:text-emerald-300 dark:border-emerald-800'
                    : 'bg-red-50 text-red-800 border border-red-200 dark:bg-red-950/60 dark:text-red-300 dark:border-red-800'
                }`}
              >
                {adminCodeMsg.type === 'success' ? (
                  <CheckCircle className="w-4 h-4 text-emerald-600 shrink-0" />
                ) : (
                  <AlertCircle className="w-4 h-4 text-red-600 shrink-0" />
                )}
                <span>{adminCodeMsg.text}</span>
              </div>
            )}

            <div className="p-4 bg-[var(--app-bg-muted,#F1F5F9)] rounded-xl border border-[var(--app-border,#E2E8F0)] text-xs text-[var(--app-text-secondary,#475569)] space-y-1.5 leading-relaxed">
              <div className="flex items-center gap-1.5 font-bold text-[var(--app-text-primary,#0F172A)]">
                <Lock className="w-3.5 h-3.5 text-[var(--brand-orange,#F7941D)]" />
                <span>Security Protocol &amp; Rotation Guidelines</span>
              </div>
              <p>
                The Admin Code is stored as a SHA-256 cryptographic hash and is never shown in plaintext.
                When rotated, the previous code becomes invalid immediately.
              </p>
            </div>

            <form onSubmit={handleChangeAdminCode} className="space-y-4 max-w-md">
              {/* Current Admin Code */}
              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="block text-xs font-semibold text-[var(--app-text-secondary,#475569)]">
                    Current Admin Code
                  </label>
                  <button
                    type="button"
                    onClick={() => setShowCurrentCode(!showCurrentCode)}
                    className="text-[11px] text-[var(--app-text-muted,#64748B)] hover:text-[var(--app-text-primary,#0F172A)] font-medium cursor-pointer"
                  >
                    {showCurrentCode ? 'Hide' : 'Show'}
                  </button>
                </div>
                <div className="relative">
                  <input
                    type={showCurrentCode ? 'text' : 'password'}
                    required
                    value={currentAdminCode ?? ''}
                    onChange={(e) => setCurrentAdminCode(e.target.value)}
                    placeholder="Enter current Admin Code"
                    className="w-full px-3 py-2 text-xs bg-[var(--app-surface-input,#FFFFFF)] border border-[var(--app-border,#CBD5E1)] text-[var(--app-text-primary,#0F172A)] rounded-lg focus:outline-none focus:ring-1 focus:ring-[var(--brand-orange,#F7941D)] font-mono"
                  />
                </div>
              </div>

              {/* New Admin Code */}
              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="block text-xs font-semibold text-[var(--app-text-secondary,#475569)]">
                    New Admin Code
                  </label>
                  <button
                    type="button"
                    onClick={() => setShowNewCode(!showNewCode)}
                    className="text-[11px] text-[var(--app-text-muted,#64748B)] hover:text-[var(--app-text-primary,#0F172A)] font-medium cursor-pointer"
                  >
                    {showNewCode ? 'Hide' : 'Show'}
                  </button>
                </div>
                <input
                  type={showNewCode ? 'text' : 'password'}
                  required
                  value={newAdminCode ?? ''}
                  onChange={(e) => setNewAdminCode(e.target.value)}
                  placeholder="Enter new Admin Code (min 8 characters)"
                  className="w-full px-3 py-2 text-xs bg-[var(--app-surface-input,#FFFFFF)] border border-[var(--app-border,#CBD5E1)] text-[var(--app-text-primary,#0F172A)] rounded-lg focus:outline-none focus:ring-1 focus:ring-[var(--brand-orange,#F7941D)] font-mono"
                />
              </div>

              {/* Confirm New Admin Code */}
              <div>
                <label className="block text-xs font-semibold text-[var(--app-text-secondary,#475569)] mb-1">
                  Confirm New Admin Code
                </label>
                <input
                  type={showNewCode ? 'text' : 'password'}
                  required
                  value={confirmAdminCode ?? ''}
                  onChange={(e) => setConfirmAdminCode(e.target.value)}
                  placeholder="Confirm new Admin Code"
                  className="w-full px-3 py-2 text-xs bg-[var(--app-surface-input,#FFFFFF)] border border-[var(--app-border,#CBD5E1)] text-[var(--app-text-primary,#0F172A)] rounded-lg focus:outline-none focus:ring-1 focus:ring-[var(--brand-orange,#F7941D)] font-mono"
                />
              </div>

              <div className="pt-2">
                <button
                  type="submit"
                  disabled={updatingAdminCode}
                  className="px-5 py-2.5 bg-[var(--color-primary,#2563EB)] hover:bg-[var(--color-primary-hover,#1D4ED8)] active:bg-[var(--color-primary-active,#1E40AF)] text-white text-xs font-bold rounded-lg shadow-xs transition flex items-center gap-2 cursor-pointer disabled:opacity-50 focus:outline-none focus-visible:ring-2 focus-visible:ring-[var(--color-primary,#2563EB)]"
                >
                  {updatingAdminCode ? (
                    <>
                      <Loader2 className="w-3.5 h-3.5 animate-spin" />
                      <span>Verifying &amp; Rotating...</span>
                    </>
                  ) : (
                    <>
                      <Save className="w-3.5 h-3.5 text-white" />
                      <span>Save New Admin Code</span>
                    </>
                  )}
                </button>
              </div>
            </form>
          </div>
        </div>
      ) : activeSubTab === 'themes' ? (
        <ThemeSettingsSection />
      ) : (

        <>
          {successMessage && (
            <div className="p-3 bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs rounded-xl flex items-center gap-2">
              <CheckCircle className="w-4 h-4 text-emerald-600 shrink-0" />
              <span>{successMessage}</span>
            </div>
          )}

          {errorMessage && (
            <div className="p-3 bg-red-50 border border-red-200 text-red-800 text-xs rounded-xl flex items-center gap-2">
              <AlertCircle className="w-4 h-4 text-red-600 shrink-0" />
              <span>{errorMessage}</span>
            </div>
          )}

          <form onSubmit={handleSave} className="space-y-6">
        {/* Section 1: Official Logo & Company Identity */}
        <div className="bg-[var(--app-surface-card,#FFFFFF)] p-6 rounded-xl border border-[var(--app-border,#E2E8F0)] shadow-xs space-y-4 transition-colors">
          <div className="flex items-center gap-2 border-b border-[var(--app-border-subtle,#F1F5F9)] pb-3">
            <Building className="w-4 h-4 text-[var(--brand-orange,#F7941D)]" />
            <h2 className="text-sm font-bold text-[var(--app-text-primary,#0F172A)]">Company Identity &amp; Branding</h2>
          </div>

          <div className="flex flex-col sm:flex-row items-center gap-6 pt-1">
            <div className="flex flex-col items-center justify-center shrink-0">
              <div
                className="w-24 h-24 bg-white flex items-center justify-center overflow-hidden p-1.5 shadow-xs"
                style={{ borderRadius: '100%', border: 'none' }}
              >
                <img
                  src={logo || '/sarwan-logo.png'}
                  alt="Official Sarwan Logo"
                  className="max-h-full max-w-full object-contain mx-auto"
                  onError={(e) => {
                    const target = e.currentTarget;
                    if (target.src.endsWith('.png')) target.src = '/sarwan-logo.svg';
                  }}
                />
              </div>
              <span className="text-[10px] text-neutral-500 mt-2 font-medium">Official Company Logo</span>
            </div>
            <div className="flex-1 text-xs text-neutral-600 space-y-2">
              <div className="space-y-1">
                <p className="font-bold text-neutral-900">Official Sarwan Technology Logo Asset</p>
                <p className="text-neutral-500 leading-relaxed">
                  Strictly preserved with original black and orange colors, CCTV camera emblem, modern cityscape,
                  and exact typography. Never distorted, stretched, or recolored across invoices, dashboard, or printouts.
                </p>
              </div>
              <div className="flex flex-wrap items-center gap-2 pt-1">
                <label className="px-3 py-1.5 bg-[var(--color-primary,#2563EB)] hover:bg-[var(--color-primary-hover,#1D4ED8)] active:bg-[var(--color-primary-active,#1E40AF)] text-white text-xs font-semibold rounded-lg cursor-pointer transition flex items-center gap-1.5 shadow-xs focus-within:ring-2 focus-within:ring-[var(--color-primary,#2563EB)]">
                  <span>Upload Logo Image</span>
                  <input
                    type="file"
                    accept="image/png,image/jpeg,image/svg+xml,image/webp"
                    className="hidden"
                    onChange={handleLogoUpload}
                  />
                </label>
                <button
                  type="button"
                  onClick={handleResetLogo}
                  className="px-3 py-1.5 bg-[var(--app-bg-muted,#F1F5F9)] hover:bg-[var(--color-interactive-active,#E2E8F0)] text-[var(--app-text-secondary,#475569)] text-xs font-semibold rounded-lg transition border border-[var(--app-border,#CBD5E1)]"
                >
                  Reset to Default Asset
                </button>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
            <div>
              <label className="text-xs font-semibold text-[var(--app-text-secondary,#475569)] block mb-1">
                Company Name *
              </label>
              <input
                type="text"
                required
                value={companyName ?? ''}
                onChange={(e) => setCompanyName(e.target.value)}
                className="w-full text-xs border border-[var(--app-border,#CBD5E1)] bg-[var(--app-surface-input,#FFFFFF)] text-[var(--app-text-primary,#0F172A)] rounded-lg px-3 py-2 focus:outline-none focus:ring-1 focus:ring-[var(--brand-orange,#F7941D)]"
              />
            </div>
            <div>
              <label className="text-xs font-semibold text-[var(--app-text-secondary,#475569)] block mb-1">
                Official Email *
              </label>
              <input
                type="email"
                required
                value={email ?? ''}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full text-xs border border-[var(--app-border,#CBD5E1)] bg-[var(--app-surface-input,#FFFFFF)] text-[var(--app-text-primary,#0F172A)] rounded-lg px-3 py-2 focus:outline-none focus:ring-1 focus:ring-[var(--brand-orange,#F7941D)] font-mono"
              />
            </div>
            <div>
              <label className="text-xs font-semibold text-[var(--app-text-secondary,#475569)] block mb-1">
                Phone Number *
              </label>
              <input
                type="text"
                required
                value={phone ?? ''}
                onChange={(e) => setPhone(e.target.value)}
                className="w-full text-xs border border-[var(--app-border,#CBD5E1)] bg-[var(--app-surface-input,#FFFFFF)] text-[var(--app-text-primary,#0F172A)] rounded-lg px-3 py-2 focus:outline-none focus:ring-1 focus:ring-[var(--brand-orange,#F7941D)] font-mono"
              />
            </div>
            <div>
              <label className="text-xs font-semibold text-[var(--app-text-secondary,#475569)] block mb-1">
                WhatsApp Number *
              </label>
              <input
                type="text"
                required
                value={whatsapp ?? ''}
                onChange={(e) => setWhatsapp(e.target.value)}
                className="w-full text-xs border border-[var(--app-border,#CBD5E1)] bg-[var(--app-surface-input,#FFFFFF)] text-[var(--app-text-primary,#0F172A)] rounded-lg px-3 py-2 focus:outline-none focus:ring-1 focus:ring-[var(--brand-orange,#F7941D)] font-mono"
              />
            </div>
            <div className="sm:col-span-2">
              <label className="text-xs font-semibold text-[var(--app-text-secondary,#475569)] block mb-1">
                Official Website
              </label>
              <input
                type="url"
                value={website ?? ''}
                onChange={(e) => setWebsite(e.target.value)}
                placeholder="e.g. https://sarwantechnology.af"
                className="w-full text-xs border border-[var(--app-border,#CBD5E1)] bg-[var(--app-surface-input,#FFFFFF)] text-[var(--app-text-primary,#0F172A)] rounded-lg px-3 py-2 focus:outline-none focus:ring-1 focus:ring-[var(--brand-orange,#F7941D)] font-mono"
              />
            </div>
            <div className="sm:col-span-2">
              <label className="text-xs font-semibold text-[var(--app-text-secondary,#475569)] block mb-1">
                Business Address
              </label>
              <input
                type="text"
                value={address ?? ''}
                onChange={(e) => setAddress(e.target.value)}
                placeholder="e.g. Kabul, Afghanistan"
                className="w-full text-xs border border-[var(--app-border,#CBD5E1)] bg-[var(--app-surface-input,#FFFFFF)] text-[var(--app-text-primary,#0F172A)] rounded-lg px-3 py-2 focus:outline-none focus:ring-1 focus:ring-[var(--brand-orange,#F7941D)]"
              />
            </div>
          </div>
        </div>

        {/* Section 2: Invoice & Numbering Rules */}
        <div className="bg-[var(--app-surface-card,#FFFFFF)] p-6 rounded-xl border border-[var(--app-border,#E2E8F0)] shadow-xs space-y-4 transition-colors">
          <div className="flex items-center gap-2 border-b border-[var(--app-border-subtle,#F1F5F9)] pb-3">
            <FileText className="w-4 h-4 text-[var(--brand-orange,#F7941D)]" />
            <h2 className="text-sm font-bold text-[var(--app-text-primary,#0F172A)]">
              Invoice Numbering &amp; Formatting
            </h2>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label className="text-xs font-semibold text-neutral-700 block mb-1">
                Invoice Prefix
              </label>
              <input
                type="text"
                required
                value={invoicePrefix ?? ''}
                onChange={(e) => setInvoicePrefix(e.target.value)}
                className="w-full text-xs font-mono font-bold border border-neutral-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-1 focus:ring-orange-500"
              />
            </div>
            <div>
              <label className="text-xs font-semibold text-neutral-700 block mb-1">
                Next Invoice Number (Starts at 1060)
              </label>
              <input
                type="number"
                min="1060"
                required
                value={nextInvoiceNumber ?? 1060}
                onChange={(e) => setNextInvoiceNumber(Number(e.target.value))}
                className="w-full text-xs font-mono font-bold border border-neutral-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-1 focus:ring-orange-500"
              />
            </div>
            <div>
              <label className="text-xs font-semibold text-neutral-700 block mb-1">Currency</label>
              <div className="w-full text-xs font-bold border border-neutral-200 bg-neutral-100 rounded-lg px-3 py-2 text-neutral-800">
                AFN (Fixed)
              </div>
            </div>
          </div>

          <div>
            <label className="text-xs font-semibold text-neutral-700 block mb-1">
              Default Invoice Note (Printed on footer of new invoices)
            </label>
            <textarea
              rows={2}
              value={invoiceNote ?? ''}
              onChange={(e) => setInvoiceNote(e.target.value)}
              className="w-full text-xs border border-neutral-300 rounded-lg p-2.5 focus:outline-none focus:ring-1 focus:ring-orange-500"
            />
          </div>

          <div>
            <label className="text-xs font-semibold text-neutral-700 block mb-1">
              Printed Invoice Sub-Footer Text
            </label>
            <input
              type="text"
              value={footerText ?? ''}
              onChange={(e) => setFooterText(e.target.value)}
              placeholder="e.g. Sarwan Technology - Comprehensive Security & Surveillance Solutions"
              className="w-full text-xs border border-neutral-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-1 focus:ring-orange-500"
            />
          </div>

          <div className="p-3 bg-neutral-50 rounded-lg border border-neutral-200 text-[11px] text-neutral-600">
            <span className="font-semibold text-neutral-900">Historical Snapshot Rule: </span>
            When an invoice is issued, it preserves a permanent snapshot of the company details and
            customer details at that time. Updating these settings only applies to new invoices.
          </div>
        </div>

        {/* Section 3: Login Portal & Branding Customization */}
        <div className="bg-[var(--app-surface-card,#FFFFFF)] p-6 rounded-xl border border-[var(--app-border,#E2E8F0)] shadow-xs space-y-4 transition-colors">
          <div className="flex items-center gap-2 border-b border-[var(--app-border-subtle,#F1F5F9)] pb-3">
            <Sparkles className="w-4 h-4 text-[var(--brand-orange,#F7941D)]" />
            <h2 className="text-sm font-bold text-[var(--app-text-primary,#0F172A)]">
              Login Portal &amp; Branding Customization
            </h2>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="text-xs font-semibold text-[var(--app-text-secondary,#475569)] block mb-1">
                Portal Title Header
              </label>
              <input
                type="text"
                value={loginTitle ?? ''}
                onChange={(e) => setLoginTitle(e.target.value)}
                className="w-full text-xs border border-[var(--app-border,#E2E8F0)] bg-[var(--app-surface-input,#FFFFFF)] text-[var(--app-text-primary,#0F172A)] rounded-lg px-3 py-2 focus:outline-none focus:ring-1 focus:ring-[var(--brand-orange,#F7941D)] font-bold"
              />
            </div>
            <div>
              <label className="text-xs font-semibold text-[var(--app-text-secondary,#475569)] block mb-1">
                Portal Subtitle / System Name
              </label>
              <input
                type="text"
                value={loginSubtitle ?? ''}
                onChange={(e) => setLoginSubtitle(e.target.value)}
                className="w-full text-xs border border-[var(--app-border,#E2E8F0)] bg-[var(--app-surface-input,#FFFFFF)] text-[var(--brand-orange,#F7941D)] rounded-lg px-3 py-2 focus:outline-none focus:ring-1 focus:ring-[var(--brand-orange,#F7941D)] font-semibold"
              />
            </div>
            <div className="sm:col-span-2">
              <label className="text-xs font-semibold text-[var(--app-text-secondary,#475569)] block mb-1">
                Dari / Pashto Welcome Tagline
              </label>
              <input
                type="text"
                dir="rtl"
                value={loginWelcome ?? ''}
                onChange={(e) => setLoginWelcome(e.target.value)}
                className="w-full text-xs border border-[var(--app-border,#E2E8F0)] bg-[var(--app-surface-input,#FFFFFF)] text-[var(--app-text-primary,#0F172A)] rounded-lg px-3 py-2 focus:outline-none focus:ring-1 focus:ring-[var(--brand-orange,#F7941D)] font-serif text-right"
              />
            </div>
          </div>
        </div>

        {/* Section 4: Authorized Google Accounts (RBAC) */}
        <div className="bg-[var(--app-surface-card,#FFFFFF)] p-6 rounded-xl border border-[var(--app-border,#E2E8F0)] shadow-xs space-y-4 transition-colors">
          <div className="flex items-center gap-2 border-b border-[var(--app-border-subtle,#F1F5F9)] pb-3">
            <Shield className="w-4 h-4 text-[var(--brand-orange,#F7941D)]" />
            <div>
              <h2 className="text-sm font-bold text-neutral-900">
                Authorized Google Accounts (Access Control)
              </h2>
              <p className="text-[11px] text-neutral-500">
                Only authenticated Google accounts listed below can log in to the billing system.
              </p>
            </div>
          </div>

          <div className="space-y-2">
            {authorizedEmails.map((em) => (
              <div
                key={em}
                className="flex items-center justify-between p-2.5 bg-neutral-50 rounded-lg border border-neutral-200 text-xs"
              >
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 rounded-full bg-emerald-500"></div>
                  <span className="font-mono text-neutral-800 font-medium">{em}</span>
                  {PRIMARY_ADMIN_EMAILS.includes(em.toLowerCase()) && (
                    <span className="px-1.5 py-0.5 text-[10px] font-bold bg-orange-100 text-orange-800 rounded">
                      Primary Admin
                    </span>
                  )}
                </div>
                {!PRIMARY_ADMIN_EMAILS.includes(em.toLowerCase()) && (
                  <button
                    type="button"
                    onClick={() => handleRemoveEmail(em)}
                    className="text-neutral-400 hover:text-red-600 transition"
                    title="Remove user access"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                )}
              </div>
            ))}
          </div>

          {/* Add email input */}
          <div className="flex items-center gap-2 pt-2">
            <input
              type="email"
              value={newEmailInput ?? ''}
              onChange={(e) => setNewEmailInput(e.target.value)}
              placeholder="Add authorized Google email (e.g. staff@gmail.com)..."
              className="flex-1 text-xs border border-neutral-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-1 focus:ring-orange-500 font-mono"
            />
            <button
              type="button"
              onClick={handleAddEmail}
              className="px-4 py-2 bg-[var(--color-primary,#2563EB)] hover:bg-[var(--color-primary-hover,#1D4ED8)] active:bg-[var(--color-primary-active,#1E40AF)] text-white text-xs font-semibold rounded-lg shadow-xs transition inline-flex items-center gap-1 cursor-pointer focus:outline-none focus-visible:ring-2 focus-visible:ring-[var(--color-primary,#2563EB)]"
            >
              <Plus className="w-3.5 h-3.5 text-white" />
              Add User
            </button>
          </div>
        </div>

        {/* Submit Actions */}
        <div className="flex justify-end">
          <button
            type="submit"
            disabled={saving}
            className="px-6 py-2.5 bg-[var(--color-primary,#2563EB)] hover:bg-[var(--color-primary-hover,#1D4ED8)] active:bg-[var(--color-primary-active,#1E40AF)] text-white text-xs font-bold rounded-lg shadow-xs transition inline-flex items-center gap-2 disabled:opacity-50 active:scale-98 cursor-pointer focus:outline-none focus-visible:ring-2 focus-visible:ring-[var(--color-primary,#2563EB)]"
          >
            <Save className="w-4 h-4 text-white" />
            {saving ? 'Saving...' : 'Save Settings'}
          </button>
        </div>
      </form>
      </>
      )}
    </div>
  );
};
