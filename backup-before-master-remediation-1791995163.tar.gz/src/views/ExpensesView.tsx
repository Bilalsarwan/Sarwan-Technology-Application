import React from 'react';
import { FileText, ArrowRight } from 'lucide-react';

interface ExpensesViewProps {
  onSelectInvoice?: (invoiceId: string) => void;
  onNavigateToInvoices?: () => void;
}

/**
 * Operating Expenses (Retired)
 * 
 * Standalone General Expenses has been completely retired.
 * All operating expenses in Sarwan Technology Billing System are now strictly
 * invoice-based and managed inside each specific Invoice detail window.
 */
export const ExpensesView: React.FC<ExpensesViewProps> = ({
  onNavigateToInvoices,
}) => {
  return (
    <div className="max-w-3xl mx-auto p-6 sm:p-10 my-8 bg-white rounded-2xl border border-neutral-200 shadow-sm text-center space-y-5">
      <div className="w-14 h-14 bg-blue-50 text-[#2563EB] rounded-2xl flex items-center justify-center mx-auto shadow-xs">
        <FileText className="w-7 h-7" />
      </div>
      <div>
        <h2 className="text-xl font-bold text-neutral-900">
          General Expenses Page Retired
        </h2>
        <p className="text-sm text-neutral-600 mt-2 max-w-xl mx-auto leading-relaxed">
          Standalone general expenses have been retired. All operating expenses, receipts, and disbursement approvals are now directly managed inside each specific invoice to maintain accurate profit accounting and immutable audit trails.
        </p>
      </div>

      <div className="p-4 bg-neutral-50 rounded-xl border border-neutral-200 text-xs text-neutral-600 text-left max-w-lg mx-auto space-y-2">
        <div className="font-semibold text-neutral-800">Where to manage expenses:</div>
        <ul className="list-disc list-inside space-y-1 text-neutral-600">
          <li>Navigate to <strong className="text-neutral-900">Invoices</strong></li>
          <li>Open any invoice to view its <strong className="text-neutral-900">Invoice Details</strong></li>
          <li>Scroll to <strong className="text-neutral-900">Invoice Expenses</strong> to submit, approve, or review expenses</li>
        </ul>
      </div>

      <div className="pt-2">
        <button
          type="button"
          onClick={() => {
            if (onNavigateToInvoices) {
              onNavigateToInvoices();
            } else if (typeof window !== 'undefined') {
              window.location.pathname = '/invoices';
            }
          }}
          className="inline-flex items-center gap-2 px-5 py-2.5 bg-[#2563EB] hover:bg-[#1D4ED8] active:bg-[#1E40AF] text-white text-xs font-bold rounded-xl shadow-xs transition cursor-pointer"
        >
          <span>Go to Invoices</span>
          <ArrowRight className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
};
