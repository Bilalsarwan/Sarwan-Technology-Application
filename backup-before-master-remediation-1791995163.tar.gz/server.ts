/**
 * Sarwan Technology Billing System
 * Full-Stack Express Server Entry Point
 * 
 * Provides trusted server-side authentication, password verification,
 * step-up authorization, and mounts Vite middlewares in development.
 */

import express, { Request, Response } from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import {
  authenticateAndMigrateUserServer,
  verifySuperAdminPasswordServer,
  verifySessionServer,
  authenticateServerCaller,
  ensureBackendAuthSession,
  syncAllCanonicalUserProfiles,
} from './src/services/authBackendService';
import {
  correctPayment,
  advanceExpenseWorkflow,
  saveInvoiceExpense,
  deleteInvoiceExpense,
  getInvoiceExpenses,
  cleanDataForFirestore,
  addAuditLog,
} from './src/services/db';
import { doc, getDoc, setDoc } from 'firebase/firestore';
import { db } from './src/services/firebase';
import { PRIMARY_ADMIN_EMAILS, ensureSuperAdminInitialized } from './src/services/security';
import { Expense } from './src/types';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();

function getCliArg(flag: string): string | undefined {
  const index = process.argv.indexOf(flag);
  if (index !== -1 && process.argv[index + 1]) {
    return process.argv[index + 1];
  }
  return undefined;
}

const PORT = parseInt(getCliArg('--port') || process.env.PORT || '3000', 10);
const HOST = getCliArg('--host') || process.env.HOST || '0.0.0.0';
const isProd = process.env.NODE_ENV === 'production';

app.use(express.json());

// Request logging for auditability
app.use((req, res, next) => {
  if (req.path.startsWith('/api/')) {
    const timestamp = new Date().toISOString();
    console.log(`[${timestamp}] ${req.method} ${req.path}`);
  }
  next();
});

// Health check endpoint
app.get('/api/health', (req: Request, res: Response) => {
  res.json({
    status: 'ok',
    system: 'Sarwan Technology Billing System',
    timestamp: new Date().toISOString(),
    environment: isProd ? 'production' : 'development',
  });
});

// Trusted Server Login & Migration Endpoint
app.post('/api/auth/login', async (req: Request, res: Response) => {
  try {
    const { identifier, password } = req.body;
    if (!identifier || !password) {
      return res.status(400).json({
        success: false,
        error: 'Identifier and password are required.',
      });
    }

    const result = await authenticateAndMigrateUserServer({ identifier, password });
    return res.json(result);
  } catch (err: any) {
    const errorMessage = err?.message || 'Authentication failed.';
    const statusCode =
      errorMessage.includes('Invalid username') || errorMessage.includes('Invalid password')
        ? 401
        : 400;
    return res.status(statusCode).json({
      success: false,
      error: errorMessage,
    });
  }
});

// Server-Side Super Admin Password Verification Endpoint
app.post('/api/auth/verify-super-admin', async (req: Request, res: Response) => {
  try {
    const { userId, password } = req.body;
    if (!userId || !password) {
      return res.status(400).json({
        isValid: false,
        error: 'User ID and password are required.',
      });
    }

    const result = await verifySuperAdminPasswordServer({ userId, password });
    return res.json(result);
  } catch (err: any) {
    return res.status(500).json({
      isValid: false,
      error: err?.message || 'Verification failed.',
    });
  }
});

// Server-Side Payment Reversal Authorization Check
app.post('/api/auth/reversal-auth', async (req: Request, res: Response) => {
  try {
    const { userId, password, userRole } = req.body;
    if (userRole !== 'super_admin') {
      return res.status(403).json({
        isAuthorized: false,
        error: 'Access Denied: Only Super Admin is authorized to reverse payments.',
      });
    }

    const result = await verifySuperAdminPasswordServer({ userId, password });
    if (!result.isValid) {
      return res.status(401).json({
        isAuthorized: false,
        error: result.error || 'Authentication Failed: Incorrect Super Admin password.',
      });
    }

    return res.json({ isAuthorized: true });
  } catch (err: any) {
    return res.status(500).json({
      isAuthorized: false,
      error: err?.message || 'Authorization check failed.',
    });
  }
});

// Server-Side Session Verification Endpoint
// Cryptographically verifies ID token and prevents client-side localStorage privilege tampering
app.post('/api/auth/verify-session', async (req: Request, res: Response) => {
  try {
    const { idToken, userId } = req.body;
    if (!idToken || !userId) {
      return res.status(400).json({
        isValid: false,
        error: 'Token and User ID are required.',
      });
    }

    const result = await verifySessionServer({ idToken, userId });
    const statusCode = result.isValid ? 200 : 401;
    return res.status(statusCode).json(result);
  } catch (err: any) {
    return res.status(500).json({
      isValid: false,
      error: err?.message || 'Session verification error.',
    });
  }
});

// Server-Side Secure Payment Reversal Endpoint
app.post('/api/payments/reverse', async (req: Request, res: Response) => {
  try {
    await ensureBackendAuthSession();
    const authCaller = await authenticateServerCaller(req);
    if (!authCaller.isValid || !authCaller.user || !authCaller.userId || !authCaller.userRole) {
      return res.status(401).json({
        success: false,
        error: authCaller.error || 'Authentication required: Invalid or missing session token.',
      });
    }

    if (authCaller.userRole !== 'super_admin') {
      return res.status(403).json({
        success: false,
        error: 'Access Denied: Only Super Admin can reverse payments.',
      });
    }

    const {
      paymentId,
      invoiceId,
      reason,
      password,
      correctedAmount,
      correctedNote,
    } = req.body;

    if (!paymentId || !invoiceId || !reason || !password) {
      return res.status(400).json({
        success: false,
        error: 'Missing required parameters for payment reversal.',
      });
    }

    const replacementPaymentId = await correctPayment({
      paymentId,
      invoiceId,
      reason,
      password,
      userId: authCaller.userId,
      userName: authCaller.userName || 'Super Admin',
      userRole: 'super_admin',
      correctedAmount,
      correctedNote,
    });

    return res.json({
      success: true,
      paymentId,
      replacementPaymentId,
      message: 'Payment reversed successfully.',
    });
  } catch (err: any) {
    return res.status(400).json({
      success: false,
      error: err?.message || 'Payment reversal failed.',
    });
  }
});

// Server-Side Secure Expense Workflow Endpoint
app.post('/api/expenses/workflow', async (req: Request, res: Response) => {
  try {
    await ensureBackendAuthSession();
    const auth = await authenticateServerCaller(req);
    if (!auth.isValid || !auth.user || !auth.userId || !auth.userRole) {
      return res.status(401).json({
        success: false,
        error: auth.error || 'Authentication required: Invalid or missing session token.',
      });
    }

    const verifiedUserId = auth.userId;
    const verifiedUserRole = auth.userRole;
    const verifiedUserName = auth.userName || 'Staff';
    const verifiedJobTitle = auth.user.jobTitle || req.body.userJobTitle || '';
    const verifiedPhotoURL = auth.user.photoURL || req.body.userPhotoURL || '';

    const {
      expenseId,
      action,
      reason,
      corrections,
      title,
      amount,
      date,
      category,
      note,
      disbursedAmount,
      disbursementMethod,
      disbursementReference,
      disbursementNote,
      executionDate,
    } = req.body;

    if (!expenseId || !action) {
      return res.status(400).json({
        success: false,
        error: 'Missing required parameters for expense workflow action.',
      });
    }

    if (verifiedUserRole === 'customer') {
      return res.status(403).json({
        success: false,
        error: 'Access Denied: Customer accounts have no permissions on operating expenses.',
      });
    }

    // Read target expense document from authoritative server Firestore
    const expSnap = await getDoc(doc(db, 'expenses', expenseId));
    if (!expSnap.exists()) {
      return res.status(404).json({
        success: false,
        error: `Expense record "${expenseId}" not found.`,
      });
    }
    const existing = expSnap.data() as Expense;

    // Self-approval & self-rejection prevention
    if (
      (action === 'manager_approve' || action === 'admin_approve') &&
      existing.requestedBy &&
      existing.requestedBy.toLowerCase() === verifiedUserId.toLowerCase()
    ) {
      return res.status(403).json({
        success: false,
        error: 'Access Denied: You cannot approve your own expense request.',
      });
    }

    if (
      action === 'reject' &&
      existing.requestedBy &&
      existing.requestedBy.toLowerCase() === verifiedUserId.toLowerCase()
    ) {
      return res.status(403).json({
        success: false,
        error: 'Access Denied: You cannot reject your own expense request.',
      });
    }

    // Role-specific action permissions and state machine enforcement
    if (action === 'manager_approve') {
      if (verifiedUserRole !== 'invoice_manager') {
        return res.status(403).json({
          success: false,
          error: 'Access Denied: Only Invoice Manager can approve expenses at the manager stage.',
        });
      }
      if (existing.status !== 'pending_manager') {
        if (existing.status === 'pending_admin' || existing.status === 'approved' || existing.status === 'executed') {
          return res.status(400).json({
            success: false,
            error: 'This expense has already been approved or advanced past manager stage.',
          });
        }
        return res.status(400).json({
          success: false,
          error: `Expense cannot be approved at manager stage because current status is "${existing.status}".`,
        });
      }
    } else if (action === 'admin_approve') {
      if (verifiedUserRole !== 'super_admin') {
        return res.status(403).json({
          success: false,
          error: 'Access Denied: Only Super Admin can approve expenses at the admin stage.',
        });
      }
      if (existing.requestedByRole === 'payment_collector' && existing.status === 'pending_manager') {
        return res.status(403).json({
          success: false,
          error: 'Access Denied: Payment Collector expenses must first receive Invoice Manager approval before Super Admin approval.',
        });
      }
      if (existing.status === 'approved') {
        return res.status(400).json({
          success: false,
          error: 'This expense has already been approved.',
        });
      }
      if (existing.status === 'executed') {
        return res.status(400).json({
          success: false,
          error: 'This expense has already been executed.',
        });
      }
      if (existing.status !== 'pending_admin') {
        return res.status(400).json({
          success: false,
          error: `Expense cannot be approved at admin stage because current status is "${existing.status}".`,
        });
      }
    } else if (action === 'admin_execute') {
      if (verifiedUserRole !== 'super_admin') {
        return res.status(403).json({
          success: false,
          error: 'Access Denied: Only Super Admin can execute and disburse expenses.',
        });
      }
      if (existing.status === 'executed' || existing.executionStatus === 'executed') {
        return res.status(400).json({
          success: false,
          error: 'This expense has already been executed and disbursed.',
        });
      }
      if (existing.status !== 'approved') {
        return res.status(400).json({
          success: false,
          error: `Expense cannot be executed because current status is "${existing.status}". Only approved expenses can be executed.`,
        });
      }
      if (disbursedAmount !== undefined) {
        const numDisbursed = Number(disbursedAmount);
        if (!Number.isFinite(numDisbursed) || numDisbursed <= 0) {
          return res.status(400).json({
            success: false,
            error: 'Disbursed amount must be a positive number.',
          });
        }
        if (numDisbursed > existing.amount) {
          return res.status(400).json({
            success: false,
            error: `Disbursed amount (${numDisbursed} AFN) cannot exceed approved amount (${existing.amount} AFN).`,
          });
        }
      }
      if (disbursementMethod) {
        const validMethods = ['Cash', 'Bank Transfer', 'Hawala', 'Cheque', 'Other'];
        const cleanMethod = disbursementMethod.trim();
        if (!validMethods.includes(cleanMethod)) {
          return res.status(400).json({
            success: false,
            error: `Invalid disbursement method: "${disbursementMethod}". Allowed methods: ${validMethods.join(', ')}.`,
          });
        }
      }
    } else if (action === 'reject') {
      if (verifiedUserRole !== 'invoice_manager' && verifiedUserRole !== 'super_admin') {
        return res.status(403).json({
          success: false,
          error: 'Access Denied: Only Invoice Manager or Super Admin can reject expenses.',
        });
      }
      if (existing.status !== 'pending_manager' && existing.status !== 'pending_admin') {
        return res.status(400).json({
          success: false,
          error: `Expense cannot be rejected because current status is "${existing.status}". Only pending expenses can be rejected.`,
        });
      }
      if (existing.status === 'pending_admin' && verifiedUserRole !== 'super_admin') {
        return res.status(403).json({
          success: false,
          error: 'Access Denied: Only Super Admin can reject expenses at the admin stage.',
        });
      }
      const reasonText = (reason || '').trim();
      if (!reasonText || reasonText.length < 3) {
        return res.status(400).json({
          success: false,
          error: 'A meaningful rejection reason (at least 3 characters) is required to reject an expense.',
        });
      }
    } else if (action === 'resubmit') {
      if (verifiedUserRole === 'super_admin') {
        return res.status(403).json({
          success: false,
          error: 'Access Denied: Super Admin cannot resubmit expense requests.',
        });
      }
      const isOwner =
        existing.requestedBy &&
        existing.requestedBy.toLowerCase() === verifiedUserId.toLowerCase();
      if (!isOwner) {
        return res.status(403).json({
          success: false,
          error: 'Access Denied: Only the original authorized requester can edit and resubmit their rejected expense request.',
        });
      }
      if (existing.status !== 'rejected') {
        return res.status(400).json({
          success: false,
          error: 'Only rejected expenses can be resubmitted.',
        });
      }
      const correctionsText = (corrections || reason || '').trim();
      if (!correctionsText || correctionsText.length < 3) {
        return res.status(400).json({
          success: false,
          error: 'A resubmission note explaining corrections (at least 3 characters) is required to resubmit a rejected expense.',
        });
      }
    } else {
      return res.status(400).json({
        success: false,
        error: `Invalid workflow action: "${action}".`,
      });
    }

    await advanceExpenseWorkflow({
      expenseId,
      action,
      userId: verifiedUserId,
      userName: verifiedUserName,
      userRole: verifiedUserRole,
      userJobTitle: verifiedJobTitle,
      userPhotoURL: verifiedPhotoURL,
      reason,
      corrections,
      title,
      amount,
      date,
      category,
      note,
      disbursedAmount: disbursedAmount !== undefined ? Number(disbursedAmount) : undefined,
      disbursementMethod,
      disbursementReference,
      disbursementNote,
      executionDate,
    });

    return res.json({
      success: true,
      message: `Expense workflow action "${action}" executed successfully.`,
    });
  } catch (err: any) {
    return res.status(400).json({
      success: false,
      error: err?.message || 'Expense workflow execution failed.',
    });
  }
});

// Server-Side Secure Invoice Expense Save Endpoint
app.post('/api/expenses/save', async (req: Request, res: Response) => {
  try {
    await ensureBackendAuthSession();
    const auth = await authenticateServerCaller(req);
    if (!auth.isValid || !auth.user || !auth.userId || !auth.userRole) {
      return res.status(401).json({
        success: false,
        error: auth.error || 'Authentication required: Invalid or missing session token.',
      });
    }

    const verifiedUserId = auth.userId;
    const verifiedUserRole = auth.userRole;
    const verifiedUserName = auth.userName || 'Staff';
    const verifiedJobTitle = auth.user.jobTitle || req.body.userJobTitle || '';
    const verifiedPhotoURL = auth.user.photoURL || req.body.userPhotoURL || '';

    const {
      id,
      invoiceId,
      billNumber,
      title,
      amount,
      date,
      category,
      note,
      corrections,
    } = req.body;

    if (!invoiceId || !title || amount === undefined || !date) {
      return res.status(400).json({
        success: false,
        error: 'Missing required parameters for saving invoice expense.',
      });
    }

    if (verifiedUserRole === 'customer') {
      return res.status(403).json({
        success: false,
        error: 'Access Denied: Customers cannot create or manage expenses.',
      });
    }

    // Super Admin cannot create or submit expense requests
    if (!id && verifiedUserRole === 'super_admin') {
      return res.status(403).json({
        success: false,
        error: 'Access Denied: Super Admin cannot create or submit expense requests. Expense creation is restricted to Invoice Managers and Payment Collectors.',
      });
    }

    // Super Admin cannot edit a requested expense
    if (id && verifiedUserRole === 'super_admin') {
      return res.status(403).json({
        success: false,
        error: 'Access Denied: Super Admin cannot edit submitted expense requests. Super Admin may only perform authorized approval or rejection actions at the correct workflow stage.',
      });
    }

    if (id) {
      const expSnap = await getDoc(doc(db, 'expenses', id));
      if (!expSnap.exists()) {
        return res.status(404).json({ success: false, error: 'Expense record not found.' });
      }
      const existing = expSnap.data() as Expense;
      if (existing.status === 'approved' || existing.status === 'executed') {
        return res.status(403).json({
          success: false,
          error: 'Access Denied: Approved expenses are immutable and cannot be edited or resubmitted.',
        });
      }
      if (existing.status === 'rejected') {
        const isOwner =
          existing.requestedBy &&
          existing.requestedBy.toLowerCase() === verifiedUserId.toLowerCase();
        if (!isOwner) {
          return res.status(403).json({
            success: false,
            error: 'Access Denied: Only the original authorized requester can edit and resubmit their rejected expense request.',
          });
        }
      } else if (existing.status === 'draft') {
        const isOwner =
          existing.requestedBy &&
          existing.requestedBy.toLowerCase() === verifiedUserId.toLowerCase();
        if (!isOwner) {
          return res.status(403).json({
            success: false,
            error: 'Access Denied: Only the request owner can edit this draft expense.',
          });
        }
      } else {
        return res.status(403).json({
          success: false,
          error: `Access Denied: Expense requests in "${existing.status}" status cannot be modified. Requests must be reviewed or rejected before modifications can be made.`,
        });
      }
    }

    const savedId = await saveInvoiceExpense({
      id,
      invoiceId,
      billNumber,
      title,
      amount: Number(amount),
      date,
      category,
      note,
      userId: verifiedUserId,
      userName: verifiedUserName,
      userRole: verifiedUserRole,
      userJobTitle: verifiedJobTitle,
      userPhotoURL: verifiedPhotoURL,
      corrections,
    });

    return res.json({
      success: true,
      id: savedId,
      message: 'Invoice expense saved successfully.',
    });
  } catch (err: any) {
    return res.status(400).json({
      success: false,
      error: err?.message || 'Saving invoice expense failed.',
    });
  }
});

// Server-Side Protected Invoice Expenses Query with Strict Privacy Enforcement
app.post('/api/expenses/by-invoice', async (req: Request, res: Response) => {
  try {
    await ensureBackendAuthSession();
    const auth = await authenticateServerCaller(req);
    if (!auth.isValid || !auth.user || !auth.userId || !auth.userRole) {
      return res.status(401).json({
        success: false,
        error: auth.error || 'Authentication required: Invalid or missing session token.',
      });
    }

    const { invoiceId } = req.body;
    if (!invoiceId) {
      return res.status(400).json({
        success: false,
        error: 'Missing required invoiceId parameter.',
      });
    }

    if (auth.userRole === 'customer') {
      return res.json({ success: true, expenses: [] });
    }

    const expenses = await getInvoiceExpenses(invoiceId, auth.userRole, auth.userId);
    return res.json({ success: true, expenses });
  } catch (err: any) {
    return res.status(400).json({
      success: false,
      error: err?.message || 'Failed to fetch invoice expenses.',
    });
  }
});

// Server-Side Secure Invoice Expense Delete Endpoint
app.post('/api/expenses/delete', async (req: Request, res: Response) => {
  try {
    await ensureBackendAuthSession();
    const auth = await authenticateServerCaller(req);
    if (!auth.isValid || !auth.user || !auth.userId || !auth.userRole) {
      return res.status(401).json({
        success: false,
        error: auth.error || 'Authentication required: Invalid or missing session token.',
      });
    }

    const verifiedUserId = auth.userId;
    const verifiedUserRole = auth.userRole;
    const verifiedUserName = auth.userName || 'Staff';

    const { expenseId, invoiceId, billNumber } = req.body;
    if (!expenseId || !invoiceId) {
      return res.status(400).json({
        success: false,
        error: 'Missing required parameters for deleting invoice expense.',
      });
    }

    if (verifiedUserRole !== 'super_admin' && verifiedUserRole !== 'invoice_manager') {
      return res.status(403).json({
        success: false,
        error: 'Access Denied: Only Super Admin and Invoice Manager can delete invoice expenses.',
      });
    }

    await deleteInvoiceExpense({
      expenseId,
      invoiceId,
      billNumber,
      userId: verifiedUserId,
      userName: verifiedUserName,
      userRole: verifiedUserRole,
    });

    return res.json({
      success: true,
      message: 'Invoice expense deleted successfully.',
    });
  } catch (err: any) {
    return res.status(400).json({
      success: false,
      error: err?.message || 'Deleting invoice expense failed.',
    });
  }
});

// Server-Side Protected Business Settings Save Endpoint
app.post('/api/settings/save', async (req: Request, res: Response) => {
  try {
    await ensureBackendAuthSession();
    const authCaller = await authenticateServerCaller(req);

    if (!authCaller.isValid || !authCaller.user || !authCaller.userId || !authCaller.userRole) {
      return res.status(401).json({
        success: false,
        error: authCaller.error || 'Authentication required: Invalid or missing session token.',
      });
    }

    const callerEmail = authCaller.user?.email || '';
    const isDesignated = Boolean(
      callerEmail &&
      PRIMARY_ADMIN_EMAILS.some(
        (em) => em.toLowerCase().trim() === String(callerEmail).toLowerCase().trim()
      )
    );

    if (authCaller.userRole !== 'super_admin' && !isDesignated) {
      return res.status(403).json({
        success: false,
        error: 'Access Denied: Only Super Admin is authorized to update business settings.',
      });
    }

    const { settings: newSettings } = req.body;
    if (!newSettings || typeof newSettings !== 'object') {
      return res.status(400).json({
        success: false,
        error: 'Invalid settings payload provided.',
      });
    }

    const settingsDocRef = doc(db, 'settings', 'company_settings');
    const cleanSettings = cleanDataForFirestore(newSettings);
    await setDoc(settingsDocRef, cleanSettings, { merge: true });

    await addAuditLog({
      action: 'update_settings',
      userId: authCaller.userId,
      userName: authCaller.userName || 'Super Admin',
      userRole: 'super_admin',
      entityType: 'settings',
      entityId: 'company_settings',
      summary: 'Updated company business & invoice settings',
    });

    return res.json({
      success: true,
      message: 'Business settings saved successfully.',
    });
  } catch (err: any) {
    console.error('Server settings save error:', err);
    return res.status(500).json({
      success: false,
      error: err?.message || 'Failed to save settings on server.',
    });
  }
});

// Initialize Frontend Handling (Vite in Dev, Static in Prod)
async function startServer() {
  if (!isProd) {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (req, res) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  }

  const server = app.listen(PORT, HOST, () => {
    console.log(`Sarwan Billing System server running on http://${HOST}:${PORT}`);
  });

  // Background initialization of trusted server auth session without blocking HTTP listener startup
  ensureBackendAuthSession()
    .then(async () => {
      console.log('Trusted server backend session initialized successfully.');
      await ensureSuperAdminInitialized().catch((err) => {
        console.warn('Super admin server initialization notice:', err);
      });
      const synced = await syncAllCanonicalUserProfiles().catch((err) => {
        console.warn('Canonical user profile sync notice:', err);
        return 0;
      });
      if (synced > 0) {
        console.log(`Synchronized ${synced} canonical user profile mappings.`);
      }
    })
    .catch((err) => {
      console.warn('Trusted server backend session init notice:', err);
    });

  const handleShutdown = () => {
    server.close(() => {
      process.exit(0);
    });
  };
  process.on('SIGTERM', handleShutdown);
  process.on('SIGINT', handleShutdown);
}

startServer().catch((err) => {
  console.error('Server startup error:', err);
  process.exit(1);
});
