import { doc, getDoc, setDoc, updateDoc, collection, query, where, getDocs, runTransaction } from 'firebase/firestore';
import { db } from './firebase';
import { UserProfile, UserRole } from '../types';
import { addAuditLog, cleanDataForFirestore } from './db';
import { uploadUserProfilePhoto } from './storage';
import { generateSalt, hashPassword } from '../utils/password';
import { isProfileComplete } from '../utils/profileCompletion';

// Known initial Super Admin identity
export const INITIAL_SUPER_ADMIN_UID = '74UtrmvUznRbczbQ6OpS62Wxw';
export const INITIAL_SUPER_ADMIN_EMAIL = 'bilalsarwan7@gmail.com';
export const INITIAL_SUPER_ADMIN_USERNAME = 'bilalsarwan7';

export const PRIMARY_ADMIN_EMAILS = [
  'admin@sarwantechnology.com',
  'bilalsarwan7@gmail.com',
  'bilalsarwan2@gmail.com',
  'sarwancreative.af@gmail.com',
];

/**
 * Allocates the next immutable, auto-incrementing User ID using a Firestore transaction.
 * Format: ST-U-5000, ST-U-5001, ST-U-5002...
 * 
 * Rules enforced:
 * 1. Starting number is 5000.
 * 2. Increments exactly +1 for every newly created user.
 * 3. Atomic transaction prevents race conditions and duplicate IDs between concurrent admins.
 * 4. Stored persistently in systemCounters/userIdCounter.
 * 5. IDs are never reused even if users are deleted, archived, or deactivated.
 */
export async function allocateNextUserId(): Promise<string> {
  const counterRef = doc(db, 'systemCounters', 'userIdCounter');
  const allocatedId = await runTransaction(db, async (transaction) => {
    const counterSnap = await transaction.get(counterRef);
    let nextNum = 5000;
    if (counterSnap.exists()) {
      const data = counterSnap.data();
      if (typeof data.nextNumber === 'number') {
        nextNum = data.nextNumber;
      } else if (typeof data.currentNumber === 'number') {
        nextNum = data.currentNumber + 1;
      }
    }

    transaction.set(
      counterRef,
      {
        currentNumber: nextNum,
        nextNumber: nextNum + 1,
        lastAllocatedId: `ST-U-${nextNum}`,
        updatedAt: new Date().toISOString(),
      },
      { merge: true }
    );

    return `ST-U-${nextNum}`;
  });

  return allocatedId;
}

/**
 * Standard browser SHA-256 cryptographic hashing via Web Crypto API.
 */
export async function sha256(message: string): Promise<string> {
  const msgBuffer = new TextEncoder().encode(message.trim());
  const hashBuffer = await crypto.subtle.digest('SHA-256', msgBuffer);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  return hashArray.map((b) => b.toString(16).padStart(2, '0')).join('');
}

/**
 * Ensures that the primary Super Admin profile is registered in the Users collection.
 * Bilal Sarwan (bilalsarwan7@gmail.com / bilalsarwan7) can log in via Google or Username/Password.
 */
export async function ensureSuperAdminInitialized(): Promise<UserProfile> {
  const userDocRef = doc(db, 'users', INITIAL_SUPER_ADMIN_UID);
  try {
    const snap = await getDoc(userDocRef);
    if (snap.exists()) {
      const data = snap.data() as UserProfile;
      if (data.role !== 'super_admin' || data.status !== 'active' || !data.username || !data.passwordHash) {
        const salt = data.passwordSalt || generateSalt();
        const hash = data.passwordHash || (await hashPassword('Sarwan@2026!', salt));
        const patch: Partial<UserProfile> = {
          role: 'super_admin',
          status: 'active',
          username: data.username || INITIAL_SUPER_ADMIN_USERNAME,
          passwordSalt: salt,
          passwordHash: hash,
          mustChangePassword: data.mustChangePassword ?? false,
          isDeactivated: false,
          updatedAt: new Date().toISOString(),
        };
        await setDoc(userDocRef, patch, { merge: true });
        return { ...data, ...patch } as UserProfile;
      }
      return data;
    }

    // Check if user exists with bilalsarwan7@gmail.com under different doc ID
    const usersCol = collection(db, 'users');
    const qEmail = query(usersCol, where('email', '==', INITIAL_SUPER_ADMIN_EMAIL));
    const snapEmail = await getDocs(qEmail);
    if (!snapEmail.empty) {
      const existingDoc = snapEmail.docs[0];
      const data = existingDoc.data() as UserProfile;
      return { id: existingDoc.id, ...data };
    }

    // Create initial Super Admin record
    const salt = generateSalt();
    const hash = await hashPassword('Sarwan@2026!', salt);
    const now = new Date().toISOString();
    const initialAdmin: UserProfile = {
      id: INITIAL_SUPER_ADMIN_UID,
      name: 'Bilal Sarwan',
      username: INITIAL_SUPER_ADMIN_USERNAME,
      email: INITIAL_SUPER_ADMIN_EMAIL,
      phone: '0731339014',
      role: 'super_admin',
      status: 'active',
      passwordHash: hash,
      passwordSalt: salt,
      mustChangePassword: false,
      googleUid: INITIAL_SUPER_ADMIN_UID,
      googleEmail: INITIAL_SUPER_ADMIN_EMAIL,
      isDeactivated: false,
      createdAt: now,
      updatedAt: now,
    };

    await setDoc(userDocRef, initialAdmin, { merge: true });
    return initialAdmin;
  } catch (e) {
    console.warn('Super Admin initialization notice:', e);
    // Return fallback in-memory object
    return {
      id: INITIAL_SUPER_ADMIN_UID,
      name: 'Bilal Sarwan',
      username: INITIAL_SUPER_ADMIN_USERNAME,
      email: INITIAL_SUPER_ADMIN_EMAIL,
      phone: '0731339014',
      role: 'super_admin',
      status: 'active',
      mustChangePassword: false,
      isDeactivated: false,
      createdAt: new Date().toISOString(),
    };
  }
}

/**
 * Super Admin Account Creation.
 * Creates an application user record directly in the central Users collection.
 * Does NOT use Firebase Email/Password Authentication.
 * Stores cryptographically hashed default password.
 * Marks mustChangePassword = true so the user is forced to create a new password upon first login.
 * Supported roles: 'invoice_manager' | 'payment_collector' | 'customer'.
 */
export async function createApplicationUser(params: {
  name: string;
  username: string;
  email: string;
  phone: string;
  address?: string;
  defaultPassword: string;
  role: 'super_admin' | 'invoice_manager' | 'payment_collector' | 'customer';
  status: 'active' | 'inactive';
  photoURL?: string;
  jobTitle?: string;
  department?: string;
  dateOfBirth?: string;
  gender?: 'male' | 'female' | 'other' | '';
  nationalId?: string;
  emergencyContactName?: string;
  emergencyContactPhone?: string;
  employmentStartDate?: string;
  employmentStatus?: 'active' | 'probation' | 'contract' | 'permanent' | 'on_leave' | 'terminated';
  employeeCode?: string;
  notes?: string;
  customerId?: string;
  creatorId: string;
  creatorName: string;
}): Promise<UserProfile> {
  // Privilege Protection: Standard user creation can NEVER assign super_admin role
  if (params.role === 'super_admin') {
    throw new Error(
      'Access Denied: Standard user creation cannot assign the super_admin role. Super Admin initialization is strictly reserved for primary system bootstrapping.'
    );
  }

  const allowedRoles: UserRole[] = ['invoice_manager', 'payment_collector', 'customer'];
  if (!allowedRoles.includes(params.role)) {
    throw new Error('Invalid user role specified.');
  }

  const trimmedUsername = params.username.trim().toLowerCase().replace(/\s+/g, '_');
  if (!trimmedUsername || trimmedUsername.length < 3) {
    throw new Error('Username must be at least 3 characters.');
  }

  const normalizedEmail = params.email.trim().toLowerCase();
  if (!normalizedEmail || !normalizedEmail.includes('@')) {
    throw new Error('Please enter a valid email address.');
  }

  if (!params.defaultPassword || params.defaultPassword.length < 6) {
    throw new Error('Default password must be at least 6 characters.');
  }

  // Check username uniqueness
  const usersCol = collection(db, 'users');
  const qUsername = query(usersCol, where('username', '==', trimmedUsername));
  const snapUsername = await getDocs(qUsername);
  if (!snapUsername.empty) {
    throw new Error(`The username "${trimmedUsername}" is already taken. Please choose another username.`);
  }

  // Check email uniqueness
  const qEmail = query(usersCol, where('email', '==', normalizedEmail));
  const snapEmail = await getDocs(qEmail);
  if (!snapEmail.empty) {
    throw new Error(`An account with the email "${normalizedEmail}" is already registered.`);
  }

  // Generate cryptographic salt and hash default password
  const salt = generateSalt(16);
  const hash = await hashPassword(params.defaultPassword, salt);

  // Allocate immutable, auto-incrementing official User ID (ST-U-5000, ST-U-5001...)
  // Transaction-safe, starting at 5000, never reused.
  const officialUserId = await allocateNextUserId();
  const newUid = officialUserId;
  const now = new Date().toISOString();

  let finalCustomerId: string | undefined = undefined;

  if (params.role === 'customer') {
    if (params.customerId && params.customerId.trim()) {
      finalCustomerId = params.customerId.trim();
      // Verify existing customer record exists
      const custRef = doc(db, 'customers', finalCustomerId);
      const custSnap = await getDoc(custRef);
      if (!custSnap.exists()) {
        throw new Error(`Referenced customer ID "${finalCustomerId}" does not exist in the database.`);
      }
      await updateDoc(custRef, {
        userId: newUid,
        userUsername: trimmedUsername,
        userEmail: normalizedEmail,
        hasPortalAccount: true,
        portalEnabled: true,
        updatedAt: now,
      }).catch(console.warn);
    } else {
      // Look up matching registered customer by phone or email
      const custCol = collection(db, 'customers');
      const allCustSnap = await getDocs(custCol);
      let matchedCustDoc: any = null;

      const cleanInputPhone = params.phone.trim().replace(/[\s\-\(\)]/g, '');

      for (const d of allCustSnap.docs) {
        const cData = d.data();
        const cPhone = (cData.phone || '').replace(/[\s\-\(\)]/g, '');
        if (cleanInputPhone && cPhone === cleanInputPhone) {
          matchedCustDoc = d;
          break;
        }
        if (normalizedEmail && cData.email && cData.email.toLowerCase().trim() === normalizedEmail) {
          matchedCustDoc = d;
          break;
        }
      }

      if (matchedCustDoc) {
        finalCustomerId = matchedCustDoc.id;
        await updateDoc(doc(db, 'customers', matchedCustDoc.id), {
          userId: newUid,
          userUsername: trimmedUsername,
          userEmail: normalizedEmail,
          hasPortalAccount: true,
          portalEnabled: true,
          updatedAt: now,
        }).catch(console.warn);
      } else {
        throw new Error(
          'Cannot assign Customer role without a valid customer relationship. Customer portal accounts must be linked to a registered customer record.'
        );
      }
    }
  } else {
    // Staff roles (invoice_manager, payment_collector) must NEVER be linked to a customer record
    finalCustomerId = undefined;
  }

  // Resolve profile photo if provided
  let resolvedPhotoURL = '';
  if (params.photoURL && params.photoURL.trim()) {
    try {
      resolvedPhotoURL = await uploadUserProfilePhoto(newUid, params.photoURL.trim());
    } catch (photoErr) {
      console.warn('Profile photo resolution notice:', photoErr);
      resolvedPhotoURL = params.photoURL.trim();
    }
  }

  const profile: UserProfile = {
    id: newUid,
    userId: officialUserId,
    name: params.name.trim(),
    username: trimmedUsername,
    email: normalizedEmail,
    role: params.role,
    status: params.status,
    isDeactivated: params.status === 'inactive',
    passwordHash: hash,
    passwordSalt: salt,
    mustChangePassword: true, // Mandatory change password after first login!
    jobTitle: params.jobTitle?.trim() || '',
    department: params.department?.trim() || '',
    dateOfBirth: params.dateOfBirth?.trim() || '',
    gender: params.gender || '',
    nationalId: params.nationalId?.trim() || '',
    address: params.address?.trim() || '',
    emergencyContactName: params.emergencyContactName?.trim() || '',
    emergencyContactPhone: params.emergencyContactPhone?.trim() || '',
    employmentStartDate: params.employmentStartDate?.trim() || '',
    employmentStatus: params.employmentStatus || (params.status === 'active' ? 'active' : 'contract'),
    employeeCode: params.employeeCode?.trim() || '',
    notes: params.notes?.trim() || '',
    createdAt: now,
    updatedAt: now,
  };

  // Only assign phone if non-empty, never write undefined
  if (params.phone && params.phone.trim()) {
    profile.phone = params.phone.trim();
  }

  // When no profile photo is selected, DO NOT write photoURL: undefined to Firestore.
  // Save an empty string or valid URL
  profile.photoURL = resolvedPhotoURL ? resolvedPhotoURL.trim() : '';

  if (finalCustomerId) {
    profile.customerId = finalCustomerId;
  }

  // Calculate automatic completion status
  profile.profileCompletionStatus = isProfileComplete(profile) ? 'complete' : 'incomplete';

  const userDocRef = doc(db, 'users', newUid);
  await setDoc(userDocRef, cleanDataForFirestore(profile), { merge: true });

  try {
    await addAuditLog({
      action: 'create_user',
      userId: params.creatorId,
      userName: params.creatorName,
      userRole: 'super_admin',
      entityType: 'user',
      entityId: newUid,
      summary: `Administrator created ${params.role} account for ${params.name} (${trimmedUsername}).`,
    });
  } catch (auditErr) {
    console.warn('Audit log write notice:', auditErr);
  }

  return profile;
}

/**
 * Allows the active Super Admin to change the Admin Code.
 */
export async function changeAdminCode(params: {
  currentCode: string;
  newCode: string;
  confirmCode: string;
  superAdminUid: string;
  superAdminName: string;
}): Promise<void> {
  const newHash = await sha256(params.newCode);
  const secRef = doc(db, 'system_security', 'admin_code');
  await setDoc(
    secRef,
    {
      codeHash: newHash,
      updatedAt: new Date().toISOString(),
      updatedBy: params.superAdminUid,
    },
    { merge: true }
  );

  await addAuditLog({
    action: 'change_admin_code',
    userId: params.superAdminUid,
    userName: params.superAdminName,
    userRole: 'super_admin',
    entityType: 'security',
    entityId: 'admin_code',
    summary: 'Super Admin updated the administrative security code.',
  });
}

/**
 * Super Admin privilege: Resets an application user's password cryptographically.
 * Generates fresh salt + hash, sets mustChangePassword = true, and records audit trail.
 */
export async function resetUserPasswordByAdmin(params: {
  targetUserId: string;
  targetUserName: string;
  newPassword?: string;
  adminId: string;
  adminName: string;
}): Promise<{ temporaryPassword: string }> {
  const tempPassword = params.newPassword && params.newPassword.trim().length >= 6
    ? params.newPassword.trim()
    : 'Sarwan@2026!';
    
  const salt = generateSalt();
  const hash = await hashPassword(tempPassword, salt);
  
  const userDocRef = doc(db, 'users', params.targetUserId);
  await updateDoc(userDocRef, {
    passwordHash: hash,
    passwordSalt: salt,
    mustChangePassword: true,
    updatedAt: new Date().toISOString(),
  });
  
  await addAuditLog({
    action: 'reset_password',
    userId: params.adminId,
    userName: params.adminName,
    userRole: 'super_admin',
    entityType: 'user',
    entityId: params.targetUserId,
    summary: `Administrator reset credentials for ${params.targetUserName}. Mandatory password change enforced on next login.`,
  });

  return { temporaryPassword: tempPassword };
}

