import {
  Payment,
  Invoice,
  PaymentMethod,
  ACTIVE_PAYMENT_METHODS,
  SUPPORTED_PAYMENT_METHODS,
  InvoiceStatus,
} from '../types';
import { getTodayDateString } from './format';

/**
 * 1. PAYMENT DATE VALIDATION RULE:
 * Payment Date <= Today
 *
 * Rules:
 * - Default Payment Date = today.
 * - Allow today and any previous date.
 * - Do NOT allow any future date.
 * - The validation exists at application/service layer, rejecting API/bypass requests.
 * - Preserves YYYY-MM-DD format and local timezone conventions.
 */
export function validatePaymentDate(
  paymentDate: string | undefined | null,
  referenceTodayStr?: string
): {
  isValid: boolean;
  normalizedDate: string;
  error?: string;
} {
  const todayStr = referenceTodayStr || getTodayDateString();

  if (!paymentDate || typeof paymentDate !== 'string' || !paymentDate.trim()) {
    return {
      isValid: false,
      normalizedDate: todayStr,
      error: 'Payment date is required.',
    };
  }

  const trimmed = paymentDate.trim();
  const normalized = trimmed.includes('T') ? trimmed.split('T')[0] : trimmed;

  // Basic YYYY-MM-DD pattern verification
  const parts = normalized.split('-');
  if (parts.length !== 3 || parts[0].length !== 4 || parts[1].length !== 2 || parts[2].length !== 2) {
    return {
      isValid: false,
      normalizedDate: normalized,
      error: 'Invalid payment date format. Expected YYYY-MM-DD.',
    };
  }

  const dateObj = new Date(normalized);
  if (isNaN(dateObj.getTime())) {
    return {
      isValid: false,
      normalizedDate: normalized,
      error: 'Invalid payment date value.',
    };
  }

  // Lexicographical comparison for ISO YYYY-MM-DD dates
  if (normalized > todayStr) {
    return {
      isValid: false,
      normalizedDate: normalized,
      error: `Payment date cannot be in the future. Selected date: ${normalized}, Today: ${todayStr}.`,
    };
  }

  return {
    isValid: true,
    normalizedDate: normalized,
  };
}

/**
 * 2. PAYMENT METHOD VALIDATION & ARCHITECTURE:
 * Keep Cash as the only currently active Payment Method.
 * Extensible for future methods (Bank Transfer, Mobile Money, Card).
 *
 * Rules:
 * - Structured PaymentMethod field.
 * - Active method: CASH.
 * - Future methods: BANK_TRANSFER, MOBILE_MONEY, CARD.
 * - Rejects inactive methods in the current phase.
 * - Backward compatible with existing records.
 */
export function validatePaymentMethod(method?: string | null): {
  isValid: boolean;
  method: PaymentMethod;
  error?: string;
} {
  if (!method || typeof method !== 'string' || !method.trim()) {
    return { isValid: true, method: 'CASH' };
  }

  const normalized = method.trim().toUpperCase() as PaymentMethod;

  if (!SUPPORTED_PAYMENT_METHODS.includes(normalized)) {
    return {
      isValid: false,
      method: 'CASH',
      error: `Unsupported payment method: "${method}". Supported methods: ${SUPPORTED_PAYMENT_METHODS.join(', ')}.`,
    };
  }

  if (!ACTIVE_PAYMENT_METHODS.includes(normalized)) {
    return {
      isValid: false,
      method: normalized,
      error: `Payment method "${method}" is not currently active. Only Cash payments are currently accepted.`,
    };
  }

  return { isValid: true, method: normalized };
}

/**
 * 3. PAYMENT NOTE SANITIZATION:
 * Payment Note is genuinely optional.
 *
 * Rules:
 * - User enters note -> save exact trimmed note.
 * - User leaves empty -> save empty string ('').
 * - Do NOT automatically store artificial/default text such as 'Cash received in shop'.
 * - Do NOT create fake/default accounting notes.
 */
export function sanitizePaymentNote(note?: string | null): string {
  if (!note || typeof note !== 'string') {
    return '';
  }
  return note.trim();
}

/**
 * Recalculates authoritative paid amount and remaining balance from real payment documents,
 * strictly excluding voided payments.
 */
export function calculateAuthoritativeBalance(
  invoiceTotal: number,
  payments: Array<Pick<Payment, 'amount' | 'isVoid'>>
): {
  authoritativeTotalPaid: number;
  remainingBalance: number;
} {
  const safeTotal = Number(invoiceTotal) || 0;
  let paid = 0;

  for (const p of payments) {
    if (!p.isVoid) {
      paid += Number(p.amount) || 0;
    }
  }

  const remaining = Math.max(0, safeTotal - paid);
  return {
    authoritativeTotalPaid: paid,
    remainingBalance: remaining,
  };
}

/**
 * Computes updated Invoice financial state and status upon applying a new payment.
 */
export function calculateNewInvoiceFinancials(
  invoiceTotal: number,
  currentAuthoritativePaid: number,
  newPaymentAmount: number
): {
  newTotalPaid: number;
  newRemaining: number;
  newStatus: InvoiceStatus;
  isLocked: boolean;
} {
  const safeTotal = Number(invoiceTotal) || 0;
  const newTotalPaid = currentAuthoritativePaid + newPaymentAmount;
  const newRemaining = Math.max(0, safeTotal - newTotalPaid);

  let newStatus: InvoiceStatus = 'Partially Paid';
  let isLocked = false;

  if (newTotalPaid >= safeTotal) {
    newStatus = 'Paid';
    isLocked = true;
  }

  return {
    newTotalPaid,
    newRemaining,
    newStatus,
    isLocked,
  };
}

/**
 * Validates recording permissions for the user (Customers cannot record; Collectors only for assigned invoices).
 */
export function validatePaymentPermissions(params: {
  userRole?: string;
  userId?: string;
  userName?: string;
  invoice: Pick<Invoice, 'assignedCollectorId' | 'assignedCollectorName' | 'isVoid' | 'status'>;
}): {
  allowed: boolean;
  error?: string;
} {
  const role = (params.userRole || '').toLowerCase().trim();

  if (role === 'customer') {
    return {
      allowed: false,
      error: 'Access Denied: Customers are not permitted to record payments.',
    };
  }

  if (params.invoice.isVoid || params.invoice.status === 'Void') {
    return {
      allowed: false,
      error: 'Cannot accept payment on a voided invoice.',
    };
  }

  if (role === 'payment_collector') {
    const collectorId = params.userId || '';
    const collectorName = (params.userName || '').toLowerCase().trim();
    const matchId = params.invoice.assignedCollectorId === collectorId;
    const matchName =
      Boolean(params.invoice.assignedCollectorName) &&
      params.invoice.assignedCollectorName!.toLowerCase().trim() === collectorName;

    if (!matchId && !matchName) {
      return {
        allowed: false,
        error: 'Access Denied: You are only authorized to record payments for invoices assigned to you.',
      };
    }
  }

  return { allowed: true };
}

/**
 * 5. 48-HOUR PAYMENT REVERSAL BUSINESS RULE ARCHITECTURE:
 *
 * Business Rules:
 * - A payment can be reversed ONLY within 48 hours from the exact date/time when that payment was created.
 * - When a payment is created: Reverse must be available immediately.
 * - Until 48 hours have passed: Reverse remains enabled.
 * - After exactly 48 hours have passed: Reverse must automatically become disabled.
 * - Exactly 48 hours = reversal window has ended (strictly elapsed < 48 hours).
 * - Calculation is based on the payment's actual creation timestamp (not invoice creation date, not payment date).
 * - Missing/invalid creation timestamp: Safely assume NOT eligible (Reverse remains disabled).
 * - Already reversed payment: Reverse remains disabled.
 * - Enforced in BOTH client UI and service/database transaction layer.
 */
export const PAYMENT_REVERSAL_WINDOW_HOURS = 48;
export const PAYMENT_REVERSAL_WINDOW_MS = PAYMENT_REVERSAL_WINDOW_HOURS * 60 * 60 * 1000; // 172,800,000 ms

/**
 * Parses any timestamp representation reliably:
 * - Firestore Timestamp (with .toDate(), .toMillis(), seconds/nanoseconds, _seconds/_nanoseconds)
 * - ISO date string
 * - JavaScript Date
 * - Numeric timestamp (milliseconds or seconds)
 */
export function parsePaymentTimestamp(raw: any): number | null {
  if (raw === null || raw === undefined || raw === '') {
    return null;
  }

  // 1. JavaScript Date instance
  if (raw instanceof Date) {
    const t = raw.getTime();
    return isNaN(t) ? null : t;
  }

  // 2. Firestore Timestamp instance or serialized object
  if (typeof raw === 'object') {
    if (typeof raw.toMillis === 'function') {
      const ms = raw.toMillis();
      return typeof ms === 'number' && !isNaN(ms) ? ms : null;
    }
    if (typeof raw.toDate === 'function') {
      const d = raw.toDate();
      const t = d instanceof Date ? d.getTime() : null;
      return t && !isNaN(t) ? t : null;
    }
    if (typeof raw.seconds === 'number') {
      const ms = raw.seconds * 1000 + Math.floor((raw.nanoseconds || 0) / 1000000);
      return isNaN(ms) ? null : ms;
    }
    if (typeof raw._seconds === 'number') {
      const ms = raw._seconds * 1000 + Math.floor((raw._nanoseconds || 0) / 1000000);
      return isNaN(ms) ? null : ms;
    }
    return null;
  }

  // 3. Numeric timestamp
  if (typeof raw === 'number') {
    if (isNaN(raw) || raw <= 0) return null;
    // Standard Unix seconds (<= 10 digits) vs milliseconds (13 digits)
    const ms = raw < 10000000000 ? raw * 1000 : raw;
    return isNaN(ms) ? null : ms;
  }

  // 4. String format (ISO 8601, numeric string, etc.)
  if (typeof raw === 'string') {
    const trimmed = raw.trim();
    if (!trimmed) return null;

    if (/^\d+$/.test(trimmed)) {
      const num = Number(trimmed);
      if (!isNaN(num) && num > 0) {
        return num < 10000000000 ? num * 1000 : num;
      }
    }

    const parsed = Date.parse(trimmed);
    if (!isNaN(parsed)) {
      return parsed;
    }
    return null;
  }

  return null;
}

export interface PaymentReversalEligibility {
  isEligible: boolean;
  isExpired: boolean;
  isAlreadyReversed: boolean;
  hasInvalidTimestamp: boolean;
  elapsedMs: number | null;
  remainingMs: number | null;
  creationTimeMs: number | null;
  reason?: string;
  tooltipText: string;
}

/**
 * Evaluates whether a payment can be reversed under the 48-Hour business rule.
 *
 * @param payment The payment document or record to evaluate
 * @param currentTimestamp Optional custom current timestamp for deterministic testing
 */
export function checkPaymentReversalEligibility(
  payment: Payment | null | undefined,
  currentTimestamp?: number | Date | string
): PaymentReversalEligibility {
  if (!payment) {
    return {
      isEligible: false,
      isExpired: false,
      isAlreadyReversed: false,
      hasInvalidTimestamp: true,
      elapsedMs: null,
      remainingMs: null,
      creationTimeMs: null,
      reason: 'No payment provided.',
      tooltipText: 'Reverse window expired (48 hours).',
    };
  }

  // 1. Check if already reversed/voided
  const isAlreadyReversed = Boolean(
    payment.isVoid === true ||
    (payment as any).status === 'Void' ||
    (payment as any).status === 'reversed'
  );

  if (isAlreadyReversed) {
    return {
      isEligible: false,
      isExpired: false,
      isAlreadyReversed: true,
      hasInvalidTimestamp: false,
      elapsedMs: null,
      remainingMs: null,
      creationTimeMs: null,
      reason: 'Payment has already been reversed.',
      tooltipText: 'Payment has already been reversed.',
    };
  }

  // 2. Extract and validate payment creation timestamp
  // Must use actual payment creation timestamp, NOT invoice date, NOT payment date.
  const rawCreation = (payment as any).createdAt ?? (payment as any).created_at;
  const creationTimeMs = parsePaymentTimestamp(rawCreation);

  if (creationTimeMs === null || isNaN(creationTimeMs)) {
    return {
      isEligible: false,
      isExpired: true,
      isAlreadyReversed: false,
      hasInvalidTimestamp: true,
      elapsedMs: null,
      remainingMs: null,
      creationTimeMs: null,
      reason: 'Payment cannot be reversed: Missing or invalid creation timestamp.',
      tooltipText: 'Reverse window expired (48 hours).',
    };
  }

  // 3. Compare against reference current time
  let nowMs: number;
  if (currentTimestamp !== undefined) {
    const parsedCurrent = parsePaymentTimestamp(currentTimestamp);
    nowMs = parsedCurrent !== null ? parsedCurrent : Date.now();
  } else {
    nowMs = Date.now();
  }

  // Handle minor clock skew gracefully
  const elapsedMs = Math.max(0, nowMs - creationTimeMs);
  const remainingMs = Math.max(0, PAYMENT_REVERSAL_WINDOW_MS - elapsedMs);

  // Reversal window ends exactly at 48 hours (elapsedMs >= PAYMENT_REVERSAL_WINDOW_MS)
  const isExpired = elapsedMs >= PAYMENT_REVERSAL_WINDOW_MS;

  if (isExpired) {
    return {
      isEligible: false,
      isExpired: true,
      isAlreadyReversed: false,
      hasInvalidTimestamp: false,
      elapsedMs,
      remainingMs: 0,
      creationTimeMs,
      reason: 'Payment reversal window expired: Payments can only be reversed within 48 hours of creation.',
      tooltipText: 'Reverse window expired (48 hours).',
    };
  }

  // Fully eligible
  return {
    isEligible: true,
    isExpired: false,
    isAlreadyReversed: false,
    hasInvalidTimestamp: false,
    elapsedMs,
    remainingMs,
    creationTimeMs,
    tooltipText: 'Reverse payment',
  };
}

/**
 * Checks whether user has permission to reverse payments according to the existing permission model.
 */
export function canUserReversePayment(
  userProfile?: { role?: string } | null,
  permissions?: { canReversePayment?: boolean } | null
): boolean {
  if (permissions?.canReversePayment === true) {
    return true;
  }
  if (userProfile?.role === 'super_admin') {
    return true;
  }
  return false;
}
