export type UserRole =
  | 'super_admin'
  | 'invoice_manager'
  | 'payment_collector'
  | 'customer';

export type UserAccountStatus = 'active' | 'inactive' | 'suspended' | 'pending' | 'rejected';

export interface UserPermissions {
  canViewDashboard: boolean;
  canViewInvoices: boolean;
  canCreateInvoice: boolean;
  canEditInvoice: boolean;
  canVoidInvoice: boolean;
  canViewPayments: boolean;
  canCollectPayment: boolean;
  canReversePayment: boolean;
  canViewCustomers: boolean;
  canManageCustomers: boolean;
  canViewExpenses: boolean;
  canCreateExpense?: boolean;
  canManageExpenses: boolean;
  canViewReports: boolean;
  canExportReports: boolean;
  canManageSettings: boolean;
  canManageStaff: boolean;
  canManageUsers: boolean;
  canManageRequests: boolean;
  canManageProjects: boolean;
  canViewAuditLogs: boolean;
  canExportBackup: boolean;
  canAssignInvoice?: boolean;
  canViewPurchaseCostAndProfit?: boolean;
}

export interface EmployeeDocument {
  id: string;
  userId: string; // Associated User ID (ST-U-XXXX)
  documentName: string; // User-friendly document title (e.g. "Employment Contract")
  fileName: string; // Original uploaded file name
  storagePath: string; // Path or identifier
  downloadURL: string; // Download / View URL or data URL
  fileType: string; // 'application/pdf'
  fileSize: number; // File size in bytes
  fileSizeFormatted: string; // Formatted size string (e.g. "2.4 MB")
  uploadedBy: string; // Name or ID of administrator who uploaded
  uploadedAt: string; // ISO 8601 string
}

export type EmploymentStatus = 'active' | 'probation' | 'contract' | 'permanent' | 'on_leave' | 'terminated';

export interface UserProfile {
  id: string; // User ID / Document ID
  userId?: string; // Immutable Official User ID (e.g. ST-U-5000)
  name: string; // Full Name
  username: string; // Username for custom login
  email: string; // Registered Email
  phone?: string; // Phone
  photoURL?: string; // Profile Photo
  role: UserRole; // 4-role system: super_admin | invoice_manager | payment_collector | customer
  status: UserAccountStatus; // Account status
  jobTitle?: string; // Job Title / Position
  department?: string; // Department
  dateOfBirth?: string; // Date of Birth (YYYY-MM-DD)
  gender?: 'male' | 'female' | 'other' | ''; // Gender
  nationalId?: string; // National ID / Identification Number (Tazkira)
  address?: string; // Contact / Residential Address
  emergencyContactName?: string; // Emergency Contact Name
  emergencyContactPhone?: string; // Emergency Contact Phone
  employmentStartDate?: string; // Employment Start Date
  employmentStatus?: EmploymentStatus; // Employment Status
  employeeCode?: string; // Optional Employee Code
  notes?: string; // Administrative Notes
  profileCompletionStatus?: 'complete' | 'incomplete'; // Profile completion status
  passwordHash?: string; // Cryptographically hashed password
  passwordSalt?: string; // Random salt used for password hashing
  mustChangePassword?: boolean; // Mandatory password change flag on first login
  googleUid?: string; // Linked Firebase Google Auth UID
  googleEmail?: string; // Linked Google Email
  permissions?: Partial<UserPermissions>;
  customerId?: string; // Links customer accounts to customers collection
  isDeactivated?: boolean;
  themePreference?: string; // Saved user theme ID (ThemeId)
  createdAt: string;
  updatedAt?: string;
}

export type CustomerType = 'Individual' | 'Business';

export type CustomerCanonicalStatus = 'Active' | 'Inactive' | 'Blocked';
export type CustomerStatus =
  | 'Active'
  | 'Inactive'
  | 'Blocked'
  | 'active'
  | 'deactivated'
  | 'archived';

export interface Customer {
  id: string;
  customerCode?: string; // Stable Customer ID format: ST-CUST-1001
  customerId?: string; // Alias matching customerCode
  customerType?: CustomerType; // 'Individual' | 'Business'
  name: string;
  companyName: string;
  phone: string;
  alternatePhone?: string;
  email?: string;
  address: string;
  city?: string;
  province?: string;
  note: string;
  notes?: string;
  photoURL?: string; // Profile photo upload (preview, change, remove)
  status?: CustomerStatus;
  isArchived?: boolean;
  userId?: string; // Linked user account in users collection
  userUsername?: string; // Linked user's username
  userEmail?: string; // Linked user's email
  hasPortalAccount?: boolean;
  portalEnabled?: boolean;
  createdAt: string;
  updatedAt: string;
  createdBy?: string;
  createdByName?: string;
  updatedBy?: string;
  updatedByName?: string;
}

export interface CustomerSnapshot {
  id: string;
  name: string;
  phone: string;
  email?: string;
  address: string;
  companyName: string;
  customerCode?: string;
  customerType?: CustomerType;
  city?: string;
  province?: string;
}

export interface CompanySnapshot {
  companyName: string;
  logo: string;
  logo2?: string;
  phone: string;
  whatsapp: string;
  email: string;
  address: string;
  website?: string;
  currency: string;
  invoiceNote: string;
  footerText?: string;
}

export interface InvoiceItem {
  sNo: number;
  description: string;
  quantity: number | '';
  unitPrice: number | '';
  totalAmount: number;
  // Purchase Cost and Profit (Phase 1)
  purchaseCost?: number | ''; // Purchase cost per unit (AFN)
  unitProfit?: number; // Unit Selling Price - Unit Purchase Cost
  totalCost?: number; // Unit Purchase Cost × Quantity
  totalSales?: number; // Unit Selling Price × Quantity
  totalProfit?: number; // (Unit Selling Price - Unit Purchase Cost) × Quantity
}

export type InvoiceStatus = 'Paid' | 'Partially Paid' | 'Unpaid' | 'Void';

export type InvoiceBillingState = 'quotation' | 'payable' | 'rejected';

export interface AssignmentHistoryEntry {
  collectorId: string;
  collectorName: string;
  assignedBy: string;
  assignedByName?: string;
  assignedAt: string;
  previousCollectorId?: string;
  previousCollectorName?: string;
}

export interface Invoice {
  id: string;
  billNumber: string; // ST-1060, ST-1061...
  customerId: string;
  customerSnapshot: CustomerSnapshot;
  companySnapshot: CompanySnapshot;
  date: string; // YYYY-MM-DD
  items: InvoiceItem[]; // 20 rows
  totalAmount: number; // Sum of line totals
  note: string;
  assignedCollectorId?: string;
  assignedCollectorName?: string;
  assignedBy?: string;
  assignedByName?: string;
  assignedAt?: string;
  assignmentHistory?: AssignmentHistoryEntry[];
  createdBy?: string;
  createdByName?: string;
  createdAt: string;
  updatedBy?: string;
  updatedByName?: string;
  updatedAt: string;
  status: InvoiceStatus;
  totalPaid?: number;
  remaining?: number;
  totalPurchaseCost?: number;
  totalProfit?: number;
  totalExpenses?: number;
  netProfit?: number;
  expenses?: Expense[];
  dueDate?: string;
  isOverdue?: boolean;
  isLocked?: boolean;
  lockedAt?: string;
  requestId?: string; // Linked customer quote/service request
  templateId?: string; // ID of custom invoice template used for this invoice
  billingState?: InvoiceBillingState;
  acceptedAt?: string;
  acceptedBy?: string;
  acceptanceSource?: string;
  rejectedAt?: string;
  rejectedBy?: string;
  rejectionSource?: string;
  changedBy?: string;
  changedByRole?: string;
  changedAt?: string;
  changeSource?: string;
  isVoid?: boolean;
  voidReason?: string;
  voidedAt?: string;
  voidedBy?: string;
}

export type PaymentMethod =
  | 'CASH'
  | 'BANK_TRANSFER'
  | 'MOBILE_MONEY'
  | 'CARD';

export const ACTIVE_PAYMENT_METHODS: readonly PaymentMethod[] = ['CASH'] as const;

export const SUPPORTED_PAYMENT_METHODS: readonly PaymentMethod[] = [
  'CASH',
  'BANK_TRANSFER',
  'MOBILE_MONEY',
  'CARD',
] as const;

export const PAYMENT_METHOD_LABELS: Record<PaymentMethod, string> = {
  CASH: 'Cash',
  BANK_TRANSFER: 'Bank Transfer',
  MOBILE_MONEY: 'Mobile Money',
  CARD: 'Card',
};

export interface Payment {
  id: string;
  invoiceId: string;
  billNumber: string;
  customerId: string;
  customerName: string;
  amount: number; // AFN
  date: string; // YYYY-MM-DD
  time?: string; // HH:mm:ss
  note?: string; // Optional note, no artificial defaults
  method: PaymentMethod; // Structured payment method (Active: CASH)
  recordedBy?: string;
  recordedByName?: string;
  createdAt: string;
  isCorrection?: boolean;
  correctionRefId?: string;
  correctionReason?: string;
  correctedBy?: string;
  correctedByName?: string;
  correctedAt?: string;
  isVoid?: boolean;
  voidReason?: string;
}

export type PaymentDatePreset =
  | 'all'
  | 'today'
  | 'yesterday'
  | 'this_week'
  | 'this_month'
  | 'last_month'
  | 'custom';

export type PaymentStatusFilter = 'all' | 'completed' | 'reversed';

export type PaymentSortField = 'date' | 'amount' | 'id' | 'customer' | 'invoice';
export type PaymentSortDirection = 'asc' | 'desc';

export type ExpenseStatus =
  | 'draft'
  | 'pending_manager'
  | 'pending_admin'
  | 'approved'
  | 'executed'
  | 'rejected';

export interface ExpenseTimelineEntry {
  action: string;
  performedBy: string;
  performedByName: string;
  performedByRole: string;
  timestamp: string;
  note?: string;
}

export interface Expense {
  id: string;
  title: string;
  amount: number; // AFN
  date: string; // YYYY-MM-DD
  category?: string;
  note: string;
  requestedBy: string;
  requestedByName: string;
  requestedByRole: string;
  status: ExpenseStatus;
  executionStatus?: 'executed' | 'pending' | 'unexecuted' | string;
  managerApprovedBy?: string;
  managerApprovedByName?: string;
  managerApprovedAt?: string;
  adminApprovedBy?: string;
  adminApprovedByName?: string;
  adminApprovedAt?: string;
  executedBy?: string;
  executedByName?: string;
  executedAt?: string;
  rejectionReason?: string;
  rejectedBy?: string;
  rejectedByName?: string;
  rejectedAt?: string;
  resubmissionReason?: string;
  resubmittedBy?: string;
  resubmittedByName?: string;
  resubmittedAt?: string;
  resubmissionCorrections?: string;
  timeline?: ExpenseTimelineEntry[];
  createdAt: string;
  updatedAt?: string;
  updatedBy?: string;
  updatedByName?: string;
  invoiceId?: string;
  billNumber?: string;
}

export interface ReceiptDesignSettings {
  logo1?: string;
  logo2?: string;
  logoSize: 'sm' | 'md' | 'lg';
  logoPosition: 'left' | 'right' | 'both' | 'center';
  headerHeight: number;
  headerText: string;
  fontSize: 'sm' | 'md' | 'lg';
  alignment: 'left' | 'center' | 'right';
  spacing: 'compact' | 'normal' | 'relaxed';
  margins: 'compact' | 'normal' | 'generous';
  showCustomerPhone: boolean;
  showCustomerAddress: boolean;
  showCustomerEmail: boolean;
  showPaymentMethod: boolean;
  showRecordedBy: boolean;
  showPreviousRemaining: boolean;
  showCurrentRemaining: boolean;
  showNote: boolean;
  showFooter: boolean;
  footerText: string;
}

export interface CustomerRegistration {
  id: string;
  name: string;
  phone: string;
  email?: string;
  companyName?: string;
  address: string;
  note?: string;
  otpVerified: boolean;
  status: 'pending' | 'active' | 'rejected';
  matchType?: 'Strong Match' | 'Possible Match' | 'No Match';
  matchedCustomerId?: string;
  rejectionReason?: string;
  reviewedBy?: string;
  reviewedAt?: string;
  createdAt: string;
  updatedAt: string;
}

export interface Service {
  id: string;
  title: string;
  description: string;
  image?: string;
  icon?: string;
  displayOrder: number;
  isPublished: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface Post {
  id: string;
  title: string;
  summary: string;
  content: string;
  coverImage?: string;
  category: string;
  author: string;
  isPublished: boolean;
  publishedAt?: string;
  createdAt: string;
  updatedAt: string;
}

export interface AuditLogChange {
  field: string;
  oldValue: any;
  newValue: any;
}

export interface AuditLog {
  id: string;
  action:
    | 'create_invoice'
    | 'edit_invoice'
    | 'void_invoice'
    | 'delete_invoice'
    | 'accept_quotation'
    | 'reject_quotation'
    | 'record_payment'
    | 'reverse_payment'
    | 'create_customer'
    | 'edit_customer'
    | 'CUSTOMER_CREATED'
    | 'CUSTOMER_UPDATED'
    | 'CUSTOMER_DEACTIVATED'
    | 'CUSTOMER_REACTIVATED'
    | 'CUSTOMER_BLOCKED'
    | 'CUSTOMER_UNBLOCKED'
    | 'CUSTOMER_DELETED'
    | 'PORTAL_ENABLED'
    | 'PORTAL_DISABLED'
    | 'change_role'
    | 'update_settings'
    | 'backup_export'
    | 'reply_request'
    | 'bootstrap_super_admin'
    | 'change_admin_code'
    | 'create_user'
    | 'reset_password';
  userId: string;
  userName: string;
  userRole?: string;
  entityType: 'invoice' | 'payment' | 'customer' | 'settings' | 'request' | 'user' | 'security';
  entityId: string;
  referenceNumber?: string;
  dateTime: string;
  summary: string;
  changes?: AuditLogChange[];
}

export interface CustomerMigrationSummary {
  totalInspected: number;
  alreadyCompliant: number;
  migratedCount: number;
  missingCodesFixed: number;
  duplicatesDetected: string[];
  highestAllocatedCode: string;
  maxNumericValue: number;
  errors: Array<{ customerId: string; error: string }>;
  success: boolean;
  timestamp: string;
}

export interface RequestAttachment {
  id: string;
  name: string;
  url: string;
  type: 'image' | 'video' | 'audio' | 'document';
  size?: number;
}

export interface CustomerRequestReply {
  id: string;
  senderId: string;
  senderName: string;
  senderRole: UserRole | 'staff';
  message: string;
  createdAt: string;
  attachments?: RequestAttachment[];
}

export type RequestStatus =
  | 'New'
  | 'In Review'
  | 'Quoted'
  | 'Invoice Created'
  | 'Completed'
  | 'Cancelled';

export interface CustomerRequest {
  id: string;
  customerId: string;
  customerName: string;
  customerPhone: string;
  customerEmail?: string;
  title: string;
  description: string;
  mediaType: 'text' | 'voice' | 'image' | 'video' | 'mixed';
  attachments: RequestAttachment[];
  voiceNoteUrl?: string;
  voiceNoteDuration?: number;
  status: RequestStatus;
  invoiceId?: string;
  billNumber?: string;
  replies: CustomerRequestReply[];
  createdAt: string;
  updatedAt: string;
}

export interface Project {
  id: string;
  title: string;
  description: string;
  category: string; // e.g. 'Security Cameras', 'Biometric Access', 'Solar Systems', 'Network Setup'
  images: string[];
  videoUrl?: string;
  isPublished: boolean;
  isFeatured: boolean;
  date: string;
  createdAt: string;
}

export interface AppNotification {
  id: string;
  target: 'staff' | 'customer' | string; // user ID, role, or general audience
  recipientId?: string;
  userId?: string;
  role?: string;
  customerId?: string;
  title: string;
  message: string;
  type: 'invoice' | 'payment' | 'expense' | 'request' | 'project' | 'system';
  linkId?: string;
  entityId?: string;
  entityType?: 'invoice' | 'payment' | 'expense' | 'request' | 'customer' | 'system';
  isRead: boolean;
  createdAt: string;
}

export * from './invoiceDesign';
import { InvoiceDesignSettings } from './invoiceDesign';

export interface CustomInvoiceTemplate {
  id: string;
  name: string;
  category: string; // e.g. 'Service' | 'Corporate' | 'Retail' | 'Maintenance' | 'Wholesale' | string
  targetServiceOrClient?: string;
  description?: string;
  design: InvoiceDesignSettings;
  createdAt: string;
  updatedAt: string;
  isDefault?: boolean;
}

export interface BusinessSettings {
  companyName: string;
  logo: string;
  logo2?: string;
  phone: string;
  whatsapp: string;
  email: string;
  address: string;
  website?: string;
  invoicePrefix: string;
  nextInvoiceNumber: number; // e.g. 1060
  customerPrefix?: string; // e.g. CUST-
  nextCustomerNumber?: number; // e.g. 1001
  currency: string; // AFN
  invoiceNote: string;
  footerText?: string;
  authorizedEmails: string[];
  loginTitle?: string;
  loginSubtitle?: string;
  loginWelcome?: string;
  loginLogo?: string;
  loginBackground?: string;
  invoiceDesign?: InvoiceDesignSettings;
  customTemplates?: CustomInvoiceTemplate[];
  activeTemplateId?: string;
  receiptDesign?: ReceiptDesignSettings;
  defaultTheme?: string; // Global default theme ID set by Super Admin (ThemeId)
}
