/**
 * Sarwan Technology Billing System
 * Full-Stack Express Server Entry Point
 * 
 * Provides trusted server-side authentication, password verification,
 * step-up authorization, and mounts Vite middlewares in development.
 */

import express, { Request, Response } from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import {
  authenticateAndMigrateUserServer,
  verifySuperAdminPasswordServer,
  verifySessionServer,
} from './src/services/authBackendService';
import { correctPayment } from './src/services/db';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = parseInt(process.env.PORT || '3000', 10);
const isProd = process.env.NODE_ENV === 'production';

app.use(express.json());

// Request logging for auditability
app.use((req, res, next) => {
  if (req.path.startsWith('/api/')) {
    const timestamp = new Date().toISOString();
    console.log(`[${timestamp}] ${req.method} ${req.path}`);
  }
  next();
});

// Health check endpoint
app.get('/api/health', (req: Request, res: Response) => {
  res.json({
    status: 'ok',
    system: 'Sarwan Technology Billing System',
    timestamp: new Date().toISOString(),
    environment: isProd ? 'production' : 'development',
  });
});

// Trusted Server Login & Migration Endpoint
app.post('/api/auth/login', async (req: Request, res: Response) => {
  try {
    const { identifier, password } = req.body;
    if (!identifier || !password) {
      return res.status(400).json({
        success: false,
        error: 'Identifier and password are required.',
      });
    }

    const result = await authenticateAndMigrateUserServer({ identifier, password });
    return res.json(result);
  } catch (err: any) {
    const errorMessage = err?.message || 'Authentication failed.';
    const statusCode =
      errorMessage.includes('Invalid username') || errorMessage.includes('Invalid password')
        ? 401
        : 400;
    return res.status(statusCode).json({
      success: false,
      error: errorMessage,
    });
  }
});

// Server-Side Super Admin Password Verification Endpoint
app.post('/api/auth/verify-super-admin', async (req: Request, res: Response) => {
  try {
    const { userId, password } = req.body;
    if (!userId || !password) {
      return res.status(400).json({
        isValid: false,
        error: 'User ID and password are required.',
      });
    }

    const result = await verifySuperAdminPasswordServer({ userId, password });
    return res.json(result);
  } catch (err: any) {
    return res.status(500).json({
      isValid: false,
      error: err?.message || 'Verification failed.',
    });
  }
});

// Server-Side Payment Reversal Authorization Check
app.post('/api/auth/reversal-auth', async (req: Request, res: Response) => {
  try {
    const { userId, password, userRole } = req.body;
    if (userRole !== 'super_admin') {
      return res.status(403).json({
        isAuthorized: false,
        error: 'Access Denied: Only Super Admin is authorized to reverse payments.',
      });
    }

    const result = await verifySuperAdminPasswordServer({ userId, password });
    if (!result.isValid) {
      return res.status(401).json({
        isAuthorized: false,
        error: result.error || 'Authentication Failed: Incorrect Super Admin password.',
      });
    }

    return res.json({ isAuthorized: true });
  } catch (err: any) {
    return res.status(500).json({
      isAuthorized: false,
      error: err?.message || 'Authorization check failed.',
    });
  }
});

// Server-Side Session Verification Endpoint
// Cryptographically verifies ID token and prevents client-side localStorage privilege tampering
app.post('/api/auth/verify-session', async (req: Request, res: Response) => {
  try {
    const { idToken, userId } = req.body;
    if (!idToken || !userId) {
      return res.status(400).json({
        isValid: false,
        error: 'Token and User ID are required.',
      });
    }

    const result = await verifySessionServer({ idToken, userId });
    const statusCode = result.isValid ? 200 : 401;
    return res.status(statusCode).json(result);
  } catch (err: any) {
    return res.status(500).json({
      isValid: false,
      error: err?.message || 'Session verification error.',
    });
  }
});

// Server-Side Secure Payment Reversal Endpoint
app.post('/api/payments/reverse', async (req: Request, res: Response) => {
  try {
    const {
      paymentId,
      invoiceId,
      reason,
      password,
      userId,
      userName,
      userRole,
      correctedAmount,
      correctedNote,
    } = req.body;

    if (!paymentId || !invoiceId || !reason || !password || !userId) {
      return res.status(400).json({
        success: false,
        error: 'Missing required parameters for payment reversal.',
      });
    }

    if (userRole !== 'super_admin') {
      return res.status(403).json({
        success: false,
        error: 'Access Denied: Only Super Admin can reverse payments.',
      });
    }

    const replacementPaymentId = await correctPayment({
      paymentId,
      invoiceId,
      reason,
      password,
      userId,
      userName: userName || 'Super Admin',
      userRole: 'super_admin',
      correctedAmount,
      correctedNote,
    });

    return res.json({
      success: true,
      paymentId,
      replacementPaymentId,
      message: 'Payment reversed successfully.',
    });
  } catch (err: any) {
    return res.status(400).json({
      success: false,
      error: err?.message || 'Payment reversal failed.',
    });
  }
});

// Initialize Frontend Handling (Vite in Dev, Static in Prod)
async function startServer() {
  if (!isProd) {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true, host: '0.0.0.0', port: PORT },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (req, res) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Sarwan Billing System server running on http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Server startup error:', err);
  process.exit(1);
});
