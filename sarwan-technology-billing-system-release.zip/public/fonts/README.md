# Mokoto Font Assets Directory

## Mandatory Primary Font: Mokoto
Designed by Drizy Studio.
Mokoto is the mandatory primary font family for the Sarwan Technology Billing System.

### Expected Files
Place any of the following valid font files in this directory (`/public/fonts/`):
- `mokoto.woff2` (Recommended modern web format)
- `mokoto.woff`
- `mokoto.ttf` (TrueType format)
- `mokoto-regular.woff2`
- `mokoto-bold.woff2`

### Global Registration
The application registers `@font-face` for `'Mokoto'` in `src/index.css` and sets `--font-family-primary: 'Mokoto', ...`.
Once valid font files are added to this folder, they will be loaded automatically by the browser with swap display and comprehensive RTL/Latin fallback.

### License Note
Mokoto is a proprietary typeface by Drizy Studio. A valid commercial license is required for commercial deployments.
