/**
 * Sarwan Technology Billing System
 * Trusted Authentication & Migration Backend Service
 * 
 * Provides server-side credential evaluation, timing-safe verification,
 * identity binding to Firebase Authentication, and sanitization of user data.
 */

import crypto from 'crypto';
import https from 'https';
import {
  collection,
  doc,
  getDoc,
  getDocs,
  query,
  updateDoc,
  where,
  runTransaction,
} from 'firebase/firestore';
import { db } from './firebase';
import { UserProfile, UserRole } from '../types';
import firebaseConfig from '../../firebase-applet-config.json';
import { resolveCustomerSafely } from './authMigrationService';

export const AUTH_DOMAIN_STAFF = 'auth.sarwan.tech';
export const AUTH_DOMAIN_CUSTOMER = 'customer.sarwan.tech';

/**
 * Performs timing-safe comparison of two hex-encoded hashes to prevent side-channel attacks.
 */
export function timingSafeCompare(a: string, b: string): boolean {
  if (!a || !b || a.length !== b.length) {
    return false;
  }
  try {
    const bufA = Buffer.from(a, 'hex');
    const bufB = Buffer.from(b, 'hex');
    if (bufA.length !== bufB.length) {
      return false;
    }
    return crypto.timingSafeEqual(bufA, bufB);
  } catch {
    return false;
  }
}

/**
 * Computes SHA-256 hash using Node.js crypto: SHA-256(password.trim() + ':' + salt)
 */
export function computeServerPasswordHash(password: string, salt: string): string {
  const hash = crypto.createHash('sha256');
  hash.update(`${password.trim()}:${salt}`);
  return hash.digest('hex');
}

/**
 * Server-side verification of legacy password against stored salt and hash.
 */
export function verifyLegacyPasswordServer(
  enteredPassword: string,
  storedSalt?: string,
  storedHash?: string
): boolean {
  if (!enteredPassword || !storedSalt || !storedHash) {
    return false;
  }
  const computed = computeServerPasswordHash(enteredPassword, storedSalt);
  return timingSafeCompare(computed, storedHash);
}

/**
 * Generates an immutable, canonical Firebase Authentication email.
 * Derived from immutable system IDs (ST-U-xxxx or CUST-xxxx), never mutable display names.
 */
export function getImmutableAuthEmail(user: { id: string; userId?: string; customerId?: string; role: UserRole; email?: string }): string {
  if (user.role === 'customer' && user.customerId) {
    const cleanCust = user.customerId.trim().toLowerCase().replace(/[^a-z0-9._-]/g, '_');
    return `c.${cleanCust}@${AUTH_DOMAIN_CUSTOMER}`;
  }
  const officialId = (user.userId || user.id).trim().toLowerCase().replace(/[^a-z0-9._-]/g, '_');
  return `u.${officialId}@${AUTH_DOMAIN_STAFF}`;
}

/**
 * Strips sensitive cryptographic credentials from user profile before sending to client.
 */
export function sanitizeUserProfile(profile: UserProfile): Omit<UserProfile, 'passwordHash' | 'passwordSalt'> {
  const sanitized = { ...profile };
  delete sanitized.passwordHash;
  delete sanitized.passwordSalt;
  return sanitized;
}

/**
 * Identity Toolkit REST API client for Firebase Authentication operations.
 */
interface IdentityToolkitResponse {
  kind?: string;
  idToken?: string;
  refreshToken?: string;
  expiresIn?: string;
  localId?: string;
  email?: string;
  error?: {
    code: number;
    message: string;
    errors?: Array<{ message: string; domain: string; reason: string }>;
  };
}

export async function callIdentityToolkit(
  endpoint: 'accounts:signInWithPassword' | 'accounts:signUp' | 'accounts:update' | 'accounts:lookup',
  payload: Record<string, any>
): Promise<IdentityToolkitResponse & { users?: Array<{ localId: string; email: string }> }> {
  const apiKey = firebaseConfig.apiKey;
  const url = `https://identitytoolkit.googleapis.com/v1/${endpoint}?key=${apiKey}`;
  const data = JSON.stringify(payload);

  return new Promise((resolve, reject) => {
    const req = https.request(
      url,
      {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Content-Length': Buffer.byteLength(data),
        },
      },
      (res) => {
        let responseBody = '';
        res.on('data', (chunk) => {
          responseBody += chunk;
        });
        res.on('end', () => {
          try {
            const parsed = JSON.parse(responseBody);
            resolve(parsed);
          } catch (e) {
            reject(new Error(`Failed to parse Identity Toolkit response: ${responseBody}`));
          }
        });
      }
    );

    req.on('error', (err) => {
      reject(err);
    });

    req.write(data);
    req.end();
  });
}

/**
 * Central Server-Side Login & JIT Migration Handler
 */
export async function authenticateAndMigrateUserServer(params: {
  identifier: string;
  password: string;
}): Promise<{
  success: boolean;
  idToken: string;
  refreshToken: string;
  localId: string;
  user: Omit<UserProfile, 'passwordHash' | 'passwordSalt'>;
  migrationStatus: 'ALREADY_MIGRATED' | 'MIGRATED_JIT';
}> {
  const cleanInput = (params.identifier || '').trim();
  const password = params.password || '';

  if (!cleanInput) {
    throw new Error('Please enter your username, email, or phone number.');
  }
  if (!password) {
    throw new Error('Please enter your password.');
  }

  // 1. Resolve target user document from Firestore
  const usersCol = collection(db, 'users');
  let targetDocSnap: any = null;

  // A. Search by exact username (lowercase)
  const qUsername = query(usersCol, where('username', '==', cleanInput.toLowerCase()));
  const snapUsername = await getDocs(qUsername);
  if (!snapUsername.empty) {
    targetDocSnap = snapUsername.docs[0];
  } else {
    // B. Search by email
    const qEmail = query(usersCol, where('email', '==', cleanInput.toLowerCase()));
    const snapEmail = await getDocs(qEmail);
    if (!snapEmail.empty) {
      targetDocSnap = snapEmail.docs[0];
    } else {
      // C. Search by phone number (customer login)
      const qPhone = query(usersCol, where('phone', '==', cleanInput));
      const snapPhone = await getDocs(qPhone);
      if (!snapPhone.empty) {
        if (snapPhone.docs.length > 1) {
          throw new Error(
            'Multiple accounts found matching this phone number. Please contact Sarwan support to resolve account ambiguity.'
          );
        }
        targetDocSnap = snapPhone.docs[0];
      } else {
        // D. Check customer table directly to see if phone is ambiguous
        const custResolution = await resolveCustomerSafely(cleanInput);
        if (custResolution.status === 'AMBIGUOUS') {
          throw new Error(
            custResolution.error || 'Multiple customer records found matching this phone number.'
          );
        }
      }
    }
  }

  if (!targetDocSnap) {
    throw new Error('Invalid username or password. Please check your credentials and try again.');
  }

  const userData = targetDocSnap.data() as UserProfile;
  const userDocId = targetDocSnap.id;

  // 2. Account Status & Authorization Validation
  const status = userData.status || (userData.isDeactivated ? 'inactive' : 'active');
  if (status !== 'active' || userData.isDeactivated === true) {
    throw new Error('Your account is inactive or deactivated. Please contact the Super Admin.');
  }

  const validRoles: UserRole[] = ['super_admin', 'invoice_manager', 'payment_collector', 'customer'];
  if (!userData.role || !validRoles.includes(userData.role)) {
    throw new Error('Your account role is not authorized to access this application.');
  }

  // 3. Evaluate Credentials & Migration State Machine
  const canonicalEmail = getImmutableAuthEmail(userData);

  // Check if user has legacy password credentials to verify
  let isPasswordValid = false;
  if (userData.passwordHash && userData.passwordSalt) {
    isPasswordValid = verifyLegacyPasswordServer(password, userData.passwordSalt, userData.passwordHash);
  }

  // Case A: User has not yet migrated in Firebase Auth
  if (isPasswordValid) {
    // Legacy credentials verified in server memory!
    // Provision or sync account on Firebase Authentication
    let authRes = await callIdentityToolkit('accounts:signInWithPassword', {
      email: canonicalEmail,
      password: password,
      returnSecureToken: true,
    });

    let migrationStatus: 'ALREADY_MIGRATED' | 'MIGRATED_JIT' = 'ALREADY_MIGRATED';

    if (authRes.error) {
      // Account does not exist in Firebase Auth yet -> create it
      if (
        authRes.error.message.includes('EMAIL_NOT_FOUND') ||
        authRes.error.message.includes('INVALID_LOGIN_CREDENTIALS')
      ) {
        authRes = await callIdentityToolkit('accounts:signUp', {
          email: canonicalEmail,
          password: password,
          returnSecureToken: true,
        });

        if (authRes.error && authRes.error.message.includes('EMAIL_EXISTS')) {
          // Orphaned account from prior partial failure -> update password to sync
          authRes = await callIdentityToolkit('accounts:update', {
            email: canonicalEmail,
            password: password,
            returnSecureToken: true,
          });
        }
        migrationStatus = 'MIGRATED_JIT';
      } else {
        throw new Error(authRes.error.message || 'Authentication provider error.');
      }
    }

    if (!authRes.idToken || !authRes.localId) {
      throw new Error('Authentication session token could not be issued.');
    }

    // Step 4: Bind identity to Firestore user document
    const now = new Date().toISOString();
    const updatePatch: Partial<UserProfile> & { authUid: string; authEmail: string; migrationStatus: string } = {
      authUid: authRes.localId,
      authEmail: canonicalEmail,
      migrationStatus: 'MIGRATED',
      updatedAt: now,
    };

    await updateDoc(doc(db, 'users', userDocId), updatePatch).catch((err) => {
      console.warn('Notice: Firestore user document binding notice:', err);
    });

    const fullProfile: UserProfile = {
      ...userData,
      id: userDocId,
      authUid: authRes.localId,
      authEmail: canonicalEmail,
      status: 'active',
    };

    return {
      success: true,
      idToken: authRes.idToken,
      refreshToken: authRes.refreshToken || '',
      localId: authRes.localId,
      user: sanitizeUserProfile(fullProfile),
      migrationStatus,
    };
  }

  // Case B: Account already migrated (hashes purged), verify directly against Firebase Auth
  const directAuthRes = await callIdentityToolkit('accounts:signInWithPassword', {
    email: canonicalEmail,
    password: password,
    returnSecureToken: true,
  });

  if (directAuthRes.error || !directAuthRes.idToken || !directAuthRes.localId) {
    throw new Error('Invalid username or password. Please check your credentials and try again.');
  }

  const fullProfile: UserProfile = {
    ...userData,
    id: userDocId,
    authUid: directAuthRes.localId,
    authEmail: canonicalEmail,
    status: 'active',
  };

  return {
    success: true,
    idToken: directAuthRes.idToken,
    refreshToken: directAuthRes.refreshToken || '',
    localId: directAuthRes.localId,
    user: sanitizeUserProfile(fullProfile),
    migrationStatus: 'ALREADY_MIGRATED',
  };
}

/**
 * Server-Side Super Admin Password Verification
 * Used for high-security step-up authorization (e.g. Payment Reversal)
 */
export async function verifySuperAdminPasswordServer(params: {
  userId: string;
  password: string;
}): Promise<{ isValid: boolean; error?: string }> {
  if (!params.userId || !params.password) {
    return { isValid: false, error: 'User ID and password are required.' };
  }

  try {
    const userDocRef = doc(db, 'users', params.userId);
    let userSnap = await getDoc(userDocRef);

    if (!userSnap.exists()) {
      const usersCol = collection(db, 'users');
      const q = query(usersCol, where('role', '==', 'super_admin'));
      const qSnap = await getDocs(q);
      const matched = qSnap.docs.find(
        (d) => d.id === params.userId || (d.data() as UserProfile).id === params.userId
      );
      if (matched) {
        userSnap = matched as any;
      }
    }

    if (!userSnap.exists()) {
      return { isValid: false, error: 'Access Denied: Super Admin account not found.' };
    }

    const userData = userSnap.data() as UserProfile;
    if (userData.role !== 'super_admin') {
      return { isValid: false, error: 'Access Denied: Only Super Admin is authorized for this operation.' };
    }

    // 1. Try legacy hash verification if present
    if (userData.passwordSalt && userData.passwordHash) {
      const match = verifyLegacyPasswordServer(params.password, userData.passwordSalt, userData.passwordHash);
      if (match) {
        return { isValid: true };
      }
    }

    // 2. Try Firebase Auth verification using canonical email
    const canonicalEmail = getImmutableAuthEmail(userData);
    const authRes = await callIdentityToolkit('accounts:signInWithPassword', {
      email: canonicalEmail,
      password: params.password,
      returnSecureToken: false,
    });

    if (!authRes.error && authRes.localId) {
      return { isValid: true };
    }

    return { isValid: false, error: 'Authentication Failed: Incorrect Super Admin password.' };
  } catch (err: any) {
    return { isValid: false, error: err.message || 'Password verification error.' };
  }
}

/**
 * Server-Side Session Verification Handler.
 * Validates the user's Firebase ID token against Google Identity Toolkit.
 * Ensures client-side storage tampering cannot grant Super Admin or unauthorized access.
 */
export async function verifySessionServer(params: {
  idToken: string;
  userId: string;
}): Promise<{
  isValid: boolean;
  user?: Omit<UserProfile, 'passwordHash' | 'passwordSalt'>;
  error?: string;
}> {
  if (!params.idToken || !params.userId) {
    return { isValid: false, error: 'Session token and user ID are required.' };
  }

  try {
    // 1. Verify token with Identity Toolkit
    const lookupRes = await callIdentityToolkit('accounts:lookup', {
      idToken: params.idToken,
    });

    if (lookupRes.error || !lookupRes.users || lookupRes.users.length === 0) {
      return { isValid: false, error: 'Session expired or invalid authentication token.' };
    }

    const authUser = lookupRes.users[0];
    const authLocalId = authUser.localId;

    // 2. Fetch user document from Firestore
    let userSnap = await getDoc(doc(db, 'users', params.userId));
    if (!userSnap.exists()) {
      // Try resolving by authUid
      const qAuth = query(collection(db, 'users'), where('authUid', '==', authLocalId));
      const qSnap = await getDocs(qAuth);
      if (!qSnap.empty) {
        userSnap = qSnap.docs[0];
      }
    }

    if (!userSnap.exists()) {
      return { isValid: false, error: 'User record not found.' };
    }

    const userData = userSnap.data() as UserProfile;
    const status = userData.status || (userData.isDeactivated ? 'inactive' : 'active');

    if (status !== 'active' || userData.isDeactivated === true) {
      return { isValid: false, error: 'Account is deactivated or inactive.' };
    }

    const validRoles: UserRole[] = ['super_admin', 'invoice_manager', 'payment_collector', 'customer'];
    if (!userData.role || !validRoles.includes(userData.role)) {
      return { isValid: false, error: 'Unauthorized role assignment.' };
    }

    const fullProfile: UserProfile = {
      ...userData,
      id: userSnap.id,
      status: 'active',
      authUid: authLocalId,
    };

    return {
      isValid: true,
      user: sanitizeUserProfile(fullProfile),
    };
  } catch (err: any) {
    return { isValid: false, error: err.message || 'Session verification failed.' };
  }
}

