import { initializeApp, getApps, getApp, FirebaseApp } from 'firebase/app';
import { getAuth, GoogleAuthProvider, Auth } from 'firebase/auth';
import {
  initializeFirestore,
  getFirestore,
  doc,
  getDocFromServer,
  setLogLevel,
  Firestore,
} from 'firebase/firestore';
import firebaseConfigJson from '../../firebase-applet-config.json';

// In preview/iframe sandbox environments, silence the internal WebChannel stream warning
// which logs an error to console before switching to long-polling or local offline cache.
setLogLevel('silent');

const firebaseConfig = {
  apiKey: firebaseConfigJson.apiKey,
  authDomain: firebaseConfigJson.authDomain,
  projectId: firebaseConfigJson.projectId,
  storageBucket: firebaseConfigJson.storageBucket,
  messagingSenderId: firebaseConfigJson.messagingSenderId,
  appId: firebaseConfigJson.appId,
};

export let app: FirebaseApp;
if (!getApps().length) {
  app = initializeApp(firebaseConfig);
} else {
  app = getApp();
}

export const auth: Auth = getAuth(app);

// Use custom firestoreDatabaseId if provided, else standard default
const databaseId = firebaseConfigJson.firestoreDatabaseId || '(default)';

// Initialize Firestore with auto-detect long polling and robust long polling settings
let firestoreInstance: Firestore;
try {
  firestoreInstance = initializeFirestore(
    app,
    {
      experimentalAutoDetectLongPolling: true,
      experimentalLongPollingOptions: {
        timeoutSeconds: 20,
      },
      ignoreUndefinedProperties: true,
    },
    databaseId
  );
} catch {
  try {
    firestoreInstance = initializeFirestore(
      app,
      {
        experimentalForceLongPolling: true,
        ignoreUndefinedProperties: true,
      },
      databaseId
    );
  } catch {
    firestoreInstance = getFirestore(app, databaseId);
  }
}

export const db: Firestore = firestoreInstance;

// Helper to check connection to Firestore gracefully without unhandled server-side errors
export async function testConnection(retries = 3): Promise<boolean> {
  for (let i = 0; i < retries; i++) {
    try {
      await getDocFromServer(doc(db, 'test', 'connection'));
      return true;
    } catch (error: any) {
      if (i === retries - 1) {
        if (
          error instanceof Error &&
          (error.message.includes('the client is offline') ||
            error.message.includes('unavailable'))
        ) {
          console.info(
            'Firestore connection notice: operating with offline cache or establishing backend connection.'
          );
        }
        return false;
      }
      await new Promise((resolve) => setTimeout(resolve, 800 * (i + 1)));
    }
  }
  return false;
}

// Perform boot connection check non-blockingly
if (typeof window !== 'undefined') {
  testConnection().catch(() => {});
}

export function getSecondaryAuth(): Auth {
  const secondaryAppName = 'SarwanSecondaryAuthApp';
  const existing = getApps().find((a) => a.name === secondaryAppName);
  const secondaryApp = existing || initializeApp(firebaseConfig, secondaryAppName);
  return getAuth(secondaryApp);
}

export const googleProvider = new GoogleAuthProvider();
googleProvider.setCustomParameters({
  prompt: 'select_account',
});

