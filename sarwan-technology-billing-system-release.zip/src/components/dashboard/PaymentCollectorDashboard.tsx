import React, { useState } from 'react';
import { PaymentCollectorDashboardData } from '../../services/dashboardAuthorization';
import { Invoice, Payment, Customer, BusinessSettings } from '../../types';
import {
  formatAFN,
  formatDate,
  calculateTotalPaidForInvoice,
  calculateRemaining,
  getTodayDateString,
} from '../../utils/format';
import {
  Wallet,
  DollarSign,
  FileText,
  Users,
  CheckCircle2,
  Clock,
  AlertCircle,
  Plus,
  Receipt,
  Phone,
  ChevronRight,
  ShieldCheck,
} from 'lucide-react';
import { ActiveTab } from '../layout/Sidebar';

interface PaymentCollectorDashboardProps {
  data: PaymentCollectorDashboardData;
  settings: BusinessSettings;
  onAddPayment: (invoiceId?: string) => void;
  onAddExpense?: () => void;
  onSelectInvoice: (invoice: Invoice) => void;
  onSelectPayment?: (payment: Payment) => void;
  onSelectCustomer?: (customer: Customer) => void;
  onTabChange?: (tab: ActiveTab) => void;
  payments: Payment[];
}

export const PaymentCollectorDashboard: React.FC<PaymentCollectorDashboardProps> = ({
  data,
  settings,
  onAddPayment,
  onAddExpense,
  onSelectInvoice,
  onSelectPayment,
  onSelectCustomer,
  onTabChange,
  payments,
}) => {
  const [activeSubTab, setActiveSubTab] = useState<'invoices' | 'customers'>('invoices');
  const todayStr = getTodayDateString();

  return (
    <div className="space-y-6">
      {/* Top Banner: Collector Work Desk */}
      <div className="bg-neutral-900 text-white rounded-2xl p-6 sm:p-7 shadow-xs border border-neutral-800 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-6">
        <div className="flex items-center gap-4">
          <div
            className="w-14 h-14 bg-white flex items-center justify-center shrink-0 overflow-hidden shadow-xs p-1.5"
            style={{ borderRadius: '100%', border: 'none' }}
          >
            <img
              src={settings?.logo || '/sarwan-logo.png'}
              alt="Sarwan Technology"
              className="max-h-full max-w-full object-contain"
              onError={(e) => {
                const target = e.currentTarget;
                if (target.src.endsWith('.png')) target.src = '/sarwan-logo.svg';
              }}
            />
          </div>
          <div>
            <div className="flex items-center gap-2 flex-wrap">
              <h1 className="text-xl sm:text-2xl font-black tracking-tight text-white">
                Payment Collector Desk
              </h1>
              <span className="text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 rounded-full flex items-center gap-1">
                <ShieldCheck className="w-3 h-3" />
                Assigned Collections Only
              </span>
            </div>
            <p className="text-xs text-neutral-400 mt-1">
              Field Cash Collections: <span className="text-white font-semibold">{data.collectorName}</span>
            </p>
          </div>
        </div>

        {/* Quick Actions (Authorized Only) */}
        <div className="flex flex-wrap items-center gap-2 w-full sm:w-auto">
          {data.quickActionsAllowed.canCollectPayment && (
            <button
              onClick={() => onAddPayment()}
              className="flex-1 sm:flex-initial px-4 py-2.5 bg-[#2563EB] hover:bg-[#1D4ED8] active:bg-[#1E40AF] text-white text-xs font-bold rounded-lg shadow-xs transition inline-flex items-center justify-center gap-1.5 cursor-pointer active:scale-98 focus:outline-none focus-visible:ring-2 focus-visible:ring-[#2563EB]"
            >
              <Plus className="w-4 h-4" />
              Collect Cash Payment
            </button>
          )}

          {data.quickActionsAllowed.canManageExpenses && onAddExpense && (
            <button
              onClick={onAddExpense}
              className="flex-1 sm:flex-initial px-3.5 py-2.5 bg-neutral-800 hover:bg-neutral-700 text-white text-xs font-semibold rounded-lg border border-neutral-700 transition inline-flex items-center justify-center gap-1.5 cursor-pointer"
            >
              <Receipt className="w-3.5 h-3.5 text-rose-400" />
              Expense Request
            </button>
          )}
        </div>
      </div>

      {/* KPI Cards: Assigned Financial Work */}
      <div className="grid grid-cols-2 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Total Assigned Invoices */}
        <div className="bg-white rounded-xl p-4 border border-neutral-200 shadow-xs">
          <div className="flex items-center justify-between text-neutral-500 mb-2">
            <span className="text-[11px] font-bold uppercase tracking-wide">Assigned Invoices</span>
            <FileText className="w-4 h-4 text-sky-500" />
          </div>
          <p className="text-2xl font-bold font-mono text-neutral-900">{data.assignedInvoices.length}</p>
          <span className="text-[10px] text-neutral-400 mt-1 block">Invoices assigned to you</span>
        </div>

        {/* Total Remaining to Collect */}
        <div className="bg-neutral-900 text-white rounded-xl p-4 shadow-xs border border-neutral-800">
          <div className="flex items-center justify-between text-orange-400 mb-2">
            <span className="text-[11px] font-bold uppercase tracking-wide">Remaining to Collect</span>
            <Wallet className="w-4 h-4 text-orange-400" />
          </div>
          <p className="text-xl sm:text-2xl font-black font-mono text-white truncate">
            {formatAFN(data.totalRemainingToCollect)}
          </p>
          <span className="text-[10px] text-neutral-400 mt-1 block">Your assigned balance</span>
        </div>

        {/* Today's Collections */}
        <div className="bg-white rounded-xl p-4 border border-neutral-200 shadow-xs">
          <div className="flex items-center justify-between text-emerald-600 mb-2">
            <span className="text-[11px] font-bold uppercase tracking-wide text-neutral-500">Today's Collections</span>
            <DollarSign className="w-4 h-4 text-emerald-600" />
          </div>
          <p className="text-xl sm:text-2xl font-bold font-mono text-emerald-600 truncate">
            {formatAFN(data.todayCollectionsAmount)}
          </p>
          <span className="text-[10px] text-neutral-400 mt-1 block font-medium">Cash gathered today</span>
        </div>

        {/* Total Collected by Collector */}
        <div className="bg-white rounded-xl p-4 border border-neutral-200 shadow-xs">
          <div className="flex items-center justify-between text-neutral-500 mb-2">
            <span className="text-[11px] font-bold uppercase tracking-wide">My Cumulative Collections</span>
            <DollarSign className="w-4 h-4 text-neutral-400" />
          </div>
          <p className="text-xl sm:text-2xl font-bold font-mono text-neutral-900 truncate">
            {formatAFN(data.totalCollectedByCollector)}
          </p>
          <span className="text-[10px] text-neutral-400 mt-1 block">Recorded in ledger</span>
        </div>
      </div>

      {/* Collection Status Grid: Pending vs Partial vs Paid */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
        <div className="bg-white p-4 rounded-xl border border-rose-100 bg-rose-50/20 shadow-xs flex items-center justify-between">
          <div>
            <span className="text-[11px] font-bold uppercase text-rose-700 tracking-wide">Pending Collections</span>
            <p className="text-xl font-bold font-mono text-rose-700 mt-1">{data.pendingCollectionsCount}</p>
            <p className="text-[10px] text-neutral-400 mt-0.5">Zero payment received</p>
          </div>
          <div className="w-10 h-10 rounded-lg bg-rose-100 text-rose-700 flex items-center justify-center font-bold text-sm">
            {data.assignedInvoices.length > 0
              ? `${Math.round((data.pendingCollectionsCount / data.assignedInvoices.length) * 100)}%`
              : '0%'}
          </div>
        </div>

        <div className="bg-white p-4 rounded-xl border border-amber-100 bg-amber-50/20 shadow-xs flex items-center justify-between">
          <div>
            <span className="text-[11px] font-bold uppercase text-amber-700 tracking-wide">Partial Payments</span>
            <p className="text-xl font-bold font-mono text-amber-700 mt-1">{data.partialPaymentsCount}</p>
            <p className="text-[10px] text-neutral-400 mt-0.5">Remaining balance active</p>
          </div>
          <div className="w-10 h-10 rounded-lg bg-amber-100 text-amber-700 flex items-center justify-center font-bold text-sm">
            {data.assignedInvoices.length > 0
              ? `${Math.round((data.partialPaymentsCount / data.assignedInvoices.length) * 100)}%`
              : '0%'}
          </div>
        </div>

        <div className="bg-white p-4 rounded-xl border border-emerald-100 bg-emerald-50/20 shadow-xs flex items-center justify-between">
          <div>
            <span className="text-[11px] font-bold uppercase text-emerald-700 tracking-wide">Fully Paid</span>
            <p className="text-xl font-bold font-mono text-emerald-700 mt-1">{data.fullyPaidInvoicesCount}</p>
            <p className="text-[10px] text-neutral-400 mt-0.5">Completed collections</p>
          </div>
          <div className="w-10 h-10 rounded-lg bg-emerald-100 text-emerald-700 flex items-center justify-center font-bold text-sm">
            {data.assignedInvoices.length > 0
              ? `${Math.round((data.fullyPaidInvoicesCount / data.assignedInvoices.length) * 100)}%`
              : '0%'}
          </div>
        </div>
      </div>

      {/* Main Assigned Work Section: Tabs for Assigned Invoices vs Assigned Customers */}
      <div className="bg-white rounded-xl border border-neutral-200 shadow-xs overflow-hidden">
        <div className="p-4 sm:p-5 border-b border-neutral-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <h3 className="text-sm font-bold text-neutral-900">Assigned Collections Ledger</h3>
            <p className="text-xs text-neutral-500">Only bills and accounts assigned to you are displayed</p>
          </div>

          <div className="flex items-center gap-2 bg-neutral-100 p-1 rounded-lg">
            <button
              onClick={() => setActiveSubTab('invoices')}
              className={`px-3 py-1.5 text-xs font-semibold rounded-md transition cursor-pointer ${
                activeSubTab === 'invoices'
                  ? 'bg-white text-neutral-900 shadow-xs font-bold'
                  : 'text-neutral-500 hover:text-neutral-900'
              }`}
            >
              Assigned Invoices ({data.assignedInvoices.length})
            </button>
            <button
              onClick={() => setActiveSubTab('customers')}
              className={`px-3 py-1.5 text-xs font-semibold rounded-md transition cursor-pointer ${
                activeSubTab === 'customers'
                  ? 'bg-white text-neutral-900 shadow-xs font-bold'
                  : 'text-neutral-500 hover:text-neutral-900'
              }`}
            >
              Assigned Customers ({data.assignedCustomers.length})
            </button>
          </div>
        </div>

        {/* Assigned Invoices Tab */}
        {activeSubTab === 'invoices' && (
          <div>
            {data.assignedInvoices.length === 0 ? (
              <div className="p-10 text-center text-neutral-400 text-xs">
                <FileText className="w-8 h-8 text-neutral-300 mx-auto mb-2" />
                <p className="font-semibold text-neutral-700">No invoices currently assigned to you.</p>
                <p className="mt-1">
                  When an Invoice Manager or Super Admin assigns billing records to your account, they will automatically appear here.
                </p>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-xs">
                  <thead>
                    <tr className="bg-neutral-50 text-neutral-600 font-semibold border-b border-neutral-200 text-left">
                      <th className="py-3 px-4">Bill No.</th>
                      <th className="py-3 px-4">Customer</th>
                      <th className="py-3 px-4">Date</th>
                      <th className="py-3 px-4 text-right">Total Bill</th>
                      <th className="py-3 px-4 text-right">Paid (Cash)</th>
                      <th className="py-3 px-4 text-right">Remaining Due</th>
                      <th className="py-3 px-4 text-center">Status</th>
                      <th className="py-3 px-4 text-right">Action</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-neutral-100">
                    {data.assignedInvoices.map((inv) => {
                      const paid = calculateTotalPaidForInvoice(inv.id, payments);
                      const remaining = calculateRemaining(inv.totalAmount, paid);

                      return (
                        <tr
                          key={inv.id}
                          className="hover:bg-neutral-50 cursor-pointer transition"
                          onClick={() => onSelectInvoice(inv)}
                        >
                          <td className="py-3 px-4 font-mono font-bold text-neutral-900">
                            {inv.billNumber}
                          </td>
                          <td className="py-3 px-4">
                            <div className="font-medium text-neutral-900">
                              {inv.customerSnapshot?.name || 'Customer'}
                            </div>
                            {inv.customerSnapshot?.phone && (
                              <div className="text-[11px] text-neutral-500 font-mono flex items-center gap-1 mt-0.5">
                                <Phone className="w-3 h-3 text-neutral-400" />
                                {inv.customerSnapshot.phone}
                              </div>
                            )}
                          </td>
                          <td className="py-3 px-4 text-neutral-500 whitespace-nowrap">
                            {formatDate(inv.date)}
                          </td>
                          <td className="py-3 px-4 text-right font-mono font-bold text-neutral-900">
                            {formatAFN(inv.totalAmount)}
                          </td>
                          <td className="py-3 px-4 text-right font-mono font-bold text-emerald-700">
                            {formatAFN(paid)}
                          </td>
                          <td className="py-3 px-4 text-right font-mono font-bold text-orange-600">
                            {formatAFN(remaining)}
                          </td>
                          <td className="py-3 px-4 text-center">
                            <span
                              className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold ${
                                inv.status === 'Paid'
                                  ? 'bg-emerald-100 text-emerald-800'
                                  : inv.status === 'Partially Paid'
                                  ? 'bg-amber-100 text-amber-800'
                                  : 'bg-rose-100 text-rose-800'
                              }`}
                            >
                              {inv.status}
                            </span>
                          </td>
                          <td className="py-3 px-4 text-right" onClick={(e) => e.stopPropagation()}>
                            {remaining > 0 && data.quickActionsAllowed.canCollectPayment ? (
                              <button
                                onClick={() => onAddPayment(inv.id)}
                                className="px-2.5 py-1 bg-emerald-600 hover:bg-emerald-700 text-white rounded text-[11px] font-bold transition cursor-pointer"
                              >
                                Collect
                              </button>
                            ) : (
                              <button
                                onClick={() => onSelectInvoice(inv)}
                                className="text-orange-600 hover:text-orange-700 font-semibold text-xs"
                              >
                                View
                              </button>
                            )}
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        )}

        {/* Assigned Customers Tab */}
        {activeSubTab === 'customers' && (
          <div className="p-4 sm:p-5">
            {data.assignedCustomers.length === 0 ? (
              <div className="py-8 text-center text-neutral-400 text-xs">
                <Users className="w-8 h-8 text-neutral-300 mx-auto mb-2" />
                No customers assigned yet.
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
                {data.assignedCustomers.map((c) => {
                  // Invoices for this customer assigned to this collector
                  const custInvoices = data.assignedInvoices.filter(
                    (i) => i.customerId === c.id || i.customerSnapshot?.phone === c.phone
                  );
                  const custTotal = custInvoices.reduce((s, i) => s + (Number(i.totalAmount) || 0), 0);
                  const custPaid = custInvoices.reduce(
                    (s, i) => s + calculateTotalPaidForInvoice(i.id, payments),
                    0
                  );
                  const custRemaining = Math.max(0, custTotal - custPaid);

                  return (
                    <div
                      key={c.id}
                      onClick={() => onSelectCustomer && onSelectCustomer(c)}
                      className="p-4 rounded-xl border border-neutral-200 bg-neutral-50/50 hover:bg-white hover:border-orange-200 transition cursor-pointer space-y-2"
                    >
                      <div className="flex items-start justify-between">
                        <div>
                          <p className="font-bold text-neutral-900 text-sm">{c.name}</p>
                          <p className="text-[11px] text-neutral-500 flex items-center gap-1 mt-0.5">
                            <Phone className="w-3 h-3 text-neutral-400" />
                            {c.phone}
                          </p>
                        </div>
                        <span className="text-[10px] font-semibold px-2 py-0.5 bg-sky-50 text-sky-700 rounded-full border border-sky-200">
                          {custInvoices.length} Bills
                        </span>
                      </div>

                      {c.address && (
                        <p className="text-[11px] text-neutral-500 truncate">{c.address}</p>
                      )}

                      <div className="pt-2 border-t border-neutral-200 flex items-center justify-between text-xs">
                        <span className="text-neutral-400">Due Balance:</span>
                        <span className="font-mono font-bold text-orange-600">
                          {formatAFN(custRemaining)}
                        </span>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        )}
      </div>

      {/* Recent Payments Recorded by this collector */}
      <div className="bg-white rounded-xl border border-neutral-200 shadow-xs overflow-hidden">
        <div className="p-4 border-b border-neutral-200 flex items-center justify-between">
          <div>
            <h3 className="text-sm font-bold text-neutral-900">Recent Collections Recorded By You</h3>
            <p className="text-xs text-neutral-500">Direct cash collections submitted</p>
          </div>
          {onTabChange && (
            <button
              onClick={() => onTabChange('payments')}
              className="text-xs text-emerald-700 hover:text-emerald-800 font-bold inline-flex items-center gap-1 transition cursor-pointer"
            >
              All My Collections <ChevronRight className="w-3.5 h-3.5" />
            </button>
          )}
        </div>

        {data.recentPaymentsByCollector.length === 0 ? (
          <p className="text-xs text-neutral-400 py-8 text-center">
            You have not recorded any cash collections yet.
          </p>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-xs">
              <thead>
                <tr className="bg-neutral-50 text-neutral-500 font-semibold border-b border-neutral-200 text-left">
                  <th className="py-2.5 px-3">Date</th>
                  <th className="py-2.5 px-3">Bill No.</th>
                  <th className="py-2.5 px-3">Customer</th>
                  <th className="py-2.5 px-3 text-right">Amount</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-neutral-100">
                {data.recentPaymentsByCollector.map((p) => (
                  <tr
                    key={p.id}
                    onClick={() => onSelectPayment && onSelectPayment(p)}
                    className="hover:bg-neutral-50 cursor-pointer transition"
                  >
                    <td className="py-2.5 px-3 text-neutral-500">{formatDate(p.date)}</td>
                    <td className="py-2.5 px-3 font-mono font-bold text-neutral-900">{p.billNumber}</td>
                    <td className="py-2.5 px-3 font-medium text-neutral-800 truncate max-w-[130px]">
                      {p.customerName || 'Customer'}
                    </td>
                    <td className="py-2.5 px-3 text-right font-mono font-bold text-emerald-700">
                      {formatAFN(p.amount)}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};
