import React, { useState, useRef, useEffect, useMemo } from 'react';
import { SuperAdminDashboardData } from '../../services/dashboardAuthorization';
import { Invoice, Payment, BusinessSettings, Customer, UserProfile, Expense } from '../../types';
import {
  formatAFN,
  formatCount,
  formatDate,
  calculateTotalPaidForInvoice,
  calculateRemaining,
  getTodayDateString,
  calculateTotalUsers,
  calculateTotalCustomers,
  calculateTotalInvoices,
  calculateTotalPayments,
  calculateTotalOutstanding,
} from '../../utils/format';
import { calculateFinancialPerformance } from '../../utils/financialPerformance';
import { getRecentInvoices } from '../../utils/recentInvoices';
import { getRecentPayments } from '../../utils/recentPayments';
import {
  Users,
  FileText,
  DollarSign,
  TrendingUp,
  Receipt,
  AlertCircle,
  Plus,
  ShieldCheck,
  Settings,
  UserCheck,
  ChevronRight,
  ChevronDown,
  Clock,
  CheckCircle2,
  Calendar,
  Wallet,
  ArrowUpRight,
  ArrowDownRight,
  Filter,
  Banknote,
} from 'lucide-react';
import { ActiveTab } from '../layout/Sidebar';
import { InvoiceStatusBreakdown } from './InvoiceStatusBreakdown';

interface SuperAdminDashboardProps {
  data: SuperAdminDashboardData;
  settings: BusinessSettings;
  onNewInvoice: () => void;
  onNewCustomer: () => void;
  onAddPayment: () => void;
  onAddExpense: () => void;
  onSelectInvoice: (invoice: Invoice) => void;
  onSelectPayment?: (payment: Payment) => void;
  onTabChange?: (tab: ActiveTab) => void;
  payments: Payment[];
  invoices?: Invoice[];
  customers?: Customer[];
  users?: UserProfile[];
  expenses?: Expense[];
  invoiceStatusBreakdown?: React.ReactNode;
}

export const SuperAdminDashboard: React.FC<SuperAdminDashboardProps> = ({
  data,
  settings,
  onNewInvoice,
  onNewCustomer,
  onAddPayment,
  onAddExpense,
  onSelectInvoice,
  onSelectPayment,
  onTabChange,
  payments,
  invoices,
  customers,
  users,
  expenses,
  invoiceStatusBreakdown,
}) => {
  const [financialTab, setFinancialTab] = useState<'daily' | 'weekly' | 'monthly'>('daily');
  const [quickActionsOpen, setQuickActionsOpen] = useState(false);
  const quickActionsMenuRef = useRef<HTMLDivElement>(null);
  const todayStr = getTodayDateString();

  // Financial Performance Summaries calculated according to approved business rules
  const financialSummaries = useMemo(() => {
    return calculateFinancialPerformance({
      invoices,
      payments,
      expenses,
      fallbackData: data,
    });
  }, [invoices, payments, expenses, data]);

  // 5 Organization KPI values calculated using approved deterministic business rules
  const totalUsers = users ? calculateTotalUsers(users) : (data?.totalUsersCount ?? 0);
  const totalCustomers = customers ? calculateTotalCustomers(customers) : (data?.totalCustomersCount ?? 0);
  const totalInvoices = invoices ? calculateTotalInvoices(invoices) : (data?.totalInvoicesCount ?? 0);
  const totalPayments = payments ? calculateTotalPayments(payments) : (data?.totalPaymentsAmount ?? 0);
  const totalOutstanding = invoices
    ? calculateTotalOutstanding(invoices, payments)
    : (data?.totalOutstandingAmount ?? 0);

  // Real-time calculated Recent Invoices (latest 8 valid invoices, sorted by createdAt descending)
  const recentInvoicesList = useMemo(() => {
    const sourceInvoices =
      invoices && invoices.length > 0 ? invoices : (data?.recentInvoices || []);
    return getRecentInvoices(sourceInvoices, payments, 8, todayStr);
  }, [invoices, data?.recentInvoices, payments, todayStr]);

  // Real-time calculated Recent Cash Receipts (latest 8 valid payments, sorted by createdAt descending, excluding void payments and void invoices)
  const recentPaymentsList = useMemo(() => {
    const sourcePayments =
      payments && payments.length > 0 ? payments : (data?.recentPayments || []);
    const sourceInvoices =
      invoices && invoices.length > 0 ? invoices : (data?.recentInvoices || []);
    return getRecentPayments(sourcePayments, sourceInvoices, 8);
  }, [payments, invoices, data?.recentPayments, data?.recentInvoices]);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent | TouchEvent) => {
      if (quickActionsMenuRef.current && !quickActionsMenuRef.current.contains(event.target as Node)) {
        setQuickActionsOpen(false);
      }
    };

    const handleKeyDown = (event: KeyboardEvent) => {
      if (event.key === 'Escape') {
        setQuickActionsOpen(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    document.addEventListener('touchstart', handleClickOutside);
    document.addEventListener('keydown', handleKeyDown);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
      document.removeEventListener('touchstart', handleClickOutside);
      document.removeEventListener('keydown', handleKeyDown);
    };
  }, []);

  return (
    <div className="space-y-6">
      {/* Super Admin Executive Header Banner */}
      <div className="bg-neutral-900 text-white rounded-2xl p-4 sm:p-5 shadow-xs border border-neutral-800">
        <div className="flex items-center justify-between gap-3 sm:gap-4">
          {/* LEFT: [Sarwan Technology Logo] Sarwan Technology + Full Control Badge */}
          <div className="flex items-center gap-2.5 sm:gap-3 min-w-0">
            <div
              className="w-10 h-10 sm:w-11 sm:h-11 bg-white flex items-center justify-center shrink-0 overflow-hidden shadow-xs p-1"
              style={{ borderRadius: '100%', border: 'none' }}
            >
              <img
                src={settings?.logo || '/sarwan-logo.png'}
                alt="Sarwan Technology"
                className="max-h-full max-w-full object-contain"
                onError={(e) => {
                  const target = e.currentTarget;
                  if (target.src.endsWith('.png')) target.src = '/sarwan-logo.svg';
                }}
              />
            </div>
            <div className="min-w-0 flex flex-col justify-center">
              <span className="text-sm sm:text-base font-bold tracking-tight text-white block truncate select-none leading-snug">
                {settings?.companyName || 'Sarwan Technology'}
              </span>
              <div className="mt-0.5">
                <span
                  id="superadmin-full-control-badge"
                  className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-[10.5px] font-semibold bg-orange-500/15 text-orange-400 border border-orange-500/30 leading-none"
                >
                  <ShieldCheck className="w-3 h-3 text-orange-400 shrink-0" />
                  Full Control
                </span>
              </div>
            </div>
          </div>

          {/* RIGHT: Quick Actions (ONE IDENTICAL BUTTON AND MENU ON ALL SCREENS) + Settings */}
          <div className="flex items-center gap-2 shrink-0">
            <div className="relative" ref={quickActionsMenuRef}>
              <button
                type="button"
                id="superadmin-quick-actions-btn"
                onClick={() => setQuickActionsOpen((prev) => !prev)}
                className="p-2 sm:px-3.5 sm:py-2 bg-[#2563EB] hover:bg-[#1D4ED8] active:bg-[#1E40AF] text-white text-xs font-bold rounded-lg shadow-xs transition inline-flex items-center justify-center gap-1.5 cursor-pointer active:scale-98 whitespace-nowrap focus:outline-none focus-visible:ring-2 focus-visible:ring-[#2563EB]"
                aria-expanded={quickActionsOpen}
                aria-haspopup="true"
                aria-label="Quick Actions"
                title="Quick Actions"
              >
                <Plus className="w-4 h-4 shrink-0" />
                <span className="hidden sm:inline">Quick Actions</span>
                <ChevronDown
                  className={`hidden sm:inline w-3.5 h-3.5 text-white/80 transition-transform duration-150 ${
                    quickActionsOpen ? 'rotate-180' : ''
                  }`}
                />
              </button>

              {quickActionsOpen && (
                <div
                  id="superadmin-quick-actions-menu"
                  className="absolute right-0 mt-1.5 w-52 sm:w-56 max-w-[calc(100vw-2rem)] max-h-[calc(100vh-5rem)] overflow-y-auto bg-neutral-900 border border-neutral-700 rounded-xl shadow-2xl py-1.5 z-50 animate-in fade-in zoom-in-95 duration-100 origin-top-right"
                >
                  <div className="px-3.5 py-1 text-[10px] uppercase font-bold tracking-wider text-neutral-400 border-b border-neutral-800 mb-1">
                    Quick Actions
                  </div>

                  {/* 1. New Invoice */}
                  {data.quickActionsAllowed.canCreateInvoice && (
                    <button
                      type="button"
                      id="quick-action-new-invoice"
                      onClick={() => {
                        setQuickActionsOpen(false);
                        onNewInvoice();
                      }}
                      className="w-full px-3.5 py-2.5 text-left text-xs text-white hover:bg-neutral-800 transition flex items-center gap-2.5 cursor-pointer font-semibold"
                    >
                      <div className="p-1 rounded-md bg-orange-500/20 text-[#F58220] shrink-0">
                        <Plus className="w-3.5 h-3.5" />
                      </div>
                      <span className="truncate">New Invoice</span>
                    </button>
                  )}

                  {/* 2. Add Payment */}
                  {data.quickActionsAllowed.canCollectPayment && (
                    <button
                      type="button"
                      id="quick-action-add-payment"
                      onClick={() => {
                        setQuickActionsOpen(false);
                        onAddPayment();
                      }}
                      className="w-full px-3.5 py-2.5 text-left text-xs text-neutral-200 hover:text-white hover:bg-neutral-800 transition flex items-center gap-2.5 cursor-pointer font-medium"
                    >
                      <div className="p-1 rounded-md bg-emerald-500/15 text-emerald-400 shrink-0">
                        <DollarSign className="w-3.5 h-3.5" />
                      </div>
                      <span className="truncate">Add Payment</span>
                    </button>
                  )}

                  {/* 3. New Customer */}
                  {data.quickActionsAllowed.canManageCustomers && (
                    <button
                      type="button"
                      id="quick-action-new-customer"
                      onClick={() => {
                        setQuickActionsOpen(false);
                        onNewCustomer();
                      }}
                      className="w-full px-3.5 py-2.5 text-left text-xs text-neutral-200 hover:text-white hover:bg-neutral-800 transition flex items-center gap-2.5 cursor-pointer font-medium"
                    >
                      <div className="p-1 rounded-md bg-orange-500/15 text-orange-400 shrink-0">
                        <Users className="w-3.5 h-3.5" />
                      </div>
                      <span className="truncate">New Customer</span>
                    </button>
                  )}

                  {/* 4. Add Expense */}
                  {data.quickActionsAllowed.canManageExpenses && (
                    <button
                      type="button"
                      id="quick-action-add-expense"
                      onClick={() => {
                        setQuickActionsOpen(false);
                        onAddExpense();
                      }}
                      className="w-full px-3.5 py-2.5 text-left text-xs text-neutral-200 hover:text-white hover:bg-neutral-800 transition flex items-center gap-2.5 cursor-pointer font-medium"
                    >
                      <div className="p-1 rounded-md bg-rose-500/15 text-rose-400 shrink-0">
                        <Receipt className="w-3.5 h-3.5" />
                      </div>
                      <span className="truncate">Add Expense</span>
                    </button>
                  )}

                  {/* 5. Manage Staff */}
                  {data.quickActionsAllowed.canManageStaff && onTabChange && (
                    <button
                      type="button"
                      id="quick-action-manage-staff"
                      onClick={() => {
                        setQuickActionsOpen(false);
                        onTabChange('staff');
                      }}
                      className="w-full px-3.5 py-2.5 text-left text-xs text-neutral-200 hover:text-white hover:bg-neutral-800 transition flex items-center gap-2.5 cursor-pointer font-medium"
                    >
                      <div className="p-1 rounded-md bg-sky-500/15 text-sky-400 shrink-0">
                        <UserCheck className="w-3.5 h-3.5" />
                      </div>
                      <span className="truncate">Manage Staff</span>
                    </button>
                  )}
                </div>
              )}
            </div>

            {/* System Settings */}
            {data.quickActionsAllowed.canManageSettings && onTabChange && (
              <button
                type="button"
                id="superadmin-settings-btn"
                onClick={() => onTabChange('settings')}
                className="p-2 bg-neutral-800 hover:bg-neutral-700 text-neutral-300 hover:text-white rounded-lg border border-neutral-700 transition cursor-pointer shrink-0"
                title="System Settings"
                aria-label="System Settings"
              >
                <Settings className="w-4 h-4" />
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Organization Overview Section */}
      <div id="organization-overview-section" className="space-y-3">
        <div className="flex flex-col sm:flex-row sm:items-baseline justify-between gap-1">
          <div>
            <h2 id="organization-overview-title" className="text-base font-bold text-[var(--app-text-primary,#0F172A)] tracking-tight">
              Organization Overview
            </h2>
            <p id="organization-overview-subtitle" className="text-xs text-[var(--app-text-muted,#64748B)]">
              Real-time organization statistics
            </p>
          </div>
        </div>

        {/* Organization KPIs */}
        <div id="organization-overview-container" className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3 sm:gap-4">
          <div id="kpi-total-users-card" className="bg-[var(--app-surface-card,#FFFFFF)] rounded-xl p-4 border border-[var(--app-border,#E2E8F0)] shadow-xs flex flex-col justify-between min-w-0 transition-colors">
            <div className="flex items-center justify-between text-[var(--app-text-muted,#64748B)] mb-2">
              <span className="text-[11px] font-bold uppercase tracking-wide truncate mr-1">Total Users</span>
              <Users className="w-4 h-4 text-[var(--app-text-muted,#64748B)] shrink-0" />
            </div>
            <div>
              <p id="kpi-total-users-value" className="text-xl sm:text-2xl font-bold font-mono text-[var(--app-text-primary,#0F172A)] tracking-tight truncate">
                {formatCount(totalUsers)}
              </p>
              <span className="text-[10px] text-[var(--app-text-muted,#64748B)] mt-1 block font-medium truncate">All accounts</span>
            </div>
          </div>

          <div id="kpi-total-customers-card" className="bg-[var(--app-surface-card,#FFFFFF)] rounded-xl p-4 border border-[var(--app-border,#E2E8F0)] shadow-xs flex flex-col justify-between min-w-0 transition-colors">
            <div className="flex items-center justify-between text-[var(--app-text-muted,#64748B)] mb-2">
              <span className="text-[11px] font-bold uppercase tracking-wide truncate mr-1">Total Customers</span>
              <UserCheck className="w-4 h-4 text-[var(--brand-orange,#F7941D)] shrink-0" />
            </div>
            <div>
              <p id="kpi-total-customers-value" className="text-xl sm:text-2xl font-bold font-mono text-[var(--app-text-primary,#0F172A)] tracking-tight truncate">
                {formatCount(totalCustomers)}
              </p>
              <span className="text-[10px] text-[var(--app-text-muted,#64748B)] mt-1 block font-medium truncate">Active client accounts</span>
            </div>
          </div>

          <div id="kpi-total-invoices-card" className="bg-[var(--app-surface-card,#FFFFFF)] rounded-xl p-4 border border-[var(--app-border,#E2E8F0)] shadow-xs flex flex-col justify-between min-w-0 transition-colors">
            <div className="flex items-center justify-between text-[var(--app-text-muted,#64748B)] mb-2">
              <span className="text-[11px] font-bold uppercase tracking-wide truncate mr-1">Total Invoices</span>
              <FileText className="w-4 h-4 text-sky-500 shrink-0" />
            </div>
            <div>
              <p id="kpi-total-invoices-value" className="text-xl sm:text-2xl font-bold font-mono text-[var(--app-text-primary,#0F172A)] tracking-tight truncate">
                {formatCount(totalInvoices)}
              </p>
              <span className="text-[10px] text-[var(--app-text-muted,#64748B)] mt-1 block font-medium truncate">Generated billing</span>
            </div>
          </div>

          <div id="kpi-total-payments-card" className="bg-[var(--app-surface-card,#FFFFFF)] rounded-xl p-4 border border-[var(--app-border,#E2E8F0)] shadow-xs flex flex-col justify-between min-w-0 transition-colors">
            <div className="flex items-center justify-between text-emerald-600 mb-2">
              <span className="text-[11px] font-bold uppercase tracking-wide text-[var(--app-text-muted,#64748B)] truncate mr-1">Total Payments</span>
              <Banknote className="w-4 h-4 text-emerald-600 shrink-0" />
            </div>
            <div>
              <p id="kpi-total-payments-value" className="text-xl sm:text-2xl font-bold font-mono text-emerald-600 tracking-tight truncate" title={formatAFN(totalPayments, true)}>
                {formatAFN(totalPayments, true)}
              </p>
              <span className="text-[10px] text-[var(--app-text-muted,#64748B)] mt-1 block font-medium truncate">Cash collected</span>
            </div>
          </div>

          <div id="kpi-total-outstanding-card" className="col-span-1 sm:col-span-2 lg:col-span-1 bg-neutral-950 text-white rounded-xl p-4 shadow-xs border border-neutral-800 flex flex-col justify-between min-w-0">
            <div className="flex items-center justify-between text-orange-400 mb-2">
              <span className="text-[11px] font-bold uppercase tracking-wide text-neutral-300 truncate mr-1">Total Outstanding</span>
              <Wallet className="w-4 h-4 text-orange-400 shrink-0" />
            </div>
            <div>
              <p id="kpi-total-outstanding-value" className="text-xl sm:text-2xl font-black font-mono text-white tracking-tight truncate" title={formatAFN(totalOutstanding, true)}>
                {formatAFN(totalOutstanding, true)}
              </p>
              <span className="text-[10px] text-neutral-400 mt-1 block font-medium truncate">Remaining balance</span>
            </div>
          </div>
        </div>
      </div>

      {/* Invoice Status Breakdown Section */}
      {invoiceStatusBreakdown ? (
        invoiceStatusBreakdown
      ) : (
        <InvoiceStatusBreakdown
          invoices={invoices || []}
          payments={payments || []}
          onSelectInvoice={onSelectInvoice}
          onViewAllInvoices={() => onTabChange?.('invoices')}
        />
      )}

      {/* Financial Summaries: Daily / Weekly / Monthly Switcher */}
      <div id="financial-performance-overview-section" className="bg-[var(--app-surface-card,#FFFFFF)] rounded-xl border border-[var(--app-border,#E2E8F0)] shadow-xs p-5 space-y-4 transition-colors">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-[var(--app-border-subtle,#F1F5F9)] pb-3">
          <div className="flex items-center gap-2">
            <TrendingUp className="w-4 h-4 text-[var(--brand-orange,#F7941D)]" />
            <h2 id="financial-performance-overview-title" className="text-sm font-bold text-[var(--app-text-primary,#0F172A)]">Financial Performance Overview</h2>
          </div>

          <div className="flex items-center bg-[var(--app-bg-muted,#F1F5F9)] p-1 rounded-lg self-start sm:self-auto border border-[var(--app-border-subtle,#F1F5F9)]">
            <button
              id="financial-tab-daily-btn"
              onClick={() => setFinancialTab('daily')}
              className={`px-3 py-1 text-xs font-semibold rounded-md transition cursor-pointer ${
                financialTab === 'daily'
                  ? 'bg-white text-neutral-900 shadow-xs font-bold'
                  : 'text-neutral-500 hover:text-neutral-900'
              }`}
            >
              Daily ({formatDate(todayStr)})
            </button>
            <button
              id="financial-tab-weekly-btn"
              onClick={() => setFinancialTab('weekly')}
              className={`px-3 py-1 text-xs font-semibold rounded-md transition cursor-pointer ${
                financialTab === 'weekly'
                  ? 'bg-white text-neutral-900 shadow-xs font-bold'
                  : 'text-neutral-500 hover:text-neutral-900'
              }`}
            >
              Last 7 Days
            </button>
            <button
              id="financial-tab-monthly-btn"
              onClick={() => setFinancialTab('monthly')}
              className={`px-3 py-1 text-xs font-semibold rounded-md transition cursor-pointer ${
                financialTab === 'monthly'
                  ? 'bg-white text-neutral-900 shadow-xs font-bold'
                  : 'text-neutral-500 hover:text-neutral-900'
              }`}
            >
              This Month
            </button>
          </div>
        </div>

        {/* Selected Summary Metric Cards */}
        {financialTab === 'daily' && (
          <div id="financial-metrics-daily-grid" className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <div id="financial-card-daily-sales" className="p-3.5 bg-neutral-50 rounded-xl border border-neutral-200">
              <span className="text-[10px] font-bold uppercase text-neutral-500 block">Today's Sales</span>
              <p
                id="financial-daily-sales-value"
                className="text-xl font-bold font-mono text-neutral-900 mt-1 truncate"
                title={formatAFN(financialSummaries.daily.sales, true)}
              >
                {formatAFN(financialSummaries.daily.sales, true)}
              </p>
              <p className="text-[11px] text-neutral-400 mt-0.5">{financialSummaries.daily.invoicesCount} Invoices generated</p>
            </div>
            <div id="financial-card-daily-payments" className="p-3.5 bg-emerald-50/60 rounded-xl border border-emerald-200">
              <span className="text-[10px] font-bold uppercase text-emerald-800 block">Today's Cash Payments</span>
              <p
                id="financial-daily-payments-value"
                className="text-xl font-bold font-mono text-emerald-700 mt-1 truncate"
                title={formatAFN(financialSummaries.daily.payments, true)}
              >
                {formatAFN(financialSummaries.daily.payments, true)}
              </p>
              <p className="text-[11px] text-neutral-400 mt-0.5">{financialSummaries.daily.paymentsCount} Cash receipts</p>
            </div>
            <div id="financial-card-daily-expenses" className="p-3.5 bg-rose-50/60 rounded-xl border border-rose-200">
              <span className="text-[10px] font-bold uppercase text-rose-800 block">Today's Expenses</span>
              <p
                id="financial-daily-expenses-value"
                className="text-xl font-bold font-mono text-rose-700 mt-1 truncate"
                title={formatAFN(financialSummaries.daily.expenses, true)}
              >
                {formatAFN(financialSummaries.daily.expenses, true)}
              </p>
              <p className="text-[11px] text-neutral-400 mt-0.5">Approved & executed</p>
            </div>
            <div id="financial-card-daily-net" className="p-3.5 bg-neutral-900 text-white rounded-xl border border-neutral-800">
              <div className="flex items-center justify-between">
                <span className="text-[10px] font-bold uppercase text-orange-400 block">Today's Net Result</span>
                {financialSummaries.daily.net >= 0 ? (
                  <ArrowUpRight className="w-3.5 h-3.5 text-emerald-400" />
                ) : (
                  <ArrowDownRight className="w-3.5 h-3.5 text-rose-400" />
                )}
              </div>
              <p
                id="financial-daily-net-value"
                className={`text-xl font-black font-mono mt-1 truncate ${
                  financialSummaries.daily.net >= 0 ? 'text-white' : 'text-rose-400'
                }`}
                title={formatAFN(financialSummaries.daily.net, true)}
              >
                {formatAFN(financialSummaries.daily.net, true)}
              </p>
              <p className="text-[10px] text-neutral-400 mt-0.5">Sales - Expenses</p>
            </div>
          </div>
        )}

        {financialTab === 'weekly' && (
          <div id="financial-metrics-weekly-grid" className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <div id="financial-card-weekly-sales" className="p-3.5 bg-neutral-50 rounded-xl border border-neutral-200">
              <span className="text-[10px] font-bold uppercase text-neutral-500 block">7-Day Sales</span>
              <p
                id="financial-weekly-sales-value"
                className="text-xl font-bold font-mono text-neutral-900 mt-1 truncate"
                title={formatAFN(financialSummaries.weekly.sales, true)}
              >
                {formatAFN(financialSummaries.weekly.sales, true)}
              </p>
              <p className="text-[11px] text-neutral-400 mt-0.5">Past 7 calendar days</p>
            </div>
            <div id="financial-card-weekly-payments" className="p-3.5 bg-emerald-50/60 rounded-xl border border-emerald-200">
              <span className="text-[10px] font-bold uppercase text-emerald-800 block">7-Day Payments</span>
              <p
                id="financial-weekly-payments-value"
                className="text-xl font-bold font-mono text-emerald-700 mt-1 truncate"
                title={formatAFN(financialSummaries.weekly.payments, true)}
              >
                {formatAFN(financialSummaries.weekly.payments, true)}
              </p>
              <p className="text-[11px] text-neutral-400 mt-0.5">Total cash in</p>
            </div>
            <div id="financial-card-weekly-expenses" className="p-3.5 bg-rose-50/60 rounded-xl border border-rose-200">
              <span className="text-[10px] font-bold uppercase text-rose-800 block">7-Day Expenses</span>
              <p
                id="financial-weekly-expenses-value"
                className="text-xl font-bold font-mono text-rose-700 mt-1 truncate"
                title={formatAFN(financialSummaries.weekly.expenses, true)}
              >
                {formatAFN(financialSummaries.weekly.expenses, true)}
              </p>
              <p className="text-[11px] text-neutral-400 mt-0.5">Approved & executed</p>
            </div>
            <div id="financial-card-weekly-net" className="p-3.5 bg-neutral-900 text-white rounded-xl border border-neutral-800">
              <div className="flex items-center justify-between">
                <span className="text-[10px] font-bold uppercase text-orange-400 block">7-Day Net Result</span>
                {financialSummaries.weekly.net >= 0 ? (
                  <ArrowUpRight className="w-3.5 h-3.5 text-emerald-400" />
                ) : (
                  <ArrowDownRight className="w-3.5 h-3.5 text-rose-400" />
                )}
              </div>
              <p
                id="financial-weekly-net-value"
                className={`text-xl font-black font-mono mt-1 truncate ${
                  financialSummaries.weekly.net >= 0 ? 'text-white' : 'text-rose-400'
                }`}
                title={formatAFN(financialSummaries.weekly.net, true)}
              >
                {formatAFN(financialSummaries.weekly.net, true)}
              </p>
              <p className="text-[10px] text-neutral-400 mt-0.5">Sales - Expenses</p>
            </div>
          </div>
        )}

        {financialTab === 'monthly' && (
          <div id="financial-metrics-monthly-grid" className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <div id="financial-card-monthly-sales" className="p-3.5 bg-neutral-50 rounded-xl border border-neutral-200">
              <span className="text-[10px] font-bold uppercase text-neutral-500 block">Monthly Sales</span>
              <p
                id="financial-monthly-sales-value"
                className="text-xl font-bold font-mono text-neutral-900 mt-1 truncate"
                title={formatAFN(financialSummaries.monthly.sales, true)}
              >
                {formatAFN(financialSummaries.monthly.sales, true)}
              </p>
              <p className="text-[11px] text-neutral-400 mt-0.5">Month-to-date</p>
            </div>
            <div id="financial-card-monthly-payments" className="p-3.5 bg-emerald-50/60 rounded-xl border border-emerald-200">
              <span className="text-[10px] font-bold uppercase text-emerald-800 block">Monthly Payments</span>
              <p
                id="financial-monthly-payments-value"
                className="text-xl font-bold font-mono text-emerald-700 mt-1 truncate"
                title={formatAFN(financialSummaries.monthly.payments, true)}
              >
                {formatAFN(financialSummaries.monthly.payments, true)}
              </p>
              <p className="text-[11px] text-neutral-400 mt-0.5">Total cash in</p>
            </div>
            <div id="financial-card-monthly-expenses" className="p-3.5 bg-rose-50/60 rounded-xl border border-rose-200">
              <span className="text-[10px] font-bold uppercase text-rose-800 block">Monthly Expenses</span>
              <p
                id="financial-monthly-expenses-value"
                className="text-xl font-bold font-mono text-rose-700 mt-1 truncate"
                title={formatAFN(financialSummaries.monthly.expenses, true)}
              >
                {formatAFN(financialSummaries.monthly.expenses, true)}
              </p>
              <p className="text-[11px] text-neutral-400 mt-0.5">Approved & executed</p>
            </div>
            <div id="financial-card-monthly-net" className="p-3.5 bg-neutral-900 text-white rounded-xl border border-neutral-800">
              <div className="flex items-center justify-between">
                <span className="text-[10px] font-bold uppercase text-orange-400 block">Monthly Net Result</span>
                {financialSummaries.monthly.net >= 0 ? (
                  <ArrowUpRight className="w-3.5 h-3.5 text-emerald-400" />
                ) : (
                  <ArrowDownRight className="w-3.5 h-3.5 text-rose-400" />
                )}
              </div>
              <p
                id="financial-monthly-net-value"
                className={`text-xl font-black font-mono mt-1 truncate ${
                  financialSummaries.monthly.net >= 0 ? 'text-white' : 'text-rose-400'
                }`}
                title={formatAFN(financialSummaries.monthly.net, true)}
              >
                {formatAFN(financialSummaries.monthly.net, true)}
              </p>
              <p className="text-[10px] text-neutral-400 mt-0.5">Sales - Expenses</p>
            </div>
          </div>
        )}
      </div>

      {/* Expenses Status & Approvals Section */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="bg-white rounded-xl border border-neutral-200 shadow-xs p-5">
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-2">
              <Receipt className="w-4 h-4 text-rose-500" />
              <h3 className="text-sm font-bold text-neutral-900">Pending Expense Approvals</h3>
            </div>
            {onTabChange && (
              <button
                onClick={() => onTabChange('expenses')}
                className="text-xs text-orange-600 hover:text-orange-700 font-bold transition cursor-pointer"
              >
                Review ({data.pendingExpenses.count})
              </button>
            )}
          </div>
          {data.pendingExpenses.items.length === 0 ? (
            <div className="py-6 text-center text-neutral-400 text-xs">
              <CheckCircle2 className="w-6 h-6 text-emerald-500 mx-auto mb-1.5" />
              No pending expense requests awaiting Super Admin action.
            </div>
          ) : (
            <div className="space-y-2">
              {data.pendingExpenses.items.map((exp) => (
                <div
                  key={exp.id}
                  className="flex items-center justify-between p-2.5 rounded-lg bg-neutral-50 border border-neutral-200 text-xs"
                >
                  <div>
                    <p className="font-semibold text-neutral-900">{exp.title}</p>
                    <p className="text-[10px] text-neutral-500">
                      By {exp.requestedByName || 'Staff'} &bull; {formatDate(exp.date)}
                    </p>
                  </div>
                  <div className="text-right">
                    <span className="font-mono font-bold text-neutral-900">{formatAFN(exp.amount)}</span>
                    <span className="block text-[9px] font-bold text-amber-700 uppercase">
                      {exp.status.replace('_', ' ')}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        <div className="bg-white rounded-xl border border-neutral-200 shadow-xs p-5">
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-600" />
              <h3 className="text-sm font-bold text-neutral-900">Approved &amp; Executed Expenses</h3>
            </div>
            {onTabChange && (
              <button
                onClick={() => onTabChange('expenses')}
                className="text-xs text-neutral-500 hover:text-neutral-700 transition cursor-pointer"
              >
                View Ledger
              </button>
            )}
          </div>
          <div className="p-4 rounded-xl bg-neutral-50 border border-neutral-200 flex items-center justify-between">
            <div>
              <p className="text-xs text-neutral-500">Approved Expenses Total</p>
              <p className="text-2xl font-bold font-mono text-neutral-900 mt-1">
                {formatAFN(data.approvedExpenses.amount)}
              </p>
            </div>
            <div className="text-right">
              <span className="text-xs font-semibold text-emerald-700 bg-emerald-50 border border-emerald-200 px-2.5 py-1 rounded-full">
                {data.approvedExpenses.count} Vouchers Approved
              </span>
            </div>
          </div>
          <p className="text-[11px] text-neutral-400 mt-3">
            Official operational costs deducted from cumulative sales to compute actual net result.
          </p>
        </div>
      </div>

      {/* Side-by-side Tables: Recent Invoices & Recent Payments */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Recent Invoices */}
        <div className="bg-white rounded-xl border border-neutral-200 shadow-xs overflow-hidden">
          <div className="p-4 border-b border-neutral-200 flex items-center justify-between">
            <div>
              <h3 className="text-sm font-bold text-neutral-900">Recent Invoices</h3>
              <p className="text-xs text-neutral-500">Latest business billing transactions</p>
            </div>
            {onTabChange && (
              <button
                onClick={() => onTabChange('invoices')}
                className="text-xs text-orange-600 hover:text-orange-700 font-bold inline-flex items-center gap-1 transition cursor-pointer"
              >
                View All <ChevronRight className="w-3.5 h-3.5" />
              </button>
            )}
          </div>

          {recentInvoicesList.length === 0 ? (
            <div className="p-8 text-center text-neutral-400 text-xs">
              <FileText className="w-7 h-7 text-neutral-300 mx-auto mb-2" />
              No invoices generated yet.
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-xs">
                <thead>
                  <tr className="bg-neutral-50 text-neutral-500 font-semibold border-b border-neutral-200 text-left">
                    <th className="py-2.5 px-3">Bill No.</th>
                    <th className="py-2.5 px-3">Customer</th>
                    <th className="py-2.5 px-3 text-right">Total</th>
                    <th className="py-2.5 px-3 text-center">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-neutral-100">
                  {recentInvoicesList.map(({ invoice: inv, calculatedStatus, totalAmount }) => (
                    <tr
                      key={inv.id}
                      onClick={() => onSelectInvoice(inv)}
                      className="hover:bg-neutral-50 cursor-pointer transition"
                    >
                      <td className="py-2.5 px-3 font-mono font-bold text-neutral-900">
                        {inv.billNumber}
                      </td>
                      <td className="py-2.5 px-3 font-medium text-neutral-800 truncate max-w-[140px]">
                        {inv.customerSnapshot?.name || 'Customer'}
                      </td>
                      <td className="py-2.5 px-3 text-right font-mono font-bold text-neutral-900">
                        {formatAFN(totalAmount)}
                      </td>
                      <td className="py-2.5 px-3 text-center">
                        <span
                          className={`px-2 py-0.5 rounded-full text-[9px] font-bold ${
                            calculatedStatus === 'Paid'
                              ? 'bg-emerald-100 text-emerald-800'
                              : calculatedStatus === 'Partially Paid'
                              ? 'bg-amber-100 text-amber-800'
                              : calculatedStatus === 'Overdue'
                              ? 'bg-rose-100 text-rose-800'
                              : 'bg-sky-100 text-sky-800'
                          }`}
                        >
                          {calculatedStatus}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>

        {/* Recent Payments */}
        <div className="bg-white rounded-xl border border-neutral-200 shadow-xs overflow-hidden">
          <div className="p-4 border-b border-neutral-200 flex items-center justify-between">
            <div>
              <h3 className="text-sm font-bold text-neutral-900">Recent Cash Receipts</h3>
              <p className="text-xs text-neutral-500">Latest incoming payment transactions</p>
            </div>
            {onTabChange && (
              <button
                onClick={() => onTabChange('payments')}
                className="text-xs text-emerald-700 hover:text-emerald-800 font-bold inline-flex items-center gap-1 transition cursor-pointer"
              >
                View All <ChevronRight className="w-3.5 h-3.5" />
              </button>
            )}
          </div>

          {recentPaymentsList.length === 0 ? (
            <div className="p-8 text-center text-neutral-400 text-xs">
              <DollarSign className="w-7 h-7 text-neutral-300 mx-auto mb-2" />
              No cash payments recorded yet.
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-xs">
                <thead>
                  <tr className="bg-neutral-50 text-neutral-500 font-semibold border-b border-neutral-200 text-left">
                    <th className="py-2.5 px-3">Date</th>
                    <th className="py-2.5 px-3">Bill No.</th>
                    <th className="py-2.5 px-3">Customer</th>
                    <th className="py-2.5 px-3 text-right">Amount</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-neutral-100">
                  {recentPaymentsList.map((p) => (
                    <tr
                      key={p.id}
                      onClick={() => onSelectPayment && onSelectPayment(p)}
                      className="hover:bg-neutral-50 cursor-pointer transition"
                    >
                      <td className="py-2.5 px-3 text-neutral-500 whitespace-nowrap">
                        {formatDate(p.date)}
                      </td>
                      <td className="py-2.5 px-3 font-mono font-bold text-neutral-900">
                        {p.billNumber}
                      </td>
                      <td className="py-2.5 px-3 font-medium text-neutral-800 truncate max-w-[130px]">
                        {p.customerName || 'Customer'}
                      </td>
                      <td className="py-2.5 px-3 text-right font-mono font-bold text-emerald-700">
                        {formatAFN(p.amount)}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
