import React from 'react';
import {
  Check,
  Shield,
  Sparkles,
  Sun,
  Moon,
  RotateCcw,
  Undo2,
} from 'lucide-react';
import { useTheme } from '../../context/ThemeContext';
import { useAuth } from '../../context/AuthContext';
import { ThemeDefinition, ThemeId } from '../../themes/types';
import { toast } from '../../context/ToastContext';

export const ThemeSettingsSection: React.FC = () => {
  const {
    currentTheme,
    themeId,
    mode,
    setMode,
    themeCatalog,
    setTheme,
    globalDefaultTheme,
    setGlobalDefaultTheme,
    themeSource,
    hasPersonalPreference,
    clearPersonalPreference,
    resetToBrandTheme,
  } = useTheme();

  const { isSuperAdmin } = useAuth();

  const renderModeCard = (t: ThemeDefinition) => {
    const isSelected = themeId === t.id || (themeId as string === 'sarwan_classic_light' && t.id === 'sarwan_light');
    const isGlobalDefault = globalDefaultTheme === t.id || (globalDefaultTheme as string === 'sarwan_classic_light' && t.id === 'sarwan_light');

    return (
      <div
        key={t.id}
        onClick={() => setTheme(t.id)}
        className={`group relative rounded-xl p-4.5 transition-all cursor-pointer border text-left flex flex-col justify-between ${
          isSelected
            ? 'ring-2 ring-[var(--color-primary,#2563EB)] border-[var(--color-primary,#2563EB)] bg-white dark:bg-neutral-900 shadow-md'
            : 'border-neutral-200 dark:border-neutral-800 hover:border-neutral-400 dark:hover:border-neutral-700 bg-white dark:bg-neutral-900/80 shadow-2xs'
        }`}
      >
        <div>
          {/* Header Row: Title & Badges */}
          <div className="flex items-start justify-between gap-2 mb-2">
            <div className="flex items-center gap-2 min-w-0">
              <div
                className={`w-7 h-7 rounded-lg flex items-center justify-center border ${
                  t.mode === 'light'
                    ? 'bg-amber-50 text-amber-600 border-amber-200'
                    : 'bg-blue-950 text-blue-400 border-blue-800'
                }`}
              >
                {t.mode === 'light' ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
              </div>
              <div>
                <h4 className="text-sm font-bold text-neutral-900 dark:text-white truncate">
                  {t.name}
                </h4>
                <p className="text-[11px] text-neutral-500 dark:text-neutral-400">
                  {t.tagline}
                </p>
              </div>
            </div>

            <div className="flex items-center gap-1.5 shrink-0">
              {isSelected && (
                <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-blue-100 dark:bg-blue-950/80 text-blue-700 dark:text-blue-300 flex items-center gap-1">
                  <Check className="w-3 h-3" />
                  Active
                </span>
              )}
            </div>
          </div>

          <p className="text-xs text-neutral-600 dark:text-neutral-300 mb-3.5 leading-relaxed">
            {t.description}
          </p>

          {/* Color Palette Swatch Bar */}
          <div className="flex items-center gap-2 p-2 rounded-lg bg-neutral-50 dark:bg-neutral-800/80 border border-neutral-200/60 dark:border-neutral-700/60 mb-3">
            <div
              className="w-6 h-6 rounded-md border border-black/10 shrink-0 shadow-2xs"
              style={{ backgroundColor: t.preview.primary }}
              title="Primary Accent"
            />
            <div
              className="w-6 h-6 rounded-md border border-black/10 shrink-0 shadow-2xs"
              style={{ backgroundColor: t.preview.accent }}
              title="Brand Orange Accent"
            />
            <div
              className="w-6 h-6 rounded-md border border-black/10 shrink-0 shadow-2xs"
              style={{ backgroundColor: t.preview.surface }}
              title="Surface"
            />
            <div
              className="flex-1 h-6 rounded-md px-2 flex items-center justify-center text-[11px] font-mono font-medium truncate"
              style={{
                backgroundColor: t.preview.background,
                color: t.preview.text,
                border: `1px solid ${t.preview.border}`,
              }}
            >
              Preview Text
            </div>
          </div>
        </div>

        {/* Footer actions & indicators */}
        <div className="flex items-center justify-between pt-2.5 border-t border-neutral-100 dark:border-neutral-800 text-xs">
          <div className="flex items-center gap-1.5">
            {isSelected ? (
              <span className="inline-flex items-center gap-1 font-bold text-blue-600 dark:text-blue-400">
                <Check className="w-3.5 h-3.5" />
                Selected Mode
              </span>
            ) : (
              <span className="text-neutral-400 group-hover:text-neutral-700 dark:group-hover:text-neutral-300">
                Click to apply
              </span>
            )}

            {isGlobalDefault && (
              <span
                className="text-[10px] px-1.5 py-0.5 rounded bg-blue-50 dark:bg-blue-950/60 text-blue-600 dark:text-blue-400 font-bold ml-1"
                title="System Global Default for users without a personal preference"
              >
                Org Default
              </span>
            )}
          </div>

          {/* Super Admin: Set as Organization Default */}
          {isSuperAdmin && !isGlobalDefault && (
            <button
              type="button"
              onClick={async (e) => {
                e.stopPropagation();
                try {
                  await setGlobalDefaultTheme(t.id);
                } catch {
                  // Handled in context
                }
              }}
              className="text-[11px] font-semibold text-blue-600 hover:text-blue-700 dark:text-blue-400 dark:hover:text-blue-300 hover:underline px-1 py-0.5 cursor-pointer"
              title="Set as organization default for users without a personal preference"
            >
              Set as Org Default
            </button>
          )}
        </div>
      </div>
    );
  };

  return (
    <div className="space-y-6">
      {/* Overview Card */}
      <div className="bg-white dark:bg-neutral-900 p-6 rounded-xl border border-neutral-200 dark:border-neutral-800 shadow-xs flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-orange-100 dark:bg-orange-950/60 text-orange-600 dark:text-orange-400 flex items-center justify-center shrink-0">
            <Sparkles className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="text-sm font-bold text-neutral-900 dark:text-white">
                Sarwan Technology Theme: {mode === 'dark' ? 'Dark Mode' : 'Light Mode'}
              </h3>
              {themeSource === 'personal' && (
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-purple-100 text-purple-700 dark:bg-purple-950/70 dark:text-purple-300 font-semibold">
                  Personal Preference
                </span>
              )}
              {themeSource === 'global_default' && (
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-blue-100 text-blue-700 dark:bg-blue-950/70 dark:text-blue-300 font-semibold">
                  Organization Default
                </span>
              )}
              {themeSource === 'fallback' && (
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-neutral-200 text-neutral-700 dark:bg-neutral-800 dark:text-neutral-300 font-semibold">
                  System Fallback
                </span>
              )}
            </div>
            <p className="text-xs text-neutral-500 dark:text-neutral-400 mt-0.5">
              Official corporate branding with tailored Light and Dark display modes.
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          {hasPersonalPreference && (
            <button
              type="button"
              onClick={async () => {
                await clearPersonalPreference();
                toast.success('Reverted to Organization Default');
              }}
              className="px-3 py-2 text-xs font-semibold text-blue-600 dark:text-blue-400 bg-blue-50 dark:bg-blue-950/50 hover:bg-blue-100 dark:hover:bg-blue-900/50 rounded-lg transition inline-flex items-center gap-1.5 cursor-pointer"
              title="Revert personal preference and follow the Organization Default mode"
            >
              <Undo2 className="w-3.5 h-3.5" />
              Follow Org Default
            </button>
          )}

          <button
            type="button"
            onClick={async () => {
              await resetToBrandTheme();
              toast.success('Reset to Sarwan Light Mode');
            }}
            className="px-3 py-2 text-xs font-semibold text-neutral-700 dark:text-neutral-200 bg-neutral-100 dark:bg-neutral-800 hover:bg-neutral-200 dark:hover:bg-neutral-700 rounded-lg transition inline-flex items-center gap-1.5 cursor-pointer"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            Reset to Light Mode
          </button>
        </div>
      </div>

      {/* Super Admin Organization Default Control Notice */}
      {isSuperAdmin && (
        <div className="bg-blue-50/80 dark:bg-blue-950/40 p-4 rounded-xl border border-blue-200 dark:border-blue-800/60 flex items-start gap-3 text-xs text-blue-900 dark:text-blue-200">
          <Shield className="w-4 h-4 text-blue-600 dark:text-blue-400 shrink-0 mt-0.5" />
          <div className="space-y-1">
            <p className="font-bold">Organization Default Appearance</p>
            <p className="text-blue-700 dark:text-blue-300 leading-relaxed">
              As Super Admin, you can set the default mode (Light or Dark) for all organization accounts by clicking &ldquo;Set as Org Default&rdquo; below. Individual users can still choose their own preferred mode.
            </p>
          </div>
        </div>
      )}

      {/* Display Mode Cards */}
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <h3 className="text-xs font-bold uppercase tracking-wider text-neutral-500 dark:text-neutral-400">
            Available Display Modes
          </h3>
          <span className="text-xs text-neutral-400">
            2 Modes Supported
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {themeCatalog.map(renderModeCard)}
        </div>
      </div>
    </div>
  );
};
