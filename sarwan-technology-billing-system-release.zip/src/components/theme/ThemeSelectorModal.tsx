import React, { useState, useEffect, useRef } from 'react';
import {
  Sun,
  Moon,
  Check,
  X,
  Shield,
  RotateCcw,
  Undo2,
  Sparkles,
  Save,
  CheckCircle2,
} from 'lucide-react';
import { useTheme } from '../../context/ThemeContext';
import { useAuth } from '../../context/AuthContext';
import { ThemeId, ThemeMode } from '../../themes/types';
import { toast } from '../../context/ToastContext';

export const ThemeSelectorModal: React.FC = () => {
  const {
    currentTheme,
    themeId,
    mode,
    setMode,
    themeCatalog,
    setTheme,
    globalDefaultTheme,
    setGlobalDefaultTheme,
    themeSource,
    hasPersonalPreference,
    clearPersonalPreference,
    isThemeSelectorOpen,
    closeThemeSelector,
    resetToBrandTheme,
    previewTheme,
    previewThemeId,
  } = useTheme();

  const { isSuperAdmin } = useAuth();

  const [selectedCandidateId, setSelectedCandidateId] = useState<ThemeId>(themeId);
  const [isSaving, setIsSaving] = useState(false);

  // Store previously focused element to restore focus on close
  const triggerElementRef = useRef<HTMLElement | null>(null);

  // Initialize candidate to current active theme whenever modal opens
  useEffect(() => {
    if (isThemeSelectorOpen) {
      triggerElementRef.current = document.activeElement as HTMLElement;
      setSelectedCandidateId(themeId);
    } else {
      if (triggerElementRef.current && typeof triggerElementRef.current.focus === 'function') {
        triggerElementRef.current.focus();
      }
    }
  }, [isThemeSelectorOpen, themeId]);

  // Handle keyboard events (Escape to cancel and close)
  useEffect(() => {
    if (!isThemeSelectorOpen) return;

    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        e.preventDefault();
        handleCancel();
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isThemeSelectorOpen]);

  if (!isThemeSelectorOpen) return null;

  // Preview mode temporarily on click
  const handleSelectMode = (id: ThemeId) => {
    setSelectedCandidateId(id);
    previewTheme(id);
  };

  // Discard preview and close modal
  const handleCancel = () => {
    previewTheme(null);
    closeThemeSelector();
  };

  // Persist selected theme mode
  const handleSaveTheme = async () => {
    if (selectedCandidateId === themeId && !previewThemeId) {
      closeThemeSelector();
      return;
    }

    setIsSaving(true);
    try {
      await setTheme(selectedCandidateId);
      const modeName = selectedCandidateId === 'sarwan_dark' ? 'Dark Mode' : 'Light Mode';
      toast.success(`Theme mode updated to ${modeName}`);
      closeThemeSelector();
    } catch (err) {
      console.error('[ThemeSelector] Failed to persist theme:', err);
      toast.error('Failed to save theme mode');
    } finally {
      setIsSaving(false);
    }
  };

  // Super admin set organization default mode
  const handleSetGlobalDefault = async (e: React.MouseEvent, id: ThemeId) => {
    e.stopPropagation();
    try {
      await setGlobalDefaultTheme(id);
    } catch {
      // Toast error already handled in context
    }
  };

  const isPreviewingDifferentMode = selectedCandidateId !== themeId;

  const lightDef = themeCatalog.find((t) => t.id === 'sarwan_light' || t.mode === 'light');
  const darkDef = themeCatalog.find((t) => t.id === 'sarwan_dark' || t.mode === 'dark');

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/60 backdrop-blur-xs animate-in fade-in duration-200"
      onClick={handleCancel}
      role="dialog"
      aria-modal="true"
      aria-labelledby="theme-modal-title"
    >
      <div
        className="w-full max-w-2xl flex flex-col bg-white dark:bg-neutral-900 rounded-2xl shadow-2xl border border-neutral-200 dark:border-neutral-800 overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Modal Header */}
        <div className="flex items-center justify-between px-6 py-4.5 border-b border-neutral-200 dark:border-neutral-800 bg-white dark:bg-neutral-900">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-orange-100 dark:bg-orange-950/60 flex items-center justify-center text-orange-600 dark:text-orange-400 shadow-2xs shrink-0">
              <Sparkles className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 id="theme-modal-title" className="text-base font-bold text-neutral-900 dark:text-white">
                  Sarwan Technology Appearance
                </h3>
                <span className="text-[10px] font-semibold px-2 py-0.5 rounded-full bg-orange-100 dark:bg-orange-950/60 text-orange-600 dark:text-orange-400">
                  Official Brand
                </span>
              </div>
              <p className="text-xs text-neutral-500 dark:text-neutral-400 mt-0.5">
                Switch between Light Mode and Dark Mode. Changes preview immediately.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-1.5">
            {hasPersonalPreference && (
              <button
                type="button"
                onClick={async () => {
                  previewTheme(null);
                  await clearPersonalPreference();
                  toast.success('Reverted to Organization Default theme');
                  closeThemeSelector();
                }}
                className="hidden sm:inline-flex px-2.5 py-1.5 text-xs font-semibold text-blue-600 dark:text-blue-400 hover:bg-blue-50 dark:hover:bg-blue-950/60 rounded-lg transition items-center gap-1.5 cursor-pointer border border-blue-200 dark:border-blue-900"
                title="Revert personal preference and follow the Organization Default theme"
              >
                <Undo2 className="w-3.5 h-3.5" />
                Follow Org Default
              </button>
            )}
            <button
              type="button"
              onClick={handleCancel}
              className="p-1.5 text-neutral-400 hover:text-neutral-600 dark:hover:text-neutral-200 rounded-lg hover:bg-neutral-100 dark:hover:bg-neutral-800 transition cursor-pointer"
              aria-label="Close modal"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Modal Body / Mode Cards */}
        <div className="p-6 space-y-5">
          {/* Quick Segmented Toggle */}
          <div className="flex p-1 bg-neutral-100 dark:bg-neutral-800/80 rounded-xl border border-neutral-200 dark:border-neutral-700">
            <button
              type="button"
              onClick={() => handleSelectMode('sarwan_light')}
              className={`flex-1 py-2 text-xs font-bold rounded-lg transition flex items-center justify-center gap-2 cursor-pointer ${
                selectedCandidateId === 'sarwan_light' || (selectedCandidateId as string) === 'sarwan_classic_light'
                  ? 'bg-white text-neutral-900 shadow-sm'
                  : 'text-neutral-500 hover:text-neutral-900 dark:text-neutral-400 dark:hover:text-white'
              }`}
            >
              <Sun className="w-4 h-4 text-amber-500" />
              Light Mode
            </button>
            <button
              type="button"
              onClick={() => handleSelectMode('sarwan_dark')}
              className={`flex-1 py-2 text-xs font-bold rounded-lg transition flex items-center justify-center gap-2 cursor-pointer ${
                selectedCandidateId === 'sarwan_dark'
                  ? 'bg-neutral-900 text-white dark:bg-neutral-700 shadow-sm'
                  : 'text-neutral-500 hover:text-neutral-900 dark:text-neutral-400 dark:hover:text-white'
              }`}
            >
              <Moon className="w-4 h-4 text-blue-400" />
              Dark Mode
            </button>
          </div>

          {/* Side-by-side Visual Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {/* 1. LIGHT MODE CARD */}
            {lightDef && (
              <div
                onClick={() => handleSelectMode('sarwan_light')}
                tabIndex={0}
                role="button"
                onKeyDown={(e) => {
                  if (e.key === 'Enter' || e.key === ' ') {
                    e.preventDefault();
                    handleSelectMode('sarwan_light');
                  }
                }}
                aria-pressed={selectedCandidateId === 'sarwan_light' || (selectedCandidateId as string) === 'sarwan_classic_light'}
                className={`relative rounded-xl p-4.5 transition-all cursor-pointer border text-left flex flex-col justify-between ${
                  selectedCandidateId === 'sarwan_light' || (selectedCandidateId as string) === 'sarwan_classic_light'
                    ? 'ring-2 ring-blue-600 border-blue-600 shadow-md bg-white'
                    : 'border-neutral-200 dark:border-neutral-800 hover:border-neutral-400 dark:hover:border-neutral-700 bg-white dark:bg-neutral-900/90 shadow-2xs'
                }`}
              >
                <div>
                  <div className="flex items-center justify-between gap-2 mb-2">
                    <div className="flex items-center gap-2">
                      <div className="w-7 h-7 rounded-lg bg-amber-50 flex items-center justify-center text-amber-600 border border-amber-200">
                        <Sun className="w-4 h-4" />
                      </div>
                      <h4 className="text-sm font-bold text-neutral-900">
                        Light Mode
                      </h4>
                    </div>
                    {(selectedCandidateId === 'sarwan_light' || (selectedCandidateId as string) === 'sarwan_classic_light') && (
                      <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-blue-100 text-blue-700 flex items-center gap-1">
                        <Check className="w-3 h-3" />
                        Selected
                      </span>
                    )}
                  </div>

                  <p className="text-xs text-neutral-600 mb-3 leading-relaxed">
                    Clean, high-contrast crisp white canvas with corporate blue accents and signature orange highlights.
                  </p>

                  {/* Swatches preview */}
                  <div className="flex items-center gap-2 p-2 rounded-lg bg-neutral-50 border border-neutral-200/80 mb-3">
                    <div className="w-6 h-6 rounded-md bg-[#2563EB] shadow-2xs" title="Primary Blue #2563EB" />
                    <div className="w-6 h-6 rounded-md bg-[#F7941D] shadow-2xs" title="Sarwan Orange #F7941D" />
                    <div className="w-6 h-6 rounded-md bg-[#FFFFFF] border border-neutral-300 shadow-2xs" title="Card Surface" />
                    <div className="flex-1 h-6 rounded-md px-2 flex items-center justify-center text-[10px] font-mono font-medium text-neutral-900 bg-[#F8FAFC] border border-neutral-200">
                      Aa 123
                    </div>
                  </div>
                </div>

                <div className="flex items-center justify-between pt-2 border-t border-neutral-100 text-[11px]">
                  <span className="text-neutral-500 font-medium">
                    {mode === 'light' ? 'Currently Active' : 'Click to preview'}
                  </span>
                  {isSuperAdmin && (
                    <button
                      type="button"
                      onClick={(e) => handleSetGlobalDefault(e, 'sarwan_light')}
                      className="text-blue-600 hover:text-blue-700 hover:underline font-semibold cursor-pointer"
                      title="Set Light Mode as default for all organization users"
                    >
                      Set Org Default
                    </button>
                  )}
                </div>
              </div>
            )}

            {/* 2. DARK MODE CARD */}
            {darkDef && (
              <div
                onClick={() => handleSelectMode('sarwan_dark')}
                tabIndex={0}
                role="button"
                onKeyDown={(e) => {
                  if (e.key === 'Enter' || e.key === ' ') {
                    e.preventDefault();
                    handleSelectMode('sarwan_dark');
                  }
                }}
                aria-pressed={selectedCandidateId === 'sarwan_dark'}
                className={`relative rounded-xl p-4.5 transition-all cursor-pointer border text-left flex flex-col justify-between ${
                  selectedCandidateId === 'sarwan_dark'
                    ? 'ring-2 ring-blue-500 border-blue-500 shadow-md bg-[#131E32]'
                    : 'border-neutral-200 dark:border-neutral-800 hover:border-neutral-400 dark:hover:border-neutral-700 bg-neutral-900 text-white shadow-2xs'
                }`}
              >
                <div>
                  <div className="flex items-center justify-between gap-2 mb-2">
                    <div className="flex items-center gap-2">
                      <div className="w-7 h-7 rounded-lg bg-blue-950 flex items-center justify-center text-blue-400 border border-blue-800">
                        <Moon className="w-4 h-4" />
                      </div>
                      <h4 className="text-sm font-bold text-white">
                        Dark Mode
                      </h4>
                    </div>
                    {selectedCandidateId === 'sarwan_dark' && (
                      <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-blue-900 text-blue-300 flex items-center gap-1">
                        <Check className="w-3 h-3" />
                        Selected
                      </span>
                    )}
                  </div>

                  <p className="text-xs text-neutral-300 mb-3 leading-relaxed">
                    Layered deep charcoal surfaces designed for comfortable working in low-light environments.
                  </p>

                  {/* Swatches preview */}
                  <div className="flex items-center gap-2 p-2 rounded-lg bg-[#0B1120] border border-neutral-700/80 mb-3">
                    <div className="w-6 h-6 rounded-md bg-[#3B82F6] shadow-2xs" title="Primary Blue #3B82F6" />
                    <div className="w-6 h-6 rounded-md bg-[#F7941D] shadow-2xs" title="Sarwan Orange #F7941D" />
                    <div className="w-6 h-6 rounded-md bg-[#131E32] border border-neutral-600 shadow-2xs" title="Card Surface" />
                    <div className="flex-1 h-6 rounded-md px-2 flex items-center justify-center text-[10px] font-mono font-medium text-white bg-[#0B1120] border border-neutral-700">
                      Aa 123
                    </div>
                  </div>
                </div>

                <div className="flex items-center justify-between pt-2 border-t border-neutral-800 text-[11px]">
                  <span className="text-neutral-400 font-medium">
                    {mode === 'dark' ? 'Currently Active' : 'Click to preview'}
                  </span>
                  {isSuperAdmin && (
                    <button
                      type="button"
                      onClick={(e) => handleSetGlobalDefault(e, 'sarwan_dark')}
                      className="text-blue-400 hover:text-blue-300 hover:underline font-semibold cursor-pointer"
                      title="Set Dark Mode as default for all organization users"
                    >
                      Set Org Default
                    </button>
                  )}
                </div>
              </div>
            )}
          </div>

          {/* Super Admin Notice */}
          {isSuperAdmin && (
            <div className="p-3.5 rounded-xl bg-blue-50 dark:bg-blue-950/40 border border-blue-200 dark:border-blue-800/60 flex items-start gap-3 text-xs text-blue-900 dark:text-blue-200">
              <Shield className="w-4 h-4 text-blue-600 dark:text-blue-400 shrink-0 mt-0.5" />
              <div>
                <span className="font-semibold">Super Admin Notice: </span>
                Clicking <strong>&ldquo;Set Org Default&rdquo;</strong> configures the organization-wide mode for users who haven&apos;t chosen an individual preference.
              </div>
            </div>
          )}
        </div>

        {/* Modal Footer */}
        <div className="px-6 py-4 bg-neutral-50 dark:bg-neutral-900 border-t border-neutral-200 dark:border-neutral-800 flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 text-xs">
          <div className="flex items-center gap-2 text-neutral-600 dark:text-neutral-400">
            <span>
              Mode:{' '}
              <strong className="text-neutral-900 dark:text-white capitalize">
                {selectedCandidateId === 'sarwan_dark' ? 'Dark' : 'Light'} Mode
              </strong>
            </span>
            {isPreviewingDifferentMode && (
              <span className="text-[10px] px-2 py-0.5 rounded-md bg-amber-100 text-amber-800 dark:bg-amber-950/80 dark:text-amber-300 font-medium">
                Unsaved Preview
              </span>
            )}
          </div>

          <div className="flex items-center justify-end gap-2">
            <button
              type="button"
              onClick={handleCancel}
              className="px-4 py-2 text-xs font-medium text-neutral-700 dark:text-neutral-300 hover:bg-neutral-200 dark:hover:bg-neutral-800 rounded-lg transition cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="button"
              onClick={handleSaveTheme}
              disabled={isSaving}
              className="px-4.5 py-2 text-xs font-semibold bg-blue-600 hover:bg-blue-700 text-white rounded-lg transition shadow-xs cursor-pointer flex items-center gap-1.5 disabled:opacity-50"
            >
              {isSaving ? (
                <span>Saving...</span>
              ) : isPreviewingDifferentMode ? (
                <>
                  <Save className="w-3.5 h-3.5" />
                  Save &amp; Apply
                </>
              ) : (
                <>
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  Done
                </>
              )}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
