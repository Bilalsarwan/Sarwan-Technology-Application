import React, { useState } from 'react';
import { UserProfile, BusinessSettings, UserRole, UserAccountStatus } from '../../types';
import { getOfficialUserId, isProfileComplete, getProfileCompletionDetails } from '../../utils/profileCompletion';
import { PRIMARY_ADMIN_EMAILS, resetUserPasswordByAdmin } from '../../services/security';
import { toggleUserActiveStatus, setUserAccountStatus } from '../../services/db';
import {
  X,
  User,
  Mail,
  Phone,
  Briefcase,
  Building2,
  Shield,
  CreditCard,
  FileText,
  CheckCircle2,
  XCircle,
  Calendar,
  MapPin,
  IdCard,
  Clock,
  KeyRound,
  AlertCircle,
  AlertTriangle,
  Download,
  Edit,
  Power,
  Sparkles,
  Info,
  Loader2,
  Check,
  FileCheck,
  Lock,
} from 'lucide-react';

interface UserDetailsModalProps {
  user: UserProfile;
  settings?: BusinessSettings;
  currentUser: UserProfile | null;
  onClose: () => void;
  onOpenViewProfile: (user: UserProfile) => void;
  onOpenEditProfile: (user: UserProfile) => void;
  onOpenCompleteProfile: (user: UserProfile) => void;
  onOpenUserCard: (user: UserProfile) => void;
  onDownloadUserCard: (user: UserProfile) => void;
  onOpenDocuments: (user: UserProfile) => void;
  onUserStatusChanged: (updatedUser: UserProfile) => void;
  onRoleChange?: (userId: string, newRole: UserRole) => Promise<void> | void;
}

export const UserDetailsModal: React.FC<UserDetailsModalProps> = ({
  user,
  settings,
  currentUser,
  onClose,
  onOpenViewProfile,
  onOpenEditProfile,
  onOpenCompleteProfile,
  onOpenUserCard,
  onDownloadUserCard,
  onOpenDocuments,
  onUserStatusChanged,
  onRoleChange,
}) => {
  const officialId = getOfficialUserId(user);
  const complete = isProfileComplete(user);
  const completion = getProfileCompletionDetails(user);

  const isSuperAdmin = currentUser?.role === 'super_admin';
  const canManageStaff =
    isSuperAdmin ||
    currentUser?.permissions?.canManageStaff ||
    currentUser?.permissions?.canManageUsers;

  const isPrimaryAdmin = PRIMARY_ADMIN_EMAILS.includes(user.email?.toLowerCase() || '');
  const isTargetSuperAdmin = user.role === 'super_admin';
  const isSelf = currentUser?.id === user.id;

  // Status toggle state
  const [togglingStatus, setTogglingStatus] = useState<boolean>(false);
  const [statusMessage, setStatusMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  // Password reset state
  const [showPasswordResetDialog, setShowPasswordResetDialog] = useState<boolean>(false);
  const [customPassword, setCustomPassword] = useState<string>('');
  const [resettingPassword, setResettingPassword] = useState<boolean>(false);
  const [resetResult, setResetResult] = useState<{ temporaryPassword: string } | null>(null);
  const [resetError, setResetError] = useState<string | null>(null);

  const currentStatus: UserAccountStatus =
    user.status === 'suspended'
      ? 'suspended'
      : user.status === 'inactive' || user.isDeactivated
      ? 'inactive'
      : 'active';

  const isSuspended = currentStatus === 'suspended';
  const isInactive = currentStatus === 'inactive';

  // Atomic, canonical account status management (active | inactive | suspended)
  const handleSetAccountStatus = async (newStatus: UserAccountStatus) => {
    if (isPrimaryAdmin || isTargetSuperAdmin) {
      setStatusMessage({
        type: 'error',
        text: 'Primary and Super Administrator accounts cannot be deactivated or suspended.',
      });
      return;
    }

    if (isSelf) {
      setStatusMessage({
        type: 'error',
        text: 'You cannot alter your own account status.',
      });
      return;
    }

    if (newStatus === currentStatus) return;

    const actionLabels: Record<UserAccountStatus, string> = {
      active: 'activate',
      inactive: 'deactivate (set inactive)',
      suspended: 'suspend',
      pending: 'set to pending',
      rejected: 'reject',
    };

    if (
      !confirm(
        `Are you sure you want to ${actionLabels[newStatus]} the account for ${user.name} (${officialId})?\n\nTarget Account Status: ${newStatus.toUpperCase()}`
      )
    ) {
      return;
    }

    setTogglingStatus(true);
    setStatusMessage(null);
    try {
      await setUserAccountStatus(
        user.id,
        newStatus,
        currentUser?.id || 'super_admin',
        currentUser?.name || 'Super Admin'
      );

      const isDeactivated = newStatus === 'inactive' || newStatus === 'suspended';
      const updatedUser: UserProfile = {
        ...user,
        status: newStatus,
        isDeactivated,
        updatedAt: new Date().toISOString(),
      };

      onUserStatusChanged(updatedUser);
      setStatusMessage({
        type: 'success',
        text: `Account status successfully updated to "${newStatus.toUpperCase()}". Staff directory updated immediately.`,
      });
      setTimeout(() => setStatusMessage(null), 3500);
    } catch (err: any) {
      console.error('Error changing account status:', err);
      setStatusMessage({
        type: 'error',
        text: err?.message || 'Failed to update account status.',
      });
    } finally {
      setTogglingStatus(false);
    }
  };

  const handleToggleActive = () => handleSetAccountStatus(isInactive ? 'active' : 'inactive');
  const handleToggleSuspend = () => handleSetAccountStatus(isSuspended ? 'active' : 'suspended');

  // Handle password reset
  const handleConfirmPasswordReset = async () => {
    if (!customPassword || customPassword.trim().length < 6) {
      setResetError('Please enter a temporary password of at least 6 characters.');
      return;
    }

    setResettingPassword(true);
    setResetError(null);
    setResetResult(null);

    try {
      const res = await resetUserPasswordByAdmin({
        targetUserId: user.id,
        targetUserName: user.name,
        newPassword: customPassword.trim(),
        adminId: currentUser?.id || 'super_admin',
        adminName: currentUser?.name || 'Super Admin',
      });

      setResetResult(res);
      setCustomPassword('');
      const updatedUser: UserProfile = {
        ...user,
        mustChangePassword: true,
      };
      onUserStatusChanged(updatedUser);
    } catch (err: any) {
      console.error('Error resetting password:', err);
      setResetError(err?.message || 'Failed to reset password.');
    } finally {
      setResettingPassword(false);
    }
  };

  const formatDate = (dateStr?: string) => {
    if (!dateStr || !dateStr.trim()) return null;
    try {
      const d = new Date(dateStr);
      if (isNaN(d.getTime())) return dateStr;
      return d.toLocaleDateString(undefined, {
        year: 'numeric',
        month: 'short',
        day: 'numeric',
      });
    } catch {
      return dateStr;
    }
  };

  const formatDateTime = (dateStr?: string) => {
    if (!dateStr || !dateStr.trim()) return null;
    try {
      const d = new Date(dateStr);
      if (isNaN(d.getTime())) return dateStr;
      return d.toLocaleString(undefined, {
        year: 'numeric',
        month: 'short',
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit',
      });
    } catch {
      return dateStr;
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-5 overflow-y-auto">
      <div className="w-full max-w-4xl bg-white rounded-2xl shadow-2xl border border-neutral-200 overflow-hidden my-auto flex flex-col max-h-[92vh]">
        {/* Modal Top Header with Identity Snapshot */}
        <div className="bg-neutral-900 text-white p-5 border-b border-neutral-800">
          <div className="flex items-start justify-between gap-4">
            <div className="flex items-center gap-4 min-w-0">
              {/* Profile Photo */}
              <div className="relative shrink-0">
                {user.photoURL ? (
                  <img
                    src={user.photoURL}
                    alt={user.name}
                    className="w-16 h-16 rounded-2xl object-cover border-2 border-orange-500 shadow-md bg-neutral-800"
                  />
                ) : (
                  <div className="w-16 h-16 rounded-2xl bg-neutral-800 border-2 border-orange-500/80 flex items-center justify-center font-black text-orange-400 text-2xl shadow-inner">
                    {user.name?.charAt(0).toUpperCase() || 'U'}
                  </div>
                )}

                <span
                  title={
                    isSuspended
                      ? 'Account Suspended'
                      : isInactive
                      ? 'Account Deactivated / Inactive'
                      : 'Account Active'
                  }
                  className={`absolute -bottom-1 -right-1 w-4 h-4 rounded-full border-2 border-neutral-900 ${
                    isSuspended ? 'bg-amber-500' : isInactive ? 'bg-red-500' : 'bg-emerald-500'
                  }`}
                />
              </div>

              {/* Title & Immutable User ID */}
              <div className="min-w-0">
                <div className="flex items-center gap-2 flex-wrap">
                  <h2 className="text-lg sm:text-xl font-bold text-white tracking-tight truncate" title={user.name}>
                    {user.name}
                  </h2>
                  {/* Immutable ID Badge */}
                  <span
                    className="font-mono text-xs font-bold text-orange-400 bg-neutral-800 px-2.5 py-0.5 rounded border border-neutral-700 tracking-wider"
                    title={`Immutable System User ID: ${officialId}`}
                  >
                    {officialId}
                  </span>
                  {/* Role Badge */}
                  <span className="text-[11px] font-semibold px-2 py-0.5 rounded bg-orange-500/20 text-orange-300 border border-orange-500/30 font-mono capitalize">
                    {user.role?.replace('_', ' ')}
                  </span>
                  {/* Account Status Badge */}
                  {isSuspended ? (
                    <span className="text-[11px] font-semibold px-2 py-0.5 rounded bg-amber-500/20 text-amber-300 border border-amber-500/30 flex items-center gap-1">
                      <span className="w-1.5 h-1.5 rounded-full bg-amber-400" />
                      Suspended
                    </span>
                  ) : isInactive ? (
                    <span className="text-[11px] font-semibold px-2 py-0.5 rounded bg-red-500/20 text-red-300 border border-red-500/30 flex items-center gap-1">
                      <span className="w-1.5 h-1.5 rounded-full bg-red-400" />
                      Inactive
                    </span>
                  ) : (
                    <span className="text-[11px] font-semibold px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 flex items-center gap-1">
                      <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
                      Active
                    </span>
                  )}
                </div>

                <div className="flex items-center gap-2 text-xs text-neutral-400 mt-1 flex-wrap">
                  <span className="text-neutral-200 font-medium">{user.jobTitle || 'Staff Member'}</span>
                  <span>•</span>
                  <span>{user.department || 'Operations'}</span>
                  <span>•</span>
                  <span className="font-mono text-neutral-300">@{user.username || 'user'}</span>
                </div>
              </div>
            </div>

            <button
              type="button"
              onClick={onClose}
              className="p-2 text-neutral-400 hover:text-white rounded-xl hover:bg-neutral-800 transition cursor-pointer shrink-0"
              aria-label="Close user details"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Profile Completion Indicator Strip */}
          <div className="mt-4 pt-3.5 border-t border-neutral-800 flex items-center justify-between flex-wrap gap-2 text-xs">
            <div className="flex items-center gap-2">
              <span className="text-neutral-400">Profile Completion Status:</span>
              {complete ? (
                <span className="inline-flex items-center gap-1 px-2.5 py-0.5 bg-blue-950 text-blue-300 border border-blue-800 rounded-md font-bold text-xs">
                  <CheckCircle2 className="w-3.5 h-3.5 text-blue-400" />
                  <span>Blue Complete ✓ (100%)</span>
                </span>
              ) : (
                <span className="inline-flex items-center gap-1 px-2.5 py-0.5 bg-red-950 text-red-300 border border-red-800 rounded-md font-bold text-xs">
                  <XCircle className="w-3.5 h-3.5 text-red-400" />
                  <span>Red Incomplete ✕ ({completion.percentage}%)</span>
                </span>
              )}
            </div>

            {!complete && completion.missingFields.length > 0 && (
              <span className="text-[11px] text-amber-300/90 font-medium">
                Missing: {completion.missingFields.map((f) => f.label).join(', ')}
              </span>
            )}
          </div>
        </div>

        {/* Action Toolbar Buttons */}
        <div className="bg-neutral-50 px-5 py-3 border-b border-neutral-200 flex items-center gap-2 overflow-x-auto scrollbar-none flex-wrap">
          {/* View Profile */}
          <button
            type="button"
            onClick={() => onOpenViewProfile(user)}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-white hover:bg-neutral-100 text-neutral-800 text-xs font-bold rounded-lg border border-neutral-300 shadow-2xs transition cursor-pointer active:scale-98"
          >
            <User className="w-3.5 h-3.5 text-neutral-600" />
            <span>View Profile</span>
          </button>

          {/* Edit Profile */}
          {canManageStaff && (
            <button
              type="button"
              onClick={() => onOpenEditProfile(user)}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-white hover:bg-neutral-100 text-neutral-800 text-xs font-bold rounded-lg border border-neutral-300 shadow-2xs transition cursor-pointer active:scale-98"
            >
              <Edit className="w-3.5 h-3.5 text-neutral-600" />
              <span>Edit Profile</span>
            </button>
          )}

          {/* Complete Profile */}
          {canManageStaff && (
            <button
              type="button"
              onClick={() => onOpenCompleteProfile(user)}
              className={`inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-bold rounded-lg border shadow-2xs transition cursor-pointer active:scale-98 ${
                complete
                  ? 'bg-blue-50 text-blue-700 border-blue-200 hover:bg-blue-100'
                  : 'bg-orange-50 text-orange-700 border-orange-300 hover:bg-orange-100 font-extrabold'
              }`}
            >
              <Check className="w-3.5 h-3.5 text-current" />
              <span>{complete ? 'Update Profile' : 'Complete Profile'}</span>
            </button>
          )}

          {/* User Card */}
          <button
            type="button"
            onClick={() => onOpenUserCard(user)}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-white hover:bg-neutral-100 text-neutral-800 text-xs font-bold rounded-lg border border-neutral-300 shadow-2xs transition cursor-pointer active:scale-98"
          >
            <CreditCard className="w-3.5 h-3.5 text-orange-600" />
            <span>User Card</span>
          </button>

          {/* Download User Card */}
          <button
            type="button"
            onClick={() => onDownloadUserCard(user)}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-orange-50 hover:bg-orange-100 text-orange-800 text-xs font-bold rounded-lg border border-orange-200 shadow-2xs transition cursor-pointer active:scale-98"
          >
            <Download className="w-3.5 h-3.5 text-orange-600" />
            <span>Download User Card</span>
          </button>

          {/* Employee Documents */}
          <button
            type="button"
            onClick={() => onOpenDocuments(user)}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-white hover:bg-neutral-100 text-neutral-800 text-xs font-bold rounded-lg border border-neutral-300 shadow-2xs transition cursor-pointer active:scale-98"
          >
            <FileText className="w-3.5 h-3.5 text-neutral-600" />
            <span>Documents</span>
          </button>

          {/* Account Status Actions (Super Admin only, strictly respecting RBAC) */}
          {isSuperAdmin && !isPrimaryAdmin && !isTargetSuperAdmin && !isSelf ? (
            <div className="flex items-center gap-1.5 flex-wrap">
              {currentStatus !== 'active' && (
                <button
                  type="button"
                  onClick={() => handleSetAccountStatus('active')}
                  disabled={togglingStatus}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-emerald-50 hover:bg-emerald-100 text-emerald-800 text-xs font-bold rounded-lg border border-emerald-300 shadow-2xs transition cursor-pointer active:scale-98 disabled:opacity-50"
                  title="Activate account to permit login and system access"
                >
                  {togglingStatus ? (
                    <Loader2 className="w-3.5 h-3.5 animate-spin" />
                  ) : (
                    <Power className="w-3.5 h-3.5 text-emerald-600" />
                  )}
                  <span>Activate Account</span>
                </button>
              )}

              {currentStatus !== 'inactive' && (
                <button
                  type="button"
                  onClick={() => handleSetAccountStatus('inactive')}
                  disabled={togglingStatus}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-red-50 hover:bg-red-100 text-red-800 text-xs font-bold rounded-lg border border-red-300 shadow-2xs transition cursor-pointer active:scale-98 disabled:opacity-50"
                  title="Deactivate account to block login access"
                >
                  {togglingStatus ? (
                    <Loader2 className="w-3.5 h-3.5 animate-spin" />
                  ) : (
                    <Power className="w-3.5 h-3.5 text-red-600" />
                  )}
                  <span>Deactivate</span>
                </button>
              )}

              {currentStatus !== 'suspended' && (
                <button
                  type="button"
                  onClick={() => handleSetAccountStatus('suspended')}
                  disabled={togglingStatus}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-amber-50 hover:bg-amber-100 text-amber-900 text-xs font-bold rounded-lg border border-amber-300 shadow-2xs transition cursor-pointer active:scale-98 disabled:opacity-50"
                  title="Suspend account access temporarily"
                >
                  {togglingStatus ? (
                    <Loader2 className="w-3.5 h-3.5 animate-spin" />
                  ) : (
                    <AlertTriangle className="w-3.5 h-3.5 text-amber-700" />
                  )}
                  <span>Suspend</span>
                </button>
              )}
            </div>
          ) : (isPrimaryAdmin || isTargetSuperAdmin) ? (
            <div
              className="inline-flex items-center gap-1.5 px-2.5 py-1.5 bg-neutral-100 text-neutral-600 text-xs font-semibold rounded-lg border border-neutral-250"
              title="Primary and Super Administrator accounts cannot be deactivated or suspended."
            >
              <Lock className="w-3.5 h-3.5 text-neutral-500" />
              <span>Protected Admin Account</span>
            </div>
          ) : isSelf ? (
            <div
              className="inline-flex items-center gap-1.5 px-2.5 py-1.5 bg-neutral-100 text-neutral-600 text-xs font-semibold rounded-lg border border-neutral-250"
              title="You cannot alter your own active session status."
            >
              <Shield className="w-3.5 h-3.5 text-neutral-500" />
              <span>Current Session</span>
            </div>
          ) : null}

          {/* Reset Password (Super Admin only) */}
          {isSuperAdmin && (
            <button
              type="button"
              onClick={() => {
                setShowPasswordResetDialog(true);
                setResetError(null);
                setResetResult(null);
              }}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-amber-50 hover:bg-amber-100 text-amber-900 text-xs font-bold rounded-lg border border-amber-300 shadow-2xs transition cursor-pointer active:scale-98 ml-auto"
            >
              <KeyRound className="w-3.5 h-3.5 text-amber-700" />
              <span>Reset Password</span>
            </button>
          )}
        </div>

        {/* Status Notification */}
        {statusMessage && (
          <div
            className={`mx-5 mt-4 p-3 rounded-xl text-xs font-semibold flex items-center gap-2 border ${
              statusMessage.type === 'success'
                ? 'bg-emerald-50 text-emerald-800 border-emerald-200'
                : 'bg-red-50 text-red-800 border-red-200'
            }`}
          >
            {statusMessage.type === 'success' ? (
              <CheckCircle2 className="w-4 h-4 text-emerald-600" />
            ) : (
              <AlertCircle className="w-4 h-4 text-red-600" />
            )}
            <span>{statusMessage.text}</span>
          </div>
        )}

        {/* Scrollable Detailed Information View */}
        <div className="p-5 overflow-y-auto space-y-6 flex-1 text-xs">
          {/* SECTION 1: PROFILE SECTION */}
          <div className="bg-white rounded-xl border border-neutral-200 p-4 shadow-2xs">
            <div className="flex items-center gap-2 pb-3 border-b border-neutral-150 mb-4">
              <User className="w-4 h-4 text-orange-600" />
              <h4 className="text-xs font-bold text-neutral-900 uppercase tracking-wider">
                Profile Section
              </h4>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
              {/* Full Name */}
              <div>
                <span className="text-[10px] text-neutral-400 font-semibold uppercase block">Full Name</span>
                <p className="font-bold text-neutral-900 text-xs mt-0.5">{user.name || '—'}</p>
              </div>

              {/* User ID (Immutable) */}
              <div>
                <span className="text-[10px] text-neutral-400 font-semibold uppercase block">User ID (Immutable)</span>
                <p className="font-mono font-bold text-orange-700 text-xs mt-0.5">{officialId}</p>
              </div>

              {/* Username */}
              <div>
                <span className="text-[10px] text-neutral-400 font-semibold uppercase block">Username</span>
                <p className="font-mono font-semibold text-neutral-800 text-xs mt-0.5">@{user.username || '—'}</p>
              </div>

              {/* Email */}
              <div>
                <span className="text-[10px] text-neutral-400 font-semibold uppercase block">Email</span>
                <p className="font-mono text-neutral-800 text-xs mt-0.5 truncate" title={user.email}>{user.email || '—'}</p>
              </div>

              {/* Phone */}
              <div>
                <span className="text-[10px] text-neutral-400 font-semibold uppercase block">Phone</span>
                <p className="font-mono text-neutral-800 text-xs mt-0.5">{user.phone || <span className="text-neutral-400 italic">Incomplete / Empty</span>}</p>
              </div>

              {/* Job Title / Position */}
              <div>
                <span className="text-[10px] text-neutral-400 font-semibold uppercase block">Job Title / Position</span>
                <p className="font-semibold text-neutral-800 text-xs mt-0.5">{user.jobTitle || <span className="text-neutral-400 italic">Incomplete / Empty</span>}</p>
              </div>

              {/* Department */}
              <div>
                <span className="text-[10px] text-neutral-400 font-semibold uppercase block">Department</span>
                <p className="text-neutral-800 text-xs mt-0.5">{user.department || <span className="text-neutral-400 italic">Incomplete / Empty</span>}</p>
              </div>

              {/* Role */}
              <div>
                <span className="text-[10px] text-neutral-400 font-semibold uppercase block">Role</span>
                {isSuperAdmin && !isPrimaryAdmin && !isTargetSuperAdmin && !user.customerId && onRoleChange ? (
                  <div className="mt-1">
                    <select
                      value={user.role}
                      onChange={(e) => onRoleChange(user.id, e.target.value as UserRole)}
                      className="px-2 py-1 text-xs bg-neutral-50 border border-neutral-300 rounded-md font-semibold text-neutral-800 focus:outline-none focus:ring-1 focus:ring-orange-500 cursor-pointer"
                    >
                      <option value="invoice_manager">Invoice Manager</option>
                      <option value="payment_collector">Payment Collector</option>
                    </select>
                  </div>
                ) : (
                  <p className="font-semibold text-neutral-900 text-xs mt-0.5 capitalize">{user.role?.replace('_', ' ') || '—'}</p>
                )}
              </div>

              {/* Account Status */}
              <div>
                <span className="text-[10px] text-neutral-400 font-semibold uppercase block">Account Status</span>
                {isSuperAdmin && !isPrimaryAdmin && !isTargetSuperAdmin && !isSelf ? (
                  <div className="mt-1 space-y-1">
                    <div className="inline-flex items-center gap-1 bg-neutral-100 p-0.5 rounded-lg border border-neutral-250">
                      <button
                        type="button"
                        disabled={togglingStatus}
                        onClick={() => handleSetAccountStatus('active')}
                        className={`px-2 py-0.5 text-[11px] font-bold rounded-md transition cursor-pointer flex items-center gap-1 ${
                          currentStatus === 'active'
                            ? 'bg-emerald-600 text-white shadow-2xs'
                            : 'text-neutral-600 hover:text-neutral-900 hover:bg-neutral-200/70'
                        }`}
                        title="Set account status to Active"
                      >
                        <span className={`w-1.5 h-1.5 rounded-full ${currentStatus === 'active' ? 'bg-white' : 'bg-emerald-500'}`} />
                        Active
                      </button>
                      <button
                        type="button"
                        disabled={togglingStatus}
                        onClick={() => handleSetAccountStatus('inactive')}
                        className={`px-2 py-0.5 text-[11px] font-bold rounded-md transition cursor-pointer flex items-center gap-1 ${
                          currentStatus === 'inactive'
                            ? 'bg-red-600 text-white shadow-2xs'
                            : 'text-neutral-600 hover:text-neutral-900 hover:bg-neutral-200/70'
                        }`}
                        title="Set account status to Inactive (Deactivated)"
                      >
                        <span className={`w-1.5 h-1.5 rounded-full ${currentStatus === 'inactive' ? 'bg-white' : 'bg-red-500'}`} />
                        Inactive
                      </button>
                      <button
                        type="button"
                        disabled={togglingStatus}
                        onClick={() => handleSetAccountStatus('suspended')}
                        className={`px-2 py-0.5 text-[11px] font-bold rounded-md transition cursor-pointer flex items-center gap-1 ${
                          currentStatus === 'suspended'
                            ? 'bg-amber-600 text-white shadow-2xs'
                            : 'text-neutral-600 hover:text-neutral-900 hover:bg-neutral-200/70'
                        }`}
                        title="Set account status to Suspended"
                      >
                        <span className={`w-1.5 h-1.5 rounded-full ${currentStatus === 'suspended' ? 'bg-white' : 'bg-amber-500'}`} />
                        Suspended
                      </button>
                    </div>
                    <span className="text-[10px] text-neutral-400 block font-medium">Controls login &amp; auth access</span>
                  </div>
                ) : (
                  <div className="mt-0.5 flex flex-col gap-0.5">
                    <div className="flex items-center gap-1.5">
                      {isSuspended ? (
                        <>
                          <span className="inline-block w-2 h-2 rounded-full bg-amber-500" />
                          <span className="font-bold text-amber-800 text-xs">Suspended</span>
                        </>
                      ) : isInactive ? (
                        <>
                          <span className="inline-block w-2 h-2 rounded-full bg-red-500" />
                          <span className="font-bold text-red-700 text-xs">Inactive / Deactivated</span>
                        </>
                      ) : (
                        <>
                          <span className="inline-block w-2 h-2 rounded-full bg-emerald-500" />
                          <span className="font-bold text-emerald-700 text-xs">Active</span>
                        </>
                      )}
                      {user.mustChangePassword && (
                        <span className="px-1.5 py-0.2 bg-amber-100 text-amber-800 text-[10px] rounded font-medium">
                          Pwd Required
                        </span>
                      )}
                    </div>
                    {(isPrimaryAdmin || isTargetSuperAdmin) && (
                      <span className="text-[10px] text-neutral-400 font-medium">Protected Administrator Account</span>
                    )}
                    {isSelf && !isPrimaryAdmin && (
                      <span className="text-[10px] text-neutral-400 font-medium">Current Signed-in User</span>
                    )}
                  </div>
                )}
              </div>

              {/* Profile Completion Status */}
              <div>
                <span className="text-[10px] text-neutral-400 font-semibold uppercase block">Profile Completion Status</span>
                <div className="mt-0.5">
                  {complete ? (
                    <span className="inline-flex items-center gap-1 px-2 py-0.5 bg-blue-50 text-blue-700 border border-blue-200 rounded font-bold text-[11px]">
                      <CheckCircle2 className="w-3.5 h-3.5 text-blue-600" />
                      <span>Blue ✓ (Complete)</span>
                    </span>
                  ) : (
                    <span className="inline-flex items-center gap-1 px-2 py-0.5 bg-red-50 text-red-700 border border-red-200 rounded font-bold text-[11px]">
                      <XCircle className="w-3.5 h-3.5 text-red-600" />
                      <span>Red ✕ (Incomplete)</span>
                    </span>
                  )}
                </div>
              </div>
            </div>
          </div>

          {/* SECTION 2: PERSONAL INFORMATION */}
          <div className="bg-white rounded-xl border border-neutral-200 p-4 shadow-2xs">
            <div className="flex items-center gap-2 pb-3 border-b border-neutral-150 mb-4">
              <IdCard className="w-4 h-4 text-orange-600" />
              <h4 className="text-xs font-bold text-neutral-900 uppercase tracking-wider">
                Personal Information
              </h4>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4">
              {/* Date of Birth */}
              <div>
                <span className="text-[10px] text-neutral-400 font-semibold uppercase block">Date of Birth</span>
                <p className="text-neutral-800 text-xs mt-0.5">
                  {formatDate(user.dateOfBirth) || <span className="text-neutral-400 italic">Incomplete / Empty</span>}
                </p>
              </div>

              {/* Gender */}
              <div>
                <span className="text-[10px] text-neutral-400 font-semibold uppercase block">Gender</span>
                <p className="text-neutral-800 text-xs mt-0.5 capitalize">
                  {user.gender && user.gender.trim() ? user.gender : <span className="text-neutral-400 italic">Incomplete / Empty</span>}
                </p>
              </div>

              {/* National ID / Tazkira */}
              <div>
                <span className="text-[10px] text-neutral-400 font-semibold uppercase block">National ID / Identification Number</span>
                <p className="font-mono text-neutral-800 text-xs mt-0.5">
                  {user.nationalId && user.nationalId.trim() ? user.nationalId : <span className="text-neutral-400 italic">Incomplete / Empty</span>}
                </p>
              </div>

              {/* Residential / Office Address */}
              <div>
                <span className="text-[10px] text-neutral-400 font-semibold uppercase block">Address</span>
                <p className="text-neutral-800 text-xs mt-0.5">
                  {user.address && user.address.trim() ? user.address : <span className="text-neutral-400 italic">Incomplete / Empty</span>}
                </p>
              </div>
            </div>
          </div>

          {/* SECTION 3: EMERGENCY CONTACT */}
          <div className="bg-white rounded-xl border border-neutral-200 p-4 shadow-2xs">
            <div className="flex items-center gap-2 pb-3 border-b border-neutral-150 mb-4">
              <Phone className="w-4 h-4 text-orange-600" />
              <h4 className="text-xs font-bold text-neutral-900 uppercase tracking-wider">
                Emergency Contact
              </h4>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {/* Emergency Contact Name */}
              <div>
                <span className="text-[10px] text-neutral-400 font-semibold uppercase block">Emergency Contact Name</span>
                <p className="text-neutral-800 text-xs mt-0.5 font-medium">
                  {user.emergencyContactName && user.emergencyContactName.trim() ? (
                    user.emergencyContactName
                  ) : (
                    <span className="text-neutral-400 italic">Incomplete / Empty</span>
                  )}
                </p>
              </div>

              {/* Emergency Contact Phone */}
              <div>
                <span className="text-[10px] text-neutral-400 font-semibold uppercase block">Emergency Contact Phone</span>
                <p className="font-mono text-neutral-800 text-xs mt-0.5">
                  {user.emergencyContactPhone && user.emergencyContactPhone.trim() ? (
                    user.emergencyContactPhone
                  ) : (
                    <span className="text-neutral-400 italic">Incomplete / Empty</span>
                  )}
                </p>
              </div>
            </div>
          </div>

          {/* SECTION 4: EMPLOYMENT INFORMATION */}
          <div className="bg-white rounded-xl border border-neutral-200 p-4 shadow-2xs">
            <div className="flex items-center gap-2 pb-3 border-b border-neutral-150 mb-4">
              <Briefcase className="w-4 h-4 text-orange-600" />
              <h4 className="text-xs font-bold text-neutral-900 uppercase tracking-wider">
                Employment Information
              </h4>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
              {/* Job Title / Position */}
              <div>
                <span className="text-[10px] text-neutral-400 font-semibold uppercase block">Job Title / Position</span>
                <p className="font-semibold text-neutral-800 text-xs mt-0.5">
                  {user.jobTitle && user.jobTitle.trim() ? user.jobTitle : <span className="text-neutral-400 italic">Incomplete / Empty</span>}
                </p>
              </div>

              {/* Department */}
              <div>
                <span className="text-[10px] text-neutral-400 font-semibold uppercase block">Department</span>
                <p className="text-neutral-800 text-xs mt-0.5">
                  {user.department && user.department.trim() ? user.department : <span className="text-neutral-400 italic">Incomplete / Empty</span>}
                </p>
              </div>

              {/* Role */}
              <div>
                <span className="text-[10px] text-neutral-400 font-semibold uppercase block">Role</span>
                <p className="font-semibold text-neutral-900 text-xs mt-0.5 capitalize">
                  {user.role?.replace('_', ' ') || '—'}
                </p>
              </div>

              {/* Employment Start Date */}
              <div>
                <span className="text-[10px] text-neutral-400 font-semibold uppercase block">Employment Start Date</span>
                <p className="text-neutral-800 text-xs mt-0.5">
                  {formatDate(user.employmentStartDate) || <span className="text-neutral-400 italic">Incomplete / Empty</span>}
                </p>
              </div>

              {/* Employment Status */}
              <div>
                <span className="text-[10px] text-neutral-400 font-semibold uppercase block">Employment Status</span>
                <p className="text-neutral-800 text-xs mt-0.5 capitalize">
                  {user.employmentStatus && user.employmentStatus.trim() ? (
                    user.employmentStatus.replace('_', ' ')
                  ) : (
                    <span className="text-neutral-400 italic">Incomplete / Empty</span>
                  )}
                </p>
              </div>

              {/* Employee Internal Code */}
              {user.employeeCode && (
                <div>
                  <span className="text-[10px] text-neutral-400 font-semibold uppercase block">Employee Internal Code</span>
                  <p className="font-mono text-neutral-800 text-xs mt-0.5">{user.employeeCode}</p>
                </div>
              )}
            </div>
          </div>

          {/* SECTION 5: ADDITIONAL INFORMATION */}
          <div className="bg-white rounded-xl border border-neutral-200 p-4 shadow-2xs">
            <div className="flex items-center gap-2 pb-3 border-b border-neutral-150 mb-4">
              <Clock className="w-4 h-4 text-orange-600" />
              <h4 className="text-xs font-bold text-neutral-900 uppercase tracking-wider">
                Additional Information
              </h4>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
              {/* Notes */}
              <div className="sm:col-span-2 md:col-span-3">
                <span className="text-[10px] text-neutral-400 font-semibold uppercase block">Notes</span>
                <p className="text-neutral-800 text-xs mt-0.5 whitespace-pre-wrap leading-relaxed">
                  {user.notes && user.notes.trim() ? user.notes : <span className="text-neutral-400 italic">Incomplete / Empty</span>}
                </p>
              </div>

              {/* Created At */}
              <div>
                <span className="text-[10px] text-neutral-400 font-semibold uppercase block">Created At</span>
                <p className="font-mono text-neutral-600 text-xs mt-0.5">
                  {formatDateTime(user.createdAt) || '—'}
                </p>
              </div>

              {/* Updated At */}
              <div>
                <span className="text-[10px] text-neutral-400 font-semibold uppercase block">Updated At</span>
                <p className="font-mono text-neutral-600 text-xs mt-0.5">
                  {formatDateTime(user.updatedAt) || <span className="text-neutral-400 italic">Incomplete / Empty</span>}
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Modal Footer */}
        <div className="bg-neutral-50 px-5 py-3.5 border-t border-neutral-200 flex items-center justify-between flex-wrap gap-2">
          <div className="text-[11px] text-neutral-500 font-mono">
            Immutable User ID: <span className="font-bold text-orange-600">{officialId}</span>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 bg-neutral-200 hover:bg-neutral-300 text-neutral-800 text-xs font-bold rounded-xl transition cursor-pointer"
          >
            Close Details
          </button>
        </div>
      </div>

      {/* ================= PASSWORD RESET DIALOG ================= */}
      {showPasswordResetDialog && (
        <div className="fixed inset-0 z-60 bg-black/70 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="w-full max-w-md bg-white rounded-2xl shadow-2xl border border-neutral-200 p-5 relative">
            <div className="flex items-center justify-between border-b border-neutral-150 pb-3 mb-4">
              <div className="flex items-center gap-2">
                <div className="p-2 bg-amber-100 text-amber-800 rounded-xl">
                  <KeyRound className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-sm font-bold text-neutral-900">
                    Reset User Password
                  </h3>
                  <p className="text-[11px] text-neutral-500 font-mono">
                    {officialId} • {user.name}
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setShowPasswordResetDialog(false)}
                className="p-1 text-neutral-400 hover:text-neutral-600 rounded-lg hover:bg-neutral-100 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {resetResult ? (
              <div className="space-y-3">
                <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-xl text-xs text-emerald-800">
                  <div className="flex items-center gap-1.5 font-bold mb-1">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                    <span>Password Reset Successfully</span>
                  </div>
                  <p className="text-[11px]">
                    The temporary password for <span className="font-bold">{user.name}</span> has been updated. The user will be required to change this password on their next login.
                  </p>
                </div>

                <div className="p-3 bg-neutral-900 text-white rounded-xl space-y-1">
                  <span className="text-[10px] text-neutral-400 uppercase font-mono block">Temporary Password:</span>
                  <p className="font-mono text-sm font-bold text-orange-400 tracking-wider">
                    {resetResult.temporaryPassword}
                  </p>
                </div>

                <div className="pt-2 flex justify-end">
                  <button
                    type="button"
                    onClick={() => setShowPasswordResetDialog(false)}
                    className="px-4 py-2 bg-[#2563EB] hover:bg-[#1D4ED8] active:bg-[#1E40AF] text-white text-xs font-bold rounded-xl transition cursor-pointer shadow-xs focus:outline-none focus-visible:ring-2 focus-visible:ring-[#2563EB]"
                  >
                    Done
                  </button>
                </div>
              </div>
            ) : (
              <div className="space-y-4">
                <p className="text-xs text-neutral-600 leading-relaxed">
                  Resetting the password will generate a new cryptographic credential for{' '}
                  <span className="font-bold text-neutral-900">{user.name}</span>. The account will be flagged with{' '}
                  <span className="font-semibold text-amber-700">Mandatory Password Change</span> on their next sign in.
                </p>

                <div>
                  <label className="block text-xs font-semibold text-neutral-700 mb-1">
                    New Temporary Password (Required)
                  </label>
                  <input
                    type="password"
                    value={customPassword}
                    onChange={(e) => setCustomPassword(e.target.value)}
                    placeholder="Enter secure temporary password (min 6 characters)..."
                    className="w-full px-3 py-2 text-xs bg-neutral-50 border border-neutral-300 rounded-xl focus:outline-none focus:bg-white focus:ring-1 focus:ring-orange-500 font-mono"
                  />
                  <span className="text-[10px] text-neutral-400 mt-1 block">
                    Must be at least 6 characters. Mandatory password change is enforced on user's first login.
                  </span>
                </div>

                {resetError && (
                  <div className="p-2.5 bg-red-50 text-red-800 border border-red-200 rounded-lg text-xs flex items-center gap-1.5">
                    <AlertCircle className="w-4 h-4 text-red-600 shrink-0" />
                    <span>{resetError}</span>
                  </div>
                )}

                <div className="pt-2 border-t border-neutral-150 flex items-center justify-end gap-2">
                  <button
                    type="button"
                    onClick={() => setShowPasswordResetDialog(false)}
                    disabled={resettingPassword}
                    className="px-3.5 py-2 border border-neutral-300 text-neutral-700 text-xs font-semibold rounded-xl hover:bg-neutral-100 transition cursor-pointer"
                  >
                    Cancel
                  </button>

                  <button
                    type="button"
                    onClick={handleConfirmPasswordReset}
                    disabled={resettingPassword}
                    className="inline-flex items-center gap-1.5 px-4 py-2 bg-[#2563EB] hover:bg-[#1D4ED8] active:bg-[#1E40AF] text-white text-xs font-bold rounded-xl shadow-xs transition cursor-pointer active:scale-98 disabled:opacity-50 focus:outline-none focus-visible:ring-2 focus-visible:ring-[#2563EB]"
                  >
                    {resettingPassword ? (
                      <>
                        <Loader2 className="w-3.5 h-3.5 animate-spin" />
                        <span>Resetting...</span>
                      </>
                    ) : (
                      <>
                        <KeyRound className="w-3.5 h-3.5" />
                        <span>Reset Password</span>
                      </>
                    )}
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
