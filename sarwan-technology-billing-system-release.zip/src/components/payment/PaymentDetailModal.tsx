import React, { useState, useRef, useEffect } from 'react';
import { Payment, Invoice, BusinessSettings } from '../../types';
import { formatAFN, formatDate } from '../../utils/format';
import { downloadElementAsPdf } from '../../utils/pdf';
import { printPaymentReceiptDocument } from './PaymentReceiptModal';
import { checkPaymentReversalEligibility } from '../../utils/paymentValidation';
import {
  X,
  Printer,
  Download,
  Loader2,
  FileText,
  User,
  Calendar,
  Clock,
  DollarSign,
  Copy,
  Check,
  ShieldCheck,
  Building,
  CreditCard,
  AlertTriangle,
  ExternalLink,
  Phone,
  Mail,
  MapPin,
  Receipt,
  Info,
} from 'lucide-react';

interface PaymentDetailModalProps {
  payment: Payment | null;
  invoice?: Invoice | null;
  settings: BusinessSettings;
  isOpen: boolean;
  onClose: () => void;
  onSelectInvoice?: (invoice: Invoice) => void;
  onViewReceipt?: (payment: Payment) => void;
  onReversePayment?: (payment: Payment) => void;
}

export const PaymentDetailModal: React.FC<PaymentDetailModalProps> = ({
  payment,
  invoice,
  settings,
  isOpen,
  onClose,
  onSelectInvoice,
  onViewReceipt,
  onReversePayment,
}) => {
  const [copiedId, setCopiedId] = useState<boolean>(false);
  const [isExportingPdf, setIsExportingPdf] = useState<boolean>(false);
  const [isPrintingReceipt, setIsPrintingReceipt] = useState<boolean>(false);

  // Prevent background page from scrolling horizontally or vertically when modal is open
  useEffect(() => {
    if (!isOpen) return;
    const originalOverflow = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    return () => {
      document.body.style.overflow = originalOverflow;
    };
  }, [isOpen]);

  // Handle ESC key to dismiss modal
  useEffect(() => {
    if (!isOpen) return;
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        onClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
    };
  }, [isOpen, onClose]);

  if (!isOpen || !payment) return null;

  const isReversed = Boolean(
    payment.isVoid === true ||
    (payment as any).status === 'Void' ||
    (payment as any).status === 'Cancelled'
  );

  const reversalEligibility = checkPaymentReversalEligibility(payment);
  const canReverse = !isReversed && reversalEligibility.isEligible;
  const reverseTooltip = !isReversed && (reversalEligibility.hasInvalidTimestamp || reversalEligibility.isExpired)
    ? 'Reverse window expired (48 hours).'
    : isReversed
    ? 'Payment has already been reversed.'
    : 'Reverse this payment (Super Admin Only)';

  const handleCopyId = () => {
    if (!payment.id) return;
    navigator.clipboard?.writeText(payment.id);
    setCopiedId(true);
    setTimeout(() => setCopiedId(false), 2000);
  };

  // Connected Invoice calculations
  const invoiceTotal = invoice
    ? (typeof invoice.totalAmount === 'number' ? invoice.totalAmount : parseFloat(String(invoice.totalAmount ?? 0)) || 0)
    : 0;
  const invoiceTotalPaid = invoice
    ? (typeof invoice.totalPaid === 'number' ? invoice.totalPaid : parseFloat(String(invoice.totalPaid ?? payment.amount)) || payment.amount)
    : payment.amount;
  const invoiceRemaining = invoice
    ? (typeof invoice.remaining === 'number'
        ? invoice.remaining
        : Math.max(0, invoiceTotal - invoiceTotalPaid))
    : 0;
  const invoiceStatus = invoice?.status || (invoiceRemaining <= 0 ? 'Paid' : 'Partially Paid');

  // Customer Information (from invoice snapshot or payment record)
  const customerName = payment.customerName || invoice?.customerSnapshot?.name || (invoice as any)?.customerName || 'Customer';
  const customerPhone = invoice?.customerSnapshot?.phone || (payment as any).customerPhone || null;
  const customerEmail = invoice?.customerSnapshot?.email || null;
  const customerAddress = invoice?.customerSnapshot?.address || null;
  const customerCompany = invoice?.customerSnapshot?.companyName || null;
  const customerId = payment.customerId || invoice?.customerId || null;

  // Date and Time formatting
  const formattedDate = formatDate(payment.date);
  const formattedTime = payment.time
    ? payment.time
    : payment.createdAt
    ? new Date(payment.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })
    : null;
  const formattedDateTime = formattedTime ? `${formattedDate} at ${formattedTime}` : formattedDate;

  // Created At formatting
  const formattedCreatedAt = payment.createdAt
    ? new Date(payment.createdAt).toLocaleString([], {
        year: 'numeric',
        month: 'short',
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit',
      })
    : formattedDate;

  // Download Receipt / PDF (delegates to canonical print authority; downloadElementAsPdf fallback)
  const handleDownloadReceiptPdf = async () => {
    setIsExportingPdf(true);
    try {
      await handlePrintReceipt();
    } catch (err) {
      console.error('Failed to export payment receipt PDF:', err);
    } finally {
      setIsExportingPdf(false);
    }
  };

  // Print Receipt using canonical PaymentReceiptDocument
  const handlePrintReceipt = async () => {
    if (isPrintingReceipt) return;
    setIsPrintingReceipt(true);
    try {
      if (onViewReceipt) {
        onViewReceipt(payment);
      }
      await printPaymentReceiptDocument(payment, invoice, settings);
    } catch (err) {
      console.error('Failed to print receipt:', err);
    } finally {
      setIsPrintingReceipt(false);
    }
  };

  return (
    <div
      id="payment-detail-modal-overlay"
      className="fixed inset-0 z-50 flex items-center justify-center p-2.5 sm:p-4 md:p-6 bg-black/75 backdrop-blur-xs overflow-y-auto"
      onClick={onClose}
    >
      <div
        id="payment-detail-modal"
        role="dialog"
        aria-modal="true"
        aria-labelledby="payment-detail-title"
        className="bg-white rounded-xl sm:rounded-2xl shadow-2xl w-full max-w-2xl max-h-[96vh] sm:max-h-[90vh] flex flex-col overflow-hidden border border-neutral-200 text-neutral-900 my-auto"
        onClick={(e) => e.stopPropagation()}
      >
        {/* 1. Details Header */}
        <div
          id="payment-detail-header"
          className="px-3.5 sm:px-6 py-3 sm:py-4 border-b border-neutral-200 bg-neutral-900 text-white shrink-0"
        >
          <div className="flex items-start justify-between gap-2.5 sm:gap-3">
            <div className="flex items-start sm:items-center gap-2.5 sm:gap-3 min-w-0 flex-1">
              <div className="p-2 rounded-lg bg-neutral-800 border border-neutral-700 text-orange-400 shrink-0 mt-0.5 sm:mt-0">
                <Receipt className="w-4 h-4 sm:w-5 sm:h-5" />
              </div>

              <div className="min-w-0 flex-1">
                <div className="flex items-center gap-2 flex-wrap">
                  <h2
                    id="payment-detail-title"
                    className="text-base sm:text-lg font-bold tracking-tight text-white"
                  >
                    Payment Details
                  </h2>

                  {/* Payment Status Badge */}
                  {isReversed ? (
                    <span
                      id="payment-detail-status-badge"
                      className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-rose-950 text-rose-300 border border-rose-700 shrink-0"
                    >
                      <AlertTriangle className="w-3 h-3 text-rose-400" />
                      <span>Reversed / Void</span>
                    </span>
                  ) : (
                    <span
                      id="payment-detail-status-badge"
                      className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-emerald-950 text-emerald-300 border border-emerald-700 shrink-0"
                    >
                      <ShieldCheck className="w-3 h-3 text-emerald-400" />
                      <span>Completed</span>
                    </span>
                  )}
                </div>

                {/* Payment ID & Related Invoice Number in Header - Stacks gracefully on mobile */}
                <div className="flex flex-col xs:flex-row xs:items-center gap-1 xs:gap-3 text-xs text-neutral-300 font-mono mt-1.5 min-w-0">
                  <div className="flex items-center gap-1 min-w-0">
                    <span className="text-neutral-400 font-sans text-[11px] shrink-0">ID:</span>
                    <span
                      id="payment-detail-header-id"
                      className="font-bold text-white truncate max-w-[140px] xs:max-w-[200px] sm:max-w-none"
                      title={payment.id}
                    >
                      #{payment.id}
                    </span>
                    <button
                      type="button"
                      onClick={handleCopyId}
                      className="hover:text-white transition p-0.5 text-neutral-400 cursor-pointer shrink-0"
                      title="Copy Payment ID"
                      aria-label="Copy Payment ID"
                    >
                      {copiedId ? (
                        <Check className="w-3 h-3 text-emerald-400" />
                      ) : (
                        <Copy className="w-3 h-3" />
                      )}
                    </button>
                  </div>

                  <span className="text-neutral-600 hidden xs:inline" aria-hidden="true">•</span>

                  <div className="flex items-center gap-1 min-w-0">
                    <span className="text-neutral-400 font-sans text-[11px] shrink-0">Invoice:</span>
                    <span
                      id="payment-detail-header-invoice"
                      className="font-bold text-orange-400 truncate max-w-[140px] xs:max-w-[200px] sm:max-w-none"
                      title={payment.billNumber || invoice?.billNumber || '—'}
                    >
                      {payment.billNumber || invoice?.billNumber || '—'}
                    </span>
                  </div>
                </div>
              </div>
            </div>

            {/* Close button */}
            <button
              type="button"
              id="btn-close-payment-detail"
              onClick={onClose}
              className="p-1.5 sm:p-2 text-neutral-400 hover:text-white hover:bg-neutral-800 rounded-lg transition cursor-pointer shrink-0 ml-1"
              title="Close details"
              aria-label="Close details"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Modal Scrollable Body - Vertically contained, smooth scroll, zero horizontal overflow */}
        <div className="flex-1 min-h-0 overflow-y-auto p-3.5 sm:p-6 space-y-3.5 sm:space-y-4 text-xs overscroll-contain">
          {/* 2. Payment Summary Section */}
          <div
            id="payment-summary-section"
            className="p-3.5 sm:p-5 rounded-xl bg-neutral-50 border border-neutral-200"
          >
            <span className="text-[11px] font-bold uppercase tracking-wider text-neutral-500 block mb-3">
              Payment Summary
            </span>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
              {/* Amount Paid - Always fully visible, never truncated */}
              <div className="min-w-0">
                <span className="text-[11px] font-semibold text-neutral-500 block">
                  Amount Paid
                </span>
                <p
                  id="payment-summary-amount"
                  className="text-xl sm:text-2xl font-black font-mono text-emerald-700 tracking-tight mt-0.5 break-words"
                >
                  +{formatAFN(payment.amount)}
                </p>
              </div>

              {/* Payment Method */}
              <div className="min-w-0">
                <span className="text-[11px] font-semibold text-neutral-500 block">
                  Payment Method
                </span>
                <div className="mt-1">
                  <span
                    id="payment-summary-method"
                    className="inline-flex items-center gap-1 px-2.5 py-1 rounded-md text-xs font-bold bg-white text-neutral-800 border border-neutral-300 shadow-2xs"
                  >
                    <CreditCard className="w-3.5 h-3.5 text-neutral-500 shrink-0" />
                    <span>{payment.method ? (payment.method === 'CASH' ? 'Cash' : payment.method) : 'Cash'}</span>
                  </span>
                </div>
              </div>

              {/* Payment Date & Time */}
              <div className="min-w-0">
                <span className="text-[11px] font-semibold text-neutral-500 block">
                  Payment Date & Time
                </span>
                <p
                  id="payment-summary-datetime"
                  className="font-mono font-semibold text-neutral-900 mt-1 break-words"
                >
                  {formattedDateTime}
                </p>
              </div>

              {/* Collector */}
              <div className="min-w-0">
                <span className="text-[11px] font-semibold text-neutral-500 block">
                  Collector
                </span>
                <p
                  id="payment-summary-collector"
                  className="font-semibold text-neutral-900 mt-1 break-words"
                >
                  {payment.recordedByName || 'Super Admin'}
                </p>
              </div>
            </div>
          </div>

          {/* 3. Customer Information Section */}
          <div
            id="payment-customer-section"
            className="p-3.5 sm:p-5 rounded-xl bg-white border border-neutral-200 space-y-3"
          >
            <div className="flex items-center gap-2 pb-2 border-b border-neutral-100">
              <User className="w-4 h-4 text-orange-600 shrink-0" />
              <h3 className="text-xs font-bold uppercase tracking-wider text-neutral-700">
                Customer Information
              </h3>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 sm:gap-3.5 pt-1">
              {/* Customer Name */}
              <div className="min-w-0">
                <span className="text-[11px] font-medium text-neutral-500 block">
                  Customer Name
                </span>
                <p
                  id="payment-customer-name"
                  className="font-bold text-neutral-900 text-sm mt-0.5 break-words"
                >
                  {customerName}
                </p>
              </div>

              {/* Phone / Contact */}
              <div className="min-w-0">
                <span className="text-[11px] font-medium text-neutral-500 block">
                  Phone / Contact
                </span>
                <div id="payment-customer-phone" className="mt-0.5 flex items-center gap-1.5 font-mono text-neutral-800 break-all">
                  {customerPhone ? (
                    <>
                      <Phone className="w-3.5 h-3.5 text-neutral-400 shrink-0" />
                      <span>{customerPhone}</span>
                    </>
                  ) : (
                    <span className="text-neutral-400 italic">Not provided</span>
                  )}
                </div>
              </div>

              {/* Additional Customer Attributes (if available) */}
              {customerEmail && (
                <div className="min-w-0">
                  <span className="text-[11px] font-medium text-neutral-500 block">
                    Email
                  </span>
                  <div className="mt-0.5 flex items-center gap-1.5 text-neutral-800 break-all">
                    <Mail className="w-3.5 h-3.5 text-neutral-400 shrink-0" />
                    <span>{customerEmail}</span>
                  </div>
                </div>
              )}

              {customerCompany && (
                <div className="min-w-0">
                  <span className="text-[11px] font-medium text-neutral-500 block">
                    Company
                  </span>
                  <div className="mt-0.5 flex items-center gap-1.5 text-neutral-800 break-words">
                    <Building className="w-3.5 h-3.5 text-neutral-400 shrink-0" />
                    <span>{customerCompany}</span>
                  </div>
                </div>
              )}

              {customerAddress && (
                <div className="col-span-1 sm:col-span-2 min-w-0">
                  <span className="text-[11px] font-medium text-neutral-500 block">
                    Address
                  </span>
                  <div className="mt-0.5 flex items-start gap-1.5 text-neutral-800 break-words">
                    <MapPin className="w-3.5 h-3.5 text-neutral-400 shrink-0 mt-0.5" />
                    <span>{customerAddress}</span>
                  </div>
                </div>
              )}

              {customerId && (
                <div className="col-span-1 sm:col-span-2 min-w-0">
                  <span className="text-[11px] font-medium text-neutral-500 block">
                    Customer Account ID
                  </span>
                  <span className="font-mono text-[11px] text-neutral-600 break-all">
                    {customerId}
                  </span>
                </div>
              )}
            </div>
          </div>

          {/* 4. Invoice Information Section */}
          <div
            id="payment-invoice-section"
            className="p-3.5 sm:p-5 rounded-xl bg-white border border-neutral-200 space-y-3"
          >
            <div className="flex flex-col xs:flex-row xs:items-center justify-between pb-2 border-b border-neutral-100 gap-2">
              <div className="flex items-center gap-2 min-w-0">
                <FileText className="w-4 h-4 text-orange-600 shrink-0" />
                <h3 className="text-xs font-bold uppercase tracking-wider text-neutral-700 truncate">
                  Invoice Information
                </h3>
              </div>

              {invoice && onSelectInvoice && (
                <button
                  type="button"
                  id="btn-view-connected-invoice"
                  onClick={() => {
                    onClose();
                    onSelectInvoice(invoice);
                  }}
                  className="text-xs font-semibold text-orange-600 hover:text-orange-700 inline-flex items-center gap-1 cursor-pointer shrink-0"
                >
                  <span>View Complete Invoice</span>
                  <ExternalLink className="w-3 h-3 shrink-0" />
                </button>
              )}
            </div>

            {invoice ? (
              <div className="space-y-3 pt-1">
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5 sm:gap-3">
                  {/* Invoice Number */}
                  <div className="min-w-0">
                    <span className="text-[11px] font-medium text-neutral-500 block">
                      Invoice Number
                    </span>
                    <span
                      id="payment-invoice-number"
                      className="font-mono font-bold text-orange-600 text-sm mt-0.5 block break-all"
                    >
                      {invoice.billNumber}
                    </span>
                  </div>

                  {/* Invoice Status */}
                  <div className="min-w-0">
                    <span className="text-[11px] font-medium text-neutral-500 block">
                      Invoice Status
                    </span>
                    <div className="mt-0.5">
                      <span
                        id="payment-invoice-status"
                        className={`inline-flex items-center px-2 py-0.5 rounded text-[11px] font-bold border ${
                          invoiceStatus === 'Paid'
                            ? 'bg-emerald-50 text-emerald-700 border-emerald-200'
                            : invoiceStatus === 'Partially Paid'
                            ? 'bg-amber-50 text-amber-700 border-amber-200'
                            : invoiceStatus === 'Void'
                            ? 'bg-rose-50 text-rose-700 border-rose-200'
                            : 'bg-neutral-100 text-neutral-700 border-neutral-200'
                        }`}
                      >
                        {invoiceStatus}
                      </span>
                    </div>
                  </div>

                  {/* Date of Invoice */}
                  <div className="min-w-0">
                    <span className="text-[11px] font-medium text-neutral-500 block">
                      Invoice Date
                    </span>
                    <span className="font-mono text-neutral-800 text-xs mt-0.5 block break-words">
                      {formatDate(invoice.date)}
                    </span>
                  </div>
                </div>

                {/* Financial Ledger Grid for Invoice - Stacks nicely on mobile, 3 columns on tablet/desktop */}
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 sm:gap-2.5 pt-1">
                  <div className="p-2.5 rounded-lg bg-neutral-50 border border-neutral-200 min-w-0">
                    <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wide block truncate">
                      Invoice Total
                    </span>
                    <span
                      id="payment-invoice-total"
                      className="font-mono font-bold text-neutral-900 text-sm mt-0.5 block break-words"
                    >
                      {formatAFN(invoiceTotal)}
                    </span>
                  </div>

                  <div className="p-2.5 rounded-lg bg-emerald-50/70 border border-emerald-200 min-w-0">
                    <span className="text-[10px] font-semibold text-emerald-700 uppercase tracking-wide block truncate">
                      Total Paid
                    </span>
                    <span
                      id="payment-invoice-paid"
                      className="font-mono font-bold text-emerald-800 text-sm mt-0.5 block break-words"
                    >
                      {formatAFN(invoiceTotalPaid)}
                    </span>
                  </div>

                  <div className="p-2.5 rounded-lg bg-amber-50/70 border border-amber-200 min-w-0">
                    <span className="text-[10px] font-semibold text-amber-700 uppercase tracking-wide block truncate">
                      Remaining Balance
                    </span>
                    <span
                      id="payment-invoice-remaining"
                      className="font-mono font-bold text-amber-800 text-sm mt-0.5 block break-words"
                    >
                      {formatAFN(invoiceRemaining)}
                    </span>
                  </div>
                </div>
              </div>
            ) : (
              <div
                id="payment-invoice-unavailable"
                className="p-3 bg-neutral-50 rounded-lg border border-neutral-200 text-neutral-500 flex items-center gap-2"
              >
                <Info className="w-4 h-4 text-neutral-400 shrink-0" />
                <span className="break-words">
                  No connected invoice record found in the database for bill number{' '}
                  <strong className="font-mono text-neutral-800">{payment.billNumber || 'N/A'}</strong>.
                </span>
              </div>
            )}
          </div>

          {/* 5. Payment Record Information Section */}
          <div
            id="payment-record-section"
            className="p-3.5 sm:p-5 rounded-xl bg-white border border-neutral-200 space-y-3"
          >
            <h3 className="text-xs font-bold uppercase tracking-wider text-neutral-700 pb-2 border-b border-neutral-100">
              Payment Record Information
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 sm:gap-3.5 pt-1">
              {/* Recorded By */}
              <div className="min-w-0">
                <span className="text-[11px] font-medium text-neutral-500 block">
                  Recorded By
                </span>
                <p
                  id="payment-record-by"
                  className="font-semibold text-neutral-900 mt-0.5 break-words"
                >
                  {payment.recordedByName || 'Super Admin'}
                  {payment.recordedBy && (
                    <span className="text-neutral-400 font-mono text-[10px] ml-1 break-all">
                      (#{payment.recordedBy})
                    </span>
                  )}
                </p>
              </div>

              {/* Created At */}
              <div className="min-w-0">
                <span className="text-[11px] font-medium text-neutral-500 block">
                  Created At
                </span>
                <p
                  id="payment-record-created-at"
                  className="font-mono text-neutral-900 mt-0.5 break-words"
                >
                  {formattedCreatedAt}
                </p>
              </div>

              {/* Notes */}
              <div className="col-span-1 sm:col-span-2 min-w-0">
                <span className="text-[11px] font-medium text-neutral-500 block">
                  Notes
                </span>
                <p
                  id="payment-record-notes"
                  className="mt-1 p-2.5 rounded-lg bg-neutral-50 border border-neutral-200 text-neutral-800 whitespace-pre-wrap font-sans text-xs break-words"
                >
                  {payment.note?.trim() || 'No notes provided'}
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* 6. Actions Footer - Responsive, stacks on very small screens, no overlap */}
        <div
          id="payment-detail-actions"
          className="px-3.5 sm:px-6 py-3 sm:py-4 border-t border-neutral-200 bg-neutral-50 flex flex-col xs:flex-row items-stretch xs:items-center justify-between gap-2.5 shrink-0"
        >
          {/* Print, Download, & Receipt Actions */}
          <div className="flex items-center gap-2 flex-1 xs:flex-initial flex-wrap xs:flex-nowrap">
            {/* View Receipt */}
            {onViewReceipt && (
              <button
                type="button"
                id="btn-open-payment-receipt"
                onClick={() => onViewReceipt(payment)}
                className="flex-1 xs:flex-initial px-3 sm:px-3.5 py-2 text-xs font-semibold bg-[#2563EB] hover:bg-[#1D4ED8] active:bg-[#1E40AF] text-white rounded-lg transition inline-flex items-center justify-center gap-1.5 cursor-pointer shadow-xs focus:outline-none focus-visible:ring-2 focus-visible:ring-[#2563EB]"
                title="View Receipt for this payment"
                aria-label="View Receipt"
              >
                <Receipt className="w-4 h-4 text-white shrink-0" />
                <span>Receipt</span>
              </button>
            )}

            {/* Print Receipt */}
            <button
              type="button"
              id="btn-print-payment-receipt"
              onClick={handlePrintReceipt}
              disabled={isPrintingReceipt}
              className="flex-1 xs:flex-initial px-3 sm:px-3.5 py-2 text-xs font-semibold bg-white hover:bg-neutral-100 text-neutral-800 rounded-lg border border-neutral-300 transition inline-flex items-center justify-center gap-1.5 cursor-pointer shadow-2xs active:scale-[0.98] disabled:opacity-60"
              title="Print Receipt for this payment"
              aria-label="Print Receipt"
            >
              {isPrintingReceipt ? (
                <Loader2 className="w-4 h-4 text-blue-600 animate-spin shrink-0" />
              ) : (
                <Printer className="w-4 h-4 text-neutral-600 shrink-0" />
              )}
              <span className="hidden sm:inline">
                {isPrintingReceipt ? 'Preparing...' : 'Print Receipt'}
              </span>
              <span className="sm:hidden">
                {isPrintingReceipt ? 'Print...' : 'Print'}
              </span>
            </button>

            {/* Download Receipt / PDF */}
            <button
              type="button"
              id="btn-download-payment-receipt"
              onClick={handleDownloadReceiptPdf}
              disabled={isExportingPdf}
              className="flex-1 xs:flex-initial px-3 sm:px-3.5 py-2 text-xs font-semibold bg-white hover:bg-neutral-100 text-neutral-800 rounded-lg border border-neutral-300 transition inline-flex items-center justify-center gap-1.5 cursor-pointer shadow-2xs active:scale-[0.98] disabled:opacity-50"
              title="Download PDF Receipt for this payment"
              aria-label="Download Receipt / PDF"
            >
              <Download className="w-4 h-4 text-blue-600 shrink-0" />
              <span className="hidden sm:inline">{isExportingPdf ? 'Exporting...' : 'Download Receipt / PDF'}</span>
              <span className="sm:hidden">{isExportingPdf ? 'PDF...' : 'PDF'}</span>
            </button>

            {/* Super Admin Payment Reversal Action */}
            {onReversePayment && (
              <button
                type="button"
                id="btn-reverse-payment-modal"
                onClick={() => {
                  if (canReverse && payment) {
                    onReversePayment(payment);
                  }
                }}
                disabled={!canReverse}
                className={`flex-1 xs:flex-initial px-3 sm:px-3.5 py-2 text-xs font-semibold rounded-lg border transition inline-flex items-center justify-center gap-1.5 shadow-2xs ${
                  canReverse
                    ? 'bg-rose-50 hover:bg-rose-100 text-rose-700 border-rose-200 cursor-pointer active:scale-[0.98]'
                    : 'bg-neutral-100 text-neutral-400 border-neutral-200 cursor-not-allowed opacity-60'
                }`}
                title={reverseTooltip}
                aria-label="Reverse Payment"
              >
                <AlertTriangle className={`w-4 h-4 shrink-0 ${canReverse ? 'text-rose-600' : 'text-neutral-400'}`} />
                <span className="hidden sm:inline">Reverse Payment</span>
                <span className="sm:hidden">Reverse</span>
              </button>
            )}
          </div>

          {/* Close */}
          <button
            type="button"
            id="btn-close-payment-detail-footer"
            onClick={onClose}
            className="w-full xs:w-auto px-5 py-2 text-xs font-semibold text-neutral-800 bg-neutral-100 hover:bg-neutral-200 active:bg-neutral-300 border border-neutral-300 rounded-lg transition shadow-2xs cursor-pointer active:scale-[0.98] text-center"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
