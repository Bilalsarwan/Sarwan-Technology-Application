import React, { useRef } from 'react';
import {
  DesignerElement,
  InvoiceDesignSettings,
  FontWeight,
  HeaderLayout,
  SignatureStyle,
  ShapeConfig,
  TableColumnConfig,
  DEFAULT_INVOICE_DESIGN,
  FooterElementId,
  normalizeFooterElementsOrder,
} from '../../types/invoiceDesign';
import {
  getElementVisibility,
  setElementVisibility,
} from '../../utils/canonicalVisibility';
import {
  X,
  Type,
  Palette,
  Image as ImageIcon,
  Building,
  FileText,
  Users,
  Table as TableIcon,
  CreditCard,
  Calculator,
  MessageSquare,
  PenTool,
  Upload,
  AlignLeft,
  AlignCenter,
  AlignRight,
  Bold,
  Italic,
  Underline,
  Underline as UnderlineIcon,
  Eye,
  EyeOff,
  ChevronRight,
  Sliders,
  GripVertical,
  RotateCcw,
  Lock,
  Unlock,
  ArrowUp,
  ArrowDown,
  ListOrdered,
} from 'lucide-react';

export const FONT_OPTIONS = [
  { value: 'Inter, system-ui, sans-serif', label: 'Inter (Clean Sans)' },
  { value: "'Roboto', sans-serif", label: 'Roboto' },
  { value: "'Poppins', sans-serif", label: 'Poppins' },
  { value: "'Outfit', sans-serif", label: 'Outfit' },
  { value: 'Arial, sans-serif', label: 'Arial' },
  { value: "'Helvetica Neue', Helvetica, sans-serif", label: 'Helvetica' },
  { value: "'Montserrat', sans-serif", label: 'Montserrat' },
  { value: "'Lato', sans-serif", label: 'Lato' },
  { value: "'Times New Roman', serif", label: 'Times New Roman' },
  { value: 'Georgia, serif', label: 'Georgia' },
  { value: "'Courier New', monospace", label: 'Courier New' },
  { value: '"Scheherazade New", "Amiri", "Noto Naskh Arabic", Arial, sans-serif', label: 'Amiri / Pashto / Arabic' },
];

export const FontFamilySelect: React.FC<{
  value?: string;
  onChange: (font: string) => void;
  label?: string;
}> = ({ value, onChange, label = 'Font Family' }) => (
  <div className="flex flex-col gap-1 min-w-[130px]">
    <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
      {label}
    </span>
    <select
      value={value || 'Inter, system-ui, sans-serif'}
      onChange={(e) => onChange(e.target.value)}
      className="px-2 py-1 text-xs border border-neutral-300 rounded font-medium focus:ring-1 focus:ring-blue-500 focus:border-blue-500 bg-white"
    >
      {FONT_OPTIONS.map((f) => (
        <option key={f.value} value={f.value}>
          {f.label}
        </option>
      ))}
    </select>
  </div>
);

export interface ContextualToolbarProps {
  selectedElement: DesignerElement;
  design: InvoiceDesignSettings;
  updateDesign: (updater: (prev: InvoiceDesignSettings) => InvoiceDesignSettings) => void;
  onClose: () => void;
  placement?: 'right' | 'left' | 'top' | 'bottom' | 'sidebar';
  onDragStart?: (e: React.MouseEvent) => void;
  isSidebar?: boolean;
}

export const ELEMENT_LABELS: Record<DesignerElement, { label: string; icon: React.ReactNode; tab?: string }> = {
  companyEnglishName: { label: 'Company English Name', icon: <Building className="w-4 h-4 text-blue-600" />, tab: 'typography' },
  companyPashtoName: { label: 'Company Pashto Name', icon: <Building className="w-4 h-4 text-blue-600" />, tab: 'typography' },
  companySlogan: { label: 'Company Slogan', icon: <Type className="w-4 h-4 text-blue-600" />, tab: 'typography' },
  logoLeft: { label: 'Company Logo (Left)', icon: <ImageIcon className="w-4 h-4 text-blue-600" />, tab: 'insert' },
  logoRight: { label: 'Partner Logo (Right)', icon: <ImageIcon className="w-4 h-4 text-blue-600" />, tab: 'insert' },
  shapeTopLeft: { label: 'Top-Left Decorative Shape', icon: <PenTool className="w-4 h-4 text-blue-600" />, tab: 'design' },
  shapeTopRight: { label: 'Top-Right Decorative Shape', icon: <PenTool className="w-4 h-4 text-blue-600" />, tab: 'design' },
  shapeGoldAccent: { label: 'Gold Accent Decorative Shape', icon: <Palette className="w-4 h-4 text-amber-500" />, tab: 'colors' },
  shapeBottomLeft: { label: 'Footer Bottom-Left Shape', icon: <PenTool className="w-4 h-4 text-blue-600" />, tab: 'design' },
  shapeBottomRight: { label: 'Footer Bottom-Right Shape', icon: <PenTool className="w-4 h-4 text-blue-600" />, tab: 'design' },
  invoiceTitle: { label: 'Invoice Title', icon: <FileText className="w-4 h-4 text-blue-600" />, tab: 'typography' },
  invoiceMeta: { label: 'Invoice Metadata Box', icon: <FileText className="w-4 h-4 text-blue-600" />, tab: 'design' },
  billNumber: { label: 'Bill Number', icon: <FileText className="w-4 h-4 text-blue-600" />, tab: 'typography' },
  invoiceDate: { label: 'Invoice Date', icon: <FileText className="w-4 h-4 text-blue-600" />, tab: 'typography' },
  dueDate: { label: 'Due Date', icon: <FileText className="w-4 h-4 text-blue-600" />, tab: 'typography' },
  collector: { label: 'Collector Field', icon: <Users className="w-4 h-4 text-blue-600" />, tab: 'design' },
  customerInfo: { label: 'Customer Details Card', icon: <Users className="w-4 h-4 text-blue-600" />, tab: 'design' },
  customerName: { label: 'Customer Name', icon: <Users className="w-4 h-4 text-blue-600" />, tab: 'typography' },
  customerPhone: { label: 'Customer Phone', icon: <Users className="w-4 h-4 text-blue-600" />, tab: 'typography' },
  customerAddress: { label: 'Customer Address', icon: <Users className="w-4 h-4 text-blue-600" />, tab: 'typography' },
  customerEmail: { label: 'Customer Email', icon: <Users className="w-4 h-4 text-blue-600" />, tab: 'typography' },
  customerCompany: { label: 'Customer Company', icon: <Building className="w-4 h-4 text-blue-600" />, tab: 'typography' },
  customerId: { label: 'Customer ID', icon: <FileText className="w-4 h-4 text-blue-600" />, tab: 'typography' },
  itemsTable: { label: 'Items Table', icon: <TableIcon className="w-4 h-4 text-blue-600" />, tab: 'layout' },
  tableHeader: { label: 'Table Header', icon: <TableIcon className="w-4 h-4 text-blue-600" />, tab: 'layout' },
  tableBody: { label: 'Table Body', icon: <TableIcon className="w-4 h-4 text-blue-600" />, tab: 'typography' },
  tableColumnSerial: { label: 'Column: Serial (#)', icon: <TableIcon className="w-4 h-4 text-blue-600" />, tab: 'layout' },
  tableColumnDescription: { label: 'Column: Description', icon: <TableIcon className="w-4 h-4 text-blue-600" />, tab: 'layout' },
  tableColumnQuantity: { label: 'Column: Quantity', icon: <TableIcon className="w-4 h-4 text-blue-600" />, tab: 'layout' },
  tableColumnUnit: { label: 'Column: Unit', icon: <TableIcon className="w-4 h-4 text-blue-600" />, tab: 'layout' },
  tableColumnUnitPrice: { label: 'Column: Unit Price', icon: <TableIcon className="w-4 h-4 text-blue-600" />, tab: 'layout' },
  tableColumnDiscount: { label: 'Column: Discount', icon: <TableIcon className="w-4 h-4 text-blue-600" />, tab: 'layout' },
  tableColumnTax: { label: 'Column: Tax', icon: <TableIcon className="w-4 h-4 text-blue-600" />, tab: 'layout' },
  tableColumnTotal: { label: 'Column: Total Amount', icon: <TableIcon className="w-4 h-4 text-blue-600" />, tab: 'layout' },
  paymentInfo: { label: 'Payment Information Card', icon: <CreditCard className="w-4 h-4 text-blue-600" />, tab: 'design' },
  paymentMethod: { label: 'Payment Method', icon: <CreditCard className="w-4 h-4 text-blue-600" />, tab: 'typography' },
  paymentStatus: { label: 'Payment Status', icon: <CreditCard className="w-4 h-4 text-blue-600" />, tab: 'typography' },
  paidAmount: { label: 'Paid Amount', icon: <CreditCard className="w-4 h-4 text-blue-600" />, tab: 'typography' },
  remainingAmount: { label: 'Remaining Balance', icon: <CreditCard className="w-4 h-4 text-blue-600" />, tab: 'typography' },
  totals: { label: 'Totals Breakdown Summary', icon: <Calculator className="w-4 h-4 text-blue-600" />, tab: 'design' },
  subtotal: { label: 'Subtotal Row', icon: <Calculator className="w-4 h-4 text-blue-600" />, tab: 'typography' },
  discountTotal: { label: 'Discount Row', icon: <Calculator className="w-4 h-4 text-blue-600" />, tab: 'typography' },
  taxTotal: { label: 'Tax Row', icon: <Calculator className="w-4 h-4 text-blue-600" />, tab: 'typography' },
  grandTotal: { label: 'Grand Total Banner', icon: <Calculator className="w-4 h-4 text-blue-600" />, tab: 'colors' },
  totalPaid: { label: 'Total Paid Row', icon: <Calculator className="w-4 h-4 text-blue-600" />, tab: 'typography' },
  remainingTotal: { label: 'Remaining Total Row', icon: <Calculator className="w-4 h-4 text-blue-600" />, tab: 'typography' },
  paymentStatusTotal: { label: 'Payment Status (Totals)', icon: <Calculator className="w-4 h-4 text-blue-600" />, tab: 'typography' },
  notes: { label: 'Notes & Terms Box', icon: <MessageSquare className="w-4 h-4 text-blue-600" />, tab: 'design' },
  signatures: { label: 'Signatures Section', icon: <PenTool className="w-4 h-4 text-blue-600" />, tab: 'design' },
  signatureCustomer: { label: 'Customer Signature', icon: <PenTool className="w-4 h-4 text-blue-600" />, tab: 'design' },
  signatureAuthorized: { label: 'Authorized Signature', icon: <PenTool className="w-4 h-4 text-blue-600" />, tab: 'design' },
  footer: { label: 'Footer Banner', icon: <Sliders className="w-4 h-4 text-blue-600" />, tab: 'colors' },
  footerThankYou: { label: 'Footer Thank You Text', icon: <Sliders className="w-4 h-4 text-blue-600" />, tab: 'typography' },
  footerContacts: { label: 'Footer Contacts', icon: <Sliders className="w-4 h-4 text-blue-600" />, tab: 'typography' },
  pageNumber: { label: 'Page Number', icon: <FileText className="w-4 h-4 text-blue-600" />, tab: 'design' },
};

export const ContextualToolbar: React.FC<ContextualToolbarProps> = ({
  selectedElement,
  design,
  updateDesign,
  onClose,
  placement = 'right',
  onDragStart,
  isSidebar = false,
}) => {
  const logo1InputRef = useRef<HTMLInputElement>(null);
  const logo2InputRef = useRef<HTMLInputElement>(null);

  const meta = ELEMENT_LABELS[selectedElement] || {
    label: selectedElement,
    icon: <Sliders className="w-4 h-4 text-blue-600" />,
    tab: 'home',
  };

  // Reorder footer elements sequence (Thank You, Contacts, Page Number)
  const currentFooterOrder = normalizeFooterElementsOrder(design.footer?.footerElementsOrder);

  const moveFooterElement = (elemId: FooterElementId, direction: 'up' | 'down') => {
    const idx = currentFooterOrder.indexOf(elemId);
    if (idx === -1) return;
    const targetIdx = direction === 'up' ? idx - 1 : idx + 1;
    if (targetIdx < 0 || targetIdx >= currentFooterOrder.length) return;

    const newOrder = [...currentFooterOrder];
    const temp = newOrder[idx];
    newOrder[idx] = newOrder[targetIdx];
    newOrder[targetIdx] = temp;

    updateDesign((p) => ({
      ...p,
      footer: {
        ...p.footer,
        footerElementsOrder: newOrder,
      },
    }));
  };

  const handleImageUpload = (
    e: React.ChangeEvent<HTMLInputElement>,
    logoKey: 'logo1' | 'logo2'
  ) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (file.size > 2 * 1024 * 1024) {
      console.warn('Logo file must be under 2MB.');
      return;
    }

    const reader = new FileReader();
    reader.onload = () => {
      const dataUrl = reader.result as string;
      updateDesign((p) => ({
        ...p,
        logos: {
          ...p.logos,
          [logoKey]: {
            ...p.logos[logoKey],
            url: dataUrl,
            show: true,
          },
        },
        visibility: {
          ...p.visibility,
          [logoKey]: true,
        },
      }));
    };
    reader.readAsDataURL(file);
  };

  return (
    <div
      onClick={(e) => e.stopPropagation()}
      className={
        isSidebar
          ? "w-full flex flex-col p-4 text-xs text-neutral-800"
          : "bg-white/95 backdrop-blur-md border border-blue-200/90 shadow-2xl rounded-xl p-3 z-50 transition-shadow duration-150 w-full max-h-[min(540px,calc(100vh-140px))] overflow-y-auto text-xs text-neutral-800"
      }
    >
      {/* Top Header of Toolbar */}
      <div className="flex items-center justify-between pb-2 mb-2.5 border-b border-neutral-200 gap-1.5 select-none">
        <div className="flex items-center gap-1.5 min-w-0">
          {!isSidebar && onDragStart && (
            <button
              type="button"
              onMouseDown={onDragStart}
              className="p-0.5 text-neutral-400 hover:text-neutral-700 cursor-grab active:cursor-grabbing rounded hover:bg-neutral-100 transition shrink-0"
              title="Drag to reposition toolbar"
            >
              <GripVertical className="w-3.5 h-3.5" />
            </button>
          )}
          <div className="p-1 rounded-md bg-blue-50 border border-blue-200 shrink-0">
            {meta.icon}
          </div>
          <div className="flex items-center gap-1 min-w-0 truncate">
            <span className="font-bold text-neutral-900 text-xs truncate">
              {meta.label}
            </span>
          </div>
        </div>

        <div className="flex items-center gap-1.5 shrink-0">
          {/* Quick Canonical Visibility Toggle for Selected Element */}
          <button
            type="button"
            onClick={() => {
              const currentVis = getElementVisibility(selectedElement, design);
              updateDesign((p) => setElementVisibility(selectedElement, !currentVis, p));
            }}
            className={`flex items-center gap-1 px-1.5 py-0.5 rounded border text-[11px] font-medium transition cursor-pointer ${
              getElementVisibility(selectedElement, design)
                ? 'bg-blue-50 text-blue-700 border-blue-200 hover:bg-blue-100'
                : 'bg-neutral-100 text-neutral-500 border-neutral-300 hover:bg-neutral-200'
            }`}
            title={
              getElementVisibility(selectedElement, design)
                ? 'Element is visible. Click to hide.'
                : 'Element is hidden. Click to show.'
            }
          >
            {getElementVisibility(selectedElement, design) ? (
              <Eye className="w-3 h-3 text-blue-600" />
            ) : (
              <EyeOff className="w-3 h-3 text-neutral-400" />
            )}
            <span className="hidden sm:inline">
              {getElementVisibility(selectedElement, design) ? 'Visible' : 'Hidden'}
            </span>
          </button>

          <span className="text-[9.5px] uppercase font-semibold text-blue-600 bg-blue-50 px-1.5 py-0.5 rounded border border-blue-200">
            {placement}
          </span>

          <button
            type="button"
            onClick={onClose}
            className="p-1 text-neutral-400 hover:text-neutral-700 hover:bg-neutral-100 rounded-md transition cursor-pointer"
            title="Deselect element (Esc)"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Contextual Body Controls based on selectedElement */}
      <div className="flex flex-wrap items-center gap-3">
        {/* 1. COMPANY ENGLISH NAME */}
        {selectedElement === 'companyEnglishName' && (
          <>
            <div className="flex flex-col gap-1 min-w-[200px] flex-1">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Company Name (English)
              </span>
              <input
                type="text"
                value={design.company.name || ''}
                onChange={(e) => {
                  const val = e.target.value;
                  updateDesign((p) => ({
                    ...p,
                    company: { ...p.company, name: val },
                    header: { ...p.header, headerText: val },
                    title: { ...p.title, text: val },
                  }));
                }}
                placeholder="Sarwan Technology"
                className="px-2 py-1 text-xs border border-neutral-300 rounded font-medium focus:ring-1 focus:ring-blue-500 focus:border-blue-500 bg-white"
              />
            </div>

            <FontFamilySelect
              value={design.company.fontFamily || design.typography.headingFontFamily}
              onChange={(f) =>
                updateDesign((p) => ({
                  ...p,
                  company: { ...p.company, fontFamily: f },
                }))
              }
              label="Font Family"
            />

            <div className="flex flex-col gap-1">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Font Size
              </span>
              <div className="flex items-center gap-1">
                <input
                  type="number"
                  min={12}
                  max={36}
                  step={0.5}
                  value={design.company.fontSize || design.typography.companyNameFontSize || 24}
                  onChange={(e) => {
                    const val = Number(e.target.value);
                    updateDesign((p) => ({
                      ...p,
                      company: { ...p.company, fontSize: val },
                    }));
                  }}
                  className="w-16 px-1.5 py-1 text-xs text-center border border-neutral-300 rounded font-mono bg-white"
                />
                <span className="text-[10px] text-neutral-400">px</span>
              </div>
            </div>

            <div className="flex flex-col gap-1">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Text Color
              </span>
              <div className="flex items-center gap-1.5">
                <input
                  type="color"
                  value={design.company.color || design.title.color || design.colors.text || '#0B1E36'}
                  onChange={(e) => {
                    const val = e.target.value;
                    updateDesign((p) => ({
                      ...p,
                      company: { ...p.company, color: val },
                    }));
                  }}
                  className="w-7 h-7 p-0.5 border border-neutral-300 rounded cursor-pointer"
                />
                <span className="text-[11px] font-mono uppercase text-neutral-600">
                  {design.company.color || design.title.color || design.colors.text || '#0B1E36'}
                </span>
              </div>
            </div>

            <div className="flex flex-col gap-1">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Style &amp; Align
              </span>
              <div className="flex items-center gap-1">
                <button
                  type="button"
                  onClick={() =>
                    updateDesign((p) => ({
                      ...p,
                      company: {
                        ...p.company,
                        fontWeight: (p.company.fontWeight || 'bold') === 'bold' ? 'normal' : 'bold',
                      },
                    }))
                  }
                  className={`p-1.5 rounded border text-xs font-bold transition cursor-pointer ${
                    (design.company.fontWeight || 'bold') === 'bold'
                      ? 'bg-blue-100 text-blue-800 border-blue-300'
                      : 'bg-white text-neutral-700 border-neutral-300 hover:bg-neutral-100'
                  }`}
                  title="Toggle Bold"
                >
                  <Bold className="w-3.5 h-3.5" />
                </button>
                <button
                  type="button"
                  onClick={() =>
                    updateDesign((p) => ({
                      ...p,
                      company: {
                        ...p.company,
                        italic: !p.company.italic,
                      },
                    }))
                  }
                  className={`p-1.5 rounded border text-xs font-bold transition cursor-pointer ${
                    design.company.italic
                      ? 'bg-blue-100 text-blue-800 border-blue-300'
                      : 'bg-white text-neutral-700 border-neutral-300 hover:bg-neutral-100'
                  }`}
                  title="Toggle Italic"
                >
                  <Italic className="w-3.5 h-3.5" />
                </button>
                <button
                  type="button"
                  onClick={() =>
                    updateDesign((p) => ({
                      ...p,
                      company: {
                        ...p.company,
                        underline: !p.company.underline,
                      },
                    }))
                  }
                  className={`p-1.5 rounded border text-xs font-bold transition cursor-pointer ${
                    design.company.underline
                      ? 'bg-blue-100 text-blue-800 border-blue-300'
                      : 'bg-white text-neutral-700 border-neutral-300 hover:bg-neutral-100'
                  }`}
                  title="Toggle Underline"
                >
                  <UnderlineIcon className="w-3.5 h-3.5" />
                </button>

                {(['left', 'center', 'right'] as const).map((align) => (
                  <button
                    key={align}
                    type="button"
                    onClick={() =>
                      updateDesign((p) => ({
                        ...p,
                        header: { ...p.header, alignment: align },
                      }))
                    }
                    className={`p-1.5 rounded border transition cursor-pointer ${
                      design.header.alignment === align
                        ? 'bg-blue-100 text-blue-800 border-blue-300'
                        : 'bg-white text-neutral-600 border-neutral-300 hover:bg-neutral-100'
                    }`}
                    title={`Align ${align}`}
                  >
                    {align === 'left' && <AlignLeft className="w-3.5 h-3.5" />}
                    {align === 'center' && <AlignCenter className="w-3.5 h-3.5" />}
                    {align === 'right' && <AlignRight className="w-3.5 h-3.5" />}
                  </button>
                ))}
              </div>
            </div>
          </>
        )}

        {/* 2. COMPANY PASHTO NAME */}
        {selectedElement === 'companyPashtoName' && (
          <>
            <div className="flex flex-col gap-1 min-w-[220px] flex-1">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Pashto / Arabic Name
              </span>
              <input
                type="text"
                dir="rtl"
                value={design.company.pashtoName || ''}
                onChange={(e) => {
                  const val = e.target.value;
                  updateDesign((p) => ({
                    ...p,
                    company: { ...p.company, pashtoName: val },
                    title: { ...p.title, secondaryText: val },
                  }));
                }}
                placeholder="د سرور ټیکنالوژۍ شرکت"
                className="px-2 py-1 text-xs border border-neutral-300 rounded font-medium focus:ring-1 focus:ring-blue-500 focus:border-blue-500 bg-white"
              />
            </div>

            <FontFamilySelect
              value={design.company.pashtoFontFamily}
              onChange={(f) =>
                updateDesign((p) => ({
                  ...p,
                  company: { ...p.company, pashtoFontFamily: f },
                }))
              }
              label="Pashto Font"
            />

            <div className="flex flex-col gap-1">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Font Size
              </span>
              <div className="flex items-center gap-1">
                <input
                  type="number"
                  min={10}
                  max={28}
                  step={0.5}
                  value={design.company.pashtoFontSize || design.typography.pashtoFontSize || 20}
                  onChange={(e) => {
                    const val = Number(e.target.value);
                    updateDesign((p) => ({
                      ...p,
                      company: { ...p.company, pashtoFontSize: val },
                    }));
                  }}
                  className="w-16 px-1.5 py-1 text-xs text-center border border-neutral-300 rounded font-mono bg-white"
                />
                <span className="text-[10px] text-neutral-400">px</span>
              </div>
            </div>

            <div className="flex flex-col gap-1">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Color
              </span>
              <div className="flex items-center gap-1.5">
                <input
                  type="color"
                  value={design.company.pashtoColor || design.title.secondaryColor || design.colors.primary || '#0B1E36'}
                  onChange={(e) => {
                    const val = e.target.value;
                    updateDesign((p) => ({
                      ...p,
                      company: { ...p.company, pashtoColor: val },
                    }));
                  }}
                  className="w-7 h-7 p-0.5 border border-neutral-300 rounded cursor-pointer"
                />
                <span className="text-[11px] font-mono uppercase text-neutral-600">
                  {design.company.pashtoColor || design.title.secondaryColor || design.colors.primary || '#0B1E36'}
                </span>
              </div>
            </div>

            <div className="flex flex-col gap-1">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Style
              </span>
              <div className="flex items-center gap-1">
                <button
                  type="button"
                  onClick={() =>
                    updateDesign((p) => ({
                      ...p,
                      company: {
                        ...p.company,
                        italic: !p.company.italic,
                      },
                    }))
                  }
                  className={`p-1.5 rounded border text-xs font-bold transition cursor-pointer ${
                    design.company.italic
                      ? 'bg-blue-100 text-blue-800 border-blue-300'
                      : 'bg-white text-neutral-700 border-neutral-300 hover:bg-neutral-100'
                  }`}
                  title="Toggle Italic"
                >
                  <Italic className="w-3.5 h-3.5" />
                </button>
                <button
                  type="button"
                  onClick={() =>
                    updateDesign((p) => ({
                      ...p,
                      company: {
                        ...p.company,
                        underline: !p.company.underline,
                      },
                    }))
                  }
                  className={`p-1.5 rounded border text-xs font-bold transition cursor-pointer ${
                    design.company.underline
                      ? 'bg-blue-100 text-blue-800 border-blue-300'
                      : 'bg-white text-neutral-700 border-neutral-300 hover:bg-neutral-100'
                  }`}
                  title="Toggle Underline"
                >
                  <UnderlineIcon className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          </>
        )}

        {/* 3. COMPANY SLOGAN */}
        {selectedElement === 'companySlogan' && (
          <>
            <div className="flex flex-col gap-1 min-w-[240px] flex-1">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Company Slogan / Subtitle
              </span>
              <input
                type="text"
                value={design.company.slogan || ''}
                onChange={(e) => {
                  const val = e.target.value;
                  updateDesign((p) => ({
                    ...p,
                    company: { ...p.company, slogan: val, subtitle: val },
                  }));
                }}
                placeholder="Comprehensive Security & Surveillance Solutions"
                className="px-2 py-1 text-xs border border-neutral-300 rounded font-medium focus:ring-1 focus:ring-blue-500 focus:border-blue-500 bg-white"
              />
            </div>

            <FontFamilySelect
              value={design.company.sloganFontFamily}
              onChange={(f) =>
                updateDesign((p) => ({
                  ...p,
                  company: { ...p.company, sloganFontFamily: f },
                }))
              }
              label="Slogan Font"
            />

            <div className="flex flex-col gap-1">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Font Size
              </span>
              <div className="flex items-center gap-1">
                <input
                  type="number"
                  min={8}
                  max={18}
                  step={0.5}
                  value={design.company.sloganFontSize || design.typography.sloganFontSize || 10.5}
                  onChange={(e) => {
                    const val = Number(e.target.value);
                    updateDesign((p) => ({
                      ...p,
                      company: { ...p.company, sloganFontSize: val },
                    }));
                  }}
                  className="w-16 px-1.5 py-1 text-xs text-center border border-neutral-300 rounded font-mono bg-white"
                />
                <span className="text-[10px] text-neutral-400">px</span>
              </div>
            </div>

            <div className="flex flex-col gap-1">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Slogan Color
              </span>
              <div className="flex items-center gap-1.5">
                <input
                  type="color"
                  value={design.company.sloganColor || '#1E4E8C'}
                  onChange={(e) => {
                    const val = e.target.value;
                    updateDesign((p) => ({
                      ...p,
                      company: { ...p.company, sloganColor: val },
                    }));
                  }}
                  className="w-7 h-7 p-0.5 border border-neutral-300 rounded cursor-pointer"
                />
                <span className="text-[11px] font-mono uppercase text-neutral-600">
                  {design.company.sloganColor || '#1E4E8C'}
                </span>
              </div>
            </div>

            <div className="flex flex-col gap-1">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Style
              </span>
              <div className="flex items-center gap-1">
                <button
                  type="button"
                  onClick={() =>
                    updateDesign((p) => ({
                      ...p,
                      company: {
                        ...p.company,
                        sloganItalic: !p.company.sloganItalic,
                      },
                    }))
                  }
                  className={`p-1.5 rounded border text-xs font-bold transition cursor-pointer ${
                    design.company.sloganItalic
                      ? 'bg-blue-100 text-blue-800 border-blue-300'
                      : 'bg-white text-neutral-700 border-neutral-300 hover:bg-neutral-100'
                  }`}
                  title="Toggle Italic"
                >
                  <Italic className="w-3.5 h-3.5" />
                </button>
                <button
                  type="button"
                  onClick={() =>
                    updateDesign((p) => ({
                      ...p,
                      company: {
                        ...p.company,
                        sloganUnderline: !p.company.sloganUnderline,
                      },
                    }))
                  }
                  className={`p-1.5 rounded border text-xs font-bold transition cursor-pointer ${
                    design.company.sloganUnderline
                      ? 'bg-blue-100 text-blue-800 border-blue-300'
                      : 'bg-white text-neutral-700 border-neutral-300 hover:bg-neutral-100'
                  }`}
                  title="Toggle Underline"
                >
                  <UnderlineIcon className="w-3.5 h-3.5" />
                </button>

                {(['normal', 'medium', 'semibold', 'bold'] as const).map((weight) => (
                  <button
                    key={weight}
                    type="button"
                    onClick={() =>
                      updateDesign((p) => ({
                        ...p,
                        company: { ...p.company, sloganFontWeight: weight },
                      }))
                    }
                    className={`px-1.5 py-1 text-[10px] rounded border transition cursor-pointer ${
                      (design.company.sloganFontWeight || 'semibold') === weight
                        ? 'bg-blue-100 text-blue-800 border-blue-300 font-bold'
                        : 'bg-white text-neutral-600 border-neutral-300 hover:bg-neutral-100'
                    }`}
                    title={`Font Weight: ${weight}`}
                  >
                    {weight[0].toUpperCase()}
                  </button>
                ))}
              </div>
            </div>

            <div className="flex flex-col gap-1">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Align
              </span>
              <div className="flex items-center gap-1">
                {(['left', 'center', 'right'] as const).map((align) => (
                  <button
                    key={align}
                    type="button"
                    onClick={() =>
                      updateDesign((p) => ({
                        ...p,
                        company: { ...p.company, sloganAlign: align },
                      }))
                    }
                    className={`p-1.5 rounded border transition cursor-pointer ${
                      (design.company.sloganAlign || 'left') === align
                        ? 'bg-blue-100 text-blue-800 border-blue-300'
                        : 'bg-white text-neutral-600 border-neutral-300 hover:bg-neutral-100'
                    }`}
                    title={`Align ${align}`}
                  >
                    {align === 'left' && <AlignLeft className="w-3.5 h-3.5" />}
                    {align === 'center' && <AlignCenter className="w-3.5 h-3.5" />}
                    {align === 'right' && <AlignRight className="w-3.5 h-3.5" />}
                  </button>
                ))}
              </div>
            </div>

            <div className="flex flex-col gap-1">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Line Ht
              </span>
              <input
                type="number"
                min={1}
                max={2.5}
                step={0.1}
                value={design.company.sloganLineHeight ?? 1.3}
                onChange={(e) => {
                  const val = Number(e.target.value);
                  updateDesign((p) => ({
                    ...p,
                    company: { ...p.company, sloganLineHeight: val },
                  }));
                }}
                className="w-14 px-1 py-1 text-xs text-center border border-neutral-300 rounded font-mono bg-white"
              />
            </div>

            <div className="flex flex-col gap-1">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Spacing
              </span>
              <div className="flex items-center gap-1">
                <input
                  type="number"
                  min={0}
                  max={24}
                  step={1}
                  value={design.company.sloganSpacing ?? 4}
                  onChange={(e) => {
                    const val = Number(e.target.value);
                    updateDesign((p) => ({
                      ...p,
                      company: { ...p.company, sloganSpacing: val },
                    }));
                  }}
                  className="w-14 px-1 py-1 text-xs text-center border border-neutral-300 rounded font-mono bg-white"
                />
                <span className="text-[10px] text-neutral-400">px</span>
              </div>
            </div>

            <div className="flex flex-col gap-1">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Letter Spc
              </span>
              <input
                type="number"
                min={-0.05}
                max={0.3}
                step={0.01}
                value={Number(design.company.sloganLetterSpacing ?? 0.04)}
                onChange={(e) => {
                  const val = Number(e.target.value);
                  updateDesign((p) => ({
                    ...p,
                    company: { ...p.company, sloganLetterSpacing: val },
                  }));
                }}
                className="w-14 px-1 py-1 text-xs text-center border border-neutral-300 rounded font-mono bg-white"
                title="Letter spacing in em"
              />
            </div>

            <div className="flex flex-col gap-1">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Width
              </span>
              <div className="flex items-center gap-1">
                <input
                  type="number"
                  min={100}
                  max={600}
                  step={10}
                  value={design.company.sloganWidth || 0}
                  placeholder="Auto"
                  onChange={(e) => {
                    const val = Number(e.target.value);
                    updateDesign((p) => ({
                      ...p,
                      company: { ...p.company, sloganWidth: val > 0 ? val : undefined },
                    }));
                  }}
                  className="w-16 px-1.5 py-1 text-xs text-center border border-neutral-300 rounded font-mono bg-white"
                  title="Max width in px (0 for auto)"
                />
                <span className="text-[10px] text-neutral-400">px</span>
              </div>
            </div>

            <div className="flex flex-col gap-1">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Slogan Visibility
              </span>
              <button
                type="button"
                onClick={() =>
                  updateDesign((p) => ({
                    ...p,
                    company: { ...p.company, showSubtitle: !p.company.showSubtitle },
                  }))
                }
                className={`flex items-center gap-1 px-2.5 py-1 text-xs rounded border transition cursor-pointer ${
                  design.company.showSubtitle !== false
                    ? 'bg-blue-50 text-blue-700 border-blue-300 font-semibold'
                    : 'bg-white text-neutral-500 border-neutral-300'
                }`}
              >
                {design.company.showSubtitle !== false ? <Eye className="w-3.5 h-3.5" /> : <EyeOff className="w-3.5 h-3.5" />}
                <span>{design.company.showSubtitle !== false ? 'Visible' : 'Hidden'}</span>
              </button>
            </div>
          </>
        )}

        {/* 4 & 5. LOGO LEFT / LOGO RIGHT */}
        {(selectedElement === 'logoLeft' || selectedElement === 'logoRight') && (() => {
          const logoKey = selectedElement === 'logoLeft' ? 'logo1' : 'logo2';
          const logoConfig = design.logos[logoKey];
          const inputRef = selectedElement === 'logoLeft' ? logo1InputRef : logo2InputRef;
          const defaultPreset = selectedElement === 'logoLeft' ? '/sarwan-logo.png' : '/dahua-logo.svg';

          return (
            <>
              {/* Show / Hide Toggle */}
              <div className="flex flex-col gap-1">
                <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                  Status
                </span>
                <button
                  type="button"
                  onClick={() =>
                    updateDesign((p) => ({
                      ...p,
                      logos: {
                        ...p.logos,
                        [logoKey]: { ...p.logos[logoKey], show: !p.logos[logoKey].show },
                      },
                      visibility: {
                        ...p.visibility,
                        [logoKey]: !p.visibility[logoKey],
                      },
                    }))
                  }
                  className={`flex items-center gap-1 px-2.5 py-1 text-xs rounded border transition cursor-pointer ${
                    logoConfig.show
                      ? 'bg-blue-50 text-blue-700 border-blue-300 font-semibold'
                      : 'bg-white text-neutral-500 border-neutral-300'
                  }`}
                >
                  {logoConfig.show ? <Eye className="w-3.5 h-3.5" /> : <EyeOff className="w-3.5 h-3.5" />}
                  <span>{logoConfig.show ? 'Enabled' : 'Disabled'}</span>
                </button>
              </div>

              {/* Upload file */}
              <div className="flex flex-col gap-1">
                <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                  Replace / Upload
                </span>
                <div className="flex items-center gap-1.5">
                  <input
                    type="file"
                    ref={inputRef}
                    accept="image/*"
                    onChange={(e) => handleImageUpload(e, logoKey)}
                    className="hidden"
                  />
                  <button
                    type="button"
                    onClick={() => inputRef.current?.click()}
                    className="flex items-center gap-1.5 px-2.5 py-1 text-xs rounded border border-neutral-300 bg-white hover:bg-neutral-50 text-neutral-800 font-medium transition cursor-pointer shadow-2xs"
                  >
                    <Upload className="w-3.5 h-3.5 text-blue-600" />
                    <span>Upload Image</span>
                  </button>
                  <button
                    type="button"
                    onClick={() =>
                      updateDesign((p) => ({
                        ...p,
                        logos: {
                          ...p.logos,
                          [logoKey]: { ...p.logos[logoKey], url: defaultPreset, show: true },
                        },
                      }))
                    }
                    className="px-2 py-1 text-xs text-neutral-600 hover:text-neutral-900 border border-neutral-200 rounded hover:bg-neutral-50"
                    title="Reset to default logo asset"
                  >
                    Reset Preset
                  </button>
                </div>
              </div>

              {/* Width & Height */}
              <div className="flex items-center gap-2">
                <div className="flex flex-col gap-1">
                  <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                    Width
                  </span>
                  <div className="flex items-center gap-1">
                    <input
                      type="number"
                      min={40}
                      max={240}
                      step={5}
                      value={logoConfig.width || (selectedElement === 'logoLeft' ? 120 : 140)}
                      onChange={(e) => {
                        const val = Number(e.target.value);
                        updateDesign((p) => ({
                          ...p,
                          logos: {
                            ...p.logos,
                            [logoKey]: { ...p.logos[logoKey], width: val },
                          },
                        }));
                      }}
                      className="w-16 px-1.5 py-1 text-xs text-center border border-neutral-300 rounded font-mono bg-white"
                    />
                    <span className="text-[10px] text-neutral-400">px</span>
                  </div>
                </div>

                <div className="flex flex-col gap-1">
                  <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                    Max Height
                  </span>
                  <div className="flex items-center gap-1">
                    <input
                      type="number"
                      min={20}
                      max={120}
                      step={2}
                      value={logoConfig.height || (selectedElement === 'logoLeft' ? 56 : 46)}
                      onChange={(e) => {
                        const val = Number(e.target.value);
                        updateDesign((p) => ({
                          ...p,
                          logos: {
                            ...p.logos,
                            [logoKey]: { ...p.logos[logoKey], height: val },
                          },
                        }));
                      }}
                      className="w-16 px-1.5 py-1 text-xs text-center border border-neutral-300 rounded font-mono bg-white"
                    />
                    <span className="text-[10px] text-neutral-400">px</span>
                  </div>
                </div>
              </div>
            </>
          );
        })()}

        {/* SHAPES: shapeTopLeft, shapeTopRight, shapeGoldAccent, shapeBottomLeft, shapeBottomRight */}
        {(selectedElement === 'shapeTopLeft' || selectedElement === 'shapeTopRight' || selectedElement === 'shapeGoldAccent' || selectedElement === 'shapeBottomLeft' || selectedElement === 'shapeBottomRight') && (() => {
          const shapeKey = selectedElement === 'shapeTopLeft'
            ? 'topLeft'
            : selectedElement === 'shapeTopRight'
            ? 'topRight'
            : selectedElement === 'shapeGoldAccent'
            ? 'goldAccent'
            : selectedElement === 'shapeBottomLeft'
            ? 'bottomLeft'
            : 'bottomRight';
          const defaultShape = DEFAULT_INVOICE_DESIGN.shapes?.[shapeKey] || {
            show: true,
            width: shapeKey === 'goldAccent' ? 200 : 130,
            height: shapeKey === 'goldAccent' ? 2.5 : 65,
            x: 0,
            y: 0,
            fillColor: shapeKey === 'goldAccent' ? '#C5A059' : '#0B1E36',
            accentColor: '#C5A059',
            opacity: 1,
            border: 'none',
            borderWidth: 2.5,
            borderRadius: shapeKey === 'goldAccent' ? 1 : 0,
            rotation: 0,
            zIndex: 20,
            locked: false,
          };
          const shape = design.shapes?.[shapeKey] || defaultShape;

          const updateShape = (patch: Partial<ShapeConfig>) => {
            updateDesign((p) => ({
              ...p,
              shapes: {
                ...p.shapes,
                [shapeKey]: {
                  ...(p.shapes?.[shapeKey] || defaultShape),
                  ...patch,
                },
              },
            }));
          };

          const isLocked = Boolean(shape.locked);

          return (
            <div className="flex flex-wrap items-center gap-3 w-full">
              {/* Show / Hide */}
              <div className="flex flex-col gap-1">
                <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                  Visibility
                </span>
                <button
                  type="button"
                  onClick={() => updateShape({ show: shape.show === false ? true : false })}
                  className={`flex items-center gap-1 px-2.5 py-1 text-xs rounded border transition cursor-pointer ${
                    shape.show !== false
                      ? 'bg-blue-50 text-blue-700 border-blue-300 font-semibold'
                      : 'bg-white text-neutral-500 border-neutral-300'
                  }`}
                >
                  {shape.show !== false ? <Eye className="w-3.5 h-3.5" /> : <EyeOff className="w-3.5 h-3.5" />}
                  <span>{shape.show !== false ? 'Visible' : 'Hidden'}</span>
                </button>
              </div>

              {/* Dimensions: Width & Height */}
              <div className="flex flex-col gap-1">
                <div className="flex items-center justify-between gap-2">
                  <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                    Width × Height
                  </span>
                  <label className="flex items-center gap-1 cursor-pointer text-[9.5px] font-medium text-neutral-600 select-none">
                    <input
                      type="checkbox"
                      disabled={isLocked}
                      checked={Boolean(shape.lockAspectRatio)}
                      onChange={(e) => updateShape({ lockAspectRatio: e.target.checked })}
                      className="rounded border-neutral-300 text-blue-600 w-3 h-3"
                    />
                    <span>Lock Ratio</span>
                  </label>
                </div>
                <div className="flex items-center gap-1">
                  <input
                    type="number"
                    disabled={isLocked}
                    min={10}
                    max={400}
                    value={shape.width || defaultShape.width}
                    onChange={(e) => {
                      const newW = Number(e.target.value);
                      if (shape.lockAspectRatio) {
                        const curW = shape.width || defaultShape.width;
                        const curH = shape.height || defaultShape.height;
                        const ratio = curW > 0 && curH > 0 ? curW / curH : 1;
                        updateShape({ width: newW, height: Math.max(1, Math.round(newW / ratio)) });
                      } else {
                        updateShape({ width: newW });
                      }
                    }}
                    className="w-16 px-1.5 py-1 text-xs text-center border border-neutral-300 rounded font-mono bg-white disabled:bg-neutral-100"
                    title="Width in px (independent when lock is off)"
                  />
                  <span className="text-neutral-400">×</span>
                  <input
                    type="number"
                    disabled={isLocked}
                    min={1}
                    max={250}
                    step={shapeKey === 'goldAccent' ? 0.5 : 1}
                    value={shape.height || defaultShape.height}
                    onChange={(e) => {
                      const newH = Number(e.target.value);
                      if (shape.lockAspectRatio) {
                        const curW = shape.width || defaultShape.width;
                        const curH = shape.height || defaultShape.height;
                        const ratio = curW > 0 && curH > 0 ? curW / curH : 1;
                        updateShape({ height: newH, width: Math.max(10, Math.round(newH * ratio)) });
                      } else {
                        updateShape({ height: newH });
                      }
                    }}
                    className="w-16 px-1.5 py-1 text-xs text-center border border-neutral-300 rounded font-mono bg-white disabled:bg-neutral-100"
                    title="Height in px (independent when lock is off)"
                  />
                  <span className="text-[10px] text-neutral-400">px</span>
                </div>
              </div>

              {/* Position: X & Y offset */}
              <div className="flex flex-col gap-1">
                <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                  Position (X / Y)
                </span>
                <div className="flex items-center gap-1">
                  <span className="text-[10px] text-neutral-500 font-mono">X:</span>
                  <input
                    type="number"
                    disabled={isLocked}
                    min={-100}
                    max={200}
                    value={shape.x || 0}
                    onChange={(e) => updateShape({ x: Number(e.target.value) })}
                    className="w-14 px-1 py-1 text-xs text-center border border-neutral-300 rounded font-mono bg-white disabled:bg-neutral-100"
                  />
                  <span className="text-[10px] text-neutral-500 font-mono ml-1">Y:</span>
                  <input
                    type="number"
                    disabled={isLocked}
                    min={-100}
                    max={200}
                    value={shape.y || 0}
                    onChange={(e) => updateShape({ y: Number(e.target.value) })}
                    className="w-14 px-1 py-1 text-xs text-center border border-neutral-300 rounded font-mono bg-white disabled:bg-neutral-100"
                  />
                  <span className="text-[10px] text-neutral-400">px</span>
                </div>
              </div>

              {/* Fill Color */}
              <div className="flex flex-col gap-1">
                <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                  Fill Color
                </span>
                <div className="flex items-center gap-1.5">
                  <input
                    type="color"
                    disabled={isLocked}
                    value={shape.fillColor || defaultShape.fillColor}
                    onChange={(e) => updateShape({ fillColor: e.target.value })}
                    className="w-7 h-7 p-0.5 border border-neutral-300 rounded cursor-pointer disabled:opacity-50"
                  />
                  <span className="text-[11px] font-mono uppercase text-neutral-600">
                    {shape.fillColor || defaultShape.fillColor}
                  </span>
                </div>
              </div>

              {/* Accent / Border Color */}
              {shapeKey !== 'goldAccent' && (
                <div className="flex flex-col gap-1">
                  <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                    Accent Line
                  </span>
                  <div className="flex items-center gap-1.5">
                    <input
                      type="color"
                      disabled={isLocked}
                      value={shape.accentColor || defaultShape.accentColor}
                      onChange={(e) => updateShape({ accentColor: e.target.value })}
                      className="w-7 h-7 p-0.5 border border-neutral-300 rounded cursor-pointer disabled:opacity-50"
                    />
                    <span className="text-[11px] font-mono uppercase text-neutral-600">
                      {shape.accentColor || defaultShape.accentColor}
                    </span>
                  </div>
                </div>
              )}

              {/* Border Width (Line thickness) */}
              <div className="flex flex-col gap-1">
                <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                  Line Width
                </span>
                <div className="flex items-center gap-1">
                  <input
                    type="number"
                    disabled={isLocked}
                    min={0.5}
                    max={12}
                    step={0.5}
                    value={shape.borderWidth || defaultShape.borderWidth}
                    onChange={(e) => updateShape({ borderWidth: Number(e.target.value) })}
                    className="w-14 px-1 py-1 text-xs text-center border border-neutral-300 rounded font-mono bg-white disabled:bg-neutral-100"
                  />
                  <span className="text-[10px] text-neutral-400">px</span>
                </div>
              </div>

              {/* Opacity */}
              <div className="flex flex-col gap-1">
                <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                  Opacity
                </span>
                <div className="flex items-center gap-1.5">
                  <input
                    type="range"
                    disabled={isLocked}
                    min={0.1}
                    max={1}
                    step={0.05}
                    value={shape.opacity ?? defaultShape.opacity}
                    onChange={(e) => updateShape({ opacity: Number(e.target.value) })}
                    className="w-18 accent-blue-600 cursor-pointer disabled:opacity-50"
                  />
                  <span className="text-[10px] font-mono text-neutral-600 w-8">
                    {Math.round((shape.opacity ?? defaultShape.opacity) * 100)}%
                  </span>
                </div>
              </div>

              {/* Border Radius */}
              <div className="flex flex-col gap-1">
                <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                  Corner Radius
                </span>
                <div className="flex items-center gap-1">
                  <input
                    type="number"
                    disabled={isLocked}
                    min={0}
                    max={50}
                    value={shape.borderRadius || 0}
                    onChange={(e) => updateShape({ borderRadius: Number(e.target.value) })}
                    className="w-14 px-1 py-1 text-xs text-center border border-neutral-300 rounded font-mono bg-white disabled:bg-neutral-100"
                  />
                  <span className="text-[10px] text-neutral-400">px</span>
                </div>
              </div>

              {/* Rotation */}
              <div className="flex flex-col gap-1">
                <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                  Rotation
                </span>
                <div className="flex items-center gap-1">
                  <input
                    type="number"
                    disabled={isLocked}
                    min={-180}
                    max={180}
                    step={5}
                    value={shape.rotation || 0}
                    onChange={(e) => updateShape({ rotation: Number(e.target.value) })}
                    className="w-14 px-1 py-1 text-xs text-center border border-neutral-300 rounded font-mono bg-white disabled:bg-neutral-100"
                  />
                  <span className="text-[10px] text-neutral-400">°</span>
                </div>
              </div>

              {/* Layer / Z-Index */}
              <div className="flex flex-col gap-1">
                <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                  Layer (Z-Index)
                </span>
                <input
                  type="number"
                  disabled={isLocked}
                  min={0}
                  max={50}
                  value={shape.zIndex ?? 20}
                  onChange={(e) => updateShape({ zIndex: Number(e.target.value) })}
                  className="w-14 px-1 py-1 text-xs text-center border border-neutral-300 rounded font-mono bg-white disabled:bg-neutral-100"
                />
              </div>

              {/* Lock & Reset buttons */}
              <div className="flex flex-col gap-1">
                <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                  Manage
                </span>
                <div className="flex items-center gap-1">
                  <button
                    type="button"
                    onClick={() => updateShape({ locked: !isLocked })}
                    className={`flex items-center gap-1 px-2 py-1 text-xs rounded border transition cursor-pointer ${
                      isLocked
                        ? 'bg-amber-50 text-amber-800 border-amber-300 font-semibold'
                        : 'bg-white text-neutral-600 border-neutral-300 hover:bg-neutral-100'
                    }`}
                    title={isLocked ? 'Unlock shape' : 'Lock shape from editing'}
                  >
                    {isLocked ? <Lock className="w-3.5 h-3.5 text-amber-600" /> : <Unlock className="w-3.5 h-3.5 text-neutral-400" />}
                    <span>{isLocked ? 'Locked' : 'Lock'}</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => updateShape(defaultShape)}
                    className="flex items-center gap-1 px-2 py-1 text-xs rounded border border-neutral-300 bg-white text-neutral-600 hover:bg-neutral-100 transition cursor-pointer"
                    title="Reset shape to Design #7 default"
                  >
                    <RotateCcw className="w-3 h-3 text-neutral-400" />
                    <span>Reset</span>
                  </button>
                </div>
              </div>
            </div>
          );
        })()}

        {/* 6. INVOICE TITLE */}
        {selectedElement === 'invoiceTitle' && (
          <>
            <div className="flex flex-col gap-1 min-w-[180px] flex-1">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Title Text
              </span>
              <input
                type="text"
                value={design.title.invoiceTitle || ''}
                onChange={(e) => {
                  const val = e.target.value;
                  updateDesign((p) => ({
                    ...p,
                    title: { ...p.title, invoiceTitle: val },
                  }));
                }}
                placeholder="INVOICE"
                className="px-2 py-1 text-xs border border-neutral-300 rounded font-medium focus:ring-1 focus:ring-blue-500 focus:border-blue-500 bg-white"
              />
            </div>

            <FontFamilySelect
              value={design.title.fontFamily || design.typography.titleFontFamily || design.typography.headingFontFamily}
              onChange={(f) =>
                updateDesign((p) => ({
                  ...p,
                  title: { ...p.title, fontFamily: f },
                }))
              }
            />

            <div className="flex flex-col gap-1">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Font Size
              </span>
              <div className="flex items-center gap-1">
                <input
                  type="number"
                  min={16}
                  max={42}
                  step={1}
                  value={design.title.fontSize || design.typography.titleFontSize || 26}
                  onChange={(e) => {
                    const val = Number(e.target.value);
                    updateDesign((p) => ({
                      ...p,
                      title: { ...p.title, fontSize: val },
                    }));
                  }}
                  className="w-16 px-1.5 py-1 text-xs text-center border border-neutral-300 rounded font-mono bg-white"
                />
                <span className="text-[10px] text-neutral-400">px</span>
              </div>
            </div>

            <div className="flex flex-col gap-1">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Title Color
              </span>
              <div className="flex items-center gap-1.5">
                <input
                  type="color"
                  value={design.title.color || design.colors.primary || '#0B1E36'}
                  onChange={(e) => {
                    const val = e.target.value;
                    updateDesign((p) => ({
                      ...p,
                      title: { ...p.title, color: val },
                    }));
                  }}
                  className="w-7 h-7 p-0.5 border border-neutral-300 rounded cursor-pointer"
                />
                <span className="text-[11px] font-mono uppercase text-neutral-600">
                  {design.title.color || design.colors.primary || '#0B1E36'}
                </span>
              </div>
            </div>

            <div className="flex flex-col gap-1">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Style &amp; Align
              </span>
              <div className="flex items-center gap-1">
                <button
                  type="button"
                  onClick={() =>
                    updateDesign((p) => ({
                      ...p,
                      title: {
                        ...p.title,
                        fontWeight: p.title.fontWeight === 'bold' ? 'normal' : 'bold',
                      },
                    }))
                  }
                  className={`p-1.5 rounded border text-xs font-bold transition cursor-pointer ${
                    design.title.fontWeight === 'bold'
                      ? 'bg-blue-100 text-blue-800 border-blue-300'
                      : 'bg-white text-neutral-700 border-neutral-300 hover:bg-neutral-100'
                  }`}
                  title="Toggle Bold"
                >
                  <Bold className="w-3.5 h-3.5" />
                </button>
                <button
                  type="button"
                  onClick={() =>
                    updateDesign((p) => ({
                      ...p,
                      title: {
                        ...p.title,
                        italic: !p.title.italic,
                      },
                    }))
                  }
                  className={`p-1.5 rounded border text-xs font-bold transition cursor-pointer ${
                    design.title.italic
                      ? 'bg-blue-100 text-blue-800 border-blue-300'
                      : 'bg-white text-neutral-700 border-neutral-300 hover:bg-neutral-100'
                  }`}
                  title="Toggle Italic"
                >
                  <Italic className="w-3.5 h-3.5" />
                </button>
                <button
                  type="button"
                  onClick={() =>
                    updateDesign((p) => ({
                      ...p,
                      title: {
                        ...p.title,
                        underline: !p.title.underline,
                      },
                    }))
                  }
                  className={`p-1.5 rounded border text-xs font-bold transition cursor-pointer ${
                    design.title.underline
                      ? 'bg-blue-100 text-blue-800 border-blue-300'
                      : 'bg-white text-neutral-700 border-neutral-300 hover:bg-neutral-100'
                  }`}
                  title="Toggle Underline"
                >
                  <UnderlineIcon className="w-3.5 h-3.5" />
                </button>

                {(['left', 'center', 'right'] as const).map((align) => (
                  <button
                    key={align}
                    type="button"
                    onClick={() =>
                      updateDesign((p) => ({
                        ...p,
                        title: { ...p.title, alignment: align },
                      }))
                    }
                    className={`p-1.5 rounded border transition cursor-pointer ${
                      design.title.alignment === align
                        ? 'bg-blue-100 text-blue-800 border-blue-300'
                        : 'bg-white text-neutral-600 border-neutral-300 hover:bg-neutral-100'
                    }`}
                    title={`Align ${align}`}
                  >
                    {align === 'left' && <AlignLeft className="w-3.5 h-3.5" />}
                    {align === 'center' && <AlignCenter className="w-3.5 h-3.5" />}
                    {align === 'right' && <AlignRight className="w-3.5 h-3.5" />}
                  </button>
                ))}
              </div>
            </div>
          </>
        )}

        {/* 7. INVOICE META */}
        {selectedElement === 'invoiceMeta' && (
          <>
            <div className="flex flex-col gap-1">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Header Bg
              </span>
              <div className="flex items-center gap-1.5">
                <input
                  type="color"
                  value={design.colors.tableHeaderBackground || design.itemsTable.headerBgColor || '#0B1E36'}
                  onChange={(e) => {
                    const val = e.target.value;
                    updateDesign((p) => ({
                      ...p,
                      colors: { ...p.colors, tableHeaderBackground: val },
                      itemsTable: { ...p.itemsTable, headerBgColor: val },
                    }));
                  }}
                  className="w-7 h-7 p-0.5 border border-neutral-300 rounded cursor-pointer"
                />
                <span className="text-[11px] font-mono uppercase text-neutral-600">
                  {design.colors.tableHeaderBackground || design.itemsTable.headerBgColor || '#0B1E36'}
                </span>
              </div>
            </div>

            <div className="flex flex-col gap-1">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Background
              </span>
              <div className="flex items-center gap-1.5">
                <input
                  type="color"
                  value={design.invoiceMeta?.backgroundColor || design.invoiceNumber.backgroundColor || '#FFFFFF'}
                  onChange={(e) => {
                    const val = e.target.value;
                    updateDesign((p) => ({
                      ...p,
                      invoiceNumber: { ...p.invoiceNumber, backgroundColor: val },
                      invoiceMeta: { ...(p.invoiceMeta || {}), backgroundColor: val },
                    }));
                  }}
                  className="w-7 h-7 p-0.5 border border-neutral-300 rounded cursor-pointer"
                />
                <span className="text-[11px] font-mono uppercase text-neutral-600">
                  {design.invoiceMeta?.backgroundColor || design.invoiceNumber.backgroundColor || '#FFFFFF'}
                </span>
              </div>
            </div>

            <div className="flex flex-col gap-1">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Border Color
              </span>
              <div className="flex items-center gap-1.5">
                <input
                  type="color"
                  value={design.invoiceMeta?.borderColor || design.invoiceNumber.borderColor || '#E5E7EB'}
                  onChange={(e) => {
                    const val = e.target.value;
                    updateDesign((p) => ({
                      ...p,
                      invoiceNumber: { ...p.invoiceNumber, borderColor: val },
                      invoiceMeta: { ...(p.invoiceMeta || {}), borderColor: val },
                    }));
                  }}
                  className="w-7 h-7 p-0.5 border border-neutral-300 rounded cursor-pointer"
                />
                <span className="text-[11px] font-mono uppercase text-neutral-600">
                  {design.invoiceMeta?.borderColor || design.invoiceNumber.borderColor || '#E5E7EB'}
                </span>
              </div>
            </div>

            <div className="flex flex-col gap-1">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Border Style
              </span>
              <select
                value={design.invoiceMeta?.borderStyle || design.invoiceNumber.borderStyle || 'solid'}
                onChange={(e) => {
                  const val = e.target.value as 'none' | 'solid' | 'dashed';
                  updateDesign((p) => ({
                    ...p,
                    invoiceNumber: { ...p.invoiceNumber, borderStyle: val },
                    invoiceMeta: { ...(p.invoiceMeta || {}), borderStyle: val },
                  }));
                }}
                className="px-2 py-1 text-xs border border-neutral-300 rounded bg-white font-medium"
              >
                <option value="solid">Solid</option>
                <option value="dashed">Dashed</option>
                <option value="none">None</option>
              </select>
            </div>

            <div className="flex flex-col gap-1">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Border Width
              </span>
              <div className="flex items-center gap-1">
                <input
                  type="number"
                  min={0}
                  max={10}
                  step={0.5}
                  value={design.invoiceMeta?.borderWidth ?? design.invoiceNumber.borderWidth ?? 1}
                  onChange={(e) => {
                    const val = Math.max(0, Number(e.target.value));
                    updateDesign((p) => ({
                      ...p,
                      invoiceNumber: { ...p.invoiceNumber, borderWidth: val },
                      invoiceMeta: { ...(p.invoiceMeta || {}), borderWidth: val },
                    }));
                  }}
                  className="w-14 px-1.5 py-1 text-xs text-center border border-neutral-300 rounded font-mono bg-white"
                />
                <span className="text-[10px] text-neutral-400">px</span>
              </div>
            </div>

            <div className="flex flex-col gap-1">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Corner Radius
              </span>
              <div className="flex items-center gap-1">
                <input
                  type="number"
                  min={0}
                  max={24}
                  step={1}
                  value={design.invoiceMeta?.borderRadius ?? design.invoiceNumber.borderRadius ?? 4}
                  onChange={(e) => {
                    const val = Math.max(0, Number(e.target.value));
                    updateDesign((p) => ({
                      ...p,
                      invoiceNumber: { ...p.invoiceNumber, borderRadius: val },
                      invoiceMeta: { ...(p.invoiceMeta || {}), borderRadius: val },
                    }));
                  }}
                  className="w-14 px-1.5 py-1 text-xs text-center border border-neutral-300 rounded font-mono bg-white"
                />
                <span className="text-[10px] text-neutral-400">px</span>
              </div>
            </div>

            <FontFamilySelect
              value={design.invoiceNumber.fontFamily || design.typography.fontFamily}
              onChange={(f) =>
                updateDesign((p) => ({
                  ...p,
                  invoiceNumber: { ...p.invoiceNumber, fontFamily: f },
                  date: { ...p.date, fontFamily: f },
                  collector: { ...p.collector, fontFamily: f },
                }))
              }
              label="Meta Font"
            />

            <div className="flex flex-col gap-1 min-w-[130px]">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Bill No Label
              </span>
              <input
                type="text"
                value={design.invoiceNumber.label || 'Bill No:'}
                onChange={(e) => {
                  const val = e.target.value;
                  updateDesign((p) => ({
                    ...p,
                    invoiceNumber: { ...p.invoiceNumber, label: val },
                    billInfo: { ...p.billInfo, billNumberLabel: val },
                  }));
                }}
                className="px-2 py-1 text-xs border border-neutral-300 rounded bg-white"
              />
            </div>

            <div className="flex flex-col gap-1 min-w-[130px]">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Date Label
              </span>
              <input
                type="text"
                value={design.date.label || 'Date:'}
                onChange={(e) => {
                  const val = e.target.value;
                  updateDesign((p) => ({
                    ...p,
                    date: { ...p.date, label: val },
                    billInfo: { ...p.billInfo, dateLabel: val },
                  }));
                }}
                className="px-2 py-1 text-xs border border-neutral-300 rounded bg-white"
              />
            </div>
          </>
        )}

        {/* 7b. BILL NUMBER */}
        {selectedElement === 'billNumber' && (
          <>
            <div className="flex flex-col gap-1 min-w-[130px] flex-1">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Bill No Label
              </span>
              <input
                type="text"
                value={design.invoiceNumber.label || 'Bill No:'}
                onChange={(e) => {
                  const val = e.target.value;
                  updateDesign((p) => ({
                    ...p,
                    invoiceNumber: { ...p.invoiceNumber, label: val },
                    billInfo: { ...p.billInfo, billNumberLabel: val },
                  }));
                }}
                className="px-2 py-1 text-xs border border-neutral-300 rounded font-medium bg-white"
              />
            </div>

            <FontFamilySelect
              value={design.invoiceNumber.fontFamily}
              onChange={(f) =>
                updateDesign((p) => ({
                  ...p,
                  invoiceNumber: { ...p.invoiceNumber, fontFamily: f },
                }))
              }
            />

            <div className="flex flex-col gap-1">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Font Size
              </span>
              <div className="flex items-center gap-1">
                <input
                  type="number"
                  min={8}
                  max={20}
                  step={0.5}
                  value={design.invoiceNumber.fontSize || 11}
                  onChange={(e) => {
                    const val = Number(e.target.value);
                    updateDesign((p) => ({
                      ...p,
                      invoiceNumber: { ...p.invoiceNumber, fontSize: val },
                    }));
                  }}
                  className="w-14 px-1 py-1 text-xs text-center border border-neutral-300 rounded font-mono bg-white"
                />
                <span className="text-[10px] text-neutral-400">px</span>
              </div>
            </div>

            <div className="flex flex-col gap-1">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Style
              </span>
              <div className="flex items-center gap-1">
                <button
                  type="button"
                  onClick={() =>
                    updateDesign((p) => ({
                      ...p,
                      invoiceNumber: {
                        ...p.invoiceNumber,
                        fontWeight: p.invoiceNumber.fontWeight === 'bold' ? 'normal' : 'bold',
                      },
                    }))
                  }
                  className={`p-1.5 rounded border text-xs font-bold transition cursor-pointer ${
                    design.invoiceNumber.fontWeight === 'bold'
                      ? 'bg-blue-100 text-blue-800 border-blue-300'
                      : 'bg-white text-neutral-700 border-neutral-300 hover:bg-neutral-100'
                  }`}
                  title="Toggle Bold"
                >
                  <Bold className="w-3.5 h-3.5" />
                </button>
                <button
                  type="button"
                  onClick={() =>
                    updateDesign((p) => ({
                      ...p,
                      invoiceNumber: {
                        ...p.invoiceNumber,
                        italic: !p.invoiceNumber.italic,
                      },
                    }))
                  }
                  className={`p-1.5 rounded border text-xs font-bold transition cursor-pointer ${
                    design.invoiceNumber.italic
                      ? 'bg-blue-100 text-blue-800 border-blue-300'
                      : 'bg-white text-neutral-700 border-neutral-300 hover:bg-neutral-100'
                  }`}
                  title="Toggle Italic"
                >
                  <Italic className="w-3.5 h-3.5" />
                </button>
                <button
                  type="button"
                  onClick={() =>
                    updateDesign((p) => ({
                      ...p,
                      invoiceNumber: {
                        ...p.invoiceNumber,
                        underline: !p.invoiceNumber.underline,
                      },
                    }))
                  }
                  className={`p-1.5 rounded border text-xs font-bold transition cursor-pointer ${
                    design.invoiceNumber.underline
                      ? 'bg-blue-100 text-blue-800 border-blue-300'
                      : 'bg-white text-neutral-700 border-neutral-300 hover:bg-neutral-100'
                  }`}
                  title="Toggle Underline"
                >
                  <UnderlineIcon className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>

            <div className="flex flex-col gap-1">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Label Color
              </span>
              <div className="flex items-center gap-1.5">
                <input
                  type="color"
                  value={design.invoiceNumber.color || '#0B1E36'}
                  onChange={(e) => {
                    const val = e.target.value;
                    updateDesign((p) => ({
                      ...p,
                      invoiceNumber: { ...p.invoiceNumber, color: val },
                    }));
                  }}
                  className="w-7 h-7 p-0.5 border border-neutral-300 rounded cursor-pointer"
                />
                <span className="text-[11px] font-mono uppercase text-neutral-600">
                  {design.invoiceNumber.color || '#0B1E36'}
                </span>
              </div>
            </div>

            <div className="flex flex-col gap-1">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Value Color
              </span>
              <div className="flex items-center gap-1.5">
                <input
                  type="color"
                  value={design.invoiceNumber.valueColor || '#0F172A'}
                  onChange={(e) => {
                    const val = e.target.value;
                    updateDesign((p) => ({
                      ...p,
                      invoiceNumber: { ...p.invoiceNumber, valueColor: val },
                    }));
                  }}
                  className="w-7 h-7 p-0.5 border border-neutral-300 rounded cursor-pointer"
                />
                <span className="text-[11px] font-mono uppercase text-neutral-600">
                  {design.invoiceNumber.valueColor || '#0F172A'}
                </span>
              </div>
            </div>

            <div className="flex flex-col gap-1">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Visibility
              </span>
              <button
                type="button"
                onClick={() =>
                  updateDesign((p) => ({
                    ...p,
                    invoiceNumber: { ...p.invoiceNumber, show: !p.invoiceNumber.show },
                    visibility: { ...p.visibility, invoiceNumber: !p.invoiceNumber.show },
                  }))
                }
                className={`flex items-center gap-1 px-2.5 py-1 text-xs rounded border transition cursor-pointer ${
                  design.invoiceNumber.show !== false && design.visibility.invoiceNumber !== false
                    ? 'bg-blue-50 text-blue-700 border-blue-300 font-semibold'
                    : 'bg-white text-neutral-500 border-neutral-300'
                }`}
              >
                {design.invoiceNumber.show !== false ? <Eye className="w-3.5 h-3.5" /> : <EyeOff className="w-3.5 h-3.5" />}
                <span>{design.invoiceNumber.show !== false ? 'Visible' : 'Hidden'}</span>
              </button>
            </div>
          </>
        )}

        {/* 7c. INVOICE DATE & DUE DATE */}
        {(selectedElement === 'invoiceDate' || selectedElement === 'dueDate') && (
          <>
            <div className="flex flex-col gap-1 min-w-[130px] flex-1">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                {selectedElement === 'invoiceDate' ? 'Date Label' : 'Due Date Label'}
              </span>
              <input
                type="text"
                value={selectedElement === 'invoiceDate' ? (design.date.label || 'Date:') : (design.date.dueDateLabel || 'Due Date:')}
                onChange={(e) => {
                  const val = e.target.value;
                  updateDesign((p) => ({
                    ...p,
                    date: {
                      ...p.date,
                      ...(selectedElement === 'invoiceDate' ? { label: val } : { dueDateLabel: val }),
                    },
                  }));
                }}
                className="px-2 py-1 text-xs border border-neutral-300 rounded font-medium bg-white"
              />
            </div>

            <FontFamilySelect
              value={design.date.fontFamily}
              onChange={(f) =>
                updateDesign((p) => ({
                  ...p,
                  date: { ...p.date, fontFamily: f },
                }))
              }
            />

            <div className="flex flex-col gap-1">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Font Size
              </span>
              <div className="flex items-center gap-1">
                <input
                  type="number"
                  min={8}
                  max={20}
                  step={0.5}
                  value={design.date.fontSize || 11}
                  onChange={(e) => {
                    const val = Number(e.target.value);
                    updateDesign((p) => ({
                      ...p,
                      date: { ...p.date, fontSize: val },
                    }));
                  }}
                  className="w-14 px-1 py-1 text-xs text-center border border-neutral-300 rounded font-mono bg-white"
                />
                <span className="text-[10px] text-neutral-400">px</span>
              </div>
            </div>

            <div className="flex flex-col gap-1">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Style
              </span>
              <div className="flex items-center gap-1">
                <button
                  type="button"
                  onClick={() =>
                    updateDesign((p) => ({
                      ...p,
                      date: {
                        ...p.date,
                        fontWeight: p.date.fontWeight === 'bold' ? 'normal' : 'bold',
                      },
                    }))
                  }
                  className={`p-1.5 rounded border text-xs font-bold transition cursor-pointer ${
                    design.date.fontWeight === 'bold'
                      ? 'bg-blue-100 text-blue-800 border-blue-300'
                      : 'bg-white text-neutral-700 border-neutral-300 hover:bg-neutral-100'
                  }`}
                  title="Toggle Bold"
                >
                  <Bold className="w-3.5 h-3.5" />
                </button>
                <button
                  type="button"
                  onClick={() =>
                    updateDesign((p) => ({
                      ...p,
                      date: {
                        ...p.date,
                        italic: !p.date.italic,
                      },
                    }))
                  }
                  className={`p-1.5 rounded border text-xs font-bold transition cursor-pointer ${
                    design.date.italic
                      ? 'bg-blue-100 text-blue-800 border-blue-300'
                      : 'bg-white text-neutral-700 border-neutral-300 hover:bg-neutral-100'
                  }`}
                  title="Toggle Italic"
                >
                  <Italic className="w-3.5 h-3.5" />
                </button>
                <button
                  type="button"
                  onClick={() =>
                    updateDesign((p) => ({
                      ...p,
                      date: {
                        ...p.date,
                        underline: !p.date.underline,
                      },
                    }))
                  }
                  className={`p-1.5 rounded border text-xs font-bold transition cursor-pointer ${
                    design.date.underline
                      ? 'bg-blue-100 text-blue-800 border-blue-300'
                      : 'bg-white text-neutral-700 border-neutral-300 hover:bg-neutral-100'
                  }`}
                  title="Toggle Underline"
                >
                  <UnderlineIcon className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>

            <div className="flex flex-col gap-1">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Label Color
              </span>
              <div className="flex items-center gap-1.5">
                <input
                  type="color"
                  value={design.date.color || '#0B1E36'}
                  onChange={(e) => {
                    const val = e.target.value;
                    updateDesign((p) => ({
                      ...p,
                      date: { ...p.date, color: val },
                    }));
                  }}
                  className="w-7 h-7 p-0.5 border border-neutral-300 rounded cursor-pointer"
                />
                <span className="text-[11px] font-mono uppercase text-neutral-600">
                  {design.date.color || '#0B1E36'}
                </span>
              </div>
            </div>

            <div className="flex flex-col gap-1">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Value Color
              </span>
              <div className="flex items-center gap-1.5">
                <input
                  type="color"
                  value={design.date.valueColor || '#0F172A'}
                  onChange={(e) => {
                    const val = e.target.value;
                    updateDesign((p) => ({
                      ...p,
                      date: { ...p.date, valueColor: val },
                    }));
                  }}
                  className="w-7 h-7 p-0.5 border border-neutral-300 rounded cursor-pointer"
                />
                <span className="text-[11px] font-mono uppercase text-neutral-600">
                  {design.date.valueColor || '#0F172A'}
                </span>
              </div>
            </div>

            <div className="flex flex-col gap-1">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Visibility
              </span>
              <button
                type="button"
                onClick={() =>
                  updateDesign((p) => ({
                    ...p,
                    date: { ...p.date, show: !p.date.show },
                    visibility: { ...p.visibility, date: !p.date.show },
                  }))
                }
                className={`flex items-center gap-1 px-2.5 py-1 text-xs rounded border transition cursor-pointer ${
                  design.date.show !== false && design.visibility.date !== false
                    ? 'bg-blue-50 text-blue-700 border-blue-300 font-semibold'
                    : 'bg-white text-neutral-500 border-neutral-300'
                }`}
              >
                {design.date.show !== false ? <Eye className="w-3.5 h-3.5" /> : <EyeOff className="w-3.5 h-3.5" />}
                <span>{design.date.show !== false ? 'Visible' : 'Hidden'}</span>
              </button>
            </div>
          </>
        )}

        {/* 7d. COLLECTOR */}
        {selectedElement === 'collector' && (
          <>
            <div className="flex flex-col gap-1 min-w-[130px]">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Collector Label
              </span>
              <input
                type="text"
                value={design.collector.label || 'Collector:'}
                onChange={(e) => {
                  const val = e.target.value;
                  updateDesign((p) => ({
                    ...p,
                    collector: { ...p.collector, label: val },
                  }));
                }}
                className="px-2 py-1 text-xs border border-neutral-300 rounded bg-white"
              />
            </div>

            <FontFamilySelect
              value={design.collector.fontFamily}
              onChange={(f) =>
                updateDesign((p) => ({
                  ...p,
                  collector: { ...p.collector, fontFamily: f },
                }))
              }
            />

            <div className="flex flex-col gap-1">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Font Size
              </span>
              <div className="flex items-center gap-1">
                <input
                  type="number"
                  min={8}
                  max={16}
                  step={0.5}
                  value={design.collector.fontSize || 11}
                  onChange={(e) => {
                    const val = Number(e.target.value);
                    updateDesign((p) => ({
                      ...p,
                      collector: { ...p.collector, fontSize: val },
                    }));
                  }}
                  className="w-16 px-1.5 py-1 text-xs text-center border border-neutral-300 rounded font-mono bg-white"
                />
                <span className="text-[10px] text-neutral-400">px</span>
              </div>
            </div>

            <div className="flex flex-col gap-1">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Style
              </span>
              <div className="flex items-center gap-1">
                <button
                  type="button"
                  onClick={() =>
                    updateDesign((p) => ({
                      ...p,
                      collector: {
                        ...p.collector,
                        fontWeight: p.collector.fontWeight === 'bold' ? 'normal' : 'bold',
                      },
                    }))
                  }
                  className={`p-1.5 rounded border text-xs font-bold transition cursor-pointer ${
                    design.collector.fontWeight === 'bold'
                      ? 'bg-blue-100 text-blue-800 border-blue-300'
                      : 'bg-white text-neutral-700 border-neutral-300 hover:bg-neutral-100'
                  }`}
                  title="Toggle Bold"
                >
                  <Bold className="w-3.5 h-3.5" />
                </button>
                <button
                  type="button"
                  onClick={() =>
                    updateDesign((p) => ({
                      ...p,
                      collector: {
                        ...p.collector,
                        italic: !p.collector.italic,
                      },
                    }))
                  }
                  className={`p-1.5 rounded border text-xs font-bold transition cursor-pointer ${
                    design.collector.italic
                      ? 'bg-blue-100 text-blue-800 border-blue-300'
                      : 'bg-white text-neutral-700 border-neutral-300 hover:bg-neutral-100'
                  }`}
                  title="Toggle Italic"
                >
                  <Italic className="w-3.5 h-3.5" />
                </button>
                <button
                  type="button"
                  onClick={() =>
                    updateDesign((p) => ({
                      ...p,
                      collector: {
                        ...p.collector,
                        underline: !p.collector.underline,
                      },
                    }))
                  }
                  className={`p-1.5 rounded border text-xs font-bold transition cursor-pointer ${
                    design.collector.underline
                      ? 'bg-blue-100 text-blue-800 border-blue-300'
                      : 'bg-white text-neutral-700 border-neutral-300 hover:bg-neutral-100'
                  }`}
                  title="Toggle Underline"
                >
                  <UnderlineIcon className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>

            <div className="flex flex-col gap-1">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Label Color
              </span>
              <div className="flex items-center gap-1.5">
                <input
                  type="color"
                  value={design.collector.color || '#0B1E36'}
                  onChange={(e) => {
                    const val = e.target.value;
                    updateDesign((p) => ({
                      ...p,
                      collector: { ...p.collector, color: val },
                    }));
                  }}
                  className="w-7 h-7 p-0.5 border border-neutral-300 rounded cursor-pointer"
                />
                <span className="text-[11px] font-mono uppercase text-neutral-600">
                  {design.collector.color || '#0B1E36'}
                </span>
              </div>
            </div>

            <div className="flex flex-col gap-1">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Value Color
              </span>
              <div className="flex items-center gap-1.5">
                <input
                  type="color"
                  value={design.collector.valueColor || design.colors.text || '#0F172A'}
                  onChange={(e) => {
                    const val = e.target.value;
                    updateDesign((p) => ({
                      ...p,
                      collector: { ...p.collector, valueColor: val },
                    }));
                  }}
                  className="w-7 h-7 p-0.5 border border-neutral-300 rounded cursor-pointer"
                />
                <span className="text-[11px] font-mono uppercase text-neutral-600">
                  {design.collector.valueColor || design.colors.text || '#0F172A'}
                </span>
              </div>
            </div>

            <div className="flex flex-col gap-1">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Visibility
              </span>
              <button
                type="button"
                onClick={() =>
                  updateDesign((p) => ({
                    ...p,
                    collector: { ...p.collector, show: !p.collector.show },
                    visibility: { ...p.visibility, collector: !p.collector.show },
                  }))
                }
                className={`flex items-center gap-1 px-2.5 py-1 text-xs rounded border transition cursor-pointer ${
                  design.collector.show && design.visibility.collector
                    ? 'bg-blue-50 text-blue-700 border-blue-300 font-semibold'
                    : 'bg-white text-neutral-500 border-neutral-300'
                }`}
              >
                {design.collector.show && design.visibility.collector ? (
                  <Eye className="w-3.5 h-3.5" />
                ) : (
                  <EyeOff className="w-3.5 h-3.5" />
                )}
                <span>{design.collector.show && design.visibility.collector ? 'Visible' : 'Hidden'}</span>
              </button>
            </div>
          </>
        )}

        {/* 8. CUSTOMER INFO */}
        {selectedElement === 'customerInfo' && (
          <>
            <div className="flex flex-col gap-1 min-w-[150px]">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Section Header
              </span>
              <input
                type="text"
                value={design.customer.sectionTitle || 'Customer Information'}
                onChange={(e) => {
                  const val = e.target.value;
                  updateDesign((p) => ({
                    ...p,
                    customer: { ...p.customer, sectionTitle: val },
                  }));
                }}
                className="px-2 py-1 text-xs border border-neutral-300 rounded bg-white font-medium"
              />
            </div>

            <div className="flex flex-col gap-1">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Header Bg
              </span>
              <div className="flex items-center gap-1.5">
                <input
                  type="color"
                  value={design.colors.tableHeaderBackground || design.itemsTable.headerBgColor || '#0B1E36'}
                  onChange={(e) => {
                    const val = e.target.value;
                    updateDesign((p) => ({
                      ...p,
                      colors: { ...p.colors, tableHeaderBackground: val },
                      itemsTable: { ...p.itemsTable, headerBgColor: val },
                    }));
                  }}
                  className="w-7 h-7 p-0.5 border border-neutral-300 rounded cursor-pointer"
                />
                <span className="text-[11px] font-mono uppercase text-neutral-600">
                  {design.colors.tableHeaderBackground || design.itemsTable.headerBgColor || '#0B1E36'}
                </span>
              </div>
            </div>

            <FontFamilySelect
              value={design.customer.fontFamily || design.typography.fontFamily}
              onChange={(f) =>
                updateDesign((p) => ({
                  ...p,
                  customer: { ...p.customer, fontFamily: f },
                }))
              }
              label="Customer Font"
            />

            <div className="flex flex-col gap-1">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Font Size
              </span>
              <div className="flex items-center gap-1">
                <input
                  type="number"
                  min={8}
                  max={18}
                  step={0.5}
                  value={design.customer.fontSize || 12}
                  onChange={(e) => {
                    const val = Number(e.target.value);
                    updateDesign((p) => ({
                      ...p,
                      customer: { ...p.customer, fontSize: val },
                    }));
                  }}
                  className="w-14 px-1 py-1 text-xs text-center border border-neutral-300 rounded font-mono bg-white"
                />
                <span className="text-[10px] text-neutral-400">px</span>
              </div>
            </div>

            <div className="flex flex-col gap-1">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Text Color
              </span>
              <div className="flex items-center gap-1.5">
                <input
                  type="color"
                  value={design.customer.color || design.colors.text || '#0B1E36'}
                  onChange={(e) => {
                    const val = e.target.value;
                    updateDesign((p) => ({
                      ...p,
                      customer: { ...p.customer, color: val },
                    }));
                  }}
                  className="w-7 h-7 p-0.5 border border-neutral-300 rounded cursor-pointer"
                />
                <span className="text-[11px] font-mono uppercase text-neutral-600">
                  {design.customer.color || design.colors.text || '#0B1E36'}
                </span>
              </div>
            </div>

            <div className="flex flex-col gap-1">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Border
              </span>
              <div className="flex items-center gap-1.5">
                <input
                  type="color"
                  value={design.customer.borderColor || '#D8E2EC'}
                  onChange={(e) => {
                    const val = e.target.value;
                    updateDesign((p) => ({
                      ...p,
                      customer: { ...p.customer, borderColor: val },
                    }));
                  }}
                  className="w-7 h-7 p-0.5 border border-neutral-300 rounded cursor-pointer"
                />
                <span className="text-[11px] font-mono uppercase text-neutral-600">
                  {design.customer.borderColor || '#D8E2EC'}
                </span>
              </div>
            </div>

            <div className="flex flex-col gap-1">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Background
              </span>
              <div className="flex items-center gap-1.5">
                <input
                  type="color"
                  value={design.customer.backgroundColor || '#FFFFFF'}
                  onChange={(e) => {
                    const val = e.target.value;
                    updateDesign((p) => ({
                      ...p,
                      customer: { ...p.customer, backgroundColor: val },
                    }));
                  }}
                  className="w-7 h-7 p-0.5 border border-neutral-300 rounded cursor-pointer"
                />
                <span className="text-[11px] font-mono uppercase text-neutral-600">
                  {design.customer.backgroundColor || '#FFFFFF'}
                </span>
              </div>
            </div>

            <div className="flex flex-col gap-1">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Style
              </span>
              <div className="flex items-center gap-1">
                <button
                  type="button"
                  onClick={() =>
                    updateDesign((p) => ({
                      ...p,
                      customer: {
                        ...p.customer,
                        fontWeight: p.customer.fontWeight === 'bold' ? 'normal' : 'bold',
                      },
                    }))
                  }
                  className={`p-1.5 rounded border text-xs font-bold transition cursor-pointer ${
                    design.customer.fontWeight === 'bold'
                      ? 'bg-blue-100 text-blue-800 border-blue-300'
                      : 'bg-white text-neutral-700 border-neutral-300 hover:bg-neutral-100'
                  }`}
                  title="Toggle Bold"
                >
                  <Bold className="w-3.5 h-3.5" />
                </button>
                <button
                  type="button"
                  onClick={() =>
                    updateDesign((p) => ({
                      ...p,
                      customer: {
                        ...p.customer,
                        italic: !p.customer.italic,
                      },
                    }))
                  }
                  className={`p-1.5 rounded border text-xs font-bold transition cursor-pointer ${
                    design.customer.italic
                      ? 'bg-blue-100 text-blue-800 border-blue-300'
                      : 'bg-white text-neutral-700 border-neutral-300 hover:bg-neutral-100'
                  }`}
                  title="Toggle Italic"
                >
                  <Italic className="w-3.5 h-3.5" />
                </button>
                <button
                  type="button"
                  onClick={() =>
                    updateDesign((p) => ({
                      ...p,
                      customer: {
                        ...p.customer,
                        underline: !p.customer.underline,
                      },
                    }))
                  }
                  className={`p-1.5 rounded border text-xs font-bold transition cursor-pointer ${
                    design.customer.underline
                      ? 'bg-blue-100 text-blue-800 border-blue-300'
                      : 'bg-white text-neutral-700 border-neutral-300 hover:bg-neutral-100'
                  }`}
                  title="Toggle Underline"
                >
                  <UnderlineIcon className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          </>
        )}

        {/* 8b. CUSTOMER NAME */}
        {selectedElement === 'customerName' && (
          <>
            <div className="flex flex-col gap-1 min-w-[130px] flex-1">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Name Label
              </span>
              <input
                type="text"
                value={design.customer.nameLabel || 'Customer Name:'}
                onChange={(e) => {
                  const val = e.target.value;
                  updateDesign((p) => ({
                    ...p,
                    customer: { ...p.customer, nameLabel: val },
                  }));
                }}
                className="px-2 py-1 text-xs border border-neutral-300 rounded font-medium bg-white"
              />
            </div>

            <FontFamilySelect
              value={design.customer.nameFontFamily || design.customer.fontFamily}
              onChange={(f) =>
                updateDesign((p) => ({
                  ...p,
                  customer: { ...p.customer, nameFontFamily: f },
                }))
              }
            />

            <div className="flex flex-col gap-1">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Font Size
              </span>
              <div className="flex items-center gap-1">
                <input
                  type="number"
                  min={8}
                  max={20}
                  step={0.5}
                  value={design.customer.nameFontSize || design.customer.fontSize || 12}
                  onChange={(e) => {
                    const val = Number(e.target.value);
                    updateDesign((p) => ({
                      ...p,
                      customer: { ...p.customer, nameFontSize: val },
                    }));
                  }}
                  className="w-14 px-1 py-1 text-xs text-center border border-neutral-300 rounded font-mono bg-white"
                />
                <span className="text-[10px] text-neutral-400">px</span>
              </div>
            </div>

            <div className="flex flex-col gap-1">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Style
              </span>
              <div className="flex items-center gap-1">
                <button
                  type="button"
                  onClick={() =>
                    updateDesign((p) => ({
                      ...p,
                      customer: {
                        ...p.customer,
                        nameFontWeight: (p.customer.nameFontWeight || p.customer.fontWeight) === 'bold' ? 'normal' : 'bold',
                      },
                    }))
                  }
                  className={`p-1.5 rounded border text-xs font-bold transition cursor-pointer ${
                    (design.customer.nameFontWeight || design.customer.fontWeight) === 'bold'
                      ? 'bg-blue-100 text-blue-800 border-blue-300'
                      : 'bg-white text-neutral-700 border-neutral-300 hover:bg-neutral-100'
                  }`}
                  title="Toggle Bold"
                >
                  <Bold className="w-3.5 h-3.5" />
                </button>
                <button
                  type="button"
                  onClick={() =>
                    updateDesign((p) => ({
                      ...p,
                      customer: {
                        ...p.customer,
                        nameItalic: !(p.customer as any).nameItalic,
                      },
                    }))
                  }
                  className={`p-1.5 rounded border text-xs font-bold transition cursor-pointer ${
                    (design.customer as any).nameItalic
                      ? 'bg-blue-100 text-blue-800 border-blue-300'
                      : 'bg-white text-neutral-700 border-neutral-300 hover:bg-neutral-100'
                  }`}
                  title="Toggle Italic"
                >
                  <Italic className="w-3.5 h-3.5" />
                </button>
                <button
                  type="button"
                  onClick={() =>
                    updateDesign((p) => ({
                      ...p,
                      customer: {
                        ...p.customer,
                        nameUnderline: !(p.customer as any).nameUnderline,
                      },
                    }))
                  }
                  className={`p-1.5 rounded border text-xs font-bold transition cursor-pointer ${
                    (design.customer as any).nameUnderline
                      ? 'bg-blue-100 text-blue-800 border-blue-300'
                      : 'bg-white text-neutral-700 border-neutral-300 hover:bg-neutral-100'
                  }`}
                  title="Toggle Underline"
                >
                  <UnderlineIcon className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>

            <div className="flex flex-col gap-1">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Label Color
              </span>
              <div className="flex items-center gap-1.5">
                <input
                  type="color"
                  value={design.customer.nameLabelColor || design.customer.color || '#0B1E36'}
                  onChange={(e) => {
                    const val = e.target.value;
                    updateDesign((p) => ({
                      ...p,
                      customer: { ...p.customer, nameLabelColor: val },
                    }));
                  }}
                  className="w-7 h-7 p-0.5 border border-neutral-300 rounded cursor-pointer"
                />
                <span className="text-[11px] font-mono uppercase text-neutral-600">
                  {design.customer.nameLabelColor || design.customer.color || '#0B1E36'}
                </span>
              </div>
            </div>

            <div className="flex flex-col gap-1">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Value Color
              </span>
              <div className="flex items-center gap-1.5">
                <input
                  type="color"
                  value={design.customer.nameValueColor || '#0F172A'}
                  onChange={(e) => {
                    const val = e.target.value;
                    updateDesign((p) => ({
                      ...p,
                      customer: { ...p.customer, nameValueColor: val },
                    }));
                  }}
                  className="w-7 h-7 p-0.5 border border-neutral-300 rounded cursor-pointer"
                />
                <span className="text-[11px] font-mono uppercase text-neutral-600">
                  {design.customer.nameValueColor || '#0F172A'}
                </span>
              </div>
            </div>

            <div className="flex flex-col gap-1">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Visibility
              </span>
              <button
                type="button"
                onClick={() =>
                  updateDesign((p) => ({
                    ...p,
                    customer: { ...p.customer, showName: !p.customer.showName },
                  }))
                }
                className={`flex items-center gap-1 px-2.5 py-1 text-xs rounded border transition cursor-pointer ${
                  design.customer.showName !== false
                    ? 'bg-blue-50 text-blue-700 border-blue-300 font-semibold'
                    : 'bg-white text-neutral-500 border-neutral-300'
                }`}
              >
                {design.customer.showName !== false ? <Eye className="w-3.5 h-3.5" /> : <EyeOff className="w-3.5 h-3.5" />}
                <span>{design.customer.showName !== false ? 'Visible' : 'Hidden'}</span>
              </button>
            </div>
          </>
        )}

        {/* 8c. CUSTOMER PHONE */}
        {selectedElement === 'customerPhone' && (
          <>
            <div className="flex flex-col gap-1 min-w-[130px] flex-1">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Phone Label
              </span>
              <input
                type="text"
                value={design.customer.phoneLabel || 'Phone:'}
                onChange={(e) => {
                  const val = e.target.value;
                  updateDesign((p) => ({
                    ...p,
                    customer: { ...p.customer, phoneLabel: val },
                  }));
                }}
                className="px-2 py-1 text-xs border border-neutral-300 rounded font-medium bg-white"
              />
            </div>

            <FontFamilySelect
              value={design.customer.phoneFontFamily || design.customer.fontFamily}
              onChange={(f) =>
                updateDesign((p) => ({
                  ...p,
                  customer: { ...p.customer, phoneFontFamily: f },
                }))
              }
            />

            <div className="flex flex-col gap-1">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Font Size
              </span>
              <div className="flex items-center gap-1">
                <input
                  type="number"
                  min={8}
                  max={20}
                  step={0.5}
                  value={design.customer.phoneFontSize || design.customer.fontSize || 12}
                  onChange={(e) => {
                    const val = Number(e.target.value);
                    updateDesign((p) => ({
                      ...p,
                      customer: { ...p.customer, phoneFontSize: val },
                    }));
                  }}
                  className="w-14 px-1 py-1 text-xs text-center border border-neutral-300 rounded font-mono bg-white"
                />
                <span className="text-[10px] text-neutral-400">px</span>
              </div>
            </div>

            <div className="flex flex-col gap-1">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Style
              </span>
              <div className="flex items-center gap-1">
                <button
                  type="button"
                  onClick={() =>
                    updateDesign((p) => ({
                      ...p,
                      customer: {
                        ...p.customer,
                        phoneFontWeight: (p.customer.phoneFontWeight || p.customer.fontWeight) === 'bold' ? 'normal' : 'bold',
                      },
                    }))
                  }
                  className={`p-1.5 rounded border text-xs font-bold transition cursor-pointer ${
                    (design.customer.phoneFontWeight || design.customer.fontWeight) === 'bold'
                      ? 'bg-blue-100 text-blue-800 border-blue-300'
                      : 'bg-white text-neutral-700 border-neutral-300 hover:bg-neutral-100'
                  }`}
                  title="Toggle Bold"
                >
                  <Bold className="w-3.5 h-3.5" />
                </button>
                <button
                  type="button"
                  onClick={() =>
                    updateDesign((p) => ({
                      ...p,
                      customer: {
                        ...p.customer,
                        phoneItalic: !p.customer.phoneItalic,
                      },
                    }))
                  }
                  className={`p-1.5 rounded border text-xs font-bold transition cursor-pointer ${
                    design.customer.phoneItalic
                      ? 'bg-blue-100 text-blue-800 border-blue-300'
                      : 'bg-white text-neutral-700 border-neutral-300 hover:bg-neutral-100'
                  }`}
                  title="Toggle Italic"
                >
                  <Italic className="w-3.5 h-3.5" />
                </button>
                <button
                  type="button"
                  onClick={() =>
                    updateDesign((p) => ({
                      ...p,
                      customer: {
                        ...p.customer,
                        phoneUnderline: !p.customer.phoneUnderline,
                      },
                    }))
                  }
                  className={`p-1.5 rounded border text-xs font-bold transition cursor-pointer ${
                    design.customer.phoneUnderline
                      ? 'bg-blue-100 text-blue-800 border-blue-300'
                      : 'bg-white text-neutral-700 border-neutral-300 hover:bg-neutral-100'
                  }`}
                  title="Toggle Underline"
                >
                  <UnderlineIcon className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>

            <div className="flex flex-col gap-1">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Label Color
              </span>
              <div className="flex items-center gap-1.5">
                <input
                  type="color"
                  value={design.customer.phoneLabelColor || design.customer.color || '#0B1E36'}
                  onChange={(e) => {
                    const val = e.target.value;
                    updateDesign((p) => ({
                      ...p,
                      customer: { ...p.customer, phoneLabelColor: val },
                    }));
                  }}
                  className="w-7 h-7 p-0.5 border border-neutral-300 rounded cursor-pointer"
                />
                <span className="text-[11px] font-mono uppercase text-neutral-600">
                  {design.customer.phoneLabelColor || design.customer.color || '#0B1E36'}
                </span>
              </div>
            </div>

            <div className="flex flex-col gap-1">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Value Color
              </span>
              <div className="flex items-center gap-1.5">
                <input
                  type="color"
                  value={design.customer.phoneValueColor || '#0F172A'}
                  onChange={(e) => {
                    const val = e.target.value;
                    updateDesign((p) => ({
                      ...p,
                      customer: { ...p.customer, phoneValueColor: val },
                    }));
                  }}
                  className="w-7 h-7 p-0.5 border border-neutral-300 rounded cursor-pointer"
                />
                <span className="text-[11px] font-mono uppercase text-neutral-600">
                  {design.customer.phoneValueColor || '#0F172A'}
                </span>
              </div>
            </div>

            <div className="flex flex-col gap-1">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Visibility
              </span>
              <button
                type="button"
                onClick={() =>
                  updateDesign((p) => ({
                    ...p,
                    customer: { ...p.customer, showPhone: !p.customer.showPhone },
                  }))
                }
                className={`flex items-center gap-1 px-2.5 py-1 text-xs rounded border transition cursor-pointer ${
                  design.customer.showPhone !== false
                    ? 'bg-blue-50 text-blue-700 border-blue-300 font-semibold'
                    : 'bg-white text-neutral-500 border-neutral-300'
                }`}
              >
                {design.customer.showPhone !== false ? <Eye className="w-3.5 h-3.5" /> : <EyeOff className="w-3.5 h-3.5" />}
                <span>{design.customer.showPhone !== false ? 'Visible' : 'Hidden'}</span>
              </button>
            </div>
          </>
        )}

        {/* 8d. CUSTOMER ADDRESS */}
        {selectedElement === 'customerAddress' && (
          <>
            <div className="flex flex-col gap-1 min-w-[130px] flex-1">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Address Label
              </span>
              <input
                type="text"
                value={design.customer.addressLabel || 'Address:'}
                onChange={(e) => {
                  const val = e.target.value;
                  updateDesign((p) => ({
                    ...p,
                    customer: { ...p.customer, addressLabel: val },
                  }));
                }}
                className="px-2 py-1 text-xs border border-neutral-300 rounded font-medium bg-white"
              />
            </div>

            <FontFamilySelect
              value={design.customer.addressFontFamily || design.customer.fontFamily}
              onChange={(f) =>
                updateDesign((p) => ({
                  ...p,
                  customer: { ...p.customer, addressFontFamily: f },
                }))
              }
            />

            <div className="flex flex-col gap-1">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Font Size
              </span>
              <div className="flex items-center gap-1">
                <input
                  type="number"
                  min={8}
                  max={20}
                  step={0.5}
                  value={design.customer.addressFontSize || design.customer.fontSize || 12}
                  onChange={(e) => {
                    const val = Number(e.target.value);
                    updateDesign((p) => ({
                      ...p,
                      customer: { ...p.customer, addressFontSize: val },
                    }));
                  }}
                  className="w-14 px-1 py-1 text-xs text-center border border-neutral-300 rounded font-mono bg-white"
                />
                <span className="text-[10px] text-neutral-400">px</span>
              </div>
            </div>

            <div className="flex flex-col gap-1">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Style
              </span>
              <div className="flex items-center gap-1">
                <button
                  type="button"
                  onClick={() =>
                    updateDesign((p) => ({
                      ...p,
                      customer: {
                        ...p.customer,
                        addressFontWeight: (p.customer.addressFontWeight || p.customer.fontWeight) === 'bold' ? 'normal' : 'bold',
                      },
                    }))
                  }
                  className={`p-1.5 rounded border text-xs font-bold transition cursor-pointer ${
                    (design.customer.addressFontWeight || design.customer.fontWeight) === 'bold'
                      ? 'bg-blue-100 text-blue-800 border-blue-300'
                      : 'bg-white text-neutral-700 border-neutral-300 hover:bg-neutral-100'
                  }`}
                  title="Toggle Bold"
                >
                  <Bold className="w-3.5 h-3.5" />
                </button>
                <button
                  type="button"
                  onClick={() =>
                    updateDesign((p) => ({
                      ...p,
                      customer: {
                        ...p.customer,
                        addressItalic: !p.customer.addressItalic,
                      },
                    }))
                  }
                  className={`p-1.5 rounded border text-xs font-bold transition cursor-pointer ${
                    design.customer.addressItalic
                      ? 'bg-blue-100 text-blue-800 border-blue-300'
                      : 'bg-white text-neutral-700 border-neutral-300 hover:bg-neutral-100'
                  }`}
                  title="Toggle Italic"
                >
                  <Italic className="w-3.5 h-3.5" />
                </button>
                <button
                  type="button"
                  onClick={() =>
                    updateDesign((p) => ({
                      ...p,
                      customer: {
                        ...p.customer,
                        addressUnderline: !p.customer.addressUnderline,
                      },
                    }))
                  }
                  className={`p-1.5 rounded border text-xs font-bold transition cursor-pointer ${
                    design.customer.addressUnderline
                      ? 'bg-blue-100 text-blue-800 border-blue-300'
                      : 'bg-white text-neutral-700 border-neutral-300 hover:bg-neutral-100'
                  }`}
                  title="Toggle Underline"
                >
                  <UnderlineIcon className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>

            <div className="flex flex-col gap-1">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Label Color
              </span>
              <div className="flex items-center gap-1.5">
                <input
                  type="color"
                  value={design.customer.addressLabelColor || design.customer.color || '#0B1E36'}
                  onChange={(e) => {
                    const val = e.target.value;
                    updateDesign((p) => ({
                      ...p,
                      customer: { ...p.customer, addressLabelColor: val },
                    }));
                  }}
                  className="w-7 h-7 p-0.5 border border-neutral-300 rounded cursor-pointer"
                />
                <span className="text-[11px] font-mono uppercase text-neutral-600">
                  {design.customer.addressLabelColor || design.customer.color || '#0B1E36'}
                </span>
              </div>
            </div>

            <div className="flex flex-col gap-1">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Value Color
              </span>
              <div className="flex items-center gap-1.5">
                <input
                  type="color"
                  value={design.customer.addressValueColor || '#0F172A'}
                  onChange={(e) => {
                    const val = e.target.value;
                    updateDesign((p) => ({
                      ...p,
                      customer: { ...p.customer, addressValueColor: val },
                    }));
                  }}
                  className="w-7 h-7 p-0.5 border border-neutral-300 rounded cursor-pointer"
                />
                <span className="text-[11px] font-mono uppercase text-neutral-600">
                  {design.customer.addressValueColor || '#0F172A'}
                </span>
              </div>
            </div>

            <div className="flex flex-col gap-1">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Visibility
              </span>
              <button
                type="button"
                onClick={() =>
                  updateDesign((p) => ({
                    ...p,
                    customer: { ...p.customer, showAddress: !p.customer.showAddress },
                  }))
                }
                className={`flex items-center gap-1 px-2.5 py-1 text-xs rounded border transition cursor-pointer ${
                  design.customer.showAddress !== false
                    ? 'bg-blue-50 text-blue-700 border-blue-300 font-semibold'
                    : 'bg-white text-neutral-500 border-neutral-300'
                }`}
              >
                {design.customer.showAddress !== false ? <Eye className="w-3.5 h-3.5" /> : <EyeOff className="w-3.5 h-3.5" />}
                <span>{design.customer.showAddress !== false ? 'Visible' : 'Hidden'}</span>
              </button>
            </div>
          </>
        )}

        {/* 8e. CUSTOMER EMAIL */}
        {selectedElement === 'customerEmail' && (
          <>
            <div className="flex flex-col gap-1 min-w-[130px] flex-1">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Email Label
              </span>
              <input
                type="text"
                value={design.customer.emailLabel || 'Email:'}
                onChange={(e) => {
                  const val = e.target.value;
                  updateDesign((p) => ({
                    ...p,
                    customer: { ...p.customer, emailLabel: val },
                  }));
                }}
                className="px-2 py-1 text-xs border border-neutral-300 rounded font-medium bg-white"
              />
            </div>

            <FontFamilySelect
              value={design.customer.emailFontFamily || design.customer.fontFamily}
              onChange={(f) =>
                updateDesign((p) => ({
                  ...p,
                  customer: { ...p.customer, emailFontFamily: f },
                }))
              }
            />

            <div className="flex flex-col gap-1">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Font Size
              </span>
              <div className="flex items-center gap-1">
                <input
                  type="number"
                  min={8}
                  max={20}
                  step={0.5}
                  value={design.customer.emailFontSize || design.customer.fontSize || 12}
                  onChange={(e) => {
                    const val = Number(e.target.value);
                    updateDesign((p) => ({
                      ...p,
                      customer: { ...p.customer, emailFontSize: val },
                    }));
                  }}
                  className="w-14 px-1 py-1 text-xs text-center border border-neutral-300 rounded font-mono bg-white"
                />
                <span className="text-[10px] text-neutral-400">px</span>
              </div>
            </div>

            <div className="flex flex-col gap-1">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Style
              </span>
              <div className="flex items-center gap-1">
                <button
                  type="button"
                  onClick={() =>
                    updateDesign((p) => ({
                      ...p,
                      customer: {
                        ...p.customer,
                        emailFontWeight: (p.customer.emailFontWeight || p.customer.fontWeight) === 'bold' ? 'normal' : 'bold',
                      },
                    }))
                  }
                  className={`p-1.5 rounded border text-xs font-bold transition cursor-pointer ${
                    (design.customer.emailFontWeight || design.customer.fontWeight) === 'bold'
                      ? 'bg-blue-100 text-blue-800 border-blue-300'
                      : 'bg-white text-neutral-700 border-neutral-300 hover:bg-neutral-100'
                  }`}
                  title="Toggle Bold"
                >
                  <Bold className="w-3.5 h-3.5" />
                </button>
                <button
                  type="button"
                  onClick={() =>
                    updateDesign((p) => ({
                      ...p,
                      customer: {
                        ...p.customer,
                        emailItalic: !p.customer.emailItalic,
                      },
                    }))
                  }
                  className={`p-1.5 rounded border text-xs font-bold transition cursor-pointer ${
                    design.customer.emailItalic
                      ? 'bg-blue-100 text-blue-800 border-blue-300'
                      : 'bg-white text-neutral-700 border-neutral-300 hover:bg-neutral-100'
                  }`}
                  title="Toggle Italic"
                >
                  <Italic className="w-3.5 h-3.5" />
                </button>
                <button
                  type="button"
                  onClick={() =>
                    updateDesign((p) => ({
                      ...p,
                      customer: {
                        ...p.customer,
                        emailUnderline: !p.customer.emailUnderline,
                      },
                    }))
                  }
                  className={`p-1.5 rounded border text-xs font-bold transition cursor-pointer ${
                    design.customer.emailUnderline
                      ? 'bg-blue-100 text-blue-800 border-blue-300'
                      : 'bg-white text-neutral-700 border-neutral-300 hover:bg-neutral-100'
                  }`}
                  title="Toggle Underline"
                >
                  <UnderlineIcon className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>

            <div className="flex flex-col gap-1">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Label Color
              </span>
              <div className="flex items-center gap-1.5">
                <input
                  type="color"
                  value={design.customer.emailLabelColor || design.customer.color || '#0B1E36'}
                  onChange={(e) => {
                    const val = e.target.value;
                    updateDesign((p) => ({
                      ...p,
                      customer: { ...p.customer, emailLabelColor: val },
                    }));
                  }}
                  className="w-7 h-7 p-0.5 border border-neutral-300 rounded cursor-pointer"
                />
                <span className="text-[11px] font-mono uppercase text-neutral-600">
                  {design.customer.emailLabelColor || design.customer.color || '#0B1E36'}
                </span>
              </div>
            </div>

            <div className="flex flex-col gap-1">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Value Color
              </span>
              <div className="flex items-center gap-1.5">
                <input
                  type="color"
                  value={design.customer.emailValueColor || '#0F172A'}
                  onChange={(e) => {
                    const val = e.target.value;
                    updateDesign((p) => ({
                      ...p,
                      customer: { ...p.customer, emailValueColor: val },
                    }));
                  }}
                  className="w-7 h-7 p-0.5 border border-neutral-300 rounded cursor-pointer"
                />
                <span className="text-[11px] font-mono uppercase text-neutral-600">
                  {design.customer.emailValueColor || '#0F172A'}
                </span>
              </div>
            </div>

            <div className="flex flex-col gap-1">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Visibility
              </span>
              <button
                type="button"
                onClick={() =>
                  updateDesign((p) => ({
                    ...p,
                    customer: { ...p.customer, showEmail: !p.customer.showEmail },
                  }))
                }
                className={`flex items-center gap-1 px-2.5 py-1 text-xs rounded border transition cursor-pointer ${
                  design.customer.showEmail !== false
                    ? 'bg-blue-50 text-blue-700 border-blue-300 font-semibold'
                    : 'bg-white text-neutral-500 border-neutral-300'
                }`}
              >
                {design.customer.showEmail !== false ? <Eye className="w-3.5 h-3.5" /> : <EyeOff className="w-3.5 h-3.5" />}
                <span>{design.customer.showEmail !== false ? 'Visible' : 'Hidden'}</span>
              </button>
            </div>
          </>
        )}

        {/* 8f. CUSTOMER COMPANY */}
        {selectedElement === 'customerCompany' && (
          <>
            <div className="flex flex-col gap-1 min-w-[130px] flex-1">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Company Label
              </span>
              <input
                type="text"
                value={design.customer.companyLabel || 'Company:'}
                onChange={(e) => {
                  const val = e.target.value;
                  updateDesign((p) => ({
                    ...p,
                    customer: { ...p.customer, companyLabel: val },
                  }));
                }}
                className="px-2 py-1 text-xs border border-neutral-300 rounded font-medium bg-white"
              />
            </div>

            <FontFamilySelect
              value={design.customer.companyFontFamily || design.customer.fontFamily}
              onChange={(f) =>
                updateDesign((p) => ({
                  ...p,
                  customer: { ...p.customer, companyFontFamily: f },
                }))
              }
              label="Font"
            />

            <div className="flex flex-col gap-1">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Font Size
              </span>
              <div className="flex items-center gap-1">
                <input
                  type="number"
                  min={8}
                  max={20}
                  step={0.5}
                  value={design.customer.companyFontSize || design.customer.fontSize || 12}
                  onChange={(e) => {
                    const val = Number(e.target.value);
                    updateDesign((p) => ({
                      ...p,
                      customer: { ...p.customer, companyFontSize: val },
                    }));
                  }}
                  className="w-14 px-1 py-1 text-xs text-center border border-neutral-300 rounded font-mono bg-white"
                />
                <span className="text-[10px] text-neutral-400">px</span>
              </div>
            </div>

            <div className="flex flex-col gap-1">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Style
              </span>
              <div className="flex items-center gap-1">
                <button
                  type="button"
                  onClick={() =>
                    updateDesign((p) => ({
                      ...p,
                      customer: {
                        ...p.customer,
                        companyFontWeight: (p.customer.companyFontWeight || p.customer.fontWeight) === 'bold' ? 'normal' : 'bold',
                      },
                    }))
                  }
                  className={`p-1.5 rounded border text-xs font-bold transition cursor-pointer ${
                    (design.customer.companyFontWeight || design.customer.fontWeight) === 'bold'
                      ? 'bg-blue-100 text-blue-800 border-blue-300'
                      : 'bg-white text-neutral-700 border-neutral-300 hover:bg-neutral-100'
                  }`}
                  title="Toggle Bold"
                >
                  <Bold className="w-3.5 h-3.5" />
                </button>
                <button
                  type="button"
                  onClick={() =>
                    updateDesign((p) => ({
                      ...p,
                      customer: {
                        ...p.customer,
                        companyItalic: !p.customer.companyItalic,
                      },
                    }))
                  }
                  className={`p-1.5 rounded border text-xs font-bold transition cursor-pointer ${
                    design.customer.companyItalic
                      ? 'bg-blue-100 text-blue-800 border-blue-300'
                      : 'bg-white text-neutral-700 border-neutral-300 hover:bg-neutral-100'
                  }`}
                  title="Toggle Italic"
                >
                  <Italic className="w-3.5 h-3.5" />
                </button>
                <button
                  type="button"
                  onClick={() =>
                    updateDesign((p) => ({
                      ...p,
                      customer: {
                        ...p.customer,
                        companyUnderline: !p.customer.companyUnderline,
                      },
                    }))
                  }
                  className={`p-1.5 rounded border text-xs font-bold transition cursor-pointer ${
                    design.customer.companyUnderline
                      ? 'bg-blue-100 text-blue-800 border-blue-300'
                      : 'bg-white text-neutral-700 border-neutral-300 hover:bg-neutral-100'
                  }`}
                  title="Toggle Underline"
                >
                  <UnderlineIcon className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>

            <div className="flex flex-col gap-1">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Label Color
              </span>
              <div className="flex items-center gap-1.5">
                <input
                  type="color"
                  value={design.customer.companyColor || design.customer.color || '#0B1E36'}
                  onChange={(e) => {
                    const val = e.target.value;
                    updateDesign((p) => ({
                      ...p,
                      customer: { ...p.customer, companyColor: val },
                    }));
                  }}
                  className="w-7 h-7 p-0.5 border border-neutral-300 rounded cursor-pointer"
                />
                <span className="text-[11px] font-mono uppercase text-neutral-600">
                  {design.customer.companyColor || design.customer.color || '#0B1E36'}
                </span>
              </div>
            </div>

            <div className="flex flex-col gap-1">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Value Color
              </span>
              <div className="flex items-center gap-1.5">
                <input
                  type="color"
                  value={design.customer.companyValueColor || '#0F172A'}
                  onChange={(e) => {
                    const val = e.target.value;
                    updateDesign((p) => ({
                      ...p,
                      customer: { ...p.customer, companyValueColor: val },
                    }));
                  }}
                  className="w-7 h-7 p-0.5 border border-neutral-300 rounded cursor-pointer"
                />
                <span className="text-[11px] font-mono uppercase text-neutral-600">
                  {design.customer.companyValueColor || '#0F172A'}
                </span>
              </div>
            </div>

            <div className="flex flex-col gap-1">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Visibility
              </span>
              <button
                type="button"
                onClick={() =>
                  updateDesign((p) => ({
                    ...p,
                    customer: { ...p.customer, showCompany: !p.customer.showCompany },
                  }))
                }
                className={`flex items-center gap-1 px-2.5 py-1 text-xs rounded border transition cursor-pointer ${
                  design.customer.showCompany
                    ? 'bg-blue-50 text-blue-700 border-blue-300 font-semibold'
                    : 'bg-white text-neutral-500 border-neutral-300'
                }`}
              >
                {design.customer.showCompany ? <Eye className="w-3.5 h-3.5" /> : <EyeOff className="w-3.5 h-3.5" />}
                <span>{design.customer.showCompany ? 'Visible' : 'Hidden'}</span>
              </button>
            </div>
          </>
        )}

        {/* 8g. CUSTOMER ID */}
        {selectedElement === 'customerId' && (
          <>
            <div className="flex flex-col gap-1 min-w-[130px] flex-1">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                ID Label
              </span>
              <input
                type="text"
                value={design.customer.customerIdLabel || 'Customer ID:'}
                onChange={(e) => {
                  const val = e.target.value;
                  updateDesign((p) => ({
                    ...p,
                    customer: { ...p.customer, customerIdLabel: val },
                  }));
                }}
                className="px-2 py-1 text-xs border border-neutral-300 rounded font-medium bg-white"
              />
            </div>

            <FontFamilySelect
              value={design.customer.customerIdFontFamily || design.customer.fontFamily}
              onChange={(f) =>
                updateDesign((p) => ({
                  ...p,
                  customer: { ...p.customer, customerIdFontFamily: f },
                }))
              }
              label="Font"
            />

            <div className="flex flex-col gap-1">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Font Size
              </span>
              <div className="flex items-center gap-1">
                <input
                  type="number"
                  min={8}
                  max={20}
                  step={0.5}
                  value={design.customer.customerIdFontSize || design.customer.fontSize || 12}
                  onChange={(e) => {
                    const val = Number(e.target.value);
                    updateDesign((p) => ({
                      ...p,
                      customer: { ...p.customer, customerIdFontSize: val },
                    }));
                  }}
                  className="w-14 px-1 py-1 text-xs text-center border border-neutral-300 rounded font-mono bg-white"
                />
                <span className="text-[10px] text-neutral-400">px</span>
              </div>
            </div>

            <div className="flex flex-col gap-1">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Style
              </span>
              <div className="flex items-center gap-1">
                <button
                  type="button"
                  onClick={() =>
                    updateDesign((p) => ({
                      ...p,
                      customer: {
                        ...p.customer,
                        customerIdFontWeight: (p.customer.customerIdFontWeight || p.customer.fontWeight) === 'bold' ? 'normal' : 'bold',
                      },
                    }))
                  }
                  className={`p-1.5 rounded border text-xs font-bold transition cursor-pointer ${
                    (design.customer.customerIdFontWeight || design.customer.fontWeight) === 'bold'
                      ? 'bg-blue-100 text-blue-800 border-blue-300'
                      : 'bg-white text-neutral-700 border-neutral-300 hover:bg-neutral-100'
                  }`}
                  title="Toggle Bold"
                >
                  <Bold className="w-3.5 h-3.5" />
                </button>
                <button
                  type="button"
                  onClick={() =>
                    updateDesign((p) => ({
                      ...p,
                      customer: {
                        ...p.customer,
                        customerIdItalic: !p.customer.customerIdItalic,
                      },
                    }))
                  }
                  className={`p-1.5 rounded border text-xs font-bold transition cursor-pointer ${
                    design.customer.customerIdItalic
                      ? 'bg-blue-100 text-blue-800 border-blue-300'
                      : 'bg-white text-neutral-700 border-neutral-300 hover:bg-neutral-100'
                  }`}
                  title="Toggle Italic"
                >
                  <Italic className="w-3.5 h-3.5" />
                </button>
                <button
                  type="button"
                  onClick={() =>
                    updateDesign((p) => ({
                      ...p,
                      customer: {
                        ...p.customer,
                        customerIdUnderline: !p.customer.customerIdUnderline,
                      },
                    }))
                  }
                  className={`p-1.5 rounded border text-xs font-bold transition cursor-pointer ${
                    design.customer.customerIdUnderline
                      ? 'bg-blue-100 text-blue-800 border-blue-300'
                      : 'bg-white text-neutral-700 border-neutral-300 hover:bg-neutral-100'
                  }`}
                  title="Toggle Underline"
                >
                  <UnderlineIcon className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>

            <div className="flex flex-col gap-1">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Label Color
              </span>
              <div className="flex items-center gap-1.5">
                <input
                  type="color"
                  value={design.customer.customerIdColor || design.customer.color || '#0B1E36'}
                  onChange={(e) => {
                    const val = e.target.value;
                    updateDesign((p) => ({
                      ...p,
                      customer: { ...p.customer, customerIdColor: val },
                    }));
                  }}
                  className="w-7 h-7 p-0.5 border border-neutral-300 rounded cursor-pointer"
                />
                <span className="text-[11px] font-mono uppercase text-neutral-600">
                  {design.customer.customerIdColor || design.customer.color || '#0B1E36'}
                </span>
              </div>
            </div>

            <div className="flex flex-col gap-1">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Value Color
              </span>
              <div className="flex items-center gap-1.5">
                <input
                  type="color"
                  value={design.customer.customerIdValueColor || '#0F172A'}
                  onChange={(e) => {
                    const val = e.target.value;
                    updateDesign((p) => ({
                      ...p,
                      customer: { ...p.customer, customerIdValueColor: val },
                    }));
                  }}
                  className="w-7 h-7 p-0.5 border border-neutral-300 rounded cursor-pointer"
                />
                <span className="text-[11px] font-mono uppercase text-neutral-600">
                  {design.customer.customerIdValueColor || '#0F172A'}
                </span>
              </div>
            </div>

            <div className="flex flex-col gap-1">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Visibility
              </span>
              <button
                type="button"
                onClick={() =>
                  updateDesign((p) => ({
                    ...p,
                    customer: { ...p.customer, showCustomerId: !p.customer.showCustomerId },
                  }))
                }
                className={`flex items-center gap-1 px-2.5 py-1 text-xs rounded border transition cursor-pointer ${
                  design.customer.showCustomerId
                    ? 'bg-blue-50 text-blue-700 border-blue-300 font-semibold'
                    : 'bg-white text-neutral-500 border-neutral-300'
                }`}
              >
                {design.customer.showCustomerId ? <Eye className="w-3.5 h-3.5" /> : <EyeOff className="w-3.5 h-3.5" />}
                <span>{design.customer.showCustomerId ? 'Visible' : 'Hidden'}</span>
              </button>
            </div>
          </>
        )}

        {/* 9. ITEMS TABLE */}
        {selectedElement === 'itemsTable' && (
          <>
            <div className="flex flex-col gap-1">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Table Background
              </span>
              <div className="flex items-center gap-1.5">
                <input
                  type="color"
                  value={design.itemsTable.backgroundColor || '#FFFFFF'}
                  onChange={(e) => {
                    const val = e.target.value;
                    updateDesign((p) => ({
                      ...p,
                      itemsTable: { ...p.itemsTable, backgroundColor: val },
                    }));
                  }}
                  className="w-7 h-7 p-0.5 border border-neutral-300 rounded cursor-pointer"
                />
                <span className="text-[11px] font-mono uppercase text-neutral-600">
                  {design.itemsTable.backgroundColor || '#FFFFFF'}
                </span>
              </div>
            </div>

            <div className="flex flex-col gap-1">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Table Border Color
              </span>
              <div className="flex items-center gap-1.5">
                <input
                  type="color"
                  value={design.itemsTable.tableBorderColor || design.itemsTable.borderColor || '#D8E2EC'}
                  onChange={(e) => {
                    const val = e.target.value;
                    updateDesign((p) => ({
                      ...p,
                      itemsTable: {
                        ...p.itemsTable,
                        borderColor: val,
                        tableBorderColor: val,
                      },
                    }));
                  }}
                  className="w-7 h-7 p-0.5 border border-neutral-300 rounded cursor-pointer"
                />
                <span className="text-[11px] font-mono uppercase text-neutral-600">
                  {design.itemsTable.tableBorderColor || design.itemsTable.borderColor || '#D8E2EC'}
                </span>
              </div>
            </div>

            <div className="flex flex-col gap-1">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Border Style
              </span>
              <select
                value={design.itemsTable.tableBorderStyle || 'solid'}
                onChange={(e) => {
                  const val = e.target.value as 'none' | 'solid' | 'dashed';
                  updateDesign((p) => ({
                    ...p,
                    itemsTable: { ...p.itemsTable, tableBorderStyle: val },
                  }));
                }}
                className="px-2 py-1 text-xs border border-neutral-300 rounded bg-white font-medium"
              >
                <option value="solid">Solid</option>
                <option value="dashed">Dashed</option>
                <option value="none">None</option>
              </select>
            </div>

            <div className="flex flex-col gap-1">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Border Width
              </span>
              <div className="flex items-center gap-1">
                <input
                  type="number"
                  min={0}
                  max={10}
                  step={0.5}
                  value={design.itemsTable.tableBorderWidth ?? 1}
                  onChange={(e) => {
                    const val = Math.max(0, Number(e.target.value));
                    updateDesign((p) => ({
                      ...p,
                      itemsTable: { ...p.itemsTable, tableBorderWidth: val },
                    }));
                  }}
                  className="w-14 px-1.5 py-1 text-xs text-center border border-neutral-300 rounded font-mono bg-white"
                />
                <span className="text-[10px] text-neutral-400">px</span>
              </div>
            </div>

            <div className="flex flex-col gap-1">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Border Radius
              </span>
              <div className="flex items-center gap-1">
                <input
                  type="number"
                  min={0}
                  max={24}
                  step={1}
                  value={design.itemsTable.tableBorderRadius ?? 4}
                  onChange={(e) => {
                    const val = Math.max(0, Number(e.target.value));
                    updateDesign((p) => ({
                      ...p,
                      itemsTable: { ...p.itemsTable, tableBorderRadius: val },
                    }));
                  }}
                  className="w-14 px-1.5 py-1 text-xs text-center border border-neutral-300 rounded font-mono bg-white"
                />
                <span className="text-[10px] text-neutral-400">px</span>
              </div>
            </div>

            <div className="flex flex-col gap-1">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Header Bg
              </span>
              <div className="flex items-center gap-1.5">
                <input
                  type="color"
                  value={design.colors.tableHeaderBackground || design.itemsTable.headerBgColor || '#0B1E36'}
                  onChange={(e) => {
                    const val = e.target.value;
                    updateDesign((p) => ({
                      ...p,
                      colors: { ...p.colors, tableHeaderBackground: val },
                      itemsTable: { ...p.itemsTable, headerBgColor: val },
                    }));
                  }}
                  className="w-7 h-7 p-0.5 border border-neutral-300 rounded cursor-pointer"
                />
                <span className="text-[11px] font-mono uppercase text-neutral-600">
                  {design.colors.tableHeaderBackground || design.itemsTable.headerBgColor || '#0B1E36'}
                </span>
              </div>
            </div>

            <div className="flex flex-col gap-1">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Header Text
              </span>
              <div className="flex items-center gap-1.5">
                <input
                  type="color"
                  value={design.colors.tableHeaderText || design.itemsTable.headerTextColor || '#FFFFFF'}
                  onChange={(e) => {
                    const val = e.target.value;
                    updateDesign((p) => ({
                      ...p,
                      colors: { ...p.colors, tableHeaderText: val },
                      itemsTable: { ...p.itemsTable, headerTextColor: val },
                    }));
                  }}
                  className="w-7 h-7 p-0.5 border border-neutral-300 rounded cursor-pointer"
                />
                <span className="text-[11px] font-mono uppercase text-neutral-600">
                  {design.colors.tableHeaderText || design.itemsTable.headerTextColor || '#FFFFFF'}
                </span>
              </div>
            </div>

            <div className="flex flex-col gap-1">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Row Height
              </span>
              <div className="flex items-center gap-1">
                <input
                  type="number"
                  min={18}
                  max={36}
                  step={1}
                  value={design.spacing.rowHeight || design.itemsTable.rowHeight || 23}
                  onChange={(e) => {
                    const val = Number(e.target.value);
                    updateDesign((p) => ({
                      ...p,
                      spacing: { ...p.spacing, rowHeight: val },
                      itemsTable: { ...p.itemsTable, rowHeight: val },
                    }));
                  }}
                  className="w-14 px-1.5 py-1 text-xs text-center border border-neutral-300 rounded font-mono bg-white"
                />
                <span className="text-[10px] text-neutral-400">px</span>
              </div>
            </div>

            <div className="flex flex-col gap-1">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Zebra Striping
              </span>
              <button
                type="button"
                onClick={() =>
                  updateDesign((p) => ({
                    ...p,
                    itemsTable: {
                      ...p.itemsTable,
                      useZebraStriping: !p.itemsTable.useZebraStriping,
                      stripedRows: !p.itemsTable.useZebraStriping,
                    },
                  }))
                }
                className={`px-2.5 py-1 text-xs rounded border transition cursor-pointer ${
                  design.itemsTable.useZebraStriping
                    ? 'bg-blue-50 text-blue-700 border-blue-300 font-semibold'
                    : 'bg-white text-neutral-500 border-neutral-300'
                }`}
              >
                {design.itemsTable.useZebraStriping ? 'Enabled' : 'Disabled'}
              </button>
            </div>
          </>
        )}

        {/* 9b. TABLE HEADER */}
        {selectedElement === 'tableHeader' && (
          <>
            <div className="flex flex-col gap-1">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Header Bg
              </span>
              <div className="flex items-center gap-1.5">
                <input
                  type="color"
                  value={design.colors.tableHeaderBackground || design.itemsTable.headerBgColor || '#0B1E36'}
                  onChange={(e) => {
                    const val = e.target.value;
                    updateDesign((p) => ({
                      ...p,
                      colors: { ...p.colors, tableHeaderBackground: val },
                      itemsTable: { ...p.itemsTable, headerBgColor: val },
                    }));
                  }}
                  className="w-7 h-7 p-0.5 border border-neutral-300 rounded cursor-pointer"
                />
                <span className="text-[11px] font-mono uppercase text-neutral-600">
                  {design.colors.tableHeaderBackground || design.itemsTable.headerBgColor || '#0B1E36'}
                </span>
              </div>
            </div>

            <div className="flex flex-col gap-1">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Header Text
              </span>
              <div className="flex items-center gap-1.5">
                <input
                  type="color"
                  value={design.colors.tableHeaderText || design.itemsTable.headerTextColor || '#FFFFFF'}
                  onChange={(e) => {
                    const val = e.target.value;
                    updateDesign((p) => ({
                      ...p,
                      colors: { ...p.colors, tableHeaderText: val },
                      itemsTable: { ...p.itemsTable, headerTextColor: val },
                    }));
                  }}
                  className="w-7 h-7 p-0.5 border border-neutral-300 rounded cursor-pointer"
                />
                <span className="text-[11px] font-mono uppercase text-neutral-600">
                  {design.colors.tableHeaderText || design.itemsTable.headerTextColor || '#FFFFFF'}
                </span>
              </div>
            </div>

            <FontFamilySelect
              value={design.itemsTable.headerFontFamily || design.typography.fontFamily}
              onChange={(f) =>
                updateDesign((p) => ({
                  ...p,
                  itemsTable: { ...p.itemsTable, headerFontFamily: f },
                }))
              }
              label="Header Font"
            />

            <div className="flex flex-col gap-1">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Font Size
              </span>
              <div className="flex items-center gap-1">
                <input
                  type="number"
                  min={9}
                  max={16}
                  step={0.5}
                  value={design.typography.tableHeaderFontSize || design.itemsTable.headerFontSize || 11.5}
                  onChange={(e) => {
                    const val = Number(e.target.value);
                    updateDesign((p) => ({
                      ...p,
                      itemsTable: { ...p.itemsTable, headerFontSize: val },
                    }));
                  }}
                  className="w-14 px-1.5 py-1 text-xs text-center border border-neutral-300 rounded font-mono bg-white"
                />
                <span className="text-[10px] text-neutral-400">px</span>
              </div>
            </div>

            <div className="flex flex-col gap-1">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Style &amp; Align
              </span>
              <div className="flex items-center gap-1">
                <button
                  type="button"
                  onClick={() =>
                    updateDesign((p) => ({
                      ...p,
                      itemsTable: {
                        ...p.itemsTable,
                        headerFontWeight: p.itemsTable.headerFontWeight === 'bold' ? 'normal' : 'bold',
                      },
                    }))
                  }
                  className={`p-1.5 rounded border text-xs font-bold transition cursor-pointer ${
                    design.itemsTable.headerFontWeight === 'bold'
                      ? 'bg-blue-100 text-blue-800 border-blue-300'
                      : 'bg-white text-neutral-700 border-neutral-300 hover:bg-neutral-100'
                  }`}
                  title="Toggle Bold"
                >
                  <Bold className="w-3.5 h-3.5" />
                </button>
                <button
                  type="button"
                  onClick={() =>
                    updateDesign((p) => ({
                      ...p,
                      itemsTable: {
                        ...p.itemsTable,
                        headerItalic: !p.itemsTable.headerItalic,
                      },
                    }))
                  }
                  className={`p-1.5 rounded border text-xs font-bold transition cursor-pointer ${
                    design.itemsTable.headerItalic
                      ? 'bg-blue-100 text-blue-800 border-blue-300'
                      : 'bg-white text-neutral-700 border-neutral-300 hover:bg-neutral-100'
                  }`}
                  title="Toggle Italic"
                >
                  <Italic className="w-3.5 h-3.5" />
                </button>
                <button
                  type="button"
                  onClick={() =>
                    updateDesign((p) => ({
                      ...p,
                      itemsTable: {
                        ...p.itemsTable,
                        headerUnderline: !p.itemsTable.headerUnderline,
                      },
                    }))
                  }
                  className={`p-1.5 rounded border text-xs font-bold transition cursor-pointer ${
                    design.itemsTable.headerUnderline
                      ? 'bg-blue-100 text-blue-800 border-blue-300'
                      : 'bg-white text-neutral-700 border-neutral-300 hover:bg-neutral-100'
                  }`}
                  title="Toggle Underline"
                >
                  <UnderlineIcon className="w-3.5 h-3.5" />
                </button>

                {(['left', 'center', 'right'] as const).map((align) => (
                  <button
                    key={align}
                    type="button"
                    onClick={() =>
                      updateDesign((p) => ({
                        ...p,
                        itemsTable: { ...p.itemsTable, headerAlignment: align },
                      }))
                    }
                    className={`p-1.5 rounded border transition cursor-pointer ${
                      design.itemsTable.headerAlignment === align
                        ? 'bg-blue-100 text-blue-800 border-blue-300'
                        : 'bg-white text-neutral-600 border-neutral-300 hover:bg-neutral-100'
                    }`}
                    title={`Align ${align}`}
                  >
                    {align === 'left' && <AlignLeft className="w-3.5 h-3.5" />}
                    {align === 'center' && <AlignCenter className="w-3.5 h-3.5" />}
                    {align === 'right' && <AlignRight className="w-3.5 h-3.5" />}
                  </button>
                ))}
              </div>
            </div>
          </>
        )}

        {/* 9c. TABLE BODY */}
        {selectedElement === 'tableBody' && (
          <>
            <FontFamilySelect
              value={design.itemsTable.bodyFontFamily || design.typography.fontFamily}
              onChange={(f) =>
                updateDesign((p) => ({
                  ...p,
                  itemsTable: { ...p.itemsTable, bodyFontFamily: f },
                }))
              }
              label="Body Font"
            />

            <div className="flex flex-col gap-1">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Font Size
              </span>
              <div className="flex items-center gap-1">
                <input
                  type="number"
                  min={8}
                  max={15}
                  step={0.5}
                  value={design.typography.tableFontSize || design.itemsTable.bodyFontSize || 10}
                  onChange={(e) => {
                    const val = Number(e.target.value);
                    updateDesign((p) => ({
                      ...p,
                      itemsTable: { ...p.itemsTable, bodyFontSize: val },
                    }));
                  }}
                  className="w-14 px-1.5 py-1 text-xs text-center border border-neutral-300 rounded font-mono bg-white"
                />
                <span className="text-[10px] text-neutral-400">px</span>
              </div>
            </div>

            <div className="flex flex-col gap-1">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Row Height
              </span>
              <div className="flex items-center gap-1">
                <input
                  type="number"
                  min={18}
                  max={36}
                  step={1}
                  value={design.spacing.rowHeight || design.itemsTable.rowHeight || 23}
                  onChange={(e) => {
                    const val = Number(e.target.value);
                    updateDesign((p) => ({
                      ...p,
                      spacing: { ...p.spacing, rowHeight: val },
                      itemsTable: { ...p.itemsTable, rowHeight: val },
                    }));
                  }}
                  className="w-14 px-1.5 py-1 text-xs text-center border border-neutral-300 rounded font-mono bg-white"
                />
                <span className="text-[10px] text-neutral-400">px</span>
              </div>
            </div>

            <div className="flex flex-col gap-1">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Row Color
              </span>
              <div className="flex items-center gap-1.5">
                <input
                  type="color"
                  value={design.colors.text || '#0F172A'}
                  onChange={(e) => {
                    const val = e.target.value;
                    updateDesign((p) => ({
                      ...p,
                      colors: { ...p.colors, text: val },
                    }));
                  }}
                  className="w-7 h-7 p-0.5 border border-neutral-300 rounded cursor-pointer"
                />
                <span className="text-[11px] font-mono uppercase text-neutral-600">
                  {design.colors.text || '#0F172A'}
                </span>
              </div>
            </div>

            <div className="flex flex-col gap-1">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Alternate Row
              </span>
              <div className="flex items-center gap-1.5">
                <input
                  type="color"
                  value={design.colors.tableRowAlternate || '#F8FAFC'}
                  onChange={(e) => {
                    const val = e.target.value;
                    updateDesign((p) => ({
                      ...p,
                      colors: { ...p.colors, tableRowAlternate: val },
                      itemsTable: { ...p.itemsTable, alternateRowColor: val },
                    }));
                  }}
                  className="w-7 h-7 p-0.5 border border-neutral-300 rounded cursor-pointer"
                />
                <span className="text-[11px] font-mono uppercase text-neutral-600">
                  {design.colors.tableRowAlternate || '#F8FAFC'}
                </span>
              </div>
            </div>

            <div className="flex flex-col gap-1">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Style &amp; Align
              </span>
              <div className="flex items-center gap-1">
                <button
                  type="button"
                  onClick={() =>
                    updateDesign((p) => ({
                      ...p,
                      itemsTable: {
                        ...p.itemsTable,
                        bodyFontWeight: p.itemsTable.bodyFontWeight === 'bold' ? 'normal' : 'bold',
                      },
                    }))
                  }
                  className={`p-1.5 rounded border text-xs font-bold transition cursor-pointer ${
                    design.itemsTable.bodyFontWeight === 'bold'
                      ? 'bg-blue-100 text-blue-800 border-blue-300'
                      : 'bg-white text-neutral-700 border-neutral-300 hover:bg-neutral-100'
                  }`}
                  title="Toggle Bold"
                >
                  <Bold className="w-3.5 h-3.5" />
                </button>
                <button
                  type="button"
                  onClick={() =>
                    updateDesign((p) => ({
                      ...p,
                      itemsTable: {
                        ...p.itemsTable,
                        bodyItalic: !p.itemsTable.bodyItalic,
                      },
                    }))
                  }
                  className={`p-1.5 rounded border text-xs font-bold transition cursor-pointer ${
                    design.itemsTable.bodyItalic
                      ? 'bg-blue-100 text-blue-800 border-blue-300'
                      : 'bg-white text-neutral-700 border-neutral-300 hover:bg-neutral-100'
                  }`}
                  title="Toggle Italic"
                >
                  <Italic className="w-3.5 h-3.5" />
                </button>
                <button
                  type="button"
                  onClick={() =>
                    updateDesign((p) => ({
                      ...p,
                      itemsTable: {
                        ...p.itemsTable,
                        bodyUnderline: !p.itemsTable.bodyUnderline,
                      },
                    }))
                  }
                  className={`p-1.5 rounded border text-xs font-bold transition cursor-pointer ${
                    design.itemsTable.bodyUnderline
                      ? 'bg-blue-100 text-blue-800 border-blue-300'
                      : 'bg-white text-neutral-700 border-neutral-300 hover:bg-neutral-100'
                  }`}
                  title="Toggle Underline"
                >
                  <Underline className="w-3.5 h-3.5" />
                </button>
                {(['left', 'center', 'right'] as const).map((align) => (
                  <button
                    key={align}
                    type="button"
                    onClick={() =>
                      updateDesign((p) => ({
                        ...p,
                        itemsTable: { ...p.itemsTable, bodyAlignment: align },
                      }))
                    }
                    className={`p-1.5 rounded border transition cursor-pointer ${
                      design.itemsTable.bodyAlignment === align
                        ? 'bg-blue-100 text-blue-800 border-blue-300'
                        : 'bg-white text-neutral-600 border-neutral-300 hover:bg-neutral-100'
                    }`}
                    title={`Align ${align}`}
                  >
                    {align === 'left' && <AlignLeft className="w-3.5 h-3.5" />}
                    {align === 'center' && <AlignCenter className="w-3.5 h-3.5" />}
                    {align === 'right' && <AlignRight className="w-3.5 h-3.5" />}
                  </button>
                ))}
              </div>
            </div>
          </>
        )}

        {/* 9d. INDEPENDENT TABLE COLUMNS */}
        {(
          selectedElement === 'tableColumnSerial' ||
          selectedElement === 'tableColumnDescription' ||
          selectedElement === 'tableColumnQuantity' ||
          selectedElement === 'tableColumnUnit' ||
          selectedElement === 'tableColumnUnitPrice' ||
          selectedElement === 'tableColumnDiscount' ||
          selectedElement === 'tableColumnTax' ||
          selectedElement === 'tableColumnTotal'
        ) && (() => {
          const colKeyMap: Record<string, keyof typeof design.itemsTable.columns> = {
            tableColumnSerial: 'sNo',
            tableColumnDescription: 'description',
            tableColumnQuantity: 'quantity',
            tableColumnUnit: 'unit',
            tableColumnUnitPrice: 'unitPrice',
            tableColumnDiscount: 'discount',
            tableColumnTax: 'tax',
            tableColumnTotal: 'totalAmount',
          };
          const colKey = colKeyMap[selectedElement] || 'sNo';
          const col = design.itemsTable.columns[colKey] || { show: true, label: '', width: '10%', align: 'center' };
          const updateCol = (patch: Partial<TableColumnConfig>) => {
            updateDesign((p) => ({
              ...p,
              itemsTable: {
                ...p.itemsTable,
                columns: {
                  ...p.itemsTable.columns,
                  [colKey]: {
                    ...p.itemsTable.columns[colKey],
                    ...patch,
                  },
                },
              },
            }));
          };

          return (
            <>
              {/* Column Label */}
              <div className="flex flex-col gap-1 min-w-[130px] flex-1">
                <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                  Column Label
                </span>
                <input
                  type="text"
                  value={col.label}
                  onChange={(e) => updateCol({ label: e.target.value })}
                  className="px-2 py-1 text-xs border border-neutral-300 rounded font-medium bg-white"
                />
              </div>

              {/* Table Header Background */}
              <div className="flex flex-col gap-1">
                <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                  Header Bg
                </span>
                <div className="flex items-center gap-1.5">
                  <input
                    type="color"
                    value={design.colors.tableHeaderBackground || design.itemsTable.headerBgColor || '#0B1E36'}
                    onChange={(e) => {
                      const val = e.target.value;
                      updateDesign((p) => ({
                        ...p,
                        colors: { ...p.colors, tableHeaderBackground: val },
                        itemsTable: { ...p.itemsTable, headerBgColor: val },
                      }));
                    }}
                    className="w-7 h-7 p-0.5 border border-neutral-300 rounded cursor-pointer"
                  />
                  <span className="text-[11px] font-mono uppercase text-neutral-600">
                    {design.colors.tableHeaderBackground || design.itemsTable.headerBgColor || '#0B1E36'}
                  </span>
                </div>
              </div>

              {/* Column Width */}
              <div className="flex flex-col gap-1 min-w-[85px]">
                <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                  Width
                </span>
                <input
                  type="text"
                  value={col.width}
                  onChange={(e) => updateCol({ width: e.target.value })}
                  className="px-2 py-1 text-xs border border-neutral-300 rounded font-mono bg-white text-center"
                  placeholder="e.g. 15%"
                />
              </div>

              {/* Visibility */}
              <div className="flex flex-col gap-1">
                <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                  Visibility
                </span>
                <button
                  type="button"
                  onClick={() => updateCol({ show: col.show === false })}
                  className={`flex items-center gap-1 px-2.5 py-1 text-xs rounded border transition cursor-pointer ${
                    col.show !== false
                      ? 'bg-blue-50 text-blue-700 border-blue-300 font-semibold'
                      : 'bg-white text-neutral-500 border-neutral-300'
                  }`}
                >
                  {col.show !== false ? <Eye className="w-3.5 h-3.5" /> : <EyeOff className="w-3.5 h-3.5" />}
                  <span>{col.show !== false ? 'Visible' : 'Hidden'}</span>
                </button>
              </div>

              {/* Font Family */}
              <FontFamilySelect
                value={col.fontFamily || design.itemsTable.bodyFontFamily || design.typography.fontFamily}
                onChange={(f) => updateCol({ fontFamily: f })}
                label="Column Font"
              />

              {/* Font Size */}
              <div className="flex flex-col gap-1">
                <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                  Font Size
                </span>
                <div className="flex items-center gap-1">
                  <input
                    type="number"
                    min={8}
                    max={20}
                    step={0.5}
                    value={col.fontSize || design.itemsTable.bodyFontSize || 10}
                    onChange={(e) => updateCol({ fontSize: Number(e.target.value) })}
                    className="w-14 px-1 py-1 text-xs text-center border border-neutral-300 rounded font-mono bg-white"
                  />
                  <span className="text-[10px] text-neutral-400">px</span>
                </div>
              </div>

              {/* Style & Alignment */}
              <div className="flex flex-col gap-1">
                <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                  Style &amp; Align
                </span>
                <div className="flex items-center gap-1">
                  <button
                    type="button"
                    onClick={() => updateCol({ fontWeight: col.fontWeight === 'bold' ? 'normal' : 'bold' })}
                    className={`p-1.5 rounded border text-xs font-bold transition cursor-pointer ${
                      col.fontWeight === 'bold'
                        ? 'bg-blue-100 text-blue-800 border-blue-300'
                        : 'bg-white text-neutral-700 border-neutral-300 hover:bg-neutral-100'
                    }`}
                    title="Toggle Bold"
                  >
                    <Bold className="w-3.5 h-3.5" />
                  </button>
                  <button
                    type="button"
                    onClick={() => updateCol({ italic: !col.italic })}
                    className={`p-1.5 rounded border text-xs font-bold transition cursor-pointer ${
                      col.italic
                        ? 'bg-blue-100 text-blue-800 border-blue-300'
                        : 'bg-white text-neutral-700 border-neutral-300 hover:bg-neutral-100'
                    }`}
                    title="Toggle Italic"
                  >
                    <Italic className="w-3.5 h-3.5" />
                  </button>
                  <button
                    type="button"
                    onClick={() => updateCol({ underline: !col.underline })}
                    className={`p-1.5 rounded border text-xs font-bold transition cursor-pointer ${
                      col.underline
                        ? 'bg-blue-100 text-blue-800 border-blue-300'
                        : 'bg-white text-neutral-700 border-neutral-300 hover:bg-neutral-100'
                    }`}
                    title="Toggle Underline"
                  >
                    <UnderlineIcon className="w-3.5 h-3.5" />
                  </button>

                  {(['left', 'center', 'right'] as const).map((align) => (
                    <button
                      key={align}
                      type="button"
                      onClick={() => updateCol({ align })}
                      className={`p-1.5 rounded border transition cursor-pointer ${
                        col.align === align
                          ? 'bg-blue-100 text-blue-800 border-blue-300 font-bold'
                          : 'bg-white text-neutral-600 border-neutral-300 hover:bg-neutral-100'
                      }`}
                      title={`Align ${align}`}
                    >
                      {align === 'left' && <AlignLeft className="w-3.5 h-3.5" />}
                      {align === 'center' && <AlignCenter className="w-3.5 h-3.5" />}
                      {align === 'right' && <AlignRight className="w-3.5 h-3.5" />}
                    </button>
                  ))}
                </div>
              </div>

              {/* Text Color */}
              <div className="flex flex-col gap-1">
                <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                  Text Color
                </span>
                <div className="flex items-center gap-1.5">
                  <input
                    type="color"
                    value={col.textColor || design.colors.text || '#0F172A'}
                    onChange={(e) => updateCol({ textColor: e.target.value })}
                    className="w-7 h-7 p-0.5 border border-neutral-300 rounded cursor-pointer"
                  />
                  <span className="text-[11px] font-mono uppercase text-neutral-600">
                    {col.textColor || design.colors.text || '#0F172A'}
                  </span>
                </div>
              </div>

              {/* Background Color */}
              <div className="flex flex-col gap-1">
                <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                  Cell Bg
                </span>
                <div className="flex items-center gap-1.5">
                  <input
                    type="color"
                    value={col.backgroundColor || '#FFFFFF'}
                    onChange={(e) => updateCol({ backgroundColor: e.target.value })}
                    className="w-7 h-7 p-0.5 border border-neutral-300 rounded cursor-pointer"
                  />
                  <span className="text-[11px] font-mono uppercase text-neutral-600">
                    {col.backgroundColor || 'transparent'}
                  </span>
                </div>
              </div>

              {/* Header Text Color */}
              <div className="flex flex-col gap-1">
                <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                  Header Text
                </span>
                <div className="flex items-center gap-1.5">
                  <input
                    type="color"
                    value={col.headerTextColor || design.itemsTable.headerTextColor || '#FFFFFF'}
                    onChange={(e) => updateCol({ headerTextColor: e.target.value })}
                    className="w-7 h-7 p-0.5 border border-neutral-300 rounded cursor-pointer"
                  />
                  <span className="text-[11px] font-mono uppercase text-neutral-600">
                    {col.headerTextColor || design.itemsTable.headerTextColor || '#FFFFFF'}
                  </span>
                </div>
              </div>

              {/* Header Background Color */}
              <div className="flex flex-col gap-1">
                <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                  Header Bg
                </span>
                <div className="flex items-center gap-1.5">
                  <input
                    type="color"
                    value={col.headerBgColor || design.itemsTable.headerBgColor || '#001838'}
                    onChange={(e) => updateCol({ headerBgColor: e.target.value })}
                    className="w-7 h-7 p-0.5 border border-neutral-300 rounded cursor-pointer"
                  />
                  <span className="text-[11px] font-mono uppercase text-neutral-600">
                    {col.headerBgColor || design.itemsTable.headerBgColor || '#001838'}
                  </span>
                </div>
              </div>

              {/* Border Style */}
              <div className="flex flex-col gap-1 min-w-[75px]">
                <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                  Border Style
                </span>
                <select
                  value={col.borderStyle || 'solid'}
                  onChange={(e) => updateCol({ borderStyle: e.target.value as any })}
                  className="px-2 py-1 text-xs border border-neutral-300 rounded bg-white"
                >
                  <option value="solid">Solid</option>
                  <option value="dashed">Dashed</option>
                  <option value="none">None</option>
                </select>
              </div>

              {/* Border Width */}
              <div className="flex flex-col gap-1">
                <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                  Border Width
                </span>
                <div className="flex items-center gap-1">
                  <input
                    type="number"
                    min={0}
                    max={6}
                    step={0.5}
                    value={col.borderWidth ?? (design.itemsTable.borderThickness ?? 1)}
                    onChange={(e) => updateCol({ borderWidth: Number(e.target.value) })}
                    className="w-14 px-1 py-1 text-xs text-center border border-neutral-300 rounded font-mono bg-white"
                  />
                  <span className="text-[10px] text-neutral-400">px</span>
                </div>
              </div>

              {/* Border Color */}
              <div className="flex flex-col gap-1">
                <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                  Border Color
                </span>
                <div className="flex items-center gap-1.5">
                  <input
                    type="color"
                    value={col.borderColor || design.itemsTable.borderColor || '#000000'}
                    onChange={(e) => updateCol({ borderColor: e.target.value })}
                    className="w-7 h-7 p-0.5 border border-neutral-300 rounded cursor-pointer"
                  />
                  <span className="text-[11px] font-mono uppercase text-neutral-600">
                    {col.borderColor || design.itemsTable.borderColor || '#000000'}
                  </span>
                </div>
              </div>

              {/* Padding */}
              <div className="flex flex-col gap-1">
                <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                  Padding
                </span>
                <div className="flex items-center gap-1">
                  <input
                    type="number"
                    min={1}
                    max={20}
                    value={col.padding ?? design.itemsTable.padding ?? 4}
                    onChange={(e) => updateCol({ padding: Number(e.target.value) })}
                    className="w-14 px-1 py-1 text-xs text-center border border-neutral-300 rounded font-mono bg-white"
                  />
                  <span className="text-[10px] text-neutral-400">px</span>
                </div>
              </div>

              {/* Lock */}
              <div className="flex flex-col gap-1">
                <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                  Lock
                </span>
                <button
                  type="button"
                  onClick={() => updateCol({ locked: !col.locked })}
                  className={`p-1.5 rounded border text-xs font-medium transition cursor-pointer flex items-center gap-1 ${
                    col.locked
                      ? 'bg-amber-50 text-amber-800 border-amber-300'
                      : 'bg-white text-neutral-700 border-neutral-300 hover:bg-neutral-100'
                  }`}
                  title={col.locked ? 'Unlock column' : 'Lock column'}
                >
                  {col.locked ? <Lock className="w-3.5 h-3.5" /> : <Unlock className="w-3.5 h-3.5" />}
                  <span>{col.locked ? 'Locked' : 'Unlocked'}</span>
                </button>
              </div>

              {/* Reset column overrides */}
              <div className="flex flex-col gap-1">
                <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                  Reset
                </span>
                <button
                  type="button"
                  onClick={() => {
                    const defaultCols = DEFAULT_INVOICE_DESIGN.itemsTable.columns;
                    const defCol = (defaultCols as any)[colKey];
                    updateCol({
                      fontFamily: undefined,
                      fontSize: undefined,
                      fontWeight: undefined,
                      italic: undefined,
                      underline: undefined,
                      textColor: undefined,
                      backgroundColor: undefined,
                      headerTextColor: undefined,
                      headerBgColor: undefined,
                      borderWidth: undefined,
                      borderColor: undefined,
                      borderStyle: undefined,
                      padding: undefined,
                      align: defCol?.align || 'center',
                      width: defCol?.width || col.width,
                      label: defCol?.label || col.label,
                    });
                  }}
                  className="p-1.5 rounded border border-neutral-300 bg-white text-neutral-600 hover:bg-neutral-100 text-xs font-medium transition cursor-pointer flex items-center gap-1"
                  title="Reset column styles to default"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                  <span>Reset</span>
                </button>
              </div>
            </>
          );
        })()}

        {/* 10. PAYMENT INFO */}
        {selectedElement === 'paymentInfo' && (
          <>
            <div className="flex flex-col gap-1">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Header Bg
              </span>
              <div className="flex items-center gap-1.5">
                <input
                  type="color"
                  value={design.colors.tableHeaderBackground || design.itemsTable.headerBgColor || '#0B1E36'}
                  onChange={(e) => {
                    const val = e.target.value;
                    updateDesign((p) => ({
                      ...p,
                      colors: { ...p.colors, tableHeaderBackground: val },
                      itemsTable: { ...p.itemsTable, headerBgColor: val },
                    }));
                  }}
                  className="w-7 h-7 p-0.5 border border-neutral-300 rounded cursor-pointer"
                />
                <span className="text-[11px] font-mono uppercase text-neutral-600">
                  {design.colors.tableHeaderBackground || design.itemsTable.headerBgColor || '#0B1E36'}
                </span>
              </div>
            </div>

            <div className="flex flex-col gap-1 min-w-[120px]">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Paid Label
              </span>
              <input
                type="text"
                value={design.payment.paidLabel || 'Paid Amount:'}
                onChange={(e) => {
                  const val = e.target.value;
                  updateDesign((p) => ({
                    ...p,
                    payment: { ...p.payment, paidLabel: val },
                  }));
                }}
                className="px-2 py-1 text-xs border border-neutral-300 rounded bg-white"
              />
            </div>

            <div className="flex flex-col gap-1 min-w-[120px]">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Remaining Label
              </span>
              <input
                type="text"
                value={design.payment.remainingLabel || 'Remaining:'}
                onChange={(e) => {
                  const val = e.target.value;
                  updateDesign((p) => ({
                    ...p,
                    payment: { ...p.payment, remainingLabel: val },
                  }));
                }}
                className="px-2 py-1 text-xs border border-neutral-300 rounded bg-white"
              />
            </div>

            <FontFamilySelect
              value={design.payment.fontFamily || design.typography.fontFamily}
              onChange={(f) =>
                updateDesign((p) => ({
                  ...p,
                  payment: { ...p.payment, fontFamily: f },
                }))
              }
              label="Payment Font"
            />

            <div className="flex flex-col gap-1">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Font Size
              </span>
              <div className="flex items-center gap-1">
                <input
                  type="number"
                  min={8}
                  max={14}
                  step={0.5}
                  value={design.payment.fontSize || 10}
                  onChange={(e) => {
                    const val = Number(e.target.value);
                    updateDesign((p) => ({
                      ...p,
                      payment: { ...p.payment, fontSize: val },
                    }));
                  }}
                  className="w-14 px-1.5 py-1 text-xs text-center border border-neutral-300 rounded font-mono bg-white"
                />
                <span className="text-[10px] text-neutral-400">px</span>
              </div>
            </div>

            <div className="flex flex-col gap-1">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Text Color
              </span>
              <div className="flex items-center gap-1.5">
                <input
                  type="color"
                  value={design.payment.textColor || '#0F172A'}
                  onChange={(e) => {
                    const val = e.target.value;
                    updateDesign((p) => ({
                      ...p,
                      payment: { ...p.payment, textColor: val },
                    }));
                  }}
                  className="w-7 h-7 p-0.5 border border-neutral-300 rounded cursor-pointer"
                />
                <span className="text-[11px] font-mono uppercase text-neutral-600">
                  {design.payment.textColor || '#0F172A'}
                </span>
              </div>
            </div>

            <div className="flex flex-col gap-1">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Border
              </span>
              <div className="flex items-center gap-1.5">
                <input
                  type="color"
                  value={design.payment.borderColor || '#D8E2EC'}
                  onChange={(e) => {
                    const val = e.target.value;
                    updateDesign((p) => ({
                      ...p,
                      payment: { ...p.payment, borderColor: val },
                    }));
                  }}
                  className="w-7 h-7 p-0.5 border border-neutral-300 rounded cursor-pointer"
                />
                <span className="text-[11px] font-mono uppercase text-neutral-600">
                  {design.payment.borderColor || '#D8E2EC'}
                </span>
              </div>
            </div>

            <div className="flex flex-col gap-1">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Background
              </span>
              <div className="flex items-center gap-1.5">
                <input
                  type="color"
                  value={design.payment.backgroundColor || '#FFFFFF'}
                  onChange={(e) => {
                    const val = e.target.value;
                    updateDesign((p) => ({
                      ...p,
                      payment: { ...p.payment, backgroundColor: val },
                    }));
                  }}
                  className="w-7 h-7 p-0.5 border border-neutral-300 rounded cursor-pointer"
                />
                <span className="text-[11px] font-mono uppercase text-neutral-600">
                  {design.payment.backgroundColor || '#FFFFFF'}
                </span>
              </div>
            </div>

            <div className="flex flex-col gap-1">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Style
              </span>
              <div className="flex items-center gap-1">
                <button
                  type="button"
                  onClick={() =>
                    updateDesign((p) => ({
                      ...p,
                      payment: { ...p.payment, italic: !p.payment.italic },
                    }))
                  }
                  className={`p-1.5 rounded border transition cursor-pointer ${
                    design.payment.italic
                      ? 'bg-blue-100 text-blue-800 border-blue-300 font-bold'
                      : 'bg-white text-neutral-600 border-neutral-300 hover:bg-neutral-100'
                  }`}
                  title="Italic"
                >
                  <Italic className="w-3.5 h-3.5" />
                </button>
                <button
                  type="button"
                  onClick={() =>
                    updateDesign((p) => ({
                      ...p,
                      payment: { ...p.payment, underline: !p.payment.underline },
                    }))
                  }
                  className={`p-1.5 rounded border transition cursor-pointer ${
                    design.payment.underline
                      ? 'bg-blue-100 text-blue-800 border-blue-300 font-bold'
                      : 'bg-white text-neutral-600 border-neutral-300 hover:bg-neutral-100'
                  }`}
                  title="Underline"
                >
                  <Underline className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>

            <div className="flex flex-col gap-1">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Status Badge
              </span>
              <button
                type="button"
                onClick={() =>
                  updateDesign((p) => ({
                    ...p,
                    payment: {
                      ...p.payment,
                      showPaymentStatusBadge: !p.payment.showPaymentStatusBadge,
                    },
                  }))
                }
                className={`px-2.5 py-1 text-xs rounded border transition cursor-pointer ${
                  design.payment.showPaymentStatusBadge !== false
                    ? 'bg-blue-50 text-blue-700 border-blue-300 font-semibold'
                    : 'bg-white text-neutral-500 border-neutral-300'
                }`}
              >
                {design.payment.showPaymentStatusBadge !== false ? 'Show Badge' : 'Hide Badge'}
              </button>
            </div>
          </>
        )}

        {/* 10b. INDEPENDENT PAYMENT METHOD */}
        {selectedElement === 'paymentMethod' && (
          <>
            <div className="flex flex-col gap-1 min-w-[130px] flex-1">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Method Label
              </span>
              <input
                type="text"
                value={design.payment.methodLabel || 'Payment Method:'}
                onChange={(e) => {
                  const val = e.target.value;
                  updateDesign((p) => ({
                    ...p,
                    payment: { ...p.payment, methodLabel: val },
                  }));
                }}
                className="px-2 py-1 text-xs border border-neutral-300 rounded bg-white font-medium"
              />
            </div>

            <div className="flex flex-col gap-1">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Visibility
              </span>
              <button
                type="button"
                onClick={() =>
                  updateDesign((p) => ({
                    ...p,
                    payment: { ...p.payment, showMethod: p.payment.showMethod === false },
                  }))
                }
                className={`flex items-center gap-1 px-2.5 py-1 text-xs rounded border transition cursor-pointer ${
                  design.payment.showMethod !== false
                    ? 'bg-blue-50 text-blue-700 border-blue-300 font-semibold'
                    : 'bg-white text-neutral-500 border-neutral-300'
                }`}
              >
                {design.payment.showMethod !== false ? <Eye className="w-3.5 h-3.5" /> : <EyeOff className="w-3.5 h-3.5" />}
                <span>{design.payment.showMethod !== false ? 'Visible' : 'Hidden'}</span>
              </button>
            </div>

            <FontFamilySelect
              value={design.payment.methodFontFamily || design.payment.fontFamily || design.typography.fontFamily}
              onChange={(f) =>
                updateDesign((p) => ({
                  ...p,
                  payment: { ...p.payment, methodFontFamily: f },
                }))
              }
              label="Method Font"
            />

            <div className="flex flex-col gap-1">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Font Size
              </span>
              <div className="flex items-center gap-1">
                <input
                  type="number"
                  min={8}
                  max={20}
                  step={0.5}
                  value={design.payment.methodFontSize || design.payment.fontSize || 11.5}
                  onChange={(e) => {
                    const val = Number(e.target.value);
                    updateDesign((p) => ({
                      ...p,
                      payment: { ...p.payment, methodFontSize: val },
                    }));
                  }}
                  className="w-14 px-1 py-1 text-xs text-center border border-neutral-300 rounded font-mono bg-white"
                />
                <span className="text-[10px] text-neutral-400">px</span>
              </div>
            </div>

            <div className="flex flex-col gap-1">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Style
              </span>
              <div className="flex items-center gap-1">
                <button
                  type="button"
                  onClick={() =>
                    updateDesign((p) => ({
                      ...p,
                      payment: {
                        ...p.payment,
                        methodFontWeight: (p.payment.methodFontWeight || 'bold') === 'bold' ? 'normal' : 'bold',
                      },
                    }))
                  }
                  className={`p-1.5 rounded border text-xs font-bold transition cursor-pointer ${
                    (design.payment.methodFontWeight || 'bold') === 'bold'
                      ? 'bg-blue-100 text-blue-800 border-blue-300'
                      : 'bg-white text-neutral-700 border-neutral-300 hover:bg-neutral-100'
                  }`}
                  title="Toggle Bold"
                >
                  <Bold className="w-3.5 h-3.5" />
                </button>
                <button
                  type="button"
                  onClick={() =>
                    updateDesign((p) => ({
                      ...p,
                      payment: { ...p.payment, methodItalic: !p.payment.methodItalic },
                    }))
                  }
                  className={`p-1.5 rounded border text-xs font-bold transition cursor-pointer ${
                    design.payment.methodItalic
                      ? 'bg-blue-100 text-blue-800 border-blue-300'
                      : 'bg-white text-neutral-700 border-neutral-300 hover:bg-neutral-100'
                  }`}
                  title="Toggle Italic"
                >
                  <Italic className="w-3.5 h-3.5" />
                </button>
                <button
                  type="button"
                  onClick={() =>
                    updateDesign((p) => ({
                      ...p,
                      payment: { ...p.payment, methodUnderline: !p.payment.methodUnderline },
                    }))
                  }
                  className={`p-1.5 rounded border text-xs font-bold transition cursor-pointer ${
                    design.payment.methodUnderline
                      ? 'bg-blue-100 text-blue-800 border-blue-300'
                      : 'bg-white text-neutral-700 border-neutral-300 hover:bg-neutral-100'
                  }`}
                  title="Toggle Underline"
                >
                  <UnderlineIcon className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>

            <div className="flex flex-col gap-1">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Label Color
              </span>
              <div className="flex items-center gap-1.5">
                <input
                  type="color"
                  value={design.payment.methodColor || design.payment.textColor || '#0B1E36'}
                  onChange={(e) => {
                    const val = e.target.value;
                    updateDesign((p) => ({
                      ...p,
                      payment: { ...p.payment, methodColor: val },
                    }));
                  }}
                  className="w-7 h-7 p-0.5 border border-neutral-300 rounded cursor-pointer"
                />
                <span className="text-[11px] font-mono uppercase text-neutral-600">
                  {design.payment.methodColor || design.payment.textColor || '#0B1E36'}
                </span>
              </div>
            </div>

            <div className="flex flex-col gap-1">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Value Color
              </span>
              <div className="flex items-center gap-1.5">
                <input
                  type="color"
                  value={design.payment.methodValueColor || design.payment.textColor || '#0F172A'}
                  onChange={(e) => {
                    const val = e.target.value;
                    updateDesign((p) => ({
                      ...p,
                      payment: { ...p.payment, methodValueColor: val },
                    }));
                  }}
                  className="w-7 h-7 p-0.5 border border-neutral-300 rounded cursor-pointer"
                />
                <span className="text-[11px] font-mono uppercase text-neutral-600">
                  {design.payment.methodValueColor || design.payment.textColor || '#0F172A'}
                </span>
              </div>
            </div>
          </>
        )}

        {/* 10c. INDEPENDENT PAYMENT STATUS */}
        {selectedElement === 'paymentStatus' && (
          <>
            <div className="flex flex-col gap-1 min-w-[130px] flex-1">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Status Label
              </span>
              <input
                type="text"
                value={design.payment.statusLabel || 'Status:'}
                onChange={(e) => {
                  const val = e.target.value;
                  updateDesign((p) => ({
                    ...p,
                    payment: { ...p.payment, statusLabel: val },
                  }));
                }}
                className="px-2 py-1 text-xs border border-neutral-300 rounded bg-white font-medium"
              />
            </div>

            <div className="flex flex-col gap-1">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Visibility
              </span>
              <button
                type="button"
                onClick={() =>
                  updateDesign((p) => ({
                    ...p,
                    payment: { ...p.payment, showPaymentStatusBadge: p.payment.showPaymentStatusBadge === false },
                  }))
                }
                className={`flex items-center gap-1 px-2.5 py-1 text-xs rounded border transition cursor-pointer ${
                  design.payment.showPaymentStatusBadge !== false
                    ? 'bg-blue-50 text-blue-700 border-blue-300 font-semibold'
                    : 'bg-white text-neutral-500 border-neutral-300'
                }`}
              >
                {design.payment.showPaymentStatusBadge !== false ? <Eye className="w-3.5 h-3.5" /> : <EyeOff className="w-3.5 h-3.5" />}
                <span>{design.payment.showPaymentStatusBadge !== false ? 'Visible' : 'Hidden'}</span>
              </button>
            </div>

            <FontFamilySelect
              value={design.payment.statusFontFamily || design.payment.fontFamily || design.typography.fontFamily}
              onChange={(f) =>
                updateDesign((p) => ({
                  ...p,
                  payment: { ...p.payment, statusFontFamily: f },
                }))
              }
              label="Status Font"
            />

            <div className="flex flex-col gap-1">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Font Size
              </span>
              <div className="flex items-center gap-1">
                <input
                  type="number"
                  min={8}
                  max={20}
                  step={0.5}
                  value={design.payment.statusFontSize || design.payment.fontSize || 11.5}
                  onChange={(e) => {
                    const val = Number(e.target.value);
                    updateDesign((p) => ({
                      ...p,
                      payment: { ...p.payment, statusFontSize: val },
                    }));
                  }}
                  className="w-14 px-1 py-1 text-xs text-center border border-neutral-300 rounded font-mono bg-white"
                />
                <span className="text-[10px] text-neutral-400">px</span>
              </div>
            </div>

            <div className="flex flex-col gap-1">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Style
              </span>
              <div className="flex items-center gap-1">
                <button
                  type="button"
                  onClick={() =>
                    updateDesign((p) => ({
                      ...p,
                      payment: {
                        ...p.payment,
                        statusFontWeight: (p.payment.statusFontWeight || 'bold') === 'bold' ? 'normal' : 'bold',
                      },
                    }))
                  }
                  className={`p-1.5 rounded border text-xs font-bold transition cursor-pointer ${
                    (design.payment.statusFontWeight || 'bold') === 'bold'
                      ? 'bg-blue-100 text-blue-800 border-blue-300'
                      : 'bg-white text-neutral-700 border-neutral-300 hover:bg-neutral-100'
                  }`}
                  title="Toggle Bold"
                >
                  <Bold className="w-3.5 h-3.5" />
                </button>
                <button
                  type="button"
                  onClick={() =>
                    updateDesign((p) => ({
                      ...p,
                      payment: { ...p.payment, statusItalic: !p.payment.statusItalic },
                    }))
                  }
                  className={`p-1.5 rounded border text-xs font-bold transition cursor-pointer ${
                    design.payment.statusItalic
                      ? 'bg-blue-100 text-blue-800 border-blue-300'
                      : 'bg-white text-neutral-700 border-neutral-300 hover:bg-neutral-100'
                  }`}
                  title="Toggle Italic"
                >
                  <Italic className="w-3.5 h-3.5" />
                </button>
                <button
                  type="button"
                  onClick={() =>
                    updateDesign((p) => ({
                      ...p,
                      payment: { ...p.payment, statusUnderline: !p.payment.statusUnderline },
                    }))
                  }
                  className={`p-1.5 rounded border text-xs font-bold transition cursor-pointer ${
                    design.payment.statusUnderline
                      ? 'bg-blue-100 text-blue-800 border-blue-300'
                      : 'bg-white text-neutral-700 border-neutral-300 hover:bg-neutral-100'
                  }`}
                  title="Toggle Underline"
                >
                  <UnderlineIcon className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>

            <div className="flex flex-col gap-1">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Label Color
              </span>
              <div className="flex items-center gap-1.5">
                <input
                  type="color"
                  value={design.payment.statusColor || design.payment.textColor || '#0B1E36'}
                  onChange={(e) => {
                    const val = e.target.value;
                    updateDesign((p) => ({
                      ...p,
                      payment: { ...p.payment, statusColor: val },
                    }));
                  }}
                  className="w-7 h-7 p-0.5 border border-neutral-300 rounded cursor-pointer"
                />
                <span className="text-[11px] font-mono uppercase text-neutral-600">
                  {design.payment.statusColor || design.payment.textColor || '#0B1E36'}
                </span>
              </div>
            </div>

            <div className="flex flex-col gap-1">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Value Color
              </span>
              <div className="flex items-center gap-1.5">
                <input
                  type="color"
                  value={design.payment.statusValueColor || design.payment.textColor || '#0F172A'}
                  onChange={(e) => {
                    const val = e.target.value;
                    updateDesign((p) => ({
                      ...p,
                      payment: { ...p.payment, statusValueColor: val },
                    }));
                  }}
                  className="w-7 h-7 p-0.5 border border-neutral-300 rounded cursor-pointer"
                />
                <span className="text-[11px] font-mono uppercase text-neutral-600">
                  {design.payment.statusValueColor || design.payment.textColor || '#0F172A'}
                </span>
              </div>
            </div>
          </>
        )}

        {/* 10d. INDEPENDENT PAID AMOUNT */}
        {selectedElement === 'paidAmount' && (
          <>
            <div className="flex flex-col gap-1 min-w-[130px] flex-1">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Paid Label
              </span>
              <input
                type="text"
                value={design.payment.paidLabel || 'Paid Amount:'}
                onChange={(e) => {
                  const val = e.target.value;
                  updateDesign((p) => ({
                    ...p,
                    payment: { ...p.payment, paidLabel: val },
                  }));
                }}
                className="px-2 py-1 text-xs border border-neutral-300 rounded bg-white font-medium"
              />
            </div>

            <div className="flex flex-col gap-1">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Visibility
              </span>
              <button
                type="button"
                onClick={() =>
                  updateDesign((p) => ({
                    ...p,
                    payment: { ...p.payment, showPaid: p.payment.showPaid === false },
                  }))
                }
                className={`flex items-center gap-1 px-2.5 py-1 text-xs rounded border transition cursor-pointer ${
                  design.payment.showPaid !== false
                    ? 'bg-blue-50 text-blue-700 border-blue-300 font-semibold'
                    : 'bg-white text-neutral-500 border-neutral-300'
                }`}
              >
                {design.payment.showPaid !== false ? <Eye className="w-3.5 h-3.5" /> : <EyeOff className="w-3.5 h-3.5" />}
                <span>{design.payment.showPaid !== false ? 'Visible' : 'Hidden'}</span>
              </button>
            </div>

            <FontFamilySelect
              value={design.payment.paidFontFamily || design.payment.fontFamily || design.typography.fontFamily}
              onChange={(f) =>
                updateDesign((p) => ({
                  ...p,
                  payment: { ...p.payment, paidFontFamily: f },
                }))
              }
              label="Paid Font"
            />

            <div className="flex flex-col gap-1">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Font Size
              </span>
              <div className="flex items-center gap-1">
                <input
                  type="number"
                  min={8}
                  max={20}
                  step={0.5}
                  value={design.payment.paidFontSize || design.payment.fontSize || 11.5}
                  onChange={(e) => {
                    const val = Number(e.target.value);
                    updateDesign((p) => ({
                      ...p,
                      payment: { ...p.payment, paidFontSize: val },
                    }));
                  }}
                  className="w-14 px-1 py-1 text-xs text-center border border-neutral-300 rounded font-mono bg-white"
                />
                <span className="text-[10px] text-neutral-400">px</span>
              </div>
            </div>

            <div className="flex flex-col gap-1">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Style
              </span>
              <div className="flex items-center gap-1">
                <button
                  type="button"
                  onClick={() =>
                    updateDesign((p) => ({
                      ...p,
                      payment: {
                        ...p.payment,
                        paidFontWeight: (p.payment.paidFontWeight || 'bold') === 'bold' ? 'normal' : 'bold',
                      },
                    }))
                  }
                  className={`p-1.5 rounded border text-xs font-bold transition cursor-pointer ${
                    (design.payment.paidFontWeight || 'bold') === 'bold'
                      ? 'bg-blue-100 text-blue-800 border-blue-300'
                      : 'bg-white text-neutral-700 border-neutral-300 hover:bg-neutral-100'
                  }`}
                  title="Toggle Bold"
                >
                  <Bold className="w-3.5 h-3.5" />
                </button>
                <button
                  type="button"
                  onClick={() =>
                    updateDesign((p) => ({
                      ...p,
                      payment: { ...p.payment, paidItalic: !p.payment.paidItalic },
                    }))
                  }
                  className={`p-1.5 rounded border text-xs font-bold transition cursor-pointer ${
                    design.payment.paidItalic
                      ? 'bg-blue-100 text-blue-800 border-blue-300'
                      : 'bg-white text-neutral-700 border-neutral-300 hover:bg-neutral-100'
                  }`}
                  title="Toggle Italic"
                >
                  <Italic className="w-3.5 h-3.5" />
                </button>
                <button
                  type="button"
                  onClick={() =>
                    updateDesign((p) => ({
                      ...p,
                      payment: { ...p.payment, paidUnderline: !p.payment.paidUnderline },
                    }))
                  }
                  className={`p-1.5 rounded border text-xs font-bold transition cursor-pointer ${
                    design.payment.paidUnderline
                      ? 'bg-blue-100 text-blue-800 border-blue-300'
                      : 'bg-white text-neutral-700 border-neutral-300 hover:bg-neutral-100'
                  }`}
                  title="Toggle Underline"
                >
                  <UnderlineIcon className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>

            <div className="flex flex-col gap-1">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Label Color
              </span>
              <div className="flex items-center gap-1.5">
                <input
                  type="color"
                  value={design.payment.paidColor || design.payment.textColor || '#0B1E36'}
                  onChange={(e) => {
                    const val = e.target.value;
                    updateDesign((p) => ({
                      ...p,
                      payment: { ...p.payment, paidColor: val },
                    }));
                  }}
                  className="w-7 h-7 p-0.5 border border-neutral-300 rounded cursor-pointer"
                />
                <span className="text-[11px] font-mono uppercase text-neutral-600">
                  {design.payment.paidColor || design.payment.textColor || '#0B1E36'}
                </span>
              </div>
            </div>

            <div className="flex flex-col gap-1">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Value Color
              </span>
              <div className="flex items-center gap-1.5">
                <input
                  type="color"
                  value={design.payment.paidValueColor || design.payment.textColor || '#0F172A'}
                  onChange={(e) => {
                    const val = e.target.value;
                    updateDesign((p) => ({
                      ...p,
                      payment: { ...p.payment, paidValueColor: val },
                    }));
                  }}
                  className="w-7 h-7 p-0.5 border border-neutral-300 rounded cursor-pointer"
                />
                <span className="text-[11px] font-mono uppercase text-neutral-600">
                  {design.payment.paidValueColor || design.payment.textColor || '#0F172A'}
                </span>
              </div>
            </div>
          </>
        )}

        {/* 10e. INDEPENDENT REMAINING AMOUNT */}
        {selectedElement === 'remainingAmount' && (
          <>
            <div className="flex flex-col gap-1 min-w-[130px] flex-1">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Remaining Label
              </span>
              <input
                type="text"
                value={design.payment.remainingLabel || 'Remaining:'}
                onChange={(e) => {
                  const val = e.target.value;
                  updateDesign((p) => ({
                    ...p,
                    payment: { ...p.payment, remainingLabel: val },
                  }));
                }}
                className="px-2 py-1 text-xs border border-neutral-300 rounded bg-white font-medium"
              />
            </div>

            <div className="flex flex-col gap-1">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Visibility
              </span>
              <button
                type="button"
                onClick={() =>
                  updateDesign((p) => ({
                    ...p,
                    payment: { ...p.payment, showRemaining: p.payment.showRemaining === false },
                  }))
                }
                className={`flex items-center gap-1 px-2.5 py-1 text-xs rounded border transition cursor-pointer ${
                  design.payment.showRemaining !== false
                    ? 'bg-blue-50 text-blue-700 border-blue-300 font-semibold'
                    : 'bg-white text-neutral-500 border-neutral-300'
                }`}
              >
                {design.payment.showRemaining !== false ? <Eye className="w-3.5 h-3.5" /> : <EyeOff className="w-3.5 h-3.5" />}
                <span>{design.payment.showRemaining !== false ? 'Visible' : 'Hidden'}</span>
              </button>
            </div>

            <FontFamilySelect
              value={design.payment.remainingFontFamily || design.payment.fontFamily || design.typography.fontFamily}
              onChange={(f) =>
                updateDesign((p) => ({
                  ...p,
                  payment: { ...p.payment, remainingFontFamily: f },
                }))
              }
              label="Remaining Font"
            />

            <div className="flex flex-col gap-1">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Font Size
              </span>
              <div className="flex items-center gap-1">
                <input
                  type="number"
                  min={8}
                  max={20}
                  step={0.5}
                  value={design.payment.remainingFontSize || design.payment.fontSize || 11.5}
                  onChange={(e) => {
                    const val = Number(e.target.value);
                    updateDesign((p) => ({
                      ...p,
                      payment: { ...p.payment, remainingFontSize: val },
                    }));
                  }}
                  className="w-14 px-1 py-1 text-xs text-center border border-neutral-300 rounded font-mono bg-white"
                />
                <span className="text-[10px] text-neutral-400">px</span>
              </div>
            </div>

            <div className="flex flex-col gap-1">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Style
              </span>
              <div className="flex items-center gap-1">
                <button
                  type="button"
                  onClick={() =>
                    updateDesign((p) => ({
                      ...p,
                      payment: {
                        ...p.payment,
                        remainingFontWeight: (p.payment.remainingFontWeight || 'bold') === 'bold' ? 'normal' : 'bold',
                      },
                    }))
                  }
                  className={`p-1.5 rounded border text-xs font-bold transition cursor-pointer ${
                    (design.payment.remainingFontWeight || 'bold') === 'bold'
                      ? 'bg-blue-100 text-blue-800 border-blue-300'
                      : 'bg-white text-neutral-700 border-neutral-300 hover:bg-neutral-100'
                  }`}
                  title="Toggle Bold"
                >
                  <Bold className="w-3.5 h-3.5" />
                </button>
                <button
                  type="button"
                  onClick={() =>
                    updateDesign((p) => ({
                      ...p,
                      payment: { ...p.payment, remainingItalic: !p.payment.remainingItalic },
                    }))
                  }
                  className={`p-1.5 rounded border text-xs font-bold transition cursor-pointer ${
                    design.payment.remainingItalic
                      ? 'bg-blue-100 text-blue-800 border-blue-300'
                      : 'bg-white text-neutral-700 border-neutral-300 hover:bg-neutral-100'
                  }`}
                  title="Toggle Italic"
                >
                  <Italic className="w-3.5 h-3.5" />
                </button>
                <button
                  type="button"
                  onClick={() =>
                    updateDesign((p) => ({
                      ...p,
                      payment: { ...p.payment, remainingUnderline: !p.payment.remainingUnderline },
                    }))
                  }
                  className={`p-1.5 rounded border text-xs font-bold transition cursor-pointer ${
                    design.payment.remainingUnderline
                      ? 'bg-blue-100 text-blue-800 border-blue-300'
                      : 'bg-white text-neutral-700 border-neutral-300 hover:bg-neutral-100'
                  }`}
                  title="Toggle Underline"
                >
                  <UnderlineIcon className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>

            <div className="flex flex-col gap-1">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Label Color
              </span>
              <div className="flex items-center gap-1.5">
                <input
                  type="color"
                  value={design.payment.remainingColor || design.payment.textColor || '#0B1E36'}
                  onChange={(e) => {
                    const val = e.target.value;
                    updateDesign((p) => ({
                      ...p,
                      payment: { ...p.payment, remainingColor: val },
                    }));
                  }}
                  className="w-7 h-7 p-0.5 border border-neutral-300 rounded cursor-pointer"
                />
                <span className="text-[11px] font-mono uppercase text-neutral-600">
                  {design.payment.remainingColor || design.payment.textColor || '#0B1E36'}
                </span>
              </div>
            </div>

            <div className="flex flex-col gap-1">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Value Color
              </span>
              <div className="flex items-center gap-1.5">
                <input
                  type="color"
                  value={design.payment.remainingValueColor || design.payment.textColor || '#0F172A'}
                  onChange={(e) => {
                    const val = e.target.value;
                    updateDesign((p) => ({
                      ...p,
                      payment: { ...p.payment, remainingValueColor: val },
                    }));
                  }}
                  className="w-7 h-7 p-0.5 border border-neutral-300 rounded cursor-pointer"
                />
                <span className="text-[11px] font-mono uppercase text-neutral-600">
                  {design.payment.remainingValueColor || design.payment.textColor || '#0F172A'}
                </span>
              </div>
            </div>
          </>
        )}

        {/* 11. TOTALS SUMMARY */}
        {selectedElement === 'totals' && (
          <>
            <div className="flex flex-col gap-1 min-w-[120px]">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Subtotal Label
              </span>
              <input
                type="text"
                value={design.totals.subtotalLabel || 'Subtotal'}
                onChange={(e) => {
                  const val = e.target.value;
                  updateDesign((p) => ({
                    ...p,
                    totals: { ...p.totals, subtotalLabel: val },
                  }));
                }}
                className="px-2 py-1 text-xs border border-neutral-300 rounded bg-white"
              />
            </div>

            <div className="flex flex-col gap-1 min-w-[120px]">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Discount Label
              </span>
              <input
                type="text"
                value={design.totals.discountLabel || 'Discount'}
                onChange={(e) => {
                  const val = e.target.value;
                  updateDesign((p) => ({
                    ...p,
                    totals: { ...p.totals, discountLabel: val },
                  }));
                }}
                className="px-2 py-1 text-xs border border-neutral-300 rounded bg-white"
              />
            </div>

            <FontFamilySelect
              value={design.totals.fontFamily || design.typography.fontFamily}
              onChange={(f) =>
                updateDesign((p) => ({
                  ...p,
                  totals: { ...p.totals, fontFamily: f },
                }))
              }
              label="Totals Font"
            />

            <div className="flex flex-col gap-1">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Totals Font Size
              </span>
              <div className="flex items-center gap-1">
                <input
                  type="number"
                  min={9}
                  max={16}
                  step={0.5}
                  value={design.totals.fontSize || 11.5}
                  onChange={(e) => {
                    const val = Number(e.target.value);
                    updateDesign((p) => ({
                      ...p,
                      totals: { ...p.totals, fontSize: val },
                    }));
                  }}
                  className="w-14 px-1.5 py-1 text-xs text-center border border-neutral-300 rounded font-mono bg-white"
                />
                <span className="text-[10px] text-neutral-400">px</span>
              </div>
            </div>

            <div className="flex flex-col gap-1">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Label Color
              </span>
              <div className="flex items-center gap-1.5">
                <input
                  type="color"
                  value={design.totals.color || design.colors.primary || '#0B1E36'}
                  onChange={(e) => {
                    const val = e.target.value;
                    updateDesign((p) => ({
                      ...p,
                      totals: { ...p.totals, color: val },
                    }));
                  }}
                  className="w-7 h-7 p-0.5 border border-neutral-300 rounded cursor-pointer"
                />
                <span className="text-[11px] font-mono uppercase text-neutral-600">
                  {design.totals.color || design.colors.primary || '#0B1E36'}
                </span>
              </div>
            </div>

            <div className="flex flex-col gap-1">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Value Color
              </span>
              <div className="flex items-center gap-1.5">
                <input
                  type="color"
                  value={design.totals.valueColor || '#0F172A'}
                  onChange={(e) => {
                    const val = e.target.value;
                    updateDesign((p) => ({
                      ...p,
                      totals: { ...p.totals, valueColor: val },
                    }));
                  }}
                  className="w-7 h-7 p-0.5 border border-neutral-300 rounded cursor-pointer"
                />
                <span className="text-[11px] font-mono uppercase text-neutral-600">
                  {design.totals.valueColor || '#0F172A'}
                </span>
              </div>
            </div>

            <div className="flex flex-col gap-1">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Border
              </span>
              <div className="flex items-center gap-1.5">
                <input
                  type="color"
                  value={design.totals.borderColor || '#D8E2EC'}
                  onChange={(e) => {
                    const val = e.target.value;
                    updateDesign((p) => ({
                      ...p,
                      totals: { ...p.totals, borderColor: val },
                    }));
                  }}
                  className="w-7 h-7 p-0.5 border border-neutral-300 rounded cursor-pointer"
                />
                <span className="text-[11px] font-mono uppercase text-neutral-600">
                  {design.totals.borderColor || '#D8E2EC'}
                </span>
              </div>
            </div>

            <div className="flex flex-col gap-1">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Border Style
              </span>
              <select
                value={design.totals.borderStyle || 'solid'}
                onChange={(e) => {
                  const val = e.target.value as 'none' | 'solid' | 'dashed';
                  updateDesign((p) => ({
                    ...p,
                    totals: { ...p.totals, borderStyle: val },
                  }));
                }}
                className="px-2 py-1 text-xs border border-neutral-300 rounded bg-white font-medium"
              >
                <option value="solid">Solid</option>
                <option value="dashed">Dashed</option>
                <option value="none">None</option>
              </select>
            </div>

            <div className="flex flex-col gap-1">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Border Width
              </span>
              <div className="flex items-center gap-1">
                <input
                  type="number"
                  min={0}
                  max={10}
                  step={0.5}
                  value={design.totals.borderWidth ?? 1}
                  onChange={(e) => {
                    const val = Math.max(0, Number(e.target.value));
                    updateDesign((p) => ({
                      ...p,
                      totals: { ...p.totals, borderWidth: val },
                    }));
                  }}
                  className="w-14 px-1.5 py-1 text-xs text-center border border-neutral-300 rounded font-mono bg-white"
                />
                <span className="text-[10px] text-neutral-400">px</span>
              </div>
            </div>

            <div className="flex flex-col gap-1">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Border Radius
              </span>
              <div className="flex items-center gap-1">
                <input
                  type="number"
                  min={0}
                  max={24}
                  step={1}
                  value={design.totals.borderRadius ?? 4}
                  onChange={(e) => {
                    const val = Math.max(0, Number(e.target.value));
                    updateDesign((p) => ({
                      ...p,
                      totals: { ...p.totals, borderRadius: val },
                    }));
                  }}
                  className="w-14 px-1.5 py-1 text-xs text-center border border-neutral-300 rounded font-mono bg-white"
                />
                <span className="text-[10px] text-neutral-400">px</span>
              </div>
            </div>

            <div className="flex flex-col gap-1">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Background
              </span>
              <div className="flex items-center gap-1.5">
                <input
                  type="color"
                  value={design.totals.backgroundColor || '#F0F7FF'}
                  onChange={(e) => {
                    const val = e.target.value;
                    updateDesign((p) => ({
                      ...p,
                      totals: { ...p.totals, backgroundColor: val },
                    }));
                  }}
                  className="w-7 h-7 p-0.5 border border-neutral-300 rounded cursor-pointer"
                />
                <span className="text-[11px] font-mono uppercase text-neutral-600">
                  {design.totals.backgroundColor || '#F0F7FF'}
                </span>
              </div>
            </div>

            <div className="flex flex-col gap-1">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Style
              </span>
              <div className="flex items-center gap-1">
                <button
                  type="button"
                  onClick={() =>
                    updateDesign((p) => ({
                      ...p,
                      totals: { ...p.totals, italic: !p.totals.italic },
                    }))
                  }
                  className={`p-1.5 rounded border transition cursor-pointer ${
                    design.totals.italic
                      ? 'bg-blue-100 text-blue-800 border-blue-300 font-bold'
                      : 'bg-white text-neutral-600 border-neutral-300 hover:bg-neutral-100'
                  }`}
                  title="Italic"
                >
                  <Italic className="w-3.5 h-3.5" />
                </button>
                <button
                  type="button"
                  onClick={() =>
                    updateDesign((p) => ({
                      ...p,
                      totals: { ...p.totals, underline: !p.totals.underline },
                    }))
                  }
                  className={`p-1.5 rounded border transition cursor-pointer ${
                    design.totals.underline
                      ? 'bg-blue-100 text-blue-800 border-blue-300 font-bold'
                      : 'bg-white text-neutral-600 border-neutral-300 hover:bg-neutral-100'
                  }`}
                  title="Underline"
                >
                  <Underline className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          </>
        )}

        {/* 12. GRAND TOTAL */}
        {selectedElement === 'grandTotal' && (
          <>
            <div className="flex flex-col gap-1 min-w-[150px]">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Grand Total Label
              </span>
              <input
                type="text"
                value={design.totals.grandTotalLabel || 'Grand Total'}
                onChange={(e) => {
                  const val = e.target.value;
                  updateDesign((p) => ({
                    ...p,
                    totals: { ...p.totals, grandTotalLabel: val },
                  }));
                }}
                className="px-2 py-1 text-xs border border-neutral-300 rounded bg-white font-bold"
              />
            </div>

            <FontFamilySelect
              value={design.totals.grandTotalFontFamily || design.totals.fontFamily || design.typography.fontFamily}
              onChange={(f) =>
                updateDesign((p) => ({
                  ...p,
                  totals: { ...p.totals, grandTotalFontFamily: f },
                }))
              }
              label="Grand Total Font"
            />

            <div className="flex flex-col gap-1">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Banner Background
              </span>
              <div className="flex items-center gap-1.5">
                <input
                  type="color"
                  value={design.colors.grandTotalBackground || '#1E4E8C'}
                  onChange={(e) => {
                    const val = e.target.value;
                    updateDesign((p) => ({
                      ...p,
                      colors: { ...p.colors, grandTotalBackground: val },
                    }));
                  }}
                  className="w-7 h-7 p-0.5 border border-neutral-300 rounded cursor-pointer"
                />
                <span className="text-[11px] font-mono uppercase text-neutral-600">
                  {design.colors.grandTotalBackground || '#1E4E8C'}
                </span>
              </div>
            </div>

            <div className="flex flex-col gap-1">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Banner Text Color
              </span>
              <div className="flex items-center gap-1.5">
                <input
                  type="color"
                  value={design.colors.grandTotalText || '#FFFFFF'}
                  onChange={(e) => {
                    const val = e.target.value;
                    updateDesign((p) => ({
                      ...p,
                      colors: { ...p.colors, grandTotalText: val },
                    }));
                  }}
                  className="w-7 h-7 p-0.5 border border-neutral-300 rounded cursor-pointer"
                />
                <span className="text-[11px] font-mono uppercase text-neutral-600">
                  {design.colors.grandTotalText || '#FFFFFF'}
                </span>
              </div>
            </div>

            <div className="flex flex-col gap-1">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Font Size
              </span>
              <div className="flex items-center gap-1">
                <input
                  type="number"
                  min={11}
                  max={22}
                  step={0.5}
                  value={design.totals.grandTotalFontSize || design.totals.fontSize || 12}
                  onChange={(e) => {
                    const val = Number(e.target.value);
                    updateDesign((p) => ({
                      ...p,
                      totals: { ...p.totals, grandTotalFontSize: val },
                    }));
                  }}
                  className="w-14 px-1.5 py-1 text-xs text-center border border-neutral-300 rounded font-mono bg-white"
                />
                <span className="text-[10px] text-neutral-400">px</span>
              </div>
            </div>

            <div className="flex flex-col gap-1">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Style
              </span>
              <div className="flex items-center gap-1">
                <button
                  type="button"
                  onClick={() =>
                    updateDesign((p) => ({
                      ...p,
                      totals: { ...p.totals, grandTotalItalic: !p.totals.grandTotalItalic },
                    }))
                  }
                  className={`p-1.5 rounded border transition cursor-pointer ${
                    design.totals.grandTotalItalic
                      ? 'bg-blue-100 text-blue-800 border-blue-300 font-bold'
                      : 'bg-white text-neutral-600 border-neutral-300 hover:bg-neutral-100'
                  }`}
                  title="Italic"
                >
                  <Italic className="w-3.5 h-3.5" />
                </button>
                <button
                  type="button"
                  onClick={() =>
                    updateDesign((p) => ({
                      ...p,
                      totals: { ...p.totals, grandTotalUnderline: !p.totals.grandTotalUnderline },
                    }))
                  }
                  className={`p-1.5 rounded border transition cursor-pointer ${
                    design.totals.grandTotalUnderline
                      ? 'bg-blue-100 text-blue-800 border-blue-300 font-bold'
                      : 'bg-white text-neutral-600 border-neutral-300 hover:bg-neutral-100'
                  }`}
                  title="Underline"
                >
                  <Underline className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          </>
        )}

        {/* 12b. INDEPENDENT SUBTOTAL */}
        {selectedElement === 'subtotal' && (
          <>
            <div className="flex flex-col gap-1 min-w-[130px] flex-1">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Subtotal Label
              </span>
              <input
                type="text"
                value={design.totals.subtotalLabel || 'Subtotal'}
                onChange={(e) => {
                  const val = e.target.value;
                  updateDesign((p) => ({
                    ...p,
                    totals: { ...p.totals, subtotalLabel: val },
                  }));
                }}
                className="px-2 py-1 text-xs border border-neutral-300 rounded bg-white font-medium"
              />
            </div>

            <div className="flex flex-col gap-1">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Visibility
              </span>
              <button
                type="button"
                onClick={() =>
                  updateDesign((p) => ({
                    ...p,
                    totals: { ...p.totals, showSubtotal: p.totals.showSubtotal === false },
                  }))
                }
                className={`flex items-center gap-1 px-2.5 py-1 text-xs rounded border transition cursor-pointer ${
                  design.totals.showSubtotal !== false
                    ? 'bg-blue-50 text-blue-700 border-blue-300 font-semibold'
                    : 'bg-white text-neutral-500 border-neutral-300'
                }`}
              >
                {design.totals.showSubtotal !== false ? <Eye className="w-3.5 h-3.5" /> : <EyeOff className="w-3.5 h-3.5" />}
                <span>{design.totals.showSubtotal !== false ? 'Visible' : 'Hidden'}</span>
              </button>
            </div>

            <FontFamilySelect
              value={design.totals.subtotalFontFamily || design.totals.fontFamily || design.typography.fontFamily}
              onChange={(f) =>
                updateDesign((p) => ({
                  ...p,
                  totals: { ...p.totals, subtotalFontFamily: f },
                }))
              }
              label="Subtotal Font"
            />

            <div className="flex flex-col gap-1">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Font Size
              </span>
              <div className="flex items-center gap-1">
                <input
                  type="number"
                  min={8}
                  max={20}
                  step={0.5}
                  value={design.totals.subtotalFontSize || design.totals.fontSize || 11.5}
                  onChange={(e) => {
                    const val = Number(e.target.value);
                    updateDesign((p) => ({
                      ...p,
                      totals: { ...p.totals, subtotalFontSize: val },
                    }));
                  }}
                  className="w-14 px-1 py-1 text-xs text-center border border-neutral-300 rounded font-mono bg-white"
                />
                <span className="text-[10px] text-neutral-400">px</span>
              </div>
            </div>

            <div className="flex flex-col gap-1">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Style
              </span>
              <div className="flex items-center gap-1">
                <button
                  type="button"
                  onClick={() =>
                    updateDesign((p) => ({
                      ...p,
                      totals: {
                        ...p.totals,
                        subtotalFontWeight: (p.totals.subtotalFontWeight || 'bold') === 'bold' ? 'normal' : 'bold',
                      },
                    }))
                  }
                  className={`p-1.5 rounded border text-xs font-bold transition cursor-pointer ${
                    (design.totals.subtotalFontWeight || 'bold') === 'bold'
                      ? 'bg-blue-100 text-blue-800 border-blue-300'
                      : 'bg-white text-neutral-700 border-neutral-300 hover:bg-neutral-100'
                  }`}
                  title="Toggle Bold"
                >
                  <Bold className="w-3.5 h-3.5" />
                </button>
                <button
                  type="button"
                  onClick={() =>
                    updateDesign((p) => ({
                      ...p,
                      totals: { ...p.totals, subtotalItalic: !p.totals.subtotalItalic },
                    }))
                  }
                  className={`p-1.5 rounded border text-xs font-bold transition cursor-pointer ${
                    design.totals.subtotalItalic
                      ? 'bg-blue-100 text-blue-800 border-blue-300'
                      : 'bg-white text-neutral-700 border-neutral-300 hover:bg-neutral-100'
                  }`}
                  title="Toggle Italic"
                >
                  <Italic className="w-3.5 h-3.5" />
                </button>
                <button
                  type="button"
                  onClick={() =>
                    updateDesign((p) => ({
                      ...p,
                      totals: { ...p.totals, subtotalUnderline: !p.totals.subtotalUnderline },
                    }))
                  }
                  className={`p-1.5 rounded border text-xs font-bold transition cursor-pointer ${
                    design.totals.subtotalUnderline
                      ? 'bg-blue-100 text-blue-800 border-blue-300'
                      : 'bg-white text-neutral-700 border-neutral-300 hover:bg-neutral-100'
                  }`}
                  title="Toggle Underline"
                >
                  <UnderlineIcon className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>

            <div className="flex flex-col gap-1">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Label Color
              </span>
              <div className="flex items-center gap-1.5">
                <input
                  type="color"
                  value={design.totals.subtotalColor || design.totals.color || '#0B1E36'}
                  onChange={(e) => {
                    const val = e.target.value;
                    updateDesign((p) => ({
                      ...p,
                      totals: { ...p.totals, subtotalColor: val },
                    }));
                  }}
                  className="w-7 h-7 p-0.5 border border-neutral-300 rounded cursor-pointer"
                />
                <span className="text-[11px] font-mono uppercase text-neutral-600">
                  {design.totals.subtotalColor || design.totals.color || '#0B1E36'}
                </span>
              </div>
            </div>

            <div className="flex flex-col gap-1">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Value Color
              </span>
              <div className="flex items-center gap-1.5">
                <input
                  type="color"
                  value={design.totals.subtotalValueColor || design.totals.valueColor || '#0F172A'}
                  onChange={(e) => {
                    const val = e.target.value;
                    updateDesign((p) => ({
                      ...p,
                      totals: { ...p.totals, subtotalValueColor: val },
                    }));
                  }}
                  className="w-7 h-7 p-0.5 border border-neutral-300 rounded cursor-pointer"
                />
                <span className="text-[11px] font-mono uppercase text-neutral-600">
                  {design.totals.subtotalValueColor || design.totals.valueColor || '#0F172A'}
                </span>
              </div>
            </div>
          </>
        )}

        {/* 12c. INDEPENDENT DISCOUNT */}
        {selectedElement === 'discountTotal' && (
          <>
            <div className="flex flex-col gap-1 min-w-[130px] flex-1">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Discount Label
              </span>
              <input
                type="text"
                value={design.totals.discountLabel || 'Discount'}
                onChange={(e) => {
                  const val = e.target.value;
                  updateDesign((p) => ({
                    ...p,
                    totals: { ...p.totals, discountLabel: val },
                  }));
                }}
                className="px-2 py-1 text-xs border border-neutral-300 rounded bg-white font-medium"
              />
            </div>

            <div className="flex flex-col gap-1">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Visibility
              </span>
              <button
                type="button"
                onClick={() =>
                  updateDesign((p) => ({
                    ...p,
                    totals: { ...p.totals, showDiscount: p.totals.showDiscount === false },
                  }))
                }
                className={`flex items-center gap-1 px-2.5 py-1 text-xs rounded border transition cursor-pointer ${
                  design.totals.showDiscount !== false
                    ? 'bg-blue-50 text-blue-700 border-blue-300 font-semibold'
                    : 'bg-white text-neutral-500 border-neutral-300'
                }`}
              >
                {design.totals.showDiscount !== false ? <Eye className="w-3.5 h-3.5" /> : <EyeOff className="w-3.5 h-3.5" />}
                <span>{design.totals.showDiscount !== false ? 'Visible' : 'Hidden'}</span>
              </button>
            </div>

            <FontFamilySelect
              value={design.totals.discountFontFamily || design.totals.fontFamily || design.typography.fontFamily}
              onChange={(f) =>
                updateDesign((p) => ({
                  ...p,
                  totals: { ...p.totals, discountFontFamily: f },
                }))
              }
              label="Discount Font"
            />

            <div className="flex flex-col gap-1">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Font Size
              </span>
              <div className="flex items-center gap-1">
                <input
                  type="number"
                  min={8}
                  max={20}
                  step={0.5}
                  value={design.totals.discountFontSize || design.totals.fontSize || 11.5}
                  onChange={(e) => {
                    const val = Number(e.target.value);
                    updateDesign((p) => ({
                      ...p,
                      totals: { ...p.totals, discountFontSize: val },
                    }));
                  }}
                  className="w-14 px-1 py-1 text-xs text-center border border-neutral-300 rounded font-mono bg-white"
                />
                <span className="text-[10px] text-neutral-400">px</span>
              </div>
            </div>

            <div className="flex flex-col gap-1">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Style
              </span>
              <div className="flex items-center gap-1">
                <button
                  type="button"
                  onClick={() =>
                    updateDesign((p) => ({
                      ...p,
                      totals: {
                        ...p.totals,
                        discountFontWeight: (p.totals.discountFontWeight || 'bold') === 'bold' ? 'normal' : 'bold',
                      },
                    }))
                  }
                  className={`p-1.5 rounded border text-xs font-bold transition cursor-pointer ${
                    (design.totals.discountFontWeight || 'bold') === 'bold'
                      ? 'bg-blue-100 text-blue-800 border-blue-300'
                      : 'bg-white text-neutral-700 border-neutral-300 hover:bg-neutral-100'
                  }`}
                  title="Toggle Bold"
                >
                  <Bold className="w-3.5 h-3.5" />
                </button>
                <button
                  type="button"
                  onClick={() =>
                    updateDesign((p) => ({
                      ...p,
                      totals: { ...p.totals, discountItalic: !p.totals.discountItalic },
                    }))
                  }
                  className={`p-1.5 rounded border text-xs font-bold transition cursor-pointer ${
                    design.totals.discountItalic
                      ? 'bg-blue-100 text-blue-800 border-blue-300'
                      : 'bg-white text-neutral-700 border-neutral-300 hover:bg-neutral-100'
                  }`}
                  title="Toggle Italic"
                >
                  <Italic className="w-3.5 h-3.5" />
                </button>
                <button
                  type="button"
                  onClick={() =>
                    updateDesign((p) => ({
                      ...p,
                      totals: { ...p.totals, discountUnderline: !p.totals.discountUnderline },
                    }))
                  }
                  className={`p-1.5 rounded border text-xs font-bold transition cursor-pointer ${
                    design.totals.discountUnderline
                      ? 'bg-blue-100 text-blue-800 border-blue-300'
                      : 'bg-white text-neutral-700 border-neutral-300 hover:bg-neutral-100'
                  }`}
                  title="Toggle Underline"
                >
                  <UnderlineIcon className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>

            <div className="flex flex-col gap-1">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Label Color
              </span>
              <div className="flex items-center gap-1.5">
                <input
                  type="color"
                  value={design.totals.discountColor || design.totals.color || '#0B1E36'}
                  onChange={(e) => {
                    const val = e.target.value;
                    updateDesign((p) => ({
                      ...p,
                      totals: { ...p.totals, discountColor: val },
                    }));
                  }}
                  className="w-7 h-7 p-0.5 border border-neutral-300 rounded cursor-pointer"
                />
                <span className="text-[11px] font-mono uppercase text-neutral-600">
                  {design.totals.discountColor || design.totals.color || '#0B1E36'}
                </span>
              </div>
            </div>

            <div className="flex flex-col gap-1">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Value Color
              </span>
              <div className="flex items-center gap-1.5">
                <input
                  type="color"
                  value={design.totals.discountValueColor || design.totals.valueColor || '#0F172A'}
                  onChange={(e) => {
                    const val = e.target.value;
                    updateDesign((p) => ({
                      ...p,
                      totals: { ...p.totals, discountValueColor: val },
                    }));
                  }}
                  className="w-7 h-7 p-0.5 border border-neutral-300 rounded cursor-pointer"
                />
                <span className="text-[11px] font-mono uppercase text-neutral-600">
                  {design.totals.discountValueColor || design.totals.valueColor || '#0F172A'}
                </span>
              </div>
            </div>
          </>
        )}

        {/* 12d. INDEPENDENT TAX */}
        {selectedElement === 'taxTotal' && (
          <>
            <div className="flex flex-col gap-1 min-w-[130px] flex-1">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Tax Label
              </span>
              <input
                type="text"
                value={design.totals.taxLabel || 'Tax'}
                onChange={(e) => {
                  const val = e.target.value;
                  updateDesign((p) => ({
                    ...p,
                    totals: { ...p.totals, taxLabel: val },
                  }));
                }}
                className="px-2 py-1 text-xs border border-neutral-300 rounded bg-white font-medium"
              />
            </div>

            <div className="flex flex-col gap-1">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Visibility
              </span>
              <button
                type="button"
                onClick={() =>
                  updateDesign((p) => ({
                    ...p,
                    totals: { ...p.totals, showTax: p.totals.showTax === false },
                  }))
                }
                className={`flex items-center gap-1 px-2.5 py-1 text-xs rounded border transition cursor-pointer ${
                  design.totals.showTax !== false
                    ? 'bg-blue-50 text-blue-700 border-blue-300 font-semibold'
                    : 'bg-white text-neutral-500 border-neutral-300'
                }`}
              >
                {design.totals.showTax !== false ? <Eye className="w-3.5 h-3.5" /> : <EyeOff className="w-3.5 h-3.5" />}
                <span>{design.totals.showTax !== false ? 'Visible' : 'Hidden'}</span>
              </button>
            </div>

            <FontFamilySelect
              value={design.totals.taxFontFamily || design.totals.fontFamily || design.typography.fontFamily}
              onChange={(f) =>
                updateDesign((p) => ({
                  ...p,
                  totals: { ...p.totals, taxFontFamily: f },
                }))
              }
              label="Tax Font"
            />

            <div className="flex flex-col gap-1">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Font Size
              </span>
              <div className="flex items-center gap-1">
                <input
                  type="number"
                  min={8}
                  max={20}
                  step={0.5}
                  value={design.totals.taxFontSize || design.totals.fontSize || 11.5}
                  onChange={(e) => {
                    const val = Number(e.target.value);
                    updateDesign((p) => ({
                      ...p,
                      totals: { ...p.totals, taxFontSize: val },
                    }));
                  }}
                  className="w-14 px-1 py-1 text-xs text-center border border-neutral-300 rounded font-mono bg-white"
                />
                <span className="text-[10px] text-neutral-400">px</span>
              </div>
            </div>

            <div className="flex flex-col gap-1">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Style
              </span>
              <div className="flex items-center gap-1">
                <button
                  type="button"
                  onClick={() =>
                    updateDesign((p) => ({
                      ...p,
                      totals: {
                        ...p.totals,
                        taxFontWeight: (p.totals.taxFontWeight || 'bold') === 'bold' ? 'normal' : 'bold',
                      },
                    }))
                  }
                  className={`p-1.5 rounded border text-xs font-bold transition cursor-pointer ${
                    (design.totals.taxFontWeight || 'bold') === 'bold'
                      ? 'bg-blue-100 text-blue-800 border-blue-300'
                      : 'bg-white text-neutral-700 border-neutral-300 hover:bg-neutral-100'
                  }`}
                  title="Toggle Bold"
                >
                  <Bold className="w-3.5 h-3.5" />
                </button>
                <button
                  type="button"
                  onClick={() =>
                    updateDesign((p) => ({
                      ...p,
                      totals: { ...p.totals, taxItalic: !p.totals.taxItalic },
                    }))
                  }
                  className={`p-1.5 rounded border text-xs font-bold transition cursor-pointer ${
                    design.totals.taxItalic
                      ? 'bg-blue-100 text-blue-800 border-blue-300'
                      : 'bg-white text-neutral-700 border-neutral-300 hover:bg-neutral-100'
                  }`}
                  title="Toggle Italic"
                >
                  <Italic className="w-3.5 h-3.5" />
                </button>
                <button
                  type="button"
                  onClick={() =>
                    updateDesign((p) => ({
                      ...p,
                      totals: { ...p.totals, taxUnderline: !p.totals.taxUnderline },
                    }))
                  }
                  className={`p-1.5 rounded border text-xs font-bold transition cursor-pointer ${
                    design.totals.taxUnderline
                      ? 'bg-blue-100 text-blue-800 border-blue-300'
                      : 'bg-white text-neutral-700 border-neutral-300 hover:bg-neutral-100'
                  }`}
                  title="Toggle Underline"
                >
                  <UnderlineIcon className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>

            <div className="flex flex-col gap-1">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Label Color
              </span>
              <div className="flex items-center gap-1.5">
                <input
                  type="color"
                  value={design.totals.taxColor || design.totals.color || '#0B1E36'}
                  onChange={(e) => {
                    const val = e.target.value;
                    updateDesign((p) => ({
                      ...p,
                      totals: { ...p.totals, taxColor: val },
                    }));
                  }}
                  className="w-7 h-7 p-0.5 border border-neutral-300 rounded cursor-pointer"
                />
                <span className="text-[11px] font-mono uppercase text-neutral-600">
                  {design.totals.taxColor || design.totals.color || '#0B1E36'}
                </span>
              </div>
            </div>

            <div className="flex flex-col gap-1">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Value Color
              </span>
              <div className="flex items-center gap-1.5">
                <input
                  type="color"
                  value={design.totals.taxValueColor || design.totals.valueColor || '#0F172A'}
                  onChange={(e) => {
                    const val = e.target.value;
                    updateDesign((p) => ({
                      ...p,
                      totals: { ...p.totals, taxValueColor: val },
                    }));
                  }}
                  className="w-7 h-7 p-0.5 border border-neutral-300 rounded cursor-pointer"
                />
                <span className="text-[11px] font-mono uppercase text-neutral-600">
                  {design.totals.taxValueColor || design.totals.valueColor || '#0F172A'}
                </span>
              </div>
            </div>
          </>
        )}

        {/* 12e. INDEPENDENT TOTAL PAID IN TOTALS */}
        {selectedElement === 'totalPaid' && (
          <>
            <div className="flex flex-col gap-1 min-w-[130px] flex-1">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Paid Row Label
              </span>
              <input
                type="text"
                value={design.totals.totalPaidLabel || 'Paid / Received'}
                onChange={(e) => {
                  const val = e.target.value;
                  updateDesign((p) => ({
                    ...p,
                    totals: { ...p.totals, totalPaidLabel: val },
                  }));
                }}
                className="px-2 py-1 text-xs border border-neutral-300 rounded bg-white font-medium"
              />
            </div>

            <div className="flex flex-col gap-1">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Visibility
              </span>
              <button
                type="button"
                onClick={() =>
                  updateDesign((p) => ({
                    ...p,
                    totals: { ...p.totals, showTotalPaid: !p.totals.showTotalPaid },
                  }))
                }
                className={`flex items-center gap-1 px-2.5 py-1 text-xs rounded border transition cursor-pointer ${
                  design.totals.showTotalPaid
                    ? 'bg-blue-50 text-blue-700 border-blue-300 font-semibold'
                    : 'bg-white text-neutral-500 border-neutral-300'
                }`}
              >
                {design.totals.showTotalPaid ? <Eye className="w-3.5 h-3.5" /> : <EyeOff className="w-3.5 h-3.5" />}
                <span>{design.totals.showTotalPaid ? 'Visible' : 'Hidden'}</span>
              </button>
            </div>

            <FontFamilySelect
              value={design.totals.totalPaidFontFamily || design.totals.fontFamily || design.typography.fontFamily}
              onChange={(f) =>
                updateDesign((p) => ({
                  ...p,
                  totals: { ...p.totals, totalPaidFontFamily: f },
                }))
              }
              label="Paid Font"
            />

            <div className="flex flex-col gap-1">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Font Size
              </span>
              <div className="flex items-center gap-1">
                <input
                  type="number"
                  min={8}
                  max={20}
                  step={0.5}
                  value={design.totals.totalPaidFontSize || design.totals.fontSize || 11.5}
                  onChange={(e) => {
                    const val = Number(e.target.value);
                    updateDesign((p) => ({
                      ...p,
                      totals: { ...p.totals, totalPaidFontSize: val },
                    }));
                  }}
                  className="w-14 px-1 py-1 text-xs text-center border border-neutral-300 rounded font-mono bg-white"
                />
                <span className="text-[10px] text-neutral-400">px</span>
              </div>
            </div>

            <div className="flex flex-col gap-1">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Style
              </span>
              <div className="flex items-center gap-1">
                <button
                  type="button"
                  onClick={() =>
                    updateDesign((p) => ({
                      ...p,
                      totals: {
                        ...p.totals,
                        totalPaidFontWeight: (p.totals.totalPaidFontWeight || 'bold') === 'bold' ? 'normal' : 'bold',
                      },
                    }))
                  }
                  className={`p-1.5 rounded border text-xs font-bold transition cursor-pointer ${
                    (design.totals.totalPaidFontWeight || 'bold') === 'bold'
                      ? 'bg-blue-100 text-blue-800 border-blue-300'
                      : 'bg-white text-neutral-700 border-neutral-300 hover:bg-neutral-100'
                  }`}
                  title="Toggle Bold"
                >
                  <Bold className="w-3.5 h-3.5" />
                </button>
                <button
                  type="button"
                  onClick={() =>
                    updateDesign((p) => ({
                      ...p,
                      totals: { ...p.totals, totalPaidItalic: !p.totals.totalPaidItalic },
                    }))
                  }
                  className={`p-1.5 rounded border text-xs font-bold transition cursor-pointer ${
                    design.totals.totalPaidItalic
                      ? 'bg-blue-100 text-blue-800 border-blue-300'
                      : 'bg-white text-neutral-700 border-neutral-300 hover:bg-neutral-100'
                  }`}
                  title="Toggle Italic"
                >
                  <Italic className="w-3.5 h-3.5" />
                </button>
                <button
                  type="button"
                  onClick={() =>
                    updateDesign((p) => ({
                      ...p,
                      totals: { ...p.totals, totalPaidUnderline: !p.totals.totalPaidUnderline },
                    }))
                  }
                  className={`p-1.5 rounded border text-xs font-bold transition cursor-pointer ${
                    design.totals.totalPaidUnderline
                      ? 'bg-blue-100 text-blue-800 border-blue-300'
                      : 'bg-white text-neutral-700 border-neutral-300 hover:bg-neutral-100'
                  }`}
                  title="Toggle Underline"
                >
                  <UnderlineIcon className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>

            <div className="flex flex-col gap-1">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Label Color
              </span>
              <div className="flex items-center gap-1.5">
                <input
                  type="color"
                  value={design.totals.totalPaidColor || design.totals.color || '#0B1E36'}
                  onChange={(e) => {
                    const val = e.target.value;
                    updateDesign((p) => ({
                      ...p,
                      totals: { ...p.totals, totalPaidColor: val },
                    }));
                  }}
                  className="w-7 h-7 p-0.5 border border-neutral-300 rounded cursor-pointer"
                />
                <span className="text-[11px] font-mono uppercase text-neutral-600">
                  {design.totals.totalPaidColor || design.totals.color || '#0B1E36'}
                </span>
              </div>
            </div>

            <div className="flex flex-col gap-1">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Value Color
              </span>
              <div className="flex items-center gap-1.5">
                <input
                  type="color"
                  value={design.totals.totalPaidValueColor || design.totals.valueColor || '#0F172A'}
                  onChange={(e) => {
                    const val = e.target.value;
                    updateDesign((p) => ({
                      ...p,
                      totals: { ...p.totals, totalPaidValueColor: val },
                    }));
                  }}
                  className="w-7 h-7 p-0.5 border border-neutral-300 rounded cursor-pointer"
                />
                <span className="text-[11px] font-mono uppercase text-neutral-600">
                  {design.totals.totalPaidValueColor || design.totals.valueColor || '#0F172A'}
                </span>
              </div>
            </div>
          </>
        )}

        {/* 12f. INDEPENDENT REMAINING TOTAL */}
        {selectedElement === 'remainingTotal' && (
          <>
            <div className="flex flex-col gap-1 min-w-[130px] flex-1">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Remaining Label
              </span>
              <input
                type="text"
                value={design.totals.remainingLabel || 'Remaining'}
                onChange={(e) => {
                  const val = e.target.value;
                  updateDesign((p) => ({
                    ...p,
                    totals: { ...p.totals, remainingLabel: val },
                  }));
                }}
                className="px-2 py-1 text-xs border border-neutral-300 rounded bg-white font-medium"
              />
            </div>

            <div className="flex flex-col gap-1">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Visibility
              </span>
              <button
                type="button"
                onClick={() =>
                  updateDesign((p) => ({
                    ...p,
                    totals: { ...p.totals, showRemaining: !p.totals.showRemaining },
                  }))
                }
                className={`flex items-center gap-1 px-2.5 py-1 text-xs rounded border transition cursor-pointer ${
                  design.totals.showRemaining
                    ? 'bg-blue-50 text-blue-700 border-blue-300 font-semibold'
                    : 'bg-white text-neutral-500 border-neutral-300'
                }`}
              >
                {design.totals.showRemaining ? <Eye className="w-3.5 h-3.5" /> : <EyeOff className="w-3.5 h-3.5" />}
                <span>{design.totals.showRemaining ? 'Visible' : 'Hidden'}</span>
              </button>
            </div>

            <FontFamilySelect
              value={design.totals.remainingFontFamily || design.totals.fontFamily || design.typography.fontFamily}
              onChange={(f) =>
                updateDesign((p) => ({
                  ...p,
                  totals: { ...p.totals, remainingFontFamily: f },
                }))
              }
              label="Remaining Font"
            />

            <div className="flex flex-col gap-1">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Font Size
              </span>
              <div className="flex items-center gap-1">
                <input
                  type="number"
                  min={8}
                  max={20}
                  step={0.5}
                  value={design.totals.remainingFontSize || design.totals.fontSize || 11.5}
                  onChange={(e) => {
                    const val = Number(e.target.value);
                    updateDesign((p) => ({
                      ...p,
                      totals: { ...p.totals, remainingFontSize: val },
                    }));
                  }}
                  className="w-14 px-1 py-1 text-xs text-center border border-neutral-300 rounded font-mono bg-white"
                />
                <span className="text-[10px] text-neutral-400">px</span>
              </div>
            </div>

            <div className="flex flex-col gap-1">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Style
              </span>
              <div className="flex items-center gap-1">
                <button
                  type="button"
                  onClick={() =>
                    updateDesign((p) => ({
                      ...p,
                      totals: {
                        ...p.totals,
                        remainingFontWeight: (p.totals.remainingFontWeight || 'bold') === 'bold' ? 'normal' : 'bold',
                      },
                    }))
                  }
                  className={`p-1.5 rounded border text-xs font-bold transition cursor-pointer ${
                    (design.totals.remainingFontWeight || 'bold') === 'bold'
                      ? 'bg-blue-100 text-blue-800 border-blue-300'
                      : 'bg-white text-neutral-700 border-neutral-300 hover:bg-neutral-100'
                  }`}
                  title="Toggle Bold"
                >
                  <Bold className="w-3.5 h-3.5" />
                </button>
                <button
                  type="button"
                  onClick={() =>
                    updateDesign((p) => ({
                      ...p,
                      totals: { ...p.totals, remainingItalic: !p.totals.remainingItalic },
                    }))
                  }
                  className={`p-1.5 rounded border text-xs font-bold transition cursor-pointer ${
                    design.totals.remainingItalic
                      ? 'bg-blue-100 text-blue-800 border-blue-300'
                      : 'bg-white text-neutral-700 border-neutral-300 hover:bg-neutral-100'
                  }`}
                  title="Toggle Italic"
                >
                  <Italic className="w-3.5 h-3.5" />
                </button>
                <button
                  type="button"
                  onClick={() =>
                    updateDesign((p) => ({
                      ...p,
                      totals: { ...p.totals, remainingUnderline: !p.totals.remainingUnderline },
                    }))
                  }
                  className={`p-1.5 rounded border text-xs font-bold transition cursor-pointer ${
                    design.totals.remainingUnderline
                      ? 'bg-blue-100 text-blue-800 border-blue-300'
                      : 'bg-white text-neutral-700 border-neutral-300 hover:bg-neutral-100'
                  }`}
                  title="Toggle Underline"
                >
                  <UnderlineIcon className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>

            <div className="flex flex-col gap-1">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Label Color
              </span>
              <div className="flex items-center gap-1.5">
                <input
                  type="color"
                  value={design.totals.remainingColor || design.totals.color || '#0B1E36'}
                  onChange={(e) => {
                    const val = e.target.value;
                    updateDesign((p) => ({
                      ...p,
                      totals: { ...p.totals, remainingColor: val },
                    }));
                  }}
                  className="w-7 h-7 p-0.5 border border-neutral-300 rounded cursor-pointer"
                />
                <span className="text-[11px] font-mono uppercase text-neutral-600">
                  {design.totals.remainingColor || design.totals.color || '#0B1E36'}
                </span>
              </div>
            </div>

            <div className="flex flex-col gap-1">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Value Color
              </span>
              <div className="flex items-center gap-1.5">
                <input
                  type="color"
                  value={design.totals.remainingValueColor || design.totals.valueColor || '#0F172A'}
                  onChange={(e) => {
                    const val = e.target.value;
                    updateDesign((p) => ({
                      ...p,
                      totals: { ...p.totals, remainingValueColor: val },
                    }));
                  }}
                  className="w-7 h-7 p-0.5 border border-neutral-300 rounded cursor-pointer"
                />
                <span className="text-[11px] font-mono uppercase text-neutral-600">
                  {design.totals.remainingValueColor || design.totals.valueColor || '#0F172A'}
                </span>
              </div>
            </div>
          </>
        )}

        {/* 12g. INDEPENDENT PAYMENT STATUS IN TOTALS */}
        {selectedElement === 'paymentStatusTotal' && (
          <>
            <div className="flex flex-col gap-1">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Visibility
              </span>
              <button
                type="button"
                onClick={() =>
                  updateDesign((p) => ({
                    ...p,
                    totals: { ...p.totals, showPaymentStatus: !p.totals.showPaymentStatus },
                  }))
                }
                className={`flex items-center gap-1 px-2.5 py-1 text-xs rounded border transition cursor-pointer ${
                  design.totals.showPaymentStatus
                    ? 'bg-blue-50 text-blue-700 border-blue-300 font-semibold'
                    : 'bg-white text-neutral-500 border-neutral-300'
                }`}
              >
                {design.totals.showPaymentStatus ? <Eye className="w-3.5 h-3.5" /> : <EyeOff className="w-3.5 h-3.5" />}
                <span>{design.totals.showPaymentStatus ? 'Visible' : 'Hidden'}</span>
              </button>
            </div>

            <FontFamilySelect
              value={design.totals.paymentStatusTotalFontFamily || design.totals.fontFamily || design.typography.fontFamily}
              onChange={(f) =>
                updateDesign((p) => ({
                  ...p,
                  totals: { ...p.totals, paymentStatusTotalFontFamily: f },
                }))
              }
              label="Status Font"
            />

            <div className="flex flex-col gap-1">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Font Size
              </span>
              <div className="flex items-center gap-1">
                <input
                  type="number"
                  min={8}
                  max={20}
                  step={0.5}
                  value={design.totals.paymentStatusTotalFontSize || design.totals.fontSize || 11.5}
                  onChange={(e) => {
                    const val = Number(e.target.value);
                    updateDesign((p) => ({
                      ...p,
                      totals: { ...p.totals, paymentStatusTotalFontSize: val },
                    }));
                  }}
                  className="w-14 px-1 py-1 text-xs text-center border border-neutral-300 rounded font-mono bg-white"
                />
                <span className="text-[10px] text-neutral-400">px</span>
              </div>
            </div>

            <div className="flex flex-col gap-1">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Style
              </span>
              <div className="flex items-center gap-1">
                <button
                  type="button"
                  onClick={() =>
                    updateDesign((p) => ({
                      ...p,
                      totals: {
                        ...p.totals,
                        paymentStatusTotalFontWeight: (p.totals.paymentStatusTotalFontWeight || 'bold') === 'bold' ? 'normal' : 'bold',
                      },
                    }))
                  }
                  className={`p-1.5 rounded border text-xs font-bold transition cursor-pointer ${
                    (design.totals.paymentStatusTotalFontWeight || 'bold') === 'bold'
                      ? 'bg-blue-100 text-blue-800 border-blue-300'
                      : 'bg-white text-neutral-700 border-neutral-300 hover:bg-neutral-100'
                  }`}
                  title="Toggle Bold"
                >
                  <Bold className="w-3.5 h-3.5" />
                </button>
                <button
                  type="button"
                  onClick={() =>
                    updateDesign((p) => ({
                      ...p,
                      totals: { ...p.totals, paymentStatusTotalItalic: !p.totals.paymentStatusTotalItalic },
                    }))
                  }
                  className={`p-1.5 rounded border text-xs font-bold transition cursor-pointer ${
                    design.totals.paymentStatusTotalItalic
                      ? 'bg-blue-100 text-blue-800 border-blue-300'
                      : 'bg-white text-neutral-700 border-neutral-300 hover:bg-neutral-100'
                  }`}
                  title="Toggle Italic"
                >
                  <Italic className="w-3.5 h-3.5" />
                </button>
                <button
                  type="button"
                  onClick={() =>
                    updateDesign((p) => ({
                      ...p,
                      totals: { ...p.totals, paymentStatusTotalUnderline: !p.totals.paymentStatusTotalUnderline },
                    }))
                  }
                  className={`p-1.5 rounded border text-xs font-bold transition cursor-pointer ${
                    design.totals.paymentStatusTotalUnderline
                      ? 'bg-blue-100 text-blue-800 border-blue-300'
                      : 'bg-white text-neutral-700 border-neutral-300 hover:bg-neutral-100'
                  }`}
                  title="Toggle Underline"
                >
                  <UnderlineIcon className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>

            <div className="flex flex-col gap-1">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Label Color
              </span>
              <div className="flex items-center gap-1.5">
                <input
                  type="color"
                  value={design.totals.paymentStatusTotalColor || design.totals.color || '#0B1E36'}
                  onChange={(e) => {
                    const val = e.target.value;
                    updateDesign((p) => ({
                      ...p,
                      totals: { ...p.totals, paymentStatusTotalColor: val },
                    }));
                  }}
                  className="w-7 h-7 p-0.5 border border-neutral-300 rounded cursor-pointer"
                />
                <span className="text-[11px] font-mono uppercase text-neutral-600">
                  {design.totals.paymentStatusTotalColor || design.totals.color || '#0B1E36'}
                </span>
              </div>
            </div>

            <div className="flex flex-col gap-1">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Value Color
              </span>
              <div className="flex items-center gap-1.5">
                <input
                  type="color"
                  value={design.totals.paymentStatusTotalValueColor || design.totals.valueColor || '#0F172A'}
                  onChange={(e) => {
                    const val = e.target.value;
                    updateDesign((p) => ({
                      ...p,
                      totals: { ...p.totals, paymentStatusTotalValueColor: val },
                    }));
                  }}
                  className="w-7 h-7 p-0.5 border border-neutral-300 rounded cursor-pointer"
                />
                <span className="text-[11px] font-mono uppercase text-neutral-600">
                  {design.totals.paymentStatusTotalValueColor || design.totals.valueColor || '#0F172A'}
                </span>
              </div>
            </div>
          </>
        )}

        {/* 13. NOTES */}
        {selectedElement === 'notes' && (
          <>
            <div className="flex flex-col gap-1 min-w-[130px]">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Notes Header Label
              </span>
              <input
                type="text"
                value={design.notes.notesLabel || 'Notes:'}
                onChange={(e) => {
                  const val = e.target.value;
                  updateDesign((p) => ({
                    ...p,
                    notes: { ...p.notes, notesLabel: val },
                  }));
                }}
                className="px-2 py-1 text-xs border border-neutral-300 rounded bg-white font-medium"
              />
            </div>

            <div className="flex flex-col gap-1 min-w-[240px] flex-1">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Default Note Text
              </span>
              <input
                type="text"
                value={design.notes.invoiceNoteText || ''}
                onChange={(e) => {
                  const val = e.target.value;
                  updateDesign((p) => ({
                    ...p,
                    notes: { ...p.notes, invoiceNoteText: val },
                  }));
                }}
                placeholder="Thank you for your business..."
                className="px-2 py-1 text-xs border border-neutral-300 rounded bg-white"
              />
            </div>

            <FontFamilySelect
              value={design.notes.invoiceNoteFontFamily || design.typography.fontFamily}
              onChange={(f) =>
                updateDesign((p) => ({
                  ...p,
                  notes: { ...p.notes, invoiceNoteFontFamily: f },
                }))
              }
              label="Notes Font"
            />

            <div className="flex flex-col gap-1">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Font Size
              </span>
              <div className="flex items-center gap-1">
                <input
                  type="number"
                  min={8}
                  max={14}
                  step={0.5}
                  value={design.notes.invoiceNoteFontSize || 10.5}
                  onChange={(e) => {
                    const val = Number(e.target.value);
                    updateDesign((p) => ({
                      ...p,
                      notes: { ...p.notes, invoiceNoteFontSize: val },
                    }));
                  }}
                  className="w-14 px-1.5 py-1 text-xs text-center border border-neutral-300 rounded font-mono bg-white"
                />
                <span className="text-[10px] text-neutral-400">px</span>
              </div>
            </div>

            <div className="flex flex-col gap-1">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Text Color
              </span>
              <div className="flex items-center gap-1.5">
                <input
                  type="color"
                  value={design.notes.invoiceNoteColor || '#334155'}
                  onChange={(e) => {
                    const val = e.target.value;
                    updateDesign((p) => ({
                      ...p,
                      notes: { ...p.notes, invoiceNoteColor: val },
                    }));
                  }}
                  className="w-7 h-7 p-0.5 border border-neutral-300 rounded cursor-pointer"
                />
                <span className="text-[11px] font-mono uppercase text-neutral-600">
                  {design.notes.invoiceNoteColor || '#334155'}
                </span>
              </div>
            </div>

            <div className="flex flex-col gap-1">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Border
              </span>
              <div className="flex items-center gap-1.5">
                <input
                  type="color"
                  value={design.notes.borderColor || '#D8E2EC'}
                  onChange={(e) => {
                    const val = e.target.value;
                    updateDesign((p) => ({
                      ...p,
                      notes: { ...p.notes, borderColor: val },
                    }));
                  }}
                  className="w-7 h-7 p-0.5 border border-neutral-300 rounded cursor-pointer"
                />
                <span className="text-[11px] font-mono uppercase text-neutral-600">
                  {design.notes.borderColor || '#D8E2EC'}
                </span>
              </div>
            </div>

            <div className="flex flex-col gap-1">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Background
              </span>
              <div className="flex items-center gap-1.5">
                <input
                  type="color"
                  value={design.notes.invoiceNoteBgColor || '#F8FAFC'}
                  onChange={(e) => {
                    const val = e.target.value;
                    updateDesign((p) => ({
                      ...p,
                      notes: { ...p.notes, invoiceNoteBgColor: val },
                    }));
                  }}
                  className="w-7 h-7 p-0.5 border border-neutral-300 rounded cursor-pointer"
                />
                <span className="text-[11px] font-mono uppercase text-neutral-600">
                  {design.notes.invoiceNoteBgColor || '#F8FAFC'}
                </span>
              </div>
            </div>

            <div className="flex flex-col gap-1">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Style
              </span>
              <div className="flex items-center gap-1">
                <button
                  type="button"
                  onClick={() =>
                    updateDesign((p) => ({
                      ...p,
                      notes: { ...p.notes, italic: !p.notes.italic },
                    }))
                  }
                  className={`p-1.5 rounded border transition cursor-pointer ${
                    design.notes.italic
                      ? 'bg-blue-100 text-blue-800 border-blue-300 font-bold'
                      : 'bg-white text-neutral-600 border-neutral-300 hover:bg-neutral-100'
                  }`}
                  title="Italic"
                >
                  <Italic className="w-3.5 h-3.5" />
                </button>
                <button
                  type="button"
                  onClick={() =>
                    updateDesign((p) => ({
                      ...p,
                      notes: { ...p.notes, underline: !p.notes.underline },
                    }))
                  }
                  className={`p-1.5 rounded border transition cursor-pointer ${
                    design.notes.underline
                      ? 'bg-blue-100 text-blue-800 border-blue-300 font-bold'
                      : 'bg-white text-neutral-600 border-neutral-300 hover:bg-neutral-100'
                  }`}
                  title="Underline"
                >
                  <Underline className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          </>
        )}

        {/* 14. SIGNATURES (ALL / CONTAINER) */}
        {selectedElement === 'signatures' && (
          <>
            <div className="flex flex-col gap-1 min-w-[150px]">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Customer Signature Label
              </span>
              <input
                type="text"
                value={design.signatures.customerSignatureLabel || 'Customer Signature'}
                onChange={(e) => {
                  const val = e.target.value;
                  updateDesign((p) => ({
                    ...p,
                    signatures: { ...p.signatures, customerSignatureLabel: val },
                  }));
                }}
                className="px-2 py-1 text-xs border border-neutral-300 rounded bg-white font-medium"
              />
            </div>

            <div className="flex flex-col gap-1 min-w-[150px]">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Collector Signature Label
              </span>
              <input
                type="text"
                value={design.signatures.managerSignatureLabel || 'Collector Signature'}
                onChange={(e) => {
                  const val = e.target.value;
                  updateDesign((p) => ({
                    ...p,
                    signatures: { ...p.signatures, managerSignatureLabel: val },
                  }));
                }}
                className="px-2 py-1 text-xs border border-neutral-300 rounded bg-white font-medium"
              />
            </div>

            <FontFamilySelect
              value={design.signatures.fontFamily || design.typography.fontFamily}
              onChange={(f) =>
                updateDesign((p) => ({
                  ...p,
                  signatures: { ...p.signatures, fontFamily: f },
                }))
              }
              label="Signature Font"
            />

            <div className="flex flex-col gap-1">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Line Style
              </span>
              <select
                value={design.signatures.signatureStyle || 'dotted_line'}
                onChange={(e) => {
                  const val = e.target.value as SignatureStyle;
                  updateDesign((p) => ({
                    ...p,
                    signatures: { ...p.signatures, signatureStyle: val },
                  }));
                }}
                className="px-2 py-1 text-xs border border-neutral-300 rounded bg-white"
              >
                <option value="dotted_line">Dashed Line</option>
                <option value="solid_line">Solid Line</option>
                <option value="box">Box</option>
              </select>
            </div>

            <div className="flex flex-col gap-1">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Line Color
              </span>
              <div className="flex items-center gap-1.5">
                <input
                  type="color"
                  value={design.signatures.borderColor || '#1E4E8C'}
                  onChange={(e) => {
                    const val = e.target.value;
                    updateDesign((p) => ({
                      ...p,
                      signatures: { ...p.signatures, borderColor: val },
                    }));
                  }}
                  className="w-7 h-7 p-0.5 border border-neutral-300 rounded cursor-pointer"
                />
                <span className="text-[11px] font-mono uppercase text-neutral-600">
                  {design.signatures.borderColor || '#1E4E8C'}
                </span>
              </div>
            </div>

            <div className="flex flex-col gap-1">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Label Color
              </span>
              <div className="flex items-center gap-1.5">
                <input
                  type="color"
                  value={design.signatures.color || '#0B1E36'}
                  onChange={(e) => {
                    const val = e.target.value;
                    updateDesign((p) => ({
                      ...p,
                      signatures: { ...p.signatures, color: val },
                    }));
                  }}
                  className="w-7 h-7 p-0.5 border border-neutral-300 rounded cursor-pointer"
                />
                <span className="text-[11px] font-mono uppercase text-neutral-600">
                  {design.signatures.color || '#0B1E36'}
                </span>
              </div>
            </div>

            <div className="flex flex-col gap-1">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Font Size
              </span>
              <div className="flex items-center gap-1">
                <input
                  type="number"
                  min={8}
                  max={16}
                  step={0.5}
                  value={design.signatures.fontSize || 10}
                  onChange={(e) => {
                    const val = Number(e.target.value);
                    updateDesign((p) => ({
                      ...p,
                      signatures: { ...p.signatures, fontSize: val },
                    }));
                  }}
                  className="w-14 px-1.5 py-1 text-xs text-center border border-neutral-300 rounded font-mono bg-white"
                />
                <span className="text-[10px] text-neutral-400">px</span>
              </div>
            </div>

            <div className="flex flex-col gap-1">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Style
              </span>
              <div className="flex items-center gap-1">
                <button
                  type="button"
                  onClick={() =>
                    updateDesign((p) => ({
                      ...p,
                      signatures: { ...p.signatures, italic: !p.signatures.italic },
                    }))
                  }
                  className={`p-1.5 rounded border transition cursor-pointer ${
                    design.signatures.italic
                      ? 'bg-blue-100 text-blue-800 border-blue-300 font-bold'
                      : 'bg-white text-neutral-600 border-neutral-300 hover:bg-neutral-100'
                  }`}
                  title="Italic"
                >
                  <Italic className="w-3.5 h-3.5" />
                </button>
                <button
                  type="button"
                  onClick={() =>
                    updateDesign((p) => ({
                      ...p,
                      signatures: { ...p.signatures, underline: !p.signatures.underline },
                    }))
                  }
                  className={`p-1.5 rounded border transition cursor-pointer ${
                    design.signatures.underline
                      ? 'bg-blue-100 text-blue-800 border-blue-300 font-bold'
                      : 'bg-white text-neutral-600 border-neutral-300 hover:bg-neutral-100'
                  }`}
                  title="Underline"
                >
                  <Underline className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          </>
        )}

        {/* 14b. SIGNATURE: CUSTOMER */}
        {selectedElement === 'signatureCustomer' && (
          <>
            <div className="flex flex-col gap-1 min-w-[170px] flex-1">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Customer Signature Label
              </span>
              <input
                type="text"
                value={design.signatures.customerSignatureLabel || 'Customer Signature'}
                onChange={(e) => {
                  const val = e.target.value;
                  updateDesign((p) => ({
                    ...p,
                    signatures: { ...p.signatures, customerSignatureLabel: val },
                  }));
                }}
                className="px-2 py-1 text-xs border border-neutral-300 rounded bg-white font-medium"
              />
            </div>

            <FontFamilySelect
              value={design.signatures.customerFontFamily || design.signatures.fontFamily || design.typography.fontFamily}
              onChange={(f) =>
                updateDesign((p) => ({
                  ...p,
                  signatures: { ...p.signatures, customerFontFamily: f },
                }))
              }
              label="Customer Sig Font"
            />

            <div className="flex flex-col gap-1">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Font Size
              </span>
              <div className="flex items-center gap-1">
                <input
                  type="number"
                  min={8}
                  max={16}
                  step={0.5}
                  value={design.signatures.fontSize || 10}
                  onChange={(e) => {
                    const val = Number(e.target.value);
                    updateDesign((p) => ({
                      ...p,
                      signatures: { ...p.signatures, fontSize: val },
                    }));
                  }}
                  className="w-14 px-1.5 py-1 text-xs text-center border border-neutral-300 rounded font-mono bg-white"
                />
                <span className="text-[10px] text-neutral-400">px</span>
              </div>
            </div>

            <div className="flex flex-col gap-1">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Label Color
              </span>
              <div className="flex items-center gap-1.5">
                <input
                  type="color"
                  value={design.signatures.color || '#0B1E36'}
                  onChange={(e) => {
                    const val = e.target.value;
                    updateDesign((p) => ({
                      ...p,
                      signatures: { ...p.signatures, color: val },
                    }));
                  }}
                  className="w-7 h-7 p-0.5 border border-neutral-300 rounded cursor-pointer"
                />
                <span className="text-[11px] font-mono uppercase text-neutral-600">
                  {design.signatures.color || '#0B1E36'}
                </span>
              </div>
            </div>

            <div className="flex flex-col gap-1">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Line Style
              </span>
              <select
                value={design.signatures.signatureStyle || 'dotted_line'}
                onChange={(e) => {
                  const val = e.target.value as SignatureStyle;
                  updateDesign((p) => ({
                    ...p,
                    signatures: { ...p.signatures, signatureStyle: val },
                  }));
                }}
                className="px-2 py-1 text-xs border border-neutral-300 rounded bg-white"
              >
                <option value="dotted_line">Dashed Line</option>
                <option value="solid_line">Solid Line</option>
                <option value="box">Box</option>
              </select>
            </div>

            <div className="flex flex-col gap-1">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Show / Hide
              </span>
              <button
                type="button"
                onClick={() =>
                  updateDesign((p) => ({
                    ...p,
                    signatures: { ...p.signatures, showCustomerSignature: !p.signatures.showCustomerSignature },
                  }))
                }
                className={`px-2.5 py-1 text-xs rounded border transition cursor-pointer ${
                  design.signatures.showCustomerSignature !== false
                    ? 'bg-blue-50 text-blue-700 border-blue-300 font-semibold'
                    : 'bg-white text-neutral-500 border-neutral-300'
                }`}
              >
                {design.signatures.showCustomerSignature !== false ? 'Shown' : 'Hidden'}
              </button>
            </div>
          </>
        )}

        {/* 14c. SIGNATURE: AUTHORIZED / COLLECTOR */}
        {selectedElement === 'signatureAuthorized' && (
          <>
            <div className="flex flex-col gap-1 min-w-[170px] flex-1">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Collector Signature Label
              </span>
              <input
                type="text"
                value={design.signatures.managerSignatureLabel || 'Collector Signature'}
                onChange={(e) => {
                  const val = e.target.value;
                  updateDesign((p) => ({
                    ...p,
                    signatures: { ...p.signatures, managerSignatureLabel: val },
                  }));
                }}
                className="px-2 py-1 text-xs border border-neutral-300 rounded bg-white font-medium"
              />
            </div>

            <FontFamilySelect
              value={design.signatures.managerFontFamily || design.signatures.fontFamily || design.typography.fontFamily}
              onChange={(f) =>
                updateDesign((p) => ({
                  ...p,
                  signatures: { ...p.signatures, managerFontFamily: f },
                }))
              }
              label="Collector Sig Font"
            />

            <div className="flex flex-col gap-1">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Font Size
              </span>
              <div className="flex items-center gap-1">
                <input
                  type="number"
                  min={8}
                  max={16}
                  step={0.5}
                  value={design.signatures.fontSize || 10}
                  onChange={(e) => {
                    const val = Number(e.target.value);
                    updateDesign((p) => ({
                      ...p,
                      signatures: { ...p.signatures, fontSize: val },
                    }));
                  }}
                  className="w-14 px-1.5 py-1 text-xs text-center border border-neutral-300 rounded font-mono bg-white"
                />
                <span className="text-[10px] text-neutral-400">px</span>
              </div>
            </div>

            <div className="flex flex-col gap-1">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Label Color
              </span>
              <div className="flex items-center gap-1.5">
                <input
                  type="color"
                  value={design.signatures.color || '#0B1E36'}
                  onChange={(e) => {
                    const val = e.target.value;
                    updateDesign((p) => ({
                      ...p,
                      signatures: { ...p.signatures, color: val },
                    }));
                  }}
                  className="w-7 h-7 p-0.5 border border-neutral-300 rounded cursor-pointer"
                />
                <span className="text-[11px] font-mono uppercase text-neutral-600">
                  {design.signatures.color || '#0B1E36'}
                </span>
              </div>
            </div>

            <div className="flex flex-col gap-1">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Line Style
              </span>
              <select
                value={design.signatures.signatureStyle || 'dotted_line'}
                onChange={(e) => {
                  const val = e.target.value as SignatureStyle;
                  updateDesign((p) => ({
                    ...p,
                    signatures: { ...p.signatures, signatureStyle: val },
                  }));
                }}
                className="px-2 py-1 text-xs border border-neutral-300 rounded bg-white"
              >
                <option value="dotted_line">Dashed Line</option>
                <option value="solid_line">Solid Line</option>
                <option value="box">Box</option>
              </select>
            </div>

            <div className="flex flex-col gap-1">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Show / Hide
              </span>
              <button
                type="button"
                onClick={() =>
                  updateDesign((p) => ({
                    ...p,
                    signatures: { ...p.signatures, showManagerSignature: !p.signatures.showManagerSignature },
                  }))
                }
                className={`px-2.5 py-1 text-xs rounded border transition cursor-pointer ${
                  design.signatures.showManagerSignature !== false
                    ? 'bg-blue-50 text-blue-700 border-blue-300 font-semibold'
                    : 'bg-white text-neutral-500 border-neutral-300'
                }`}
              >
                {design.signatures.showManagerSignature !== false ? 'Shown' : 'Hidden'}
              </button>
            </div>
          </>
        )}

        {/* 15. FOOTER (ALL) */}
        {selectedElement === 'footer' && (
          <>
            <div className="flex flex-col gap-1">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Footer Layout
              </span>
              <select
                value={design.footer.layoutMode || 'full_width'}
                onChange={(e) => {
                  const val = e.target.value as 'full_width' | 'contained';
                  updateDesign((p) => ({
                    ...p,
                    footer: { ...p.footer, layoutMode: val },
                  }));
                }}
                className="px-2 py-1 text-xs border border-neutral-300 rounded bg-white font-medium"
              >
                <option value="full_width">Full Bleed (Edge-to-Edge)</option>
                <option value="contained">Contained (Boxed inside margins)</option>
              </select>
            </div>

            <div className="flex flex-col gap-1 min-w-[220px] flex-1">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Footer Tagline Text
              </span>
              <input
                type="text"
                value={design.footer.footerText || ''}
                onChange={(e) => {
                  const val = e.target.value;
                  updateDesign((p) => ({
                    ...p,
                    footer: { ...p.footer, footerText: val },
                  }));
                }}
                placeholder="Thank you for your business!"
                className="px-2 py-1 text-xs border border-neutral-300 rounded bg-white font-medium"
              />
            </div>

            <FontFamilySelect
              value={design.footer.fontFamily || design.typography.fontFamily}
              onChange={(f) =>
                updateDesign((p) => ({
                  ...p,
                  footer: { ...p.footer, fontFamily: f },
                }))
              }
              label="Footer Font"
            />

            <div className="flex flex-col gap-1">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Background
              </span>
              <div className="flex items-center gap-1.5">
                <input
                  type="color"
                  value={design.colors.footerBackground || design.footer.backgroundColor || '#0B1E36'}
                  onChange={(e) => {
                    const val = e.target.value;
                    updateDesign((p) => ({
                      ...p,
                      colors: { ...p.colors, footerBackground: val },
                      footer: { ...p.footer, backgroundColor: val },
                    }));
                  }}
                  className="w-7 h-7 p-0.5 border border-neutral-300 rounded cursor-pointer"
                />
                <span className="text-[11px] font-mono uppercase text-neutral-600">
                  {design.colors.footerBackground || design.footer.backgroundColor || '#0B1E36'}
                </span>
              </div>
            </div>

            <div className="flex flex-col gap-1">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Text Color
              </span>
              <div className="flex items-center gap-1.5">
                <input
                  type="color"
                  value={design.colors.footerText || design.footer.color || '#FFFFFF'}
                  onChange={(e) => {
                    const val = e.target.value;
                    updateDesign((p) => ({
                      ...p,
                      colors: { ...p.colors, footerText: val },
                      footer: { ...p.footer, color: val },
                    }));
                  }}
                  className="w-7 h-7 p-0.5 border border-neutral-300 rounded cursor-pointer"
                />
                <span className="text-[11px] font-mono uppercase text-neutral-600">
                  {design.colors.footerText || design.footer.color || '#FFFFFF'}
                </span>
              </div>
            </div>

            <div className="flex flex-col gap-1">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Border / Accent
              </span>
              <div className="flex items-center gap-1.5">
                <input
                  type="color"
                  value={design.colors.footerAccent || design.footer.borderColor || design.footer.accentColor || '#C5A059'}
                  onChange={(e) => {
                    const val = e.target.value;
                    updateDesign((p) => ({
                      ...p,
                      colors: { ...p.colors, footerAccent: val },
                      footer: {
                        ...p.footer,
                        accentColor: val,
                        borderColor: val,
                      },
                    }));
                  }}
                  className="w-7 h-7 p-0.5 border border-neutral-300 rounded cursor-pointer"
                />
                <span className="text-[11px] font-mono uppercase text-neutral-600">
                  {design.colors.footerAccent || design.footer.borderColor || design.footer.accentColor || '#C5A059'}
                </span>
              </div>
            </div>

            <div className="flex flex-col gap-1">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Border Style
              </span>
              <select
                value={design.footer.borderStyle || 'solid'}
                onChange={(e) => {
                  const val = e.target.value as 'none' | 'solid' | 'dashed';
                  updateDesign((p) => ({
                    ...p,
                    footer: { ...p.footer, borderStyle: val },
                  }));
                }}
                className="px-2 py-1 text-xs border border-neutral-300 rounded bg-white font-medium"
              >
                <option value="solid">Solid</option>
                <option value="dashed">Dashed</option>
                <option value="none">None</option>
              </select>
            </div>

            <div className="flex flex-col gap-1">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Border Width
              </span>
              <div className="flex items-center gap-1">
                <input
                  type="number"
                  min={0}
                  max={10}
                  step={0.5}
                  value={design.footer.borderWidth ?? 2.5}
                  onChange={(e) => {
                    const val = Math.max(0, Number(e.target.value));
                    updateDesign((p) => ({
                      ...p,
                      footer: { ...p.footer, borderWidth: val },
                    }));
                  }}
                  className="w-14 px-1.5 py-1 text-xs text-center border border-neutral-300 rounded font-mono bg-white"
                />
                <span className="text-[10px] text-neutral-400">px</span>
              </div>
            </div>

            <div className="flex flex-col gap-1">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Border Radius
              </span>
              <div className="flex items-center gap-1">
                <input
                  type="number"
                  min={0}
                  max={24}
                  step={1}
                  value={design.footer.borderRadius ?? 0}
                  onChange={(e) => {
                    const val = Math.max(0, Number(e.target.value));
                    updateDesign((p) => ({
                      ...p,
                      footer: { ...p.footer, borderRadius: val },
                    }));
                  }}
                  className="w-14 px-1.5 py-1 text-xs text-center border border-neutral-300 rounded font-mono bg-white"
                />
                <span className="text-[10px] text-neutral-400">px</span>
              </div>
            </div>

            <div className="flex flex-col gap-1">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Font Size
              </span>
              <div className="flex items-center gap-1">
                <input
                  type="number"
                  min={8}
                  max={16}
                  step={0.5}
                  value={design.footer.fontSize || design.typography.footerFontSize || 11}
                  onChange={(e) => {
                    const val = Number(e.target.value);
                    updateDesign((p) => ({
                      ...p,
                      footer: { ...p.footer, fontSize: val },
                    }));
                  }}
                  className="w-14 px-1.5 py-1 text-xs text-center border border-neutral-300 rounded font-mono bg-white"
                />
                <span className="text-[10px] text-neutral-400">px</span>
              </div>
            </div>

            <div className="flex flex-col gap-1">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Vertical Spacing
              </span>
              <div className="flex items-center gap-1">
                <input
                  type="number"
                  min={0}
                  max={50}
                  value={design.footer.topSpacing ?? design.footer.paddingTop ?? 8}
                  onChange={(e) => {
                    const val = Number(e.target.value);
                    updateDesign((p) => ({
                      ...p,
                      footer: {
                        ...p.footer,
                        topSpacing: val,
                        bottomSpacing: val,
                        paddingTop: val,
                        paddingBottom: val,
                      },
                    }));
                  }}
                  className="w-14 px-1.5 py-1 text-xs text-center border border-neutral-300 rounded font-mono bg-white"
                />
                <span className="text-[10px] text-neutral-400">px</span>
              </div>
            </div>

            <div className="flex flex-col gap-1">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Padding (Side)
              </span>
              <div className="flex items-center gap-1">
                <input
                  type="number"
                  min={0}
                  max={200}
                  value={design.footer.paddingLeft ?? design.footer.padding ?? 40}
                  onChange={(e) => {
                    const val = Number(e.target.value);
                    updateDesign((p) => ({
                      ...p,
                      footer: {
                        ...p.footer,
                        padding: val,
                        paddingLeft: val,
                        paddingRight: val,
                      },
                    }));
                  }}
                  className="w-14 px-1.5 py-1 text-xs text-center border border-neutral-300 rounded font-mono bg-white"
                />
                <span className="text-[10px] text-neutral-400">px</span>
              </div>
            </div>

            <div className="flex flex-col gap-1">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Style
              </span>
              <div className="flex items-center gap-1">
                <button
                  type="button"
                  onClick={() =>
                    updateDesign((p) => ({
                      ...p,
                      footer: { ...p.footer, italic: !p.footer.italic },
                    }))
                  }
                  className={`p-1.5 rounded border transition cursor-pointer ${
                    design.footer.italic
                      ? 'bg-blue-100 text-blue-800 border-blue-300 font-bold'
                      : 'bg-white text-neutral-600 border-neutral-300 hover:bg-neutral-100'
                  }`}
                  title="Italic"
                >
                  <Italic className="w-3.5 h-3.5" />
                </button>
                <button
                  type="button"
                  onClick={() =>
                    updateDesign((p) => ({
                      ...p,
                      footer: { ...p.footer, underline: !p.footer.underline },
                    }))
                  }
                  className={`p-1.5 rounded border transition cursor-pointer ${
                    design.footer.underline
                      ? 'bg-blue-100 text-blue-800 border-blue-300 font-bold'
                      : 'bg-white text-neutral-600 border-neutral-300 hover:bg-neutral-100'
                  }`}
                  title="Underline"
                >
                  <Underline className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>

            {/* Reorder Footer Elements */}
            <div className="flex flex-col gap-1 border-l border-neutral-200/80 pl-2 min-w-[260px]">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider flex items-center gap-1">
                <ListOrdered className="w-3 h-3 text-blue-600" />
                Footer Elements Order
              </span>
              <div className="flex flex-col gap-1 bg-neutral-50 p-1.5 rounded border border-neutral-200">
                {currentFooterOrder.map((elemId, idx) => {
                  const label =
                    elemId === 'thankYou'
                      ? 'Thank You Message'
                      : elemId === 'contacts'
                      ? 'Contact Information'
                      : 'Page Number';
                  return (
                    <div
                      key={elemId}
                      className="flex items-center justify-between gap-1.5 px-2 py-1 bg-white rounded border border-neutral-200 shadow-2xs text-xs"
                    >
                      <div className="flex items-center gap-1.5">
                        <span className="w-4 h-4 rounded-full bg-blue-100 text-blue-700 text-[10px] font-bold flex items-center justify-center shrink-0">
                          {idx + 1}
                        </span>
                        <span className="font-medium text-neutral-800 text-[11px]">{label}</span>
                      </div>
                      <div className="flex items-center gap-1">
                        <button
                          type="button"
                          onClick={() => moveFooterElement(elemId, 'up')}
                          disabled={idx <= 0}
                          className="flex items-center gap-0.5 px-1.5 py-0.5 text-[11px] font-medium rounded border border-neutral-200 text-neutral-700 hover:bg-neutral-100 active:bg-neutral-200 disabled:opacity-30 disabled:cursor-not-allowed transition cursor-pointer"
                          title={`Move ${label} Up`}
                        >
                          <ArrowUp className="w-3 h-3 text-blue-600" />
                          <span>Move Up</span>
                        </button>
                        <button
                          type="button"
                          onClick={() => moveFooterElement(elemId, 'down')}
                          disabled={idx >= currentFooterOrder.length - 1}
                          className="flex items-center gap-0.5 px-1.5 py-0.5 text-[11px] font-medium rounded border border-neutral-200 text-neutral-700 hover:bg-neutral-100 active:bg-neutral-200 disabled:opacity-30 disabled:cursor-not-allowed transition cursor-pointer"
                          title={`Move ${label} Down`}
                        >
                          <ArrowDown className="w-3 h-3 text-blue-600" />
                          <span>Move Down</span>
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </>
        )}

        {/* 15b. FOOTER THANK YOU */}
        {selectedElement === 'footerThankYou' && (
          <>
            <div className="flex flex-col gap-1 min-w-[260px] flex-1">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Thank-You Message Text
              </span>
              <input
                type="text"
                value={design.footer.footerText || ''}
                onChange={(e) => {
                  const val = e.target.value;
                  updateDesign((p) => ({
                    ...p,
                    footer: { ...p.footer, footerText: val },
                  }));
                }}
                placeholder="Thank you for your business!"
                className="px-2 py-1 text-xs border border-neutral-300 rounded bg-white font-medium"
              />
            </div>

            <FontFamilySelect
              value={design.footer.thankYouFontFamily || design.footer.fontFamily || design.typography.fontFamily}
              onChange={(f) =>
                updateDesign((p) => ({
                  ...p,
                  footer: { ...p.footer, thankYouFontFamily: f },
                }))
              }
              label="Thank-You Font"
            />

            <div className="flex flex-col gap-1">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Font Size
              </span>
              <div className="flex items-center gap-1">
                <input
                  type="number"
                  min={8}
                  max={18}
                  step={0.5}
                  value={design.footer.thankYouFontSize || design.footer.fontSize || 11}
                  onChange={(e) => {
                    const val = Number(e.target.value);
                    updateDesign((p) => ({
                      ...p,
                      footer: { ...p.footer, thankYouFontSize: val },
                    }));
                  }}
                  className="w-14 px-1.5 py-1 text-xs text-center border border-neutral-300 rounded font-mono bg-white"
                />
                <span className="text-[10px] text-neutral-400">px</span>
              </div>
            </div>

            <div className="flex flex-col gap-1">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Color
              </span>
              <div className="flex items-center gap-1.5">
                <input
                  type="color"
                  value={(design.footer as any).thankYouColor || design.colors.footerText || design.footer.color || '#FFFFFF'}
                  onChange={(e) => {
                    const val = e.target.value;
                    updateDesign((p) => ({
                      ...p,
                      footer: { ...p.footer, thankYouColor: val } as any,
                    }));
                  }}
                  className="w-7 h-7 p-0.5 border border-neutral-300 rounded cursor-pointer"
                />
                <span className="text-[11px] font-mono uppercase text-neutral-600">
                  {(design.footer as any).thankYouColor || design.colors.footerText || design.footer.color || '#FFFFFF'}
                </span>
              </div>
            </div>

            <div className="flex flex-col gap-1">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Style
              </span>
              <div className="flex items-center gap-1">
                <button
                  type="button"
                  onClick={() =>
                    updateDesign((p) => ({
                      ...p,
                      footer: { ...p.footer, italic: !p.footer.italic },
                    }))
                  }
                  className={`p-1.5 rounded border transition cursor-pointer ${
                    design.footer.italic
                      ? 'bg-blue-100 text-blue-800 border-blue-300 font-bold'
                      : 'bg-white text-neutral-600 border-neutral-300 hover:bg-neutral-100'
                  }`}
                  title="Italic"
                >
                  <Italic className="w-3.5 h-3.5" />
                </button>
                <button
                  type="button"
                  onClick={() =>
                    updateDesign((p) => ({
                      ...p,
                      footer: { ...p.footer, underline: !p.footer.underline },
                    }))
                  }
                  className={`p-1.5 rounded border transition cursor-pointer ${
                    design.footer.underline
                      ? 'bg-blue-100 text-blue-800 border-blue-300 font-bold'
                      : 'bg-white text-neutral-600 border-neutral-300 hover:bg-neutral-100'
                  }`}
                  title="Underline"
                >
                  <Underline className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>

            {/* Accent Lines Shapes Controls */}
            <div className="flex flex-col gap-1 border-l border-neutral-200/80 pl-2">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Accent Lines
              </span>
              <div className="flex items-center gap-1.5">
                <button
                  type="button"
                  onClick={() =>
                    updateDesign((p) => ({
                      ...p,
                      footer: { ...p.footer, showAccentLines: p.footer.showAccentLines === false ? true : false },
                    }))
                  }
                  className={`px-2 py-1 text-xs rounded border transition cursor-pointer ${
                    design.footer.showAccentLines !== false
                      ? 'bg-blue-50 text-blue-700 border-blue-300 font-semibold'
                      : 'bg-white text-neutral-500 border-neutral-300'
                  }`}
                >
                  {design.footer.showAccentLines !== false ? 'Shown' : 'Hidden'}
                </button>
                {design.footer.showAccentLines !== false && (
                  <>
                    <input
                      type="number"
                      min={10}
                      max={200}
                      step={2}
                      value={design.footer.accentLineWidth || 56}
                      onChange={(e) => {
                        const val = Number(e.target.value);
                        updateDesign((p) => ({
                          ...p,
                          footer: { ...p.footer, accentLineWidth: val },
                        }));
                      }}
                      className="w-13 px-1 py-1 text-xs text-center border border-neutral-300 rounded font-mono bg-white"
                      title="Accent Line Width (px)"
                    />
                    <input
                      type="color"
                      value={design.footer.accentLineColor || design.footer.accentColor || design.colors.footerAccent || '#C5A059'}
                      onChange={(e) => {
                        const val = e.target.value;
                        updateDesign((p) => ({
                          ...p,
                          footer: { ...p.footer, accentLineColor: val },
                        }));
                      }}
                      className="w-6 h-6 p-0.5 border border-neutral-300 rounded cursor-pointer"
                      title="Accent Line Color"
                    />
                  </>
                )}
              </div>
            </div>

            {/* Footer Sequence Order: Move Up / Move Down */}
            <div className="flex flex-col gap-1 border-l border-neutral-200/80 pl-2">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider flex items-center gap-1">
                <ListOrdered className="w-3 h-3 text-blue-600" />
                Footer Position
              </span>
              <div className="flex items-center gap-1.5">
                <span className="px-2 py-1 text-xs font-semibold bg-neutral-100 text-neutral-700 rounded border border-neutral-200 shrink-0">
                  #{currentFooterOrder.indexOf('thankYou') + 1} of {currentFooterOrder.length}
                </span>
                <button
                  type="button"
                  onClick={() => moveFooterElement('thankYou', 'up')}
                  disabled={currentFooterOrder.indexOf('thankYou') <= 0}
                  className="flex items-center gap-1 px-2.5 py-1 text-xs font-medium rounded border border-neutral-300 bg-white text-neutral-700 hover:bg-neutral-50 active:bg-neutral-100 disabled:opacity-40 disabled:cursor-not-allowed transition cursor-pointer"
                  title="Move Thank You Up in Footer"
                >
                  <ArrowUp className="w-3.5 h-3.5 text-blue-600" />
                  <span>Move Up</span>
                </button>
                <button
                  type="button"
                  onClick={() => moveFooterElement('thankYou', 'down')}
                  disabled={currentFooterOrder.indexOf('thankYou') >= currentFooterOrder.length - 1}
                  className="flex items-center gap-1 px-2.5 py-1 text-xs font-medium rounded border border-neutral-300 bg-white text-neutral-700 hover:bg-neutral-50 active:bg-neutral-100 disabled:opacity-40 disabled:cursor-not-allowed transition cursor-pointer"
                  title="Move Thank You Down in Footer"
                >
                  <ArrowDown className="w-3.5 h-3.5 text-blue-600" />
                  <span>Move Down</span>
                </button>
              </div>
            </div>
          </>
        )}

        {/* 15c. FOOTER CONTACTS */}
        {selectedElement === 'footerContacts' && (
          <>
            <FontFamilySelect
              value={design.footer.contactsFontFamily || design.footer.fontFamily || design.typography.fontFamily}
              onChange={(f) =>
                updateDesign((p) => ({
                  ...p,
                  footer: { ...p.footer, contactsFontFamily: f },
                }))
              }
              label="Contacts Font"
            />

            <div className="flex flex-col gap-1">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Text Color
              </span>
              <div className="flex items-center gap-1.5">
                <input
                  type="color"
                  value={(design.footer as any).contactsColor || design.colors.footerText || design.footer.color || '#FFFFFF'}
                  onChange={(e) => {
                    const val = e.target.value;
                    updateDesign((p) => ({
                      ...p,
                      footer: { ...p.footer, contactsColor: val } as any,
                    }));
                  }}
                  className="w-7 h-7 p-0.5 border border-neutral-300 rounded cursor-pointer"
                />
                <span className="text-[11px] font-mono uppercase text-neutral-600">
                  {(design.footer as any).contactsColor || design.colors.footerText || design.footer.color || '#FFFFFF'}
                </span>
              </div>
            </div>

            <div className="flex flex-col gap-1">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Font Size
              </span>
              <div className="flex items-center gap-1">
                <input
                  type="number"
                  min={8}
                  max={14}
                  step={0.5}
                  value={design.footer.contactsFontSize || 9.5}
                  onChange={(e) => {
                    const val = Number(e.target.value);
                    updateDesign((p) => ({
                      ...p,
                      footer: { ...p.footer, contactsFontSize: val },
                    }));
                  }}
                  className="w-14 px-1.5 py-1 text-xs text-center border border-neutral-300 rounded font-mono bg-white"
                />
                <span className="text-[10px] text-neutral-400">px</span>
              </div>
            </div>

            <div className="flex flex-col gap-1">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Toggles
              </span>
              <div className="flex items-center gap-1">
                <button
                  type="button"
                  onClick={() =>
                    updateDesign((p) => ({
                      ...p,
                      footer: { ...p.footer, showPhone: !p.footer.showPhone },
                    }))
                  }
                  className={`px-2 py-1 text-xs rounded border transition cursor-pointer ${
                    design.footer.showPhone !== false
                      ? 'bg-blue-50 text-blue-700 border-blue-300 font-semibold'
                      : 'bg-white text-neutral-500 border-neutral-300'
                  }`}
                >
                  Phone: {design.footer.showPhone !== false ? 'ON' : 'OFF'}
                </button>
                <button
                  type="button"
                  onClick={() =>
                    updateDesign((p) => ({
                      ...p,
                      footer: { ...p.footer, showEmail: !p.footer.showEmail },
                    }))
                  }
                  className={`px-2 py-1 text-xs rounded border transition cursor-pointer ${
                    design.footer.showEmail !== false
                      ? 'bg-blue-50 text-blue-700 border-blue-300 font-semibold'
                      : 'bg-white text-neutral-500 border-neutral-300'
                  }`}
                >
                  Email: {design.footer.showEmail !== false ? 'ON' : 'OFF'}
                </button>
              </div>
            </div>

            {/* Footer Sequence Order: Move Up / Move Down */}
            <div className="flex flex-col gap-1 border-l border-neutral-200/80 pl-2">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider flex items-center gap-1">
                <ListOrdered className="w-3 h-3 text-blue-600" />
                Footer Position
              </span>
              <div className="flex items-center gap-1.5">
                <span className="px-2 py-1 text-xs font-semibold bg-neutral-100 text-neutral-700 rounded border border-neutral-200 shrink-0">
                  #{currentFooterOrder.indexOf('contacts') + 1} of {currentFooterOrder.length}
                </span>
                <button
                  type="button"
                  onClick={() => moveFooterElement('contacts', 'up')}
                  disabled={currentFooterOrder.indexOf('contacts') <= 0}
                  className="flex items-center gap-1 px-2.5 py-1 text-xs font-medium rounded border border-neutral-300 bg-white text-neutral-700 hover:bg-neutral-50 active:bg-neutral-100 disabled:opacity-40 disabled:cursor-not-allowed transition cursor-pointer"
                  title="Move Contacts Up in Footer"
                >
                  <ArrowUp className="w-3.5 h-3.5 text-blue-600" />
                  <span>Move Up</span>
                </button>
                <button
                  type="button"
                  onClick={() => moveFooterElement('contacts', 'down')}
                  disabled={currentFooterOrder.indexOf('contacts') >= currentFooterOrder.length - 1}
                  className="flex items-center gap-1 px-2.5 py-1 text-xs font-medium rounded border border-neutral-300 bg-white text-neutral-700 hover:bg-neutral-50 active:bg-neutral-100 disabled:opacity-40 disabled:cursor-not-allowed transition cursor-pointer"
                  title="Move Contacts Down in Footer"
                >
                  <ArrowDown className="w-3.5 h-3.5 text-blue-600" />
                  <span>Move Down</span>
                </button>
              </div>
            </div>
          </>
        )}

        {/* 16. PAGE NUMBER */}
        {selectedElement === 'pageNumber' && (
          <>
            <div className="flex flex-col gap-1">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Show Page Number
              </span>
              <button
                type="button"
                onClick={() =>
                  updateDesign((p) => ({
                    ...p,
                    pageNumber: { ...p.pageNumber, show: !p.pageNumber.show },
                  }))
                }
                className={`px-2.5 py-1 text-xs rounded border transition cursor-pointer ${
                  design.pageNumber.show
                    ? 'bg-blue-50 text-blue-700 border-blue-300 font-semibold'
                    : 'bg-white text-neutral-500 border-neutral-300'
                }`}
              >
                {design.pageNumber.show ? 'Enabled' : 'Disabled'}
              </button>
            </div>

            <FontFamilySelect
              value={design.pageNumber.fontFamily || design.typography.fontFamily}
              onChange={(f) =>
                updateDesign((p) => ({
                  ...p,
                  pageNumber: { ...p.pageNumber, fontFamily: f },
                }))
              }
              label="Page Font"
            />

            <div className="flex flex-col gap-1">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Format
              </span>
              <select
                value={design.pageNumber.format || 'page_x_of_y'}
                onChange={(e) => {
                  const val = e.target.value as 'page_x_of_y' | 'page_x' | 'simple';
                  updateDesign((p) => ({
                    ...p,
                    pageNumber: { ...p.pageNumber, format: val },
                  }));
                }}
                className="px-2 py-1 text-xs border border-neutral-300 rounded bg-white"
              >
                <option value="page_x_of_y">Page X of Y</option>
                <option value="page_x">Page X</option>
                <option value="simple">X / Y</option>
              </select>
            </div>

            <div className="flex flex-col gap-1">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Position
              </span>
              <select
                value={design.pageNumber.position || 'bottom_right'}
                onChange={(e) => {
                  const val = e.target.value as 'bottom_right' | 'bottom_center' | 'bottom_left';
                  updateDesign((p) => ({
                    ...p,
                    pageNumber: { ...p.pageNumber, position: val },
                  }));
                }}
                className="px-2 py-1 text-xs border border-neutral-300 rounded bg-white"
              >
                <option value="bottom_left">Bottom Left</option>
                <option value="bottom_center">Bottom Center</option>
                <option value="bottom_right">Bottom Right</option>
              </select>
            </div>

            <div className="flex flex-col gap-1">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Font Size
              </span>
              <div className="flex items-center gap-1">
                <input
                  type="number"
                  min={7}
                  max={14}
                  step={0.5}
                  value={design.pageNumber.fontSize || 9}
                  onChange={(e) => {
                    const val = Number(e.target.value);
                    updateDesign((p) => ({
                      ...p,
                      pageNumber: { ...p.pageNumber, fontSize: val },
                    }));
                  }}
                  className="w-14 px-1.5 py-1 text-xs text-center border border-neutral-300 rounded font-mono bg-white"
                />
                <span className="text-[10px] text-neutral-400">px</span>
              </div>
            </div>

            <div className="flex flex-col gap-1">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                Color
              </span>
              <div className="flex items-center gap-1.5">
                <input
                  type="color"
                  value={design.pageNumber.color || '#94A3B8'}
                  onChange={(e) => {
                    const val = e.target.value;
                    updateDesign((p) => ({
                      ...p,
                      pageNumber: { ...p.pageNumber, color: val },
                    }));
                  }}
                  className="w-7 h-7 p-0.5 border border-neutral-300 rounded cursor-pointer"
                />
                <span className="text-[11px] font-mono uppercase text-neutral-600">
                  {design.pageNumber.color || '#94A3B8'}
                </span>
              </div>
            </div>

            {/* Footer Sequence Order: Move Up / Move Down */}
            <div className="flex flex-col gap-1 border-l border-neutral-200/80 pl-2">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider flex items-center gap-1">
                <ListOrdered className="w-3 h-3 text-blue-600" />
                Footer Position
              </span>
              <div className="flex items-center gap-1.5">
                <span className="px-2 py-1 text-xs font-semibold bg-neutral-100 text-neutral-700 rounded border border-neutral-200 shrink-0">
                  #{currentFooterOrder.indexOf('pageNumber') + 1} of {currentFooterOrder.length}
                </span>
                <button
                  type="button"
                  onClick={() => moveFooterElement('pageNumber', 'up')}
                  disabled={currentFooterOrder.indexOf('pageNumber') <= 0}
                  className="flex items-center gap-1 px-2.5 py-1 text-xs font-medium rounded border border-neutral-300 bg-white text-neutral-700 hover:bg-neutral-50 active:bg-neutral-100 disabled:opacity-40 disabled:cursor-not-allowed transition cursor-pointer"
                  title="Move Page Number Up in Footer"
                >
                  <ArrowUp className="w-3.5 h-3.5 text-blue-600" />
                  <span>Move Up</span>
                </button>
                <button
                  type="button"
                  onClick={() => moveFooterElement('pageNumber', 'down')}
                  disabled={currentFooterOrder.indexOf('pageNumber') >= currentFooterOrder.length - 1}
                  className="flex items-center gap-1 px-2.5 py-1 text-xs font-medium rounded border border-neutral-300 bg-white text-neutral-700 hover:bg-neutral-50 active:bg-neutral-100 disabled:opacity-40 disabled:cursor-not-allowed transition cursor-pointer"
                  title="Move Page Number Down in Footer"
                >
                  <ArrowDown className="w-3.5 h-3.5 text-blue-600" />
                  <span>Move Down</span>
                </button>
              </div>
            </div>
          </>
        )}
      </div>

      {/* Footer helper hint */}
      <div className="mt-2.5 pt-1.5 border-t border-neutral-100 flex items-center justify-between text-[10px] text-neutral-400">
        <span>⚡ All changes update immediately in live A4 preview</span>
        <span>Click empty space or press <kbd className="font-mono bg-neutral-100 border border-neutral-300 px-1 py-0.5 rounded text-neutral-600">Esc</kbd> to deselect</span>
      </div>
    </div>
  );
};
export default ContextualToolbar;
