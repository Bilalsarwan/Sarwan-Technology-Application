import React from 'react';
import {
  DesignerElement,
  InvoiceDesignSettings,
  FontWeight,
} from '../../types/invoiceDesign';
import { Type, Bold, Italic, Underline, X } from 'lucide-react';

export const FONT_OPTIONS = [
  { value: 'Inter, system-ui, sans-serif', label: 'Inter (Clean Sans)' },
  { value: "'Roboto', sans-serif", label: 'Roboto' },
  { value: "'Poppins', sans-serif", label: 'Poppins' },
  { value: "'Outfit', sans-serif", label: 'Outfit' },
  { value: 'Arial, sans-serif', label: 'Arial' },
  { value: "'Helvetica Neue', Helvetica, sans-serif", label: 'Helvetica' },
  { value: "'Montserrat', sans-serif", label: 'Montserrat' },
  { value: "'Lato', sans-serif", label: 'Lato' },
  { value: "'Times New Roman', serif", label: 'Times New Roman' },
  { value: 'Georgia, serif', label: 'Georgia' },
  { value: "'Courier New', monospace", label: 'Courier New' },
  { value: '"Scheherazade New", "Amiri", "Noto Naskh Arabic", Arial, sans-serif', label: 'Amiri / Pashto / Arabic' },
];

export const FONT_WEIGHT_OPTIONS: { value: FontWeight; label: string; shortLabel: string }[] = [
  { value: 'normal', label: 'Regular (400)', shortLabel: 'Regular' },
  { value: 'medium', label: 'Medium (500)', shortLabel: 'Medium' },
  { value: 'semibold', label: 'Semi Bold (600)', shortLabel: 'Semi Bold' },
  { value: 'bold', label: 'Bold (700)', shortLabel: 'Bold' },
];

export const FONT_SIZE_PRESETS = [8, 9, 10, 11, 12, 13, 14, 15, 16, 18, 20, 22, 24, 26, 28, 32, 36, 40, 48];

export interface ElementTypographyState {
  isTextElement: boolean;
  elementName: string;
  fontFamily: string;
  fontSize: number;
  fontWeight: FontWeight;
  italic?: boolean;
  underline?: boolean;
  color?: string;
  minFontSize?: number;
  maxFontSize?: number;
}

/**
 * Returns true if the selected designer element supports typography properties.
 */
export function isTextDesignerElement(element: DesignerElement | null | undefined): boolean {
  if (!element) return false;
  const nonTextElements: DesignerElement[] = [
    'logoLeft',
    'logoRight',
    'shapeTopLeft',
    'shapeTopRight',
    'shapeGoldAccent',
    'shapeBottomLeft',
    'shapeBottomRight',
  ];
  return !nonTextElements.includes(element);
}

/**
 * Extracts the canonical typography state for any selected designer element.
 */
export function getElementTypography(
  element: DesignerElement | null | undefined,
  design: InvoiceDesignSettings
): ElementTypographyState {
  const defaultFont = design.typography?.fontFamily || 'Inter, system-ui, sans-serif';
  const defaultHeadingFont = design.typography?.headingFontFamily || defaultFont;

  if (!element) {
    return {
      isTextElement: true,
      elementName: 'Default Document Typography',
      fontFamily: defaultFont,
      fontSize: design.typography?.baseFontSize || 11.5,
      fontWeight: 'normal',
      color: design.colors?.text || '#0F172A',
      minFontSize: 8,
      maxFontSize: 24,
    };
  }

  switch (element) {
    case 'companyEnglishName':
      return {
        isTextElement: true,
        elementName: 'Company English Name',
        fontFamily: design.company?.fontFamily || defaultHeadingFont,
        fontSize: design.company?.fontSize || design.typography?.companyNameFontSize || 24,
        fontWeight: design.company?.fontWeight || 'bold',
        italic: design.company?.italic,
        underline: design.company?.underline,
        color: design.company?.color || design.title?.color || design.colors?.text || '#0B1E36',
        minFontSize: 12,
        maxFontSize: 40,
      };

    case 'companyPashtoName':
      return {
        isTextElement: true,
        elementName: 'Company Pashto Name',
        fontFamily:
          design.company?.pashtoFontFamily ||
          '"Scheherazade New", "Amiri", "Noto Naskh Arabic", Arial, sans-serif',
        fontSize: design.company?.pashtoFontSize || 18,
        fontWeight: design.company?.fontWeight || 'bold',
        italic: design.company?.italic,
        underline: design.company?.underline,
        color: design.company?.pashtoColor || design.company?.color || '#0B1E36',
        minFontSize: 10,
        maxFontSize: 36,
      };

    case 'companySlogan':
      return {
        isTextElement: true,
        elementName: 'Company Slogan',
        fontFamily: design.company?.sloganFontFamily || design.company?.fontFamily || defaultFont,
        fontSize: design.company?.sloganFontSize || 10,
        fontWeight: design.company?.sloganFontWeight || 'normal',
        italic: design.company?.sloganItalic,
        underline: design.company?.sloganUnderline,
        color: design.company?.sloganColor || design.colors?.mutedText || '#4A6B82',
        minFontSize: 7,
        maxFontSize: 24,
      };

    case 'invoiceTitle':
      return {
        isTextElement: true,
        elementName: 'Invoice Title',
        fontFamily: design.title?.fontFamily || defaultHeadingFont,
        fontSize: design.title?.fontSize || design.typography?.titleFontSize || 26,
        fontWeight: design.title?.fontWeight || 'bold',
        color: design.title?.color || design.colors?.primary || '#0B1E36',
        minFontSize: 14,
        maxFontSize: 48,
      };

    case 'billNumber':
      return {
        isTextElement: true,
        elementName: 'Bill Number',
        fontFamily: design.invoiceNumber?.fontFamily || defaultFont,
        fontSize: design.invoiceNumber?.fontSize || 12,
        fontWeight: design.invoiceNumber?.fontWeight || 'semibold',
        italic: design.invoiceNumber?.italic,
        underline: design.invoiceNumber?.underline,
        color: design.invoiceNumber?.valueColor || design.invoiceNumber?.color || design.colors?.text || '#0B1E36',
        minFontSize: 8,
        maxFontSize: 24,
      };

    case 'invoiceDate':
    case 'dueDate':
      return {
        isTextElement: true,
        elementName: element === 'invoiceDate' ? 'Invoice Date' : 'Due Date',
        fontFamily: design.date?.fontFamily || defaultFont,
        fontSize: design.date?.fontSize || 11,
        fontWeight: design.date?.fontWeight || 'normal',
        italic: design.date?.italic,
        underline: design.date?.underline,
        color: design.date?.valueColor || design.date?.color || design.colors?.text || '#1E293B',
        minFontSize: 8,
        maxFontSize: 22,
      };

    case 'collector':
      return {
        isTextElement: true,
        elementName: 'Assigned Collector',
        fontFamily: design.collector?.fontFamily || defaultFont,
        fontSize: design.collector?.fontSize || 11,
        fontWeight: design.collector?.fontWeight || 'normal',
        italic: design.collector?.italic,
        underline: design.collector?.underline,
        color: design.collector?.valueColor || design.collector?.color || design.colors?.text || '#1E293B',
        minFontSize: 8,
        maxFontSize: 22,
      };

    case 'customerName':
      return {
        isTextElement: true,
        elementName: 'Customer Name',
        fontFamily: design.customer?.nameFontFamily || design.customer?.fontFamily || defaultFont,
        fontSize: design.customer?.nameFontSize || design.customer?.fontSize || 12,
        fontWeight: design.customer?.nameFontWeight || 'semibold',
        italic: design.customer?.nameItalic,
        underline: design.customer?.nameUnderline,
        color: design.customer?.nameValueColor || design.customer?.color || design.colors?.text || '#0F172A',
        minFontSize: 8,
        maxFontSize: 26,
      };

    case 'customerPhone':
      return {
        isTextElement: true,
        elementName: 'Customer Phone',
        fontFamily: design.customer?.phoneFontFamily || design.customer?.fontFamily || defaultFont,
        fontSize: design.customer?.phoneFontSize || design.customer?.fontSize || 11,
        fontWeight: design.customer?.phoneFontWeight || 'normal',
        italic: design.customer?.phoneItalic,
        underline: design.customer?.phoneUnderline,
        color: design.customer?.phoneValueColor || design.customer?.color || design.colors?.text || '#334155',
        minFontSize: 8,
        maxFontSize: 22,
      };

    case 'customerAddress':
      return {
        isTextElement: true,
        elementName: 'Customer Address',
        fontFamily: design.customer?.addressFontFamily || design.customer?.fontFamily || defaultFont,
        fontSize: design.customer?.addressFontSize || design.customer?.fontSize || 11,
        fontWeight: design.customer?.addressFontWeight || 'normal',
        italic: design.customer?.addressItalic,
        underline: design.customer?.addressUnderline,
        color: design.customer?.addressValueColor || design.customer?.color || design.colors?.text || '#334155',
        minFontSize: 8,
        maxFontSize: 22,
      };

    case 'customerEmail':
      return {
        isTextElement: true,
        elementName: 'Customer Email',
        fontFamily: design.customer?.emailFontFamily || design.customer?.fontFamily || defaultFont,
        fontSize: design.customer?.emailFontSize || design.customer?.fontSize || 11,
        fontWeight: design.customer?.emailFontWeight || 'normal',
        italic: design.customer?.emailItalic,
        underline: design.customer?.emailUnderline,
        color: design.customer?.emailValueColor || design.customer?.color || design.colors?.text || '#334155',
        minFontSize: 8,
        maxFontSize: 22,
      };

    case 'customerCompany':
      return {
        isTextElement: true,
        elementName: 'Customer Company',
        fontFamily: design.customer?.companyFontFamily || design.customer?.fontFamily || defaultFont,
        fontSize: design.customer?.companyFontSize || design.customer?.fontSize || 11,
        fontWeight: design.customer?.companyFontWeight || 'normal',
        italic: design.customer?.companyItalic,
        underline: design.customer?.companyUnderline,
        color: design.customer?.companyValueColor || design.customer?.color || design.colors?.text || '#334155',
        minFontSize: 8,
        maxFontSize: 22,
      };

    case 'customerId':
      return {
        isTextElement: true,
        elementName: 'Customer ID',
        fontFamily: design.customer?.customerIdFontFamily || design.customer?.fontFamily || defaultFont,
        fontSize: design.customer?.customerIdFontSize || design.customer?.fontSize || 11,
        fontWeight: design.customer?.customerIdFontWeight || 'normal',
        italic: design.customer?.customerIdItalic,
        underline: design.customer?.customerIdUnderline,
        color: design.customer?.customerIdValueColor || design.customer?.color || design.colors?.text || '#334155',
        minFontSize: 8,
        maxFontSize: 22,
      };

    case 'customerInfo':
      return {
        isTextElement: true,
        elementName: 'Customer Info Card',
        fontFamily: design.customer?.fontFamily || defaultFont,
        fontSize: design.customer?.fontSize || 11,
        fontWeight: design.customer?.fontWeight || 'normal',
        italic: design.customer?.italic,
        underline: design.customer?.underline,
        color: design.customer?.color || design.colors?.text || '#0F172A',
        minFontSize: 8,
        maxFontSize: 24,
      };

    case 'tableHeader':
      return {
        isTextElement: true,
        elementName: 'Table Header',
        fontFamily: design.itemsTable?.headerFontFamily || defaultHeadingFont,
        fontSize: design.itemsTable?.headerFontSize || 11,
        fontWeight: design.itemsTable?.headerFontWeight || 'bold',
        italic: design.itemsTable?.headerItalic,
        underline: design.itemsTable?.headerUnderline,
        color: design.colors?.tableHeaderText || design.itemsTable?.headerTextColor || '#FFFFFF',
        minFontSize: 8,
        maxFontSize: 22,
      };

    case 'tableBody':
      return {
        isTextElement: true,
        elementName: 'Table Body',
        fontFamily: design.itemsTable?.bodyFontFamily || defaultFont,
        fontSize: design.itemsTable?.bodyFontSize || 10,
        fontWeight: design.itemsTable?.bodyFontWeight || 'normal',
        italic: design.itemsTable?.bodyItalic,
        underline: design.itemsTable?.bodyUnderline,
        color: design.colors?.text || '#1E293B',
        minFontSize: 7,
        maxFontSize: 20,
      };

    case 'tableColumnSerial':
    case 'tableColumnDescription':
    case 'tableColumnQuantity':
    case 'tableColumnUnit':
    case 'tableColumnUnitPrice':
    case 'tableColumnDiscount':
    case 'tableColumnTax':
    case 'tableColumnTotal': {
      const colMap: Record<string, keyof typeof design.itemsTable.columns> = {
        tableColumnSerial: 'sNo',
        tableColumnDescription: 'description',
        tableColumnQuantity: 'quantity',
        tableColumnUnit: 'unit',
        tableColumnUnitPrice: 'unitPrice',
        tableColumnDiscount: 'discount',
        tableColumnTax: 'tax',
        tableColumnTotal: 'totalAmount',
      };
      const colKey = colMap[element];
      const col = design.itemsTable?.columns?.[colKey];
      return {
        isTextElement: true,
        elementName: `Column: ${col?.label || colKey}`,
        fontFamily: col?.fontFamily || design.itemsTable?.bodyFontFamily || defaultFont,
        fontSize: col?.fontSize || design.itemsTable?.bodyFontSize || 10,
        fontWeight: col?.fontWeight || design.itemsTable?.bodyFontWeight || 'normal',
        italic: col?.italic,
        underline: col?.underline,
        color: col?.textColor || design.colors?.text || '#1E293B',
        minFontSize: 7,
        maxFontSize: 20,
      };
    }

    case 'paymentInfo':
    case 'paymentMethod':
    case 'paymentStatus':
    case 'paidAmount':
    case 'remainingAmount':
      return {
        isTextElement: true,
        elementName: 'Payment Information',
        fontFamily: design.payment?.fontFamily || defaultFont,
        fontSize: design.payment?.fontSize || 11,
        fontWeight: design.payment?.fontWeight || 'normal',
        italic: design.payment?.italic,
        underline: design.payment?.underline,
        color: design.payment?.textColor || design.colors?.text || '#1E293B',
        minFontSize: 8,
        maxFontSize: 22,
      };

    case 'totals':
    case 'subtotal':
      return {
        isTextElement: true,
        elementName: 'Subtotal Row',
        fontFamily: design.totals?.subtotalFontFamily || defaultFont,
        fontSize: design.totals?.subtotalFontSize || 11,
        fontWeight: design.totals?.subtotalFontWeight || 'normal',
        italic: design.totals?.subtotalItalic,
        underline: design.totals?.subtotalUnderline,
        color: design.totals?.subtotalValueColor || design.totals?.subtotalColor || design.colors?.text || '#1E293B',
        minFontSize: 8,
        maxFontSize: 22,
      };

    case 'discountTotal':
      return {
        isTextElement: true,
        elementName: 'Discount Row',
        fontFamily: design.totals?.discountFontFamily || defaultFont,
        fontSize: design.totals?.discountFontSize || 11,
        fontWeight: design.totals?.discountFontWeight || 'normal',
        italic: design.totals?.discountItalic,
        underline: design.totals?.discountUnderline,
        color: design.totals?.discountValueColor || design.totals?.discountColor || design.colors?.text || '#1E293B',
        minFontSize: 8,
        maxFontSize: 22,
      };

    case 'taxTotal':
      return {
        isTextElement: true,
        elementName: 'Tax Row',
        fontFamily: design.totals?.taxFontFamily || defaultFont,
        fontSize: design.totals?.taxFontSize || 11,
        fontWeight: design.totals?.taxFontWeight || 'normal',
        italic: design.totals?.taxItalic,
        underline: design.totals?.taxUnderline,
        color: design.totals?.taxValueColor || design.totals?.taxColor || design.colors?.text || '#1E293B',
        minFontSize: 8,
        maxFontSize: 22,
      };

    case 'grandTotal':
      return {
        isTextElement: true,
        elementName: 'Grand Total',
        fontFamily: design.totals?.grandTotalFontFamily || defaultHeadingFont,
        fontSize: design.totals?.grandTotalFontSize || 14,
        fontWeight: design.totals?.grandTotalFontWeight || 'bold',
        italic: design.totals?.grandTotalItalic,
        underline: design.totals?.grandTotalUnderline,
        color: design.totals?.grandTotalColor || '#FFFFFF',
        minFontSize: 10,
        maxFontSize: 32,
      };

    case 'totalPaid':
      return {
        isTextElement: true,
        elementName: 'Total Paid Row',
        fontFamily: design.totals?.totalPaidFontFamily || defaultFont,
        fontSize: design.totals?.totalPaidFontSize || 11,
        fontWeight: design.totals?.totalPaidFontWeight || 'normal',
        italic: design.totals?.totalPaidItalic,
        underline: design.totals?.totalPaidUnderline,
        color: design.totals?.totalPaidValueColor || design.totals?.totalPaidColor || design.colors?.text || '#1E293B',
        minFontSize: 8,
        maxFontSize: 22,
      };

    case 'remainingTotal':
    case 'paymentStatusTotal':
      return {
        isTextElement: true,
        elementName: 'Remaining Total Row',
        fontFamily: design.totals?.remainingFontFamily || defaultFont,
        fontSize: design.totals?.remainingFontSize || 11,
        fontWeight: design.totals?.remainingFontWeight || 'bold',
        italic: design.totals?.remainingItalic,
        underline: design.totals?.remainingUnderline,
        color: design.totals?.remainingValueColor || design.totals?.remainingColor || '#DC2626',
        minFontSize: 8,
        maxFontSize: 24,
      };

    case 'notes':
      return {
        isTextElement: true,
        elementName: 'Notes & Terms',
        fontFamily: design.notes?.invoiceNoteFontFamily || defaultFont,
        fontSize: design.notes?.invoiceNoteFontSize || 10,
        fontWeight: design.notes?.invoiceNoteFontWeight || 'normal',
        italic: design.notes?.italic,
        underline: design.notes?.underline,
        color: design.notes?.invoiceNoteColor || design.colors?.text || '#1E293B',
        minFontSize: 7,
        maxFontSize: 20,
      };

    case 'signatures':
      return {
        isTextElement: true,
        elementName: 'Signatures',
        fontFamily: design.signatures?.fontFamily || defaultFont,
        fontSize: design.signatures?.fontSize || 11,
        fontWeight: design.signatures?.fontWeight || 'medium',
        italic: design.signatures?.italic,
        underline: design.signatures?.underline,
        color: design.signatures?.color || design.colors?.text || '#1E293B',
        minFontSize: 8,
        maxFontSize: 22,
      };

    case 'signatureCustomer':
      return {
        isTextElement: true,
        elementName: 'Customer Signature Line',
        fontFamily: design.signatures?.customerFontFamily || design.signatures?.fontFamily || defaultFont,
        fontSize: design.signatures?.customerFontSize || design.signatures?.fontSize || 11,
        fontWeight: design.signatures?.customerFontWeight || design.signatures?.fontWeight || 'medium',
        italic: design.signatures?.italic,
        underline: design.signatures?.underline,
        color: design.signatures?.customerColor || design.signatures?.color || design.colors?.text || '#1E293B',
        minFontSize: 8,
        maxFontSize: 22,
      };

    case 'signatureAuthorized':
      return {
        isTextElement: true,
        elementName: 'Authorized Signature Line',
        fontFamily: design.signatures?.managerFontFamily || design.signatures?.fontFamily || defaultFont,
        fontSize: design.signatures?.managerFontSize || design.signatures?.fontSize || 11,
        fontWeight: design.signatures?.managerFontWeight || design.signatures?.fontWeight || 'medium',
        italic: design.signatures?.italic,
        underline: design.signatures?.underline,
        color: design.signatures?.managerColor || design.signatures?.color || design.colors?.text || '#1E293B',
        minFontSize: 8,
        maxFontSize: 22,
      };

    case 'footer':
      return {
        isTextElement: true,
        elementName: 'Footer',
        fontFamily: design.footer?.fontFamily || defaultFont,
        fontSize: design.footer?.fontSize || 10,
        fontWeight: design.footer?.fontWeight || 'normal',
        italic: design.footer?.italic,
        underline: design.footer?.underline,
        color: design.footer?.color || design.colors?.mutedText || '#64748B',
        minFontSize: 7,
        maxFontSize: 20,
      };

    case 'footerThankYou':
      return {
        isTextElement: true,
        elementName: 'Footer Thank You',
        fontFamily: design.footer?.thankYouFontFamily || design.footer?.fontFamily || defaultFont,
        fontSize: design.footer?.thankYouFontSize || design.footer?.fontSize || 10,
        fontWeight: design.footer?.thankYouFontWeight || design.footer?.fontWeight || 'normal',
        italic: design.footer?.italic,
        underline: design.footer?.underline,
        color: design.footer?.thankYouColor || design.footer?.color || design.colors?.mutedText || '#64748B',
        minFontSize: 7,
        maxFontSize: 20,
      };

    case 'footerContacts':
      return {
        isTextElement: true,
        elementName: 'Footer Contacts',
        fontFamily: design.footer?.contactsFontFamily || design.footer?.fontFamily || defaultFont,
        fontSize: design.footer?.contactsFontSize || design.footer?.fontSize || 10,
        fontWeight: design.footer?.fontWeight || 'normal',
        italic: design.footer?.italic,
        underline: design.footer?.underline,
        color: design.footer?.contactsColor || design.footer?.color || design.colors?.mutedText || '#64748B',
        minFontSize: 7,
        maxFontSize: 20,
      };

    case 'pageNumber':
      return {
        isTextElement: true,
        elementName: 'Page Number',
        fontFamily: design.pageNumber?.fontFamily || defaultFont,
        fontSize: design.pageNumber?.fontSize || 9,
        fontWeight: design.pageNumber?.fontWeight || 'normal',
        italic: design.pageNumber?.italic,
        underline: design.pageNumber?.underline,
        color: design.pageNumber?.color || design.colors?.mutedText || '#64748B',
        minFontSize: 6,
        maxFontSize: 18,
      };

    case 'invoiceMeta':
      return {
        isTextElement: true,
        elementName: 'Invoice Meta Box',
        fontFamily: design.invoiceNumber?.fontFamily || defaultFont,
        fontSize: design.invoiceNumber?.fontSize || 11,
        fontWeight: design.invoiceNumber?.fontWeight || 'normal',
        minFontSize: 8,
        maxFontSize: 22,
      };

    case 'itemsTable':
      return {
        isTextElement: true,
        elementName: 'Items Table',
        fontFamily: design.itemsTable?.bodyFontFamily || defaultFont,
        fontSize: design.itemsTable?.bodyFontSize || 10,
        fontWeight: design.itemsTable?.bodyFontWeight || 'normal',
        minFontSize: 7,
        maxFontSize: 20,
      };

    default:
      return {
        isTextElement: false,
        elementName: String(element),
        fontFamily: defaultFont,
        fontSize: 12,
        fontWeight: 'normal',
      };
  }
}

/**
 * Updates the canonical typography state in InvoiceDesignSettings for a given element.
 */
export function updateElementTypography(
  element: DesignerElement | null | undefined,
  updateDesign: (updater: (prev: InvoiceDesignSettings) => InvoiceDesignSettings) => void,
  changes: {
    fontFamily?: string;
    fontSize?: number;
    fontWeight?: FontWeight;
    italic?: boolean;
    underline?: boolean;
    color?: string;
  }
) {
  updateDesign((prev) => {
    if (!element) {
      return {
        ...prev,
        typography: {
          ...prev.typography,
          ...(changes.fontFamily !== undefined ? { fontFamily: changes.fontFamily } : {}),
          ...(changes.fontSize !== undefined ? { baseFontSize: changes.fontSize } : {}),
        },
      };
    }
    switch (element) {
      case 'companyEnglishName':
        return {
          ...prev,
          company: {
            ...prev.company,
            ...(changes.fontFamily !== undefined ? { fontFamily: changes.fontFamily } : {}),
            ...(changes.fontSize !== undefined ? { fontSize: changes.fontSize } : {}),
            ...(changes.fontWeight !== undefined ? { fontWeight: changes.fontWeight } : {}),
            ...(changes.italic !== undefined ? { italic: changes.italic } : {}),
            ...(changes.underline !== undefined ? { underline: changes.underline } : {}),
            ...(changes.color !== undefined ? { color: changes.color } : {}),
          },
        };

      case 'companyPashtoName':
        return {
          ...prev,
          company: {
            ...prev.company,
            ...(changes.fontFamily !== undefined ? { pashtoFontFamily: changes.fontFamily } : {}),
            ...(changes.fontSize !== undefined ? { pashtoFontSize: changes.fontSize } : {}),
            ...(changes.fontWeight !== undefined ? { fontWeight: changes.fontWeight } : {}),
            ...(changes.italic !== undefined ? { italic: changes.italic } : {}),
            ...(changes.underline !== undefined ? { underline: changes.underline } : {}),
            ...(changes.color !== undefined ? { pashtoColor: changes.color } : {}),
          },
        };

      case 'companySlogan':
        return {
          ...prev,
          company: {
            ...prev.company,
            ...(changes.fontFamily !== undefined ? { sloganFontFamily: changes.fontFamily } : {}),
            ...(changes.fontSize !== undefined ? { sloganFontSize: changes.fontSize } : {}),
            ...(changes.fontWeight !== undefined ? { sloganFontWeight: changes.fontWeight } : {}),
            ...(changes.italic !== undefined ? { sloganItalic: changes.italic } : {}),
            ...(changes.underline !== undefined ? { sloganUnderline: changes.underline } : {}),
            ...(changes.color !== undefined ? { sloganColor: changes.color } : {}),
          },
        };

      case 'invoiceTitle':
        return {
          ...prev,
          title: {
            ...prev.title,
            ...(changes.fontFamily !== undefined ? { fontFamily: changes.fontFamily } : {}),
            ...(changes.fontSize !== undefined ? { fontSize: changes.fontSize } : {}),
            ...(changes.fontWeight !== undefined ? { fontWeight: changes.fontWeight } : {}),
            ...(changes.color !== undefined ? { color: changes.color } : {}),
          },
        };

      case 'billNumber':
        return {
          ...prev,
          invoiceNumber: {
            ...prev.invoiceNumber,
            ...(changes.fontFamily !== undefined ? { fontFamily: changes.fontFamily } : {}),
            ...(changes.fontSize !== undefined ? { fontSize: changes.fontSize } : {}),
            ...(changes.fontWeight !== undefined ? { fontWeight: changes.fontWeight } : {}),
            ...(changes.italic !== undefined ? { italic: changes.italic } : {}),
            ...(changes.underline !== undefined ? { underline: changes.underline } : {}),
            ...(changes.color !== undefined ? { valueColor: changes.color } : {}),
          },
        };

      case 'invoiceDate':
      case 'dueDate':
        return {
          ...prev,
          date: {
            ...prev.date,
            ...(changes.fontFamily !== undefined ? { fontFamily: changes.fontFamily } : {}),
            ...(changes.fontSize !== undefined ? { fontSize: changes.fontSize } : {}),
            ...(changes.fontWeight !== undefined ? { fontWeight: changes.fontWeight } : {}),
            ...(changes.italic !== undefined ? { italic: changes.italic } : {}),
            ...(changes.underline !== undefined ? { underline: changes.underline } : {}),
            ...(changes.color !== undefined ? { valueColor: changes.color } : {}),
          },
        };

      case 'collector':
        return {
          ...prev,
          collector: {
            ...prev.collector,
            ...(changes.fontFamily !== undefined ? { fontFamily: changes.fontFamily } : {}),
            ...(changes.fontSize !== undefined ? { fontSize: changes.fontSize } : {}),
            ...(changes.fontWeight !== undefined ? { fontWeight: changes.fontWeight } : {}),
            ...(changes.italic !== undefined ? { italic: changes.italic } : {}),
            ...(changes.underline !== undefined ? { underline: changes.underline } : {}),
            ...(changes.color !== undefined ? { valueColor: changes.color } : {}),
          },
        };

      case 'customerName':
        return {
          ...prev,
          customer: {
            ...prev.customer,
            ...(changes.fontFamily !== undefined ? { nameFontFamily: changes.fontFamily } : {}),
            ...(changes.fontSize !== undefined ? { nameFontSize: changes.fontSize } : {}),
            ...(changes.fontWeight !== undefined ? { nameFontWeight: changes.fontWeight } : {}),
            ...(changes.italic !== undefined ? { nameItalic: changes.italic } : {}),
            ...(changes.underline !== undefined ? { nameUnderline: changes.underline } : {}),
            ...(changes.color !== undefined ? { nameValueColor: changes.color } : {}),
          },
        };

      case 'customerPhone':
        return {
          ...prev,
          customer: {
            ...prev.customer,
            ...(changes.fontFamily !== undefined ? { phoneFontFamily: changes.fontFamily } : {}),
            ...(changes.fontSize !== undefined ? { phoneFontSize: changes.fontSize } : {}),
            ...(changes.fontWeight !== undefined ? { phoneFontWeight: changes.fontWeight } : {}),
            ...(changes.italic !== undefined ? { phoneItalic: changes.italic } : {}),
            ...(changes.underline !== undefined ? { phoneUnderline: changes.underline } : {}),
            ...(changes.color !== undefined ? { phoneValueColor: changes.color } : {}),
          },
        };

      case 'customerAddress':
        return {
          ...prev,
          customer: {
            ...prev.customer,
            ...(changes.fontFamily !== undefined ? { addressFontFamily: changes.fontFamily } : {}),
            ...(changes.fontSize !== undefined ? { addressFontSize: changes.fontSize } : {}),
            ...(changes.fontWeight !== undefined ? { addressFontWeight: changes.fontWeight } : {}),
            ...(changes.italic !== undefined ? { addressItalic: changes.italic } : {}),
            ...(changes.underline !== undefined ? { addressUnderline: changes.underline } : {}),
            ...(changes.color !== undefined ? { addressValueColor: changes.color } : {}),
          },
        };

      case 'customerEmail':
        return {
          ...prev,
          customer: {
            ...prev.customer,
            ...(changes.fontFamily !== undefined ? { emailFontFamily: changes.fontFamily } : {}),
            ...(changes.fontSize !== undefined ? { emailFontSize: changes.fontSize } : {}),
            ...(changes.fontWeight !== undefined ? { emailFontWeight: changes.fontWeight } : {}),
            ...(changes.italic !== undefined ? { emailItalic: changes.italic } : {}),
            ...(changes.underline !== undefined ? { emailUnderline: changes.underline } : {}),
            ...(changes.color !== undefined ? { emailValueColor: changes.color } : {}),
          },
        };

      case 'customerCompany':
        return {
          ...prev,
          customer: {
            ...prev.customer,
            ...(changes.fontFamily !== undefined ? { companyFontFamily: changes.fontFamily } : {}),
            ...(changes.fontSize !== undefined ? { companyFontSize: changes.fontSize } : {}),
            ...(changes.fontWeight !== undefined ? { companyFontWeight: changes.fontWeight } : {}),
            ...(changes.italic !== undefined ? { companyItalic: changes.italic } : {}),
            ...(changes.underline !== undefined ? { companyUnderline: changes.underline } : {}),
            ...(changes.color !== undefined ? { companyValueColor: changes.color } : {}),
          },
        };

      case 'customerId':
        return {
          ...prev,
          customer: {
            ...prev.customer,
            ...(changes.fontFamily !== undefined ? { customerIdFontFamily: changes.fontFamily } : {}),
            ...(changes.fontSize !== undefined ? { customerIdFontSize: changes.fontSize } : {}),
            ...(changes.fontWeight !== undefined ? { customerIdFontWeight: changes.fontWeight } : {}),
            ...(changes.italic !== undefined ? { customerIdItalic: changes.italic } : {}),
            ...(changes.underline !== undefined ? { customerIdUnderline: changes.underline } : {}),
            ...(changes.color !== undefined ? { customerIdValueColor: changes.color } : {}),
          },
        };

      case 'customerInfo':
        return {
          ...prev,
          customer: {
            ...prev.customer,
            ...(changes.fontFamily !== undefined ? { fontFamily: changes.fontFamily } : {}),
            ...(changes.fontSize !== undefined ? { fontSize: changes.fontSize } : {}),
            ...(changes.fontWeight !== undefined ? { fontWeight: changes.fontWeight } : {}),
            ...(changes.italic !== undefined ? { italic: changes.italic } : {}),
            ...(changes.underline !== undefined ? { underline: changes.underline } : {}),
            ...(changes.color !== undefined ? { color: changes.color } : {}),
          },
        };

      case 'tableHeader':
        return {
          ...prev,
          colors: {
            ...prev.colors,
            ...(changes.color !== undefined ? { tableHeaderText: changes.color } : {}),
          },
          itemsTable: {
            ...prev.itemsTable,
            ...(changes.fontFamily !== undefined ? { headerFontFamily: changes.fontFamily } : {}),
            ...(changes.fontSize !== undefined ? { headerFontSize: changes.fontSize } : {}),
            ...(changes.fontWeight !== undefined ? { headerFontWeight: changes.fontWeight } : {}),
            ...(changes.italic !== undefined ? { headerItalic: changes.italic } : {}),
            ...(changes.underline !== undefined ? { headerUnderline: changes.underline } : {}),
            ...(changes.color !== undefined ? { headerTextColor: changes.color } : {}),
          },
        };

      case 'tableBody':
        return {
          ...prev,
          itemsTable: {
            ...prev.itemsTable,
            ...(changes.fontFamily !== undefined ? { bodyFontFamily: changes.fontFamily } : {}),
            ...(changes.fontSize !== undefined ? { bodyFontSize: changes.fontSize } : {}),
            ...(changes.fontWeight !== undefined ? { bodyFontWeight: changes.fontWeight } : {}),
            ...(changes.italic !== undefined ? { bodyItalic: changes.italic } : {}),
            ...(changes.underline !== undefined ? { bodyUnderline: changes.underline } : {}),
          },
        };

      case 'tableColumnSerial':
      case 'tableColumnDescription':
      case 'tableColumnQuantity':
      case 'tableColumnUnit':
      case 'tableColumnUnitPrice':
      case 'tableColumnDiscount':
      case 'tableColumnTax':
      case 'tableColumnTotal': {
        const colMap: Record<string, keyof typeof prev.itemsTable.columns> = {
          tableColumnSerial: 'sNo',
          tableColumnDescription: 'description',
          tableColumnQuantity: 'quantity',
          tableColumnUnit: 'unit',
          tableColumnUnitPrice: 'unitPrice',
          tableColumnDiscount: 'discount',
          tableColumnTax: 'tax',
          tableColumnTotal: 'totalAmount',
        };
        const colKey = colMap[element];
        const prevCol = prev.itemsTable.columns[colKey];
        return {
          ...prev,
          itemsTable: {
            ...prev.itemsTable,
            columns: {
              ...prev.itemsTable.columns,
              [colKey]: {
                ...prevCol,
                ...(changes.fontFamily !== undefined ? { fontFamily: changes.fontFamily } : {}),
                ...(changes.fontSize !== undefined ? { fontSize: changes.fontSize } : {}),
                ...(changes.fontWeight !== undefined ? { fontWeight: changes.fontWeight } : {}),
                ...(changes.italic !== undefined ? { italic: changes.italic } : {}),
                ...(changes.underline !== undefined ? { underline: changes.underline } : {}),
                ...(changes.color !== undefined ? { textColor: changes.color } : {}),
              },
            },
          },
        };
      }

      case 'paymentInfo':
      case 'paymentMethod':
      case 'paymentStatus':
      case 'paidAmount':
      case 'remainingAmount':
        return {
          ...prev,
          payment: {
            ...prev.payment,
            ...(changes.fontFamily !== undefined ? { fontFamily: changes.fontFamily } : {}),
            ...(changes.fontSize !== undefined ? { fontSize: changes.fontSize } : {}),
            ...(changes.fontWeight !== undefined ? { fontWeight: changes.fontWeight } : {}),
            ...(changes.italic !== undefined ? { italic: changes.italic } : {}),
            ...(changes.underline !== undefined ? { underline: changes.underline } : {}),
            ...(changes.color !== undefined ? { textColor: changes.color } : {}),
          },
        };

      case 'totals':
      case 'subtotal':
        return {
          ...prev,
          totals: {
            ...prev.totals,
            ...(changes.fontFamily !== undefined ? { subtotalFontFamily: changes.fontFamily } : {}),
            ...(changes.fontSize !== undefined ? { subtotalFontSize: changes.fontSize } : {}),
            ...(changes.fontWeight !== undefined ? { subtotalFontWeight: changes.fontWeight } : {}),
            ...(changes.italic !== undefined ? { subtotalItalic: changes.italic } : {}),
            ...(changes.underline !== undefined ? { subtotalUnderline: changes.underline } : {}),
            ...(changes.color !== undefined ? { subtotalValueColor: changes.color } : {}),
          },
        };

      case 'discountTotal':
        return {
          ...prev,
          totals: {
            ...prev.totals,
            ...(changes.fontFamily !== undefined ? { discountFontFamily: changes.fontFamily } : {}),
            ...(changes.fontSize !== undefined ? { discountFontSize: changes.fontSize } : {}),
            ...(changes.fontWeight !== undefined ? { discountFontWeight: changes.fontWeight } : {}),
            ...(changes.italic !== undefined ? { discountItalic: changes.italic } : {}),
            ...(changes.underline !== undefined ? { discountUnderline: changes.underline } : {}),
            ...(changes.color !== undefined ? { discountValueColor: changes.color } : {}),
          },
        };

      case 'taxTotal':
        return {
          ...prev,
          totals: {
            ...prev.totals,
            ...(changes.fontFamily !== undefined ? { taxFontFamily: changes.fontFamily } : {}),
            ...(changes.fontSize !== undefined ? { taxFontSize: changes.fontSize } : {}),
            ...(changes.fontWeight !== undefined ? { taxFontWeight: changes.fontWeight } : {}),
            ...(changes.italic !== undefined ? { taxItalic: changes.italic } : {}),
            ...(changes.underline !== undefined ? { taxUnderline: changes.underline } : {}),
            ...(changes.color !== undefined ? { taxValueColor: changes.color } : {}),
          },
        };

      case 'grandTotal':
        return {
          ...prev,
          totals: {
            ...prev.totals,
            ...(changes.fontFamily !== undefined ? { grandTotalFontFamily: changes.fontFamily } : {}),
            ...(changes.fontSize !== undefined ? { grandTotalFontSize: changes.fontSize } : {}),
            ...(changes.fontWeight !== undefined ? { grandTotalFontWeight: changes.fontWeight } : {}),
            ...(changes.italic !== undefined ? { grandTotalItalic: changes.italic } : {}),
            ...(changes.underline !== undefined ? { grandTotalUnderline: changes.underline } : {}),
            ...(changes.color !== undefined ? { grandTotalColor: changes.color } : {}),
          },
        };

      case 'totalPaid':
        return {
          ...prev,
          totals: {
            ...prev.totals,
            ...(changes.fontFamily !== undefined ? { totalPaidFontFamily: changes.fontFamily } : {}),
            ...(changes.fontSize !== undefined ? { totalPaidFontSize: changes.fontSize } : {}),
            ...(changes.fontWeight !== undefined ? { totalPaidFontWeight: changes.fontWeight } : {}),
            ...(changes.italic !== undefined ? { totalPaidItalic: changes.italic } : {}),
            ...(changes.underline !== undefined ? { totalPaidUnderline: changes.underline } : {}),
            ...(changes.color !== undefined ? { totalPaidValueColor: changes.color } : {}),
          },
        };

      case 'remainingTotal':
      case 'paymentStatusTotal':
        return {
          ...prev,
          totals: {
            ...prev.totals,
            ...(changes.fontFamily !== undefined ? { remainingFontFamily: changes.fontFamily } : {}),
            ...(changes.fontSize !== undefined ? { remainingFontSize: changes.fontSize } : {}),
            ...(changes.fontWeight !== undefined ? { remainingFontWeight: changes.fontWeight } : {}),
            ...(changes.italic !== undefined ? { remainingItalic: changes.italic } : {}),
            ...(changes.underline !== undefined ? { remainingUnderline: changes.underline } : {}),
            ...(changes.color !== undefined ? { remainingValueColor: changes.color } : {}),
          },
        };

      case 'notes':
        return {
          ...prev,
          notes: {
            ...prev.notes,
            ...(changes.fontFamily !== undefined ? { invoiceNoteFontFamily: changes.fontFamily } : {}),
            ...(changes.fontSize !== undefined ? { invoiceNoteFontSize: changes.fontSize } : {}),
            ...(changes.fontWeight !== undefined ? { invoiceNoteFontWeight: changes.fontWeight } : {}),
            ...(changes.italic !== undefined ? { italic: changes.italic } : {}),
            ...(changes.underline !== undefined ? { underline: changes.underline } : {}),
            ...(changes.color !== undefined ? { invoiceNoteColor: changes.color } : {}),
          },
        };

      case 'signatures':
        return {
          ...prev,
          signatures: {
            ...prev.signatures,
            ...(changes.fontFamily !== undefined ? { fontFamily: changes.fontFamily } : {}),
            ...(changes.fontSize !== undefined ? { fontSize: changes.fontSize } : {}),
            ...(changes.fontWeight !== undefined ? { fontWeight: changes.fontWeight } : {}),
            ...(changes.italic !== undefined ? { italic: changes.italic } : {}),
            ...(changes.underline !== undefined ? { underline: changes.underline } : {}),
            ...(changes.color !== undefined ? { color: changes.color } : {}),
          },
        };

      case 'signatureCustomer':
        return {
          ...prev,
          signatures: {
            ...prev.signatures,
            ...(changes.fontFamily !== undefined ? { customerFontFamily: changes.fontFamily } : {}),
            ...(changes.fontSize !== undefined ? { customerFontSize: changes.fontSize } : {}),
            ...(changes.fontWeight !== undefined ? { customerFontWeight: changes.fontWeight } : {}),
            ...(changes.italic !== undefined ? { italic: changes.italic } : {}),
            ...(changes.underline !== undefined ? { underline: changes.underline } : {}),
            ...(changes.color !== undefined ? { customerColor: changes.color } : {}),
          },
        };

      case 'signatureAuthorized':
        return {
          ...prev,
          signatures: {
            ...prev.signatures,
            ...(changes.fontFamily !== undefined ? { managerFontFamily: changes.fontFamily } : {}),
            ...(changes.fontSize !== undefined ? { managerFontSize: changes.fontSize } : {}),
            ...(changes.fontWeight !== undefined ? { managerFontWeight: changes.fontWeight } : {}),
            ...(changes.italic !== undefined ? { italic: changes.italic } : {}),
            ...(changes.underline !== undefined ? { underline: changes.underline } : {}),
            ...(changes.color !== undefined ? { managerColor: changes.color } : {}),
          },
        };

      case 'footer':
        return {
          ...prev,
          footer: {
            ...prev.footer,
            ...(changes.fontFamily !== undefined ? { fontFamily: changes.fontFamily } : {}),
            ...(changes.fontSize !== undefined ? { fontSize: changes.fontSize } : {}),
            ...(changes.fontWeight !== undefined ? { fontWeight: changes.fontWeight } : {}),
            ...(changes.italic !== undefined ? { italic: changes.italic } : {}),
            ...(changes.underline !== undefined ? { underline: changes.underline } : {}),
            ...(changes.color !== undefined ? { color: changes.color } : {}),
          },
          typography: {
            ...prev.typography,
            ...(changes.fontSize !== undefined ? { footerFontSize: changes.fontSize } : {}),
            ...(changes.fontWeight !== undefined ? { footerFontWeight: changes.fontWeight } : {}),
          },
        };

      case 'footerThankYou':
        return {
          ...prev,
          footer: {
            ...prev.footer,
            ...(changes.fontFamily !== undefined ? { thankYouFontFamily: changes.fontFamily } : {}),
            ...(changes.fontSize !== undefined ? { thankYouFontSize: changes.fontSize } : {}),
            ...(changes.fontWeight !== undefined ? { thankYouFontWeight: changes.fontWeight } : {}),
            ...(changes.italic !== undefined ? { italic: changes.italic } : {}),
            ...(changes.underline !== undefined ? { underline: changes.underline } : {}),
            ...(changes.color !== undefined ? { thankYouColor: changes.color } : {}),
          },
        };

      case 'footerContacts':
        return {
          ...prev,
          footer: {
            ...prev.footer,
            ...(changes.fontFamily !== undefined ? { contactsFontFamily: changes.fontFamily } : {}),
            ...(changes.fontSize !== undefined ? { contactsFontSize: changes.fontSize } : {}),
            ...(changes.italic !== undefined ? { italic: changes.italic } : {}),
            ...(changes.underline !== undefined ? { underline: changes.underline } : {}),
            ...(changes.color !== undefined ? { contactsColor: changes.color } : {}),
          },
        };

      case 'pageNumber':
        return {
          ...prev,
          pageNumber: {
            ...prev.pageNumber,
            ...(changes.fontFamily !== undefined ? { fontFamily: changes.fontFamily } : {}),
            ...(changes.fontSize !== undefined ? { fontSize: changes.fontSize } : {}),
            ...(changes.fontWeight !== undefined ? { fontWeight: changes.fontWeight } : {}),
            ...(changes.italic !== undefined ? { italic: changes.italic } : {}),
            ...(changes.underline !== undefined ? { underline: changes.underline } : {}),
            ...(changes.color !== undefined ? { color: changes.color } : {}),
          },
        };

      default:
        return prev;
    }
  });
}

export interface TypographyControlsProps {
  selectedElement: DesignerElement | null;
  design: InvoiceDesignSettings;
  updateDesign: (updater: (prev: InvoiceDesignSettings) => InvoiceDesignSettings) => void;
  onSelectElement?: (el: DesignerElement | null) => void;
  onClose?: () => void;
  className?: string;
  layout?: 'compact' | 'horizontal' | 'vertical' | 'toolbar';
  showLabels?: boolean;
  showFormattingButtons?: boolean;
}

export const TypographyControls: React.FC<TypographyControlsProps> = ({
  selectedElement,
  design,
  updateDesign,
  onSelectElement,
  onClose,
  className = '',
  layout = 'vertical',
  showLabels = true,
  showFormattingButtons = true,
}) => {
  const typography = getElementTypography(selectedElement, design);

  if (selectedElement && !typography.isTextElement) {
    return null;
  }

  const { fontFamily, fontSize, fontWeight, italic, underline, color, minFontSize = 7, maxFontSize = 48 } = typography;

  const handleFontFamilyChange = (val: string) => {
    updateElementTypography(selectedElement, updateDesign, { fontFamily: val });
  };

  const handleFontSizeChange = (val: number) => {
    const clamped = Math.max(minFontSize, Math.min(maxFontSize, val));
    updateElementTypography(selectedElement, updateDesign, { fontSize: clamped });
  };

  const handleFontWeightChange = (val: FontWeight) => {
    updateElementTypography(selectedElement, updateDesign, { fontWeight: val });
  };

  const handleItalicToggle = () => {
    updateElementTypography(selectedElement, updateDesign, { italic: !italic });
  };

  const handleUnderlineToggle = () => {
    updateElementTypography(selectedElement, updateDesign, { underline: !underline });
  };

  const handleColorChange = (newColor: string) => {
    updateElementTypography(selectedElement, updateDesign, { color: newColor });
  };

  // Horizontal / Toolbar mode (e.g. for top ribbon or floating contextual bar)
  if (layout === 'horizontal' || layout === 'toolbar') {
    return (
      <div
        className={`flex flex-wrap items-center gap-2 text-xs bg-white/95 rounded-lg border border-neutral-200 px-3 py-1.5 shadow-xs ${className}`}
        data-typography-controls={selectedElement || 'documentDefault'}
      >
        {/* Element Selector Dropdown / Badge */}
        {onSelectElement ? (
          <div className="flex items-center gap-1 border-r border-neutral-200 pr-2">
            <Type className="w-3.5 h-3.5 text-blue-600 shrink-0" />
            <select
              value={selectedElement || ''}
              onChange={(e) => onSelectElement(e.target.value ? (e.target.value as DesignerElement) : null)}
              className="px-1.5 py-1 text-xs font-semibold border border-neutral-300 rounded bg-neutral-50 text-neutral-800 hover:border-neutral-400 focus:border-blue-500 cursor-pointer max-w-[170px]"
              title="Target Text Element"
            >
              <option value="">Default Document Font</option>
              <optgroup label="Header & Branding">
                <option value="companyEnglishName">Company English Name</option>
                <option value="companyPashtoName">Company Pashto Name</option>
                <option value="companySlogan">Company Slogan</option>
              </optgroup>
              <optgroup label="Invoice Information">
                <option value="invoiceTitle">Invoice Title</option>
                <option value="billNumber">Bill Number</option>
                <option value="invoiceDate">Invoice Date</option>
                <option value="dueDate">Due Date</option>
                <option value="collector">Assigned Collector</option>
              </optgroup>
              <optgroup label="Customer Details">
                <option value="customerName">Customer Name</option>
                <option value="customerPhone">Customer Phone</option>
                <option value="customerAddress">Customer Address</option>
                <option value="customerEmail">Customer Email</option>
                <option value="customerCompany">Customer Company</option>
                <option value="customerId">Customer ID</option>
              </optgroup>
              <optgroup label="Items Table">
                <option value="tableHeader">Table Header</option>
                <option value="tableBody">Table Body</option>
                <option value="tableColumnSerial">Column: Serial (#)</option>
                <option value="tableColumnDescription">Column: Description</option>
                <option value="tableColumnQuantity">Column: Quantity</option>
                <option value="tableColumnUnit">Column: Unit</option>
                <option value="tableColumnUnitPrice">Column: Unit Price</option>
                <option value="tableColumnDiscount">Column: Discount</option>
                <option value="tableColumnTax">Column: Tax</option>
                <option value="tableColumnTotal">Column: Total</option>
              </optgroup>
              <optgroup label="Payment & Totals">
                <option value="paymentInfo">Payment Details</option>
                <option value="subtotal">Subtotal Row</option>
                <option value="discountTotal">Discount Row</option>
                <option value="taxTotal">Tax Row</option>
                <option value="grandTotal">Grand Total Banner</option>
                <option value="totalPaid">Total Paid Row</option>
                <option value="remainingTotal">Remaining Total Row</option>
              </optgroup>
              <optgroup label="Closing & Signatures">
                <option value="notes">Notes & Terms</option>
                <option value="signatures">Signatures (General)</option>
                <option value="signatureCustomer">Customer Signature</option>
                <option value="signatureAuthorized">Authorized Signature</option>
                <option value="footer">Footer (General)</option>
                <option value="footerThankYou">Footer Thank You</option>
                <option value="footerContacts">Footer Contacts</option>
                <option value="pageNumber">Page Number</option>
              </optgroup>
            </select>
          </div>
        ) : (
          <div className="flex items-center gap-1 text-neutral-500 font-semibold text-[11px] pr-1 border-r border-neutral-200">
            <Type className="w-3.5 h-3.5 text-blue-600" />
            <span className="hidden md:inline">{typography.elementName}:</span>
          </div>
        )}

        {/* 1. Font Family Dropdown */}
        <div className="flex items-center gap-1">
          {showLabels && (
            <span className="text-[10px] text-neutral-400 uppercase font-semibold">Font</span>
          )}
          <select
            value={fontFamily}
            onChange={(e) => handleFontFamilyChange(e.target.value)}
            className="px-2 py-1 text-xs font-medium border border-neutral-300 rounded bg-white text-neutral-800 hover:border-neutral-400 focus:border-blue-500 focus:ring-1 focus:ring-blue-500 cursor-pointer max-w-[150px]"
            title="Font Family"
          >
            {FONT_OPTIONS.map((f) => (
              <option key={f.value} value={f.value}>
                {f.label}
              </option>
            ))}
          </select>
        </div>

        {/* 2. Font Size Dropdown + Number Stepper */}
        <div className="flex items-center gap-1">
          {showLabels && (
            <span className="text-[10px] text-neutral-400 uppercase font-semibold">Size</span>
          )}
          <select
            value={FONT_SIZE_PRESETS.includes(fontSize) ? fontSize : ''}
            onChange={(e) => {
              if (e.target.value) handleFontSizeChange(Number(e.target.value));
            }}
            className="px-1.5 py-1 text-xs font-medium border border-neutral-300 rounded bg-white text-neutral-800 hover:border-neutral-400 focus:border-blue-500 cursor-pointer w-14"
            title="Font Size Presets"
          >
            {!FONT_SIZE_PRESETS.includes(fontSize) && (
              <option value="">{fontSize}px</option>
            )}
            {FONT_SIZE_PRESETS.map((s) => (
              <option key={s} value={s}>
                {s}px
              </option>
            ))}
          </select>

          <input
            type="number"
            min={minFontSize}
            max={maxFontSize}
            step={0.5}
            value={fontSize}
            onChange={(e) => handleFontSizeChange(Number(e.target.value))}
            className="w-12 px-1 py-1 text-xs text-center border border-neutral-300 rounded font-mono bg-white text-neutral-800 focus:border-blue-500"
            title="Custom Font Size (px)"
          />
        </div>

        {/* 3. Font Weight Dropdown */}
        <div className="flex items-center gap-1">
          {showLabels && (
            <span className="text-[10px] text-neutral-400 uppercase font-semibold">Weight</span>
          )}
          <select
            value={fontWeight}
            onChange={(e) => handleFontWeightChange(e.target.value as FontWeight)}
            className="px-2 py-1 text-xs font-medium border border-neutral-300 rounded bg-white text-neutral-800 hover:border-neutral-400 focus:border-blue-500 cursor-pointer"
            title="Font Weight"
          >
            {FONT_WEIGHT_OPTIONS.map((w) => (
              <option key={w.value} value={w.value}>
                {w.label}
              </option>
            ))}
          </select>
        </div>

        {/* Quick Style Toggles */}
        {showFormattingButtons && (
          <div className="flex items-center gap-1 pl-1 border-l border-neutral-200">
            <button
              type="button"
              onClick={() => handleFontWeightChange(fontWeight === 'bold' ? 'normal' : 'bold')}
              className={`p-1 rounded border transition ${
                fontWeight === 'bold'
                  ? 'bg-blue-600 text-white border-blue-600'
                  : 'bg-white text-neutral-700 border-neutral-300 hover:bg-neutral-50'
              }`}
              title="Toggle Bold"
            >
              <Bold className="w-3.5 h-3.5" />
            </button>
            <button
              type="button"
              onClick={handleItalicToggle}
              className={`p-1 rounded border transition ${
                italic
                  ? 'bg-blue-600 text-white border-blue-600'
                  : 'bg-white text-neutral-700 border-neutral-300 hover:bg-neutral-50'
              }`}
              title="Toggle Italic"
            >
              <Italic className="w-3.5 h-3.5" />
            </button>
            <button
              type="button"
              onClick={handleUnderlineToggle}
              className={`p-1 rounded border transition ${
                underline
                  ? 'bg-blue-600 text-white border-blue-600'
                  : 'bg-white text-neutral-700 border-neutral-300 hover:bg-neutral-50'
              }`}
              title="Toggle Underline"
            >
              <Underline className="w-3.5 h-3.5" />
            </button>

            {color !== undefined && (
              <div className="flex items-center gap-1 ml-1" title="Text Color">
                <input
                  type="color"
                  value={color}
                  onChange={(e) => handleColorChange(e.target.value)}
                  className="w-6 h-6 rounded border border-neutral-300 cursor-pointer p-0.5"
                />
              </div>
            )}
          </div>
        )}

        {/* Optional Close Button */}
        {onClose && (
          <div className="flex items-center pl-1 border-l border-neutral-200 ml-auto">
            <button
              type="button"
              onClick={onClose}
              className="p-1 rounded text-neutral-400 hover:text-neutral-700 hover:bg-neutral-100 transition cursor-pointer"
              title="Close Typography Toolbar"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
        )}
      </div>
    );
  }

  // Vertical / Sidebar inspector mode
  return (
    <div className={`space-y-3 ${className}`} data-typography-controls={selectedElement}>
      {/* 1. Font Family Dropdown */}
      <div className="flex flex-col gap-1">
        {showLabels && (
          <label className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
            Font Family
          </label>
        )}
        <select
          value={fontFamily}
          onChange={(e) => handleFontFamilyChange(e.target.value)}
          className="w-full px-2 py-1.5 text-xs font-medium border border-neutral-300 rounded bg-white text-neutral-800 hover:border-neutral-400 focus:border-blue-500 focus:ring-1 focus:ring-blue-500 cursor-pointer"
        >
          {FONT_OPTIONS.map((f) => (
            <option key={f.value} value={f.value}>
              {f.label}
            </option>
          ))}
        </select>
      </div>

      {/* 2. Font Size (Dropdown + Precision Input) */}
      <div className="flex flex-col gap-1">
        {showLabels && (
          <label className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
            Font Size
          </label>
        )}
        <div className="grid grid-cols-2 gap-2">
          <select
            value={FONT_SIZE_PRESETS.includes(fontSize) ? fontSize : ''}
            onChange={(e) => {
              if (e.target.value) handleFontSizeChange(Number(e.target.value));
            }}
            className="w-full px-2 py-1 text-xs font-medium border border-neutral-300 rounded bg-white text-neutral-800 hover:border-neutral-400 focus:border-blue-500 cursor-pointer"
          >
            {!FONT_SIZE_PRESETS.includes(fontSize) && (
              <option value="">{fontSize}px</option>
            )}
            {FONT_SIZE_PRESETS.map((s) => (
              <option key={s} value={s}>
                {s}px
              </option>
            ))}
          </select>

          <div className="flex items-center gap-1">
            <input
              type="number"
              min={minFontSize}
              max={maxFontSize}
              step={0.5}
              value={fontSize}
              onChange={(e) => handleFontSizeChange(Number(e.target.value))}
              className="w-full px-2 py-1 text-xs text-center border border-neutral-300 rounded font-mono bg-white text-neutral-800 focus:border-blue-500"
            />
            <span className="text-[10px] text-neutral-400 font-mono">px</span>
          </div>
        </div>
      </div>

      {/* 3. Font Weight Dropdown */}
      <div className="flex flex-col gap-1">
        {showLabels && (
          <label className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
            Font Weight
          </label>
        )}
        <select
          value={fontWeight}
          onChange={(e) => handleFontWeightChange(e.target.value as FontWeight)}
          className="w-full px-2 py-1.5 text-xs font-medium border border-neutral-300 rounded bg-white text-neutral-800 hover:border-neutral-400 focus:border-blue-500 cursor-pointer"
        >
          {FONT_WEIGHT_OPTIONS.map((w) => (
            <option key={w.value} value={w.value}>
              {w.label}
            </option>
          ))}
        </select>
      </div>

      {/* Quick Formatting Toggles */}
      {showFormattingButtons && (
        <div className="flex items-center gap-1.5 pt-1">
          <button
            type="button"
            onClick={() => handleFontWeightChange(fontWeight === 'bold' ? 'normal' : 'bold')}
            className={`flex-1 py-1 text-xs font-semibold rounded border flex items-center justify-center gap-1 transition ${
              fontWeight === 'bold'
                ? 'bg-blue-600 text-white border-blue-600'
                : 'bg-white text-neutral-700 border-neutral-300 hover:bg-neutral-50'
            }`}
          >
            <Bold className="w-3.5 h-3.5" />
            <span>Bold</span>
          </button>

          <button
            type="button"
            onClick={handleItalicToggle}
            className={`flex-1 py-1 text-xs font-semibold rounded border flex items-center justify-center gap-1 transition ${
              italic
                ? 'bg-blue-600 text-white border-blue-600'
                : 'bg-white text-neutral-700 border-neutral-300 hover:bg-neutral-50'
            }`}
          >
            <Italic className="w-3.5 h-3.5" />
            <span>Italic</span>
          </button>

          <button
            type="button"
            onClick={handleUnderlineToggle}
            className={`flex-1 py-1 text-xs font-semibold rounded border flex items-center justify-center gap-1 transition ${
              underline
                ? 'bg-blue-600 text-white border-blue-600'
                : 'bg-white text-neutral-700 border-neutral-300 hover:bg-neutral-50'
            }`}
          >
            <Underline className="w-3.5 h-3.5" />
            <span>Underline</span>
          </button>
        </div>
      )}
    </div>
  );
};

export default TypographyControls;
