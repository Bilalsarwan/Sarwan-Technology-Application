import React, { useState, useMemo } from 'react';
import { Invoice, Expense, BusinessSettings, UserProfile } from '../../types';
import { formatAFN, formatDate, getTodayDateString } from '../../utils/format';
import { calculateInvoiceExpenseSummary } from '../../utils/purchaseCostCalculator';
import { downloadElementAsPdf } from '../../utils/pdf';
import {
  X,
  Download,
  Printer,
  FileText,
  AlertTriangle,
  Receipt,
  Building,
  User,
  Calendar,
  ShieldCheck,
  CheckCircle2,
  Loader2,
} from 'lucide-react';

export interface InternalInvoiceExpenseReportModalProps {
  isOpen: boolean;
  onClose: () => void;
  invoice: Invoice | null;
  expenses: Expense[];
  settings: BusinessSettings;
  userProfile?: UserProfile | null;
}

export const InternalInvoiceExpenseReportModal: React.FC<InternalInvoiceExpenseReportModalProps> = ({
  isOpen,
  onClose,
  invoice,
  expenses,
  settings,
  userProfile,
}) => {
  const [isExportingPdf, setIsExportingPdf] = useState<boolean>(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  const todayStr = useMemo(() => getTodayDateString(), []);

  // Filter expenses strictly to this invoice and calculate authoritative summary
  const invoiceExpenses = useMemo(() => {
    if (!invoice?.id) return [];
    return (expenses || []).filter((e) => e.invoiceId === invoice.id);
  }, [expenses, invoice?.id]);

  const expenseSummary = useMemo(() => {
    return calculateInvoiceExpenseSummary(invoiceExpenses, invoice?.id);
  }, [invoiceExpenses, invoice?.id]);

  if (!isOpen || !invoice) return null;

  const handleDownloadPdf = async () => {
    if (isExportingPdf) return;
    setIsExportingPdf(true);
    setErrorMessage(null);
    try {
      const filename = `Internal-Expense-Report-${invoice.billNumber || invoice.id}-${todayStr}.pdf`;
      await downloadElementAsPdf('printable-invoice-expense-report', filename, {
        paperSize: 'A4',
        orientation: 'portrait',
      });
    } catch (err: any) {
      console.error('Failed to export internal expense report PDF:', err);
      setErrorMessage(err?.message || 'Failed to generate PDF. Please try again.');
    } finally {
      setIsExportingPdf(false);
    }
  };

  const handlePrint = () => {
    // Hide modal chrome and trigger native browser print of printable area
    window.print();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-black/70 backdrop-blur-xs overflow-y-auto print:p-0 print:bg-white print:static">
      <div className="bg-white rounded-xl shadow-2xl w-full max-w-4xl max-h-[94vh] flex flex-col overflow-hidden border border-neutral-200 print:max-h-none print:shadow-none print:border-none print:w-full">
        {/* Top Header Bar - Hidden in Print */}
        <div className="px-4 py-3 sm:px-6 sm:py-3.5 bg-neutral-900 text-white flex items-center justify-between shrink-0 border-b border-neutral-800 print:hidden">
          <div className="flex items-center gap-2.5 sm:gap-3 min-w-0">
            <div className="p-2 bg-neutral-800 rounded-lg border border-neutral-700 shrink-0 text-orange-400">
              <Receipt className="w-5 h-5" />
            </div>
            <div className="min-w-0">
              <div className="flex items-center gap-2 flex-wrap">
                <h2 className="text-sm sm:text-base font-bold text-white truncate">
                  Internal Invoice Expense Report
                </h2>
                <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-neutral-800 border border-neutral-700 text-orange-400 font-bold shrink-0">
                  {invoice.billNumber}
                </span>
                <span className="text-[10px] font-semibold px-2 py-0.5 rounded bg-amber-950 text-amber-300 border border-amber-800 shrink-0">
                  Internal Staff Only
                </span>
              </div>
              <p className="text-[11px] text-neutral-400 truncate">
                Customer: {invoice.customerSnapshot?.name || 'Customer'} • Total Expenses:{' '}
                {formatAFN(expenseSummary.totalExpenses)}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            <button
              type="button"
              onClick={onClose}
              disabled={isExportingPdf}
              className="p-1.5 rounded-lg text-neutral-400 hover:text-white hover:bg-neutral-800 transition cursor-pointer disabled:opacity-50"
              title="Close"
              aria-label="Close"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Error Banner */}
        {errorMessage && (
          <div className="px-4 py-2.5 bg-rose-50 border-b border-rose-200 text-rose-700 text-xs flex items-center justify-between shrink-0 print:hidden">
            <div className="flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 text-rose-600 shrink-0" />
              <span>{errorMessage}</span>
            </div>
            <button
              type="button"
              onClick={() => setErrorMessage(null)}
              className="text-rose-500 hover:text-rose-800 cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        )}

        {/* Scrollable Document Container */}
        <div className="flex-1 overflow-y-auto p-3 sm:p-6 bg-neutral-100 print:bg-white print:p-0">
          <div
            id="printable-invoice-expense-report"
            className="max-w-3xl mx-auto bg-white p-6 sm:p-8 rounded-lg shadow-sm border border-neutral-200 print:border-none print:shadow-none print:p-0 print:max-w-none space-y-6 text-neutral-900"
          >
            {/* Header / Company Branding */}
            <div className="border-b-2 border-neutral-900 pb-5">
              <div className="flex flex-row items-center justify-between gap-4">
                <div className="flex items-center gap-3.5">
                  <div
                    className="w-16 h-16 bg-white flex items-center justify-center shrink-0 overflow-hidden p-1 shadow-2xs rounded-full border border-neutral-200"
                  >
                    <img
                      src={settings.logo || '/sarwan-logo.png'}
                      alt="Sarwan Technology"
                      className="max-h-full max-w-full object-contain"
                      onError={(e) => {
                        const target = e.currentTarget;
                        if (target.src.endsWith('.png')) target.src = '/sarwan-logo.svg';
                      }}
                    />
                  </div>
                  <div>
                    <h1 className="text-xl sm:text-2xl font-black tracking-tight text-neutral-900">
                      {settings.companyName || 'SARWAN TECHNOLOGY'}
                    </h1>
                    <p className="text-xs font-bold text-orange-600 tracking-wider uppercase">
                      Internal Invoice Expense &amp; Direct Cost Audit Report
                    </p>
                    <div className="mt-1 text-[11px] text-neutral-500 flex flex-wrap gap-x-3 gap-y-0.5">
                      {settings.phone && <span>Phone: {settings.phone}</span>}
                      {settings.email && <span>Email: {settings.email}</span>}
                    </div>
                  </div>
                </div>

                <div className="text-right shrink-0">
                  <span className="text-[10px] font-bold uppercase tracking-wider text-rose-700 bg-rose-50 border border-rose-200 px-2 py-0.5 rounded">
                    Internal Confidential
                  </span>
                  <p className="text-xs font-mono font-bold text-neutral-700 mt-2">
                    Date: {formatDate(todayStr)}
                  </p>
                  <p className="text-[10px] text-neutral-400 mt-0.5">
                    Generated by: {userProfile?.name || 'Authorized Staff'}
                  </p>
                </div>
              </div>
            </div>

            {/* Document Metadata Grid (Invoice & Customer Details) */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 bg-neutral-50 p-4 rounded-xl border border-neutral-200 text-xs">
              {/* Invoice Information */}
              <div className="space-y-1.5 border-b sm:border-b-0 sm:border-r border-neutral-200 pb-3 sm:pb-0 sm:pr-4">
                <div className="flex items-center gap-1.5 text-neutral-500 font-bold uppercase tracking-wider text-[10px]">
                  <FileText className="w-3.5 h-3.5 text-neutral-600" />
                  <span>Invoice Information</span>
                </div>
                <div className="grid grid-cols-2 gap-x-2 gap-y-1 pt-1">
                  <span className="text-neutral-500">Invoice Number:</span>
                  <span className="font-mono font-bold text-neutral-900 break-words">
                    {invoice.billNumber}
                  </span>

                  <span className="text-neutral-500">Invoice Date:</span>
                  <span className="font-mono text-neutral-800">{formatDate(invoice.date)}</span>

                  <span className="text-neutral-500">Billing Status:</span>
                  <span className="capitalize font-semibold text-neutral-800">
                    {invoice.billingState === 'quotation'
                      ? 'Quotation'
                      : invoice.billingState === 'rejected'
                      ? 'Rejected'
                      : invoice.status || 'Active'}
                  </span>

                  <span className="text-neutral-500">Billed Sales Total:</span>
                  <span className="font-mono font-bold text-neutral-900">
                    {formatAFN(invoice.totalAmount)}
                  </span>
                </div>
              </div>

              {/* Customer Information (Strictly respects permissions) */}
              <div className="space-y-1.5 sm:pl-2">
                <div className="flex items-center gap-1.5 text-neutral-500 font-bold uppercase tracking-wider text-[10px]">
                  <Building className="w-3.5 h-3.5 text-neutral-600" />
                  <span>Customer Details</span>
                </div>
                <div className="grid grid-cols-2 gap-x-2 gap-y-1 pt-1">
                  <span className="text-neutral-500">Customer Name:</span>
                  <span className="font-bold text-neutral-900 break-words">
                    {invoice.customerSnapshot?.name || 'Customer'}
                  </span>

                  <span className="text-neutral-500">Phone:</span>
                  <span className="font-mono text-neutral-800 break-words">
                    {invoice.customerSnapshot?.phone || '—'}
                  </span>

                  <span className="text-neutral-500">Email:</span>
                  <span className="font-mono text-neutral-800 break-words">
                    {invoice.customerSnapshot?.email || '—'}
                  </span>

                  <span className="text-neutral-500">Address:</span>
                  <span className="text-neutral-700 break-words">
                    {invoice.customerSnapshot?.address || '—'}
                  </span>
                </div>
              </div>
            </div>

            {/* Expenses Summary KPI Cards */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div className="p-3 bg-neutral-50 rounded-lg border border-neutral-200">
                <span className="text-[10px] font-bold uppercase tracking-wider text-neutral-500 block">
                  Total Expenses
                </span>
                <span className="text-base font-bold font-mono text-neutral-900 block mt-1 break-words">
                  {formatAFN(expenseSummary.totalExpenses)}
                </span>
                <span className="text-[10px] text-neutral-400 block mt-0.5">
                  Sum of invoice-linked records
                </span>
              </div>

              <div className="p-3 bg-neutral-50 rounded-lg border border-neutral-200">
                <span className="text-[10px] font-bold uppercase tracking-wider text-neutral-500 block">
                  Number of Expenses
                </span>
                <span className="text-base font-bold font-mono text-neutral-900 block mt-1">
                  {expenseSummary.count} record{expenseSummary.count === 1 ? '' : 's'}
                </span>
                <span className="text-[10px] text-neutral-400 block mt-0.5">
                  Associated with #{invoice.billNumber}
                </span>
              </div>

              <div className="p-3 bg-neutral-50 rounded-lg border border-neutral-200">
                <span className="text-[10px] font-bold uppercase tracking-wider text-neutral-500 block">
                  Latest Expense Date
                </span>
                <span className="text-base font-bold font-mono text-neutral-900 block mt-1">
                  {expenseSummary.latestDate ? formatDate(expenseSummary.latestDate) : 'None'}
                </span>
                <span className="text-[10px] text-neutral-400 block mt-0.5">
                  Most recent recorded cost
                </span>
              </div>
            </div>

            {/* Expenses Detail Table */}
            <div>
              <div className="flex items-center justify-between mb-2">
                <h3 className="text-xs font-bold uppercase tracking-wider text-neutral-800 flex items-center gap-1.5">
                  <Receipt className="w-3.5 h-3.5 text-orange-500" />
                  Itemized Direct Expenses ({invoiceExpenses.length})
                </h3>
                <span className="text-[11px] text-neutral-500 font-mono">
                  All figures in Afghani (AFN)
                </span>
              </div>

              {invoiceExpenses.length === 0 ? (
                <div className="p-6 bg-neutral-50 border border-neutral-200 rounded-lg text-center text-xs text-neutral-500">
                  <Receipt className="w-8 h-8 text-neutral-300 mx-auto mb-2" />
                  <p className="font-semibold text-neutral-700">No expenses recorded for this invoice.</p>
                  <p className="text-[11px] text-neutral-400 mt-0.5">
                    Direct operational costs and purchase disbursements can be recorded in the invoice details view.
                  </p>
                </div>
              ) : (
                <div className="border border-neutral-200 rounded-lg overflow-hidden shadow-2xs">
                  <table className="w-full border-collapse text-xs">
                    <thead>
                      <tr className="bg-neutral-900 text-white font-semibold text-left">
                        <th className="py-2.5 px-3 w-8 text-center">#</th>
                        <th className="py-2.5 px-3 whitespace-nowrap">Date</th>
                        <th className="py-2.5 px-3">Description / Purpose</th>
                        <th className="py-2.5 px-3 whitespace-nowrap">Category</th>
                        <th className="py-2.5 px-3 whitespace-nowrap">Recorded By</th>
                        <th className="py-2.5 px-3 text-right whitespace-nowrap">Amount (AFN)</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-neutral-200">
                      {invoiceExpenses.map((exp, idx) => (
                        <tr key={exp.id || idx} className="hover:bg-neutral-50/80">
                          <td className="py-2.5 px-3 text-center text-neutral-400 font-mono text-[11px]">
                            {idx + 1}
                          </td>
                          <td className="py-2.5 px-3 font-mono text-neutral-700 whitespace-nowrap">
                            {formatDate(exp.date)}
                          </td>
                          <td className="py-2.5 px-3 text-neutral-900 font-medium">
                            <div className="break-words max-w-sm whitespace-normal">{exp.title}</div>
                            {exp.note && (
                              <div className="text-[11px] text-neutral-500 font-normal break-words max-w-sm whitespace-normal mt-0.5">
                                {exp.note}
                              </div>
                            )}
                          </td>
                          <td className="py-2.5 px-3 whitespace-nowrap">
                            <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-neutral-100 text-neutral-700 border border-neutral-200">
                              {exp.category || 'General'}
                            </span>
                          </td>
                          <td className="py-2.5 px-3 text-neutral-600 whitespace-nowrap">
                            {exp.requestedByName || 'Staff Member'}
                          </td>
                          <td className="py-2.5 px-3 text-right font-mono font-bold text-neutral-900 whitespace-nowrap">
                            {formatAFN(exp.amount)}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                    <tfoot>
                      <tr className="bg-neutral-100 font-bold border-t-2 border-neutral-300">
                        <td colSpan={5} className="py-3 px-3 text-right text-neutral-800 uppercase text-[11px] tracking-wider">
                          Total Direct Expenses:
                        </td>
                        <td className="py-3 px-3 text-right font-mono font-black text-sm text-neutral-900 whitespace-nowrap">
                          {formatAFN(expenseSummary.totalExpenses)}
                        </td>
                      </tr>
                    </tfoot>
                  </table>
                </div>
              )}
            </div>

            {/* Financial Separation & Compliance Notice */}
            <div className="p-3 bg-neutral-50 border border-neutral-200 rounded-lg text-[11px] text-neutral-600 space-y-1">
              <div className="flex items-center gap-1.5 font-bold text-neutral-800">
                <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
                <span>Financial Independence &amp; Data Integrity Policy</span>
              </div>
              <p>
                Direct invoice expenses are recorded solely for internal cost tracking and net profitability analysis.
                These figures remain strictly isolated from the customer&apos;s billing statement: customer payment calculations,
                issued receipts, and receivable balances are unaffected.
              </p>
            </div>

            {/* Signatures / Audit Sign-Off */}
            <div className="pt-6 border-t border-neutral-200 grid grid-cols-2 gap-8 text-xs text-neutral-600">
              <div>
                <p className="font-semibold text-neutral-800">Prepared &amp; Verified By:</p>
                <div className="mt-8 border-b border-neutral-400 w-48" />
                <p className="mt-1 font-mono text-[11px] text-neutral-500">
                  {userProfile?.name || 'Staff User'} ({userProfile?.role || 'Staff'})
                </p>
              </div>
              <div className="text-right">
                <p className="font-semibold text-neutral-800">Management Authorization:</p>
                <div className="mt-8 border-b border-neutral-400 w-48 ml-auto" />
                <p className="mt-1 font-mono text-[11px] text-neutral-500">Official Stamp &amp; Signature</p>
              </div>
            </div>

            {/* Footer */}
            <div className="pt-3 border-t border-neutral-100 text-center text-[10px] text-neutral-400 font-mono">
              Sarwan Technology Billing &amp; Invoicing System • Internal Audit Document • Generated {formatDate(todayStr)}
            </div>
          </div>
        </div>

        {/* Modal Footer Controls - Hidden in Print */}
        <div className="px-4 py-3 sm:px-6 sm:py-3.5 bg-neutral-50 border-t border-neutral-200 flex flex-col sm:flex-row items-center justify-between gap-3 shrink-0 print:hidden">
          <div className="text-xs text-neutral-600 flex items-center gap-2">
            <span className="font-semibold text-neutral-800">Document Type:</span>
            <span className="font-mono text-neutral-600">
              Internal Expense Report • {invoiceExpenses.length} expense record{invoiceExpenses.length !== 1 ? 's' : ''}
            </span>
          </div>

          <div className="flex items-center gap-2 w-full sm:w-auto justify-end">
            <button
              type="button"
              onClick={onClose}
              disabled={isExportingPdf}
              className="px-4 py-2 text-xs font-semibold rounded-lg bg-white hover:bg-neutral-100 border border-neutral-300 text-neutral-700 transition cursor-pointer disabled:opacity-50"
            >
              Close
            </button>
            <button
              type="button"
              onClick={handlePrint}
              disabled={isExportingPdf}
              className="px-4 py-2 text-xs font-semibold rounded-lg bg-white hover:bg-neutral-50 active:bg-neutral-100 text-neutral-800 border border-neutral-300 transition inline-flex items-center gap-1.5 shadow-2xs cursor-pointer disabled:opacity-50 active:scale-95"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>Print</span>
            </button>
            <button
              type="button"
              onClick={handleDownloadPdf}
              disabled={isExportingPdf}
              className="px-5 py-2 text-xs font-bold rounded-lg bg-[#2563EB] hover:bg-[#1D4ED8] active:bg-[#1E40AF] text-white transition inline-flex items-center gap-2 shadow-xs cursor-pointer disabled:opacity-50 active:scale-95 min-w-[150px] justify-center focus:outline-none focus-visible:ring-2 focus-visible:ring-[#2563EB]"
            >
              {isExportingPdf ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin shrink-0" />
                  <span>Generating PDF...</span>
                </>
              ) : (
                <>
                  <Download className="w-4 h-4 shrink-0" />
                  <span>Download PDF</span>
                </>
              )}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default InternalInvoiceExpenseReportModal;
