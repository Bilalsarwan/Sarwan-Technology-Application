import React, { useState } from 'react';
import { useAuth } from '../../context/AuthContext';
import { toast } from '../../context/ToastContext';
import { Lock, KeyRound, AlertCircle, CheckCircle, Eye, EyeOff, Loader2, ShieldAlert, LogOut, X } from 'lucide-react';

interface ChangePasswordModalProps {
  isVoluntary?: boolean;
  onClose?: () => void;
}

export const ChangePasswordModal: React.FC<ChangePasswordModalProps> = ({
  isVoluntary = false,
  onClose,
}) => {
  const { userProfile, changeMandatoryPassword, signOutUser } = useAuth();
  const [newPassword, setNewPassword] = useState<string>('');
  const [confirmPassword, setConfirmPassword] = useState<string>('');
  const [showPassword, setShowPassword] = useState<boolean>(false);
  const [loading, setLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<boolean>(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    if (!newPassword || newPassword.length < 6) {
      setError('Password must be at least 6 characters long.');
      return;
    }

    if (newPassword !== confirmPassword) {
      setError('Password and confirmation do not match.');
      return;
    }

    if (newPassword === 'Sarwan@User2026!' || newPassword.toLowerCase() === 'password') {
      setError('Please choose a secure personal password different from the default password.');
      return;
    }

    setLoading(true);
    try {
      await changeMandatoryPassword(newPassword);
      setSuccess(true);
      toast.success('Your password has been changed successfully.');
      if (isVoluntary) {
        setTimeout(() => {
          onClose?.();
        }, 1200);
      }
    } catch (err: any) {
      const errMsg = err.message || 'Failed to update password. Please try again.';
      setError(errMsg);
      toast.error(errMsg);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-xs p-4 overflow-y-auto">
      <div className="w-full max-w-md bg-white rounded-2xl shadow-2xl border border-neutral-200 p-6 sm:p-8 relative animate-in fade-in zoom-in-95 duration-200">
        {/* Optional Close Button for voluntary mode */}
        {isVoluntary && onClose && (
          <button
            type="button"
            onClick={onClose}
            className="absolute top-4 right-4 p-2 rounded-lg text-neutral-400 hover:text-neutral-700 hover:bg-neutral-100 transition cursor-pointer"
            aria-label="Close"
          >
            <X className="w-5 h-5" />
          </button>
        )}

        {/* Header Icon */}
        <div className="flex items-center gap-3 mb-5">
          <div className="p-3 bg-amber-50 text-amber-600 rounded-xl border border-amber-200">
            <KeyRound className="w-6 h-6" />
          </div>
          <div>
            <span className="text-[10px] font-bold tracking-widest text-amber-600 uppercase bg-amber-100 px-2 py-0.5 rounded-full">
              {isVoluntary ? 'Account Security' : 'Mandatory Action'}
            </span>
            <h2 className="text-xl font-black text-neutral-900 tracking-tight mt-1">
              {isVoluntary ? 'Change Password' : 'Create New Password'}
            </h2>
          </div>
        </div>

        {/* Success state for voluntary mode */}
        {success && isVoluntary ? (
          <div className="p-6 text-center space-y-3">
            <div className="w-12 h-12 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center mx-auto">
              <CheckCircle className="w-7 h-7" />
            </div>
            <h3 className="text-base font-bold text-neutral-900">Password Changed</h3>
            <p className="text-xs text-neutral-600">
              Your personal password has been successfully updated and secured.
            </p>
            {onClose && (
              <button
                type="button"
                onClick={onClose}
                className="mt-2 px-5 py-2 bg-[#2563EB] hover:bg-[#1D4ED8] active:bg-[#1E40AF] text-white text-xs font-bold rounded-xl shadow-xs transition cursor-pointer active:scale-[0.98] focus:outline-none focus-visible:ring-2 focus-visible:ring-[#2563EB]"
              >
                Close
              </button>
            )}
          </div>
        ) : (
          <>
            {/* Informative notice */}
            <div className="p-3.5 bg-neutral-50 rounded-xl border border-neutral-200 mb-5 text-xs text-neutral-600 space-y-1">
              <p className="font-semibold text-neutral-900">
                {isVoluntary ? `Account: ${userProfile?.name}` : `Welcome, ${userProfile?.name}!`}
              </p>
              <p>
                {isVoluntary
                  ? 'Update your personal login password. Enter a confidential password containing at least 6 characters.'
                  : 'You are logged in with a default initial password. As a mandatory security measure, you must set a new confidential password before accessing your account dashboard.'}
              </p>
              <div className="pt-2 flex items-center gap-2 text-[11px] text-neutral-500">
                <span className="font-mono bg-neutral-200 px-1.5 py-0.5 rounded text-neutral-700">
                  @{userProfile?.username || userProfile?.email}
                </span>
                <span className="capitalize font-semibold text-neutral-700">
                  ({userProfile?.role?.replace('_', ' ')})
                </span>
              </div>
            </div>

            {/* Error Notice */}
            {error && (
              <div className="mb-4 p-3 bg-red-50 border border-red-200 text-red-700 text-xs rounded-xl flex items-start gap-2">
                <AlertCircle className="w-4 h-4 shrink-0 text-red-500 mt-0.5" />
                <div className="flex-1 font-medium">{error}</div>
              </div>
            )}

            {/* Form */}
            <form onSubmit={handleSubmit} className="space-y-4">
              {/* New Password */}
              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="block text-xs font-semibold text-neutral-700">
                    New Password
                  </label>
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="text-[11px] text-neutral-500 hover:text-neutral-700 font-medium flex items-center gap-1 cursor-pointer"
                  >
                    {showPassword ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                    <span>{showPassword ? 'Hide' : 'Show'}</span>
                  </button>
                </div>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-neutral-400">
                    <Lock className="w-4 h-4" />
                  </div>
                  <input
                    type={showPassword ? 'text' : 'password'}
                    required
                    autoComplete="new-password"
                    value={newPassword}
                    onChange={(e) => {
                      setNewPassword(e.target.value);
                      if (error) setError(null);
                    }}
                    placeholder="Enter new password (min. 6 characters)"
                    className="w-full pl-9.5 pr-3.5 py-2.5 text-xs bg-neutral-50 border border-neutral-300 rounded-xl focus:outline-none focus:bg-white focus:border-[#F58220] focus:ring-1 focus:ring-[#F58220] transition text-neutral-900 placeholder:text-neutral-400"
                  />
                </div>
              </div>

              {/* Confirm Password */}
              <div>
                <label className="block text-xs font-semibold text-neutral-700 mb-1">
                  Confirm New Password
                </label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-neutral-400">
                    <Lock className="w-4 h-4" />
                  </div>
                  <input
                    type={showPassword ? 'text' : 'password'}
                    required
                    autoComplete="new-password"
                    value={confirmPassword}
                    onChange={(e) => {
                      setConfirmPassword(e.target.value);
                      if (error) setError(null);
                    }}
                    placeholder="Re-enter your new password"
                    className="w-full pl-9.5 pr-3.5 py-2.5 text-xs bg-neutral-50 border border-neutral-300 rounded-xl focus:outline-none focus:bg-white focus:border-[#F58220] focus:ring-1 focus:ring-[#F58220] transition text-neutral-900 placeholder:text-neutral-400"
                  />
                </div>
              </div>

              {/* Action buttons */}
              <div className="pt-2 flex items-center justify-between gap-3">
                {isVoluntary ? (
                  <button
                    type="button"
                    onClick={onClose}
                    className="px-3.5 py-2.5 text-xs font-semibold text-neutral-600 hover:text-neutral-900 hover:bg-neutral-100 rounded-xl transition cursor-pointer"
                  >
                    Cancel
                  </button>
                ) : (
                  <button
                    type="button"
                    onClick={signOutUser}
                    className="px-3.5 py-2.5 text-xs font-semibold text-neutral-600 hover:text-red-600 hover:bg-neutral-100 rounded-xl transition flex items-center gap-1.5 cursor-pointer"
                  >
                    <LogOut className="w-4 h-4" />
                    <span>Sign Out</span>
                  </button>
                )}

                <button
                  type="submit"
                  disabled={loading || !newPassword || !confirmPassword}
                  className="px-5 py-2.5 bg-[#2563EB] hover:bg-[#1D4ED8] active:bg-[#1E40AF] text-white text-xs font-bold rounded-xl transition shadow-xs flex items-center gap-2 cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed active:scale-[0.99] focus:outline-none focus-visible:ring-2 focus-visible:ring-[#2563EB]"
                >
                  {loading ? (
                    <>
                      <Loader2 className="w-4 h-4 animate-spin" />
                      <span>Saving New Password...</span>
                    </>
                  ) : (
                    <>
                      <CheckCircle className="w-4 h-4" />
                      <span>{isVoluntary ? 'Update Password' : 'Set Password & Open Dashboard'}</span>
                    </>
                  )}
                </button>
              </div>
            </form>
          </>
        )}
      </div>
    </div>
  );
};
