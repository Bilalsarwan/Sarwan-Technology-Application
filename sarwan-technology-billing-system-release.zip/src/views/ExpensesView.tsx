import React, { useState, useMemo } from 'react';
import { Expense, ExpenseStatus, Invoice, BusinessSettings } from '../types';
import { formatAFN, formatDate, getTodayDateString } from '../utils/format';
import { useAuth } from '../context/AuthContext';
import { advanceExpenseWorkflow } from '../services/db';
import { downloadElementAsPdf } from '../utils/pdf';
import { toast } from '../context/ToastContext';
import {
  Search,
  Receipt,
  Plus,
  CheckCircle2,
  Clock,
  ShieldCheck,
  AlertCircle,
  XCircle,
  History,
  ArrowRight,
  User,
  X,
  Send,
  Download,
  Loader2,
  FileText,
} from 'lucide-react';

interface ExpensesViewProps {
  expenses: Expense[];
  onAddExpense: () => void;
  onEditExpense?: (expense: Expense) => void;
  invoices?: Invoice[];
  settings?: BusinessSettings;
}

export const ExpensesView: React.FC<ExpensesViewProps> = ({
  expenses,
  onAddExpense,
  onEditExpense,
  invoices,
  settings,
}) => {
  const { userProfile, isSuperAdmin, currentUser } = useAuth();
  const isInvoiceManager = userProfile?.role === 'invoice_manager';

  const currentUserId = userProfile?.id || currentUser?.uid;
  const isOwnerOfExpense = (expense: Expense) => {
    if (!currentUserId || !expense.requestedBy) return false;
    return (
      expense.requestedBy === currentUserId ||
      expense.requestedBy.toLowerCase() === currentUserId.toLowerCase()
    );
  };

  const [searchTerm, setSearchTerm] = useState<string>('');
  const [startDate, setStartDate] = useState<string>('');
  const [endDate, setEndDate] = useState<string>('');
  const [statusFilter, setStatusFilter] = useState<'all' | ExpenseStatus>('all');
  const [categoryFilter, setCategoryFilter] = useState<string>('all');
  const [invoiceFilter, setInvoiceFilter] = useState<'all' | 'invoice_linked' | 'general'>('all');
  const [isExportingPdf, setIsExportingPdf] = useState<boolean>(false);

  // Timeline / Details Modal
  const [selectedTimelineExpense, setSelectedTimelineExpense] = useState<Expense | null>(null);

  // Workflow action state
  const [activeActionExpense, setActiveActionExpense] = useState<Expense | null>(null);
  const [actionType, setActionType] = useState<'reject' | 'resubmit' | null>(null);
  const [actionReason, setActionReason] = useState<string>('');
  const [actionCorrections, setActionCorrections] = useState<string>('');
  const [isProcessing, setIsProcessing] = useState<boolean>(false);
  const [actionError, setActionError] = useState<string | null>(null);

  // Derive categories from data
  const availableCategories = useMemo(() => {
    const set = new Set<string>();
    expenses.forEach((e) => {
      if (e.category) set.add(e.category);
    });
    return Array.from(set);
  }, [expenses]);

  const filteredExpenses = useMemo(() => {
    const seenIds = new Set<string>();
    return expenses.filter((e) => {
      if (!e) return false;
      // Deduplicate by ID if present to ensure financial accuracy
      if (e.id) {
        if (seenIds.has(e.id)) return false;
        seenIds.add(e.id);
      }

      const term = searchTerm.toLowerCase().trim();
      if (term) {
        const matchTitle = e.title?.toLowerCase().includes(term);
        const matchNote = e.note?.toLowerCase().includes(term);
        const matchRequester = e.requestedByName?.toLowerCase().includes(term);
        const matchCategory = e.category?.toLowerCase().includes(term);
        const matchBillNumber = e.billNumber?.toLowerCase().includes(term);
        if (!matchTitle && !matchNote && !matchRequester && !matchCategory && !matchBillNumber) return false;
      }

      if (invoiceFilter === 'invoice_linked' && !e.invoiceId && !e.billNumber) return false;
      if (invoiceFilter === 'general' && (e.invoiceId || e.billNumber)) return false;

      if (statusFilter !== 'all') {
        const currentStatus = e.status || 'pending_manager';
        if (currentStatus !== statusFilter) return false;
      }

      if (categoryFilter !== 'all' && e.category !== categoryFilter) {
        return false;
      }

      if (startDate && e.date < startDate) return false;
      if (endDate && e.date > endDate) return false;

      return true;
    });
  }, [expenses, searchTerm, statusFilter, categoryFilter, invoiceFilter, startDate, endDate]);

  const totalExpenseAmount = filteredExpenses.reduce(
    (sum, e) => sum + (Number(e.amount) || 0),
    0
  );

  const invoiceLinkedCount = useMemo(() => {
    return filteredExpenses.filter((e) => Boolean(e.invoiceId || e.billNumber)).length;
  }, [filteredExpenses]);

  const handleExportPdf = async () => {
    if (isExportingPdf) return;
    setIsExportingPdf(true);
    try {
      const todayStr = getTodayDateString();
      await downloadElementAsPdf(
        'printable-expenses-view-container',
        `Sarwan-Technology-Expenses-Report-${todayStr}.pdf`,
        { paperSize: 'A4', orientation: 'landscape' }
      );
      toast.success('Expenses report PDF downloaded successfully.');
    } catch (err: any) {
      console.error('Failed to export expenses report PDF:', err);
      toast.error(err?.message || 'Failed to export PDF report. Please try again.');
    } finally {
      setIsExportingPdf(false);
    }
  };

  // Status counts
  const counts = useMemo(() => {
    const c = {
      all: expenses.length,
      pending_manager: 0,
      pending_admin: 0,
      approved: 0,
      executed: 0,
      rejected: 0,
    };
    expenses.forEach((e) => {
      const s = e.status || 'pending_manager';
      if (c[s] !== undefined) {
        c[s]++;
      }
    });
    return c;
  }, [expenses]);

  const handleQuickAdvance = async (
    expense: Expense,
    action: 'manager_approve' | 'admin_approve' | 'admin_execute'
  ) => {
    if (!userProfile) return;
    setIsProcessing(true);
    try {
      await advanceExpenseWorkflow({
        expenseId: expense.id,
        action,
        userId: userProfile.id,
        userName: userProfile.name,
        userRole: userProfile.role,
        existingTimeline: expense.timeline,
      });
      const actionLabels = {
        manager_approve: 'Expense approved by manager.',
        admin_approve: 'Expense approved by super admin.',
        admin_execute: 'Expense marked as executed and disbursed.',
      };
      toast.success(actionLabels[action] || 'Expense status updated successfully.');
    } catch (err: any) {
      console.error('Workflow advance error:', err);
      toast.error(err.message || 'Failed to update expense status.');
    } finally {
      setIsProcessing(false);
    }
  };

  const handleConfirmActionWithReason = async () => {
    if (!activeActionExpense || !userProfile || !actionType) return;
    if (actionType === 'reject' && !actionReason.trim()) {
      setActionError('Please specify the reason for rejection.');
      return;
    }

    setIsProcessing(true);
    setActionError(null);

    try {
      await advanceExpenseWorkflow({
        expenseId: activeActionExpense.id,
        action: actionType,
        userId: userProfile.id,
        userName: userProfile.name,
        userRole: userProfile.role,
        reason: actionReason.trim(),
        corrections: actionCorrections.trim(),
        existingTimeline: activeActionExpense.timeline,
      });

      toast.success(
        actionType === 'reject'
          ? 'Expense rejected and returned to requester with feedback.'
          : 'Expense resubmitted for manager review.'
      );

      setActiveActionExpense(null);
      setActionType(null);
      setActionReason('');
      setActionCorrections('');
    } catch (err: any) {
      console.error('Workflow action error:', err);
      const errMsg = err.message || 'Failed to submit workflow action.';
      setActionError(errMsg);
      toast.error(errMsg);
    } finally {
      setIsProcessing(false);
    }
  };

  const renderStatusBadge = (status?: ExpenseStatus) => {
    switch (status) {
      case 'pending_admin':
        return (
          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[11px] font-bold bg-blue-100 text-blue-800 border border-blue-200">
            <Clock className="w-3 h-3 text-blue-600" />
            Pending Admin
          </span>
        );
      case 'approved':
        return (
          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[11px] font-bold bg-purple-100 text-purple-800 border border-purple-200">
            <ShieldCheck className="w-3 h-3 text-purple-600" />
            Ready for Payout
          </span>
        );
      case 'executed':
        return (
          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[11px] font-bold bg-emerald-100 text-emerald-800 border border-emerald-200">
            <CheckCircle2 className="w-3 h-3 text-emerald-600" />
            Executed (Paid)
          </span>
        );
      case 'rejected':
        return (
          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[11px] font-bold bg-rose-100 text-rose-800 border border-rose-200">
            <XCircle className="w-3 h-3 text-rose-600" />
            Rejected
          </span>
        );
      case 'pending_manager':
      default:
        return (
          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[11px] font-bold bg-amber-100 text-amber-900 border border-amber-300">
            <Clock className="w-3 h-3 text-amber-700" />
            Pending Manager
          </span>
        );
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-xl font-bold text-neutral-900">Expenses &amp; Payout Workflow</h1>
            <span className="px-2 py-0.5 text-[10px] font-black uppercase bg-neutral-100 text-neutral-800 rounded border border-neutral-300">
              4-Stage Audit
            </span>
          </div>
          <p className="text-xs text-neutral-500 mt-0.5">
            Submit, review, approve, and disburse operating expenses with full dual-authorization audit trail.
          </p>
        </div>
        <div className="flex items-center gap-2 self-start sm:self-auto flex-wrap">
          <button
            onClick={handleExportPdf}
            disabled={isExportingPdf || filteredExpenses.length === 0}
            className="px-4 py-2 bg-white hover:bg-neutral-100 text-neutral-800 text-xs font-bold rounded-lg border border-neutral-300 shadow-2xs transition inline-flex items-center justify-center gap-1.5 active:scale-98 cursor-pointer disabled:opacity-50"
            title="Download Expense Report PDF"
          >
            {isExportingPdf ? (
              <Loader2 className="w-4 h-4 animate-spin text-blue-600" />
            ) : (
              <Download className="w-4 h-4 text-blue-600" />
            )}
            <span>Expense Report PDF</span>
          </button>
          <button
            onClick={onAddExpense}
            className="px-4 py-2 bg-[#2563EB] hover:bg-[#1D4ED8] active:bg-[#1E40AF] text-white text-xs font-bold rounded-lg shadow-xs transition inline-flex items-center justify-center gap-1.5 active:scale-98 cursor-pointer focus:outline-none focus-visible:ring-2 focus-visible:ring-[#2563EB]"
          >
            <Plus className="w-4 h-4 text-white" />
            <span>Record Expense</span>
          </button>
        </div>
      </div>

      {/* Metric Summary */}
      <div className="bg-neutral-900 text-white p-5 rounded-xl border border-neutral-800 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <span className="text-[11px] font-bold text-rose-400 uppercase tracking-wide block">
            Total Filtered Business Expenses
          </span>
          <p className="text-2xl sm:text-3xl font-black font-mono mt-1 text-white">
            {formatAFN(totalExpenseAmount)}
          </p>
          <p className="text-xs text-neutral-400 mt-1">
            Across {filteredExpenses.length} expense records
          </p>
        </div>
        <div className="flex items-center gap-2">
          <div className="bg-neutral-800 px-3.5 py-2 rounded-lg border border-neutral-700 text-xs">
            <span className="text-[10px] text-neutral-400 uppercase block">Pending Manager</span>
            <span className="font-bold text-amber-400 font-mono text-base">{counts.pending_manager}</span>
          </div>
          <div className="bg-neutral-800 px-3.5 py-2 rounded-lg border border-neutral-700 text-xs">
            <span className="text-[10px] text-neutral-400 uppercase block">Pending Admin</span>
            <span className="font-bold text-blue-400 font-mono text-base">{counts.pending_admin}</span>
          </div>
          <div className="bg-neutral-800 px-3.5 py-2 rounded-lg border border-neutral-700 text-xs">
            <span className="text-[10px] text-neutral-400 uppercase block">Ready Payout</span>
            <span className="font-bold text-purple-400 font-mono text-base">{counts.approved}</span>
          </div>
        </div>
      </div>

      {/* Workflow Tabs */}
      <div className="flex items-center gap-1.5 border-b border-neutral-200 overflow-x-auto pb-1 text-xs">
        <button
          onClick={() => setStatusFilter('all')}
          className={`px-3 py-2 font-semibold rounded-t-lg transition whitespace-nowrap ${
            statusFilter === 'all'
              ? 'border-b-2 border-orange-600 text-neutral-900 bg-white'
              : 'text-neutral-500 hover:text-neutral-900'
          }`}
        >
          All ({counts.all})
        </button>
        <button
          onClick={() => setStatusFilter('pending_manager')}
          className={`px-3 py-2 font-semibold rounded-t-lg transition whitespace-nowrap ${
            statusFilter === 'pending_manager'
              ? 'border-b-2 border-orange-600 text-neutral-900 bg-white'
              : 'text-neutral-500 hover:text-neutral-900'
          }`}
        >
          Pending Manager ({counts.pending_manager})
        </button>
        <button
          onClick={() => setStatusFilter('pending_admin')}
          className={`px-3 py-2 font-semibold rounded-t-lg transition whitespace-nowrap ${
            statusFilter === 'pending_admin'
              ? 'border-b-2 border-orange-600 text-neutral-900 bg-white'
              : 'text-neutral-500 hover:text-neutral-900'
          }`}
        >
          Pending Admin ({counts.pending_admin})
        </button>
        <button
          onClick={() => setStatusFilter('approved')}
          className={`px-3 py-2 font-semibold rounded-t-lg transition whitespace-nowrap ${
            statusFilter === 'approved'
              ? 'border-b-2 border-orange-600 text-neutral-900 bg-white'
              : 'text-neutral-500 hover:text-neutral-900'
          }`}
        >
          Ready for Payout ({counts.approved})
        </button>
        <button
          onClick={() => setStatusFilter('executed')}
          className={`px-3 py-2 font-semibold rounded-t-lg transition whitespace-nowrap ${
            statusFilter === 'executed'
              ? 'border-b-2 border-orange-600 text-neutral-900 bg-white'
              : 'text-neutral-500 hover:text-neutral-900'
          }`}
        >
          Executed ({counts.executed})
        </button>
        <button
          onClick={() => setStatusFilter('rejected')}
          className={`px-3 py-2 font-semibold rounded-t-lg transition whitespace-nowrap ${
            statusFilter === 'rejected'
              ? 'border-b-2 border-orange-600 text-neutral-900 bg-white'
              : 'text-neutral-500 hover:text-neutral-900'
          }`}
        >
          Rejected ({counts.rejected})
        </button>
      </div>

      {/* Filter and Search */}
      <div className="bg-white p-4 rounded-xl border border-neutral-200 shadow-xs space-y-3">
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-6 gap-3">
          <div className="relative md:col-span-2">
            <Search className="w-4 h-4 text-neutral-400 absolute left-3 top-2.5" />
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Search by title, invoice #, note, requester..."
              className="w-full text-xs pl-9 pr-3 py-2 border border-neutral-300 rounded-lg focus:outline-none focus:ring-1 focus:ring-orange-500"
            />
          </div>
          <div>
            <select
              value={invoiceFilter}
              onChange={(e) => setInvoiceFilter(e.target.value as any)}
              className="w-full text-xs border border-neutral-300 rounded-lg px-3 py-2 bg-white focus:outline-none focus:ring-1 focus:ring-orange-500"
            >
              <option value="all">All Expense Types</option>
              <option value="invoice_linked">Invoice-Linked Only</option>
              <option value="general">General Operations Only</option>
            </select>
          </div>
          <div>
            <select
              value={categoryFilter}
              onChange={(e) => setCategoryFilter(e.target.value)}
              className="w-full text-xs border border-neutral-300 rounded-lg px-3 py-2 bg-white focus:outline-none focus:ring-1 focus:ring-orange-500"
            >
              <option value="all">All Categories</option>
              {availableCategories.map((c) => (
                <option key={c} value={c}>
                  {c}
                </option>
              ))}
            </select>
          </div>
          <div>
            <input
              type="date"
              value={startDate}
              onChange={(e) => setStartDate(e.target.value)}
              className="w-full text-xs font-mono border border-neutral-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-1 focus:ring-orange-500"
            />
          </div>
          <div>
            <input
              type="date"
              value={endDate}
              onChange={(e) => setEndDate(e.target.value)}
              className="w-full text-xs font-mono border border-neutral-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-1 focus:ring-orange-500"
            />
          </div>
        </div>

        {(searchTerm || startDate || endDate || categoryFilter !== 'all' || statusFilter !== 'all' || invoiceFilter !== 'all') && (
          <div className="pt-2 border-t border-neutral-100 flex items-center justify-between text-xs">
            <button
              onClick={() => {
                setSearchTerm('');
                setStartDate('');
                setEndDate('');
                setCategoryFilter('all');
                setStatusFilter('all');
                setInvoiceFilter('all');
              }}
              className="text-[11px] text-orange-600 hover:text-orange-700 font-semibold cursor-pointer"
            >
              Reset Filters
            </button>
            <span className="text-neutral-500">
              Showing {filteredExpenses.length} of {expenses.length} records
            </span>
          </div>
        )}
      </div>

      {/* Expenses Table (Exportable as PDF) */}
      <div
        id="printable-expenses-view-container"
        className="bg-white rounded-xl border border-neutral-200 shadow-xs overflow-hidden"
      >
        {/* Printable Document Header (Rendered in exported PDF / Print) */}
        <div className="p-5 border-b-2 border-neutral-900 bg-white">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
              <h2 className="text-xl font-black text-neutral-900 tracking-tight">
                {settings?.companyName || 'SARWAN TECHNOLOGY'}
              </h2>
              <p className="text-xs font-bold text-orange-600 uppercase tracking-wider">
                Operating &amp; Invoice Direct Expenses Audit Ledger
              </p>
              <div className="text-[11px] text-neutral-500 mt-1 flex flex-wrap gap-x-3">
                <span>Generated: {formatDate(getTodayDateString())}</span>
                <span>Audited By: {userProfile?.name || 'Staff User'}</span>
              </div>
            </div>
            <div className="text-left sm:text-right">
              <span className="text-[11px] font-bold text-neutral-500 uppercase tracking-wider block">
                Total Filtered Volume
              </span>
              <p className="text-xl font-mono font-black text-rose-600 mt-0.5">
                {formatAFN(totalExpenseAmount)}
              </p>
              <p className="text-[10px] text-neutral-400">
                {filteredExpenses.length} record{filteredExpenses.length !== 1 ? 's' : ''} ({invoiceLinkedCount} invoice-linked)
              </p>
            </div>
          </div>
        </div>

        {filteredExpenses.length === 0 ? (
          <div className="p-12 text-center text-xs text-neutral-500">
            <Receipt className="w-10 h-10 text-neutral-300 mx-auto mb-3" />
            <p className="font-bold text-sm text-neutral-700">No expenses found.</p>
            <p className="mt-1 text-neutral-400">Record a new business expense or adjust search.</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full border-collapse text-xs">
              <thead>
                <tr className="bg-neutral-900 text-white font-semibold text-left">
                  <th className="py-3 px-4 whitespace-nowrap">Date</th>
                  <th className="py-3 px-4">Title / Purpose</th>
                  <th className="py-3 px-4 whitespace-nowrap">Category</th>
                  <th className="py-3 px-4 whitespace-nowrap">Linked Invoice</th>
                  <th className="py-3 px-4 whitespace-nowrap">Requested By</th>
                  <th className="py-3 px-4 whitespace-nowrap">Workflow Status</th>
                  <th className="py-3 px-4 text-right whitespace-nowrap">Amount</th>
                  <th className="py-3 px-4 text-right whitespace-nowrap print:hidden">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-neutral-200">
                {filteredExpenses.map((e) => {
                  const status = e.status || 'pending_manager';

                  return (
                    <tr key={e.id} className="hover:bg-neutral-50 transition">
                      <td className="py-3 px-4 font-mono font-medium text-neutral-800 whitespace-nowrap">
                        {formatDate(e.date)}
                      </td>
                      <td className="py-3 px-4">
                        <p className="font-bold text-neutral-900 break-words max-w-xs">{e.title}</p>
                        {e.note && (
                          <p className="text-[11px] text-neutral-500 break-words max-w-xs mt-0.5">{e.note}</p>
                        )}
                      </td>
                      <td className="py-3 px-4 whitespace-nowrap">
                        <span className="px-2 py-0.5 rounded bg-neutral-100 text-neutral-700 font-medium text-[11px]">
                          {e.category || 'General'}
                        </span>
                      </td>
                      <td className="py-3 px-4 whitespace-nowrap">
                        {e.billNumber ? (
                          <span className="font-mono font-bold text-neutral-900 bg-orange-50 text-orange-700 border border-orange-200 px-2 py-0.5 rounded text-[11px] inline-flex items-center gap-1">
                            <FileText className="w-3 h-3 text-orange-500" />
                            #{e.billNumber}
                          </span>
                        ) : (
                          <span className="text-neutral-400 text-[11px] italic">General Ops</span>
                        )}
                      </td>
                      <td className="py-3 px-4 whitespace-nowrap text-neutral-700">
                        <div className="flex items-center gap-1.5">
                          <User className="w-3.5 h-3.5 text-neutral-400" />
                          <span>{e.requestedByName || 'Staff Member'}</span>
                        </div>
                      </td>
                      <td className="py-3 px-4 whitespace-nowrap">
                        <div className="flex items-center gap-1.5">
                          {renderStatusBadge(status)}
                          {e.timeline && e.timeline.length > 0 && (
                            <button
                              type="button"
                              onClick={() => setSelectedTimelineExpense(e)}
                              className="text-neutral-400 hover:text-neutral-700 p-0.5 rounded cursor-pointer"
                              title="View Audit Trail"
                            >
                              <History className="w-3.5 h-3.5" />
                            </button>
                          )}
                        </div>
                      </td>
                      <td className="py-3 px-4 text-right font-mono font-black text-rose-600 text-sm whitespace-nowrap">
                        -{formatAFN(e.amount)}
                      </td>
                      <td className="py-3 px-4 text-right whitespace-nowrap">
                        <div className="inline-flex items-center gap-1.5 justify-end">
                          {/* Stage 1: Pending Manager Review */}
                          {status === 'pending_manager' && (isInvoiceManager || isSuperAdmin) && (
                            <>
                              <button
                                type="button"
                                disabled={isProcessing}
                                onClick={() => handleQuickAdvance(e, 'manager_approve')}
                                className="px-2.5 py-1 text-xs font-semibold bg-blue-50 hover:bg-blue-100 text-blue-700 rounded border border-blue-200 transition cursor-pointer"
                                title="Approve as Invoice Manager"
                              >
                                Mgr Approve
                              </button>
                              <button
                                type="button"
                                onClick={() => {
                                  setActiveActionExpense(e);
                                  setActionType('reject');
                                  setActionReason('');
                                  setActionError(null);
                                }}
                                className="px-2 py-1 text-xs text-rose-600 hover:bg-rose-50 rounded transition cursor-pointer"
                              >
                                Reject
                              </button>
                            </>
                          )}

                          {/* Stage 2: Pending Admin Review */}
                          {status === 'pending_admin' && isSuperAdmin && (
                            <>
                              <button
                                type="button"
                                disabled={isProcessing}
                                onClick={() => handleQuickAdvance(e, 'admin_approve')}
                                className="px-2.5 py-1 text-xs font-semibold bg-purple-50 hover:bg-purple-100 text-purple-700 rounded border border-purple-200 transition cursor-pointer"
                                title="Approve as Super Admin"
                              >
                                Admin Approve
                              </button>
                              <button
                                type="button"
                                onClick={() => {
                                  setActiveActionExpense(e);
                                  setActionType('reject');
                                  setActionReason('');
                                  setActionError(null);
                                }}
                                className="px-2 py-1 text-xs text-rose-600 hover:bg-rose-50 rounded transition cursor-pointer"
                              >
                                Reject
                              </button>
                            </>
                          )}

                          {/* Stage 3: Approved / Ready for Payout */}
                          {status === 'approved' && isSuperAdmin && (
                            <button
                              type="button"
                              disabled={isProcessing}
                              onClick={() => handleQuickAdvance(e, 'admin_execute')}
                              className="px-2.5 py-1 text-xs font-bold bg-emerald-600 hover:bg-emerald-700 text-white rounded transition cursor-pointer shadow-xs"
                              title="Disburse Cash & Mark Executed"
                            >
                              Disburse &amp; Pay
                            </button>
                          )}

                          {/* Stage 4: Rejected - Only Original Requester can Edit & Resubmit */}
                          {status === 'rejected' && isOwnerOfExpense(e) && (
                            <button
                              type="button"
                              onClick={() => {
                                if (onEditExpense) {
                                  onEditExpense(e);
                                } else {
                                  setActiveActionExpense(e);
                                  setActionType('resubmit');
                                  setActionReason('');
                                  setActionCorrections('');
                                  setActionError(null);
                                }
                              }}
                              className="px-2.5 py-1 text-xs font-bold bg-amber-50 hover:bg-amber-100 text-amber-800 rounded border border-amber-300 transition cursor-pointer"
                              title="Edit and resubmit your rejected expense request"
                            >
                              Edit &amp; Resubmit
                            </button>
                          )}

                          {/* View details button */}
                          <button
                            type="button"
                            onClick={() => setSelectedTimelineExpense(e)}
                            className="px-2 py-1 text-xs text-neutral-600 hover:text-neutral-900 hover:bg-neutral-100 rounded transition font-medium cursor-pointer"
                          >
                            Details
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
              <tfoot>
                <tr className="bg-neutral-50 font-bold border-t-2 border-neutral-300">
                  <td colSpan={6} className="py-3 px-4 text-right text-neutral-700 uppercase text-[11px] tracking-wider">
                    Total Filtered Expenses ({filteredExpenses.length} records):
                  </td>
                  <td className="py-3 px-4 text-right font-mono font-black text-rose-600 text-sm whitespace-nowrap">
                    -{formatAFN(totalExpenseAmount)}
                  </td>
                  <td className="print:hidden" />
                </tr>
              </tfoot>
            </table>
          </div>
        )}
      </div>

      {/* Audit Timeline / Detail Modal */}
      {selectedTimelineExpense && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
          <div className="bg-white rounded-xl shadow-2xl w-full max-w-lg overflow-hidden border border-neutral-200">
            <div className="px-6 py-4 border-b border-neutral-200 bg-neutral-900 text-white flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Receipt className="w-5 h-5 text-orange-400" />
                <h3 className="font-bold text-sm">Expense Audit Trail</h3>
              </div>
              <button
                onClick={() => setSelectedTimelineExpense(null)}
                className="p-1 rounded-lg text-neutral-400 hover:text-white hover:bg-neutral-800 transition"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            <div className="p-6 space-y-4 text-xs">
              <div className="bg-neutral-50 p-3.5 rounded-lg border border-neutral-200 space-y-1.5">
                <div className="flex justify-between">
                  <span className="text-neutral-500">Title:</span>
                  <span className="font-bold text-neutral-900">{selectedTimelineExpense.title}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-neutral-500">Category:</span>
                  <span className="font-semibold text-neutral-800">{selectedTimelineExpense.category || 'General'}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-neutral-500">Amount:</span>
                  <span className="font-mono font-black text-rose-600 text-sm">
                    {formatAFN(selectedTimelineExpense.amount)}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-neutral-500">Current Status:</span>
                  <span>{renderStatusBadge(selectedTimelineExpense.status)}</span>
                </div>
                {selectedTimelineExpense.rejectionReason && (
                  <div className="p-2 bg-rose-50 border border-rose-200 text-rose-700 rounded mt-2">
                    <span className="font-bold block">Rejection Reason:</span>
                    <span>{selectedTimelineExpense.rejectionReason}</span>
                  </div>
                )}
              </div>

              <div>
                <h4 className="font-bold text-neutral-900 mb-2 flex items-center gap-1.5">
                  <History className="w-4 h-4 text-neutral-500" />
                  Audit Timeline
                </h4>
                <div className="space-y-3 border-l-2 border-neutral-200 pl-4 ml-2">
                  {selectedTimelineExpense.timeline && selectedTimelineExpense.timeline.length > 0 ? (
                    selectedTimelineExpense.timeline.map((step, idx) => (
                      <div key={idx} className="relative">
                        <div className="absolute -left-[21px] top-1 w-2.5 h-2.5 rounded-full bg-orange-600"></div>
                        <div className="flex items-center justify-between">
                          <span className="font-bold text-neutral-900">{step.action}</span>
                          <span className="text-neutral-400 font-mono text-[10px]">
                            {new Date(step.timestamp).toLocaleDateString()}
                          </span>
                        </div>
                        <p className="text-neutral-600 text-[11px]">
                          By {step.performedByName} ({step.performedByRole})
                        </p>
                        {step.note && (
                          <p className="text-neutral-500 text-[10px] italic mt-0.5 bg-neutral-50 p-1 rounded">
                            "{step.note}"
                          </p>
                        )}
                      </div>
                    ))
                  ) : (
                    <p className="text-neutral-400 italic">No timeline entries recorded yet.</p>
                  )}
                </div>
              </div>

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-neutral-200">
                {selectedTimelineExpense.status === 'rejected' && isOwnerOfExpense(selectedTimelineExpense) && (
                  <button
                    type="button"
                    onClick={() => {
                      const exp = selectedTimelineExpense;
                      setSelectedTimelineExpense(null);
                      if (onEditExpense) {
                        onEditExpense(exp);
                      }
                    }}
                    className="px-4 py-2 text-xs font-bold bg-amber-600 text-white rounded-lg hover:bg-amber-700 transition cursor-pointer"
                  >
                    Edit &amp; Resubmit
                  </button>
                )}
                <button
                  type="button"
                  onClick={() => setSelectedTimelineExpense(null)}
                  className="px-4 py-2 text-xs font-semibold bg-neutral-900 text-white rounded-lg hover:bg-black transition cursor-pointer"
                >
                  Close
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Action Dialog (Reject or Resubmit with Reason) */}
      {activeActionExpense && actionType && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
          <div className="bg-white rounded-xl shadow-2xl w-full max-w-md overflow-hidden border border-neutral-200">
            <div
              className={`px-5 py-4 border-b border-neutral-200 text-white flex items-center gap-2.5 ${
                actionType === 'reject' ? 'bg-rose-950' : 'bg-neutral-900'
              }`}
            >
              {actionType === 'reject' ? (
                <XCircle className="w-5 h-5 text-rose-400" />
              ) : (
                <Send className="w-5 h-5 text-orange-400" />
              )}
              <div>
                <h3 className="text-sm font-bold">
                  {actionType === 'reject' ? 'Reject Business Expense' : 'Resubmit Expense with Corrections'}
                </h3>
                <p className="text-[11px] text-neutral-300">
                  {activeActionExpense.title} ({formatAFN(activeActionExpense.amount)})
                </p>
              </div>
            </div>

            <div className="p-5 space-y-3 text-xs">
              {actionError && (
                <div className="p-2 bg-rose-50 border border-rose-200 text-rose-700 rounded-lg">
                  {actionError}
                </div>
              )}

              <div>
                <label className="font-semibold text-neutral-700 block mb-1">
                  {actionType === 'reject' ? 'Reason for Rejection *' : 'Resubmission Justification / Note *'}
                </label>
                <textarea
                  rows={3}
                  required
                  value={actionReason}
                  onChange={(e) => setActionReason(e.target.value)}
                  placeholder={
                    actionType === 'reject'
                      ? 'e.g. Missing supplier receipt, budget exceeded, unauthorized purchase...'
                      : 'e.g. Attached verified vendor invoice and adjusted tax breakdown...'
                  }
                  className="w-full text-xs border border-neutral-300 rounded-lg p-2.5 focus:outline-none focus:ring-1 focus:ring-orange-500"
                />
              </div>

              {actionType === 'resubmit' && (
                <div>
                  <label className="font-semibold text-neutral-700 block mb-1">
                    Corrections Made (Optional)
                  </label>
                  <input
                    type="text"
                    value={actionCorrections}
                    onChange={(e) => setActionCorrections(e.target.value)}
                    placeholder="e.g. Clarified model numbers and discounted pricing"
                    className="w-full text-xs border border-neutral-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-1 focus:ring-orange-500"
                  />
                </div>
              )}

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-neutral-200">
                <button
                  type="button"
                  onClick={() => {
                    setActiveActionExpense(null);
                    setActionType(null);
                  }}
                  className="px-3.5 py-1.5 font-medium text-neutral-600 hover:bg-neutral-100 rounded-lg"
                >
                  Cancel
                </button>
                <button
                  type="button"
                  disabled={isProcessing}
                  onClick={handleConfirmActionWithReason}
                  className={`px-4 py-1.5 font-bold text-white rounded-lg transition disabled:opacity-50 inline-flex items-center gap-1.5 ${
                    actionType === 'reject' ? 'bg-rose-600 hover:bg-rose-700' : 'bg-neutral-900 hover:bg-black'
                  }`}
                >
                  {isProcessing
                    ? 'Submitting...'
                    : actionType === 'reject'
                    ? 'Confirm Rejection'
                    : 'Submit for Review'}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
