import React, { useState } from 'react';
import { Customer, Invoice, Payment, CustomerRequest, BusinessSettings, Project, AppNotification } from '../types';
import { useAuth } from '../context/AuthContext';
import { createCustomerRequest } from '../services/db';
import { formatAFN, calculateTotalPaidForInvoice, calculateRemaining, formatDate } from '../utils/format';
import { toast } from '../context/ToastContext';
import {
  FileText,
  DollarSign,
  MessageSquare,
  Sparkles,
  Download,
  Plus,
  Clock,
  CheckCircle2,
  AlertCircle,
  Phone,
  Shield,
  Send,
  X,
  UserCheck,
  ChevronRight,
  LogOut,
  Receipt,
  LayoutDashboard,
  Bell,
  XCircle,
  Ban,
} from 'lucide-react';
import { PaymentReceiptModal } from '../components/payment/PaymentReceiptModal';
import { CustomerDashboard } from '../components/dashboard/CustomerDashboard';
import { getCustomerDashboardData } from '../services/dashboardAuthorization';
import { normalizeCustomerStatus } from '../utils/customerValidation';

interface CustomerPortalViewProps {
  customer: Customer;
  invoices: Invoice[];
  payments: Payment[];
  requests: CustomerRequest[];
  projects: Project[];
  settings: BusinessSettings;
  onSelectInvoice: (invoice: Invoice) => void;
  onSwitchToStaffPortal?: () => void;
  notifications?: AppNotification[];
  onMarkNotificationRead?: (id: string) => void;
}

export const CustomerPortalView: React.FC<CustomerPortalViewProps> = ({
  customer,
  invoices,
  payments,
  requests,
  projects,
  settings,
  onSelectInvoice,
  onSwitchToStaffPortal,
  notifications = [],
  onMarkNotificationRead,
}) => {
  const { signOutUser, userProfile } = useAuth();

  const currentStatus = normalizeCustomerStatus(customer.status, customer.isArchived);
  if (currentStatus === 'Inactive' || currentStatus === 'Blocked') {
    return (
      <div className="min-h-screen bg-neutral-100 flex flex-col items-center justify-center p-4">
        <div className="max-w-md w-full bg-white rounded-2xl shadow-lg border border-neutral-200 p-8 text-center space-y-4">
          <div className="w-14 h-14 mx-auto rounded-full bg-rose-50 border border-rose-200 flex items-center justify-center">
            <Ban className="w-7 h-7 text-rose-600" />
          </div>
          <h2 className="text-lg font-bold text-neutral-900">Portal Access Disabled</h2>
          <p className="text-xs text-neutral-600 leading-relaxed">
            Your customer portal account for <strong>{customer.name}</strong> is currently {currentStatus.toLowerCase()}.
            Self-service portal access has been disabled. Please contact Sarwan Technology support at{' '}
            <span className="font-mono font-bold text-neutral-800">{settings.phone}</span>.
          </p>
          <button
            onClick={() => signOutUser()}
            className="w-full py-2.5 px-4 bg-neutral-100 hover:bg-neutral-200 active:bg-neutral-300 text-neutral-800 border border-neutral-300 rounded-xl text-xs font-bold transition shadow-2xs cursor-pointer active:scale-[0.98] focus:outline-none focus-visible:ring-2 focus-visible:ring-neutral-400"
          >
            Sign Out
          </button>
        </div>
      </div>
    );
  }
  const [activeTab, setActiveTab] = useState<'dashboard' | 'invoices' | 'payments' | 'requests' | 'showcase'>(
    'dashboard'
  );
  const [isNotifOpen, setIsNotifOpen] = useState<boolean>(false);
  const [selectedReceiptPayment, setSelectedReceiptPayment] = useState<Payment | null>(null);
  const [isRequestModalOpen, setIsRequestModalOpen] = useState<boolean>(false);
  const [requestTitle, setRequestTitle] = useState<string>('');
  const [requestType, setRequestType] = useState<string>('CCTV Installation');
  const [requestDesc, setRequestDesc] = useState<string>('');
  const [submittingReq, setSubmittingReq] = useState<boolean>(false);

  // Filter invoices for this specific customer
  const myInvoices = invoices.filter(
    (inv) =>
      inv.customerId === customer.id ||
      inv.customerSnapshot?.phone === customer.phone ||
      inv.customerSnapshot?.name?.toLowerCase() === customer.name.toLowerCase()
  );

  // Filter payments for this specific customer
  const myPayments = payments.filter(
    (p) =>
      p.customerId === customer.id ||
      p.customerName?.toLowerCase() === customer.name.toLowerCase()
  );

  // Filter requests for this specific customer
  const myRequests = requests.filter(
    (r) =>
      r.customerId === customer.id ||
      r.customerPhone === customer.phone ||
      r.customerName?.toLowerCase() === customer.name.toLowerCase()
  );

  // Compute customer financials
  const totalBilled = myInvoices.reduce((acc, inv) => acc + (Number(inv.totalAmount) || 0), 0);
  const totalPaid = myPayments.reduce((acc, p) => acc + (p.isVoid ? 0 : Number(p.amount) || 0), 0);
  const totalRemaining = Math.max(0, totalBilled - totalPaid);

  const handleCreateRequest = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!requestTitle.trim() || !requestDesc.trim()) return;

    setSubmittingReq(true);
    try {
      await createCustomerRequest({
        customerId: customer.id,
        customerName: customer.name,
        customerPhone: customer.phone,
        customerEmail: customer.email,
        title: `[${requestType}] ${requestTitle.trim()}`,
        description: requestDesc.trim(),
        mediaType: 'text',
        attachments: [],
      });
      setRequestTitle('');
      setRequestDesc('');
      setIsRequestModalOpen(false);
      setActiveTab('requests');
      toast.success('Your service request has been received! Our technician will respond shortly.');
    } catch (err) {
      console.error(err);
      toast.error('Could not submit request. Please try again.');
    } finally {
      setSubmittingReq(false);
    }
  };

  return (
    <div className="min-h-screen bg-neutral-100 text-neutral-900">
      {/* Customer Header */}
      <header className="sticky top-0 z-30 bg-neutral-950 text-white border-b border-neutral-800 px-4 sm:px-6 py-3 shadow-md">
        <div className="max-w-6xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div
              className="w-10 h-10 bg-white shrink-0 flex items-center justify-center overflow-hidden p-1 shadow-xs"
              style={{ borderRadius: '100%', border: 'none' }}
            >
              <img
                src={settings.logo || '/sarwan-logo.png'}
                alt="Sarwan Technology"
                className="max-h-full max-w-full object-contain"
                onError={(e) => {
                  e.currentTarget.src = '/sarwan-logo.svg';
                }}
              />
            </div>
            <div>
              <h1 className="text-sm font-bold text-white tracking-wide">
                SARWAN TECHNOLOGY
              </h1>
              <p className="text-[10px] text-orange-400 font-semibold uppercase tracking-wider">
                Customer Care &amp; Billing Portal
              </p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            {/* Notifications Bell */}
            <div className="relative">
              <button
                type="button"
                onClick={() => setIsNotifOpen(!isNotifOpen)}
                className="p-1.5 rounded-lg text-neutral-400 hover:text-white hover:bg-neutral-800 transition relative cursor-pointer"
                aria-label="Notifications"
              >
                <Bell className="w-4 h-4" />
                {notifications.filter((n) => !n.isRead).length > 0 && (
                  <span className="absolute top-0.5 right-0.5 w-4 h-4 bg-orange-500 text-white rounded-full text-[9px] font-bold flex items-center justify-center">
                    {notifications.filter((n) => !n.isRead).length > 9 ? '9+' : notifications.filter((n) => !n.isRead).length}
                  </span>
                )}
              </button>

              {isNotifOpen && (
                <>
                  <div
                    className="fixed inset-0 z-40"
                    onClick={() => setIsNotifOpen(false)}
                  />
                  <div className="absolute right-0 mt-2 w-80 sm:w-96 bg-white text-neutral-900 rounded-xl shadow-xl border border-neutral-200 z-50 overflow-hidden text-xs">
                    <div className="p-3 border-b border-neutral-100 bg-neutral-50 flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-neutral-900">Your Notifications</span>
                        {notifications.filter((n) => !n.isRead).length > 0 && (
                          <span className="px-1.5 py-0.5 bg-orange-100 text-orange-700 rounded-full text-[10px] font-bold">
                            {notifications.filter((n) => !n.isRead).length} new
                          </span>
                        )}
                      </div>
                      {notifications.filter((n) => !n.isRead).length > 0 && onMarkNotificationRead && (
                        <button
                          type="button"
                          onClick={() => {
                            notifications
                              .filter((n) => !n.isRead)
                              .forEach((n) => onMarkNotificationRead(n.id));
                          }}
                          className="text-[11px] text-orange-600 hover:text-orange-700 font-semibold cursor-pointer"
                        >
                          Mark all read
                        </button>
                      )}
                    </div>

                    <div className="max-h-80 overflow-y-auto divide-y divide-neutral-100">
                      {notifications.length === 0 ? (
                        <div className="p-6 text-center text-neutral-400">
                          <Bell className="w-8 h-8 mx-auto mb-2 text-neutral-300" />
                          <p>No notifications yet</p>
                        </div>
                      ) : (
                        notifications.map((notif) => (
                          <div
                            key={notif.id}
                            onClick={() => {
                              if (!notif.isRead && onMarkNotificationRead) {
                                onMarkNotificationRead(notif.id);
                              }
                              if (notif.type === 'invoice') setActiveTab('invoices');
                              if (notif.type === 'payment') setActiveTab('payments');
                              if (notif.type === 'request') setActiveTab('requests');
                              if (notif.type === 'project') setActiveTab('showcase');
                              setIsNotifOpen(false);
                            }}
                            className={`p-3 hover:bg-neutral-50 transition cursor-pointer flex gap-2.5 ${
                              !notif.isRead ? 'bg-orange-50/40' : ''
                            }`}
                          >
                            <div
                              className={`w-2 h-2 rounded-full mt-1.5 shrink-0 ${
                                !notif.isRead ? 'bg-orange-500' : 'bg-transparent'
                              }`}
                            />
                            <div className="flex-1 overflow-hidden">
                              <p className="font-bold text-neutral-900 truncate">{notif.title}</p>
                              <p className="text-neutral-600 line-clamp-2 mt-0.5">{notif.message}</p>
                              <span className="text-[10px] text-neutral-400 mt-1 block">
                                {formatDate(notif.createdAt)}
                              </span>
                            </div>
                          </div>
                        ))
                      )}
                    </div>
                  </div>
                </>
              )}
            </div>

            {/* Staff Portal switch only accessible if Super Admin */}
            {onSwitchToStaffPortal && userProfile?.role === 'super_admin' && (
              <button
                onClick={onSwitchToStaffPortal}
                className="text-xs px-2.5 py-1.5 bg-neutral-800 hover:bg-neutral-700 text-neutral-200 rounded-lg transition border border-neutral-700 cursor-pointer"
                title="Return to Business Management Console"
              >
                Staff Portal
              </button>
            )}

            <button
              onClick={signOutUser}
              className="p-1.5 text-neutral-400 hover:text-white hover:bg-neutral-800 rounded-lg transition"
              title="Sign Out"
            >
              <LogOut className="w-4 h-4" />
            </button>
          </div>
        </div>
      </header>

      {/* Main Content Container */}
      <main className="max-w-6xl mx-auto p-4 sm:p-6 space-y-6">
        {/* Customer Welcome & Financial Banner */}
        <div className="bg-white rounded-2xl p-6 border border-neutral-200 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="flex items-start gap-4">
            <div className="w-14 h-14 rounded-2xl bg-orange-100 text-orange-700 font-extrabold text-xl flex items-center justify-center shrink-0 border border-orange-200">
              {customer.name.charAt(0)}
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-xl font-bold text-neutral-900">{customer.name}</h2>
                <span className="text-[10px] font-bold px-2 py-0.5 bg-emerald-50 text-emerald-700 border border-emerald-200 rounded-full flex items-center gap-1">
                  <UserCheck className="w-3 h-3" />
                  Verified Account
                </span>
              </div>
              <p className="text-xs text-neutral-500 mt-1 flex flex-wrap items-center gap-3">
                <span className="flex items-center gap-1">
                  <Phone className="w-3 h-3 text-neutral-400" />
                  {customer.phone}
                </span>
                {customer.address && <span>&bull; {customer.address}</span>}
                {customer.companyName && <span>&bull; {customer.companyName}</span>}
              </p>
            </div>
          </div>

          {/* Balance Cards */}
          <div className="flex items-center gap-3">
            <div className="p-3.5 bg-neutral-50 rounded-xl border border-neutral-200 text-center min-w-[110px]">
              <p className="text-[10px] text-neutral-500 font-semibold uppercase">Total Invoiced</p>
              <p className="text-sm font-bold text-neutral-900 mt-0.5">{formatAFN(totalBilled)}</p>
            </div>
            <div className="p-3.5 bg-emerald-50 rounded-xl border border-emerald-200 text-center min-w-[110px]">
              <p className="text-[10px] text-emerald-700 font-semibold uppercase">Paid (Cash)</p>
              <p className="text-sm font-bold text-emerald-700 mt-0.5">{formatAFN(totalPaid)}</p>
            </div>
            <div className="p-3.5 bg-orange-50 rounded-xl border border-orange-200 text-center min-w-[110px]">
              <p className="text-[10px] text-orange-700 font-semibold uppercase">Remaining Due</p>
              <p className="text-sm font-bold text-orange-700 mt-0.5">{formatAFN(totalRemaining)}</p>
            </div>
          </div>
        </div>

        {/* Tab Navigation */}
        <div className="flex flex-wrap items-center justify-between gap-3 border-b border-neutral-200 pb-2">
          <div className="flex flex-wrap gap-2">
            <button
              onClick={() => setActiveTab('dashboard')}
              className={`text-xs font-bold px-4 py-2 rounded-lg transition flex items-center gap-2 cursor-pointer ${
                activeTab === 'dashboard'
                  ? 'bg-neutral-900 text-white shadow-xs'
                  : 'bg-white text-neutral-600 hover:bg-neutral-200 border border-neutral-200'
              }`}
            >
              <LayoutDashboard className="w-4 h-4" />
              <span>Dashboard</span>
            </button>

            <button
              onClick={() => setActiveTab('invoices')}
              className={`text-xs font-bold px-4 py-2 rounded-lg transition flex items-center gap-2 cursor-pointer ${
                activeTab === 'invoices'
                  ? 'bg-neutral-900 text-white shadow-xs'
                  : 'bg-white text-neutral-600 hover:bg-neutral-200 border border-neutral-200'
              }`}
            >
              <FileText className="w-4 h-4" />
              <span>My Invoices ({myInvoices.length})</span>
            </button>

            <button
              onClick={() => setActiveTab('payments')}
              className={`text-xs font-bold px-4 py-2 rounded-lg transition flex items-center gap-2 cursor-pointer ${
                activeTab === 'payments'
                  ? 'bg-neutral-900 text-white shadow-xs'
                  : 'bg-white text-neutral-600 hover:bg-neutral-200 border border-neutral-200'
              }`}
            >
              <DollarSign className="w-4 h-4" />
              <span>Payments &amp; Receipts ({myPayments.length})</span>
            </button>

            <button
              onClick={() => setActiveTab('requests')}
              className={`text-xs font-bold px-4 py-2 rounded-lg transition flex items-center gap-2 cursor-pointer ${
                activeTab === 'requests'
                  ? 'bg-neutral-900 text-white shadow-xs'
                  : 'bg-white text-neutral-600 hover:bg-neutral-200 border border-neutral-200'
              }`}
            >
              <MessageSquare className="w-4 h-4" />
              <span>Service Requests ({myRequests.length})</span>
            </button>

            <button
              onClick={() => setActiveTab('showcase')}
              className={`text-xs font-bold px-4 py-2 rounded-lg transition flex items-center gap-2 cursor-pointer ${
                activeTab === 'showcase'
                  ? 'bg-neutral-900 text-white shadow-xs'
                  : 'bg-white text-neutral-600 hover:bg-neutral-200 border border-neutral-200'
              }`}
            >
              <Sparkles className="w-4 h-4 text-orange-500" />
              <span>Dahua Security Portfolio</span>
            </button>
          </div>

          <button
            onClick={() => setIsRequestModalOpen(true)}
            className="px-3.5 py-2 bg-[#2563EB] hover:bg-[#1D4ED8] active:bg-[#1E40AF] text-white text-xs font-bold rounded-lg shadow-xs transition flex items-center gap-1.5 cursor-pointer active:scale-98 focus:outline-none focus-visible:ring-2 focus-visible:ring-[#2563EB]"
          >
            <Plus className="w-4 h-4" />
            <span>New Service / Quotation Request</span>
          </button>
        </div>

        {/* Tab 0: Customer Role-Specific Dashboard */}
        {activeTab === 'dashboard' && (
          <CustomerDashboard
            data={getCustomerDashboardData(
              userProfile || {
                id: customer.id,
                name: customer.name,
                email: customer.email || '',
                phone: customer.phone,
                role: 'customer',
                status: 'active',
              },
              customer,
              invoices,
              payments,
              requests,
              projects,
              []
            )}
            settings={settings}
            onSelectInvoice={onSelectInvoice}
            onNewRequest={() => setIsRequestModalOpen(true)}
            onRequestProject={(proj) => {
              setRequestType(proj.category || 'CCTV Installation');
              setRequestTitle(`Inquiry: ${proj.title}`);
              setRequestDesc(`I am interested in ${proj.title}. Please provide quotation and installation details.`);
              setIsRequestModalOpen(true);
            }}
            payments={payments}
          />
        )}

        {/* Tab 1: My Invoices */}
        {activeTab === 'invoices' && (
          <div className="space-y-4">
            {myInvoices.length === 0 ? (
              <div className="bg-white rounded-xl p-12 text-center border border-neutral-200 text-neutral-400">
                <FileText className="w-10 h-10 mx-auto mb-2 opacity-40" />
                <p className="text-sm font-semibold text-neutral-700">No invoices on file</p>
                <p className="text-xs text-neutral-500 mt-0.5">
                  You do not have any bills yet. Request a quotation or equipment order below.
                </p>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {myInvoices.map((inv) => {
                  const invPaid = calculateTotalPaidForInvoice(inv.id, payments);
                  const invRemaining = calculateRemaining(inv.totalAmount, invPaid);
                  return (
                    <div
                      key={inv.id}
                      className="bg-white rounded-xl border border-neutral-200 shadow-xs p-5 hover:shadow-md transition flex flex-col justify-between"
                    >
                      <div>
                        <div className="flex items-center justify-between mb-3">
                          <div className="flex items-center gap-2">
                            <span className="font-mono font-bold text-sm text-neutral-900">
                              {inv.billNumber}
                            </span>
                            <span
                              className={`text-[10px] font-bold px-2 py-0.5 rounded-full border ${
                                inv.status === 'Paid'
                                  ? 'bg-emerald-50 text-emerald-700 border-emerald-200'
                                  : inv.status === 'Partially Paid'
                                  ? 'bg-amber-50 text-amber-700 border-amber-200'
                                  : 'bg-red-50 text-red-700 border-red-200'
                              }`}
                            >
                              {inv.status}
                            </span>
                          </div>
                          <span className="text-xs text-neutral-400 font-mono">{inv.date}</span>
                        </div>

                        {/* Items preview */}
                        <div className="py-2 text-xs text-neutral-600 border-y border-neutral-100 my-2 space-y-1">
                          {inv.items.filter((i) => i.description).slice(0, 3).map((item, idx) => (
                            <div key={idx} className="flex justify-between">
                              <span className="truncate max-w-[200px]">{item.description}</span>
                              <span className="font-mono">{formatAFN(item.totalAmount)}</span>
                            </div>
                          ))}
                          {inv.items.filter((i) => i.description).length > 3 && (
                            <p className="text-[11px] text-neutral-400 italic">
                              + {inv.items.filter((i) => i.description).length - 3} more items...
                            </p>
                          )}
                        </div>

                        {/* Financial balance breakdown */}
                        <div className="grid grid-cols-3 gap-2 text-center text-xs py-2 bg-neutral-50 rounded-lg">
                          <div>
                            <p className="text-[10px] text-neutral-400">Total</p>
                            <p className="font-bold text-neutral-900">{formatAFN(inv.totalAmount)}</p>
                          </div>
                          <div>
                            <p className="text-[10px] text-emerald-600">Paid</p>
                            <p className="font-bold text-emerald-700">{formatAFN(invPaid)}</p>
                          </div>
                          <div>
                            <p className="text-[10px] text-orange-600">Remaining</p>
                            <p className="font-bold text-orange-700">{formatAFN(invRemaining)}</p>
                          </div>
                        </div>
                      </div>

                      {/* Action: Open official A4 view */}
                      <button
                        onClick={() => onSelectInvoice(inv)}
                        className="mt-4 w-full py-2 bg-[#2563EB] hover:bg-[#1D4ED8] active:bg-[#1E40AF] text-white text-xs font-bold rounded-lg shadow-xs transition flex items-center justify-center gap-1.5 cursor-pointer active:scale-[0.98] focus:outline-none focus-visible:ring-2 focus-visible:ring-[#2563EB]"
                      >
                        <FileText className="w-3.5 h-3.5" />
                        <span>View / Export Official A4 Invoice</span>
                      </button>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        )}

        {/* Tab 2: Payments & Receipts */}
        {activeTab === 'payments' && (
          <div className="bg-white rounded-xl border border-neutral-200 shadow-xs overflow-hidden">
            <table className="w-full text-left text-xs">
              <thead className="bg-neutral-50 text-neutral-500 border-b border-neutral-200 uppercase font-semibold">
                <tr>
                  <th className="px-4 py-3">Date</th>
                  <th className="px-4 py-3">Bill No.</th>
                  <th className="px-4 py-3">Method</th>
                  <th className="px-4 py-3">Note</th>
                  <th className="px-4 py-3 text-right">Amount Paid</th>
                  <th className="px-4 py-3 text-right">Receipt</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-neutral-100">
                {myPayments.length === 0 ? (
                  <tr>
                    <td colSpan={6} className="px-4 py-10 text-center text-neutral-400">
                      No cash payments recorded for this account.
                    </td>
                  </tr>
                ) : (
                  myPayments.map((p) => (
                    <tr key={p.id} className="hover:bg-neutral-50/70 transition">
                      <td className="px-4 py-3 font-mono text-neutral-600">{p.date}</td>
                      <td className="px-4 py-3 font-mono font-bold text-neutral-900">
                        {p.billNumber}
                      </td>
                      <td className="px-4 py-3 font-bold text-neutral-700">CASH ONLY</td>
                      <td className="px-4 py-3 text-neutral-500">{p.note || 'Cash payment received'}</td>
                      <td className="px-4 py-3 font-mono font-bold text-emerald-700 text-right">
                        {formatAFN(p.amount)}
                      </td>
                      <td className="px-4 py-3 text-right">
                        <button
                          type="button"
                          onClick={() => setSelectedReceiptPayment(p)}
                          className="px-2.5 py-1 text-[11px] font-semibold bg-neutral-100 hover:bg-neutral-200 text-neutral-800 rounded border border-neutral-300 transition inline-flex items-center gap-1 cursor-pointer"
                        >
                          <Receipt className="w-3 h-3 text-orange-600" />
                          <span>Receipt</span>
                        </button>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        )}

        {/* Tab 3: Customer Service Requests */}
        {activeTab === 'requests' && (
          <div className="space-y-4">
            {myRequests.length === 0 ? (
              <div className="bg-white rounded-xl p-12 text-center border border-neutral-200 text-neutral-400">
                <MessageSquare className="w-10 h-10 mx-auto mb-2 opacity-40" />
                <p className="text-sm font-semibold text-neutral-700">No active service requests</p>
                <p className="text-xs text-neutral-500 mt-0.5">
                  Need a CCTV installation, camera repair, or equipment quotation? Click below.
                </p>
                <button
                  onClick={() => setIsRequestModalOpen(true)}
                  className="mt-4 px-4 py-2 bg-[#2563EB] hover:bg-[#1D4ED8] active:bg-[#1E40AF] text-white text-xs font-bold rounded-lg shadow-xs transition cursor-pointer focus:outline-none focus-visible:ring-2 focus-visible:ring-[#2563EB]"
                >
                  Submit Service Request
                </button>
              </div>
            ) : (
              myRequests.map((req) => (
                <div
                  key={req.id}
                  className="bg-white rounded-xl border border-neutral-200 shadow-xs p-5 space-y-3"
                >
                  <div className="flex items-center justify-between">
                    <div>
                      <span className="text-[10px] font-bold px-2 py-0.5 rounded-full border bg-orange-50 text-orange-700 border-orange-200 mr-2">
                        {req.status}
                      </span>
                      <span className="text-xs text-neutral-500 font-medium">
                        {req.type} &bull; {new Date(req.createdAt).toLocaleDateString()}
                      </span>
                      <h3 className="text-sm font-bold text-neutral-900 mt-1">{req.title}</h3>
                    </div>
                  </div>

                  <p className="text-xs text-neutral-700 bg-neutral-50 p-3 rounded-lg border border-neutral-200 leading-relaxed whitespace-pre-line">
                    {req.description}
                  </p>

                  {/* Staff replies */}
                  {req.replies && req.replies.length > 0 && (
                    <div className="pt-2 border-t border-neutral-100 space-y-2">
                      <p className="text-[11px] font-bold text-neutral-700 uppercase">
                        Technician Updates ({req.replies.length}):
                      </p>
                      {req.replies.map((rep) => (
                        <div
                          key={rep.id}
                          className="p-3 bg-neutral-900 text-white rounded-lg text-xs space-y-1"
                        >
                          <div className="flex justify-between text-[10px] text-neutral-400">
                            <span className="font-bold text-orange-400">{rep.authorName}</span>
                            <span>{new Date(rep.createdAt).toLocaleTimeString()}</span>
                          </div>
                          <p className="leading-relaxed">{rep.message}</p>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              ))
            )}
          </div>
        )}

        {/* Tab 4: Dahua Portfolio Showcase */}
        {activeTab === 'showcase' && (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {projects.map((proj) => (
              <div
                key={proj.id}
                className="bg-white rounded-xl border border-neutral-200 shadow-xs overflow-hidden flex flex-col"
              >
                <div className="aspect-video bg-neutral-900 relative">
                  <img
                    src={proj.images?.[0] || 'https://images.unsplash.com/photo-1557597774-9d273605dfa9?w=800&q=80'}
                    alt={proj.title}
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute top-2.5 left-2.5 bg-black/70 text-white text-[10px] font-bold px-2 py-0.5 rounded">
                    {proj.category}
                  </div>
                </div>
                <div className="p-4 flex-1 flex flex-col justify-between">
                  <div>
                    <h4 className="text-xs font-bold text-neutral-900 line-clamp-2">{proj.title}</h4>
                    <p className="text-[11px] text-neutral-600 mt-1 line-clamp-3 leading-relaxed">
                      {proj.description}
                    </p>
                  </div>
                  <button
                    onClick={() => {
                      setRequestTitle(`Inquiry for: ${proj.title}`);
                      setRequestDesc(`I would like to inquire about installing this security system: ${proj.title}\nCategory: ${proj.category}`);
                      setIsRequestModalOpen(true);
                    }}
                    className="mt-4 w-full py-2 bg-orange-50 hover:bg-orange-100 text-orange-700 border border-orange-200 text-xs font-bold rounded-lg transition"
                  >
                    Request System Like This
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </main>

      {/* New Request Modal */}
      {isRequestModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
          <div className="bg-white rounded-xl shadow-2xl w-full max-w-lg overflow-hidden border border-neutral-200">
            <div className="flex items-center justify-between px-6 py-4 border-b border-neutral-200 bg-neutral-900 text-white">
              <h2 className="text-sm font-bold">Submit Service / Equipment Request</h2>
              <button
                onClick={() => setIsRequestModalOpen(false)}
                className="p-1 rounded-lg text-neutral-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCreateRequest} className="p-6 space-y-4">
              <div>
                <label className="block text-xs font-semibold text-neutral-700 mb-1">
                  Request Subject *
                </label>
                <input
                  type="text"
                  required
                  value={requestTitle}
                  onChange={(e) => setRequestTitle(e.target.value)}
                  placeholder="e.g. Quotation for 8x 4K Dahua CCTV cameras"
                  className="w-full text-xs p-2.5 bg-neutral-50 border border-neutral-300 rounded-lg focus:outline-none focus:bg-white focus:ring-1 focus:ring-orange-500"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-neutral-700 mb-1">
                  Service Category
                </label>
                <select
                  value={requestType}
                  onChange={(e) => setRequestType(e.target.value)}
                  className="w-full text-xs p-2.5 bg-neutral-50 border border-neutral-300 rounded-lg focus:outline-none"
                >
                  <option value="CCTV Installation">CCTV Installation</option>
                  <option value="Camera Repair">Camera Repair</option>
                  <option value="Maintenance">Maintenance &amp; Inspection</option>
                  <option value="Quotation">Equipment Quotation</option>
                  <option value="Equipment Purchase">Equipment Purchase</option>
                  <option value="Other">Other Inquiry</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-neutral-700 mb-1">
                  Detailed Requirements *
                </label>
                <textarea
                  rows={4}
                  required
                  value={requestDesc}
                  onChange={(e) => setRequestDesc(e.target.value)}
                  placeholder="Specify location, number of cameras, DVR/NVR storage, wiring needs, or problem description..."
                  className="w-full text-xs p-2.5 bg-neutral-50 border border-neutral-300 rounded-lg focus:outline-none focus:bg-white focus:ring-1 focus:ring-orange-500"
                />
              </div>

              <div className="pt-3 flex justify-end gap-2 border-t border-neutral-200">
                <button
                  type="button"
                  onClick={() => setIsRequestModalOpen(false)}
                  className="px-4 py-2 text-xs font-semibold text-neutral-600 hover:bg-neutral-100 rounded-lg transition"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={submittingReq}
                  className="px-5 py-2 bg-[#2563EB] hover:bg-[#1D4ED8] active:bg-[#1E40AF] text-white text-xs font-bold rounded-lg shadow-xs transition disabled:opacity-50 cursor-pointer focus:outline-none focus-visible:ring-2 focus-visible:ring-[#2563EB]"
                >
                  {submittingReq ? 'Submitting...' : 'Send Request'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Official Payment Receipt Modal */}
      {selectedReceiptPayment && (
        <PaymentReceiptModal
          isOpen={!!selectedReceiptPayment}
          onClose={() => setSelectedReceiptPayment(null)}
          payment={selectedReceiptPayment}
          invoice={invoices.find((inv) => inv.id === selectedReceiptPayment.invoiceId) || null}
          settings={settings}
        />
      )}
    </div>
  );
};
