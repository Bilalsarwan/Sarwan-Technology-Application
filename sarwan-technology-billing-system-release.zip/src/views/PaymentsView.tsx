import React, { useState, useMemo, useEffect, useRef } from 'react';
import { Payment, Invoice, BusinessSettings, UserProfile, PAYMENT_METHOD_LABELS } from '../types';
import { formatAFN, formatDate, getTodayDateString } from '../utils/format';
import { isValidPayment, isValidInvoice, getValidPaymentsPerInvoice } from '../utils/invoiceCalculator';
import {
  Search,
  DollarSign,
  Plus,
  FileText,
  CheckCircle2,
  Receipt,
  AlertTriangle,
  X,
  Filter,
  ChevronDown,
  ChevronUp,
  SlidersHorizontal,
  ArrowUpDown,
  ArrowUp,
  ArrowDown,
  ChevronLeft,
  ChevronRight,
  ArrowRight,
} from 'lucide-react';
import { PaymentDetailModal } from '../components/payment/PaymentDetailModal';
import { PaymentReceiptModal } from '../components/payment/PaymentReceiptModal';
import { useAuth } from '../context/AuthContext';
import { correctPayment } from '../services/db';
import { checkPaymentReversalEligibility } from '../utils/paymentValidation';

export type FinancialCardFilter = 'total_collected' | 'today' | 'this_month' | 'outstanding' | null;

export type PaymentDatePreset =
  | 'all'
  | 'today'
  | 'yesterday'
  | 'this_week'
  | 'this_month'
  | 'last_month'
  | 'custom';

export type PaymentStatusFilter = 'all' | 'completed' | 'reversed';

export type PaymentSortField = 'date' | 'amount' | 'id' | 'customer' | 'invoice';
export type PaymentSortDirection = 'asc' | 'desc';

/**
 * Format payment time safely from payment.time or payment.createdAt
 */
export const formatPaymentTime = (p: Payment): string | null => {
  if (p.time) return p.time;
  if (p.createdAt) {
    try {
      const d = new Date(p.createdAt);
      if (!isNaN(d.getTime())) {
        return d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
      }
    } catch {}
  }
  return null;
};

/**
 * Table column definition for Payments List.
 * Strict mandatory order:
 * 1. Invoice #
 * 2. Payment Date & Time
 * 3. Collector
 * 4. Customer
 * 5. Total
 * 6. Paid
 * 7. Remain
 * 8. Method
 * 9. Status
 * 10. Action
 */
export interface PaymentTableColumnDef {
  key:
    | 'invoice'
    | 'paymentDateTime'
    | 'collector'
    | 'customer'
    | 'total'
    | 'paid'
    | 'remain'
    | 'method'
    | 'status'
    | 'action';
  label: string;
  sortField?: PaymentSortField;
  align?: 'left' | 'right';
  headerClassName: string;
  cellClassName: string;
}

export const PAYMENT_TABLE_COLUMNS: PaymentTableColumnDef[] = [
  {
    key: 'invoice',
    label: 'Invoice #',
    sortField: 'invoice',
    align: 'left',
    headerClassName: 'py-3 px-3 sm:px-3.5 whitespace-nowrap text-left',
    cellClassName: 'py-3.5 px-3 sm:px-3.5 font-mono font-bold text-orange-600 whitespace-nowrap',
  },
  {
    key: 'paymentDateTime',
    label: 'Payment Date & Time',
    sortField: 'date',
    align: 'left',
    headerClassName: 'py-3 px-3 sm:px-3.5 whitespace-nowrap text-left hidden sm:table-cell',
    cellClassName: 'py-3.5 px-3 sm:px-3.5 whitespace-nowrap hidden sm:table-cell',
  },
  {
    key: 'collector',
    label: 'Collector',
    align: 'left',
    headerClassName: 'py-3 px-3 sm:px-3.5 whitespace-nowrap text-left hidden lg:table-cell',
    cellClassName: 'py-3.5 px-3 sm:px-3.5 text-neutral-700 whitespace-nowrap font-medium hidden lg:table-cell',
  },
  {
    key: 'customer',
    label: 'Customer',
    sortField: 'customer',
    align: 'left',
    headerClassName: 'py-3 px-3 sm:px-3.5 whitespace-nowrap text-left',
    cellClassName: 'py-3.5 px-3 sm:px-3.5 font-semibold text-neutral-900',
  },
  {
    key: 'total',
    label: 'Total',
    sortField: 'amount',
    align: 'right',
    headerClassName: 'py-3 px-3 sm:px-3.5 text-right whitespace-nowrap hidden md:table-cell',
    cellClassName: 'py-3.5 px-3 sm:px-3.5 text-right font-mono font-bold text-neutral-900 whitespace-nowrap hidden md:table-cell',
  },
  {
    key: 'paid',
    label: 'Paid',
    align: 'right',
    headerClassName: 'py-3 px-3 sm:px-3.5 text-right whitespace-nowrap',
    cellClassName: 'py-3.5 px-3 sm:px-3.5 text-right font-mono font-bold text-emerald-700 whitespace-nowrap',
  },
  {
    key: 'remain',
    label: 'Remain',
    align: 'right',
    headerClassName: 'py-3 px-3 sm:px-3.5 text-right whitespace-nowrap hidden sm:table-cell',
    cellClassName: 'py-3.5 px-3 sm:px-3.5 text-right font-mono font-bold text-amber-700 whitespace-nowrap hidden sm:table-cell',
  },
  {
    key: 'method',
    label: 'Method',
    align: 'left',
    headerClassName: 'py-3 px-3 sm:px-3.5 whitespace-nowrap text-left hidden lg:table-cell',
    cellClassName: 'py-3.5 px-3 sm:px-3.5 text-neutral-700 whitespace-nowrap font-medium hidden lg:table-cell',
  },
  {
    key: 'status',
    label: 'Status',
    align: 'left',
    headerClassName: 'py-3 px-3 sm:px-3.5 whitespace-nowrap text-left',
    cellClassName: 'py-3.5 px-3 sm:px-3.5 whitespace-nowrap',
  },
  {
    key: 'action',
    label: 'Action',
    align: 'right',
    headerClassName: 'py-3 px-3 sm:px-3.5 whitespace-nowrap text-right',
    cellClassName: 'py-3.5 px-3 sm:px-3.5 whitespace-nowrap text-right',
  },
];

interface PaymentsViewProps {
  payments: Payment[];
  invoices: Invoice[];
  settings: BusinessSettings;
  users?: UserProfile[];
  onAddPayment: () => void;
  onAddCorrection: () => void;
  onSelectInvoice: (invoice: Invoice) => void;
  onNavigateToInvoices?: () => void;
}

export const PaymentsView: React.FC<PaymentsViewProps> = ({
  payments,
  invoices,
  settings,
  users,
  onAddPayment,
  onAddCorrection,
  onSelectInvoice,
  onNavigateToInvoices,
}) => {
  const { userProfile, permissions } = useAuth();

  // Collapsible filter panel state (collapsed by default)
  const [isFilterExpanded, setIsFilterExpanded] = useState<boolean>(false);
  const [isPanelMounted, setIsPanelMounted] = useState<boolean>(false);
  const [isPanelVisible, setIsPanelVisible] = useState<boolean>(false);
  const panelRef = useRef<HTMLDivElement>(null);

  // Smooth height transition animation synchronization
  useEffect(() => {
    let closeTimer: any = null;

    if (isFilterExpanded) {
      setIsPanelMounted(true);
    } else {
      setIsPanelVisible(false);
      closeTimer = setTimeout(() => {
        setIsPanelMounted(false);
      }, 300);
    }

    return () => {
      if (closeTimer) clearTimeout(closeTimer);
    };
  }, [isFilterExpanded]);

  useEffect(() => {
    if (isPanelMounted && isFilterExpanded) {
      // Force synchronous layout recalculation so browser paints the collapsed 0fr state
      if (panelRef.current) {
        void panelRef.current.offsetHeight;
      }
      const raf = requestAnimationFrame(() => {
        setIsPanelVisible(true);
      });
      return () => cancelAnimationFrame(raf);
    }
  }, [isPanelMounted, isFilterExpanded]);

  // Draft filter criteria (edited inside the expanded panel)
  const [draftSearch, setDraftSearch] = useState<string>('');
  const [draftDatePreset, setDraftDatePreset] = useState<PaymentDatePreset>('all');
  const [draftCustomStartDate, setDraftCustomStartDate] = useState<string>('');
  const [draftCustomEndDate, setDraftCustomEndDate] = useState<string>('');
  const [draftStatus, setDraftStatus] = useState<PaymentStatusFilter>('all');
  const [draftMethod, setDraftMethod] = useState<string>('all');
  const [draftCollector, setDraftCollector] = useState<string>('all');
  const [draftMinAmount, setDraftMinAmount] = useState<string>('');
  const [draftMaxAmount, setDraftMaxAmount] = useState<string>('');

  // Applied filter criteria (drives the live filtered list)
  const [appliedSearch, setAppliedSearch] = useState<string>('');
  const [appliedDatePreset, setAppliedDatePreset] = useState<PaymentDatePreset>('all');
  const [appliedCustomStartDate, setAppliedCustomStartDate] = useState<string>('');
  const [appliedCustomEndDate, setAppliedCustomEndDate] = useState<string>('');
  const [appliedStatus, setAppliedStatus] = useState<PaymentStatusFilter>('all');
  const [appliedMethod, setAppliedMethod] = useState<string>('all');
  const [appliedCollector, setAppliedCollector] = useState<string>('all');
  const [appliedMinAmount, setAppliedMinAmount] = useState<string>('');
  const [appliedMaxAmount, setAppliedMaxAmount] = useState<string>('');

  // Sorting state (default: Payment Date — Newest First)
  const [sortField, setSortField] = useState<PaymentSortField>('date');
  const [sortDirection, setSortDirection] = useState<PaymentSortDirection>('desc');

  // Screen width state for responsive conditional rendering of columns
  const [screenWidth, setScreenWidth] = useState<number>(() => {
    if (typeof window !== 'undefined') {
      return window.innerWidth;
    }
    return 1200; // Default to wide desktop in SSR / test environments
  });

  useEffect(() => {
    if (typeof window === 'undefined') return;
    const handleResize = () => {
      setScreenWidth(window.innerWidth);
    };
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  // Visible table columns strictly in mandatory exact order
  const visibleColumns = PAYMENT_TABLE_COLUMNS;

  // Track expanded rows on tablet & mobile for secondary details
  const [expandedRowIds, setExpandedRowIds] = useState<Set<string>>(new Set());

  const toggleRowExpanded = (paymentId: string, e?: React.MouseEvent) => {
    if (e) {
      e.stopPropagation();
    }
    setExpandedRowIds((prev) => {
      const next = new Set(prev);
      if (next.has(paymentId)) {
        next.delete(paymentId);
      } else {
        next.add(paymentId);
      }
      return next;
    });
  };

  const [activeCardFilter, setActiveCardFilter] = useState<FinancialCardFilter>(null);
  const [selectedPaymentForDetails, setSelectedPaymentForDetails] = useState<Payment | null>(null);
  const [selectedReceiptPayment, setSelectedReceiptPayment] = useState<Payment | null>(null);
  const [reversingPayment, setReversingPayment] = useState<Payment | null>(null);
  const [reversalReason, setReversalReason] = useState<string>('');
  const [reversalPassword, setReversalPassword] = useState<string>('');
  const [isProcessingReversal, setIsProcessingReversal] = useState<boolean>(false);
  const [reversalError, setReversalError] = useState<string | null>(null);

  const openReversalModal = (p: Payment) => {
    setReversingPayment(p);
    setReversalReason('');
    setReversalPassword('');
    setReversalError(null);
  };

  const closeReversalModal = () => {
    setReversingPayment(null);
    setReversalReason('');
    setReversalPassword('');
    setReversalError(null);
  };

  const todayStr = useMemo(() => getTodayDateString(), []);
  const currentMonthPrefix = useMemo(() => todayStr.slice(0, 7), [todayStr]);

  // Index void invoices to exclude payments belonging to void invoices
  const { voidInvoiceIds, voidBillNumbers } = useMemo(() => {
    const vIds = new Set<string>();
    const vBills = new Set<string>();
    if (Array.isArray(invoices)) {
      for (const inv of invoices) {
        if (!inv) continue;
        if (inv.isVoid === true || inv.status === 'Void') {
          if (inv.id) vIds.add(String(inv.id).trim());
          if (inv.billNumber) vBills.add(String(inv.billNumber).trim());
        }
      }
    }
    return { voidInvoiceIds: vIds, voidBillNumbers: vBills };
  }, [invoices]);

  // 1. Authoritative metrics for Financial Summary Cards
  const {
    totalCollectedAmount,
    completedPaymentsCount,
    todayAmount,
    todayPaymentsCount,
    thisMonthAmount,
    thisMonthPaymentsCount,
  } = useMemo(() => {
    let totalAmt = 0;
    let completedCount = 0;
    let todayAmt = 0;
    let todayCount = 0;
    let monthAmt = 0;
    let monthCount = 0;

    if (Array.isArray(payments)) {
      for (const p of payments) {
        if (!isValidPayment(p, voidInvoiceIds, voidBillNumbers)) continue;
        const rawAmt = typeof p.amount === 'number' ? p.amount : parseFloat(String(p.amount ?? 0));
        const safeAmt = Number.isFinite(rawAmt) && rawAmt > 0 ? rawAmt : 0;

        totalAmt += safeAmt;
        completedCount++;

        const pDate = p.date || '';
        if (pDate === todayStr || pDate.startsWith(todayStr)) {
          todayAmt += safeAmt;
          todayCount++;
        }

        if (pDate.startsWith(currentMonthPrefix)) {
          monthAmt += safeAmt;
          monthCount++;
        }
      }
    }

    return {
      totalCollectedAmount: totalAmt,
      completedPaymentsCount: completedCount,
      todayAmount: todayAmt,
      todayPaymentsCount: todayCount,
      thisMonthAmount: monthAmt,
      thisMonthPaymentsCount: monthCount,
    };
  }, [payments, voidInvoiceIds, voidBillNumbers, todayStr, currentMonthPrefix]);

  // 2. Authoritative Outstanding calculations
  const {
    totalOutstandingAmount,
    outstandingInvoicesCount,
    outstandingInvoiceIds,
    outstandingBillNumbers,
  } = useMemo(() => {
    const { paymentsByInvoiceId, paymentsByBillNumber } = getValidPaymentsPerInvoice(invoices, payments);
    let totalOut = 0;
    let countOut = 0;
    const outIds = new Set<string>();
    const outBills = new Set<string>();

    if (Array.isArray(invoices)) {
      for (const inv of invoices) {
        if (!isValidInvoice(inv)) continue;
        const rawTotal =
          typeof inv.totalAmount === 'number'
            ? inv.totalAmount
            : parseFloat(String(inv.totalAmount ?? 0));
        const invoiceTotal = Number.isFinite(rawTotal) && rawTotal > 0 ? rawTotal : 0;

        const paid =
          inv.id && paymentsByInvoiceId.has(inv.id)
            ? paymentsByInvoiceId.get(inv.id)!
            : inv.billNumber && paymentsByBillNumber.has(inv.billNumber)
            ? paymentsByBillNumber.get(inv.billNumber)!
            : Number(inv.totalPaid) || 0;

        const remaining = Math.max(0, invoiceTotal - paid);
        if (remaining > 0) {
          totalOut += remaining;
          countOut++;
          if (inv.id) outIds.add(String(inv.id).trim());
          if (inv.billNumber) outBills.add(String(inv.billNumber).trim());
        }
      }
    }

    return {
      totalOutstandingAmount: Math.round(totalOut),
      outstandingInvoicesCount: countOut,
      outstandingInvoiceIds: outIds,
      outstandingBillNumbers: outBills,
    };
  }, [invoices, payments]);

  // Extract unique collectors from live users and payments
  const availableCollectors = useMemo(() => {
    const collectorMap = new Map<string, string>();

    // 1. From users prop
    if (Array.isArray(users)) {
      for (const u of users) {
        if (!u || u.status !== 'active') continue;
        if (
          u.role === 'payment_collector' ||
          u.role === 'super_admin' ||
          u.role === 'invoice_manager'
        ) {
          const name = u.name?.trim();
          if (name) {
            collectorMap.set(name, u.id);
          }
        }
      }
    }

    // 2. From payments
    if (Array.isArray(payments)) {
      for (const p of payments) {
        if (p.recordedByName?.trim()) {
          const name = p.recordedByName.trim();
          if (!collectorMap.has(name)) {
            collectorMap.set(name, p.recordedBy || name);
          }
        }
      }
    }

    // Default Super Admin fallback if empty
    if (collectorMap.size === 0) {
      collectorMap.set('Super Admin', 'super-admin');
    }

    return Array.from(collectorMap.entries()).map(([name, id]) => ({ name, id }));
  }, [users, payments]);

  // Compute number of active filters in the collapsible filter bar
  const activeFilterCount = useMemo(() => {
    let count = 0;
    if (appliedSearch.trim() !== '') count++;
    if (appliedDatePreset !== 'all') count++;
    if (appliedStatus !== 'all') count++;
    if (appliedMethod !== 'all') count++;
    if (appliedCollector !== 'all') count++;
    if (appliedMinAmount.trim() !== '' || appliedMaxAmount.trim() !== '') count++;
    return count;
  }, [
    appliedSearch,
    appliedDatePreset,
    appliedStatus,
    appliedMethod,
    appliedCollector,
    appliedMinAmount,
    appliedMaxAmount,
  ]);

  // Filter helper functions
  const checkSearchMatch = (p: Payment, query: string): boolean => {
    if (!query.trim()) return true;
    const term = query.toLowerCase().trim();
    const matchCust = p.customerName?.toLowerCase().includes(term);
    const matchBill = p.billNumber?.toLowerCase().includes(term);
    const matchId = p.id?.toLowerCase().includes(term);
    const matchNote = p.note?.toLowerCase().includes(term);
    return Boolean(matchCust || matchBill || matchId || matchNote);
  };

  const checkDatePresetMatch = (
    paymentDate: string,
    preset: PaymentDatePreset,
    start: string,
    end: string
  ): boolean => {
    if (preset === 'all') return true;
    if (!paymentDate) return false;

    const dateOnly = paymentDate.slice(0, 10);

    if (preset === 'today') {
      return dateOnly === todayStr;
    }
    if (preset === 'yesterday') {
      const now = new Date();
      const yDate = new Date(now.getFullYear(), now.getMonth(), now.getDate() - 1);
      const yesterdayStr = `${yDate.getFullYear()}-${String(yDate.getMonth() + 1).padStart(2, '0')}-${String(yDate.getDate()).padStart(2, '0')}`;
      return dateOnly === yesterdayStr;
    }
    if (preset === 'this_week') {
      const now = new Date();
      const day = now.getDay();
      const diffToMonday = (day + 6) % 7;
      const monday = new Date(now.getFullYear(), now.getMonth(), now.getDate() - diffToMonday);
      const mondayStr = `${monday.getFullYear()}-${String(monday.getMonth() + 1).padStart(2, '0')}-${String(monday.getDate()).padStart(2, '0')}`;
      return dateOnly >= mondayStr && dateOnly <= todayStr;
    }
    if (preset === 'this_month') {
      return dateOnly.startsWith(currentMonthPrefix);
    }
    if (preset === 'last_month') {
      const now = new Date();
      const lm = new Date(now.getFullYear(), now.getMonth() - 1, 1);
      const lastMonthPrefix = `${lm.getFullYear()}-${String(lm.getMonth() + 1).padStart(2, '0')}`;
      return dateOnly.startsWith(lastMonthPrefix);
    }
    if (preset === 'custom') {
      if (start && dateOnly < start) return false;
      if (end && dateOnly > end) return false;
      return true;
    }
    return true;
  };

  const checkStatusMatch = (p: Payment, status: PaymentStatusFilter): boolean => {
    if (status === 'all') return true;
    const isReversed = Boolean(
      p.isVoid === true ||
      (p as any).status === 'Void' ||
      (p as any).status === 'Cancelled'
    );

    if (status === 'reversed') return isReversed;
    if (status === 'completed') return !isReversed;
    return true;
  };

  const checkCollectorMatch = (p: Payment, collector: string): boolean => {
    if (collector === 'all') return true;
    const name = p.recordedByName?.trim();
    const id = p.recordedBy?.trim();
    if (name && name.toLowerCase() === collector.toLowerCase()) return true;
    if (id && id === collector) return true;
    if (collector === 'Super Admin' && !name) return true;
    return false;
  };

  const checkMethodMatch = (p: Payment, method: string): boolean => {
    if (method === 'all') return true;
    const pMethod = p.method || 'CASH';
    return pMethod.toUpperCase() === method.toUpperCase();
  };

  const checkAmountMatch = (p: Payment, minStr: string, maxStr: string): boolean => {
    const amt = Number(p.amount) || 0;
    if (minStr.trim() !== '') {
      const minVal = Number(minStr);
      if (Number.isFinite(minVal) && amt < minVal) return false;
    }
    if (maxStr.trim() !== '') {
      const maxVal = Number(maxStr);
      if (Number.isFinite(maxVal) && amt > maxVal) return false;
    }
    return true;
  };

  // Filtered payments taking into account Summary Card filter AND Collapsible Filter Bar filters
  const filteredPayments = useMemo(() => {
    return payments.filter((p) => {
      // 1. Summary Card Filter
      if (activeCardFilter === 'total_collected') {
        if (!isValidPayment(p, voidInvoiceIds, voidBillNumbers)) return false;
      } else if (activeCardFilter === 'today') {
        if (!isValidPayment(p, voidInvoiceIds, voidBillNumbers)) return false;
        const pDate = p.date || '';
        if (pDate !== todayStr && !pDate.startsWith(todayStr)) return false;
      } else if (activeCardFilter === 'this_month') {
        if (!isValidPayment(p, voidInvoiceIds, voidBillNumbers)) return false;
        const pDate = p.date || '';
        if (!pDate.startsWith(currentMonthPrefix)) return false;
      } else if (activeCardFilter === 'outstanding') {
        if (!isValidPayment(p, voidInvoiceIds, voidBillNumbers)) return false;
        const invId = p.invoiceId ? String(p.invoiceId).trim() : '';
        const billNum = p.billNumber ? String(p.billNumber).trim() : '';
        const isLinkedToOutstanding =
          (invId && outstandingInvoiceIds.has(invId)) ||
          (billNum && outstandingBillNumbers.has(billNum));
        if (!isLinkedToOutstanding) return false;
      }

      // 2. Collapsible Filter Bar filters (Search, Date, Status, Method, Collector, Amount)
      if (!checkSearchMatch(p, appliedSearch)) return false;
      if (
        !checkDatePresetMatch(
          p.date || '',
          appliedDatePreset,
          appliedCustomStartDate,
          appliedCustomEndDate
        )
      ) {
        return false;
      }
      if (!checkStatusMatch(p, appliedStatus)) return false;
      if (!checkMethodMatch(p, appliedMethod)) return false;
      if (!checkCollectorMatch(p, appliedCollector)) return false;
      if (!checkAmountMatch(p, appliedMinAmount, appliedMaxAmount)) return false;

      return true;
    });
  }, [
    payments,
    activeCardFilter,
    voidInvoiceIds,
    voidBillNumbers,
    todayStr,
    currentMonthPrefix,
    outstandingInvoiceIds,
    outstandingBillNumbers,
    appliedSearch,
    appliedDatePreset,
    appliedCustomStartDate,
    appliedCustomEndDate,
    appliedStatus,
    appliedMethod,
    appliedCollector,
    appliedMinAmount,
    appliedMaxAmount,
  ]);

  const handleCardClick = (filter: FinancialCardFilter) => {
    setActiveCardFilter((prev) => (prev === filter ? null : filter));
  };

  const handleApplyFilters = () => {
    setAppliedSearch(draftSearch);
    setAppliedDatePreset(draftDatePreset);
    setAppliedCustomStartDate(draftCustomStartDate);
    setAppliedCustomEndDate(draftCustomEndDate);
    setAppliedStatus(draftStatus);
    setAppliedMethod(draftMethod);
    setAppliedCollector(draftCollector);
    setAppliedMinAmount(draftMinAmount);
    setAppliedMaxAmount(draftMaxAmount);
  };

  const handleClearAllFilters = () => {
    setDraftSearch('');
    setDraftDatePreset('all');
    setDraftCustomStartDate('');
    setDraftCustomEndDate('');
    setDraftStatus('all');
    setDraftMethod('all');
    setDraftCollector('all');
    setDraftMinAmount('');
    setDraftMaxAmount('');

    setAppliedSearch('');
    setAppliedDatePreset('all');
    setAppliedCustomStartDate('');
    setAppliedCustomEndDate('');
    setAppliedStatus('all');
    setAppliedMethod('all');
    setAppliedCollector('all');
    setAppliedMinAmount('');
    setAppliedMaxAmount('');

    setActiveCardFilter(null);
  };

  // 3. Dynamic metrics for Payment Overview (responds to active Summary Card filter and collapsible filters)
  const overviewMetrics = useMemo(() => {
    // Only valid, non-void payment records are counted towards Collected and Transactions
    const relevantValidPayments = filteredPayments.filter((p) =>
      isValidPayment(p, voidInvoiceIds, voidBillNumbers)
    );

    // 1. Collected: sum of amounts from currently relevant payment records
    const collected = relevantValidPayments.reduce(
      (sum, p) => sum + (Number(p.amount) || 0),
      0
    );

    // 2. Transactions: count of currently relevant payment transactions
    const transactions = relevantValidPayments.length;

    // 3. Outstanding: total remaining amount from currently relevant unpaid/partially-paid invoices
    const { paymentsByInvoiceId, paymentsByBillNumber } = getValidPaymentsPerInvoice(
      invoices,
      payments
    );

    // Build set of invoice IDs and bill numbers from relevantValidPayments
    const relevantPaymentInvoiceIds = new Set<string>();
    const relevantPaymentBillNumbers = new Set<string>();
    for (const p of relevantValidPayments) {
      if (p.invoiceId) relevantPaymentInvoiceIds.add(String(p.invoiceId).trim());
      if (p.billNumber) relevantPaymentBillNumbers.add(String(p.billNumber).trim());
    }

    const term = appliedSearch.toLowerCase().trim();
    let outstanding = 0;

    if (Array.isArray(invoices)) {
      for (const inv of invoices) {
        if (!isValidInvoice(inv)) continue;

        if (term) {
          const custName = (inv as any).customerName || inv.customerSnapshot?.name || '';
          const matchCust = custName.toLowerCase().includes(term);
          const matchBill = inv.billNumber?.toLowerCase().includes(term);
          if (!matchCust && !matchBill) continue;
        }

        const invId = inv.id ? String(inv.id).trim() : '';
        const billNum = inv.billNumber ? String(inv.billNumber).trim() : '';

        let isRelevant = false;
        if (
          !activeCardFilter ||
          activeCardFilter === 'total_collected' ||
          activeCardFilter === 'outstanding'
        ) {
          isRelevant = true;
        } else if (activeCardFilter === 'today') {
          const invDate = inv.date || '';
          const isTodayInvoice = invDate === todayStr || invDate.startsWith(todayStr);
          const isLinkedToTodayPayment =
            (invId && relevantPaymentInvoiceIds.has(invId)) ||
            (billNum && relevantPaymentBillNumbers.has(billNum));
          isRelevant = isTodayInvoice || isLinkedToTodayPayment;
        } else if (activeCardFilter === 'this_month') {
          const invDate = inv.date || '';
          const isMonthInvoice = invDate.startsWith(currentMonthPrefix);
          const isLinkedToMonthPayment =
            (invId && relevantPaymentInvoiceIds.has(invId)) ||
            (billNum && relevantPaymentBillNumbers.has(billNum));
          isRelevant = isMonthInvoice || isLinkedToMonthPayment;
        }

        if (!isRelevant) continue;

        const rawTotal =
          typeof inv.totalAmount === 'number'
            ? inv.totalAmount
            : parseFloat(String(inv.totalAmount ?? 0));
        const invoiceTotal = Number.isFinite(rawTotal) && rawTotal > 0 ? rawTotal : 0;

        const paid =
          inv.id && paymentsByInvoiceId.has(inv.id)
            ? paymentsByInvoiceId.get(inv.id)!
            : inv.billNumber && paymentsByBillNumber.has(inv.billNumber)
            ? paymentsByBillNumber.get(inv.billNumber)!
            : Number(inv.totalPaid) || 0;

        const remaining = Math.max(0, invoiceTotal - paid);
        if (remaining > 0) {
          outstanding += remaining;
        }
      }
    }

    return {
      collected,
      outstanding: Math.round(outstanding),
      transactions,
    };
  }, [
    filteredPayments,
    invoices,
    payments,
    activeCardFilter,
    appliedSearch,
    todayStr,
    currentMonthPrefix,
    voidInvoiceIds,
    voidBillNumbers,
  ]);

  // Sorting interaction handler
  const handleSort = (field: PaymentSortField) => {
    if (sortField === field) {
      setSortDirection((prev) => (prev === 'asc' ? 'desc' : 'asc'));
    } else {
      setSortField(field);
      // Default directions:
      // Dates: Newest first (descending)
      // Amount: Highest first (descending)
      // Text / ID / Invoice: Ascending (A-Z / 1-9)
      if (field === 'date' || field === 'amount') {
        setSortDirection('desc');
      } else {
        setSortDirection('asc');
      }
    }
  };

  // Cumulative paid and invoice mapping for accurate data presentation
  const { paymentCumulativePaidMap, paymentInvoiceMap } = useMemo(() => {
    const cumulativeMap = new Map<string, number>();
    const invMap = new Map<string, Invoice>();

    // 1. Index invoices by ID and billNumber
    const invoiceById = new Map<string, Invoice>();
    const invoiceByBill = new Map<string, Invoice>();
    if (Array.isArray(invoices)) {
      for (const inv of invoices) {
        if (!inv) continue;
        if (inv.id) invoiceById.set(String(inv.id).trim(), inv);
        if (inv.billNumber) invoiceByBill.set(String(inv.billNumber).trim(), inv);
      }
    }

    // 2. Group payments by related invoice (id or billNumber)
    const invoicePaymentsGroup = new Map<string, Payment[]>();
    for (const p of payments) {
      if (!p) continue;
      const invId = p.invoiceId ? String(p.invoiceId).trim() : '';
      const billNum = p.billNumber ? String(p.billNumber).trim() : '';
      const inv = (invId && invoiceById.get(invId)) || (billNum && invoiceByBill.get(billNum)) || null;
      if (inv) {
        invMap.set(p.id, inv);
      }
      const groupKey = inv?.id || invId || billNum || p.id;
      if (!invoicePaymentsGroup.has(groupKey)) {
        invoicePaymentsGroup.set(groupKey, []);
      }
      invoicePaymentsGroup.get(groupKey)!.push(p);
    }

    // 3. For each invoice group, sort payments chronologically (oldest to newest) and calculate cumulative paid
    for (const [_, group] of invoicePaymentsGroup.entries()) {
      const sortedChronological = [...group].sort((a, b) => {
        const dateA = (a.date || '').slice(0, 10);
        const dateB = (b.date || '').slice(0, 10);
        if (dateA !== dateB) return dateA.localeCompare(dateB);

        if (a.time && b.time && a.time !== b.time) {
          return a.time.localeCompare(b.time);
        }

        const timeA = a.createdAt ? new Date(a.createdAt).getTime() : 0;
        const timeB = b.createdAt ? new Date(b.createdAt).getTime() : 0;
        if (timeA !== timeB) return timeA - timeB;

        return (a.id || '').localeCompare(b.id || '');
      });

      let runningPaid = 0;
      for (const p of sortedChronological) {
        const isVoid = Boolean(
          p.isVoid === true ||
          (p as any).status === 'Void' ||
          (p as any).status === 'Cancelled'
        );
        const amt = Number(p.amount) || 0;
        if (!isVoid && amt > 0) {
          runningPaid += amt;
        }
        cumulativeMap.set(p.id, runningPaid);
      }
    }

    return { paymentCumulativePaidMap: cumulativeMap, paymentInvoiceMap: invMap };
  }, [payments, invoices]);

  const getInvoiceTotalForPayment = (p: Payment): number => {
    const linkedInvoice = paymentInvoiceMap.get(p.id);
    if (linkedInvoice) {
      const raw =
        typeof linkedInvoice.totalAmount === 'number'
          ? linkedInvoice.totalAmount
          : parseFloat(String(linkedInvoice.totalAmount ?? 0));
      return Number.isFinite(raw) && raw > 0 ? raw : 0;
    }
    const rawAmt = typeof p.amount === 'number' ? p.amount : parseFloat(String(p.amount ?? 0));
    return Number.isFinite(rawAmt) && rawAmt > 0 ? rawAmt : 0;
  };

  // Helper to compare payment dates cleanly (primary: date, secondary: time/createdAt timestamp, tertiary: id)
  const comparePaymentDates = (a: Payment, b: Payment): number => {
    const dateA = (a.date || '').slice(0, 10);
    const dateB = (b.date || '').slice(0, 10);
    if (dateA !== dateB) {
      return dateA.localeCompare(dateB);
    }
    if (a.time && b.time && a.time !== b.time) {
      return a.time.localeCompare(b.time);
    }
    const timeA = a.createdAt ? new Date(a.createdAt).getTime() : 0;
    const timeB = b.createdAt ? new Date(b.createdAt).getTime() : 0;
    if (timeA !== timeB) {
      return timeA - timeB;
    }
    return (a.id || '').localeCompare(b.id || '');
  };

  // Authoritative sorted payments list (Default: Payment Date & Time — Newest First)
  const sortedPayments = useMemo(() => {
    const list = [...filteredPayments];

    list.sort((a, b) => {
      let comparison = 0;

      switch (sortField) {
        case 'date': {
          comparison = comparePaymentDates(a, b);
          break;
        }
        case 'amount': {
          const totalA = getInvoiceTotalForPayment(a);
          const totalB = getInvoiceTotalForPayment(b);
          if (totalA !== totalB) {
            comparison = totalA - totalB;
          } else {
            comparison = (a.id || '').localeCompare(b.id || '');
          }
          break;
        }
        case 'id': {
          const idA = (a.id || '').toLowerCase().trim();
          const idB = (b.id || '').toLowerCase().trim();
          comparison = idA.localeCompare(idB, undefined, { numeric: true });
          break;
        }
        case 'customer': {
          const custA = (a.customerName || '').toLowerCase().trim();
          const custB = (b.customerName || '').toLowerCase().trim();
          if (custA !== custB) {
            comparison = custA.localeCompare(custB);
          } else {
            comparison = (a.id || '').localeCompare(b.id || '');
          }
          break;
        }
        case 'invoice': {
          const invA = (a.billNumber || '').toLowerCase().trim();
          const invB = (b.billNumber || '').toLowerCase().trim();
          if (invA !== invB) {
            comparison = invA.localeCompare(invB, undefined, { numeric: true });
          } else {
            comparison = (a.id || '').localeCompare(b.id || '');
          }
          break;
        }
        default:
          comparison = 0;
      }

      return sortDirection === 'asc' ? comparison : -comparison;
    });

    return list;
  }, [filteredPayments, sortField, sortDirection, paymentInvoiceMap]);

  // Pagination constants & state (strictly 10 payments per page)
  const PAYMENTS_PER_PAGE = 10;
  const [currentPage, setCurrentPage] = useState<number>(1);

  // When search, filters, active card, or sorting change, return to page 1
  useEffect(() => {
    setCurrentPage(1);
  }, [
    appliedSearch,
    appliedDatePreset,
    appliedCustomStartDate,
    appliedCustomEndDate,
    appliedStatus,
    appliedMethod,
    appliedCollector,
    appliedMinAmount,
    appliedMaxAmount,
    activeCardFilter,
    sortField,
    sortDirection,
  ]);

  // Authoritative pagination metrics
  const totalPayments = sortedPayments.length;
  const totalPages = Math.max(1, Math.ceil(totalPayments / PAYMENTS_PER_PAGE));
  const safeCurrentPage = Math.min(Math.max(1, currentPage), totalPages);
  const startIndex = (safeCurrentPage - 1) * PAYMENTS_PER_PAGE;
  const endIndex = Math.min(startIndex + PAYMENTS_PER_PAGE, totalPayments);

  const paginatedPayments = useMemo(() => {
    return sortedPayments.slice(startIndex, startIndex + PAYMENTS_PER_PAGE);
  }, [sortedPayments, startIndex]);

  const handleConfirmReversal = async () => {
    if (!reversingPayment || !userProfile) return;
    if (!reversalReason.trim()) {
      setReversalError('Please provide an official audit reason for this payment reversal.');
      return;
    }

    if (!reversalPassword || !reversalPassword.trim()) {
      setReversalError('Super Admin password is required to reverse this payment.');
      return;
    }

    const eligibility = checkPaymentReversalEligibility(reversingPayment);
    if (!eligibility.isEligible) {
      setReversalError(
        eligibility.reason || 'Payment cannot be reversed: Reverse window expired (48 hours).'
      );
      return;
    }

    setIsProcessingReversal(true);
    setReversalError(null);

    try {
      if (typeof navigator !== 'undefined' && !navigator.onLine) {
        throw new Error('Payment reversal requires an active connection to the trusted server. You are currently offline.');
      }

      const resp = await fetch('/api/payments/reverse', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          paymentId: reversingPayment.id,
          invoiceId: reversingPayment.invoiceId,
          reason: reversalReason.trim(),
          password: reversalPassword,
          userId: userProfile.id,
          userName: userProfile.name,
          userRole: userProfile.role,
        }),
      });

      if (!resp.ok) {
        const errData = await resp.json().catch(() => ({}));
        throw new Error(errData.error || 'Server rejected payment reversal.');
      }

      const data = await resp.json();
      if (!data.success) {
        throw new Error(data.error || 'Payment reversal failed on server.');
      }

      closeReversalModal();
    } catch (err: any) {
      console.warn('Payment reversal notice:', err.message || err);
      setReversalError(err.message || 'Failed to reverse payment.');
    } finally {
      setIsProcessingReversal(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Payments Header */}
      <div className="flex flex-row items-start sm:items-center justify-between gap-3 sm:gap-4">
        <div className="min-w-0 flex-1">
          <h1 className="text-xl sm:text-2xl font-bold text-neutral-900 tracking-tight">
            Payments
          </h1>
          <p className="text-xs sm:text-sm text-neutral-500 mt-0.5 sm:mt-1">
            Manage and track all customer payments
          </p>
        </div>

        <div className="flex items-center gap-2 shrink-0">
          <button
            id="btn-record-payment"
            type="button"
            onClick={onAddPayment}
            className="p-2 sm:px-4 sm:py-2.5 bg-[#2563EB] hover:bg-[#1D4ED8] active:bg-[#1E40AF] text-white text-xs sm:text-sm font-bold rounded-lg shadow-xs transition inline-flex items-center justify-center gap-1.5 cursor-pointer shrink-0 focus:outline-none focus-visible:ring-2 focus-visible:ring-[#2563EB]"
            title="Record Payment"
            aria-label="Record Payment"
          >
            <Plus className="w-4 h-4 text-white shrink-0" />
            <span className="hidden sm:inline">Record Payment</span>
          </button>
        </div>
      </div>

      {/* Professional Financial Summary Cards */}
      <div
        id="financial-summary-cards"
        className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4"
      >
        {/* 1. Total Collected */}
        <button
          type="button"
          id="card-total-collected"
          onClick={() => handleCardClick('total_collected')}
          aria-pressed={activeCardFilter === 'total_collected'}
          className={`p-4 sm:p-5 rounded-xl border text-left flex flex-col justify-between transition-all duration-150 cursor-pointer min-h-[110px] sm:min-h-[120px] focus:outline-none focus:ring-2 focus:ring-neutral-900/20 group ${
            activeCardFilter === 'total_collected'
              ? 'bg-neutral-900 border-neutral-900 text-white shadow-md ring-2 ring-neutral-900'
              : 'bg-white border-neutral-200 text-neutral-900 hover:border-neutral-300 hover:shadow-xs shadow-2xs'
          }`}
          title="Click to filter completed payments"
        >
          <div className="flex items-center justify-between gap-2">
            <span
              className={`text-[11px] font-bold uppercase tracking-wider ${
                activeCardFilter === 'total_collected' ? 'text-orange-400' : 'text-neutral-500'
              }`}
            >
              Total Collected
            </span>
            {activeCardFilter === 'total_collected' ? (
              <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-neutral-800 text-orange-400 border border-neutral-700">
                Active
              </span>
            ) : (
              <span className="text-[10px] font-medium text-neutral-400 opacity-0 group-hover:opacity-100 transition">
                Filter
              </span>
            )}
          </div>
          <div className="mt-2 min-w-0">
            <p
              className={`text-xl sm:text-2xl font-black font-mono tracking-tight truncate ${
                activeCardFilter === 'total_collected' ? 'text-white' : 'text-neutral-900'
              }`}
            >
              {formatAFN(totalCollectedAmount)}
            </p>
            <p
              className={`text-xs mt-1 truncate ${
                activeCardFilter === 'total_collected' ? 'text-neutral-300' : 'text-neutral-500'
              }`}
            >
              {completedPaymentsCount === 1
                ? '1 completed payment'
                : `${completedPaymentsCount} completed payments`}
            </p>
          </div>
        </button>

        {/* 2. Today */}
        <button
          type="button"
          id="card-today"
          onClick={() => handleCardClick('today')}
          aria-pressed={activeCardFilter === 'today'}
          className={`p-4 sm:p-5 rounded-xl border text-left flex flex-col justify-between transition-all duration-150 cursor-pointer min-h-[110px] sm:min-h-[120px] focus:outline-none focus:ring-2 focus:ring-neutral-900/20 group ${
            activeCardFilter === 'today'
              ? 'bg-neutral-900 border-neutral-900 text-white shadow-md ring-2 ring-neutral-900'
              : 'bg-white border-neutral-200 text-neutral-900 hover:border-neutral-300 hover:shadow-xs shadow-2xs'
          }`}
          title="Click to filter today's payments"
        >
          <div className="flex items-center justify-between gap-2">
            <span
              className={`text-[11px] font-bold uppercase tracking-wider ${
                activeCardFilter === 'today' ? 'text-orange-400' : 'text-neutral-500'
              }`}
            >
              Today
            </span>
            {activeCardFilter === 'today' ? (
              <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-neutral-800 text-orange-400 border border-neutral-700">
                Active
              </span>
            ) : (
              <span className="text-[10px] font-medium text-neutral-400 opacity-0 group-hover:opacity-100 transition">
                Filter
              </span>
            )}
          </div>
          <div className="mt-2 min-w-0">
            <p
              className={`text-xl sm:text-2xl font-black font-mono tracking-tight truncate ${
                activeCardFilter === 'today' ? 'text-white' : 'text-neutral-900'
              }`}
            >
              {formatAFN(todayAmount)}
            </p>
            <p
              className={`text-xs mt-1 truncate ${
                activeCardFilter === 'today' ? 'text-neutral-300' : 'text-neutral-500'
              }`}
            >
              {todayPaymentsCount === 1
                ? '1 payment today'
                : `${todayPaymentsCount} payments today`}
            </p>
          </div>
        </button>

        {/* 3. This Month */}
        <button
          type="button"
          id="card-this-month"
          onClick={() => handleCardClick('this_month')}
          aria-pressed={activeCardFilter === 'this_month'}
          className={`p-4 sm:p-5 rounded-xl border text-left flex flex-col justify-between transition-all duration-150 cursor-pointer min-h-[110px] sm:min-h-[120px] focus:outline-none focus:ring-2 focus:ring-neutral-900/20 group ${
            activeCardFilter === 'this_month'
              ? 'bg-neutral-900 border-neutral-900 text-white shadow-md ring-2 ring-neutral-900'
              : 'bg-white border-neutral-200 text-neutral-900 hover:border-neutral-300 hover:shadow-xs shadow-2xs'
          }`}
          title="Click to filter this month's payments"
        >
          <div className="flex items-center justify-between gap-2">
            <span
              className={`text-[11px] font-bold uppercase tracking-wider ${
                activeCardFilter === 'this_month' ? 'text-orange-400' : 'text-neutral-500'
              }`}
            >
              This Month
            </span>
            {activeCardFilter === 'this_month' ? (
              <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-neutral-800 text-orange-400 border border-neutral-700">
                Active
              </span>
            ) : (
              <span className="text-[10px] font-medium text-neutral-400 opacity-0 group-hover:opacity-100 transition">
                Filter
              </span>
            )}
          </div>
          <div className="mt-2 min-w-0">
            <p
              className={`text-xl sm:text-2xl font-black font-mono tracking-tight truncate ${
                activeCardFilter === 'this_month' ? 'text-white' : 'text-neutral-900'
              }`}
            >
              {formatAFN(thisMonthAmount)}
            </p>
            <p
              className={`text-xs mt-1 truncate ${
                activeCardFilter === 'this_month' ? 'text-neutral-300' : 'text-neutral-500'
              }`}
            >
              {thisMonthPaymentsCount === 1
                ? '1 payment this month'
                : `${thisMonthPaymentsCount} payments this month`}
            </p>
          </div>
        </button>

        {/* 4. Outstanding */}
        <button
          type="button"
          id="card-outstanding"
          onClick={() => handleCardClick('outstanding')}
          aria-pressed={activeCardFilter === 'outstanding'}
          className={`p-4 sm:p-5 rounded-xl border text-left flex flex-col justify-between transition-all duration-150 cursor-pointer min-h-[110px] sm:min-h-[120px] focus:outline-none focus:ring-2 focus:ring-neutral-900/20 group ${
            activeCardFilter === 'outstanding'
              ? 'bg-neutral-900 border-neutral-900 text-white shadow-md ring-2 ring-neutral-900'
              : 'bg-white border-neutral-200 text-neutral-900 hover:border-neutral-300 hover:shadow-xs shadow-2xs'
          }`}
          title="Click to filter invoices with outstanding balance"
        >
          <div className="flex items-center justify-between gap-2">
            <span
              className={`text-[11px] font-bold uppercase tracking-wider ${
                activeCardFilter === 'outstanding' ? 'text-orange-400' : 'text-neutral-500'
              }`}
            >
              Outstanding
            </span>
            {activeCardFilter === 'outstanding' ? (
              <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-neutral-800 text-orange-400 border border-neutral-700">
                Active
              </span>
            ) : (
              <span className="text-[10px] font-medium text-neutral-400 opacity-0 group-hover:opacity-100 transition">
                Filter
              </span>
            )}
          </div>
          <div className="mt-2 min-w-0">
            <p
              className={`text-xl sm:text-2xl font-black font-mono tracking-tight truncate ${
                activeCardFilter === 'outstanding' ? 'text-white' : 'text-neutral-900'
              }`}
            >
              {formatAFN(totalOutstandingAmount)}
            </p>
            <div className="flex items-center justify-between mt-1 gap-1">
              <p
                className={`text-xs truncate ${
                  activeCardFilter === 'outstanding' ? 'text-neutral-300' : 'text-neutral-500'
                }`}
              >
                {outstandingInvoicesCount === 1
                  ? '1 invoice with balance'
                  : `${outstandingInvoicesCount} invoices with balance`}
              </p>
              {onNavigateToInvoices && (
                <span
                  role="button"
                  tabIndex={0}
                  id="btn-nav-outstanding-invoices"
                  onClick={(e) => {
                    e.stopPropagation();
                    onNavigateToInvoices();
                  }}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter' || e.key === ' ') {
                      e.stopPropagation();
                      onNavigateToInvoices();
                    }
                  }}
                  className={`text-[10px] font-bold inline-flex items-center gap-0.5 hover:underline shrink-0 ${
                    activeCardFilter === 'outstanding'
                      ? 'text-orange-300 hover:text-white'
                      : 'text-orange-600 hover:text-orange-700'
                  }`}
                  title="View unpaid and partially paid invoices"
                >
                  <span>Invoices</span>
                  <ChevronRight className="w-3 h-3" />
                </span>
              )}
            </div>
          </div>
        </button>
      </div>

      {/* Payment Overview */}
      <div
        id="payment-overview"
        className="bg-white border border-neutral-200/90 rounded-xl p-3.5 sm:p-4 shadow-2xs"
      >
        <div className="flex items-center justify-between mb-3 pb-2 border-b border-neutral-100">
          <div className="flex items-center gap-2">
            <span className="text-xs font-bold uppercase tracking-wider text-neutral-700">
              Payment Overview
            </span>
            {activeCardFilter && (
              <span className="text-[10px] font-semibold px-2 py-0.5 rounded-full bg-neutral-100 text-neutral-600 border border-neutral-200">
                Filtered:{' '}
                {activeCardFilter === 'total_collected' && 'Total Collected'}
                {activeCardFilter === 'today' && 'Today'}
                {activeCardFilter === 'this_month' && 'This Month'}
                {activeCardFilter === 'outstanding' && 'Outstanding'}
              </span>
            )}
          </div>
          <span className="text-[11px] text-neutral-400 font-medium hidden sm:inline">
            Live Financial Ledger Metrics
          </span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 sm:gap-4 divide-y sm:divide-y-0 sm:divide-x divide-neutral-100">
          {/* 1. Collected */}
          <div className="min-w-0 pt-2 sm:pt-0 sm:px-3 first:pl-0">
            <span className="text-[11px] font-semibold text-neutral-500 uppercase tracking-wide block">
              Collected
            </span>
            <p
              id="overview-collected-amount"
              className="text-lg sm:text-xl font-black font-mono text-emerald-700 tracking-tight mt-0.5 truncate"
            >
              {formatAFN(overviewMetrics.collected)}
            </p>
            <span className="text-[11px] text-neutral-400 block truncate mt-0.5">
              Relevant cash receipts
            </span>
          </div>

          {/* 2. Outstanding */}
          <div className="min-w-0 pt-2 sm:pt-0 sm:px-3">
            <span className="text-[11px] font-semibold text-neutral-500 uppercase tracking-wide block">
              Outstanding
            </span>
            <p
              id="overview-outstanding-amount"
              className="text-lg sm:text-xl font-black font-mono text-amber-700 tracking-tight mt-0.5 truncate"
            >
              {formatAFN(overviewMetrics.outstanding)}
            </p>
            <span className="text-[11px] text-neutral-400 block truncate mt-0.5">
              Relevant unpaid balance
            </span>
          </div>

          {/* 3. Transactions */}
          <div className="min-w-0 pt-2 sm:pt-0 sm:px-3 last:pr-0">
            <span className="text-[11px] font-semibold text-neutral-500 uppercase tracking-wide block">
              Transactions
            </span>
            <p
              id="overview-transactions-count"
              className="text-lg sm:text-xl font-black font-mono text-neutral-900 tracking-tight mt-0.5 truncate"
            >
              {overviewMetrics.transactions}
            </p>
            <span className="text-[11px] text-neutral-400 block truncate mt-0.5">
              {overviewMetrics.transactions === 1
                ? 'Relevant transaction'
                : 'Relevant transactions'}
            </span>
          </div>
        </div>
      </div>

      {/* Active Filter Pill & All/Clear Control */}
      {activeCardFilter && (
        <div
          id="active-card-filter-banner"
          className="flex flex-row items-center justify-between bg-neutral-100 px-3.5 py-2.5 rounded-xl border border-neutral-200 text-xs gap-2"
        >
          <div className="flex items-center gap-2 min-w-0 flex-wrap">
            <span className="text-neutral-500 font-medium">Filtering by:</span>
            <span className="font-bold text-neutral-900 bg-white px-2.5 py-1 rounded-md border border-neutral-200 shadow-2xs text-[11px] truncate">
              {activeCardFilter === 'total_collected' && 'Total Collected'}
              {activeCardFilter === 'today' && 'Today'}
              {activeCardFilter === 'this_month' && 'This Month'}
              {activeCardFilter === 'outstanding' && 'Outstanding'}
            </span>
            <span className="text-neutral-400 text-xs hidden sm:inline">
              ({filteredPayments.length} of {payments.length} payments visible)
            </span>
            {activeCardFilter === 'outstanding' && onNavigateToInvoices && (
              <button
                type="button"
                id="btn-banner-nav-outstanding-invoices"
                onClick={onNavigateToInvoices}
                className="inline-flex items-center gap-1 px-2.5 py-1 text-[11px] font-bold text-blue-700 bg-blue-100 hover:bg-blue-200 border border-blue-300 rounded-lg transition cursor-pointer"
                title="View unpaid and partially paid invoices"
              >
                <span>View Outstanding Invoices</span>
                <ArrowRight className="w-3 h-3" />
              </button>
            )}
          </div>
          <button
            type="button"
            id="btn-clear-card-filter"
            onClick={() => setActiveCardFilter(null)}
            className="text-xs font-bold text-orange-600 hover:text-orange-700 inline-flex items-center gap-1 cursor-pointer shrink-0 px-2 py-1 hover:bg-orange-50 rounded-md transition"
            title="Restore all records"
          >
            <X className="w-3.5 h-3.5" />
            <span>Clear Filter (All Records)</span>
          </button>
        </div>
      )}

      {/* Professional Collapsible Payment Filter Bar */}
      <div
        id="collapsible-payment-filter-bar"
        className="bg-white rounded-xl border border-neutral-200 shadow-2xs overflow-hidden transition-all duration-200"
      >
        {/* Filter Bar Header / Toggle */}
        <div
          id="btn-filter-header"
          onClick={() => setIsFilterExpanded(!isFilterExpanded)}
          className="p-3 sm:p-3.5 flex flex-wrap items-center justify-between gap-3 bg-white hover:bg-neutral-50/70 transition cursor-pointer select-none"
          role="button"
          tabIndex={0}
          aria-expanded={isFilterExpanded}
          aria-controls="expanded-filter-panel"
          onKeyDown={(e) => {
            if (e.key === 'Enter' || e.key === ' ') {
              e.preventDefault();
              setIsFilterExpanded(!isFilterExpanded);
            }
          }}
        >
          <div className="flex items-center gap-2.5 min-w-0">
            <div
              className={`p-1.5 rounded-lg border transition ${
                activeFilterCount > 0
                  ? 'bg-orange-50 border-orange-200 text-orange-600'
                  : 'bg-neutral-100 border-neutral-200 text-neutral-600'
              }`}
            >
              <Filter className="w-4 h-4 shrink-0" />
            </div>

            <div className="flex items-center gap-2">
              <span className="font-bold text-xs sm:text-sm text-neutral-900 tracking-tight">
                Filters
              </span>

              {activeFilterCount > 0 && (
                <span
                  id="active-filters-count-badge"
                  className="px-2 py-0.5 text-[10px] sm:text-xs font-bold rounded-full bg-orange-100 text-orange-800 border border-orange-200 shrink-0"
                >
                  {activeFilterCount} active
                </span>
              )}
            </div>

            {/* Concise active filter chips when collapsed */}
            {!isFilterExpanded && activeFilterCount > 0 && (
              <div
                id="collapsed-active-filter-chips"
                className="hidden md:flex items-center gap-1.5 ml-2 overflow-hidden"
              >
                {appliedSearch && (
                  <span className="text-[10px] font-medium px-2 py-0.5 rounded bg-neutral-100 text-neutral-700 truncate max-w-[120px]">
                    "{appliedSearch}"
                  </span>
                )}
                {appliedDatePreset !== 'all' && (
                  <span className="text-[10px] font-medium px-2 py-0.5 rounded bg-neutral-100 text-neutral-700">
                    {appliedDatePreset === 'today'
                      ? 'Today'
                      : appliedDatePreset === 'yesterday'
                      ? 'Yesterday'
                      : appliedDatePreset === 'this_week'
                      ? 'This Week'
                      : appliedDatePreset === 'this_month'
                      ? 'This Month'
                      : appliedDatePreset === 'last_month'
                      ? 'Last Month'
                      : 'Custom Dates'}
                  </span>
                )}
                {appliedStatus !== 'all' && (
                  <span className="text-[10px] font-medium px-2 py-0.5 rounded bg-neutral-100 text-neutral-700">
                    {appliedStatus === 'completed'
                      ? 'Completed'
                      : 'Cancelled / Reversed'}
                  </span>
                )}
                {appliedCollector !== 'all' && (
                  <span className="text-[10px] font-medium px-2 py-0.5 rounded bg-neutral-100 text-neutral-700 truncate max-w-[100px]">
                    {appliedCollector}
                  </span>
                )}
                {appliedMethod !== 'all' && (
                  <span className="text-[10px] font-medium px-2 py-0.5 rounded bg-neutral-100 text-neutral-700">
                    {appliedMethod}
                  </span>
                )}
                {(appliedMinAmount || appliedMaxAmount) && (
                  <span className="text-[10px] font-medium px-2 py-0.5 rounded bg-neutral-100 text-neutral-700">
                    {appliedMinAmount ? `Min ${appliedMinAmount}` : ''}
                    {appliedMinAmount && appliedMaxAmount ? ' - ' : ''}
                    {appliedMaxAmount ? `Max ${appliedMaxAmount}` : ''} AFN
                  </span>
                )}
              </div>
            )}
          </div>

          <div className="flex items-center gap-2 shrink-0">
            {activeFilterCount > 0 && (
              <button
                type="button"
                id="btn-clear-all-filters-header"
                onClick={(e) => {
                  e.stopPropagation();
                  handleClearAllFilters();
                }}
                className="text-xs font-bold text-blue-600 hover:text-blue-700 hover:bg-blue-50 px-2.5 py-1 rounded-md transition inline-flex items-center gap-1 cursor-pointer"
                title="Clear all active filters"
              >
                <X className="w-3.5 h-3.5" />
                <span>Clear All</span>
              </button>
            )}

            <span className="text-neutral-400 hover:text-neutral-600 p-1">
              <ChevronDown
                className={`w-4 h-4 transition-transform duration-300 ease-in-out ${
                  isFilterExpanded ? 'rotate-180 text-neutral-800' : 'rotate-0'
                }`}
              />
            </span>
          </div>
        </div>

        {/* Expanded Filter Panel with Smooth Height Transition */}
        {isPanelMounted && (
          <div
            ref={panelRef}
            className={`collapsible-filter-panel grid transition-[grid-template-rows,opacity] duration-300 ease-in-out ${
              isPanelVisible
                ? 'is-expanded grid-rows-[1fr] opacity-100'
                : 'grid-rows-[0fr] opacity-0'
            }`}
            style={{
              gridTemplateRows: isPanelVisible ? '1fr' : '0fr',
              opacity: isPanelVisible ? 1 : 0,
              transitionProperty: 'grid-template-rows, opacity',
              transitionDuration: '300ms',
              transitionTimingFunction: 'cubic-bezier(0.4, 0, 0.2, 1)',
            }}
          >
            <div className="collapsible-filter-inner overflow-hidden min-h-0">
              <div
                id="expanded-filter-panel"
                className="p-4 border-t border-neutral-100 space-y-4 bg-neutral-50/40"
              >
            {/* Primary Controls */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
              {/* 1. Search */}
              <div className="lg:col-span-1">
                <label className="block text-[11px] font-bold uppercase tracking-wider text-neutral-600 mb-1">
                  Search (ID, Invoice, Customer)
                </label>
                <div className="relative">
                  <Search className="w-4 h-4 text-neutral-400 absolute left-3 top-2.5" />
                  <input
                    id="filter-search-input"
                    type="text"
                    value={draftSearch}
                    onChange={(e) => setDraftSearch(e.target.value)}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter') handleApplyFilters();
                    }}
                    placeholder="Payment ID, Invoice #, or Customer..."
                    className="w-full text-xs pl-9 pr-3 py-2 bg-white border border-neutral-300 rounded-lg focus:outline-none focus:ring-1 focus:ring-orange-500"
                  />
                </div>
              </div>

              {/* 2. Date Range */}
              <div>
                <label className="block text-[11px] font-bold uppercase tracking-wider text-neutral-600 mb-1">
                  Date Range
                </label>
                <select
                  id="filter-date-preset-select"
                  value={draftDatePreset}
                  onChange={(e) => setDraftDatePreset(e.target.value as any)}
                  className="w-full text-xs px-3 py-2 bg-white border border-neutral-300 rounded-lg focus:outline-none focus:ring-1 focus:ring-orange-500 cursor-pointer"
                >
                  <option value="all">All Dates</option>
                  <option value="today">Today</option>
                  <option value="yesterday">Yesterday</option>
                  <option value="this_week">This Week</option>
                  <option value="this_month">This Month</option>
                  <option value="last_month">Last Month</option>
                  <option value="custom">Custom Date Range</option>
                </select>
              </div>

              {/* 3. Payment Status */}
              <div>
                <label className="block text-[11px] font-bold uppercase tracking-wider text-neutral-600 mb-1">
                  Payment Status
                </label>
                <select
                  id="filter-status-select"
                  value={draftStatus}
                  onChange={(e) => setDraftStatus(e.target.value as any)}
                  className="w-full text-xs px-3 py-2 bg-white border border-neutral-300 rounded-lg focus:outline-none focus:ring-1 focus:ring-orange-500 cursor-pointer"
                >
                  <option value="all">All Statuses</option>
                  <option value="completed">Completed</option>
                  <option value="reversed">Cancelled / Reversed</option>
                </select>
              </div>
            </div>

            {/* Custom Date Range inputs (if Custom selected) */}
            {draftDatePreset === 'custom' && (
              <div
                id="custom-date-range-fields"
                className="grid grid-cols-1 sm:grid-cols-2 gap-3 p-3 bg-white rounded-lg border border-neutral-200"
              >
                <div>
                  <label className="block text-[11px] font-semibold text-neutral-500 mb-1">
                    From Date
                  </label>
                  <input
                    id="filter-custom-start-date"
                    type="date"
                    value={draftCustomStartDate}
                    onChange={(e) => setDraftCustomStartDate(e.target.value)}
                    className="w-full text-xs font-mono border border-neutral-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-1 focus:ring-orange-500"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-semibold text-neutral-500 mb-1">
                    To Date
                  </label>
                  <input
                    id="filter-custom-end-date"
                    type="date"
                    value={draftCustomEndDate}
                    onChange={(e) => setDraftCustomEndDate(e.target.value)}
                    className="w-full text-xs font-mono border border-neutral-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-1 focus:ring-orange-500"
                  />
                </div>
              </div>
            )}

            {/* Additional Controls */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-2 border-t border-neutral-200/60">
              {/* Payment Method */}
              <div>
                <label className="block text-[11px] font-bold uppercase tracking-wider text-neutral-600 mb-1">
                  Payment Method
                </label>
                <select
                  id="filter-method-select"
                  value={draftMethod}
                  onChange={(e) => setDraftMethod(e.target.value)}
                  className="w-full text-xs px-3 py-2 bg-white border border-neutral-300 rounded-lg focus:outline-none focus:ring-1 focus:ring-orange-500 cursor-pointer"
                >
                  <option value="all">All Methods</option>
                  <option value="CASH">Cash</option>
                </select>
              </div>

              {/* Collector */}
              <div>
                <label className="block text-[11px] font-bold uppercase tracking-wider text-neutral-600 mb-1">
                  Collector
                </label>
                <select
                  id="filter-collector-select"
                  value={draftCollector}
                  onChange={(e) => setDraftCollector(e.target.value)}
                  className="w-full text-xs px-3 py-2 bg-white border border-neutral-300 rounded-lg focus:outline-none focus:ring-1 focus:ring-orange-500 cursor-pointer"
                >
                  <option value="all">All Collectors</option>
                  {availableCollectors.map((c) => (
                    <option key={c.name} value={c.name}>
                      {c.name}
                    </option>
                  ))}
                </select>
              </div>

              {/* Amount Range */}
              <div>
                <label className="block text-[11px] font-bold uppercase tracking-wider text-neutral-600 mb-1">
                  Amount Range (AFN)
                </label>
                <div className="flex items-center gap-2">
                  <input
                    id="filter-min-amount"
                    type="number"
                    min="0"
                    placeholder="Min AFN"
                    value={draftMinAmount}
                    onChange={(e) => setDraftMinAmount(e.target.value)}
                    className="w-1/2 text-xs font-mono px-3 py-2 bg-white border border-neutral-300 rounded-lg focus:outline-none focus:ring-1 focus:ring-orange-500"
                  />
                  <span className="text-neutral-400 text-xs">—</span>
                  <input
                    id="filter-max-amount"
                    type="number"
                    min="0"
                    placeholder="Max AFN"
                    value={draftMaxAmount}
                    onChange={(e) => setDraftMaxAmount(e.target.value)}
                    className="w-1/2 text-xs font-mono px-3 py-2 bg-white border border-neutral-300 rounded-lg focus:outline-none focus:ring-1 focus:ring-orange-500"
                  />
                </div>
              </div>
            </div>

            {/* Filter Action Buttons */}
            <div className="pt-3 border-t border-neutral-200/60 flex items-center justify-between text-xs">
              <span className="text-neutral-500 text-xs">
                Showing {filteredPayments.length} of {payments.length} records
              </span>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  id="btn-clear-filters-expanded"
                  onClick={handleClearAllFilters}
                  className="px-3.5 py-2 font-semibold text-neutral-600 hover:text-neutral-900 bg-white hover:bg-neutral-100 rounded-lg border border-neutral-300 transition cursor-pointer"
                >
                  Clear All
                </button>
                <button
                  type="button"
                  id="btn-apply-filters"
                  onClick={handleApplyFilters}
                  className="px-4 py-2 font-bold text-white bg-[#2563EB] hover:bg-[#1D4ED8] active:bg-[#1E40AF] rounded-lg transition shadow-xs cursor-pointer inline-flex items-center gap-1.5 focus:outline-none focus-visible:ring-2 focus-visible:ring-[#2563EB]"
                >
                  Apply Filters
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    )}
  </div>

      {/* Payments List Section */}
      <div
        id="payments-list-section"
        className="bg-white rounded-xl border border-neutral-200 shadow-xs overflow-hidden"
      >
        {/* Payments List Toolbar Header */}
        <div className="p-3.5 sm:p-4 border-b border-neutral-200 bg-neutral-50/50 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex items-center gap-2.5">
            <h2 className="text-sm font-bold text-neutral-900 tracking-tight">
              Payments List
            </h2>
            <span
              id="payments-count-badge"
              className="text-xs font-semibold px-2 py-0.5 rounded-full bg-neutral-200/70 text-neutral-700"
            >
              {sortedPayments.length} of {payments.length}
            </span>
          </div>

          {/* Active Sort Indicator on Desktop & Mobile Sort Selector */}
          <div className="flex items-center gap-2">
            <span className="text-[11px] font-semibold text-neutral-500 hidden sm:inline">
              Sorted by:
            </span>
            <span
              id="active-sort-indicator-badge"
              className="text-xs font-bold text-neutral-800 bg-white px-2.5 py-1 rounded-md border border-neutral-200 shadow-2xs hidden sm:inline-flex items-center gap-1.5"
            >
              {sortField === 'date' && `Payment Date & Time (${sortDirection === 'desc' ? 'Newest First' : 'Oldest First'})`}
              {sortField === 'amount' && `Total Amount (${sortDirection === 'desc' ? 'Highest First' : 'Lowest First'})`}
              {sortField === 'id' && `Payment ID (${sortDirection === 'asc' ? 'Ascending' : 'Descending'})`}
              {sortField === 'customer' && `Customer (${sortDirection === 'asc' ? 'A ↔ Z' : 'Z ↔ A'})`}
              {sortField === 'invoice' && `Invoice # (${sortDirection === 'asc' ? 'Ascending' : 'Descending'})`}
              {sortDirection === 'asc' ? (
                <ArrowUp className="w-3.5 h-3.5 text-orange-600 shrink-0" />
              ) : (
                <ArrowDown className="w-3.5 h-3.5 text-orange-600 shrink-0" />
              )}
            </span>

            {/* Mobile / Small Screen Accessible Sort Selector */}
            <div className="flex sm:hidden items-center gap-1.5 w-full">
              <span className="text-xs font-semibold text-neutral-600 shrink-0">Sort:</span>
              <select
                id="mobile-sort-select"
                aria-label="Sort Payments List"
                value={`${sortField}_${sortDirection}`}
                onChange={(e) => {
                  const [field, dir] = e.target.value.split('_') as [PaymentSortField, PaymentSortDirection];
                  setSortField(field);
                  setSortDirection(dir);
                }}
                className="w-full text-xs font-medium px-2.5 py-1.5 bg-white border border-neutral-300 rounded-lg focus:outline-none focus:ring-1 focus:ring-orange-500 cursor-pointer shadow-2xs"
              >
                <option value="date_desc">Payment Date & Time — Newest First</option>
                <option value="date_asc">Payment Date & Time — Oldest First</option>
                <option value="amount_desc">Total Amount — Highest First</option>
                <option value="amount_asc">Total Amount — Lowest First</option>
                <option value="invoice_asc">Invoice # — Ascending</option>
                <option value="invoice_desc">Invoice # — Descending</option>
                <option value="customer_asc">Customer — A ↔ Z</option>
                <option value="customer_desc">Customer — Z ↔ A</option>
                <option value="id_asc">Payment ID — Ascending</option>
                <option value="id_desc">Payment ID — Descending</option>
              </select>
            </div>
          </div>
        </div>

        {/* Payments Table / List */}
        {sortedPayments.length === 0 ? (
          <div className="p-12 text-center text-xs text-neutral-500">
            <DollarSign className="w-10 h-10 text-neutral-300 mx-auto mb-3" />
            <p className="font-bold text-sm text-neutral-700">No payment records found.</p>
            <p className="mt-1 text-neutral-400">
              {activeCardFilter === 'outstanding'
                ? 'No payments found for invoices with an outstanding balance. Invoices with remaining balances may not have had any payments recorded yet.'
                : 'Record a payment or adjust your search filters.'}
            </p>
            {activeCardFilter === 'outstanding' && onNavigateToInvoices && (
              <button
                type="button"
                id="btn-empty-nav-invoices"
                onClick={onNavigateToInvoices}
                className="mt-3 inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-bold bg-neutral-900 hover:bg-black text-white rounded-lg transition cursor-pointer shadow-xs"
              >
                <span>View Invoices with Balance</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            )}
          </div>
        ) : (
          <>
            <div className="overflow-x-auto">
              <table id="payments-table" className="w-full min-w-full lg:min-w-[950px] border-collapse text-xs">
              <thead>
                <tr className="bg-neutral-900 text-white font-semibold text-left">
                  {visibleColumns.map((col) => {
                    if (col.key === 'invoice') {
                      return (
                        <th key={col.key} className={col.headerClassName}>
                          <button
                            type="button"
                            id="sort-col-invoice"
                            onClick={() => handleSort('invoice')}
                            aria-sort={sortField === 'invoice' ? (sortDirection === 'asc' ? 'ascending' : 'descending') : 'none'}
                            className={`inline-flex items-center gap-1.5 transition select-none cursor-pointer hover:text-orange-400 ${
                              sortField === 'invoice' ? 'text-orange-400 font-bold' : 'text-neutral-200'
                            }`}
                            title="Sort by Invoice # (Ascending ↔ Descending)"
                          >
                            <span>Invoice #</span>
                            {sortField === 'invoice' ? (
                              sortDirection === 'asc' ? (
                                <ArrowUp className="w-3.5 h-3.5 text-orange-400 shrink-0" />
                              ) : (
                                <ArrowDown className="w-3.5 h-3.5 text-orange-400 shrink-0" />
                              )
                            ) : (
                              <ArrowUpDown className="w-3 h-3 text-neutral-400 opacity-60 shrink-0" />
                            )}
                          </button>
                        </th>
                      );
                    }
                    if (col.key === 'paymentDateTime') {
                      return (
                        <th key={col.key} className={col.headerClassName}>
                          <button
                            type="button"
                            id="sort-col-date"
                            onClick={() => handleSort('date')}
                            aria-sort={sortField === 'date' ? (sortDirection === 'asc' ? 'ascending' : 'descending') : 'none'}
                            className={`inline-flex items-center gap-1.5 transition select-none cursor-pointer hover:text-orange-400 ${
                              sortField === 'date' ? 'text-orange-400 font-bold' : 'text-neutral-200'
                            }`}
                            title="Sort by Payment Date & Time (Newest ↔ Oldest)"
                          >
                            <span>Payment Date & Time</span>
                            {sortField === 'date' ? (
                              sortDirection === 'asc' ? (
                                <ArrowUp className="w-3.5 h-3.5 text-orange-400 shrink-0" />
                              ) : (
                                <ArrowDown className="w-3.5 h-3.5 text-orange-400 shrink-0" />
                              )
                            ) : (
                              <ArrowUpDown className="w-3 h-3 text-neutral-400 opacity-60 shrink-0" />
                            )}
                          </button>
                        </th>
                      );
                    }
                    if (col.key === 'collector') {
                      return (
                        <th key={col.key} className={col.headerClassName}>
                          <span>Collector</span>
                        </th>
                      );
                    }
                    if (col.key === 'customer') {
                      return (
                        <th key={col.key} className={col.headerClassName}>
                          <button
                            type="button"
                            id="sort-col-customer"
                            onClick={() => handleSort('customer')}
                            aria-sort={sortField === 'customer' ? (sortDirection === 'asc' ? 'ascending' : 'descending') : 'none'}
                            className={`inline-flex items-center gap-1.5 transition select-none cursor-pointer hover:text-orange-400 ${
                              sortField === 'customer' ? 'text-orange-400 font-bold' : 'text-neutral-200'
                            }`}
                            title="Sort by Customer (A ↔ Z)"
                          >
                            <span>Customer</span>
                            {sortField === 'customer' ? (
                              sortDirection === 'asc' ? (
                                <ArrowUp className="w-3.5 h-3.5 text-orange-400 shrink-0" />
                              ) : (
                                <ArrowDown className="w-3.5 h-3.5 text-orange-400 shrink-0" />
                              )
                            ) : (
                              <ArrowUpDown className="w-3 h-3 text-neutral-400 opacity-60 shrink-0" />
                            )}
                          </button>
                        </th>
                      );
                    }
                    if (col.key === 'total') {
                      return (
                        <th key={col.key} className={col.headerClassName}>
                          <button
                            type="button"
                            id="sort-col-amount"
                            onClick={() => handleSort('amount')}
                            aria-sort={sortField === 'amount' ? (sortDirection === 'asc' ? 'ascending' : 'descending') : 'none'}
                            className={`inline-flex items-center gap-1.5 transition select-none cursor-pointer hover:text-orange-400 ml-auto ${
                              sortField === 'amount' ? 'text-orange-400 font-bold' : 'text-neutral-200'
                            }`}
                            title="Sort by Total (Highest ↔ Lowest)"
                          >
                            <span>Total</span>
                            {sortField === 'amount' ? (
                              sortDirection === 'asc' ? (
                                <ArrowUp className="w-3.5 h-3.5 text-orange-400 shrink-0" />
                              ) : (
                                <ArrowDown className="w-3.5 h-3.5 text-orange-400 shrink-0" />
                              )
                            ) : (
                              <ArrowUpDown className="w-3 h-3 text-neutral-400 opacity-60 shrink-0" />
                            )}
                          </button>
                        </th>
                      );
                    }
                    if (col.key === 'paid') {
                      return (
                        <th key={col.key} className={col.headerClassName}>
                          <span>Paid</span>
                        </th>
                      );
                    }
                    if (col.key === 'remain') {
                      return (
                        <th key={col.key} className={col.headerClassName}>
                          <span>Remain</span>
                        </th>
                      );
                    }
                    if (col.key === 'method') {
                      return (
                        <th key={col.key} className={col.headerClassName}>
                          <span>Method</span>
                        </th>
                      );
                    }
                    if (col.key === 'status') {
                      return (
                        <th key={col.key} className={col.headerClassName}>
                          <span>Status</span>
                        </th>
                      );
                    }
                    if (col.key === 'action') {
                      return (
                        <th key={col.key} className={col.headerClassName}>
                          <span>Action</span>
                        </th>
                      );
                    }
                    return null;
                  })}
                </tr>
              </thead>
              <tbody className="divide-y divide-neutral-200">
                {paginatedPayments.map((p) => {
                  const isReversed = Boolean(
                    p.isVoid === true ||
                    (p as any).status === 'Void' ||
                    (p as any).status === 'Cancelled'
                  );

                  const linkedInvoice = paymentInvoiceMap.get(p.id) || null;
                  const invoiceDisplay = p.billNumber || linkedInvoice?.billNumber || '—';

                  const formattedDate = formatDate(p.date);
                  const formattedTime = formatPaymentTime(p);

                  const collectorDisplay =
                    p.recordedByName ||
                    (p.recordedBy ? (users?.find((u) => u.id === p.recordedBy)?.name || p.recordedBy) : 'Super Admin');

                  const customerDisplay =
                    p.customerName ||
                    linkedInvoice?.customerSnapshot?.name ||
                    (linkedInvoice as any)?.customerName ||
                    'Customer';

                  const invoiceTotal = getInvoiceTotalForPayment(p);
                  const paidAfterThisPayment = paymentCumulativePaidMap.get(p.id) ?? (Number(p.amount) || 0);
                  const remainAfterThisPayment = Math.max(0, invoiceTotal - paidAfterThisPayment);

                  const methodDisplay = p.method
                    ? (PAYMENT_METHOD_LABELS[p.method] || p.method)
                    : 'Cash';

                  const reversalEligibility = checkPaymentReversalEligibility(p);
                  const canUserReverse = Boolean(permissions?.canReversePayment || userProfile?.role === 'super_admin');
                  const canReverseThisPayment = canUserReverse && reversalEligibility.isEligible;

                  let reverseTooltip = 'Reverse payment';
                  if (!canUserReverse) {
                    reverseTooltip = 'Only Super Admin is authorized to reverse payments.';
                  } else if (p.isVoid) {
                    reverseTooltip = 'Payment has already been reversed.';
                  } else if (reversalEligibility.hasInvalidTimestamp || reversalEligibility.isExpired) {
                    reverseTooltip = 'Reverse window expired (48 hours).';
                  }

                  const isExpanded = expandedRowIds.has(p.id);

                  return (
                    <React.Fragment key={p.id}>
                      <tr
                        id={`payment-row-${p.id}`}
                        onClick={() => setSelectedPaymentForDetails(p)}
                        className={`hover:bg-neutral-50/90 transition cursor-pointer group ${
                          isExpanded ? 'bg-orange-50/20' : ''
                        }`}
                        tabIndex={0}
                        role="button"
                        aria-label={`View payment details for ${customerDisplay} - ${invoiceDisplay}`}
                        onKeyDown={(e) => {
                          if (e.key === 'Enter' || e.key === ' ') {
                            e.preventDefault();
                            setSelectedPaymentForDetails(p);
                          }
                        }}
                      >
                        {visibleColumns.map((col) => {
                          if (col.key === 'invoice') {
                            return (
                              <td key={col.key} className={col.cellClassName}>
                                <div className="flex items-center gap-1.5">
                                  <button
                                    type="button"
                                    id={`btn-expand-payment-${p.id}`}
                                    onClick={(e) => toggleRowExpanded(p.id, e)}
                                    className="p-1 rounded text-neutral-400 hover:text-neutral-700 hover:bg-neutral-200/60 transition cursor-pointer lg:hidden shrink-0"
                                    title={isExpanded ? 'Collapse secondary details' : 'Expand secondary details'}
                                    aria-label={isExpanded ? `Collapse details for ${p.id}` : `Expand details for ${p.id}`}
                                    aria-expanded={isExpanded}
                                  >
                                    <ChevronDown
                                      className={`w-3.5 h-3.5 transition-transform duration-200 ${
                                        isExpanded ? 'rotate-180 text-orange-600' : ''
                                      }`}
                                    />
                                  </button>
                                  <div>
                                    <span className="font-mono font-bold text-orange-600 block">{invoiceDisplay}</span>
                                    <span className="text-[10px] font-mono text-neutral-500 block sm:hidden">
                                      {formattedDate}
                                    </span>
                                  </div>
                                </div>
                              </td>
                            );
                          }
                          if (col.key === 'paymentDateTime') {
                            return (
                              <td key={col.key} className={col.cellClassName}>
                                <span className="font-mono font-medium text-neutral-800">{formattedDate}</span>
                                {formattedTime && (
                                  <span className="text-[11px] font-mono text-neutral-500 block sm:inline sm:ml-1.5">
                                    {formattedTime}
                                  </span>
                                )}
                              </td>
                            );
                          }
                          if (col.key === 'collector') {
                            return (
                              <td key={col.key} className={col.cellClassName}>
                                {collectorDisplay}
                              </td>
                            );
                          }
                          if (col.key === 'customer') {
                            return (
                              <td key={col.key} className={col.cellClassName}>
                                <div className="truncate max-w-[120px] sm:max-w-[160px] lg:max-w-[200px]" title={customerDisplay}>
                                  {customerDisplay}
                                </div>
                              </td>
                            );
                          }
                          if (col.key === 'total') {
                            return (
                              <td key={col.key} className={col.cellClassName}>
                                {formatAFN(invoiceTotal)}
                              </td>
                            );
                          }
                          if (col.key === 'paid') {
                            return (
                              <td key={col.key} className={col.cellClassName}>
                                <span>{formatAFN(paidAfterThisPayment)}</span>
                                <span className="text-[10px] text-neutral-500 font-mono block md:hidden font-normal">
                                  of {formatAFN(invoiceTotal)}
                                </span>
                              </td>
                            );
                          }
                          if (col.key === 'remain') {
                            return (
                              <td key={col.key} className={col.cellClassName}>
                                {formatAFN(remainAfterThisPayment)}
                              </td>
                            );
                          }
                          if (col.key === 'method') {
                            return (
                              <td key={col.key} className={col.cellClassName}>
                                {methodDisplay}
                              </td>
                            );
                          }
                          if (col.key === 'status') {
                            return (
                              <td key={col.key} className={col.cellClassName}>
                                {isReversed ? (
                                  <span className="inline-flex items-center px-2 py-0.5 rounded-full text-[10px] sm:text-xs font-bold bg-rose-50 text-rose-700 border border-rose-200">
                                    Reversed
                                  </span>
                                ) : (
                                  <span className="inline-flex items-center px-2 py-0.5 rounded-full text-[10px] sm:text-xs font-bold bg-emerald-50 text-emerald-700 border border-emerald-200">
                                    Completed
                                  </span>
                                )}
                              </td>
                            );
                          }
                          if (col.key === 'action') {
                            return (
                              <td
                                key={col.key}
                                className={col.cellClassName}
                                onClick={(e) => e.stopPropagation()}
                              >
                                <div className="inline-flex items-center gap-1 sm:gap-1.5 justify-end">
                                  <button
                                    type="button"
                                    id={`btn-view-payment-${p.id}`}
                                    onClick={(e) => {
                                      e.stopPropagation();
                                      setSelectedPaymentForDetails(p);
                                    }}
                                    className="px-2 sm:px-2.5 py-1 text-[11px] sm:text-xs font-semibold text-neutral-700 bg-white hover:bg-neutral-100 hover:text-neutral-900 border border-neutral-300 rounded-md transition shadow-2xs cursor-pointer inline-flex items-center gap-1"
                                    title="View Payment Details"
                                    aria-label="View Payment Details"
                                  >
                                    <span>View</span>
                                  </button>
                                  <button
                                    type="button"
                                    id={`btn-print-payment-${p.id}`}
                                    onClick={(e) => {
                                      e.stopPropagation();
                                      setSelectedReceiptPayment(p);
                                    }}
                                    className="px-2 sm:px-2.5 py-1 text-[11px] sm:text-xs font-semibold text-neutral-700 bg-white hover:bg-neutral-100 hover:text-neutral-900 border border-neutral-300 rounded-md transition shadow-2xs cursor-pointer inline-flex items-center gap-1"
                                    title="Print Payment Receipt"
                                    aria-label="Print Payment Receipt"
                                  >
                                    <span>Print</span>
                                  </button>
                                  <button
                                    type="button"
                                    id={`btn-reverse-payment-${p.id}`}
                                    onClick={(e) => {
                                      e.stopPropagation();
                                      if (canReverseThisPayment) {
                                        openReversalModal(p);
                                      }
                                    }}
                                    disabled={!canReverseThisPayment}
                                    className={`px-2 sm:px-2.5 py-1 text-[11px] sm:text-xs font-semibold rounded-md transition shadow-2xs inline-flex items-center gap-1 ${
                                      canReverseThisPayment
                                        ? 'text-rose-700 bg-white hover:bg-rose-50 hover:text-rose-800 border border-rose-300 cursor-pointer active:scale-[0.98]'
                                        : 'text-neutral-400 bg-neutral-100 border border-neutral-200 cursor-not-allowed opacity-60'
                                    }`}
                                    title={reverseTooltip}
                                    aria-label="Reverse Payment"
                                  >
                                    <span>Reverse</span>
                                  </button>
                                </div>
                              </td>
                            );
                          }
                          return null;
                        })}
                      </tr>
                      {/* Responsive Secondary Details Drawer for Mobile & Tablet */}
                      {isExpanded && (
                        <tr
                          key={`${p.id}-expanded-details`}
                          id={`payment-expanded-${p.id}`}
                          className="bg-neutral-50/90 border-b border-neutral-200 lg:hidden"
                          onClick={(e) => e.stopPropagation()}
                        >
                          <td colSpan={visibleColumns.length} className="px-3.5 py-3 sm:px-6">
                            <div className="bg-white rounded-lg p-3 sm:p-4 border border-neutral-200 shadow-2xs space-y-3">
                              {/* Secondary Info Grid */}
                              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
                                <div>
                                  <span className="text-[10px] font-bold uppercase tracking-wider text-neutral-400 block">
                                    Payment ID
                                  </span>
                                  <span className="font-mono font-semibold text-neutral-800 text-xs">
                                    #{p.id}
                                  </span>
                                </div>
                                <div>
                                  <span className="text-[10px] font-bold uppercase tracking-wider text-neutral-400 block">
                                    Collector
                                  </span>
                                  <span className="font-medium text-neutral-700 text-xs">
                                    {collectorDisplay}
                                  </span>
                                </div>
                                <div>
                                  <span className="text-[10px] font-bold uppercase tracking-wider text-neutral-400 block">
                                    Payment Method
                                  </span>
                                  <span className="font-medium text-neutral-700 text-xs">
                                    {methodDisplay}
                                  </span>
                                </div>
                                <div>
                                  <span className="text-[10px] font-bold uppercase tracking-wider text-neutral-400 block">
                                    Date &amp; Time
                                  </span>
                                  <span className="font-mono text-neutral-700 text-xs">
                                    {formattedDate} {formattedTime ? `at ${formattedTime}` : ''}
                                  </span>
                                </div>
                              </div>

                              {/* Financial Breakdown (Essential on mobile/tablet) */}
                              <div className="pt-2.5 border-t border-neutral-100 flex flex-col sm:flex-row sm:items-center justify-between gap-2.5 text-xs">
                                <div className="flex flex-wrap items-center gap-3 sm:gap-5 font-mono text-xs">
                                  <div>
                                    <span className="text-[10px] text-neutral-400 font-sans block">Invoice Total:</span>
                                    <span className="font-bold text-neutral-900">{formatAFN(invoiceTotal)}</span>
                                  </div>
                                  <div>
                                    <span className="text-[10px] text-neutral-400 font-sans block">Cumulative Paid:</span>
                                    <span className="font-bold text-emerald-700">{formatAFN(paidAfterThisPayment)}</span>
                                  </div>
                                  <div>
                                    <span className="text-[10px] text-neutral-400 font-sans block">Remaining Balance:</span>
                                    <span className="font-bold text-amber-700">{formatAFN(remainAfterThisPayment)}</span>
                                  </div>
                                  {p.amount !== undefined && (
                                    <div>
                                      <span className="text-[10px] text-neutral-400 font-sans block">This Payment:</span>
                                      <span className="font-bold text-neutral-800">{formatAFN(p.amount)}</span>
                                    </div>
                                  )}
                                </div>

                                {/* Quick Actions inside detail view */}
                                <div className="flex items-center gap-2 self-end sm:self-auto pt-1 sm:pt-0">
                                  <button
                                    type="button"
                                    id={`btn-expanded-view-${p.id}`}
                                    onClick={(e) => {
                                      e.stopPropagation();
                                      setSelectedPaymentForDetails(p);
                                    }}
                                    className="px-2.5 py-1 text-xs font-semibold text-neutral-700 bg-white hover:bg-neutral-100 border border-neutral-300 rounded-md transition shadow-2xs cursor-pointer inline-flex items-center gap-1"
                                  >
                                    <span>View Details</span>
                                  </button>
                                  <button
                                    type="button"
                                    id={`btn-expanded-print-${p.id}`}
                                    onClick={(e) => {
                                      e.stopPropagation();
                                      setSelectedReceiptPayment(p);
                                    }}
                                    className="px-2.5 py-1 text-xs font-semibold text-neutral-700 bg-white hover:bg-neutral-100 border border-neutral-300 rounded-md transition shadow-2xs cursor-pointer inline-flex items-center gap-1"
                                  >
                                    <span>Print Receipt</span>
                                  </button>
                                  <button
                                    type="button"
                                    id={`btn-expanded-reverse-${p.id}`}
                                    onClick={(e) => {
                                      e.stopPropagation();
                                      if (canReverseThisPayment) {
                                        openReversalModal(p);
                                      }
                                    }}
                                    disabled={!canReverseThisPayment}
                                    className={`px-2.5 py-1 text-xs font-semibold rounded-md transition shadow-2xs inline-flex items-center gap-1 ${
                                      canReverseThisPayment
                                        ? 'text-rose-700 bg-white hover:bg-rose-50 hover:text-rose-800 border border-rose-300 cursor-pointer active:scale-[0.98]'
                                        : 'text-neutral-400 bg-neutral-100 border border-neutral-200 cursor-not-allowed opacity-60'
                                    }`}
                                    title={reverseTooltip}
                                    aria-label="Reverse Payment"
                                  >
                                    <span>Reverse</span>
                                  </button>
                                </div>
                              </div>

                              {p.note && (
                                <div className="text-xs text-neutral-600 bg-neutral-50 px-2.5 py-1.5 rounded border border-neutral-200/50">
                                  <span className="font-semibold text-neutral-700 mr-1">Note:</span>
                                  {p.note}
                                </div>
                              )}
                            </div>
                          </td>
                        </tr>
                      )}
                    </React.Fragment>
                  );
                })}
              </tbody>
            </table>
          </div>

          {/* Pagination Controls */}
          {totalPayments > 0 && (
            <div
              id="payments-pagination"
              className="px-4 py-3 bg-neutral-50 border-t border-neutral-200 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-neutral-600"
            >
              <div className="text-neutral-600 font-medium">
                Showing <span className="font-semibold text-neutral-900">{startIndex + 1}–{endIndex}</span> of{' '}
                <span className="font-semibold text-neutral-900">{totalPayments}</span> payments
              </div>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  id="btn-prev-payment-page"
                  onClick={() => setCurrentPage((prev) => Math.max(1, prev - 1))}
                  disabled={safeCurrentPage <= 1}
                  className="inline-flex items-center gap-1 px-3 py-1.5 rounded-md border border-neutral-300 bg-white font-medium text-neutral-700 hover:bg-neutral-100 disabled:opacity-40 disabled:cursor-not-allowed disabled:hover:bg-white transition cursor-pointer select-none"
                  aria-label="Previous page"
                  title="Previous page"
                >
                  <ChevronLeft className="w-4 h-4" />
                  <span>Previous</span>
                </button>
                <div className="flex items-center gap-1 px-2 font-mono text-neutral-700 font-medium text-xs">
                  <span>Page {safeCurrentPage} of {totalPages}</span>
                </div>
                <button
                  type="button"
                  id="btn-next-payment-page"
                  onClick={() => setCurrentPage((prev) => Math.min(totalPages, prev + 1))}
                  disabled={safeCurrentPage >= totalPages}
                  className="inline-flex items-center gap-1 px-3 py-1.5 rounded-md border border-neutral-300 bg-white font-medium text-neutral-700 hover:bg-neutral-100 disabled:opacity-40 disabled:cursor-not-allowed disabled:hover:bg-white transition cursor-pointer select-none"
                  aria-label="Next page"
                  title="Next page"
                >
                  <span>Next</span>
                  <ChevronRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          )}
        </>
      )}
      </div>

      {/* Payment Details Modal */}
      {selectedPaymentForDetails && (
        <PaymentDetailModal
          isOpen={!!selectedPaymentForDetails}
          onClose={() => setSelectedPaymentForDetails(null)}
          payment={selectedPaymentForDetails}
          invoice={invoices.find((inv) => inv.id === selectedPaymentForDetails.invoiceId) || null}
          settings={settings}
          onViewReceipt={(p) => setSelectedReceiptPayment(p)}
          onReversePayment={(p) => {
            setSelectedPaymentForDetails(null);
            openReversalModal(p);
          }}
          onSelectInvoice={onSelectInvoice}
        />
      )}

      {/* Official Payment Receipt Modal (Only opened if explicitly requested from inside details) */}
      {selectedReceiptPayment && (
        <PaymentReceiptModal
          isOpen={!!selectedReceiptPayment}
          onClose={() => setSelectedReceiptPayment(null)}
          payment={selectedReceiptPayment}
          invoice={invoices.find((inv) => inv.id === selectedReceiptPayment.invoiceId) || null}
          settings={settings}
        />
      )}

      {/* Reversal Audit Modal for Super Admin */}
      {reversingPayment && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-xs">
          <div className="bg-white rounded-xl shadow-2xl w-full max-w-md overflow-hidden border border-neutral-200">
            <div className="px-5 py-4 border-b border-neutral-200 bg-rose-950 text-white flex items-center gap-2.5">
              <AlertTriangle className="w-5 h-5 text-rose-400" />
              <div>
                <h3 className="text-sm font-bold">Reverse Cash Payment</h3>
                <p className="text-[11px] text-rose-200">Super Admin Audit Reversal</p>
              </div>
            </div>
            <div className="p-5 space-y-4 text-xs">
              {reversalError && (
                <div className="p-2.5 bg-rose-50 border border-rose-200 text-rose-700 rounded-lg">
                  {reversalError}
                </div>
              )}
              {!checkPaymentReversalEligibility(reversingPayment).isEligible && !reversalError && (
                <div className="p-2.5 bg-rose-50 border border-rose-200 text-rose-700 rounded-lg">
                  {checkPaymentReversalEligibility(reversingPayment).reason || 'Reverse window expired (48 hours).'}
                </div>
              )}
              <div className="bg-neutral-50 p-3 rounded-lg border border-neutral-200 space-y-1.5">
                <div className="flex justify-between">
                  <span className="text-neutral-500">Bill Number:</span>
                  <span className="font-bold font-mono text-neutral-900">{reversingPayment.billNumber}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-neutral-500">Customer:</span>
                  <span className="font-semibold text-neutral-800">{reversingPayment.customerName}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-neutral-500">Amount to Void:</span>
                  <span className="font-bold font-mono text-rose-600 text-sm">+{formatAFN(reversingPayment.amount)}</span>
                </div>
              </div>
              <div>
                <label className="font-semibold text-neutral-700 block mb-1">
                  Reason for Reversal / Correction *
                </label>
                <textarea
                  rows={3}
                  required
                  value={reversalReason}
                  onChange={(e) => {
                    setReversalReason(e.target.value);
                    if (reversalError) setReversalError(null);
                  }}
                  placeholder="e.g. Accidental double entry by cashier, customer requested refund..."
                  className="w-full text-xs border border-neutral-300 rounded-lg p-2.5 focus:outline-none focus:ring-1 focus:ring-rose-500"
                />
              </div>
              <div>
                <label className="font-semibold text-neutral-700 block mb-1">
                  Super Admin Password *
                </label>
                <input
                  type="password"
                  required
                  id="reversal-super-admin-password"
                  value={reversalPassword}
                  onChange={(e) => {
                    setReversalPassword(e.target.value);
                    if (reversalError) setReversalError(null);
                  }}
                  placeholder="Enter your Super Admin password..."
                  autoComplete="current-password"
                  className="w-full text-xs border border-neutral-300 rounded-lg p-2.5 focus:outline-none focus:ring-1 focus:ring-rose-500"
                />
                <p className="text-[11px] text-neutral-500 mt-1">
                  Reversing a payment strictly requires your authenticated Super Admin account password.
                </p>
              </div>
              <div className="flex items-center justify-end gap-2 pt-2 border-t border-neutral-200">
                <button
                  type="button"
                  onClick={closeReversalModal}
                  className="px-3 py-1.5 font-medium text-neutral-600 hover:bg-neutral-100 rounded-lg cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="button"
                  id="btn-confirm-reversal"
                  onClick={handleConfirmReversal}
                  disabled={
                    isProcessingReversal ||
                    !checkPaymentReversalEligibility(reversingPayment).isEligible ||
                    !reversalReason.trim() ||
                    !reversalPassword.trim()
                  }
                  className="px-4 py-1.5 font-bold bg-rose-600 hover:bg-rose-700 text-white rounded-lg disabled:opacity-50 disabled:cursor-not-allowed inline-flex items-center gap-1.5 cursor-pointer"
                >
                  {isProcessingReversal ? 'Processing...' : 'Confirm Reversal'}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
