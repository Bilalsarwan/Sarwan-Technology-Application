import React, { useState } from 'react';
import {
  CustomerRequest,
  Customer,
  RequestStatus,
  CustomerRequestReply,
} from '../types';
import {
  updateCustomerRequestStatus,
  addCustomerRequestReply,
} from '../services/db';
import { useAuth } from '../context/AuthContext';
import { toast } from '../context/ToastContext';
import {
  MessageSquare,
  Search,
  Filter,
  Clock,
  CheckCircle2,
  AlertCircle,
  FileText,
  Send,
  User,
  Phone,
  Tag,
  Calendar,
  ChevronRight,
  PlusCircle,
} from 'lucide-react';

interface CustomerRequestsViewProps {
  requests: CustomerRequest[];
  customers: Customer[];
  onGenerateInvoice: (request: CustomerRequest) => void;
  onRequestSelectCustomer?: (customer: Customer) => void;
}

export const CustomerRequestsView: React.FC<CustomerRequestsViewProps> = ({
  requests,
  customers,
  onGenerateInvoice,
  onRequestSelectCustomer,
}) => {
  const { userProfile, permissions } = useAuth();
  const [selectedRequestId, setSelectedRequestId] = useState<string | null>(
    requests.length > 0 ? requests[0].id : null
  );
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [replyText, setReplyText] = useState<string>('');
  const [sendingReply, setSendingReply] = useState<boolean>(false);

  const selectedRequest = requests.find((r) => r.id === selectedRequestId);

  const filteredRequests = requests.filter((req) => {
    if (statusFilter !== 'all' && req.status !== statusFilter) return false;
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      const matchName = req.customerName?.toLowerCase().includes(q);
      const matchPhone = req.customerPhone?.toLowerCase().includes(q);
      const matchTitle = req.title?.toLowerCase().includes(q);
      const matchDesc = req.description?.toLowerCase().includes(q);
      const matchBill = req.billNumber?.toLowerCase().includes(q);
      if (!matchName && !matchPhone && !matchTitle && !matchDesc && !matchBill) {
        return false;
      }
    }
    return true;
  });

  const handleSendReply = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedRequest || !replyText.trim()) return;

    setSendingReply(true);
    try {
      await addCustomerRequestReply(
        selectedRequest.id,
        {
          senderId: userProfile?.id || 'team',
          senderName: userProfile?.name || 'Sarwan Support Team',
          senderRole: userProfile?.role || 'super_admin',
          message: replyText.trim(),
        },
        selectedRequest.replies || []
      );
      setReplyText('');
      // If status was 'New', automatically move to 'In Review'
      if (selectedRequest.status === 'New') {
        await updateCustomerRequestStatus(selectedRequest.id, 'In Review');
      }
      toast.success('Reply sent successfully.');
    } catch (err) {
      console.error('Failed to send reply:', err);
      toast.error('Could not send reply. Please try again.');
    } finally {
      setSendingReply(false);
    }
  };

  const handleStatusChange = async (newStatus: RequestStatus) => {
    if (!selectedRequest) return;
    try {
      await updateCustomerRequestStatus(selectedRequest.id, newStatus);
      toast.success(`Request status updated to "${newStatus}".`);
    } catch (err) {
      console.error('Failed to update status:', err);
      toast.error('Failed to update request status.');
    }
  };

  const getStatusBadge = (status: RequestStatus) => {
    switch (status) {
      case 'New':
        return 'bg-blue-50 text-blue-700 border-blue-200';
      case 'In Review':
        return 'bg-amber-50 text-amber-700 border-amber-200';
      case 'Quoted':
        return 'bg-purple-50 text-purple-700 border-purple-200';
      case 'Invoice Created':
        return 'bg-orange-50 text-orange-700 border-orange-200 font-bold';
      case 'Completed':
        return 'bg-emerald-50 text-emerald-700 border-emerald-200';
      case 'Cancelled':
        return 'bg-red-50 text-red-700 border-red-200';
      default:
        return 'bg-neutral-100 text-neutral-700 border-neutral-200';
    }
  };

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="bg-white rounded-xl p-5 border border-neutral-200 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-xs font-semibold text-orange-600">
            <MessageSquare className="w-4 h-4" />
            <span>Customer Service &amp; Inquiries</span>
          </div>
          <h1 className="text-xl font-bold text-neutral-900 mt-1">
            Customer Requests &amp; Support Tickets
          </h1>
          <p className="text-xs text-neutral-500 mt-0.5">
            Manage inquiries, CCTV installation quotes, maintenance tickets, and convert directly to invoices.
          </p>
        </div>

        {/* Counts summary */}
        <div className="flex items-center gap-2">
          <div className="px-3 py-1.5 bg-neutral-50 rounded-lg border border-neutral-200 text-center">
            <p className="text-[10px] text-neutral-500 font-medium">Total</p>
            <p className="text-sm font-bold text-neutral-800">{requests.length}</p>
          </div>
          <div className="px-3 py-1.5 bg-blue-50 rounded-lg border border-blue-200 text-center">
            <p className="text-[10px] text-blue-600 font-medium">New</p>
            <p className="text-sm font-bold text-blue-700">
              {requests.filter((r) => r.status === 'New').length}
            </p>
          </div>
          <div className="px-3 py-1.5 bg-orange-50 rounded-lg border border-orange-200 text-center">
            <p className="text-[10px] text-orange-600 font-medium">Invoiced</p>
            <p className="text-sm font-bold text-orange-700">
              {requests.filter((r) => r.status === 'Invoice Created').length}
            </p>
          </div>
        </div>
      </div>

      {/* Main 2-Column Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Left Column: Requests List & Filters (5 cols) */}
        <div className="lg:col-span-5 bg-white rounded-xl border border-neutral-200 shadow-xs overflow-hidden">
          <div className="p-3.5 border-b border-neutral-200 bg-neutral-50 space-y-2.5">
            {/* Search */}
            <div className="relative">
              <Search className="w-4 h-4 text-neutral-400 absolute left-3 top-2.5" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search by customer, phone, title..."
                className="w-full pl-9 pr-3 py-1.5 text-xs bg-white border border-neutral-300 rounded-lg focus:outline-none focus:ring-1 focus:ring-orange-500"
              />
            </div>

            {/* Filter */}
            <div className="flex gap-2">
              <select
                value={statusFilter}
                onChange={(e) => setStatusFilter(e.target.value)}
                className="w-full text-xs py-1.5 px-2 bg-white border border-neutral-300 rounded-lg focus:outline-none"
              >
                <option value="all">All Statuses</option>
                <option value="New">New</option>
                <option value="In Review">In Review</option>
                <option value="Quoted">Quoted</option>
                <option value="Invoice Created">Invoice Created</option>
                <option value="Completed">Completed</option>
                <option value="Cancelled">Cancelled</option>
              </select>
            </div>
          </div>

          {/* List items */}
          <div className="divide-y divide-neutral-100 max-h-[600px] overflow-y-auto">
            {filteredRequests.length === 0 ? (
              <div className="p-8 text-center text-neutral-400">
                <MessageSquare className="w-8 h-8 mx-auto mb-2 opacity-40" />
                <p className="text-xs font-semibold">No requests found</p>
                <p className="text-[11px]">No customer inquiries match current filters.</p>
              </div>
            ) : (
              filteredRequests.map((req) => {
                const isSelected = selectedRequestId === req.id;
                return (
                  <div
                    key={req.id}
                    onClick={() => setSelectedRequestId(req.id)}
                    className={`p-3.5 transition cursor-pointer text-left hover:bg-neutral-50 ${
                      isSelected ? 'bg-orange-50/70 border-l-3 border-orange-500' : ''
                    }`}
                  >
                    <div className="flex items-start justify-between gap-2">
                      <div className="min-w-0 flex-1">
                        <div className="flex items-center gap-1.5 mb-1">
                          <span
                            className={`text-[10px] font-bold px-1.5 py-0.5 rounded-full border ${getStatusBadge(
                              req.status
                            )}`}
                          >
                            {req.status}
                          </span>
                          <span className="text-[10px] text-neutral-400 flex items-center gap-1">
                            <Clock className="w-3 h-3" />
                            {new Date(req.createdAt).toLocaleDateString()}
                          </span>
                        </div>
                        <h4 className="text-xs font-bold text-neutral-900 truncate">
                          {req.title}
                        </h4>
                        <p className="text-[11px] text-neutral-500 truncate mt-0.5">
                          {req.customerName} &bull; {req.customerPhone}
                        </p>
                      </div>
                      <ChevronRight
                        className={`w-4 h-4 shrink-0 transition ${
                          isSelected ? 'text-orange-500 translate-x-0.5' : 'text-neutral-300'
                        }`}
                      />
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </div>

        {/* Right Column: Request Detail & Conversation Thread (7 cols) */}
        <div className="lg:col-span-7 bg-white rounded-xl border border-neutral-200 shadow-xs overflow-hidden">
          {selectedRequest ? (
            <div>
              {/* Header */}
              <div className="p-5 border-b border-neutral-200 bg-neutral-50/50">
                <div className="flex flex-wrap items-center justify-between gap-3">
                  <div>
                    <div className="flex items-center gap-2 mb-1">
                      <span
                        className={`text-xs font-bold px-2 py-0.5 rounded-full border ${getStatusBadge(
                          selectedRequest.status
                        )}`}
                      >
                        {selectedRequest.status}
                      </span>
                      <span className="text-xs text-neutral-500 font-medium">
                        Format: {selectedRequest.mediaType || 'Text'}
                      </span>
                    </div>
                    <h2 className="text-base font-bold text-neutral-900">
                      {selectedRequest.title}
                    </h2>
                  </div>

                  {/* Quick action: Convert to Invoice */}
                  {permissions.canCreateInvoice && (
                    <button
                      onClick={() => onGenerateInvoice(selectedRequest)}
                      className="px-3.5 py-2 bg-[#2563EB] hover:bg-[#1D4ED8] active:bg-[#1E40AF] text-white text-xs font-bold rounded-lg shadow-xs transition flex items-center gap-1.5 cursor-pointer active:scale-98 focus:outline-none focus-visible:ring-2 focus-visible:ring-[#2563EB]"
                    >
                      <FileText className="w-4 h-4" />
                      Generate Invoice
                    </button>
                  )}
                </div>

                {/* Customer Card */}
                <div className="mt-4 p-3 bg-white rounded-lg border border-neutral-200 flex flex-wrap items-center justify-between gap-3 text-xs">
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-full bg-orange-100 text-orange-700 font-bold flex items-center justify-center shrink-0">
                      {selectedRequest.customerName?.charAt(0) || 'C'}
                    </div>
                    <div>
                      <p className="font-bold text-neutral-900">
                        {selectedRequest.customerName}
                      </p>
                      <p className="text-[11px] text-neutral-500 flex items-center gap-2">
                        <span>{selectedRequest.customerPhone}</span>
                        {selectedRequest.customerEmail && (
                          <span>&bull; {selectedRequest.customerEmail}</span>
                        )}
                      </p>
                    </div>
                  </div>

                  {/* Status dropdown */}
                  <div className="flex items-center gap-2">
                    <span className="text-[11px] text-neutral-500">Status:</span>
                    <select
                      value={selectedRequest.status}
                      onChange={(e) => handleStatusChange(e.target.value as RequestStatus)}
                      className="text-xs font-semibold py-1 px-2 bg-neutral-100 border border-neutral-300 rounded-md focus:outline-none"
                    >
                      <option value="New">New</option>
                      <option value="In Review">In Review</option>
                      <option value="Quoted">Quoted</option>
                      <option value="Invoice Created">Invoice Created</option>
                      <option value="Completed">Completed</option>
                      <option value="Cancelled">Cancelled</option>
                    </select>
                  </div>
                </div>

                {/* Linked invoice notice */}
                {selectedRequest.billNumber && (
                  <div className="mt-2.5 p-2 bg-orange-50 border border-orange-200 rounded-lg text-xs text-orange-800 flex items-center justify-between">
                    <span>
                      Linked Invoice Generated: <strong>{selectedRequest.billNumber}</strong>
                    </span>
                    <span className="text-[11px] text-orange-600 font-medium">Ready</span>
                  </div>
                )}
              </div>

              {/* Description body */}
              <div className="p-5 border-b border-neutral-200">
                <h4 className="text-xs font-bold text-neutral-700 uppercase tracking-wider mb-2">
                  Request Details &amp; Equipment Requirements
                </h4>
                <div className="p-3.5 bg-neutral-50 rounded-lg border border-neutral-200 text-xs text-neutral-800 leading-relaxed whitespace-pre-line">
                  {selectedRequest.description}
                </div>
              </div>

              {/* Discussion thread / replies */}
              <div className="p-5 space-y-4">
                <h4 className="text-xs font-bold text-neutral-700 uppercase tracking-wider">
                  Conversation &amp; Notes History ({selectedRequest.replies?.length || 0})
                </h4>

                <div className="space-y-3 max-h-72 overflow-y-auto pr-1">
                  {(!selectedRequest.replies || selectedRequest.replies.length === 0) ? (
                    <p className="text-xs text-neutral-400 italic py-2">
                      No replies or staff notes yet. Add the first reply below.
                    </p>
                  ) : (
                    selectedRequest.replies.map((rep) => {
                      const isStaff = rep.senderRole !== 'customer';
                      return (
                        <div
                          key={rep.id}
                          className={`p-3 rounded-lg text-xs ${
                            isStaff
                              ? 'bg-neutral-900 text-white ml-6'
                              : 'bg-orange-50 text-neutral-900 border border-orange-200 mr-6'
                          }`}
                        >
                          <div className="flex items-center justify-between gap-2 mb-1">
                            <span className="font-bold text-[11px] opacity-90">
                              {rep.senderName} {isStaff ? '(Staff)' : '(Customer)'}
                            </span>
                            <span className="text-[10px] opacity-60">
                              {new Date(rep.createdAt).toLocaleTimeString([], {
                                hour: '2-digit',
                                minute: '2-digit',
                              })}
                            </span>
                          </div>
                          <p className="whitespace-pre-line leading-relaxed">{rep.message}</p>
                        </div>
                      );
                    })
                  )}
                </div>

                {/* Reply box */}
                <form onSubmit={handleSendReply} className="mt-4 pt-4 border-t border-neutral-200">
                  <div className="flex gap-2">
                    <input
                      type="text"
                      value={replyText}
                      onChange={(e) => setReplyText(e.target.value)}
                      placeholder="Type a reply or internal note for this request..."
                      className="flex-1 text-xs px-3 py-2 bg-neutral-50 border border-neutral-300 rounded-lg focus:outline-none focus:bg-white focus:ring-1 focus:ring-orange-500"
                    />
                    <button
                      type="submit"
                      disabled={sendingReply || !replyText.trim()}
                      className="px-4 py-2 bg-[#2563EB] hover:bg-[#1D4ED8] active:bg-[#1E40AF] text-white text-xs font-bold rounded-lg shadow-xs transition flex items-center gap-1.5 disabled:opacity-50 cursor-pointer focus:outline-none focus-visible:ring-2 focus-visible:ring-[#2563EB]"
                    >
                      <Send className="w-3.5 h-3.5" />
                      <span>{sendingReply ? 'Sending...' : 'Reply'}</span>
                    </button>
                  </div>
                </form>
              </div>
            </div>
          ) : (
            <div className="p-16 text-center text-neutral-400">
              <MessageSquare className="w-10 h-10 mx-auto mb-2 opacity-40" />
              <p className="text-sm font-semibold text-neutral-700">Select a Request</p>
              <p className="text-xs text-neutral-500">
                Choose a customer inquiry or support ticket from the list on the left to view details.
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
