import React, { useState } from 'react';
import { AuditLog } from '../types';
import {
  ShieldAlert,
  Search,
  Filter,
  Clock,
  User,
  FileText,
  DollarSign,
  Settings,
  Download,
  CheckCircle2,
  ChevronDown,
  ChevronUp,
} from 'lucide-react';

interface AuditLogsViewProps {
  logs: AuditLog[];
}

export const AuditLogsView: React.FC<AuditLogsViewProps> = ({ logs }) => {
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [actionFilter, setActionFilter] = useState<string>('all');
  const [expandedLogId, setExpandedLogId] = useState<string | null>(null);

  const filteredLogs = logs.filter((log) => {
    if (actionFilter !== 'all' && log.action !== actionFilter) return false;
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      const matchUser = log.userName?.toLowerCase().includes(q);
      const matchSummary = log.summary?.toLowerCase().includes(q);
      const matchRef = log.referenceNumber?.toLowerCase().includes(q);
      const matchEntity = log.entityId?.toLowerCase().includes(q);
      if (!matchUser && !matchSummary && !matchRef && !matchEntity) return false;
    }
    return true;
  });

  const getActionBadge = (action: AuditLog['action']) => {
    switch (action) {
      case 'create_invoice':
        return 'bg-blue-50 text-blue-700 border-blue-200';
      case 'edit_invoice':
        return 'bg-amber-50 text-amber-700 border-amber-200';
      case 'void_invoice':
        return 'bg-red-50 text-red-700 border-red-200';
      case 'record_payment':
        return 'bg-emerald-50 text-emerald-700 border-emerald-200';
      case 'reverse_payment':
        return 'bg-rose-50 text-rose-700 border-rose-200';
      case 'create_customer':
      case 'edit_customer':
        return 'bg-purple-50 text-purple-700 border-purple-200';
      case 'update_settings':
      case 'change_role':
        return 'bg-neutral-100 text-neutral-700 border-neutral-300';
      default:
        return 'bg-neutral-100 text-neutral-600 border-neutral-200';
    }
  };

  const exportLogsAsCSV = () => {
    if (filteredLogs.length === 0) return;
    const headers = ['ID', 'Date & Time', 'Action', 'User', 'Reference', 'Summary'];
    const rows = filteredLogs.map((l) => [
      l.id,
      l.dateTime,
      l.action,
      l.userName,
      l.referenceNumber || '',
      `"${(l.summary || '').replace(/"/g, '""')}"`,
    ]);
    const csvContent = [headers.join(','), ...rows.map((r) => r.join(','))].join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', `sarwan_audit_trail_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="bg-white rounded-xl p-5 border border-neutral-200 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-xs font-semibold text-orange-600">
            <ShieldAlert className="w-4 h-4" />
            <span>Audit Trail &amp; Compliance</span>
          </div>
          <h1 className="text-xl font-bold text-neutral-900 mt-1">
            System Audit &amp; Activity Logs
          </h1>
          <p className="text-xs text-neutral-500 mt-0.5">
            Immutable log of all invoice creations, edits, voidings, payments, reversals, and role modifications.
          </p>
        </div>

        <button
          onClick={exportLogsAsCSV}
          disabled={filteredLogs.length === 0}
          className="px-3.5 py-2 bg-[#2563EB] hover:bg-[#1D4ED8] active:bg-[#1E40AF] text-white text-xs font-bold rounded-lg shadow-xs transition flex items-center gap-2 disabled:opacity-50 cursor-pointer focus:outline-none focus-visible:ring-2 focus-visible:ring-[#2563EB]"
        >
          <Download className="w-4 h-4" />
          <span>Export Audit CSV</span>
        </button>
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-white rounded-xl p-4 border border-neutral-200 shadow-xs flex flex-wrap items-center justify-between gap-3">
        <div className="relative flex-1 min-w-[240px]">
          <Search className="w-4 h-4 text-neutral-400 absolute left-3 top-2.5" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search by user, summary, bill number..."
            className="w-full pl-9 pr-3 py-1.5 text-xs bg-neutral-50 border border-neutral-300 rounded-lg focus:outline-none focus:bg-white focus:ring-1 focus:ring-orange-500"
          />
        </div>

        <div className="flex items-center gap-2">
          <Filter className="w-4 h-4 text-neutral-400" />
          <select
            value={actionFilter}
            onChange={(e) => setActionFilter(e.target.value)}
            className="text-xs py-1.5 px-3 bg-neutral-50 border border-neutral-300 rounded-lg focus:outline-none font-medium"
          >
            <option value="all">All Actions ({logs.length})</option>
            <option value="create_invoice">Create Invoice</option>
            <option value="edit_invoice">Edit Invoice</option>
            <option value="void_invoice">Void Invoice</option>
            <option value="record_payment">Record Payment</option>
            <option value="reverse_payment">Reverse/Void Payment</option>
            <option value="create_customer">Create Customer</option>
            <option value="edit_customer">Edit Customer</option>
            <option value="update_settings">Update Settings</option>
            <option value="change_role">User Roles &amp; Permissions</option>
          </select>
        </div>
      </div>

      {/* Table of logs */}
      <div className="bg-white rounded-xl border border-neutral-200 shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-neutral-50 text-neutral-500 border-b border-neutral-200 uppercase tracking-wider font-semibold">
              <tr>
                <th className="px-4 py-3">Date &amp; Time</th>
                <th className="px-4 py-3">Action</th>
                <th className="px-4 py-3">User</th>
                <th className="px-4 py-3">Reference</th>
                <th className="px-4 py-3">Summary</th>
                <th className="px-4 py-3 text-right">Details</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-neutral-100">
              {filteredLogs.length === 0 ? (
                <tr>
                  <td colSpan={6} className="px-4 py-12 text-center text-neutral-400">
                    No activity logs recorded matching criteria.
                  </td>
                </tr>
              ) : (
                filteredLogs.map((log) => {
                  const isExpanded = expandedLogId === log.id;
                  const hasChanges = log.changes && log.changes.length > 0;
                  return (
                    <React.Fragment key={log.id}>
                      <tr className="hover:bg-neutral-50/70 transition">
                        <td className="px-4 py-3 font-mono text-[11px] text-neutral-500 whitespace-nowrap">
                          {new Date(log.dateTime).toLocaleString('en-GB', {
                            day: '2-digit',
                            month: 'short',
                            year: 'numeric',
                            hour: '2-digit',
                            minute: '2-digit',
                            second: '2-digit',
                          })}
                        </td>
                        <td className="px-4 py-3 whitespace-nowrap">
                          <span
                            className={`text-[10px] font-bold px-2 py-0.5 rounded-full border ${getActionBadge(
                              log.action
                            )}`}
                          >
                            {log.action.replace('_', ' ').toUpperCase()}
                          </span>
                        </td>
                        <td className="px-4 py-3 font-semibold text-neutral-800 whitespace-nowrap">
                          {log.userName}
                        </td>
                        <td className="px-4 py-3 font-mono font-bold text-neutral-700 whitespace-nowrap">
                          {log.referenceNumber || '—'}
                        </td>
                        <td className="px-4 py-3 text-neutral-700 max-w-md truncate">
                          {log.summary}
                        </td>
                        <td className="px-4 py-3 text-right whitespace-nowrap">
                          {hasChanges ? (
                            <button
                              onClick={() => setExpandedLogId(isExpanded ? null : log.id)}
                              className="inline-flex items-center gap-1 text-[11px] text-orange-600 font-bold hover:underline"
                            >
                              <span>{isExpanded ? 'Hide Diffs' : 'View Diffs'}</span>
                              {isExpanded ? (
                                <ChevronUp className="w-3.5 h-3.5" />
                              ) : (
                                <ChevronDown className="w-3.5 h-3.5" />
                              )}
                            </button>
                          ) : (
                            <span className="text-[11px] text-neutral-400">—</span>
                          )}
                        </td>
                      </tr>

                      {/* Expandable Diffs */}
                      {isExpanded && hasChanges && (
                        <tr className="bg-neutral-50">
                          <td colSpan={6} className="px-6 py-3 border-b border-neutral-200">
                            <div className="bg-white p-3 rounded-lg border border-neutral-200 space-y-1.5">
                              <p className="text-[11px] font-bold text-neutral-700">
                                Field Modifications:
                              </p>
                              <div className="space-y-1">
                                {log.changes!.map((ch, cIdx) => (
                                  <div
                                    key={cIdx}
                                    className="text-xs font-mono grid grid-cols-3 gap-2 py-1 border-b border-neutral-100 last:border-b-0"
                                  >
                                    <span className="font-semibold text-neutral-600">
                                      {ch.field}:
                                    </span>
                                    <span className="text-red-600 line-through">
                                      {String(ch.oldValue ?? 'none')}
                                    </span>
                                    <span className="text-emerald-600 font-bold">
                                      &rarr; {String(ch.newValue ?? 'none')}
                                    </span>
                                  </div>
                                ))}
                              </div>
                            </div>
                          </td>
                        </tr>
                      )}
                    </React.Fragment>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
