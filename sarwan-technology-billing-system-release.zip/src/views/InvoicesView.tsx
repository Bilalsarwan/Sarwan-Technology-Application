import React, { useState, useMemo, useEffect } from 'react';
import { Invoice, Payment, BusinessSettings, InvoiceStatus, UserProfile } from '../types';
import {
  formatAFN,
  formatAfghani,
  formatDate,
  calculateTotalPaidForInvoice,
  calculateRemaining,
} from '../utils/format';
import { useAuth } from '../context/AuthContext';
import { getAuthorizedInvoices } from '../services/dashboardAuthorization';
import { InvoiceAssignmentModal } from '../components/invoice/InvoiceAssignmentModal';
import { InvoicePdfDownloadModal } from '../components/invoice/InvoicePdfDownloadModal';
import { isInvoiceLocked } from '../utils/invoiceCalculator';
import {
  Search,
  Plus,
  FileText,
  Download,
  Printer,
  Eye,
  Lock,
  Ban,
  Loader2,
  ArrowUpDown,
  ArrowUp,
  ArrowDown,
  UserCheck,
  AlertTriangle,
  ChevronLeft,
  ChevronRight,
  ChevronDown,
  ChevronUp,
  SlidersHorizontal,
  X,
  Clock,
  XCircle,
} from 'lucide-react';

export type InvoiceSortField =
  | 'bill'
  | 'customer'
  | 'date'
  | 'amount'
  | 'paid'
  | 'remaining'
  | 'status'
  | 'collector';

export type InvoiceSortOption =
  | 'bill-desc'
  | 'bill-asc'
  | 'customer-asc'
  | 'customer-desc'
  | 'date-desc'
  | 'date-asc'
  | 'amount-desc'
  | 'amount-asc'
  | 'paid-desc'
  | 'paid-asc'
  | 'remaining-desc'
  | 'remaining-asc'
  | 'status-asc'
  | 'status-desc'
  | 'collector-asc'
  | 'collector-desc';

export const INVOICES_PER_PAGE = 10;

interface InvoicesViewProps {
  invoices: Invoice[];
  payments: Payment[];
  settings: BusinessSettings;
  users?: UserProfile[];
  initialStatusFilter?: string;
  onNewInvoice: () => void;
  onSelectInvoice: (invoice: Invoice) => void;
  onEditInvoice: (invoice: Invoice) => void;
  onAssignInvoice?: (invoice: Invoice) => void;
}

export const InvoicesView: React.FC<InvoicesViewProps> = ({
  invoices,
  payments,
  settings,
  users = [],
  initialStatusFilter,
  onNewInvoice,
  onSelectInvoice,
  onEditInvoice,
  onAssignInvoice,
}) => {
  const { userProfile, permissions } = useAuth();

  const [downloadingInvoiceId, setDownloadingInvoiceId] = useState<string | null>(null);
  const [pdfModalInvoice, setPdfModalInvoice] = useState<Invoice | null>(null);
  const [invoiceToAssign, setInvoiceToAssign] = useState<Invoice | null>(null);
  const [searchTerm, setSearchTerm] = useState<string>('');
  const [statusFilter, setStatusFilter] = useState<string>(initialStatusFilter || 'all');

  useEffect(() => {
    if (initialStatusFilter) {
      setStatusFilter(initialStatusFilter);
    }
  }, [initialStatusFilter]);

  const [startDate, setStartDate] = useState<string>('');
  const [endDate, setEndDate] = useState<string>('');
  const [sortBy, setSortBy] = useState<InvoiceSortOption>('bill-desc');
  const [currentPage, setCurrentPage] = useState<number>(1);

  // Unified collapsible Filters & Summary Panel (default: collapsed / false)
  const [isFiltersOpen, setIsFiltersOpen] = useState<boolean>(false);

  // Active filter tracking
  const hasActiveFilters = Boolean(
    searchTerm.trim() ||
    statusFilter !== 'all' ||
    startDate ||
    endDate ||
    sortBy !== 'bill-desc'
  );

  const activeFilterCount =
    (searchTerm.trim() ? 1 : 0) +
    (statusFilter !== 'all' ? 1 : 0) +
    (startDate || endDate ? 1 : 0) +
    (sortBy !== 'bill-desc' ? 1 : 0);

  // Detect when both start date and end date are selected and end date is earlier than start date
  const isInvalidDateRange = Boolean(startDate && endDate && endDate < startDate);

  // Determine if the current authenticated user has permission to assign collectors
  // Super Admin and Invoice Manager are authorized; Payment Collectors and Customers are strictly prohibited
  const canAssign = Boolean(
    (userProfile?.role === 'super_admin' ||
      userProfile?.role === 'invoice_manager' ||
      permissions?.canAssignInvoice) &&
    userProfile?.role !== 'customer' &&
    userProfile?.role !== 'payment_collector'
  );

  const handleAssignClick = (inv: Invoice) => {
    if (!canAssign) return;
    const fin = invoiceFinancials.get(inv.id);
    const isLocked = fin?.isLockedOrPaid ?? isInvoiceLocked(inv);
    const isVoid = fin?.isVoid ?? Boolean(inv.isVoid || inv.status === 'Void');
    if (isLocked || isVoid) {
      return;
    }
    if (onAssignInvoice) {
      onAssignInvoice(inv);
    } else {
      setInvoiceToAssign(inv);
    }
  };

  // Role-based visibility: Collectors see only assigned invoices, Admin/Manager see all
  const authorizedInvoices = useMemo(() => {
    return getAuthorizedInvoices(userProfile, invoices);
  }, [userProfile, invoices]);

  // Pre-calculate payment summaries & actual statuses for all authorized invoices
  const invoiceFinancials = useMemo(() => {
    const map = new Map<
      string,
      {
        paid: number;
        remaining: number;
        actualStatus: InvoiceStatus;
        isLockedOrPaid: boolean;
        isVoid: boolean;
      }
    >();

    for (const inv of authorizedInvoices) {
      const isVoid = Boolean(inv.isVoid === true || inv.status === 'Void');
      const paidFromPayments = calculateTotalPaidForInvoice(inv.id, payments);
      const paid = Math.max(paidFromPayments, Number(inv.totalPaid) || 0);
      const total = Number(inv.totalAmount) || 0;
      // If void, remaining balance must not be interpreted as an active outstanding balance
      const remaining = isVoid ? 0 : calculateRemaining(total, paid);

      const isLockedOrPaid = Boolean(
        isVoid ||
        inv.isLocked ||
        inv.status === 'Paid' ||
        (total > 0 && paid >= total) ||
        (total === 0 && paid === 0 && inv.status === 'Paid') ||
        (total > 0 && remaining <= 0)
      );

      let actualStatus: InvoiceStatus = 'Unpaid';
      if (isVoid) {
        // Void has absolute priority!
        // A Void invoice must always resolve to: status = 'Void'
        actualStatus = 'Void';
      } else if (isLockedOrPaid || remaining <= 0) {
        actualStatus = 'Paid';
      } else if (paid > 0 || inv.status === 'Partially Paid') {
        actualStatus = 'Partially Paid';
      } else {
        actualStatus = 'Unpaid';
      }

      map.set(inv.id, {
        paid,
        remaining,
        actualStatus,
        isLockedOrPaid,
        isVoid,
      });
    }

    return map;
  }, [authorizedInvoices, payments]);

  // Filter & Search pipeline
  const filteredInvoices = useMemo(() => {
    return authorizedInvoices
      .filter((inv) => {
        const financials = invoiceFinancials.get(inv.id);
        const actualStatus = financials?.actualStatus || (inv.isVoid ? 'Void' : inv.status) || 'Unpaid';

        // 1. Search term (Bill No, Customer Name, Customer Phone, Company Name)
        const term = searchTerm.toLowerCase().trim();
        if (term) {
          const matchBill = inv.billNumber?.toLowerCase().includes(term);
          const matchCust = inv.customerSnapshot?.name?.toLowerCase().includes(term);

          // Customer Phone search: normalize spaces, hyphens (-), and parentheses
          const cleanPhoneSearch = term.replace(/[\s\-()]/g, '');
          const cleanStoredPhone = (inv.customerSnapshot?.phone || '').toLowerCase().replace(/[\s\-()]/g, '');
          const matchPhone = Boolean(
            cleanPhoneSearch.length > 0 && cleanStoredPhone.includes(cleanPhoneSearch)
          );

          const matchCompany = inv.customerSnapshot?.companyName?.toLowerCase().includes(term);
          if (!matchBill && !matchCust && !matchPhone && !matchCompany) {
            return false;
          }
        }

        // 2. Status filter: evaluates against actual invoice/payment state & billingState
        if (statusFilter !== 'all') {
          if (statusFilter === 'quotation') {
            if (inv.billingState !== 'quotation') return false;
          } else if (statusFilter === 'rejected') {
            if (inv.billingState !== 'rejected') return false;
          } else if (statusFilter === 'payable') {
            if (inv.billingState === 'quotation' || inv.billingState === 'rejected' || inv.isVoid || inv.status === 'Void') return false;
          } else if (statusFilter === 'Void') {
            if (actualStatus !== 'Void') return false;
          } else {
            // For Paid, Partially Paid, Unpaid: must be payable and match actualStatus
            if (inv.billingState === 'quotation' || inv.billingState === 'rejected') return false;
            if (actualStatus !== statusFilter) return false;
          }
        }

        // 3. Date range filter
        // If the date range is invalid (endDate is earlier than startDate),
        // do not silently return an empty result. Instead, show validation message in UI.
        if (!isInvalidDateRange) {
          if (startDate && inv.date < startDate) {
            return false;
          }
          if (endDate && inv.date > endDate) {
            return false;
          }
        }

        return true;
      })
      .sort((a, b) => {
        const finA = invoiceFinancials.get(a.id);
        const finB = invoiceFinancials.get(b.id);
        const paidA = finA?.paid ?? calculateTotalPaidForInvoice(a.id, payments);
        const paidB = finB?.paid ?? calculateTotalPaidForInvoice(b.id, payments);
        const remainingA = finA?.remaining ?? calculateRemaining(a.totalAmount, paidA);
        const remainingB = finB?.remaining ?? calculateRemaining(b.totalAmount, paidB);
        const statusA = finA?.actualStatus ?? (a.isVoid ? 'Void' : a.status) ?? 'Unpaid';
        const statusB = finB?.actualStatus ?? (b.isVoid ? 'Void' : b.status) ?? 'Unpaid';

        switch (sortBy) {
          case 'bill-asc':
            return (a.billNumber || '').localeCompare(b.billNumber || '', undefined, { numeric: true });
          case 'bill-desc':
            return (b.billNumber || '').localeCompare(a.billNumber || '', undefined, { numeric: true });
          case 'customer-asc':
            return (a.customerSnapshot?.name || '').localeCompare(b.customerSnapshot?.name || '');
          case 'customer-desc':
            return (b.customerSnapshot?.name || '').localeCompare(a.customerSnapshot?.name || '');
          case 'date-desc':
            return b.date.localeCompare(a.date);
          case 'date-asc':
            return a.date.localeCompare(b.date);
          case 'amount-desc':
            return (Number(b.totalAmount) || 0) - (Number(a.totalAmount) || 0);
          case 'amount-asc':
            return (Number(a.totalAmount) || 0) - (Number(b.totalAmount) || 0);
          case 'paid-desc':
            return paidB - paidA;
          case 'paid-asc':
            return paidA - paidB;
          case 'remaining-desc':
            return remainingB - remainingA;
          case 'remaining-asc':
            return remainingA - remainingB;
          case 'status-asc':
            return statusA.localeCompare(statusB);
          case 'status-desc':
            return statusB.localeCompare(statusA);
          case 'collector-asc':
            return (a.assignedCollectorName || '').localeCompare(b.assignedCollectorName || '');
          case 'collector-desc':
            return (b.assignedCollectorName || '').localeCompare(a.assignedCollectorName || '');
          default:
            return (b.billNumber || '').localeCompare(a.billNumber || '', undefined, { numeric: true });
        }
      });
  }, [authorizedInvoices, invoiceFinancials, searchTerm, statusFilter, startDate, endDate, sortBy, payments]);

  // When search, filters, or sorting change, return to page 1
  useEffect(() => {
    setCurrentPage(1);
  }, [searchTerm, statusFilter, startDate, endDate, sortBy]);

  // Pagination calculation (strictly 10 invoices per page)
  const totalInvoices = filteredInvoices.length;
  const totalPages = Math.max(1, Math.ceil(totalInvoices / INVOICES_PER_PAGE));
  const safeCurrentPage = Math.min(Math.max(1, currentPage), totalPages);
  const startIndex = (safeCurrentPage - 1) * INVOICES_PER_PAGE;
  const endIndex = Math.min(startIndex + INVOICES_PER_PAGE, totalInvoices);

  const paginatedInvoices = useMemo(() => {
    return filteredInvoices.slice(startIndex, startIndex + INVOICES_PER_PAGE);
  }, [filteredInvoices, startIndex]);

  // Handle interactive click-to-sort on table header columns
  const handleSort = (field: InvoiceSortField) => {
    const isCurrentField = sortBy.startsWith(`${field}-`);
    const currentDirection = isCurrentField ? (sortBy.endsWith('-asc') ? 'asc' : 'desc') : null;

    if (currentDirection === 'desc') {
      setSortBy(`${field}-asc`);
    } else if (currentDirection === 'asc') {
      setSortBy(`${field}-desc`);
    } else {
      // Inactive field clicked: text fields default to 'asc', numeric/date default to 'desc'
      const defaultAsc = ['customer', 'status', 'collector'].includes(field);
      setSortBy(`${field}-${defaultAsc ? 'asc' : 'desc'}` as InvoiceSortOption);
    }
  };

  const renderSortIndicator = (field: InvoiceSortField) => {
    const isCurrentField = sortBy.startsWith(`${field}-`);
    const isAsc = sortBy === `${field}-asc`;

    if (isCurrentField) {
      return isAsc ? (
        <ArrowUp className="w-3.5 h-3.5 text-[#F58220] shrink-0" />
      ) : (
        <ArrowDown className="w-3.5 h-3.5 text-[#F58220] shrink-0" />
      );
    }

    return (
      <ArrowUpDown className="w-3.5 h-3.5 text-neutral-400 group-hover:text-neutral-200 opacity-60 group-hover:opacity-100 shrink-0 transition-opacity" />
    );
  };

  const getAriaSort = (field: InvoiceSortField): 'ascending' | 'descending' | 'none' => {
    if (sortBy === `${field}-asc`) return 'ascending';
    if (sortBy === `${field}-desc`) return 'descending';
    return 'none';
  };

  const getSortTooltip = (label: string, field: InvoiceSortField) => {
    if (sortBy === `${field}-desc`) {
      return `Sorted by ${label} (Descending). Click to sort Ascending.`;
    }
    if (sortBy === `${field}-asc`) {
      return `Sorted by ${label} (Ascending). Click to sort Descending.`;
    }
    return `Click to sort by ${label}.`;
  };

  // Aggregate stats of filtered set
  const totalFilteredAmount = useMemo(() => {
    return filteredInvoices.reduce((sum, inv) => {
      const isVoid = inv.isVoid === true || inv.status === 'Void';
      const isQuotation = inv.billingState === 'quotation';
      const isRejected = inv.billingState === 'rejected';
      // In active sales summary (when viewing all or active statuses), void, quotation, and rejected invoices are excluded
      // When explicitly viewing Void, quotation, or rejected filter, shows face value of those items
      if (isVoid && statusFilter !== 'Void') return sum;
      if (isQuotation && statusFilter !== 'quotation') return sum;
      if (isRejected && statusFilter !== 'rejected') return sum;
      return sum + (Number(inv.totalAmount) || 0);
    }, 0);
  }, [filteredInvoices, statusFilter]);

  const totalFilteredPaid = useMemo(() => {
    return filteredInvoices.reduce((sum, inv) => {
      const isVoid = inv.isVoid === true || inv.status === 'Void';
      if (isVoid && statusFilter !== 'Void') return sum;
      if (inv.billingState === 'quotation' || inv.billingState === 'rejected') return sum;
      const fin = invoiceFinancials.get(inv.id);
      return sum + (fin?.paid ?? calculateTotalPaidForInvoice(inv.id, payments));
    }, 0);
  }, [filteredInvoices, invoiceFinancials, payments, statusFilter]);

  const totalFilteredRemaining = useMemo(() => {
    return filteredInvoices.reduce((sum, inv) => {
      const isVoid = inv.isVoid === true || inv.status === 'Void';
      // Void, quotation, and rejected invoices have 0 active outstanding receivables!
      if (isVoid || inv.billingState === 'quotation' || inv.billingState === 'rejected') return sum;
      const fin = invoiceFinancials.get(inv.id);
      return sum + (fin?.remaining ?? 0);
    }, 0);
  }, [filteredInvoices, invoiceFinancials]);

  // Safe handler for edit: rejects if invoice is locked, fully paid, or void
  const handleEditClick = (inv: Invoice) => {
    const fin = invoiceFinancials.get(inv.id);
    const isLocked = fin?.isLockedOrPaid ?? false;
    const isVoid = fin?.isVoid ?? Boolean(inv.isVoid || inv.status === 'Void');

    // Strict validation: Fully paid, locked, or void invoices cannot be edited
    if (isLocked || isVoid) {
      return;
    }

    if (!permissions.canEditInvoice) {
      return;
    }

    onEditInvoice(inv);
  };

  const handleDownloadInvoice = (inv: Invoice) => {
    setPdfModalInvoice(inv);
  };

  return (
    <div className="space-y-3 sm:space-y-4">
      {/* Header and Action Controls */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h1 className="text-xl font-bold text-neutral-900">Invoices</h1>
          <p className="text-xs text-neutral-500">
            Search, filter, export, and track all business billing documents.
          </p>
        </div>
        <div className="flex flex-wrap items-center gap-2 self-start sm:self-auto">
          {/* One single Filters button controls the entire unified panel */}
          <button
            type="button"
            onClick={() => setIsFiltersOpen((prev) => !prev)}
            className={`px-3 py-2 text-xs font-semibold rounded-lg border transition inline-flex items-center gap-1.5 cursor-pointer select-none focus:outline-none focus-visible:ring-2 focus-visible:ring-[#2563EB] ${
              isFiltersOpen
                ? 'bg-blue-50 text-blue-700 border-blue-300 shadow-2xs'
                : 'bg-white text-neutral-700 border-neutral-300 hover:bg-neutral-50 shadow-2xs'
            }`}
            title={isFiltersOpen ? 'Hide Filters & Summary' : 'Show Filters & Summary'}
            aria-expanded={isFiltersOpen}
          >
            <SlidersHorizontal className="w-3.5 h-3.5" />
            <span>Filters</span>
            {hasActiveFilters && (
              <span className="px-1.5 py-0.2 rounded-full text-[9px] font-bold bg-blue-100 text-blue-800">
                {activeFilterCount}
              </span>
            )}
            {isFiltersOpen ? (
              <ChevronUp className="w-3.5 h-3.5 text-blue-600" />
            ) : (
              <ChevronDown className="w-3.5 h-3.5 text-neutral-400" />
            )}
          </button>

          {permissions.canCreateInvoice && (
            <button
              onClick={onNewInvoice}
              className="px-4 py-2 bg-[#2563EB] hover:bg-[#1D4ED8] active:bg-[#1E40AF] text-white text-xs font-bold rounded-lg shadow-xs transition inline-flex items-center justify-center gap-1.5 active:scale-98 cursor-pointer focus:outline-none focus-visible:ring-2 focus-visible:ring-[#2563EB]"
            >
              <Plus className="w-4 h-4" />
              New Invoice
            </button>
          )}
        </div>
      </div>

      {/* UNIFIED COLLAPSIBLE FILTERS & SUMMARY PANEL */}
      {isFiltersOpen && (
        <div className="bg-white p-4 rounded-xl border border-neutral-200 shadow-xs space-y-4 animate-in fade-in duration-150">
          {/* 1. Filter Controls Grid */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-3">
            {/* Search box */}
            <div className="relative md:col-span-2">
              <Search className="w-4 h-4 text-neutral-400 absolute left-3 top-2.5" />
              <input
                type="text"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder="Search by Bill No (e.g. ST-1060), Customer, Phone, Company..."
                className="w-full text-xs pl-9 pr-3 py-2 border border-neutral-300 rounded-lg focus:outline-none focus:ring-1 focus:ring-orange-500"
              />
            </div>

            {/* Status selector */}
            <div>
              <select
                value={statusFilter}
                onChange={(e) => setStatusFilter(e.target.value)}
                className="w-full text-xs border border-neutral-300 rounded-lg px-3 py-2 bg-white focus:outline-none focus:ring-1 focus:ring-orange-500 cursor-pointer"
              >
                <option value="all">All Invoices</option>
                <option value="quotation">Quotation / Pending Approval</option>
                <option value="payable">Payable (Confirmed Sales)</option>
                <option value="Paid">Paid</option>
                <option value="Partially Paid">Partially Paid</option>
                <option value="Unpaid">Unpaid</option>
                <option value="rejected">Rejected</option>
                <option value="Void">Void</option>
              </select>
            </div>

            {/* Sort selector */}
            <div>
              <select
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value as any)}
                className="w-full text-xs border border-neutral-300 rounded-lg px-3 py-2 bg-white focus:outline-none focus:ring-1 focus:ring-orange-500 cursor-pointer"
              >
                <option value="bill-desc">Sort by Bill No (Latest first)</option>
                <option value="bill-asc">Sort by Bill No (Oldest first)</option>
                <option value="customer-asc">Sort by Customer (A to Z)</option>
                <option value="customer-desc">Sort by Customer (Z to A)</option>
                <option value="date-desc">Sort by Date (Newest first)</option>
                <option value="date-asc">Sort by Date (Oldest first)</option>
                <option value="amount-desc">Sort by Total Amount (Highest)</option>
                <option value="amount-asc">Sort by Total Amount (Lowest)</option>
                <option value="paid-desc">Sort by Cash Received (Highest)</option>
                <option value="paid-asc">Sort by Cash Received (Lowest)</option>
                <option value="remaining-desc">Sort by Remaining (Highest)</option>
                <option value="remaining-asc">Sort by Remaining (Lowest)</option>
                <option value="status-asc">Sort by Status (A to Z)</option>
                <option value="status-desc">Sort by Status (Z to A)</option>
                <option value="collector-asc">Sort by Collector (A to Z)</option>
                <option value="collector-desc">Sort by Collector (Z to A)</option>
              </select>
            </div>
          </div>

          {/* 2. Date Range & Filter Metadata Row */}
          <div className="flex flex-wrap items-center gap-3 pt-2 border-t border-neutral-100 text-xs">
            <span className="text-neutral-500 font-medium">Date Range:</span>
            <div className="flex items-center gap-2">
              <input
                type="date"
                value={startDate}
                onChange={(e) => setStartDate(e.target.value)}
                className={`text-xs font-mono border rounded px-2 py-1 focus:outline-none focus:ring-1 ${
                  isInvalidDateRange
                    ? 'border-rose-400 bg-rose-50/30 text-rose-900 focus:ring-rose-500'
                    : 'border-neutral-300 focus:ring-orange-500'
                }`}
              />
              <span className="text-neutral-400">to</span>
              <input
                type="date"
                value={endDate}
                onChange={(e) => setEndDate(e.target.value)}
                className={`text-xs font-mono border rounded px-2 py-1 focus:outline-none focus:ring-1 ${
                  isInvalidDateRange
                    ? 'border-rose-400 bg-rose-50/30 text-rose-900 focus:ring-rose-500'
                    : 'border-neutral-300 focus:ring-orange-500'
                }`}
              />
            </div>
            {(startDate || endDate || searchTerm || statusFilter !== 'all' || sortBy !== 'bill-desc') && (
              <button
                type="button"
                onClick={() => {
                  setSearchTerm('');
                  setStatusFilter('all');
                  setStartDate('');
                  setEndDate('');
                  setSortBy('bill-desc');
                  setCurrentPage(1);
                }}
                className="text-[11px] text-blue-600 hover:text-blue-700 font-semibold cursor-pointer underline"
              >
                Reset Filters
              </button>
            )}

            <div className="ml-auto flex items-center gap-3 text-neutral-500 font-medium">
              <span>
                Showing <span className="font-bold text-neutral-900">{filteredInvoices.length}</span>{' '}
                of {authorizedInvoices.length} invoices
              </span>
              <button
                type="button"
                onClick={() => setIsFiltersOpen(false)}
                className="text-[11px] text-neutral-400 hover:text-neutral-700 font-semibold cursor-pointer underline"
                title="Hide Filters Panel"
              >
                Hide
              </button>
            </div>
          </div>

          {/* Invalid Date Range Validation Message */}
          {isInvalidDateRange && (
            <div
              role="alert"
              className="flex items-center gap-2 p-2.5 bg-rose-50 border border-rose-200 text-rose-700 rounded-lg text-xs"
            >
              <AlertTriangle className="w-4 h-4 text-rose-600 shrink-0" />
              <span>
                <strong>Invalid Date Range:</strong> End date ({endDate}) cannot be earlier than start date ({startDate}). Please select an end date on or after the start date.
              </span>
            </div>
          )}

          {/* 3. Filter Data / Summary Cards (Unified inside the Filters Panel) */}
          <div className="pt-3 border-t border-neutral-100">
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div className="bg-neutral-50/70 p-3.5 rounded-lg border border-neutral-200 text-xs">
                <span className="text-neutral-500 block">
                  {statusFilter === 'Void' ? 'Total Voided Amount:' : 'Total Filtered Sales:'}
                </span>
                <span className="text-base font-bold font-mono text-neutral-900">
                  {formatAfghani(totalFilteredAmount)}
                </span>
              </div>
              <div className="bg-emerald-50/50 p-3.5 rounded-lg border border-emerald-200/80 text-xs">
                <span className="text-emerald-700 block">
                  {statusFilter === 'Void' ? 'Historical Cash Received:' : 'Total Cash Received:'}
                </span>
                <span className="text-base font-bold font-mono text-emerald-600">
                  {formatAfghani(totalFilteredPaid)}
                </span>
              </div>
              <div className="bg-orange-50/50 p-3.5 rounded-lg border border-orange-200/80 text-xs">
                <span className="text-orange-600 block">
                  {statusFilter === 'Void' ? 'Active Outstanding Balance:' : 'Total Remaining Balance:'}
                </span>
                <span className="text-base font-bold font-mono text-orange-600">
                  {formatAfghani(totalFilteredRemaining)}
                </span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Invoices Table */}
      <div className="bg-[var(--app-surface-card,#FFFFFF)] rounded-xl border border-[var(--app-border,#E2E8F0)] shadow-xs overflow-hidden transition-colors">
        {filteredInvoices.length === 0 ? (
          <div className="p-12 text-center text-xs text-[var(--app-text-muted,#64748B)]">
            <FileText className="w-10 h-10 text-[var(--app-border-strong,#CBD5E1)] mx-auto mb-3" />
            <p className="font-bold text-sm text-[var(--app-text-primary,#0F172A)]">No invoices match your criteria.</p>
            <p className="mt-1 text-[var(--app-text-muted,#64748B)]">Try adjusting your search terms or filters.</p>
          </div>
        ) : (
          <>
            <div className="overflow-x-auto">
            <table className="w-full border-collapse text-xs">
              <thead>
                <tr className="bg-[var(--color-surface-sidebar,#0A0F1D)] text-white font-semibold text-left">
                  {/* Bill Number Header */}
                  <th
                    scope="col"
                    aria-sort={getAriaSort('bill')}
                    className="py-2.5 sm:py-3 px-2 sm:px-4 whitespace-nowrap"
                  >
                    <button
                      type="button"
                      onClick={() => handleSort('bill')}
                      className="group inline-flex items-center gap-1 sm:gap-1.5 font-semibold text-white hover:text-orange-400 cursor-pointer select-none transition-colors"
                      title={getSortTooltip('Bill No.', 'bill')}
                    >
                      <span className={sortBy.startsWith('bill-') ? 'text-orange-400' : ''}>
                        Bill No.
                      </span>
                      {renderSortIndicator('bill')}
                    </button>
                  </th>

                  {/* Customer Header */}
                  <th
                    scope="col"
                    aria-sort={getAriaSort('customer')}
                    className="py-2.5 sm:py-3 px-2 sm:px-4"
                  >
                    <button
                      type="button"
                      onClick={() => handleSort('customer')}
                      className="group inline-flex items-center gap-1 sm:gap-1.5 font-semibold text-white hover:text-orange-400 cursor-pointer select-none transition-colors"
                      title={getSortTooltip('Customer Name', 'customer')}
                    >
                      <span className={sortBy.startsWith('customer-') ? 'text-orange-400' : ''}>
                        Customer
                      </span>
                      {renderSortIndicator('customer')}
                    </button>
                  </th>

                  {/* Date Header (Medium/Tablet sm: and up) */}
                  <th
                    scope="col"
                    aria-sort={getAriaSort('date')}
                    className="py-2.5 sm:py-3 px-2 sm:px-4 hidden sm:table-cell whitespace-nowrap"
                  >
                    <button
                      type="button"
                      onClick={() => handleSort('date')}
                      className="group inline-flex items-center gap-1 sm:gap-1.5 font-semibold text-white hover:text-orange-400 cursor-pointer select-none transition-colors"
                      title={getSortTooltip('Date', 'date')}
                    >
                      <span className={sortBy.startsWith('date-') ? 'text-orange-400' : ''}>
                        Date
                      </span>
                      {renderSortIndicator('date')}
                    </button>
                  </th>

                  {/* Total Price Header */}
                  <th
                    scope="col"
                    aria-sort={getAriaSort('amount')}
                    className="py-2.5 sm:py-3 px-2 sm:px-4 text-right whitespace-nowrap"
                  >
                    <div className="flex justify-end">
                      <button
                        type="button"
                        onClick={() => handleSort('amount')}
                        className="group inline-flex items-center gap-1 sm:gap-1.5 font-semibold text-white hover:text-orange-400 cursor-pointer select-none transition-colors"
                        title={getSortTooltip('Total Price', 'amount')}
                      >
                        <span className={sortBy.startsWith('amount-') ? 'text-orange-400' : ''}>
                          Total Price
                        </span>
                        {renderSortIndicator('amount')}
                      </button>
                    </div>
                  </th>

                  {/* Cash Received Header (Medium/Tablet md: and up) */}
                  <th
                    scope="col"
                    aria-sort={getAriaSort('paid')}
                    className="py-2.5 sm:py-3 px-2 sm:px-4 text-right whitespace-nowrap hidden md:table-cell"
                  >
                    <div className="flex justify-end">
                      <button
                        type="button"
                        onClick={() => handleSort('paid')}
                        className="group inline-flex items-center gap-1 sm:gap-1.5 font-semibold text-white hover:text-orange-400 cursor-pointer select-none transition-colors"
                        title={getSortTooltip('Cash Received', 'paid')}
                      >
                        <span className={sortBy.startsWith('paid-') ? 'text-orange-400' : ''}>
                          Cash Received
                        </span>
                        {renderSortIndicator('paid')}
                      </button>
                    </div>
                  </th>

                  {/* Remaining Header (Medium/Tablet md: and up) */}
                  <th
                    scope="col"
                    aria-sort={getAriaSort('remaining')}
                    className="py-2.5 sm:py-3 px-2 sm:px-4 text-right whitespace-nowrap hidden md:table-cell"
                  >
                    <div className="flex justify-end">
                      <button
                        type="button"
                        onClick={() => handleSort('remaining')}
                        className="group inline-flex items-center gap-1 sm:gap-1.5 font-semibold text-white hover:text-orange-400 cursor-pointer select-none transition-colors"
                        title={getSortTooltip('Remaining Balance', 'remaining')}
                      >
                        <span className={sortBy.startsWith('remaining-') ? 'text-orange-400' : ''}>
                          Remaining
                        </span>
                        {renderSortIndicator('remaining')}
                      </button>
                    </div>
                  </th>

                  {/* Status Header */}
                  <th
                    scope="col"
                    aria-sort={getAriaSort('status')}
                    className="py-2.5 sm:py-3 px-1.5 sm:px-4 text-center whitespace-nowrap"
                  >
                    <div className="flex justify-center">
                      <button
                        type="button"
                        onClick={() => handleSort('status')}
                        className="group inline-flex items-center gap-1 sm:gap-1.5 font-semibold text-white hover:text-orange-400 cursor-pointer select-none transition-colors"
                        title={getSortTooltip('Payment Status', 'status')}
                      >
                        <span className={sortBy.startsWith('status-') ? 'text-orange-400' : ''}>
                          Status
                        </span>
                        {renderSortIndicator('status')}
                      </button>
                    </div>
                  </th>

                  {/* Collector Header (Desktop lg: and up) */}
                  <th
                    scope="col"
                    aria-sort={getAriaSort('collector')}
                    className="py-2.5 sm:py-3 px-2 sm:px-4 text-left whitespace-nowrap hidden lg:table-cell"
                  >
                    <button
                      type="button"
                      onClick={() => handleSort('collector')}
                      className="group inline-flex items-center gap-1 sm:gap-1.5 font-semibold text-white hover:text-orange-400 cursor-pointer select-none transition-colors"
                      title={getSortTooltip('Assigned Collector', 'collector')}
                    >
                      <span className={sortBy.startsWith('collector-') ? 'text-orange-400' : ''}>
                        Collector
                      </span>
                      {renderSortIndicator('collector')}
                    </button>
                  </th>

                  {/* Actions Header (Always visible) */}
                  <th scope="col" className="py-2.5 sm:py-3 px-2 sm:px-4 text-right whitespace-nowrap font-semibold text-white">
                    Actions
                  </th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[var(--app-border-subtle,#F1F5F9)]">
                {paginatedInvoices.map((inv) => {
                  const fin = invoiceFinancials.get(inv.id);
                  const isVoid = fin?.isVoid ?? Boolean(inv.isVoid === true || inv.status === 'Void');
                  const isQuotation = inv.billingState === 'quotation';
                  const isRejected = inv.billingState === 'rejected';
                  const isPayable = !isQuotation && !isRejected;
                  const paid = fin?.paid ?? calculateTotalPaidForInvoice(inv.id, payments);
                  const remaining = isVoid ? 0 : (fin?.remaining ?? calculateRemaining(inv.totalAmount, paid));
                  const status: InvoiceStatus = fin?.actualStatus ?? (isVoid ? 'Void' : inv.status) ?? 'Unpaid';
                  const isLockedOrPaid =
                    fin?.isLockedOrPaid ??
                    Boolean(
                      isVoid ||
                      inv.isLocked ||
                      status === 'Paid' ||
                      (Number(inv.totalAmount) > 0 && paid >= Number(inv.totalAmount)) ||
                      remaining <= 0
                    );
                  const isEditDisabled = isLockedOrPaid || isVoid || isRejected || !permissions.canEditInvoice;

                  return (
                    <tr
                      key={inv.id}
                      className="hover:bg-[var(--color-interactive-hover,#F1F5F9)] transition-colors duration-150 ease-in-out cursor-pointer"
                      onClick={() => onSelectInvoice(inv)}
                    >
                      {/* 1. Bill Number (Always visible) */}
                      <td className="py-2.5 sm:py-3 px-2 sm:px-4 font-mono font-bold text-orange-600 whitespace-nowrap">
                        <div className="flex items-center gap-1 sm:gap-1.5">
                          <span>{inv.billNumber}</span>
                          {isVoid ? (
                            <span
                              title="Void Invoice"
                              className="inline-flex items-center gap-0.5 px-1 sm:px-1.5 py-0.5 rounded text-[10px] bg-neutral-200 text-neutral-800 font-sans font-medium border border-neutral-300"
                            >
                              <Ban className="w-3 h-3 text-neutral-600 shrink-0" />
                              <span className="hidden sm:inline text-[9px]">Void</span>
                            </span>
                          ) : isQuotation ? (
                            <span
                              title="Quotation / Pending Approval"
                              className="inline-flex items-center gap-0.5 px-1 sm:px-1.5 py-0.5 rounded text-[10px] bg-amber-100 text-amber-800 font-sans font-medium border border-amber-300"
                            >
                              <Clock className="w-3 h-3 text-amber-600 shrink-0" />
                              <span className="hidden sm:inline text-[9px]">Quotation</span>
                            </span>
                          ) : isRejected ? (
                            <span
                              title="Quotation Rejected"
                              className="inline-flex items-center gap-0.5 px-1 sm:px-1.5 py-0.5 rounded text-[10px] bg-rose-100 text-rose-800 font-sans font-medium border border-rose-300"
                            >
                              <XCircle className="w-3 h-3 text-rose-600 shrink-0" />
                              <span className="hidden sm:inline text-[9px]">Rejected</span>
                            </span>
                          ) : isLockedOrPaid ? (
                            <span
                              title="Locked (Fully Paid)"
                              className="inline-flex items-center gap-0.5 px-1 py-0.5 rounded text-[10px] bg-neutral-100 text-neutral-600 font-sans font-medium"
                            >
                              <Lock className="w-3 h-3 text-neutral-500 shrink-0" />
                              <span className="hidden sm:inline text-[9px]">Locked</span>
                            </span>
                          ) : null}
                        </div>
                      </td>

                      {/* 2. Customer Name (Always visible) */}
                      <td className="py-2.5 sm:py-3 px-2 sm:px-4 font-semibold text-neutral-900">
                        <div className="truncate max-w-[100px] sm:max-w-[170px] md:max-w-none" title={inv.customerSnapshot?.name || 'Customer'}>
                          {inv.customerSnapshot?.name || 'Customer'}
                        </div>
                        {inv.customerSnapshot?.companyName && (
                          <span
                            className="hidden sm:block text-[11px] text-neutral-500 font-normal truncate max-w-[170px] md:max-w-xs"
                            title={inv.customerSnapshot.companyName}
                          >
                            {inv.customerSnapshot.companyName}
                          </span>
                        )}
                      </td>

                      {/* 3. Date (Medium/Tablet sm: and up) */}
                      <td className="py-2.5 sm:py-3 px-2 sm:px-4 text-neutral-600 whitespace-nowrap hidden sm:table-cell">
                        {formatDate(inv.date)}
                      </td>

                      {/* 4. Total Price (Always visible) */}
                      <td className="py-2.5 sm:py-3 px-2 sm:px-4 text-right font-mono font-bold text-neutral-900 whitespace-nowrap">
                        {formatAfghani(inv.totalAmount)}
                      </td>

                      {/* 5. Cash Received / Paid Amount (Medium/Tablet md: and up) */}
                      <td className="py-2.5 sm:py-3 px-2 sm:px-4 text-right font-mono font-bold whitespace-nowrap hidden md:table-cell">
                        {isQuotation || isRejected ? (
                          <span className="text-neutral-400 font-normal text-xs">—</span>
                        ) : (
                          <span className="text-emerald-700">{formatAfghani(paid)}</span>
                        )}
                      </td>

                      {/* 6. Remaining Balance (Medium/Tablet md: and up) */}
                      <td className="py-2.5 sm:py-3 px-2 sm:px-4 text-right font-mono font-bold text-neutral-900 whitespace-nowrap hidden md:table-cell">
                        {isVoid ? (
                          <span className="text-neutral-400 font-normal">
                            ؋ 0
                            <span className="text-[10px] block font-sans text-neutral-400">(Void)</span>
                          </span>
                        ) : isQuotation ? (
                          <span className="text-amber-600 font-normal text-xs">
                            —
                            <span className="text-[10px] block font-sans text-amber-600">(Quotation)</span>
                          </span>
                        ) : isRejected ? (
                          <span className="text-rose-600 font-normal text-xs">
                            —
                            <span className="text-[10px] block font-sans text-rose-600">(Rejected)</span>
                          </span>
                        ) : (
                          formatAfghani(remaining)
                        )}
                      </td>

                      {/* 7. Status (Always visible) */}
                      <td className="py-2.5 sm:py-3 px-1.5 sm:px-4 text-center whitespace-nowrap">
                        {status === 'Void' ? (
                          <span className="inline-flex items-center gap-1 px-1.5 sm:px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-neutral-200 text-neutral-800 border border-neutral-300">
                            <Ban className="w-2.5 h-2.5 text-neutral-700 inline shrink-0" />
                            Void
                          </span>
                        ) : isQuotation ? (
                          <span className="inline-flex items-center gap-1 px-1.5 sm:px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-amber-100 text-amber-800 border border-amber-300">
                            <Clock className="w-2.5 h-2.5 text-amber-700 inline shrink-0" />
                            <span className="sm:hidden">Quotation</span>
                            <span className="hidden sm:inline">Quotation / Pending Approval</span>
                          </span>
                        ) : isRejected ? (
                          <span className="inline-flex items-center gap-1 px-1.5 sm:px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-rose-100 text-rose-800 border border-rose-300">
                            <XCircle className="w-2.5 h-2.5 text-rose-700 inline shrink-0" />
                            Rejected
                          </span>
                        ) : (
                          <span
                            className={`inline-flex items-center gap-1 px-1.5 sm:px-2.5 py-0.5 rounded-full text-[10px] font-bold ${
                              status === 'Paid'
                                ? 'bg-emerald-100 text-emerald-800'
                                : status === 'Partially Paid'
                                ? 'bg-amber-100 text-amber-800'
                                : 'bg-rose-100 text-rose-800'
                            }`}
                          >
                            {status === 'Paid' && (
                              <Lock className="w-2.5 h-2.5 text-emerald-700 inline shrink-0" />
                            )}
                            {status === 'Partially Paid' ? (
                              <>
                                <span className="sm:hidden">Partial</span>
                                <span className="hidden sm:inline">Partially Paid</span>
                              </>
                            ) : (
                              status
                            )}
                          </span>
                        )}
                      </td>

                      {/* 8. Assigned Collector (Desktop lg: and up) */}
                      <td className="py-2.5 sm:py-3 px-2 sm:px-4 text-left whitespace-nowrap hidden lg:table-cell">
                        {isQuotation ? (
                          <span
                            className="text-neutral-400 font-normal text-xs"
                            title="Collector assignment is disabled for quotations."
                          >
                            —
                          </span>
                        ) : isRejected ? (
                          <span
                            className="text-neutral-400 font-normal text-xs"
                            title="Collector assignment is disabled for rejected quotations."
                          >
                            —
                          </span>
                        ) : inv.assignedCollectorName ? (
                          <div
                            className="flex items-center gap-1.5"
                            title={isLockedOrPaid ? 'Invoice is locked. Collector assignment cannot be changed.' : undefined}
                          >
                            <span className="text-neutral-800 font-medium text-xs">
                              {inv.assignedCollectorName}
                            </span>
                            {canAssign && !isLockedOrPaid && !isVoid && isPayable && (
                              <button
                                type="button"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  handleAssignClick(inv);
                                }}
                                className="text-[10px] text-orange-600 hover:text-orange-700 font-semibold hover:underline cursor-pointer"
                                title={`Reassign Collector for ${inv.billNumber}`}
                              >
                                Change
                              </button>
                            )}
                          </div>
                        ) : canAssign && !isLockedOrPaid && !isVoid && isPayable ? (
                          <button
                            type="button"
                            onClick={(e) => {
                              e.stopPropagation();
                              handleAssignClick(inv);
                            }}
                            className="inline-flex items-center gap-1 text-[11px] text-[#F58220] hover:text-[#e0751a] font-semibold hover:underline cursor-pointer"
                            title={`Assign Collector for ${inv.billNumber}`}
                          >
                            <UserCheck className="w-3 h-3" />
                            <span>Assign</span>
                          </button>
                        ) : (
                          <span
                            className="text-neutral-400 font-normal text-xs"
                            title={
                              isLockedOrPaid
                                ? 'Invoice is locked. Collector assignment cannot be changed.'
                                : isVoid
                                ? 'Void invoices cannot have collectors assigned.'
                                : undefined
                            }
                          >
                            -
                          </span>
                        )}
                      </td>

                      {/* 9. Actions (Always visible) */}
                      <td className="py-2.5 sm:py-3 px-2 sm:px-4 text-right whitespace-nowrap" onClick={(e) => e.stopPropagation()}>
                        <div className="flex items-center justify-end gap-1 sm:gap-1.5">
                          {/* View Action - always available on all screens */}
                          <button
                            type="button"
                            onClick={() => onSelectInvoice(inv)}
                            className="p-1.5 text-neutral-500 hover:text-neutral-900 hover:bg-neutral-100 rounded transition cursor-pointer"
                            title="View Invoice Details"
                            aria-label="View Invoice Details"
                          >
                            <Eye className="w-4 h-4 text-neutral-600" />
                          </button>

                          {/* Assign Collector Action - visible for authorized users on md: and up when unlocked, non-void, and payable */}
                          {canAssign && !isLockedOrPaid && !isVoid && isPayable && (
                            <button
                              type="button"
                              onClick={(e) => {
                                e.stopPropagation();
                                handleAssignClick(inv);
                              }}
                              className="hidden md:inline-flex p-1.5 text-neutral-500 hover:text-blue-600 hover:bg-blue-50 rounded transition cursor-pointer"
                              title={
                                inv.assignedCollectorName
                                  ? `Reassign Collector (Current: ${inv.assignedCollectorName})`
                                  : 'Assign Invoice to Collector'
                              }
                              aria-label={
                                inv.assignedCollectorName
                                  ? `Reassign Collector (Current: ${inv.assignedCollectorName})`
                                  : 'Assign Invoice to Collector'
                              }
                            >
                              <UserCheck className="w-4 h-4 text-neutral-600 hover:text-blue-600" />
                            </button>
                          )}

                          {/* Download Action - visible on tablet and desktop */}
                          <button
                            type="button"
                            onClick={(e) => {
                              e.stopPropagation();
                              handleDownloadInvoice(inv);
                            }}
                            disabled={downloadingInvoiceId === inv.id}
                            className="hidden md:inline-flex p-1.5 text-neutral-500 hover:text-blue-600 hover:bg-blue-50 rounded transition cursor-pointer disabled:opacity-50"
                            title="Print / Save Invoice as PDF"
                            aria-label="Print / Save Invoice as PDF"
                          >
                            {downloadingInvoiceId === inv.id ? (
                              <Loader2 className="w-4 h-4 text-blue-600 animate-spin" />
                            ) : (
                              <Printer className="w-4 h-4 text-neutral-600 hover:text-blue-600" />
                            )}
                          </button>

                          {/* Edit / Update Action:
                              - If locked, void, or no permission: does not appear as an active action!
                              - On small mobile: inactive/disabled button is not shown, keeping row compact.
                              - On larger screens (sm: and up): disabled button shows lock/void reason.
                          */}
                          {isEditDisabled ? (
                            <button
                              type="button"
                              disabled
                              className="hidden sm:inline-flex text-xs px-2.5 py-1 font-medium rounded transition items-center gap-1 select-none text-neutral-400 bg-neutral-100 border border-neutral-200 cursor-not-allowed opacity-60 pointer-events-none"
                              title={
                                isVoid
                                  ? 'This invoice is void. Void invoices cannot be modified.'
                                  : isLockedOrPaid
                                  ? 'Invoice is locked (Fully Paid). Modifications disabled.'
                                  : 'You do not have permission to edit invoices.'
                              }
                              aria-disabled="true"
                            >
                              {isVoid ? (
                                <Ban className="w-3 h-3 text-neutral-400 shrink-0" />
                              ) : isLockedOrPaid ? (
                                <Lock className="w-3 h-3 text-neutral-400 shrink-0" />
                              ) : null}
                              Edit
                            </button>
                          ) : (
                            <button
                              type="button"
                              onClick={(e) => {
                                e.stopPropagation();
                                handleEditClick(inv);
                              }}
                              className="hidden sm:inline-flex text-xs px-2 sm:px-2.5 py-1 font-medium rounded transition items-center gap-1 select-none text-neutral-700 bg-white hover:bg-neutral-100 border border-neutral-300 hover:text-neutral-900 cursor-pointer shadow-xs active:scale-95"
                              title="Edit Invoice"
                              aria-label="Edit Invoice"
                            >
                              Edit
                            </button>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>

          {/* Pagination Controls */}
          <div className="px-4 py-3 bg-[var(--app-bg-muted,#F1F5F9)] border-t border-[var(--app-border,#E2E8F0)] flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-[var(--app-text-secondary,#475569)] transition-colors">
            <div className="text-[var(--app-text-secondary,#475569)] font-medium">
              Showing <span className="font-semibold text-[var(--app-text-primary,#0F172A)]">{startIndex + 1}–{endIndex}</span> of{' '}
              <span className="font-semibold text-[var(--app-text-primary,#0F172A)]">{totalInvoices}</span> invoices
            </div>
            <div className="flex items-center gap-2">
              <button
                type="button"
                id="btn-prev-invoice-page"
                onClick={() => setCurrentPage((prev) => Math.max(1, prev - 1))}
                disabled={safeCurrentPage <= 1}
                className="inline-flex items-center gap-1 px-3 py-1.5 rounded-md border border-[var(--app-border,#E2E8F0)] bg-[var(--app-surface-card,#FFFFFF)] font-medium text-[var(--app-text-primary,#0F172A)] hover:bg-[var(--color-interactive-hover,#F1F5F9)] disabled:opacity-40 disabled:cursor-not-allowed disabled:hover:bg-[var(--app-surface-card,#FFFFFF)] transition cursor-pointer select-none"
                aria-label="Previous page"
                title="Previous page"
              >
                <ChevronLeft className="w-4 h-4" />
                <span>Previous</span>
              </button>
              <div className="flex items-center gap-1 px-2 font-mono text-[var(--app-text-primary,#0F172A)] font-medium text-xs">
                <span>Page {safeCurrentPage} of {totalPages}</span>
              </div>
              <button
                type="button"
                id="btn-next-invoice-page"
                onClick={() => setCurrentPage((prev) => Math.min(totalPages, prev + 1))}
                disabled={safeCurrentPage >= totalPages}
                className="inline-flex items-center gap-1 px-3 py-1.5 rounded-md border border-[var(--app-border,#E2E8F0)] bg-[var(--app-surface-card,#FFFFFF)] font-medium text-[var(--app-text-primary,#0F172A)] hover:bg-[var(--color-interactive-hover,#F1F5F9)] disabled:opacity-40 disabled:cursor-not-allowed disabled:hover:bg-[var(--app-surface-card,#FFFFFF)] transition cursor-pointer select-none"
                aria-label="Next page"
                title="Next page"
              >
                <span>Next</span>
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        </>
        )}
      </div>

      {invoiceToAssign && (
        <InvoiceAssignmentModal
          isOpen={Boolean(invoiceToAssign)}
          onClose={() => setInvoiceToAssign(null)}
          invoice={invoiceToAssign}
          users={users}
        />
      )}

      {pdfModalInvoice && (
        <InvoicePdfDownloadModal
          isOpen={Boolean(pdfModalInvoice)}
          onClose={() => setPdfModalInvoice(null)}
          invoice={pdfModalInvoice}
          payments={payments}
          settings={settings}
          userProfile={userProfile}
        />
      )}
    </div>
  );
};
