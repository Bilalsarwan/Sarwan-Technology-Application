import React, { useState, useMemo } from 'react';
import { Invoice, Payment, Expense, BusinessSettings } from '../types';
import {
  formatAFN,
  formatDate,
  calculateTotalPaidForInvoice,
  calculateRemaining,
  getTodayDateString,
} from '../utils/format';
import { downloadElementAsPdf } from '../utils/pdf';
import { toast } from '../context/ToastContext';
import {
  BarChart3,
  Calendar,
  Download,
  DollarSign,
  TrendingUp,
  Receipt,
  FileText,
  Clock,
  ArrowUpRight,
  ArrowDownRight,
} from 'lucide-react';

interface ReportsViewProps {
  invoices: Invoice[];
  payments: Payment[];
  expenses: Expense[];
  settings: BusinessSettings;
}

type ReportPeriod = 'daily' | 'monthly' | 'yearly' | 'custom';

export const ReportsView: React.FC<ReportsViewProps> = ({
  invoices,
  payments,
  expenses,
  settings,
}) => {
  const todayStr = getTodayDateString();
  const currentMonthStr = todayStr.slice(0, 7); // YYYY-MM
  const currentYearStr = todayStr.slice(0, 4); // YYYY

  const [period, setPeriod] = useState<ReportPeriod>('monthly');
  const [customStart, setCustomStart] = useState<string>(`${currentMonthStr}-01`);
  const [customEnd, setCustomEnd] = useState<string>(todayStr);
  const [expenseTypeFilter, setExpenseTypeFilter] = useState<'all' | 'invoice_linked' | 'general'>('all');

  // Fast invoice lookup map for linking invoice numbers and customer details
  const invoiceMap = useMemo(() => {
    const map = new Map<string, Invoice>();
    invoices.forEach((inv) => {
      if (inv.id) map.set(inv.id, inv);
    });
    return map;
  }, [invoices]);

  // Determine effective start and end dates
  const { startDate, endDate, periodLabel } = useMemo(() => {
    if (period === 'daily') {
      return {
        startDate: todayStr,
        endDate: todayStr,
        periodLabel: `Daily Report: ${formatDate(todayStr)}`,
      };
    }
    if (period === 'monthly') {
      return {
        startDate: `${currentMonthStr}-01`,
        endDate: `${currentMonthStr}-31`,
        periodLabel: `Monthly Report: ${new Date().toLocaleString('en-US', {
          month: 'long',
          year: 'numeric',
        })}`,
      };
    }
    if (period === 'yearly') {
      return {
        startDate: `${currentYearStr}-01-01`,
        endDate: `${currentYearStr}-12-31`,
        periodLabel: `Annual Report: ${currentYearStr}`,
      };
    }
    // Custom
    return {
      startDate: customStart,
      endDate: customEnd,
      periodLabel: `Custom Period: ${formatDate(customStart)} to ${formatDate(customEnd)}`,
    };
  }, [period, todayStr, currentMonthStr, currentYearStr, customStart, customEnd]);

  // Filter Data
  const periodInvoices = useMemo(() => {
    return invoices.filter((inv) => inv.date >= startDate && inv.date <= endDate);
  }, [invoices, startDate, endDate]);

  const periodPayableInvoices = useMemo(() => {
    return periodInvoices.filter(
      (inv) =>
        !inv.isVoid &&
        inv.status !== 'Void' &&
        inv.billingState !== 'quotation' &&
        inv.billingState !== 'rejected'
    );
  }, [periodInvoices]);

  const periodPayments = useMemo(() => {
    return payments.filter((p) => !p.isVoid && p.date >= startDate && p.date <= endDate);
  }, [payments, startDate, endDate]);

  // Authoritative deduplicated period expenses (prevents counting records twice)
  const periodExpenses = useMemo(() => {
    const seenIds = new Set<string>();
    const list: Expense[] = [];
    for (const e of expenses) {
      if (!e) continue;
      if (e.id) {
        if (seenIds.has(e.id)) continue;
        seenIds.add(e.id);
      }
      if (
        (e.status === 'approved' || e.status === 'executed') &&
        e.date >= startDate &&
        e.date <= endDate
      ) {
        list.push(e);
      }
    }
    return list;
  }, [expenses, startDate, endDate]);

  // Filtered expenses based on invoice-linked status
  const filteredPeriodExpenses = useMemo(() => {
    if (expenseTypeFilter === 'invoice_linked') {
      return periodExpenses.filter((e) => Boolean(e.invoiceId || e.billNumber));
    }
    if (expenseTypeFilter === 'general') {
      return periodExpenses.filter((e) => !e.invoiceId && !e.billNumber);
    }
    return periodExpenses;
  }, [periodExpenses, expenseTypeFilter]);

  const invoiceLinkedExpensesCount = useMemo(() => {
    return periodExpenses.filter((e) => Boolean(e.invoiceId || e.billNumber)).length;
  }, [periodExpenses]);

  // Calculations
  const totalInvoicesCount = periodInvoices.length;
  const totalSales = periodPayableInvoices.reduce((sum, inv) => sum + (Number(inv.totalAmount) || 0), 0);
  const totalCashReceived = periodPayments.reduce((sum, p) => sum + (Number(p.amount) || 0), 0);
  const totalExpenses = periodExpenses.reduce((sum, e) => sum + (Number(e.amount) || 0), 0);

  // Receivable = Sales - Cash Received
  const totalReceivable = Math.max(0, totalSales - totalCashReceived);

  // Net Result = Total Sales - Total Expenses (Strict Rule: DO NOT call Gross Profit)
  const netResult = totalSales - totalExpenses;

  return (
    <div className="space-y-6">
      {/* Header and Print/Export Actions */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold text-neutral-900">Financial Reports</h1>
          <p className="text-xs text-neutral-500">
            Audit-ready business accounting, cash flow summaries, and Net Result calculations.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={async () => {
              try {
                await downloadElementAsPdf(
                  'printable-report-container',
                  `Sarwan-Technology-Report-${period}-${todayStr}.pdf`
                );
                toast.success('Financial report PDF downloaded successfully.');
              } catch (err: any) {
                console.error('PDF export error:', err);
                toast.error(err?.message || 'Failed to download PDF report.');
              }
            }}
            className="px-4 py-2 bg-[#2563EB] hover:bg-[#1D4ED8] active:bg-[#1E40AF] text-white text-xs font-bold rounded-lg shadow-xs transition inline-flex items-center gap-1.5 active:scale-98 cursor-pointer focus:outline-none focus-visible:ring-2 focus-visible:ring-[#2563EB]"
          >
            <Download className="w-4 h-4 text-white" />
            Download PDF
          </button>
        </div>
      </div>

      {/* Period Selection Tabs */}
      <div className="bg-white p-4 rounded-xl border border-neutral-200 shadow-xs space-y-4">
        <div className="flex flex-wrap items-center gap-2">
          {(
            [
              { id: 'daily', label: 'Daily (Today)' },
              { id: 'monthly', label: 'Monthly (This Month)' },
              { id: 'yearly', label: 'Yearly (This Year)' },
              { id: 'custom', label: 'Custom Date Range' },
            ] as const
          ).map((t) => (
            <button
              key={t.id}
              onClick={() => setPeriod(t.id)}
              className={`px-3.5 py-1.5 text-xs font-bold rounded-lg transition cursor-pointer ${
                period === t.id
                  ? 'bg-[#2563EB] text-white shadow-xs'
                  : 'bg-neutral-100 text-neutral-600 hover:bg-neutral-200'
              }`}
            >
              {t.label}
            </button>
          ))}
        </div>

        {period === 'custom' && (
          <div className="flex flex-wrap items-center gap-3 pt-2 border-t border-neutral-100 text-xs">
            <span className="font-semibold text-neutral-700">Select Date Range:</span>
            <div className="flex items-center gap-2">
              <input
                type="date"
                value={customStart}
                onChange={(e) => setCustomStart(e.target.value)}
                className="text-xs font-mono border border-neutral-300 rounded px-2 py-1 focus:outline-none focus:ring-1 focus:ring-orange-500"
              />
              <span className="text-neutral-400">to</span>
              <input
                type="date"
                value={customEnd}
                onChange={(e) => setCustomEnd(e.target.value)}
                className="text-xs font-mono border border-neutral-300 rounded px-2 py-1 focus:outline-none focus:ring-1 focus:ring-orange-500"
              />
            </div>
          </div>
        )}
      </div>

      {/* ================= EXPORTABLE REPORT CONTAINER ================= */}
      <div
        id="printable-report-container"
        className="bg-white rounded-xl border border-neutral-200 shadow-sm p-6 sm:p-8 space-y-8"
      >
        {/* Report Company Header */}
        <div className="border-b-2 border-neutral-900 pb-5">
          <div className="flex flex-row items-center justify-between">
            <div className="flex items-center gap-4">
              <div
                className="w-16 h-16 sm:w-20 sm:h-20 bg-white flex items-center justify-center shrink-0 overflow-hidden p-1 shadow-xs"
                style={{ borderRadius: '100%', border: 'none' }}
              >
                <img
                  src={settings.logo || '/sarwan-logo.png'}
                  alt="Sarwan Technology"
                  className="max-h-full max-w-full object-contain"
                  onError={(e) => {
                    const target = e.currentTarget;
                    if (target.src.endsWith('.png')) target.src = '/sarwan-logo.svg';
                  }}
                />
              </div>
              <div>
                <h2 className="text-2xl font-black tracking-tight text-neutral-900">
                  {settings.companyName || 'SARWAN TECHNOLOGY'}
                </h2>
                <p className="text-xs font-semibold text-[#F58220] tracking-wider uppercase">
                  Business Financial Performance Report
                </p>
                <div className="mt-1 text-xs text-neutral-500 flex flex-wrap gap-x-4">
                  <span>Phone: {settings.phone}</span>
                  <span>WhatsApp: {settings.whatsapp}</span>
                  <span>Email: {settings.email}</span>
                </div>
              </div>
            </div>

            <div className="text-right">
              <span className="text-xs font-bold uppercase tracking-wider text-neutral-500 block">
                Period
              </span>
              <p className="text-sm font-bold text-neutral-900 font-mono mt-0.5">{periodLabel}</p>
              <p className="text-[11px] text-neutral-400 mt-1">Generated: {formatDate(todayStr)}</p>
            </div>
          </div>
        </div>

        {/* Core Financial Metrics Grid */}
        <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
          <div className="bg-neutral-50 p-4 rounded-xl border border-neutral-200">
            <span className="text-[11px] font-bold uppercase tracking-wide text-neutral-500 block">
              Total Invoices
            </span>
            <p className="text-2xl font-bold font-mono text-neutral-900 mt-1.5">
              {totalInvoicesCount}
            </p>
            <p className="text-xs text-neutral-400 mt-0.5">Documents generated in period</p>
          </div>

          <div className="bg-neutral-50 p-4 rounded-xl border border-neutral-200">
            <span className="text-[11px] font-bold uppercase tracking-wide text-neutral-700 block">
              Total Sales
            </span>
            <p className="text-2xl font-black font-mono text-neutral-900 mt-1.5">
              {formatAFN(totalSales)}
            </p>
            <p className="text-xs text-neutral-400 mt-0.5">Cumulative billed volume</p>
          </div>

          <div className="bg-emerald-50/70 p-4 rounded-xl border border-emerald-200">
            <span className="text-[11px] font-bold uppercase tracking-wide text-emerald-800 block">
              Total Cash Received
            </span>
            <p className="text-2xl font-black font-mono text-emerald-700 mt-1.5">
              {formatAFN(totalCashReceived)}
            </p>
            <p className="text-xs text-emerald-600 mt-0.5">
              {periodPayments.length} Cash payments collected
            </p>
          </div>

          <div className="bg-rose-50/70 p-4 rounded-xl border border-rose-200">
            <span className="text-[11px] font-bold uppercase tracking-wide text-rose-800 block">
              Total Expenses
            </span>
            <p className="text-2xl font-black font-mono text-rose-600 mt-1.5">
              {formatAFN(totalExpenses)}
            </p>
            <p className="text-xs text-rose-600 mt-0.5">
              {periodExpenses.length} Operating expense vouchers
            </p>
          </div>

          <div className="bg-neutral-900 text-white p-4 rounded-xl border border-neutral-800">
            <span className="text-[11px] font-bold uppercase tracking-wide text-orange-400 block">
              Total Remaining / Receivable
            </span>
            <p className="text-2xl font-black font-mono text-white mt-1.5">
              {formatAFN(totalReceivable)}
            </p>
            <p className="text-xs text-neutral-400 mt-0.5">Outstanding customer balance</p>
          </div>

          {/* Net Result (Total Sales - Total Expenses) */}
          <div className="bg-neutral-100 p-4 rounded-xl border-2 border-neutral-900">
            <div className="flex items-center justify-between">
              <span className="text-[11px] font-bold uppercase tracking-wide text-neutral-900">
                Net Result
              </span>
              <span className="text-[10px] font-mono text-neutral-500">Sales - Expenses</span>
            </div>
            <p
              className={`text-2xl font-black font-mono mt-1.5 ${
                netResult >= 0 ? 'text-neutral-900' : 'text-rose-600'
              }`}
            >
              {formatAFN(netResult)}
            </p>
            <p className="text-xs text-neutral-600 mt-0.5">Operating Sales minus Expenses</p>
          </div>
        </div>

        {/* Invoices in this period */}
        <div>
          <h3 className="text-xs font-bold uppercase tracking-wider text-neutral-800 mb-3">
            Invoices in Period ({periodInvoices.length})
          </h3>
          {periodInvoices.length === 0 ? (
            <p className="text-xs text-neutral-500 italic p-4 bg-neutral-50 rounded-lg">
              No invoices created in this period.
            </p>
          ) : (
            <div className="border border-neutral-200 rounded-lg overflow-hidden text-xs">
              <table className="w-full border-collapse">
                <thead>
                  <tr className="bg-neutral-100 text-neutral-700 font-semibold text-left">
                    <th className="py-2.5 px-3">Date</th>
                    <th className="py-2.5 px-3">Bill No.</th>
                    <th className="py-2.5 px-3">Customer</th>
                    <th className="py-2.5 px-3 text-center">Status</th>
                    <th className="py-2.5 px-3 text-right">Invoice Amount</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-neutral-200">
                  {periodInvoices.map((inv) => (
                    <tr key={inv.id}>
                      <td className="py-2 px-3 font-mono text-neutral-600">
                        {formatDate(inv.date)}
                      </td>
                      <td className="py-2 px-3 font-mono font-bold text-neutral-900">
                        {inv.billNumber}
                      </td>
                      <td className="py-2 px-3 text-neutral-800">{inv.customerSnapshot.name}</td>
                      <td className="py-2 px-3 text-center">
                        <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-neutral-100 text-neutral-800">
                          {inv.status}
                        </span>
                      </td>
                      <td className="py-2 px-3 text-right font-mono font-bold text-neutral-900">
                        {formatAFN(inv.totalAmount)}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>

        {/* Expenses in this period */}
        <div>
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-3">
            <h3 className="text-xs font-bold uppercase tracking-wider text-neutral-800">
              Expenses in Period ({periodExpenses.length})
            </h3>
            {/* Filter controls for viewing invoice-linked vs general expenses */}
            <div className="flex items-center gap-1 bg-neutral-100 p-0.5 rounded-lg border border-neutral-200 text-xs">
              <button
                type="button"
                onClick={() => setExpenseTypeFilter('all')}
                className={`px-2.5 py-1 rounded text-[11px] font-semibold transition cursor-pointer ${
                  expenseTypeFilter === 'all'
                    ? 'bg-white text-neutral-900 shadow-2xs'
                    : 'text-neutral-600 hover:text-neutral-900'
                }`}
              >
                All ({periodExpenses.length})
              </button>
              <button
                type="button"
                onClick={() => setExpenseTypeFilter('invoice_linked')}
                className={`px-2.5 py-1 rounded text-[11px] font-semibold transition cursor-pointer ${
                  expenseTypeFilter === 'invoice_linked'
                    ? 'bg-white text-neutral-900 shadow-2xs'
                    : 'text-neutral-600 hover:text-neutral-900'
                }`}
              >
                Invoice-Linked ({invoiceLinkedExpensesCount})
              </button>
              <button
                type="button"
                onClick={() => setExpenseTypeFilter('general')}
                className={`px-2.5 py-1 rounded text-[11px] font-semibold transition cursor-pointer ${
                  expenseTypeFilter === 'general'
                    ? 'bg-white text-neutral-900 shadow-2xs'
                    : 'text-neutral-600 hover:text-neutral-900'
                }`}
              >
                General ({periodExpenses.length - invoiceLinkedExpensesCount})
              </button>
            </div>
          </div>

          {filteredPeriodExpenses.length === 0 ? (
            <p className="text-xs text-neutral-500 italic p-4 bg-neutral-50 rounded-lg border border-neutral-200">
              No expenses recorded for this filter in the selected period.
            </p>
          ) : (
            <div className="border border-neutral-200 rounded-lg overflow-hidden text-xs shadow-2xs">
              <table className="w-full border-collapse">
                <thead>
                  <tr className="bg-neutral-100 text-neutral-700 font-semibold text-left">
                    <th className="py-2.5 px-3">Date</th>
                    <th className="py-2.5 px-3">Expense Title / Purpose</th>
                    <th className="py-2.5 px-3">Category</th>
                    <th className="py-2.5 px-3">Linked Invoice</th>
                    <th className="py-2.5 px-3">Customer</th>
                    <th className="py-2.5 px-3 text-right">Amount</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-neutral-200">
                  {filteredPeriodExpenses.map((exp) => {
                    const linkedInvoice = exp.invoiceId ? invoiceMap.get(exp.invoiceId) : null;
                    const billNo = exp.billNumber || linkedInvoice?.billNumber;
                    const customerName = linkedInvoice?.customerSnapshot?.name;

                    return (
                      <tr key={exp.id} className="hover:bg-neutral-50">
                        <td className="py-2.5 px-3 font-mono text-neutral-600 whitespace-nowrap">
                          {formatDate(exp.date)}
                        </td>
                        <td className="py-2.5 px-3">
                          <p className="font-bold text-neutral-800 break-words max-w-xs">{exp.title}</p>
                          {exp.note && (
                            <p className="text-[11px] text-neutral-500 break-words max-w-xs mt-0.5">
                              {exp.note}
                            </p>
                          )}
                        </td>
                        <td className="py-2.5 px-3 whitespace-nowrap">
                          <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-neutral-100 text-neutral-700 border border-neutral-200">
                            {exp.category || 'General'}
                          </span>
                        </td>
                        <td className="py-2.5 px-3 whitespace-nowrap">
                          {billNo ? (
                            <span className="font-mono font-bold text-neutral-900 bg-orange-50 text-orange-700 border border-orange-200 px-2 py-0.5 rounded text-[10px]">
                              {billNo}
                            </span>
                          ) : (
                            <span className="text-neutral-400 text-[11px] italic">
                              General Ops
                            </span>
                          )}
                        </td>
                        <td className="py-2.5 px-3 text-neutral-700 whitespace-nowrap">
                          {customerName || '—'}
                        </td>
                        <td className="py-2.5 px-3 text-right font-mono font-bold text-rose-600 whitespace-nowrap">
                          {formatAFN(exp.amount)}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
                <tfoot>
                  <tr className="bg-neutral-50 font-bold border-t-2 border-neutral-300">
                    <td colSpan={5} className="py-2.5 px-3 text-right text-neutral-700 uppercase text-[10px] tracking-wider">
                      Total Displayed Expenses ({filteredPeriodExpenses.length} items):
                    </td>
                    <td className="py-2.5 px-3 text-right font-mono font-black text-rose-700 whitespace-nowrap">
                      {formatAFN(
                        filteredPeriodExpenses.reduce((sum, e) => sum + (Number(e.amount) || 0), 0)
                      )}
                    </td>
                  </tr>
                </tfoot>
              </table>
            </div>
          )}
        </div>

        {/* Report Footer */}
        <div className="border-t border-neutral-200 pt-4 text-center text-[11px] text-neutral-400">
          Sarwan Technology • Security Systems &amp; Technology Solutions • Official Accounting
          Ledger
        </div>
      </div>
    </div>
  );
};
