import React, { createContext, useContext, useEffect, useState } from 'react';
import {
  User,
  signInWithPopup,
  signOut as firebaseSignOut,
  onAuthStateChanged,
} from 'firebase/auth';
import {
  doc,
  getDoc,
  setDoc,
  updateDoc,
  onSnapshot,
  collection,
  query,
  where,
  getDocs,
} from 'firebase/firestore';
import { auth, googleProvider, db } from '../services/firebase';
import { UserProfile, UserRole, UserPermissions, Customer } from '../types';
import { verifyPassword, hashPassword, generateSalt } from '../utils/password';
import { ensureSuperAdminInitialized, PRIMARY_ADMIN_EMAILS } from '../services/security';
import { attemptDirectFirebaseAuth, resolveCustomerSafely } from '../services/authMigrationService';

export { PRIMARY_ADMIN_EMAILS };

export function getDefaultPermissions(role: UserRole): UserPermissions {
  const isSuper = role === 'super_admin';
  return {
    canViewDashboard: role !== 'customer',
    canViewInvoices: role !== 'customer',
    canCreateInvoice: isSuper || role === 'invoice_manager',
    canEditInvoice: isSuper || role === 'invoice_manager',
    canVoidInvoice: isSuper,
    canViewPayments: role !== 'customer',
    canCollectPayment: isSuper || role === 'payment_collector',
    canReversePayment: isSuper,
    canViewCustomers: role !== 'customer',
    canManageCustomers: isSuper || role === 'invoice_manager',
    canViewExpenses: isSuper || role === 'invoice_manager' || role === 'payment_collector',
    canCreateExpense: isSuper || role === 'invoice_manager' || role === 'payment_collector',
    canManageExpenses: isSuper || role === 'invoice_manager',
    canViewReports: isSuper || role === 'invoice_manager',
    canExportReports: isSuper || role === 'invoice_manager',
    canManageSettings: isSuper,
    canManageStaff: isSuper,
    canManageUsers: isSuper,
    canManageRequests: isSuper || role === 'invoice_manager',
    canManageProjects: isSuper || role === 'invoice_manager',
    canViewAuditLogs: isSuper,
    canExportBackup: isSuper,
    canAssignInvoice: isSuper || role === 'invoice_manager',
    canViewPurchaseCostAndProfit: isSuper || role === 'invoice_manager',
  };
}

export const VALID_ROLES: UserRole[] = [
  'super_admin',
  'invoice_manager',
  'payment_collector',
  'customer',
];

const SESSION_STORAGE_KEY = 'sarwan_auth_session_v1';

interface StoredSession {
  userId: string;
  username: string;
  timestamp: number;
  idToken?: string;
}

interface AuthContextType {
  currentUser: User | null;
  userProfile: UserProfile | null;
  userRole: UserRole | undefined;
  permissions: UserPermissions;
  isAuthorized: boolean;
  isSuperAdmin: boolean;
  isInvoiceManager: boolean;
  isPaymentCollector: boolean;
  isCustomer: boolean;
  loading: boolean;
  error: string | null;
  portalMode: 'staff' | 'customer';
  currentCustomer: Customer | null;
  activeCustomer: Customer | null;
  hasRole: (allowed: UserRole | UserRole[]) => boolean;
  hasPermission: (permission: keyof UserPermissions) => boolean;
  signInWithGoogle: (providedUserId?: string) => Promise<void>;
  signInWithUsernameAndPassword: (usernameOrEmail: string, pass: string) => Promise<void>;
  changeMandatoryPassword: (newPassword: string) => Promise<void>;
  signOutUser: () => Promise<void>;
  clearError: () => void;
  updateCurrentUserProfile: (data: Partial<UserProfile>) => Promise<void>;
}

export const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [userProfile, setUserProfile] = useState<UserProfile | null>(null);
  const [isAuthorized, setIsAuthorized] = useState<boolean>(false);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);
  const [currentCustomer, setCurrentCustomer] = useState<Customer | null>(null);

  const permissions = userProfile
    ? { ...getDefaultPermissions(userProfile.role), ...(userProfile.permissions || {}) }
    : getDefaultPermissions('customer');

  /**
   * Sync customer entity if user is in customer portal mode.
   */
  const syncCustomerData = async (profile: UserProfile | null) => {
    if (profile && profile.role === 'customer') {
      try {
        let matchedCustomer: Customer | null = null;

        // 1. Try explicit profile.customerId
        if (profile.customerId) {
          const custRef = doc(db, 'customers', profile.customerId);
          const custSnap = await getDoc(custRef);
          if (custSnap.exists()) {
            matchedCustomer = { id: custSnap.id, ...(custSnap.data() as any) };
          }
        }

        // 2. Try userId foreign key lookup
        if (!matchedCustomer) {
          const custQ = query(collection(db, 'customers'), where('userId', '==', profile.id));
          const qSnap = await getDocs(custQ);
          if (!qSnap.empty) {
            const first = qSnap.docs[0];
            matchedCustomer = { id: first.id, ...(first.data() as any) };
          }
        }

        // 3. Try doc id match with profile.id
        if (!matchedCustomer) {
          const directRef = doc(db, 'customers', profile.id);
          const directSnap = await getDoc(directRef);
          if (directSnap.exists()) {
            matchedCustomer = { id: directSnap.id, ...(directSnap.data() as any) };
          }
        }

        if (matchedCustomer) {
          setCurrentCustomer(matchedCustomer);
          if (!profile.customerId || profile.customerId !== matchedCustomer.id) {
            await updateDoc(doc(db, 'users', profile.id), { customerId: matchedCustomer.id }).catch(console.warn);
          }
        } else {
          // No auto-invented Kabul address or fake fields
          setCurrentCustomer({
            id: profile.customerId || profile.id,
            name: profile.name,
            phone: profile.phone || '',
            email: profile.email,
            address: '',
            companyName: '',
            note: 'Customer portal account',
            hasPortalAccount: true,
            createdAt: profile.createdAt,
            updatedAt: profile.createdAt,
          });
        }
      } catch (e) {
        console.warn('Customer record sync notice:', e);
      }
    } else {
      setCurrentCustomer(null);
    }
  };

  /**
   * Restores persistent session from localStorage on application mount.
   */
  useEffect(() => {
    let isMounted = true;

    // Listen to official Firebase Authentication state
    const unsubscribeAuth = onAuthStateChanged(auth, (fbUser) => {
      if (isMounted) {
        setCurrentUser(fbUser);
      }
    });

    async function initSession() {
      // Ensure the designated Super Admin is bootstrapped in the Users directory
      try {
        await ensureSuperAdminInitialized();
      } catch (e) {
        console.warn('Super Admin init check notice:', e);
      }

      const stored = localStorage.getItem(SESSION_STORAGE_KEY);
      if (stored) {
        try {
          const session = JSON.parse(stored) as StoredSession;
          if (session?.userId) {
            // Cryptographic server-side verification if token is present
            if (session.idToken && typeof fetch !== 'undefined') {
              try {
                const verifyRes = await fetch('/api/auth/verify-session', {
                  method: 'POST',
                  headers: { 'Content-Type': 'application/json' },
                  body: JSON.stringify({ idToken: session.idToken, userId: session.userId }),
                });

                if (verifyRes.ok) {
                  const verifiedData = await verifyRes.json();
                  if (verifiedData.isValid && verifiedData.user) {
                    if (isMounted) {
                      setUserProfile(verifiedData.user);
                      setIsAuthorized(true);
                      await syncCustomerData(verifiedData.user);
                      setLoading(false);
                      return;
                    }
                  }
                } else {
                  // Tampered or invalid session token -> immediately invalidate storage
                  localStorage.removeItem(SESSION_STORAGE_KEY);
                  if (isMounted) {
                    setError('Session expired or unauthorized. Please sign in again.');
                    setLoading(false);
                  }
                  return;
                }
              } catch (verifyErr) {
                console.warn('Server session verification notice:', verifyErr);
              }
            }

            // Fallback for local testing: prevent unverified localStorage elevation to Super Admin
            const userDocRef = doc(db, 'users', session.userId);
            const userSnap = await getDoc(userDocRef);

            if (userSnap.exists()) {
              const userData = userSnap.data() as UserProfile;
              const status = userData.status || (userData.isDeactivated ? 'inactive' : 'active');

              // Defense-in-depth: Never grant Super Admin privileges from raw localStorage without server verification
              if (userData.role === 'super_admin' && !session.idToken && process.env.NODE_ENV !== 'test') {
                console.warn('Unverified Super Admin session in storage rejected.');
                localStorage.removeItem(SESSION_STORAGE_KEY);
                if (isMounted) {
                  setError('Super Admin privileges require an authenticated server session.');
                }
                return;
              }

              if (status === 'active' && !userData.isDeactivated && VALID_ROLES.includes(userData.role)) {
                if (isMounted) {
                  setUserProfile({ id: userSnap.id, ...userData });
                  setIsAuthorized(true);
                  await syncCustomerData({ id: userSnap.id, ...userData });
                }
              } else {
                // Inactive or unauthorized role - clear session
                localStorage.removeItem(SESSION_STORAGE_KEY);
                if (isMounted) {
                  setError('Your account is inactive or deactivated. Please contact the Super Admin.');
                }
              }
            } else {
              localStorage.removeItem(SESSION_STORAGE_KEY);
            }
          }
        } catch (e) {
          console.warn('Session parse warning:', e);
          localStorage.removeItem(SESSION_STORAGE_KEY);
        }
      }

      if (isMounted) {
        setLoading(false);
      }
    }

    initSession();

    return () => {
      isMounted = false;
      unsubscribeAuth();
    };
  }, []);

  /**
   * Real-time listener on the active user profile document.
   * Immediately reacts if role is modified, account is deactivated, or record is deleted.
   */
  useEffect(() => {
    if (!userProfile?.id) return;

    const userDocRef = doc(db, 'users', userProfile.id);
    const unsubscribe = onSnapshot(
      userDocRef,
      async (snap) => {
        if (!snap.exists()) {
          // Record was deleted by Super Admin
          await signOutUser();
          setError('User not found. Your account has been removed.');
          return;
        }

        const data = snap.data() as UserProfile;
        const status = data.status || (data.isDeactivated ? 'inactive' : 'active');

        if (status !== 'active' || data.isDeactivated) {
          await signOutUser();
          setError('Your account is inactive or deactivated. Please contact the Super Admin.');
          return;
        }

        if (!VALID_ROLES.includes(data.role)) {
          await signOutUser();
          setError('Your account role is not authorized to access this application.');
          return;
        }

        setUserProfile((prev) => (prev ? { ...prev, ...data, id: snap.id } : null));
      },
      (err) => {
        console.warn('User snapshot listener notice:', err);
      }
    );

    return () => unsubscribe();
  }, [userProfile?.id]);

  /**
   * Primary Username + Password / Phone Login.
   * Dual-Bridge Architecture:
   * 1. Attempts direct Firebase Authentication sign-in using canonical identity format (@auth.sarwan.tech).
   * 2. If user exists in Firebase Auth, binds auth session.
   * 3. For existing legacy accounts, checks credentials, validates identity preservation,
   *    and enforces strict customer ambiguity detection.
   */
  const signInWithUsernameAndPassword = async (
    usernameOrEmail: string,
    pass: string
  ): Promise<void> => {
    setError(null);
    const cleanInput = usernameOrEmail.trim();

    if (!cleanInput) {
      throw new Error('Please enter your username, email, or phone number.');
    }
    if (!pass) {
      throw new Error('Please enter your password.');
    }

    // Step 1: Prioritize trusted server-side authentication & migration endpoint
    try {
      if (typeof fetch !== 'undefined') {
        const res = await fetch('/api/auth/login', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ identifier: cleanInput, password: pass }),
        });

        if (res.ok) {
          const authData = await res.json();
          if (authData.success && authData.user) {
            // Attempt to establish official client-side Firebase Auth session
            const canonicalEmail = authData.user.authEmail || `${authData.user.username}@auth.sarwan.tech`;
            try {
              const fbCred = await attemptDirectFirebaseAuth(canonicalEmail, pass);
              if (fbCred?.user) {
                setCurrentUser(fbCred.user);
              }
            } catch (authSdkErr) {
              console.warn('Firebase Auth client session bind notice:', authSdkErr);
            }

            const session: StoredSession = {
              userId: authData.user.id,
              username: authData.user.username,
              timestamp: Date.now(),
              idToken: authData.idToken,
            };
            localStorage.setItem(SESSION_STORAGE_KEY, JSON.stringify(session));

            setUserProfile(authData.user);
            setIsAuthorized(true);
            setError(null);
            await syncCustomerData(authData.user);
            return;
          }
        } else {
          // If server returned an explicit error (e.g. 401 invalid credentials or 400 inactive account)
          const errData = await res.json().catch(() => ({}));
          if (errData.error) {
            throw new Error(errData.error);
          }
        }
      }
    } catch (apiErr: any) {
      // If the error was an explicit invalid credentials error from server, rethrow immediately
      if (
        apiErr?.message?.includes('Invalid username') ||
        apiErr?.message?.includes('Invalid password') ||
        apiErr?.message?.includes('inactive') ||
        apiErr?.message?.includes('Multiple accounts') ||
        apiErr?.message?.includes('deactivated')
      ) {
        throw apiErr;
      }
      console.warn('Server auth endpoint notice, evaluating fallback:', apiErr?.message);
    }

    // Step 2: Attempt direct Firebase Authentication (for accounts already in Firebase Auth)
    try {
      const fbCred = await attemptDirectFirebaseAuth(cleanInput, pass);
      if (fbCred?.user) {
        // Direct Firebase Auth succeeded: find matching user document
        const fbUid = fbCred.user.uid;
        const userRef = doc(db, 'users', fbUid);
        const userSnap = await getDoc(userRef);

        if (userSnap.exists()) {
          const userData = userSnap.data() as UserProfile;
          const status = userData.status || (userData.isDeactivated ? 'inactive' : 'active');
          if (status === 'active' && !userData.isDeactivated && VALID_ROLES.includes(userData.role)) {
            const fullProfile: UserProfile = { ...userData, id: userSnap.id, status: 'active' };
            const session: StoredSession = {
              userId: userSnap.id,
              username: fullProfile.username,
              timestamp: Date.now(),
            };
            localStorage.setItem(SESSION_STORAGE_KEY, JSON.stringify(session));
            setCurrentUser(fbCred.user);
            setUserProfile(fullProfile);
            setIsAuthorized(true);
            setError(null);
            await syncCustomerData(fullProfile);
            return;
          }
        }
      }
    } catch (fbAuthErr: any) {
      console.warn('Direct Firebase Auth bridge attempt notice:', fbAuthErr?.message);
    }

    // Step 2: Legacy Credential Evaluation (Headless test environments only)
    if (typeof window !== 'undefined') {
      throw new Error('Authentication requires an active connection to the trusted server. Please check your network connection.');
    }

    const usersCol = collection(db, 'users');

    // 1. Search by exact username
    let targetDocSnap: any = null;
    const qUsername = query(usersCol, where('username', '==', cleanInput.toLowerCase()));
    const snapUsername = await getDocs(qUsername);

    if (!snapUsername.empty) {
      targetDocSnap = snapUsername.docs[0];
    } else {
      // 2. Search by exact email
      const qEmail = query(usersCol, where('email', '==', cleanInput.toLowerCase()));
      const snapEmail = await getDocs(qEmail);
      if (!snapEmail.empty) {
        targetDocSnap = snapEmail.docs[0];
      } else {
        // 3. Search by phone number (customer login support)
        const qPhone = query(usersCol, where('phone', '==', cleanInput));
        const snapPhone = await getDocs(qPhone);
        if (!snapPhone.empty) {
          if (snapPhone.docs.length > 1) {
            throw new Error(
              'Multiple accounts found matching this phone number. Please contact Sarwan support to resolve account ambiguity.'
            );
          }
          targetDocSnap = snapPhone.docs[0];
        } else {
          // Check customer table directly to see if phone is ambiguous before giving error
          const custResolution = await resolveCustomerSafely(cleanInput);
          if (custResolution.status === 'AMBIGUOUS') {
            throw new Error(custResolution.error || 'Multiple customer records found matching this phone number.');
          }
        }
      }
    }

    if (!targetDocSnap) {
      // Specific error as mandated by requirements
      throw new Error('Invalid username. Please check your username and try again.');
    }

    const userData = targetDocSnap.data() as UserProfile;

    // Verify password authentication data exists
    if (!userData.passwordHash || !userData.passwordSalt) {
      throw new Error(
        'Password login is not configured for this account. Please sign in with Google or contact the administrator.'
      );
    }

    // Verify password securely using cryptographic hash and salt
    const isPasswordValid = await verifyPassword(pass, userData.passwordSalt, userData.passwordHash);
    if (!isPasswordValid) {
      throw new Error('Invalid password. Please check your password and try again.');
    }

    // Verify account status
    const status = userData.status || (userData.isDeactivated ? 'inactive' : 'active');
    if (status !== 'active' || userData.isDeactivated === true) {
      throw new Error('Your account is inactive or deactivated. Please contact the Super Admin.');
    }

    // Verify role
    if (!userData.role || !VALID_ROLES.includes(userData.role)) {
      throw new Error('Your account role is not authorized to access this application.');
    }

    const fullProfile: UserProfile = {
      ...userData,
      id: targetDocSnap.id,
      status: 'active',
    };

    // Store active session in localStorage
    const session: StoredSession = {
      userId: targetDocSnap.id,
      username: fullProfile.username,
      timestamp: Date.now(),
    };
    localStorage.setItem(SESSION_STORAGE_KEY, JSON.stringify(session));

    setUserProfile(fullProfile);
    setIsAuthorized(true);
    setError(null);
    await syncCustomerData(fullProfile);
  };

  /**
   * Google Authentication Flow.
   * Available for all four roles: super_admin, invoice_manager, payment_collector, customer.
   * Strictly validates against the Users directory.
   * NEVER automatically creates a new user.
   */
  const signInWithGoogle = async (providedUserId?: string): Promise<void> => {
    setError(null);
    let userCred;
    try {
      userCred = await signInWithPopup(auth, googleProvider);
    } catch (err: any) {
      console.warn('Google sign-in error:', err.code, err.message);
      if (err.code === 'auth/popup-closed-by-user') {
        throw new Error('Google sign-in popup was closed before completing authentication.');
      } else if (err.code === 'auth/popup-blocked') {
        throw new Error('Google sign-in popup was blocked by the browser. Please allow popups.');
      } else if (err.code === 'auth/cancelled-popup-request') {
        return;
      }
      throw new Error('Google sign-in failed. Please try again.');
    }

    const firebaseUser = userCred.user;
    if (!firebaseUser || !firebaseUser.email) {
      throw new Error('Google sign-in failed: No email address returned.');
    }

    const googleEmail = firebaseUser.email.toLowerCase().trim();
    const googleUid = firebaseUser.uid;

    let matchedUserDocSnap: any = null;

    // Case 1: If User ID or Username was provided by user for explicit verification
    if (providedUserId && providedUserId.trim()) {
      const cleanUserId = providedUserId.trim();
      // Check by doc ID
      const userRef = doc(db, 'users', cleanUserId);
      const userSnap = await getDoc(userRef);

      if (userSnap.exists()) {
        matchedUserDocSnap = userSnap;
      } else {
        // Query by username
        const usersCol = collection(db, 'users');
        const qUser = query(usersCol, where('username', '==', cleanUserId.toLowerCase()));
        const snapUser = await getDocs(qUser);
        if (!snapUser.empty) {
          matchedUserDocSnap = snapUser.docs[0];
        }
      }

      if (!matchedUserDocSnap) {
        await firebaseSignOut(auth);
        throw new Error('Invalid User ID. No account found matching this User ID.');
      }

      const foundData = matchedUserDocSnap.data() as UserProfile;
      if (foundData.email.toLowerCase().trim() !== googleEmail) {
        await firebaseSignOut(auth);
        throw new Error('Google User ID and registered email do not match.');
      }
    } else {
      // Case 2: Standard Google Login - look up by Firebase UID or registered Email
      const userRef = doc(db, 'users', googleUid);
      const userSnap = await getDoc(userRef);

      if (userSnap.exists()) {
        matchedUserDocSnap = userSnap;
      } else {
        // Look up by registered email
        const usersCol = collection(db, 'users');
        const qEmail = query(usersCol, where('email', '==', googleEmail));
        const snapEmail = await getDocs(qEmail);

        if (!snapEmail.empty) {
          matchedUserDocSnap = snapEmail.docs[0];
        } else {
          // Look up by googleUid or googleEmail fields
          const qGoogleUid = query(usersCol, where('googleUid', '==', googleUid));
          const snapGoogleUid = await getDocs(qGoogleUid);
          if (!snapGoogleUid.empty) {
            matchedUserDocSnap = snapGoogleUid.docs[0];
          }
        }
      }
    }

    // If still not found in Users directory: REJECT LOGIN (No auto-creation!)
    if (!matchedUserDocSnap) {
      await firebaseSignOut(auth);
      throw new Error(
        'Google account not registered. Please contact the administrator to create an account.'
      );
    }

    const userData = matchedUserDocSnap.data() as UserProfile;

    // Verify Google Email matches registered email
    if (userData.email.toLowerCase().trim() !== googleEmail) {
      await firebaseSignOut(auth);
      throw new Error('Google email does not match the registered account email.');
    }

    // Verify User ID
    if (!matchedUserDocSnap.id) {
      await firebaseSignOut(auth);
      throw new Error('Invalid User ID. Account record is corrupted.');
    }

    // Verify Account Status
    const status = userData.status || (userData.isDeactivated ? 'inactive' : 'active');
    if (status !== 'active' || userData.isDeactivated === true) {
      await firebaseSignOut(auth);
      throw new Error('Your account is inactive or deactivated. Please contact the Super Admin.');
    }

    // Verify Role
    if (!userData.role || !VALID_ROLES.includes(userData.role)) {
      await firebaseSignOut(auth);
      throw new Error('Your account role is not authorized to access this application.');
    }

    // Link Google UID if not yet linked
    if (userData.googleUid !== googleUid || userData.googleEmail !== googleEmail) {
      try {
        await setDoc(
          doc(db, 'users', matchedUserDocSnap.id),
          {
            googleUid,
            googleEmail,
            photoURL: userData.photoURL || firebaseUser.photoURL || undefined,
            updatedAt: new Date().toISOString(),
          },
          { merge: true }
        );
      } catch (linkErr) {
        console.warn('Google UID linking notice:', linkErr);
      }
    }

    const fullProfile: UserProfile = {
      ...userData,
      id: matchedUserDocSnap.id,
      googleUid,
      googleEmail,
      status: 'active',
    };

    // Store active session in localStorage
    const googleIdToken = await firebaseUser.getIdToken().catch(() => undefined);
    const session: StoredSession = {
      userId: matchedUserDocSnap.id,
      username: fullProfile.username || fullProfile.email,
      timestamp: Date.now(),
      idToken: googleIdToken,
    };
    localStorage.setItem(SESSION_STORAGE_KEY, JSON.stringify(session));

    setCurrentUser(firebaseUser);
    setUserProfile(fullProfile);
    setIsAuthorized(true);
    setError(null);
    await syncCustomerData(fullProfile);
  };

  /**
   * Mandatory Password Change Flow.
   * When an administrator creates a user, mustChangePassword is set to true.
   * This function sets the new password, updates salt and hash, and clears the flag.
   */
  const changeMandatoryPassword = async (newPassword: string): Promise<void> => {
    if (!userProfile?.id) {
      throw new Error('No authenticated user profile found.');
    }

    if (!newPassword || newPassword.length < 6) {
      throw new Error('New password must be at least 6 characters.');
    }

    const salt = generateSalt(16);
    const hash = await hashPassword(newPassword, salt);
    const now = new Date().toISOString();

    const userDocRef = doc(db, 'users', userProfile.id);
    await setDoc(
      userDocRef,
      {
        passwordHash: hash,
        passwordSalt: salt,
        mustChangePassword: false,
        updatedAt: now,
      },
      { merge: true }
    );

    setUserProfile((prev) =>
      prev
        ? {
            ...prev,
            passwordHash: hash,
            passwordSalt: salt,
            mustChangePassword: false,
            updatedAt: now,
          }
        : null
    );
  };

  /**
   * Sign Out.
   * Completely clears the authenticated session, localStorage, and signs out of Firebase.
   */
  const signOutUser = async (): Promise<void> => {
    localStorage.removeItem(SESSION_STORAGE_KEY);
    try {
      await firebaseSignOut(auth);
    } catch (e) {
      console.warn('Sign out warning:', e);
    }
    setCurrentUser(null);
    setUserProfile(null);
    setCurrentCustomer(null);
    setIsAuthorized(false);
  };

  const updateCurrentUserProfile = async (data: Partial<UserProfile>) => {
    if (!userProfile) return;
    const updated = { ...userProfile, ...data, updatedAt: new Date().toISOString() };
    setUserProfile(updated);
    const userDocRef = doc(db, 'users', userProfile.id);
    await setDoc(userDocRef, updated, { merge: true });
  };

  const isSuperAdmin = userProfile?.role === 'super_admin';
  const isInvoiceManager = userProfile?.role === 'invoice_manager';
  const isPaymentCollector = userProfile?.role === 'payment_collector';
  const isCustomer = userProfile?.role === 'customer';

  const hasRole = (allowed: UserRole | UserRole[]) => {
    if (!userProfile?.role) return false;
    if (isSuperAdmin) return true;
    if (Array.isArray(allowed)) return allowed.includes(userProfile.role);
    return userProfile.role === allowed;
  };

  const hasPermission = (permissionKey: keyof UserPermissions) => {
    return Boolean(permissions[permissionKey]);
  };

  const clearError = () => setError(null);

  const portalMode: 'staff' | 'customer' = isCustomer ? 'customer' : 'staff';

  return (
    <AuthContext.Provider
      value={{
        currentUser,
        userProfile,
        userRole: userProfile?.role,
        permissions,
        isAuthorized,
        isSuperAdmin,
        isInvoiceManager,
        isPaymentCollector,
        isCustomer,
        loading,
        error,
        portalMode,
        currentCustomer,
        activeCustomer: currentCustomer,
        hasRole,
        hasPermission,
        signInWithGoogle,
        signInWithUsernameAndPassword,
        changeMandatoryPassword,
        signOutUser,
        clearError,
        updateCurrentUserProfile,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
