import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import { createPortal } from 'react-dom';
import {
  AlertTriangle,
  AlertCircle,
  CheckCircle2,
  Info,
  X,
  Download,
  ExternalLink,
} from 'lucide-react';

export type ToastType = 'error' | 'warning' | 'info' | 'success';

export interface ToastAction {
  label: string;
  onClick: () => void;
  variant?: 'primary' | 'secondary';
  icon?: 'download' | 'link';
}

export interface ToastItem {
  id: string;
  type: ToastType;
  title?: string;
  message: string;
  duration?: number; // ms; default 6000ms for errors, 4000ms for others; 0 = persistent
  action?: ToastAction;
  timestamp: number;
}

export interface ToastOptions {
  title?: string;
  duration?: number;
  action?: ToastAction;
}

interface ToastContextType {
  toasts: ToastItem[];
  showToast: (toast: Omit<ToastItem, 'id' | 'timestamp'>) => string;
  dismissToast: (id: string) => void;
  clearAllToasts: () => void;
}

const ToastContext = createContext<ToastContextType | undefined>(undefined);

// Global custom event name for cross-boundary toast emission (works from both React & pure utilities)
const GLOBAL_TOAST_EVENT = 'sarwan:global-toast-event';
const GLOBAL_TOAST_DISMISS = 'sarwan:global-toast-dismiss';

// In-memory cache to debounce and deduplicate consecutive identical toasts
let lastDispatchedToast: { key: string; time: number } = { key: '', time: 0 };

/**
 * Universal singleton `toast` helper to dispatch toasts from anywhere in the codebase,
 * including React components, services, and non-React event listeners.
 */
export const toast = {
  show(toastData: Omit<ToastItem, 'id' | 'timestamp'>): string {
    const dedupeKey = `${toastData.type}:${toastData.message}`;
    const now = Date.now();
    if (lastDispatchedToast.key === dedupeKey && now - lastDispatchedToast.time < 1500) {
      // Ignore rapid consecutive duplicate
      return 'duplicate-debounced';
    }
    lastDispatchedToast = { key: dedupeKey, time: now };

    const id = `toast-${now}-${Math.random().toString(36).slice(2, 7)}`;
    if (typeof window !== 'undefined') {
      window.dispatchEvent(
        new CustomEvent(GLOBAL_TOAST_EVENT, {
          detail: { ...toastData, id, timestamp: now },
        })
      );
    }
    return id;
  },
  error(message: string, options?: ToastOptions): string {
    return toast.show({
      type: 'error',
      title: options?.title || 'Error',
      message,
      // Critical errors remain visible long enough to be read and understood (default 9000ms)
      duration: options?.duration !== undefined ? options.duration : 9000,
      action: options?.action,
    });
  },
  warning(message: string, options?: ToastOptions): string {
    return toast.show({
      type: 'warning',
      title: options?.title || 'Notice',
      message,
      duration: options?.duration ?? 6000,
      action: options?.action,
    });
  },
  info(message: string, options?: ToastOptions): string {
    return toast.show({
      type: 'info',
      title: options?.title || 'Information',
      message,
      duration: options?.duration ?? 5000,
      action: options?.action,
    });
  },
  success(message: string, options?: ToastOptions): string {
    return toast.show({
      type: 'success',
      title: options?.title || 'Success',
      message,
      duration: options?.duration ?? 4000,
      action: options?.action,
    });
  },
  dismiss(id: string): void {
    if (typeof window !== 'undefined') {
      window.dispatchEvent(
        new CustomEvent(GLOBAL_TOAST_DISMISS, {
          detail: { id },
        })
      );
    }
  },
};

export const showToast = toast.show;

export const useToast = (): ToastContextType => {
  const ctx = useContext(ToastContext);
  if (!ctx) {
    // Graceful fallback to singleton API if hook called outside provider
    return {
      toasts: [],
      showToast: toast.show,
      dismissToast: toast.dismiss,
      clearAllToasts: () => {},
    };
  }
  return ctx;
};

interface ToastProviderProps {
  children: React.ReactNode;
}

export const ToastProvider: React.FC<ToastProviderProps> = ({ children }) => {
  const [toasts, setToasts] = useState<ToastItem[]>([]);

  const dismissToast = useCallback((id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  }, []);

  const clearAllToasts = useCallback(() => {
    setToasts([]);
  }, []);

  const showToastLocal = useCallback(
    (item: Omit<ToastItem, 'id' | 'timestamp'>) => {
      const id = `toast-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`;
      const newToast: ToastItem = {
        ...item,
        id,
        timestamp: Date.now(),
      };
      setToasts((prev) => [newToast, ...prev].slice(0, 5)); // Keep max 5 active
      return id;
    },
    []
  );

  // Subscribe to global singleton custom events
  useEffect(() => {
    if (typeof window === 'undefined') return;

    const handleGlobalToast = (e: Event) => {
      const custom = e as CustomEvent<ToastItem>;
      if (custom.detail) {
        setToasts((prev) => [custom.detail, ...prev].slice(0, 5));
      }
    };

    const handleGlobalDismiss = (e: Event) => {
      const custom = e as CustomEvent<{ id: string }>;
      if (custom.detail?.id) {
        dismissToast(custom.detail.id);
      }
    };

    window.addEventListener(GLOBAL_TOAST_EVENT, handleGlobalToast);
    window.addEventListener(GLOBAL_TOAST_DISMISS, handleGlobalDismiss);

    return () => {
      window.removeEventListener(GLOBAL_TOAST_EVENT, handleGlobalToast);
      window.removeEventListener(GLOBAL_TOAST_DISMISS, handleGlobalDismiss);
    };
  }, [dismissToast]);

  const value: ToastContextType = {
    toasts,
    showToast: showToastLocal,
    dismissToast,
    clearAllToasts,
  };

  const portalTarget = typeof document !== 'undefined' ? document.body : null;

  return (
    <ToastContext.Provider value={value}>
      {children}
      {portalTarget &&
        createPortal(
          <ToastContainer toasts={toasts} onDismiss={dismissToast} />,
          portalTarget
        )}
    </ToastContext.Provider>
  );
};

interface ToastContainerProps {
  toasts: ToastItem[];
  onDismiss: (id: string) => void;
}

const ToastContainer: React.FC<ToastContainerProps> = ({ toasts, onDismiss }) => {
  if (toasts.length === 0) return null;

  return (
    <div
      className="fixed top-4 right-4 z-[99999999] flex flex-col gap-2.5 max-w-md w-[calc(100vw-2rem)] sm:w-96 pointer-events-none transition-all duration-300"
      role="region"
      aria-live="assertive"
      aria-label="Notifications"
    >
      {toasts.map((item) => (
        <ToastCard key={item.id} item={item} onDismiss={() => onDismiss(item.id)} />
      ))}
    </div>
  );
};

interface ToastCardProps {
  item: ToastItem;
  onDismiss: () => void;
}

const ToastCard: React.FC<ToastCardProps> = ({ item, onDismiss }) => {
  useEffect(() => {
    const duration = item.duration !== undefined ? item.duration : (item.type === 'error' ? 9000 : 5000);
    if (duration <= 0) return;

    const timer = setTimeout(() => {
      onDismiss();
    }, duration);

    return () => clearTimeout(timer);
  }, [item, onDismiss]);

  const configByType = {
    error: {
      bg: 'bg-rose-900/95 text-white border-rose-700/80 shadow-rose-950/40',
      badge: 'bg-rose-800 text-rose-100 border-rose-600',
      icon: <AlertTriangle className="w-5 h-5 text-rose-300 shrink-0" />,
      accent: 'text-rose-200',
      actionBtn: 'bg-white hover:bg-rose-50 text-rose-900 border-transparent',
    },
    warning: {
      bg: 'bg-amber-900/95 text-white border-amber-700/80 shadow-amber-950/40',
      badge: 'bg-amber-800 text-amber-100 border-amber-600',
      icon: <AlertCircle className="w-5 h-5 text-amber-300 shrink-0" />,
      accent: 'text-amber-200',
      actionBtn: 'bg-white hover:bg-amber-50 text-amber-900 border-transparent',
    },
    success: {
      bg: 'bg-emerald-900/95 text-white border-emerald-700/80 shadow-emerald-950/40',
      badge: 'bg-emerald-800 text-emerald-100 border-emerald-600',
      icon: <CheckCircle2 className="w-5 h-5 text-emerald-300 shrink-0" />,
      accent: 'text-emerald-200',
      actionBtn: 'bg-white hover:bg-emerald-50 text-emerald-900 border-transparent',
    },
    info: {
      bg: 'bg-[#2563EB]/95 text-white border-blue-400/80 shadow-blue-950/40',
      badge: 'bg-blue-700 text-blue-100 border-blue-500',
      icon: <Info className="w-5 h-5 text-blue-100 shrink-0" />,
      accent: 'text-blue-100',
      actionBtn: 'bg-white hover:bg-blue-50 text-blue-900 border-transparent',
    },
  }[item.type];

  return (
    <div
      className={`pointer-events-auto rounded-xl p-3.5 border shadow-2xl backdrop-blur-md flex flex-col gap-2 transition-all transform animate-in slide-in-from-top-2 duration-200 ${configByType.bg}`}
      role="alert"
    >
      <div className="flex items-start gap-3">
        <div className="pt-0.5">{configByType.icon}</div>
        <div className="flex-1 min-w-0">
          {item.title && (
            <h4 className="text-xs font-bold uppercase tracking-wider mb-0.5 flex items-center gap-1.5 text-white">
              {item.title}
            </h4>
          )}
          <p className="text-xs leading-relaxed text-neutral-100 font-medium break-words">
            {item.message}
          </p>
        </div>
        <button
          type="button"
          onClick={onDismiss}
          className="p-1 rounded-md text-white/70 hover:text-white hover:bg-white/10 transition shrink-0 cursor-pointer -mr-1 -mt-1 active:scale-95"
          title="Dismiss"
          aria-label="Dismiss notification"
        >
          <X className="w-4 h-4" />
        </button>
      </div>

      {item.action && (
        <div className="flex items-center justify-end gap-2 pt-1 border-t border-white/15 mt-0.5">
          <button
            type="button"
            onClick={() => {
              try {
                item.action?.onClick();
              } finally {
                onDismiss();
              }
            }}
            className={`px-3 py-1.5 text-xs font-bold rounded-lg shadow-sm transition inline-flex items-center gap-1.5 cursor-pointer active:scale-95 shrink-0 ${configByType.actionBtn}`}
          >
            {item.action.icon === 'link' ? (
              <ExternalLink className="w-3.5 h-3.5" />
            ) : (
              <Download className="w-3.5 h-3.5" />
            )}
            <span>{item.action.label}</span>
          </button>
        </div>
      )}
    </div>
  );
};
