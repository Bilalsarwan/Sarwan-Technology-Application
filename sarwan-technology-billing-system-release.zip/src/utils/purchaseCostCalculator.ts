import { Invoice, InvoiceItem, UserRole, Expense } from '../types';
import { calculateLineTotal } from './format';

/**
 * Authorization check for Phase 1: Purchase Cost and Profit feature.
 * ONLY super_admin and invoice_manager are permitted access.
 * payment_collector and customer are strictly forbidden.
 */
export function canAccessPurchaseCost(role?: UserRole | string | null): boolean {
  if (!role) return false;
  return role === 'super_admin' || role === 'invoice_manager';
}

/**
 * Real-Time Profit Calculation formulas for an invoice item:
 * - Unit Profit = Unit Selling Price - Unit Purchase Cost
 * - Total Item Cost = Unit Purchase Cost × Quantity
 * - Total Item Sales = Unit Selling Price × Quantity
 * - Total Item Profit = (Unit Selling Price - Unit Purchase Cost) × Quantity
 */
export interface ItemProfitCalculations {
  unitSellingPrice: number;
  unitPurchaseCost: number;
  quantity: number;
  unitProfit: number;
  totalCost: number;
  totalSales: number;
  totalProfit: number;
}

/**
 * Validates that the purchase cost is a valid, non-negative number.
 */
export function validatePurchaseCost(
  cost: unknown
): { isValid: boolean; error?: string } {
  if (cost === undefined || cost === null || cost === '') {
    return { isValid: true }; // optional / not yet entered
  }
  const num = typeof cost === 'number' ? cost : parseFloat(String(cost));
  if (isNaN(num)) {
    return { isValid: false, error: 'Purchase cost must be a valid number.' };
  }
  if (!isFinite(num)) {
    return { isValid: false, error: 'Purchase cost must be a finite number.' };
  }
  if (num < 0) {
    return { isValid: false, error: 'Purchase cost must be a non-negative number.' };
  }
  return { isValid: true };
}

/**
 * Calculates item profit values in real time according to the official formulas.
 * Returns undefined values if purchaseCost is not provided.
 */
export function calculateItemProfitValues(
  quantity: number | '' | undefined,
  unitSellingPrice: number | '' | undefined,
  purchaseCost: number | '' | undefined
): {
  unitProfit?: number;
  totalCost?: number;
  totalSales?: number;
  totalProfit?: number;
} {
  if (
    purchaseCost === undefined ||
    purchaseCost === null ||
    purchaseCost === '' ||
    isNaN(Number(purchaseCost))
  ) {
    return {};
  }

  const cost = Number(purchaseCost);
  if (cost < 0) {
    return {};
  }

  const q = typeof quantity === 'number' ? quantity : parseFloat(String(quantity)) || 0;
  const p = typeof unitSellingPrice === 'number' ? unitSellingPrice : parseFloat(String(unitSellingPrice)) || 0;

  // Formula 1: Unit Profit = Unit Selling Price - Unit Purchase Cost
  const unitProfit = p - cost;

  // Formula 2: Total Item Cost = Unit Purchase Cost × Quantity
  const totalCost = cost * q;

  // Formula 3: Total Item Sales = Unit Selling Price × Quantity
  const totalSales = p * q;

  // Formula 4: Total Item Profit = (Unit Selling Price - Unit Purchase Cost) × Quantity
  const totalProfit = (p - cost) * q;

  return {
    unitProfit: Math.round(unitProfit * 100) / 100,
    totalCost: Math.round(totalCost * 100) / 100,
    totalSales: Math.round(totalSales * 100) / 100,
    totalProfit: Math.round(totalProfit * 100) / 100,
  };
}

/**
 * Sanitizes an invoice item for unauthorized roles (payment_collector, customer).
 * Strips all purchase cost and profit information.
 */
export function sanitizeInvoiceItemForRole(
  item: InvoiceItem,
  role?: UserRole | string | null
): InvoiceItem {
  if (canAccessPurchaseCost(role)) {
    return item;
  }
  const {
    purchaseCost,
    unitProfit,
    totalCost,
    totalSales,
    totalProfit,
    ...publicItem
  } = item;

  return publicItem as InvoiceItem;
}

/**
 * Sanitizes a complete invoice document for unauthorized roles.
 * Strips purchase costs, item costs, and profit data from every item and the invoice itself.
 */
export function sanitizeInvoiceForRole(
  invoice: Invoice,
  role?: UserRole | string | null
): Invoice {
  if (canAccessPurchaseCost(role)) {
    return invoice;
  }

  const sanitizedItems = (invoice.items || []).map((it) =>
    sanitizeInvoiceItemForRole(it, role)
  );

  const {
    totalPurchaseCost,
    totalProfit,
    ...publicInvoice
  } = invoice as any;

  return {
    ...publicInvoice,
    items: sanitizedItems,
  };
}

/**
 * Phase 2: Invoice Profit Summary Model
 *
 * Formulas:
 * - Total Item Cost = Sum of (Unit Purchase Cost × Quantity)
 * - Total Sales = Sum of the invoice items' selling amounts according to existing calculation model
 * - Gross Profit = Total Sales − Total Item Cost
 * - Total Expenses = Reliable expense source (AFN 0 in Phase 2 with deferred note)
 * - Net Profit = Gross Profit − Total Expenses
 */
export interface InvoiceExpenseSummaryResult {
  totalExpenses: number;
  count: number;
  latestDate: string | null;
  validExpenses: Expense[];
}

/**
 * Authoritative calculator for an invoice's direct expenses.
 * Enforces:
 * 1. Filtering valid expense records (excludes null/undefined, rejected, non-positive or non-finite amounts).
 * 2. Deduplication by expense ID (avoids counting the same expense more than once).
 * 3. Strict invoice ID association check when targetInvoiceId is provided.
 * 4. Safe rounding to 2 decimal places.
 * 5. Extraction of latest expense date.
 */
export function calculateInvoiceExpenseSummary(
  expenses: Expense[] = [],
  targetInvoiceId?: string
): InvoiceExpenseSummaryResult {
  if (!Array.isArray(expenses) || expenses.length === 0) {
    return {
      totalExpenses: 0,
      count: 0,
      latestDate: null,
      validExpenses: [],
    };
  }

  const seenIds = new Set<string>();
  const validExpenses: Expense[] = [];
  let total = 0;
  let latestDate: string | null = null;

  for (const e of expenses) {
    if (!e || typeof e !== 'object') continue;

    // Deduplicate by ID if present
    if (e.id) {
      if (seenIds.has(e.id)) continue;
      seenIds.add(e.id);
    }

    // Exclude expenses belonging to a different invoice when targetInvoiceId is supplied
    if (targetInvoiceId && e.invoiceId && e.invoiceId !== targetInvoiceId) {
      continue;
    }

    // Exclude rejected and draft expenses
    if (e.status === 'rejected' || e.status === 'draft') continue;

    const amt = Number(e.amount);
    // Ignore non-finite, zero, or negative amounts
    if (!Number.isFinite(amt) || amt <= 0) continue;

    validExpenses.push(e);
    total += amt;

    if (e.date && typeof e.date === 'string') {
      const trimmedDate = e.date.trim();
      if (trimmedDate && (!latestDate || trimmedDate > latestDate)) {
        latestDate = trimmedDate;
      }
    }
  }

  return {
    totalExpenses: Math.round(total * 100) / 100,
    count: validExpenses.length,
    latestDate,
    validExpenses,
  };
}

export interface InvoiceProfitSummary {
  totalSales: number;
  totalItemCost: number;
  grossProfit: number;
  totalExpenses: number;
  netProfit: number;
  hasCompleteCostData: boolean;
  totalItemsCount: number;
  itemsWithCostCount: number;
  missingCostItemsCount: number;
  isPartial: boolean;
  invoiceExpensesCount: number;
}

/**
 * Computes the internal Invoice Profit Summary from an invoice's line items, stored snapshots,
 * and valid invoice-specific expenses.
 *
 * Requirements:
 * 1. Total Sales: Sum of invoice line items' selling amounts using calculateLineTotal(q, p).
 * 2. Total Item Cost: Sum of (Unit Purchase Cost × Quantity) using stored snapshot for each item.
 * 3. Gross Profit: Total Sales − Total Item Cost.
 * 4. Total Expenses: Sum of valid expense records belonging to this invoice (0 if none linked).
 * 5. Net Profit: Gross Profit − Total Expenses.
 * 6. Never invent missing historical costs. If any populated item has missing cost,
 *    clearly flag hasCompleteCostData: false so the summary is shown as incomplete.
 */
export function calculateInvoiceProfitSummary(
  items: InvoiceItem[] = [],
  invoiceExpenses?: number | Expense[],
  targetInvoiceId?: string
): InvoiceProfitSummary {
  // Filter for active/populated items with description or quantity > 0
  const populatedItems = items.filter(
    (it) => (it.description && it.description.trim().length > 0) || (Number(it.quantity) || 0) > 0
  );

  let totalSales = 0;
  let totalItemCost = 0;
  let itemsWithCostCount = 0;
  let missingCostItemsCount = 0;

  for (const item of populatedItems) {
    const q = typeof item.quantity === 'number' ? item.quantity : parseFloat(String(item.quantity)) || 0;
    const lineSales = calculateLineTotal(item.quantity, item.unitPrice);
    totalSales += lineSales;

    const rawCost = item.purchaseCost;
    if (
      rawCost !== undefined &&
      rawCost !== null &&
      rawCost !== '' &&
      !isNaN(Number(rawCost)) &&
      Number(rawCost) >= 0
    ) {
      const unitCost = Number(rawCost);
      const itemCost = Math.round(unitCost * q * 100) / 100;
      totalItemCost += itemCost;
      itemsWithCostCount++;
    } else {
      missingCostItemsCount++;
    }
  }

  // Rounded values
  totalSales = Math.round(totalSales * 100) / 100;
  totalItemCost = Math.round(totalItemCost * 100) / 100;
  const grossProfit = Math.round((totalSales - totalItemCost) * 100) / 100;

  let totalExpenses = 0;
  let invoiceExpensesCount = 0;
  if (typeof invoiceExpenses === 'number') {
    totalExpenses = Math.max(0, Math.round(invoiceExpenses * 100) / 100);
    if (totalExpenses > 0) {
      invoiceExpensesCount = 1;
    }
  } else if (Array.isArray(invoiceExpenses)) {
    const expSummary = calculateInvoiceExpenseSummary(invoiceExpenses, targetInvoiceId);
    totalExpenses = expSummary.totalExpenses;
    invoiceExpensesCount = expSummary.count;
  }

  const netProfit = Math.round((grossProfit - totalExpenses) * 100) / 100;

  const totalItemsCount = populatedItems.length;
  // If there are no items, cost is not considered incomplete, but total is 0
  const hasCompleteCostData = totalItemsCount > 0 && missingCostItemsCount === 0;
  const isPartial = totalItemsCount > 0 && itemsWithCostCount > 0 && missingCostItemsCount > 0;

  return {
    totalSales,
    totalItemCost,
    grossProfit,
    totalExpenses,
    netProfit,
    hasCompleteCostData,
    totalItemsCount,
    itemsWithCostCount,
    missingCostItemsCount,
    isPartial,
    invoiceExpensesCount,
  };
}

