import { Invoice, InvoiceItem, UserRole } from '../types';
import {
  canAccessPurchaseCost,
  calculateItemProfitValues,
  calculateInvoiceProfitSummary,
  sanitizeInvoiceForRole,
  sanitizeInvoiceItemForRole,
  validatePurchaseCost,
} from './purchaseCostCalculator';
import {
  formatAFN,
  calculateLineTotal,
  calculateInvoiceTotal,
  calculateRemaining,
} from './format';

let totalTests = 0;
let passedTests = 0;

function assert(condition: boolean, testName: string, details?: any) {
  totalTests++;
  if (condition) {
    passedTests++;
    console.log(`  ✓ PASS: ${testName}`);
  } else {
    console.error(`  ✗ FAIL: ${testName}`, details || '');
  }
}

console.log('\n======================================================');
console.log('PHASE 2: INTERNAL INVOICE PROFIT SUMMARY VERIFICATION');
console.log('======================================================\n');

// -------------------------------------------------------------------------
// 1. Profit Summary Calculation Rules
// -------------------------------------------------------------------------
console.log('--- 1. PROFIT SUMMARY CALCULATION RULES & FORMULAS ---');

// Scenario A: Standard complete cost items
const sampleItemsComplete: InvoiceItem[] = [
  {
    sNo: 1,
    description: '5MP Hikvision Bullet Camera',
    quantity: 4,
    unitPrice: 2500, // Sales: 10,000 AFN
    purchaseCost: 1800, // Cost: 7,200 AFN
    totalAmount: 10000,
    unitProfit: 700,
    totalCost: 7200,
    totalSales: 10000,
    totalProfit: 2800,
  },
  {
    sNo: 2,
    description: '8-Port PoE Gigabit Switch',
    quantity: 2,
    unitPrice: 4000, // Sales: 8,000 AFN
    purchaseCost: 3100, // Cost: 6,200 AFN
    totalAmount: 8000,
    unitProfit: 900,
    totalCost: 6200,
    totalSales: 8000,
    totalProfit: 1800,
  },
];

const summaryA = calculateInvoiceProfitSummary(sampleItemsComplete);

assert(summaryA.totalSales === 18000, 'Total Sales = Sum of line sales (10,000 + 8,000 = 18,000 AFN)');
assert(summaryA.totalItemCost === 13400, 'Total Item Cost = Sum of (Unit Purchase Cost × Quantity) (7,200 + 6,200 = 13,400 AFN)');
assert(summaryA.grossProfit === 4600, 'Gross Profit = Total Sales − Total Item Cost (18,000 - 13,400 = 4,600 AFN)');
assert(summaryA.totalExpenses === 0, 'Total Expenses = AFN 0 (Phase 3 deferred)');
assert(summaryA.netProfit === 4600, 'Net Profit = Gross Profit − Total Expenses (4,600 - 0 = 4,600 AFN)');
assert(summaryA.hasCompleteCostData === true, 'hasCompleteCostData is true when all populated items have valid cost');
assert(summaryA.itemsWithCostCount === 2, 'itemsWithCostCount is 2');
assert(summaryA.missingCostItemsCount === 0, 'missingCostItemsCount is 0');
assert(summaryA.isPartial === false, 'isPartial is false when complete');

// -------------------------------------------------------------------------
// 2. Incomplete Cost Data & Historical Backward Compatibility
// -------------------------------------------------------------------------
console.log('\n--- 2. INCOMPLETE COST DATA & HISTORICAL INVOICES ---');

// Scenario B: Partial cost data (one item has cost, another does not)
const sampleItemsPartial: InvoiceItem[] = [
  {
    sNo: 1,
    description: 'Solar Inverter 3KW',
    quantity: 1,
    unitPrice: 20000,
    purchaseCost: 16500,
    totalAmount: 20000,
  },
  {
    sNo: 2,
    description: 'Installation Service & Labor',
    quantity: 1,
    unitPrice: 5000,
    purchaseCost: undefined, // Missing / not recorded
    totalAmount: 5000,
  },
];

const summaryB = calculateInvoiceProfitSummary(sampleItemsPartial);

assert(summaryB.totalSales === 25000, 'Total Sales calculates all line items correctly (25,000 AFN)');
assert(summaryB.totalItemCost === 16500, 'Total Item Cost only sums available cost snapshot without inventing missing costs (16,500 AFN)');
assert(summaryB.grossProfit === 8500, 'Gross Profit is calculated strictly from available costs (8,500 AFN)');
assert(summaryB.hasCompleteCostData === false, 'hasCompleteCostData is false when any item is missing purchase cost');
assert(summaryB.isPartial === true, 'isPartial is true when some items have cost and some do not');
assert(summaryB.itemsWithCostCount === 1, 'itemsWithCostCount reflects exact count of costed items');
assert(summaryB.missingCostItemsCount === 1, 'missingCostItemsCount reflects exact count of missing items');

// Scenario C: Legacy historical invoice with zero cost data
const sampleLegacyInvoice: InvoiceItem[] = [
  {
    sNo: 1,
    description: 'Cat6 Network Cable 305m Roll',
    quantity: 3,
    unitPrice: 4500,
    totalAmount: 13500,
  },
];

const summaryC = calculateInvoiceProfitSummary(sampleLegacyInvoice);

assert(summaryC.totalSales === 13500, 'Legacy invoice total sales is preserved (13,500 AFN)');
assert(summaryC.totalItemCost === 0, 'Legacy invoice has AFN 0 total cost (never fabricates historical cost)');
assert(summaryC.hasCompleteCostData === false, 'Legacy invoice is flagged as incomplete cost data');
assert(summaryC.missingCostItemsCount === 1, 'Legacy invoice has 1 item missing cost');

// Scenario D: Empty items array
const summaryD = calculateInvoiceProfitSummary([]);
assert(summaryD.totalSales === 0 && summaryD.totalItemCost === 0 && summaryD.grossProfit === 0, 'Empty items yield 0 totals');
assert(summaryD.hasCompleteCostData === false, 'Empty items does not claim complete cost data');

// -------------------------------------------------------------------------
// 3. Role-Based Access Control & Security
// -------------------------------------------------------------------------
console.log('\n--- 3. ROLE-BASED ACCESS CONTROL & SECURITY ---');

assert(canAccessPurchaseCost('super_admin') === true, 'Super Admin is authorized to view purchase cost and profit');
assert(canAccessPurchaseCost('invoice_manager') === true, 'Invoice Manager is authorized to view purchase cost and profit');
assert(canAccessPurchaseCost('payment_collector') === false, 'Payment Collector is strictly denied purchase cost and profit access');
assert(canAccessPurchaseCost('customer') === false, 'Customer is strictly denied purchase cost and profit access');
assert(canAccessPurchaseCost(null) === false, 'Null / Unauthenticated is denied access');
assert(canAccessPurchaseCost(undefined) === false, 'Undefined role is denied access');

// Security Sanitization check
const testInvoiceToSanitize: Invoice = {
  id: 'INV-TEST-001',
  billNumber: 'ST-1065',
  customerId: 'CUST-001',
  customerSnapshot: { id: 'CUST-001', name: 'Zia Khan', phone: '0700123456', address: 'Kabul', companyName: 'Zia Logistics' },
  companySnapshot: {
    companyName: 'Sarwan Technology',
    logo: '',
    phone: '0731339014',
    whatsapp: '0731339014',
    email: 'info@sarwantechnology.af',
    address: 'Kabul, Afghanistan',
    currency: 'AFN',
    invoiceNote: 'Thank you',
  },
  date: '2026-10-09',
  items: sampleItemsComplete,
  totalAmount: 18000,
  totalPaid: 0,
  remaining: 18000,
  totalPurchaseCost: 13400,
  totalProfit: 4600,
  createdAt: '2026-10-09T00:00:00Z',
  updatedAt: '2026-10-09T00:00:00Z',
  note: '',
  status: 'Unpaid',
  billingState: 'payable',
};

// Test Collector Sanitization
const collectorSanitized = sanitizeInvoiceForRole(testInvoiceToSanitize, 'payment_collector');
assert((collectorSanitized as any).totalPurchaseCost === undefined, 'Collector invoice has totalPurchaseCost stripped');
assert((collectorSanitized as any).totalProfit === undefined, 'Collector invoice has totalProfit stripped');
assert(collectorSanitized.items[0].purchaseCost === undefined, 'Collector item has purchaseCost stripped');
assert(collectorSanitized.items[0].unitProfit === undefined, 'Collector item has unitProfit stripped');
assert(collectorSanitized.items[0].totalCost === undefined, 'Collector item has totalCost stripped');
assert(collectorSanitized.items[0].totalProfit === undefined, 'Collector item has totalProfit stripped');
assert(collectorSanitized.items[0].totalAmount === 10000, 'Collector item preserves totalAmount and selling price');

// Test Customer Sanitization
const customerSanitized = sanitizeInvoiceForRole(testInvoiceToSanitize, 'customer');
assert((customerSanitized as any).totalPurchaseCost === undefined, 'Customer invoice has totalPurchaseCost stripped');
assert((customerSanitized as any).totalProfit === undefined, 'Customer invoice has totalProfit stripped');
assert(customerSanitized.items[0].purchaseCost === undefined, 'Customer item has purchaseCost stripped');

// Test Super Admin Sanitization (preserves data)
const adminPreserved = sanitizeInvoiceForRole(testInvoiceToSanitize, 'super_admin');
assert((adminPreserved as any).totalPurchaseCost === 13400, 'Super Admin retains totalPurchaseCost');
assert(adminPreserved.items[0].purchaseCost === 1800, 'Super Admin retains item purchaseCost');

// -------------------------------------------------------------------------
// 4. Currency Formatting Verification
// -------------------------------------------------------------------------
console.log('\n--- 4. CURRENCY FORMATTING (AFN) ---');

assert(formatAFN(4600).includes('AFN'), 'formatAFN outputs AFN currency');
assert(formatAFN(0).includes('AFN'), 'formatAFN(0) outputs AFN currency');
assert(!formatAFN(4600).includes('$'), 'formatAFN never contains dollar signs ($)');

// -------------------------------------------------------------------------
// 5. Negative / Zero Margins Handling
// -------------------------------------------------------------------------
console.log('\n--- 5. NEGATIVE / ZERO PROFIT MARGINS ---');

const lossItems: InvoiceItem[] = [
  {
    sNo: 1,
    description: 'Clearance Item sold below cost',
    quantity: 2,
    unitPrice: 1000, // Sales: 2,000 AFN
    purchaseCost: 1500, // Cost: 3,000 AFN
    totalAmount: 2000,
  },
];
const lossSummary = calculateInvoiceProfitSummary(lossItems);
assert(lossSummary.totalSales === 2000, 'Loss item total sales = 2,000 AFN');
assert(lossSummary.totalItemCost === 3000, 'Loss item total cost = 3,000 AFN');
assert(lossSummary.grossProfit === -1000, 'Loss item gross profit is -1,000 AFN (negative profit handled gracefully)');
assert(lossSummary.netProfit === -1000, 'Loss item net profit is -1,000 AFN');

// -------------------------------------------------------------------------
// 6. Purchase Cost Input Validation (Numeric, Finite, Non-Negative, Optional)
// -------------------------------------------------------------------------
console.log('\n--- 6. PURCHASE COST INPUT VALIDATION ---');

assert(validatePurchaseCost(undefined).isValid === true, 'Undefined purchase cost is valid (optional field)');
assert(validatePurchaseCost(null).isValid === true, 'Null purchase cost is valid (optional field)');
assert(validatePurchaseCost('').isValid === true, 'Empty string purchase cost is valid (optional field)');
assert(validatePurchaseCost(0).isValid === true, 'Zero purchase cost is valid');
assert(validatePurchaseCost('0').isValid === true, 'Zero string purchase cost is valid');
assert(validatePurchaseCost(1500).isValid === true, 'Positive purchase cost is valid');
assert(validatePurchaseCost('1500.50').isValid === true, 'Positive decimal purchase cost is valid');
assert(validatePurchaseCost(-10).isValid === false, 'Negative purchase cost is rejected');
assert(validatePurchaseCost('-500').isValid === false, 'Negative string purchase cost is rejected');
assert(validatePurchaseCost('abc').isValid === false, 'Non-numeric string purchase cost is rejected');
assert(validatePurchaseCost(Infinity).isValid === false, 'Infinity purchase cost is rejected as not finite');
assert(validatePurchaseCost(-Infinity).isValid === false, '-Infinity purchase cost is rejected as not finite');
assert(validatePurchaseCost(NaN).isValid === false, 'NaN purchase cost is rejected');

// -------------------------------------------------------------------------
// 7. Real-Time Item Cost and Profit Formulas
// -------------------------------------------------------------------------
console.log('\n--- 7. REAL-TIME ITEM COST & PROFIT FORMULAS ---');

// Formula 1: Unit Profit = Unit Selling Price - Unit Purchase Cost
// Formula 2: Total Item Cost = Unit Purchase Cost × Quantity
// Formula 3: Total Item Sales = Unit Selling Price × Quantity
// Formula 4: Total Item Profit = (Unit Selling Price - Unit Purchase Cost) × Quantity
const calcs1 = calculateItemProfitValues(5, 2000, 1400);
assert(calcs1.unitProfit === 600, 'Unit Profit = 2000 - 1400 = 600 AFN');
assert(calcs1.totalCost === 7000, 'Total Item Cost = 1400 × 5 = 7,000 AFN');
assert(calcs1.totalSales === 10000, 'Total Item Sales = 2000 × 5 = 10,000 AFN');
assert(calcs1.totalProfit === 3000, 'Total Item Profit = (2000 - 1400) × 5 = 3,000 AFN');

// Partial/Empty cost behavior (does not compute, returns empty object)
const emptyCostCalcs = calculateItemProfitValues(5, 2000, '');
assert(emptyCostCalcs.unitProfit === undefined, 'Empty cost returns undefined unitProfit');
assert(emptyCostCalcs.totalCost === undefined, 'Empty cost returns undefined totalCost');

// -------------------------------------------------------------------------
// 8. Customer Billing Integrity & Pricing Unaffected
// -------------------------------------------------------------------------
console.log('\n--- 8. CUSTOMER BILLING INTEGRITY (UNAFFECTED BY PURCHASE COST) ---');

const billingTestItems: InvoiceItem[] = [
  { sNo: 1, description: 'Item 1', quantity: 3, unitPrice: 1200, purchaseCost: 800, totalAmount: 3600 },
  { sNo: 2, description: 'Item 2', quantity: 2, unitPrice: 2500, purchaseCost: 2000, totalAmount: 5000 },
];
const subtotalSales = calculateInvoiceTotal(billingTestItems);
const remainingBal = calculateRemaining(subtotalSales, 2000);
assert(subtotalSales === 8600, 'Customer invoice total is strictly selling amount (8,600 AFN)');
assert(remainingBal === 6600, 'Remaining balance is strictly invoice total - cash paid (6,600 AFN)');

// -------------------------------------------------------------------------
// 9. Historical Invoices & Incomplete Cost Data
// -------------------------------------------------------------------------
console.log('\n--- 9. HISTORICAL INVOICES & INCOMPLETE COST DATA ---');

const mixedHistoryItems: InvoiceItem[] = [
  { sNo: 1, description: 'New Camera', quantity: 2, unitPrice: 3000, purchaseCost: 2200, totalAmount: 6000 },
  { sNo: 2, description: 'Old Cable without cost', quantity: 5, unitPrice: 500, totalAmount: 2500 },
];
const mixedSummary = calculateInvoiceProfitSummary(mixedHistoryItems);
assert(mixedSummary.totalSales === 8500, 'Total sales sums all items (8,500 AFN)');
assert(mixedSummary.totalItemCost === 4400, 'Total cost sums only available cost snapshots (4,400 AFN)');
assert(mixedSummary.grossProfit === 4100, 'Gross profit = 8500 - 4400 = 4,100 AFN');
assert(mixedSummary.hasCompleteCostData === false, 'hasCompleteCostData is false because historical item lacks cost');
assert(mixedSummary.missingCostItemsCount === 1, 'missingCostItemsCount is accurately 1');
assert(mixedSummary.itemsWithCostCount === 1, 'itemsWithCostCount is accurately 1');

// -------------------------------------------------------------------------
// 10. Invoice-Specific Expenses Aggregation & Net Profit Verification
// -------------------------------------------------------------------------
console.log('\n--- 10. INVOICE-SPECIFIC EXPENSES AGGREGATION & NET PROFIT ---');

const invoiceSpecificExpenses: any[] = [
  { id: 'exp-1', invoiceId: 'inv-123', amount: 500, status: 'approved' },
  { id: 'exp-2', invoiceId: 'inv-123', amount: 350, status: 'executed' },
  { id: 'exp-3', invoiceId: 'inv-123', amount: 200, status: 'pending_admin' },
  { id: 'exp-4', invoiceId: 'inv-123', amount: 999, status: 'rejected' }, // Rejected: MUST NOT count
  { id: 'exp-5', invoiceId: 'inv-123', amount: 888, status: 'draft' },    // Draft: MUST NOT count
];

const summaryWithExpenses = calculateInvoiceProfitSummary(sampleItemsComplete, invoiceSpecificExpenses);
assert(summaryWithExpenses.totalSales === 18000, 'Sales unchanged when expenses present (18,000 AFN)');
assert(summaryWithExpenses.totalItemCost === 13400, 'Item cost unchanged when expenses present (13,400 AFN)');
assert(summaryWithExpenses.grossProfit === 4600, 'Gross profit = 18,000 - 13,400 = 4,600 AFN');
assert(summaryWithExpenses.totalExpenses === 1050, 'Total Expenses aggregates approved/executed/pending expenses (500 + 350 + 200 = 1,050 AFN)');
assert(summaryWithExpenses.invoiceExpensesCount === 3, 'Valid expense count excludes rejected and draft records');
assert(summaryWithExpenses.netProfit === 3550, 'Net Profit = Gross Profit − Total Expenses (4,600 - 1,050 = 3,550 AFN)');

// Test numeric expense argument support
const summaryNumericExpense = calculateInvoiceProfitSummary(sampleItemsComplete, 600);
assert(summaryNumericExpense.totalExpenses === 600, 'Numeric expense argument supported (600 AFN)');
assert(summaryNumericExpense.netProfit === 4000, 'Net Profit with numeric expense = 4,600 - 600 = 4,000 AFN');

// -------------------------------------------------------------------------
// 11. Stored Purchase-Cost Snapshot Persistence & Reopening
// -------------------------------------------------------------------------
console.log('\n--- 11. STORED PURCHASE-COST SNAPSHOT REOPENING INTEGRITY ---');

const persistedInvoice: Invoice = {
  id: 'inv-persisted-1',
  billNumber: 'ST-INV-2026-0099',
  customerId: 'cust-1',
  customerSnapshot: {
    id: 'cust-1',
    name: 'Kabul Supermarket',
    phone: '0799000111',
    address: 'Kabul',
    companyName: 'Kabul Supermarket LLC',
  },
  companySnapshot: {
    companyName: 'Sarwan Technology',
    logo: '',
    phone: '0700000000',
    whatsapp: '0700000000',
    email: 'info@sarwan.af',
    address: 'Kabul, Afghanistan',
    currency: 'AFN',
    invoiceNote: 'Thank you',
  },
  date: '2026-10-09',
  note: 'Test order',
  createdAt: '2026-10-09T08:00:00.000Z',
  updatedAt: '2026-10-09T08:00:00.000Z',
  status: 'Unpaid',
  billingState: 'payable',
  totalAmount: 18000,
  totalPurchaseCost: 13400,
  totalProfit: 4600,
  items: sampleItemsComplete,
};

const reopenedSummary = calculateInvoiceProfitSummary(persistedInvoice.items || [], persistedInvoice.expenses || persistedInvoice.totalExpenses || 0);
assert(reopenedSummary.totalSales === persistedInvoice.totalAmount, 'Reopened invoice total sales matches stored invoice amount (18,000 AFN)');
assert(reopenedSummary.totalItemCost === persistedInvoice.totalPurchaseCost, 'Reopened invoice item cost matches stored snapshot (13,400 AFN)');
assert(reopenedSummary.grossProfit === persistedInvoice.totalProfit, 'Reopened invoice gross profit matches stored totalProfit (4,600 AFN)');
assert(reopenedSummary.netProfit === 4600, 'Reopened net profit matches gross profit when no expenses');

// Reopen with expenses attached to invoice
const persistedInvoiceWithExp: Invoice = {
  ...persistedInvoice,
  expenses: invoiceSpecificExpenses,
  totalExpenses: 1050,
  netProfit: 3550,
};
const reopenedExpSummary = calculateInvoiceProfitSummary(persistedInvoiceWithExp.items || [], persistedInvoiceWithExp.expenses);
assert(reopenedExpSummary.totalExpenses === 1050, 'Reopened invoice correctly loads stored invoice expenses (1,050 AFN)');
assert(reopenedExpSummary.netProfit === 3550, 'Reopened invoice correctly loads stored net profit (3,550 AFN)');

// -------------------------------------------------------------------------
// 12. Strict Customer and Non-Privileged Isolation
// -------------------------------------------------------------------------
console.log('\n--- 12. STRICT CUSTOMER & PRINT/PDF EXPOSURE ISOLATION ---');

const sanitizedCustomerView = sanitizeInvoiceForRole(persistedInvoiceWithExp, 'customer');
assert((sanitizedCustomerView as any).totalPurchaseCost === undefined, 'Customer view strictly hides totalPurchaseCost');
assert((sanitizedCustomerView as any).totalProfit === undefined, 'Customer view strictly hides totalProfit');
assert(sanitizedCustomerView.items[0].purchaseCost === undefined, 'Customer view strictly hides line purchaseCost');
assert(sanitizedCustomerView.items[0].unitProfit === undefined, 'Customer view strictly hides line unitProfit');
assert(sanitizedCustomerView.items[0].totalProfit === undefined, 'Customer view strictly hides line totalProfit');
assert(sanitizedCustomerView.totalAmount === 18000, 'Customer view preserves exact billing totalAmount (18,000 AFN)');

console.log('\n======================================================');
console.log(`ALL TESTS COMPLETED: ${passedTests}/${totalTests} PASSED`);
console.log('======================================================\n');

if (passedTests !== totalTests) {
  process.exit(1);
}
