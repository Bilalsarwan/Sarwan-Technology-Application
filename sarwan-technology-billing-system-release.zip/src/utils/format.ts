import { Invoice, InvoiceItem, Payment, Customer, UserProfile } from '../types';

/**
 * Centralized formatting rule for all invoice numeric displays.
 * Globally removes unnecessary trailing decimal zeros while preserving meaningful decimals:
 * - 100.00 -> "100"
 * - 100.50 -> "100.5"
 * - 25.00 -> "25"
 * - 25.40 -> "25.4"
 * - 0.00 -> "0"
 * - 100.25 -> "100.25"
 * - 12500 -> "12,500"
 * - 12500.50 -> "12,500.5"
 *
 * Rules:
 * - Does NOT force two decimal places anywhere
 * - Does NOT display .00 or trailing zeros
 * - Preserves standard comma thousands separators
 * - Safe against strings, numbers, undefined, null, or empty values
 */
export function formatInvoiceNumber(
  val: number | string | undefined | null,
  fallback = '0'
): string {
  if (val === undefined || val === null || val === '') {
    return fallback;
  }
  const cleanStr = typeof val === 'string' ? val.replace(/,/g, '').trim() : String(val);
  if (cleanStr === '') return fallback;
  const num = Number(cleanStr);
  if (!Number.isFinite(num)) {
    return fallback;
  }
  return new Intl.NumberFormat('en-US', {
    minimumFractionDigits: 0,
    maximumFractionDigits: 4,
  }).format(num);
}

/**
 * Formats a number as Afghani currency (AFN) with standard comma separators
 * without unnecessary trailing zeros.
 * Example: 50000 -> "50,000 AFN" or with prefix: "AFN 50,000"
 * 100.50 -> "100.5 AFN", 100.00 -> "100 AFN", 0.00 -> "0 AFN"
 */
export function formatAFN(amount: number | string | undefined | null, prefix = false): string {
  if (amount === undefined || amount === null || amount === '') {
    return prefix ? 'AFN 0' : '0 AFN';
  }
  const formatted = formatInvoiceNumber(amount);
  return prefix ? `AFN ${formatted}` : `${formatted} AFN`;
}

/**
 * Formats a monetary number with the Afghan Afghani currency symbol (؋)
 * without unnecessary trailing zeros.
 * Example: 50000 -> "؋ 50,000", 100.50 -> "؋ 100.5", 0.00 -> "؋ 0"
 */
export function formatAfghani(amount: number | string | undefined | null): string {
  if (amount === undefined || amount === null || amount === '') {
    return '؋ 0';
  }
  const formatted = formatInvoiceNumber(amount);
  return `؋ ${formatted}`;
}

/**
 * Formats integer counts with standard comma separation (e.g. 1250 -> "1,250")
 */
export function formatCount(count: number | undefined | null): string {
  if (count === undefined || count === null || isNaN(count)) {
    return '0';
  }
  const safe = Math.max(0, Math.round(count));
  return new Intl.NumberFormat('en-US').format(safe);
}

/**
 * Formats date string (YYYY-MM-DD or ISO) into readable presentation
 */
export function formatDate(dateString: string | undefined | null): string {
  if (!dateString) return '—';
  try {
    const d = new Date(dateString);
    if (isNaN(d.getTime())) return dateString;
    return d.toLocaleDateString('en-GB', {
      day: 'numeric',
      month: 'short',
      year: 'numeric',
    });
  } catch {
    return dateString;
  }
}

/**
 * Formats date for official Sarwan Invoice matching real PDF ("4 Sep 2026")
 */
export function formatInvoicePrintDate(dateString: string | undefined | null): string {
  if (!dateString) return '';
  try {
    const parts = dateString.split('-');
    if (parts.length === 3) {
      const year = parseInt(parts[0], 10);
      const monthIndex = parseInt(parts[1], 10) - 1;
      const day = parseInt(parts[2], 10);
      const months = [
        'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
        'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'
      ];
      if (!isNaN(day) && monthIndex >= 0 && monthIndex < 12 && !isNaN(year)) {
        return `${day} ${months[monthIndex]} ${year}`;
      }
    }
    const d = new Date(dateString);
    if (isNaN(d.getTime())) return dateString;
    const day = d.getDate();
    const months = [
      'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
      'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'
    ];
    return `${day} ${months[d.getMonth()]} ${d.getFullYear()}`;
  } catch {
    return dateString;
  }
}

/**
 * Returns today's date formatted as YYYY-MM-DD for input fields
 */
export function getTodayDateString(): string {
  const now = new Date();
  const year = now.getFullYear();
  const month = String(now.getMonth() + 1).padStart(2, '0');
  const day = String(now.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

/**
 * Line Total = Quantity × Unit Price
 */
export function calculateLineTotal(quantity: number | '', unitPrice: number | ''): number {
  const q = typeof quantity === 'number' ? quantity : parseFloat(String(quantity)) || 0;
  const p = typeof unitPrice === 'number' ? unitPrice : parseFloat(String(unitPrice)) || 0;
  if (q < 0 || p < 0) return 0;
  return Math.round(q * p);
}

/**
 * Invoice Total = Sum of all line totals
 */
export function calculateInvoiceTotal(items: InvoiceItem[]): number {
  if (!items || !items.length) return 0;
  return items.reduce((sum, item) => {
    return sum + calculateLineTotal(item.quantity, item.unitPrice);
  }, 0);
}

/**
 * Total Paid = Sum of all payment transactions connected to that invoice
 */
export function calculateTotalPaidForInvoice(invoiceId: string, payments: Payment[]): number {
  if (!payments || !payments.length) return 0;
  return payments
    .filter((p) => p.invoiceId === invoiceId)
    .reduce((sum, p) => sum + (Number(p.amount) || 0), 0);
}

/**
 * Remaining = Invoice Total - Total Paid
 */
export function calculateRemaining(invoiceTotal: number, totalPaid: number): number {
  return Math.max(0, invoiceTotal - totalPaid);
}

/**
 * Calculates customer-level totals:
 * - Total Invoices
 * - Total Sales (Sum of invoice totals for customer)
 * - Total Paid (Sum of customer payment transactions)
 * - Remaining Balance (Total Sales - Total Paid)
 */
export function calculateCustomerSummary(
  customerId: string,
  invoices: Invoice[] = [],
  payments: Payment[] = []
) {
  if (!customerId) {
    return {
      totalInvoices: 0,
      totalSales: 0,
      totalPaid: 0,
      remainingBalance: 0,
      customerInvoices: [],
      customerPayments: [],
    };
  }

  // Filter invoices belonging strictly to this customer
  const customerInvoices = invoices.filter(
    (inv) => inv.customerId === customerId || inv.customerSnapshot?.id === customerId
  );

  // Filter payments belonging strictly to this customer
  const customerPayments = payments.filter((p) => p.customerId === customerId);

  // Total Sales excludes void, quotation, and rejected invoices (only payable)
  const totalSales = customerInvoices
    .filter((inv) => inv.status !== 'Void' && !inv.isVoid && inv.billingState !== 'quotation' && inv.billingState !== 'rejected')
    .reduce((sum, inv) => sum + (Number(inv.totalAmount) || 0), 0);

  // Total Paid excludes void payments
  const totalPaid = customerPayments
    .filter((p) => !p.isVoid)
    .reduce((sum, p) => sum + (Number(p.amount) || 0), 0);

  const remainingBalance = Math.max(0, totalSales - totalPaid);

  // Check if customer has any overdue unpaid/partially paid invoices
  const todayStr = new Date().toISOString().slice(0, 10);
  const hasOverdue = customerInvoices.some((inv) => {
    if (inv.status === 'Void' || inv.isVoid || inv.status === 'Paid') return false;
    if (inv.billingState === 'quotation' || inv.billingState === 'rejected') return false;
    if (inv.dueDate && inv.dueDate < todayStr) {
      const invTotal = Number(inv.totalAmount) || 0;
      const invPaid = customerPayments
        .filter((p) => p.invoiceId === inv.id && !p.isVoid)
        .reduce((sum, p) => sum + (Number(p.amount) || 0), 0);
      return Math.max(0, invTotal - invPaid) > 0;
    }
    return false;
  });

  const financialStatus: 'Paid' | 'Outstanding' | 'Overdue' = hasOverdue
    ? 'Overdue'
    : remainingBalance > 0
    ? 'Outstanding'
    : 'Paid';

  return {
    totalInvoices: customerInvoices.length,
    totalSales,
    totalPaid,
    remainingBalance,
    customerInvoices,
    customerPayments,
    hasOverdue,
    financialStatus,
  };
}

// =========================================================================
// ORGANIZATION KPIS CALCULATION FUNCTIONS
// =========================================================================

/**
 * 1. Total Users
 * Formula: Total Users = count of all existing user accounts
 * Rules:
 * - Count every existing user record regardless of its current status.
 * - Active, inactive, suspended, pending, or other valid status values are included.
 * - Excludes non-existent/deleted records.
 * - Does not filter by role.
 */
export function calculateTotalUsers(users: UserProfile[] = []): number {
  if (!Array.isArray(users)) return 0;
  return users.filter((u) => u && typeof u === 'object' && Boolean(u.id)).length;
}

/**
 * 2. Total Customers
 * Formula: Total Customers = count(customers where isArchived !== true)
 * Rules:
 * - Count only real customer records with valid id.
 * - Exclude customers where isArchived === true.
 * - Archived customers must not contribute to the KPI.
 */
export function calculateTotalCustomers(customers: Customer[] = []): number {
  if (!Array.isArray(customers)) return 0;
  return customers.filter(
    (c) => c && typeof c === 'object' && Boolean(c.id) && c.isArchived !== true
  ).length;
}

/**
 * 3. Total Invoices
 * Formula: Total Invoices = count(invoices where isVoid !== true)
 * Rules:
 * - Count all valid invoices with valid id.
 * - Exclude every invoice where isVoid === true.
 * - Paid, partially paid, unpaid, and overdue valid invoices are all included.
 */
export function calculateTotalInvoices(invoices: Invoice[] = []): number {
  if (!Array.isArray(invoices)) return 0;
  return invoices.filter(
    (inv) => inv && typeof inv === 'object' && Boolean(inv.id) && inv.isVoid !== true && inv.status !== 'Void'
  ).length;
}

/**
 * 4. Total Payments
 * Formula: Total Payments = SUM(amount of all valid payments where isVoid !== true)
 * Rules:
 * - Use only real payment records with valid id.
 * - Exclude every payment where isVoid === true.
 * - Include valid payments regardless of which invoice they belong to.
 * - Multiple valid payments for the same invoice must all be included.
 * - Sum the actual payment amount values directly from valid payment records.
 * - Handle missing/null/invalid amounts safely without producing NaN.
 */
export function calculateTotalPayments(payments: Payment[] = []): number {
  if (!Array.isArray(payments)) return 0;
  return payments.reduce((sum, p) => {
    if (!p || typeof p !== 'object' || !p.id || p.isVoid === true) {
      return sum;
    }
    const rawAmount = typeof p.amount === 'number' ? p.amount : parseFloat(String(p.amount ?? 0));
    const validAmount = Number.isFinite(rawAmount) && rawAmount > 0 ? rawAmount : 0;
    return sum + validAmount;
  }, 0);
}

/**
 * 5. Total Outstanding
 * Formula:
 * For every valid invoice (where isVoid !== true):
 *   Invoice Paid Amount = SUM(all valid payments belonging to that invoice where isVoid !== true)
 *   Invoice Outstanding = Math.max(0, Invoice Total Amount - Invoice Paid Amount)
 * Finally:
 *   Total Outstanding = SUM(all valid invoice outstanding amounts)
 * Rules:
 * - Only invoices where isVoid !== true are included.
 * - Only payments where isVoid !== true are included.
 * - Payments must be matched using actual invoice/payment database relationship (invoiceId with billNumber fallback).
 * - Multiple payments for one invoice are summed together.
 * - A fully paid invoice contributes 0.
 * - Clamps negative outstanding amount to 0 (never negative).
 * - Does NOT simply sum stored remaining or calculate Total Invoices - Total Payments.
 */
export function calculateTotalOutstanding(
  invoices: Invoice[] = [],
  payments: Payment[] = []
): number {
  if (!Array.isArray(invoices)) return 0;

  // 1. Valid, real payments where isVoid !== true
  const validPayments = Array.isArray(payments)
    ? payments.filter((p) => p && typeof p === 'object' && Boolean(p.id) && p.isVoid !== true)
    : [];

  // 2. Valid, real invoices where isVoid !== true and not quotation/rejected (only payable sales)
  const validInvoices = invoices.filter(
    (inv) =>
      inv &&
      typeof inv === 'object' &&
      Boolean(inv.id) &&
      inv.isVoid !== true &&
      inv.status !== 'Void' &&
      inv.billingState !== 'quotation' &&
      inv.billingState !== 'rejected'
  );

  // 3. Fast lookup: invoiceId set + billNumber -> invoice.id for fallback matching if an older payment record lacked invoiceId
  const invoiceIdSet = new Set<string>();
  const billNumberToInvoiceId = new Map<string, string>();
  for (const inv of validInvoices) {
    invoiceIdSet.add(inv.id);
    if (inv.billNumber) {
      billNumberToInvoiceId.set(inv.billNumber, inv.id);
    }
  }

  // 4. Sum valid payments per invoice using actual database relationships
  const paymentsByInvoiceId = new Map<string, number>();
  for (const p of validPayments) {
    const rawAmt = typeof p.amount === 'number' ? p.amount : parseFloat(String(p.amount ?? 0));
    const safeAmt = Number.isFinite(rawAmt) && rawAmt > 0 ? rawAmt : 0;

    let targetInvoiceId: string | undefined = undefined;
    if (p.invoiceId && invoiceIdSet.has(p.invoiceId)) {
      targetInvoiceId = p.invoiceId;
    } else if (p.billNumber && billNumberToInvoiceId.has(p.billNumber)) {
      targetInvoiceId = billNumberToInvoiceId.get(p.billNumber);
    } else if (p.invoiceId && billNumberToInvoiceId.has(p.invoiceId)) {
      targetInvoiceId = billNumberToInvoiceId.get(p.invoiceId);
    }

    if (targetInvoiceId) {
      paymentsByInvoiceId.set(
        targetInvoiceId,
        (paymentsByInvoiceId.get(targetInvoiceId) || 0) + safeAmt
      );
    }
  }

  // 5. Calculate Invoice Outstanding for every valid invoice and sum
  let totalOutstanding = 0;

  for (const inv of validInvoices) {
    const rawTotal = typeof inv.totalAmount === 'number'
      ? inv.totalAmount
      : parseFloat(String(inv.totalAmount ?? 0));
    const invoiceTotalAmount = Number.isFinite(rawTotal) && rawTotal > 0 ? rawTotal : 0;

    const invoicePaidAmount = paymentsByInvoiceId.get(inv.id) || 0;

    // A fully paid invoice contributes 0; if overpaid/inconsistent, clamp to 0
    const invoiceOutstanding = Math.max(0, invoiceTotalAmount - invoicePaidAmount);

    totalOutstanding += invoiceOutstanding;
  }

  return Math.round(totalOutstanding);
}

/**
 * Convenience helper to compute all 5 Organization KPIs simultaneously
 */
export function calculateOrganizationKPIs(params: {
  users?: UserProfile[];
  customers?: Customer[];
  invoices?: Invoice[];
  payments?: Payment[];
}) {
  return {
    totalUsersCount: calculateTotalUsers(params.users),
    totalCustomersCount: calculateTotalCustomers(params.customers),
    totalInvoicesCount: calculateTotalInvoices(params.invoices),
    totalPaymentsAmount: calculateTotalPayments(params.payments),
    totalOutstandingAmount: calculateTotalOutstanding(params.invoices, params.payments),
  };
}

