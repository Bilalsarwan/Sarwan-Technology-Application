import { Invoice, Payment, Expense } from '../types';
import { SuperAdminDashboardData } from '../services/dashboardAuthorization';
import { formatAFN, getTodayDateString } from './format';

export interface FinancialPerformanceSummary {
  sales: number;
  payments: number;
  expenses: number;
  net: number;
  invoicesCount?: number;
  paymentsCount?: number;
}

export interface AllFinancialPerformanceSummaries {
  daily: FinancialPerformanceSummary & { invoicesCount: number; paymentsCount: number };
  weekly: FinancialPerformanceSummary;
  monthly: FinancialPerformanceSummary;
}

/**
 * Safely parses any value into a finite number.
 * Returns 0 for null, undefined, NaN, Infinity, -Infinity, empty strings, and non-numeric values.
 */
export function parseSafeAmount(value: unknown): number {
  if (value === null || value === undefined || value === '') return 0;
  if (typeof value === 'number') {
    return Number.isFinite(value) ? value : 0;
  }
  const parsed = parseFloat(String(value).trim());
  return Number.isFinite(parsed) ? parsed : 0;
}

/**
 * Checks if an invoice is valid and non-void for Financial Performance calculation.
 * Excludes:
 * - isVoid === true
 * - status === 'Void'
 * - deleted / non-existent / empty records
 */
export function isValidInvoiceForPerformance(inv: unknown): inv is Invoice {
  if (!inv || typeof inv !== 'object') return false;
  const i = inv as Partial<Invoice>;
  if (!i.id || typeof i.id !== 'string') return false;
  if (i.isVoid === true) return false;
  if (i.status === 'Void') return false;
  return true;
}

/**
 * Checks if an expense meets the official financial rule:
 * For actual financial totals, use ONLY: status === "executed".
 * Excludes:
 * - pending_manager: No
 * - pending_admin: No
 * - approved: No (approved has been approved but NOT yet executed/disbursed)
 * - rejected: No
 * - executed: Yes
 */
export function isValidExpenseForPerformance(exp: unknown): exp is Expense {
  if (!exp || typeof exp !== 'object') return false;
  const e = exp as Partial<Expense>;
  if (!e.id || typeof e.id !== 'string') return false;

  const status = String(e.status || '').toLowerCase().trim();

  // Official rule: ONLY status === 'executed' is an actual financial expense!
  if (status === 'executed') {
    return true;
  }

  return false;
}

/**
 * Checks if a payment is valid for Financial Performance calculation.
 * Excludes:
 * - isVoid === true
 * - deleted / non-existent / empty records
 * - payments belonging to void invoices
 * - payments that do not belong to a valid invoice (when invoice index is available)
 */
export function isValidPaymentForPerformance(
  payment: unknown,
  validInvoiceIds?: Set<string>,
  validBillNumbers?: Set<string>,
  voidInvoiceIds?: Set<string>,
  voidBillNumbers?: Set<string>
): payment is Payment {
  if (!payment || typeof payment !== 'object') return false;
  const p = payment as Partial<Payment>;
  if (!p.id || typeof p.id !== 'string') return false;
  if (p.isVoid === true) return false;

  const invoiceId = p.invoiceId?.trim();
  const billNumber = p.billNumber?.trim();

  // Exclude payments belonging to void invoices
  if (invoiceId && voidInvoiceIds?.has(invoiceId)) return false;
  if (billNumber && voidBillNumbers?.has(billNumber)) return false;

  // If a set of valid invoices is available, enforce that payment belongs to a valid invoice
  if (validInvoiceIds && validInvoiceIds.size > 0) {
    const belongsToValid =
      (invoiceId && validInvoiceIds.has(invoiceId)) ||
      (billNumber && validBillNumbers?.has(billNumber));
    if (!belongsToValid) return false;
  }

  return true;
}

/**
 * Extracts a calendar date string in YYYY-MM-DD format without UTC shifts.
 * Directly respects YYYY-MM-DD strings without passing through UTC conversion.
 */
export function extractCalendarDateString(
  recordDate?: string,
  recordCreatedAt?: string
): string | null {
  const raw = (recordDate || recordCreatedAt || '').trim();
  if (!raw) return null;

  // If already standard YYYY-MM-DD, return directly to avoid timezone drift
  if (/^\d{4}-\d{2}-\d{2}$/.test(raw)) {
    return raw;
  }

  // If starts with YYYY-MM-DD (e.g. ISO string like 2026-09-18T12:00:00)
  const isoPrefixMatch = raw.match(/^(\d{4}-\d{2}-\d{2})/);
  if (isoPrefixMatch) {
    // Check if it has a timezone offset or Z
    if (raw.includes('T') || raw.includes('Z')) {
      const parsed = new Date(raw);
      if (!isNaN(parsed.getTime())) {
        const y = parsed.getFullYear();
        const m = String(parsed.getMonth() + 1).padStart(2, '0');
        const d = String(parsed.getDate()).padStart(2, '0');
        return `${y}-${m}-${d}`;
      }
    }
    return isoPrefixMatch[1];
  }

  // Parse other date formats
  const parsed = new Date(raw);
  if (isNaN(parsed.getTime())) return null;
  const y = parsed.getFullYear();
  const m = String(parsed.getMonth() + 1).padStart(2, '0');
  const d = String(parsed.getDate()).padStart(2, '0');
  return `${y}-${m}-${d}`;
}

/**
 * Computes deterministic calendar date ranges:
 * - Daily: Current application-local calendar day (YYYY-MM-DD)
 * - Last 7 Days: Current calendar day + previous 6 calendar days (strictly 7 calendar days)
 * - This Month: Current calendar month (YYYY-MM)
 */
export function getCalendarDateRanges(referenceDate: Date = new Date()): {
  todayStr: string;
  last7DaysSet: Set<string>;
  last7DaysStartStr: string;
  last7DaysEndStr: string;
  thisMonthPrefix: string;
} {
  const year = referenceDate.getFullYear();
  const month = referenceDate.getMonth();
  const day = referenceDate.getDate();

  const pad = (n: number) => String(n).padStart(2, '0');

  const todayStr = `${year}-${pad(month + 1)}-${pad(day)}`;
  const thisMonthPrefix = `${year}-${pad(month + 1)}`;

  const last7DaysSet = new Set<string>();
  // Exactly 7 calendar days: today (i=0) + previous 6 days (i=1..6)
  for (let i = 0; i < 7; i++) {
    const d = new Date(year, month, day - i);
    const dStr = `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
    last7DaysSet.add(dStr);
  }

  const startD = new Date(year, month, day - 6);
  const last7DaysStartStr = `${startD.getFullYear()}-${pad(startD.getMonth() + 1)}-${pad(startD.getDate())}`;
  const last7DaysEndStr = todayStr;

  return {
    todayStr,
    last7DaysSet,
    last7DaysStartStr,
    last7DaysEndStr,
    thisMonthPrefix,
  };
}

/**
 * Master calculation function for Financial Performance Overview.
 * Computes Daily, Last 7 Days, and This Month metrics based on strict business rules:
 * - Sales: valid non-void invoices
 * - Payments: valid non-void payments belonging to valid invoices
 * - Expenses: approved AND executed expenses
 * - Net Result: Sales - Expenses
 */
export function calculateFinancialPerformance(params: {
  invoices?: Invoice[];
  payments?: Payment[];
  expenses?: Expense[];
  fallbackData?: SuperAdminDashboardData;
  referenceDate?: Date;
}): AllFinancialPerformanceSummaries {
  const { invoices = [], payments = [], expenses = [], fallbackData, referenceDate } = params;

  // If no raw collections are provided but fallbackData exists, use fallback
  const hasRawData = invoices.length > 0 || payments.length > 0 || expenses.length > 0;
  if (!hasRawData && fallbackData) {
    return {
      daily: {
        sales: parseSafeAmount(fallbackData.dailySummary?.sales),
        payments: parseSafeAmount(fallbackData.dailySummary?.payments),
        expenses: parseSafeAmount(fallbackData.dailySummary?.expenses),
        net:
          parseSafeAmount(fallbackData.dailySummary?.sales) -
          parseSafeAmount(fallbackData.dailySummary?.expenses),
        invoicesCount: fallbackData.dailySummary?.invoicesCount || 0,
        paymentsCount: fallbackData.dailySummary?.paymentsCount || 0,
      },
      weekly: {
        sales: parseSafeAmount(fallbackData.weeklySummary?.sales),
        payments: parseSafeAmount(fallbackData.weeklySummary?.payments),
        expenses: parseSafeAmount(fallbackData.weeklySummary?.expenses),
        net:
          parseSafeAmount(fallbackData.weeklySummary?.sales) -
          parseSafeAmount(fallbackData.weeklySummary?.expenses),
      },
      monthly: {
        sales: parseSafeAmount(fallbackData.monthlySummary?.sales),
        payments: parseSafeAmount(fallbackData.monthlySummary?.payments),
        expenses: parseSafeAmount(fallbackData.monthlySummary?.expenses),
        net:
          parseSafeAmount(fallbackData.monthlySummary?.sales) -
          parseSafeAmount(fallbackData.monthlySummary?.expenses),
      },
    };
  }

  const { todayStr, last7DaysSet, thisMonthPrefix } = getCalendarDateRanges(referenceDate);

  // 1. Build Invoice index
  const validInvoiceIds = new Set<string>();
  const validBillNumbers = new Set<string>();
  const voidInvoiceIds = new Set<string>();
  const voidBillNumbers = new Set<string>();

  const validInvoices: Invoice[] = [];
  for (const inv of invoices) {
    if (!inv || typeof inv !== 'object' || !inv.id) continue;
    if (inv.isVoid === true || inv.status === 'Void') {
      voidInvoiceIds.add(inv.id);
      if (inv.billNumber) voidBillNumbers.add(inv.billNumber);
    } else {
      validInvoiceIds.add(inv.id);
      if (inv.billNumber) validBillNumbers.add(inv.billNumber);
      validInvoices.push(inv);
    }
  }

  // 2. Filter valid payments belonging to valid invoices
  const validPayments: Payment[] = [];
  for (const p of payments) {
    if (isValidPaymentForPerformance(p, validInvoiceIds, validBillNumbers, voidInvoiceIds, voidBillNumbers)) {
      validPayments.push(p);
    }
  }

  // 3. Filter valid approved & executed expenses
  const validExpenses: Expense[] = [];
  for (const e of expenses) {
    if (isValidExpenseForPerformance(e)) {
      validExpenses.push(e);
    }
  }

  // Helper to determine if a record date belongs to Daily, Last 7 Days, and/or This Month
  const isInDaily = (dateStr: string | null) => Boolean(dateStr && dateStr === todayStr);
  const isInLast7Days = (dateStr: string | null) => Boolean(dateStr && last7DaysSet.has(dateStr));
  const isInThisMonth = (dateStr: string | null) =>
    Boolean(dateStr && dateStr.startsWith(thisMonthPrefix) && dateStr <= todayStr);

  // Daily Accumulators
  let dailySales = 0;
  let dailyInvoicesCount = 0;
  for (const inv of validInvoices) {
    const d = extractCalendarDateString(inv.date, inv.createdAt);
    if (isInDaily(d)) {
      dailySales += parseSafeAmount(inv.totalAmount);
      dailyInvoicesCount++;
    }
  }

  let dailyPayments = 0;
  let dailyPaymentsCount = 0;
  for (const p of validPayments) {
    const d = extractCalendarDateString(p.date, p.createdAt);
    if (isInDaily(d)) {
      dailyPayments += parseSafeAmount(p.amount);
      dailyPaymentsCount++;
    }
  }

  let dailyExpenses = 0;
  for (const e of validExpenses) {
    const d = extractCalendarDateString(e.date, e.createdAt);
    if (isInDaily(d)) {
      dailyExpenses += parseSafeAmount(e.amount);
    }
  }

  // Last 7 Days Accumulators
  let weeklySales = 0;
  for (const inv of validInvoices) {
    const d = extractCalendarDateString(inv.date, inv.createdAt);
    if (isInLast7Days(d)) {
      weeklySales += parseSafeAmount(inv.totalAmount);
    }
  }

  let weeklyPayments = 0;
  for (const p of validPayments) {
    const d = extractCalendarDateString(p.date, p.createdAt);
    if (isInLast7Days(d)) {
      weeklyPayments += parseSafeAmount(p.amount);
    }
  }

  let weeklyExpenses = 0;
  for (const e of validExpenses) {
    const d = extractCalendarDateString(e.date, e.createdAt);
    if (isInLast7Days(d)) {
      weeklyExpenses += parseSafeAmount(e.amount);
    }
  }

  // This Month Accumulators
  let monthlySales = 0;
  for (const inv of validInvoices) {
    const d = extractCalendarDateString(inv.date, inv.createdAt);
    if (isInThisMonth(d)) {
      monthlySales += parseSafeAmount(inv.totalAmount);
    }
  }

  let monthlyPayments = 0;
  for (const p of validPayments) {
    const d = extractCalendarDateString(p.date, p.createdAt);
    if (isInThisMonth(d)) {
      monthlyPayments += parseSafeAmount(p.amount);
    }
  }

  let monthlyExpenses = 0;
  for (const e of validExpenses) {
    const d = extractCalendarDateString(e.date, e.createdAt);
    if (isInThisMonth(d)) {
      monthlyExpenses += parseSafeAmount(e.amount);
    }
  }

  return {
    daily: {
      sales: dailySales,
      payments: dailyPayments,
      expenses: dailyExpenses,
      net: dailySales - dailyExpenses,
      invoicesCount: dailyInvoicesCount,
      paymentsCount: dailyPaymentsCount,
    },
    weekly: {
      sales: weeklySales,
      payments: weeklyPayments,
      expenses: weeklyExpenses,
      net: weeklySales - weeklyExpenses,
    },
    monthly: {
      sales: monthlySales,
      payments: monthlyPayments,
      expenses: monthlyExpenses,
      net: monthlySales - monthlyExpenses,
    },
  };
}
